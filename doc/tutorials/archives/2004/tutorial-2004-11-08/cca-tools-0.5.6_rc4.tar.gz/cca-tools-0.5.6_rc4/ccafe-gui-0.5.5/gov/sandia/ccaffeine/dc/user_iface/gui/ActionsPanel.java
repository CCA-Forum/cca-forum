package gov.sandia.ccaffeine.dc.user_iface.gui;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.filechooser.*;
import gov.sandia.ccaffeine.util.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.Gui;
import gov.sandia.ccaffeine.dc.user_iface.AccessServer;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CcaOneCommandParser;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiUserListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GoEvent;

/**
 * ActionsPanel.java
 */

public class ActionsPanel extends JPanel implements ActionListener{

  private final String[] actions = {
                                    "Run",
				    "Remove",
	       	      		    "Remove All",
     				    "Open...",
      				    "Save",
       				    "Save As..."
                                    };
  private JFileChooser chooser;
  private ExtensionFileFilter filter;
  private Builder builder;
  private Arena arena;
  private GlobalData global;
  private JPanel buttonPanel;

  protected Gui gui = null;
  protected AccessServer accessServer = null;

  protected CcaOneCommandParser parser = null;


  public ActionsPanel(GlobalData global) {
    this.parser = new CcaOneCommandParser();
    this.gui = global.getBuilder().getGui();
    this.accessServer = global.getBuilder().getAccessServer();
    this.global = global;
    initialize();
    if (appletness==false){
	createButtons();
    }
  }
  public void initialize(){

    // Check whether this is an applet GUI or not
    appletness  = LocalSystem.isApplet();

    setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
    if (appletness==false){
	setBorder(actionsBorder);
    }

    arena = global.getArena();
    builder = global.getBuilder();

    if (appletness==false){
	chooser  = new JFileChooser();
	filter   = new ExtensionFileFilter("bld","Builder files");
	chooser.setFileFilter(filter);
    }
    buttonPanel = new JPanel();
    global.setActionsPanel(this);
  }

  private void createButtons() {
    for(int i = 0; i < actions.length; i++){
	JButton b = new JButton(actions[i]);
	b.setActionCommand(i+"");
	b.addActionListener(this);
	add(b);
	if(i==0 || i==2)
	    add(Box.createHorizontalStrut(5));
    }
    add(Box.createHorizontalGlue());
    setMaximumSize(new Dimension(9999,getPreferredSize().height));
  }

  public void actionPerformed(ActionEvent e) {
    int action = Integer.parseInt(e.getActionCommand());
    switch(action) {
    case 0:
      doGoAction();
      break;
    case 1:
      doRemoveAction();
      break;
    case 2:
      doRemoveAllAction();
      break;
    case 3:
      doOpenAction();
      break;
    case 4:
      doSaveAction();
      break;
    case 5:
      doSaveAsAction();
      break;
    default:
      global.err.println("Bad action command in button");
      break;
    }
  }
  private void doRemoveAction() {
    if(arena.getSelectedComponentInstance() != null) {

          String componentInstanceName =
              arena.getSelectedComponentInstance().getInstanceName();
      global.addToHistoryAndToDebugger("remove " + componentInstanceName);
      this.accessServer.broadcastRemove(componentInstanceName);
    }
  }
  public void doRemoveAllAction() {
    Component[] c = arena.getComponents();
    for(int i = 0;i < c.length;i++) {
      if(c[i] instanceof ComponentInstance) {
        String componentInstanceName =
            ((ComponentInstance)c[i]).getInstanceName();
	global.addToHistoryAndToDebugger("remove " + componentInstanceName);
        this.accessServer.broadcastRemove(componentInstanceName);
      }
    }
  }
  private void doGoAction() {
    //global.write("go");
    global.addToHistoryAndToDebugger("go");

    /* get all of the components in the arena */
    Hashtable componentInstances = arena.getComponentInstances();

    Enumeration keys = componentInstances.keys();
    while (keys.hasMoreElements()) {

          /* get the name of the component */
          String name = (String)keys.nextElement();

          /* get the component */
          ComponentInstance component =
              (ComponentInstance)componentInstances.get(name);

          /* if the component does NOT have a go_port */
          /* then skip over the component.            */
          if (component.getPort("go_port")==null)
              continue;

          /* create a GoEvent */
          GoEvent event = new GoEvent(this,name,"go_port");

          /* Send the GoEvent to the VIEW.                     */
          /* The VIEW will send a GO command to the cca server */
          this.accessServer.broadcastGo(event);
    }


    //this.accessServer.broadcastGo();
  }





  private int NUKE_ARENA = 0;
  private int MERGE_ARENA = 1;

  private void doOpenAction() {
    int inputMode = NUKE_ARENA; // Whether we merge or we wipe the Arena first.
    Object[] choices = {"new", "merge", "cancel"};
    JOptionPane pain = new JOptionPane("Merge the new file or create a new arena?", JOptionPane.WARNING_MESSAGE);
    pain.setOptions(choices);
    JDialog d = pain.createDialog(builder, "Merge or start over?");
    d.show();
    String selected = (String)pain.getValue();
    if(selected.equals(choices[2])) {// Cancelled.
      return;
    }
    if(selected.equals(choices[0])) {
      inputMode = NUKE_ARENA;
    } else if(selected.equals(choices[1])) {
      inputMode = MERGE_ARENA;
    }
    if(global.getDocChanged()){
      int ans = JOptionPane.showConfirmDialog(builder,
					      "Changes in have not "+
					      "been saved, do you wish "+
					      "to save now?");
      if(ans == JOptionPane.YES_OPTION) {
	saveResave();
      }
    }

    if (appletness==false){
	chooser.rescanCurrentDirectory();
    }

    openDialogOption = chooser.showOpenDialog(builder);
    if(openDialogOption == JFileChooser.APPROVE_OPTION) {
      if(inputMode == NUKE_ARENA) {
	clearArena();
      }
      currentFile = chooser.getSelectedFile();
      toRead = currentFile;
      try {
	readFile(toRead);
      } catch(IOException x) {
	String msg = "There has been a file read error,\n loading of file: "+
	  toRead.getAbsolutePath()+".\n Read is terminated.";
	JOptionPane.showMessageDialog(builder,
				      msg,
				      "Error",
				      JOptionPane.ERROR_MESSAGE );
	return;
      }
    }
  }

  public boolean notCanceled(String msg) {
    confirmClose = JOptionPane.showConfirmDialog(builder, msg);
    switch(confirmClose) {
    case JOptionPane.CANCEL_OPTION:
      return false;
      //      break;
    case JOptionPane.NO_OPTION:
      return false;
      //      break;
    case JOptionPane.YES_OPTION:
      return saveResave();
      //      break;
    }
    return false;
  }


  private void doSaveAction(){
    saveResave();
  }
  private void doSaveAsAction(){
    saveDialog();
  }

  protected void openDialog() throws IOException{
    if (appletness==false){
	chooser.rescanCurrentDirectory();
    }
    openDialogOption = chooser.showOpenDialog(builder);
    if(openDialogOption == JFileChooser.APPROVE_OPTION) {
      clearArena();
      currentFile = chooser.getSelectedFile();
      toRead = currentFile;
      readFile(toRead);
    }
  }
  public void loadFile(String file) throws IOException {
    File f;
      f = new File(file);
      readFile(f);
  }

  protected void readFile
      (File file)
      throws IOException {

    String currentLine;
    global.setIgnoreChanges(true);
    input = new BufferedReader(new FileReader(file));



    while ((currentLine = input.readLine()) != null) {
      makeHistory(currentLine);
    }
    input.close();

    global.setDocUnsaved(false);
    global.setDocChanged(false);
    global.setDocName(file.getName());
    builder.updateTitle();
    global.setIgnoreChanges(false);
  }

  /** This is poorly named.  This just feeds the file back into the
   * system. */
  protected void makeHistory
      (String currentLine)
      throws IOException {

    while(global.getWaitingForPorts()){
      try{Thread.sleep(100);}catch(Exception e){}
      System.out.println("WAITING FOR PORTS");
    }
    if(currentLine.equals("eof")){
      if(progressDialog != null)
	progressDialog.hide();
    }
    else{
      if(currentLine.equals(""))
	return;
      else if(currentLine.startsWith("commandCount"))
	showProgressDialog(currentLine);
      else if(currentLine.startsWith("setSize"));
      //builder.setSize(currentLine);
      else if(currentLine.startsWith("setMaximum"));
      //try{builder.setMaximum(currentLine);}catch(Exception e){}



      else{
	incrementProgressBar(currentLine);

        /* tokenize the current line that we read from the file */
        StringTokenizer s = new StringTokenizer(currentLine);
        Vector tok = new Vector();
        while(s.hasMoreTokens()) {
            tok.add(s.nextToken());
        }

	if(currentLine.startsWith("setDropLocation"))
	  global.setDropLocation(currentLine);
	else if(currentLine.startsWith("move"))
	  arena.moveComponentInstance(currentLine);
	else {
	  // Check to see if the this is an instantiation, then check
	  // to see if the instance name is already taken.
	  if(currentLine.startsWith("pulldown") ||
	     currentLine.startsWith("instantiate") ||
	     currentLine.startsWith("create") ) {

	    if(tok.size() == 3) {
	      String instanceName = (String)tok.get(2);
	      if(arena.getComponentInstance(instanceName) != null) {
		// There already is a component by that name in the arena.
		String msg = "This file requests a component with \n"+
		  "an instance"+
		  " name: "+instanceName+".\n"+
		  "A component by this name already appears"+
		  " in the Arena.\nLoading will end and"+
		  " the state of the Arena is unknown.";
		JOptionPane.
		  showMessageDialog(builder,
				    msg,
				    "Error",
				    JOptionPane.ERROR_MESSAGE );
		progressDialog.hide();
		throw new IOException(msg);
	      }
	    }
	  } //is {pulldown, instantiate, create}
	  int prevCount = arena.getComponentCount();


	 //global.write(currentLine);
         global.addToHistoryAndToDebugger(currentLine);
         this.parser.parse(currentLine);


	  if(currentLine.startsWith("pulldown")){
	    while(arena.getComponentCount() <= prevCount){
	      try{Thread.sleep(100);}catch(Exception e){}
	    }
	  }
	  else if(currentLine.startsWith("remove")){
	    while(arena.getComponentCount() >= prevCount){
	      try{Thread.sleep(100);}catch(Exception e){}
	    }
	  }
	  try{Thread.sleep(1000);}catch(Exception e){}
	}//not {setDropLocation,move}



	if(currentLine.startsWith("pulldown") ||
	   currentLine.startsWith("move")     ||
	   currentLine.startsWith("go")   ||
	   currentLine.startsWith("remove")   ||
	   currentLine.startsWith("connect"))
	  arena.update(arena.getGraphics());
      }//not {commandCount, setSize, setMaximum}



    }
  }
  private void showProgressDialog(String s){
    StringTokenizer tokens = new StringTokenizer(s);
    tokens.nextToken();
    int count = Integer.parseInt(tokens.nextToken());
    JOptionPane pane = new JOptionPane("");
    pane.removeAll();
    progressBar = new JProgressBar(0, count);
    progressBar.setStringPainted(true);
    pane.add(progressBar);
    elapsedTime = new JLabel("0 seconds elapsed");
    JPanel panel = new JPanel();
    panel.add(elapsedTime);
    pane.add(panel);
    progressDialog = pane.createDialog
      (global.getAppFrame(), "Opening File...");
    startTime = new Date().getTime();
    (new Thread(new ShowProgress())).start();
  }


  private void incrementProgressBar(String s){
    if(progressBar != null){
      StringTokenizer tokens = new StringTokenizer(s);
      String command = tokens.nextToken();
      progressBar.setValue(progressBar.getValue() + 1);
      progressBar.setString(command + " ("
			    + progressBar.getValue() + "/"
			    + progressBar.getMaximum() + ")");
      long elapsed = ((new Date().getTime()) - startTime) / 1000;
      elapsedTime.setText(Long.toString(elapsed)
			  + " seconds elapsed");
      elapsedTime.setSize(elapsedTime.getPreferredSize());
      progressDialog.update(progressDialog.getGraphics());
    }
  }

  protected boolean saveResave(){
    if (global.getDocUnsaved()){
      currentFile = new File(global.getDocName());
      return(saveDialog());
    }
    else{
      writeFile(currentFile);
      return true;
    }
  }
  protected boolean saveDialog(){
    chooser.setSelectedFile(currentFile);
    chooser.rescanCurrentDirectory();
    saveDialogOption = chooser.showSaveDialog(builder);
    if(saveDialogOption == JFileChooser.APPROVE_OPTION) {
      toWrite = chooser.getSelectedFile();
      if(!(toWrite.toString().endsWith(".bld"))){
	addSuffix = toWrite.toString() + ".bld";
	currentFile = new File(addSuffix);
	toWrite = currentFile;
      }
      if(toWrite.exists()){
	overWriteMessage = "Overwrite " + "\"" +
	  toWrite.getName() + "\"?";
	confirmOverWrite = JOptionPane.showConfirmDialog
	  (builder, overWriteMessage);
	if(confirmOverWrite != JOptionPane.CANCEL_OPTION){
	  if(confirmOverWrite == JOptionPane.YES_OPTION){
	    global.setDocName(toWrite.getName());
	    writeFile(toWrite);
	    return true;
	  }
	  else return saveDialog();
	} else return false;
      }else {
	global.setDocName(toWrite.getName());
	writeFile(toWrite);
	return true;
      }
    } else {
      return false;
    }
  }

  protected void writeFile(File file){
    try{
      output = new FileWriter(file);
      output.write("commandCount "
		   + global.getCommandCount() + "\n");
      output.write("setSize "
		   + builder.getWidth()  + " "
		   + builder.getHeight() + "\n" );
      if(global.getBuilder().isMaximum())
	output.write("setMaximum true\n");
      else
	output.write("setMaximum false\n");
      output.write(global.getHistory());
      output.write("eof\n");
      output.flush();
      output.close();
    } catch (IOException e) {
      global.err.println("Write failed\n" +
			 e.toString());
    }
    global.setDocChanged(false);
    global.setDocUnsaved(false);
    builder.updateTitle();
  }

  protected void clearArena(){//for new and open actions
    global.setIgnoreChanges(true);//prevents unnecessary title updates
    global.getActionsPanel().doRemoveAllAction();
    while(arena.getComponentCount() > 0){
      try{Thread.sleep(100);}catch(Exception e){}
    }
    arena.updateUI();
  }

  //This group is related to FileChooser operations
  private int           confirmClose;
  private int       confirmOverWrite;
  private int       saveDialogOption;
  private int       openDialogOption;
  private String           arenaInfo;
  private String           addSuffix;
  private String    overWriteMessage;
  private File                toRead;
  private File               toWrite;
  private File           currentFile;
  private BufferedReader       input;
  private FileWriter          output;

  private long             startTime;
  private JLabel         elapsedTime;
  private JProgressBar   progressBar;
  private JDialog     progressDialog;


  private static boolean appletness;

  private final Border actionsBorder = BorderFactory.createCompoundBorder
    (BorderFactory.createTitledBorder("Actions"),
     BorderFactory.createEmptyBorder(5,5,5,5));

  private class ShowProgress implements Runnable{
    public void run(){
      progressDialog.show();
    }
  }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    synchronized public void addGuiUserListener(GuiUserListener listener) {
        this.parser.addGuiUserListener(listener);    }

    synchronized public void removeGuiUserListener(GuiUserListener listener) {
       this.parser.removeGuiUserListener(listener);
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    synchronized public void addGuiListener(GuiListener listener) {
        this.parser.addGuiListener(listener);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    synchronized public void removeGuiListener(GuiListener listener) {
        this.parser.removeGuiListener(listener);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


} // ActionsPanel
