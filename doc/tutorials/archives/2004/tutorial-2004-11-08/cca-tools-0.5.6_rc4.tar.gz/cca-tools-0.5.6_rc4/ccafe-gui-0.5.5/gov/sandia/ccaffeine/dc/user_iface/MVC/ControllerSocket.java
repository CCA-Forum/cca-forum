package gov.sandia.ccaffeine.dc.user_iface.MVC;



import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUI;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIAddComponentClass;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIAddProvidesPorts;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIAddUsesPorts;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIConnect;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIDisconnect;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIExit;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIGetProperty;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIInstantiate;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUILoad;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIMessage;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamCurrent;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamDefault;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamDialog;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamEndDialog;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamField;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamHelp;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamNumberRange;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamPrompt;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamStringChoice;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamTab;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIRemove;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIRevalidate;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUISetProperty;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUISetPortProperty;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdContextGUI;
import gov.sandia.ccaffeine.cmd.CmdParse;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiUserListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ControllerListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ClientSocket;


/**
 * An MVC controller.
 * This controller receives commands and data from
 * the cca server.  Usually the data is forwarded to
 * the CmdParse for parsing.
 */

/*
 * Programmer's Notes:
 * scenario:  GUI wants to populate the palette
 *    GUI formulates a query that asks for all the components in the palette
 *    GUI sends the query to the ViewSocket
 *        NOTE:  The ViewSocket is a GuiListener
 *    ViewSocket forwards the query to the cca server
 *    cca server sends the components to the ControllerSocket
 *    ControllerSocket sends the data to CmdParse
 *    CmdParse invokes one of the CmdActionXXX classes
 *    CmdActionXXX invokes the CmdAction class
 *    CmdAction sends an event to the GUI
 *        NOTE:  The GUI is a ControllerListener
 */

public class ControllerSocket {

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    ClientSocket clientSocket = null;

    CmdContextGUI cmdContextGUI = null;

    java.util.Vector vectorCmdActionGui = null;

    CmdParse parser = null;


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Create an MVC controller.
     * This controller receives input from the cca server.
     * @param inputStream The input stream that is used
     * to read commands & data from the input stream.
     */
    public ControllerSocket(ClientSocket clientSocket) {

        this.clientSocket = clientSocket;

        /* Create a CmdContextGUI */
        this.cmdContextGUI = new CmdContextGUI(this);

        /* turn off the "gui>" prompt that cmdContextGUI prints to stdout */
        this.cmdContextGUI.setPromptDisplayed(false);

        /* Create a parser */
        this.parser = new CmdParse(cmdContextGUI);
        parser.setContextVerbose(false);
        addActionsToParser(parser);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    synchronized public String readLine() throws java.io.IOException {
        //return(this.clientSocket.readLine());
        String oneLine = this.clientSocket.readLine();
        System.out.println("IN: " + oneLine + "\n");
        return(oneLine);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    private void addActionsToParser(CmdParse parser){




        /* We want to be able to interact with the GUI */
        //Gui gui = new Gui(this);

        //cmdContextGui.addAccessGuiListener(gui);





        this.vectorCmdActionGui = new java.util.Vector();




        /*
         When this client establishes a communication link
         with the cca server, the cca server sends the classes
         of all the cca components to the client.  The classes
         are sent one class at a time.  When the client
         receives a class, the client displays the class
         in the palette.
         */
	//parser.addAction(new CmdActionGUIAddComponentClass(this));//S
        CmdActionGUI addComponentClassAction =
            new CmdActionGUIAddComponentClass();
        //addComponentClassAction.addServerListener(gui);
        this.vectorCmdActionGui.add(addComponentClassAction);
        parser.addAction(addComponentClassAction);





        /*
         When the client drags a cca component from the
         palette to the arena, the cca server instantiates
         a new cca component, creates the Provides Ports for
         the cca component, and creates the Uses Ports for the
         cca component.  The cca server sends the Provides Ports
         to the client.  The client renders the Provides ports
         are small boxes on the left side of the component.
         */
	//parser.addAction(new CmdActionGUIAddProvidesPorts(this)); //Is*
        CmdActionGUI addProvidesPortsAction =
            new CmdActionGUIAddProvidesPorts();
        //addProvidesPortsAction.addServerListener(gui);
        this.vectorCmdActionGui.add(addProvidesPortsAction);
        parser.addAction(addProvidesPortsAction);




       /*
        * When the client drags a cca component from the
        * palette to the arena, the cca server instantiates
        * a new cca component, creates the Provides Ports for
        * the cca component, and creates the Uses Ports for the
        * cca component.  The cca server sends the Uses Ports
        * to the client.  The client renders the Uses ports
        * are small boxes on the right side of the component.
        */
	//parser.addAction(new CmdActionGUIAddUsesPorts(this));     //Is*
        CmdActionGUI addUsesPortsAction
            = new CmdActionGUIAddUsesPorts();
        //addUsesPortsAction.addServerListener(gui);
        this.vectorCmdActionGui.add(addUsesPortsAction);
        parser.addAction(addUsesPortsAction);





        /*
         * When the end-user clicks on a red Uses Port and then
         * clicks on a Provides Port, the cca server connects
         * the two ports.  The cca server sends a connect message
         * to the client.  The client responds by drawing a line
         * between the two ports.
         */
	//parser.addAction(new CmdActionGUIConnect(this));          //ISIS
        CmdActionGUI connectAction = new CmdActionGUIConnect();
        //connectAction.addServerListener(gui);
        this.vectorCmdActionGui.add(connectAction);
        parser.addAction(connectAction);




       /*
        * If the screen is showing a line connecting a Provides Port
        * with a Uses Port and if the end-user clicks on the Provides Port
        * then the cca server removes the connection.  The cca server
        * sends a disconnect message to this client.  The client
        * responds by removing the line.
        */
	//parser.addAction(new CmdActionGUIDisconnect(this));          //ISIS
        CmdActionGUI disconnectAction = new CmdActionGUIDisconnect();
        //disconnectAction.addServerListener(gui);
        this.vectorCmdActionGui.add(disconnectAction);
        parser.addAction(disconnectAction);




        /*
         If the end-user clicks on the File->Exit menu item
         then the cca server breaks its connection with this
         client.  Before severing the connection, the cca
         server sends a disconnect message to the client.
         The client responds by closing the application.
         */
	//parser.addAction(new CmdActionGUIExit(this));             //
        CmdActionGUI exitAction = new CmdActionGUIExit();
        //exitAction.addServerListener(gui);
        this.vectorCmdActionGui.add(exitAction);
        parser.addAction(exitAction);



        /*
         * Whenever the cca server sets the value of a component
         * property or creates a component property, the cca server
         * sends a message to the client.  This controller forwards
         * the message to the GUI.
         */
	//parser.addAction(new CmdActionGUIGetProperty(this));      //IS
        CmdActionGUI getPropertyAction = new CmdActionGUIGetProperty();
        //getPropertyAction.addServerListener(gui);
        this.vectorCmdActionGui.add(getPropertyAction);
        parser.addAction(getPropertyAction);




       /*
        * The end-user drags a component from the palette to the arena.
        * The cca server uses the component's class to instantiate a
        * brand new cca component object.  The cca server sends the
        * new component to this client.  This client responds by
        * rendering the new component inside the arena.
        */
	//parser.addAction(new CmdActionGUIInstantiate(this));      //CS
        CmdActionGUI instantiateAction = new CmdActionGUIInstantiate();
        //instantiateAction.addServerListener(gui);
        this.vectorCmdActionGui.add(instantiateAction);
        parser.addAction(instantiateAction);



         /*
          * Whenever the cca server wants the GUI to render
          * a widget, the cca server will send a message to the client.
          * This controller will forward the message to the GUI.
          * The GUI will render the widget.
          */
	//parser.addAction(new CmdActionGUILoad(this));
        CmdActionGUI loadAction = new CmdActionGUILoad();
        //loadAction.addServerListener(gui);
        this.vectorCmdActionGui.add(loadAction);
        parser.addAction(loadAction);




       /*
        * If the end-user clicks on the GO button,
        * the cca server executes the go command.
        * The cca server also sends a Message to this client.
        * The client responds by writing the message to standard out.
        */
	//parser.addAction(new CmdActionGUIMessage(this));          //ISIS
        CmdActionGUI messageAction = new CmdActionGUIMessage();
        //messageAction.addServerListener(gui);
        this.vectorCmdActionGui.add(messageAction);
        parser.addAction(messageAction);




       /*
        * The cca server is sending the value
        * of one of these data fields.  A view entity might
        * respond by displaying the current value on the screen.
        */
	//parser.addAction(new CmdActionGUIParamCurrent(this));     //ISs*
        CmdActionGUI paramCurrentAction = new CmdActionGUIParamCurrent();
        //paramCurrentAction.addServerListener(gui);
        this.vectorCmdActionGui.add(paramCurrentAction);
        parser.addAction(paramCurrentAction);




       /*
        * The cca server is sending the default value
        * of one of these data fields.  A view entity
        * might respond by checking the state of a
        * data field; if the data field does not have
        * a current value then the default value is
        * displayed on the screen.
        */
	//parser.addAction(new CmdActionGUIParamDefault(this));     //ISs*
        CmdActionGUI paramDefaultAction = new CmdActionGUIParamDefault();
        //paramDefaultAction.addServerListener(gui);
        this.vectorCmdActionGui.add(paramDefaultAction);
        parser.addAction(paramDefaultAction);




       /*
        * The cca server wants the client to
        * create (but not display) a dialog box
        * that contains the values
        * of all the data fields in the port.  A view
        * entity might respond by creating an empty
        * dialog box.
        */
	//parser.addAction(new CmdActionGUIParamDialog(this));      //ISs*
        CmdActionGUI paramDialogAction = new CmdActionGUIParamDialog();
        //paramDialogAction.addServerListener(gui);
        this.vectorCmdActionGui.add(paramDialogAction);
        parser.addAction(paramDialogAction);





       /*
        * The cca server has finished sending information
        * for all the data fields in a port.  A client
        * entity might respond by displaying a dialog box
        * that was already populated with information
        * from all the data fields.
        */
	//parser.addAction(new CmdActionGUIParamEndDialog(this));   //IS
        CmdActionGUI paramEndDialogAction = new CmdActionGUIParamEndDialog();
        //paramEndDialogAction.addServerListener(gui);
        this.vectorCmdActionGui.add(paramEndDialogAction);
        parser.addAction(paramEndDialogAction);




       /*
        * The cca server has sent this client
        * the name of a data field that is
        * inside a port.  This controller will
        * forward the information to the GUI.
        */
	//parser.addAction(new CmdActionGUIParamField(this));       //ISS
        CmdActionGUI paramFieldAction = new CmdActionGUIParamField();
        //paramFieldAction.addServerListener(gui);
        this.vectorCmdActionGui.add(paramFieldAction);
        parser.addAction(paramFieldAction);






       /*
        * The cca server has sent this client
        * some helpful info about this component parameter.
        * This controller will forward the information to the GUI.
        * The GUI will create a tool tip for this parameter.
        */
	//parser.addAction(new CmdActionGUIParamHelp(this));        //ISs*
        CmdActionGUI paramHelpAction = new CmdActionGUIParamHelp();
        //paramHelpAction.addServerListener(gui);
        this.vectorCmdActionGui.add(paramHelpAction);
        parser.addAction(paramHelpAction);



        /*
         * The cca server has sent the client the lower and
         * upper bounds for the value of a component parameter.
         * This controller will forward the information to the GUI.
         */
	//parser.addAction(new CmdActionGUIParamNumberRange(this)); //ISSS
        CmdActionGUI paramNumberRangeAction = new CmdActionGUIParamNumberRange();
        //paramNumberRangeAction.addServerListener(gui);
        this.vectorCmdActionGui.add(paramNumberRangeAction);
        parser.addAction(paramNumberRangeAction);



        /*
         * The cca server has sent the client the text contents
         * of a prompt for a component parameter.  This controller
         * will forward the prompt to the GUI.  The GUI will
         * display the prompt to the left of the component parameter.
         */
	//parser.addAction(new CmdActionGUIParamPrompt(this));      //ISs*
        CmdActionGUI paramPromptAction = new CmdActionGUIParamPrompt();
        //paramPromptAction.addServerListener(gui);
        this.vectorCmdActionGui.add(paramPromptAction);
        parser.addAction(paramPromptAction);



        /*
         * The cca server has sent the client one of the values that
         * a component parameter can have.  This controller will
         * forward the prompt to the GUI.  The GUI will
         * insert the value into a choice box.
         */
	//parser.addAction(new CmdActionGUIParamStringChoice(this));//ISs*
        CmdActionGUI paramStringChoiceAction = new CmdActionGUIParamStringChoice();
        //paramStringChoiceAction.addServerListener(gui);
        this.vectorCmdActionGui.add(paramStringChoiceAction);
        parser.addAction(paramStringChoiceAction);




        /*
         * The cca server wants the client to create an empty
         * tabbed pane (The cca serer will later populate the
         * tabbed pane with the values of several component
         * parameters.).  This controller will forward the request
         * to the GUI.  The GUI will render the tabbed pane.
         */
	//parser.addAction(new CmdActionGUIParamTab(this));         //ISs*
        CmdActionGUI paramTabAction = new CmdActionGUIParamTab();
        //paramTabAction.addServerListener(gui);
        this.vectorCmdActionGui.add(paramTabAction);
        parser.addAction(paramTabAction);



    /*
     * Whenever the cca server destroys one of the instances of
     * a cca component, the cca server will notify the client.
     * This controller will forward the notification to the GUI.
     * The GUI will remove the destroyed component from the arena.
     */
	//parser.addAction(new CmdActionGUIRemove(this));           //I
        CmdActionGUI removeAction = new CmdActionGUIRemove();
        //removeAction.addServerListener(gui);
        this.vectorCmdActionGui.add(removeAction);
        parser.addAction(removeAction);




        /*
         * The cca server wants the client to refresh all
         * of the ports on a specific component.  This
         * controller will forward the request to the GUI.
         * The GUI will refresh the ports.
         */
	//parser.addAction(new CmdActionGUIRevalidate(this));       //I
        CmdActionGUI revalidateAction = new CmdActionGUIRevalidate();
        //revalidateAction.addServerListener(gui);
        this.vectorCmdActionGui.add(revalidateAction);
        parser.addAction(revalidateAction);




        /*
         * Whenever the cca server sets the value of a component
         * property or creates a new component property, the
         * cca server will notify the client.  This controller
         * will forward the notification to the GUI.
         */
	//parser.addAction(new CmdActionGUISetProperty(this));      //ISS
        CmdActionGUI setPropertyAction = new CmdActionGUISetProperty();
        //setPropertyAction.addServerListener(gui);
        this.vectorCmdActionGui.add(setPropertyAction);
        parser.addAction(setPropertyAction);


        /*
         * Whenever the cca server sets the value of a port
         * property or creates a new port property, the
         * cca server will notify the client.  This controller
         * will forward the notification to the GUI.
         */
        //parser.addAction(new CmdActionGUISetProperty(this));      //ISS
        CmdActionGUI setPortPropertyAction = new CmdActionGUISetPortProperty();
        //setPropertyAction.addServerListener(gui);
        this.vectorCmdActionGui.add(setPortPropertyAction);
        parser.addAction(setPortPropertyAction);

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    public void parse(){
	new ParseStarter();
    }
    public class ParseStarter extends Thread{
	public ParseStarter(){start();}
	synchronized public void run(){
	    try{
		parser.parse();
	    }catch(java.io.IOException e){e.printStackTrace();}
	}
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    synchronized public void addControllerListener(ControllerListener listener) {

         /* error check */
         if (this.vectorCmdActionGui == null) return;

         /* how many CmdActionGui components do we have? */
         int numberOfComponents = this.vectorCmdActionGui.size();

         /* add the listener to each CmdActionGui component */
         for (int i=0; i<numberOfComponents; i++) {
             CmdActionGUI x = (CmdActionGUI)(this.vectorCmdActionGui.get(i));
             x.addControllerListener(listener);
         }

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    synchronized public void removeControllerListener(ControllerListener listener) {

         /* error check */
         if (this.vectorCmdActionGui == null) return;

         /* how many CmdActionGui components do we have? */
         int numberOfComponents = this.vectorCmdActionGui.size();

         /* remove the listener from each CmdActionGui component */
         for (int i=0; i<numberOfComponents; i++) {
             CmdActionGUI x = (CmdActionGUI)(this.vectorCmdActionGui.get(i));
             x.removeControllerListener(listener);
         }

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    synchronized public void addGuiUserListener(GuiUserListener listener) {
       this.cmdContextGUI.addGuiUserListener(listener);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    synchronized public void removeGuiUserListener(GuiUserListener listener) {
        this.cmdContextGUI.removeGuiUserListener(listener);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
}
