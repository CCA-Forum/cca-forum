package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUI;

/**
 * CmdActionGUIConnect.java
 *
 * If the screen is showing a line connecting a Provides Port
 * with a Uses Port and if the end-user clicks on the Provides Port
 * then the cca server removes the connection.  The cca server
 * sends a disconnect message to this client.  The client
 * responds by removing the line.
 */

public class CmdActionGUIDisconnect
       extends CmdActionGUI
       implements CmdAction {

    public CmdActionGUIDisconnect() {
    }


    public String argtype(){
	return "ISIS";
    }

    public String[] names(){
	return namelist;
    }

    public String help(){
	return "disconnects an existing connection.";
    }

    private static final String[] namelist = {"disconnect"};

    /** It is not safe to assume the input to this is valid,
	as the action of the connection already done in the
        framework may invalidate the ports being connected.
    */
    public void doIt(CmdContext cc, Vector args) {

	CmdContextGUI ccg = (CmdContextGUI)cc;

        /*
         * A connection is made from a source port to a target port.
         * This is the name of the component that houses the source port.
         * The name is usually the java class name of the component
         * (without the package name) concatenated with an index number.
         * Example:  "StartComponent0"
         */
	String     sourceComponentName = (String)args.get(0);

         /*
          * A connection is made from a source port to a target port.
          * This is the name of the source port.
          * The name is usually the java class name of the port
          * (without the package name).
          * Example:  "out0"
          */
	String sourcePortName = (String)args.get(1);

        /*
         * A connection is made from a source port to a target port.
         * This is the name of the component that houses the target port.
         * The name is usually the java class name of the component
         * (without the package name) concatenated with an index number.
         * Example:  "Printer0"
         */
	String     targetComponentName = (String)args.get(2);

         /*
          * A connection is made from a source port to a target port.
          * This is the name of the target port.
          * The name is usually the java class name of the port
          * (without the package name).
          * Example:  "printer_port"
          */
	String targetPortName = (String)args.get(3);


	//ComponentInstance source =
	//    global.getArena().getComponentInstance(sourceName);
	//Port sourcePort =
	//    source.getPort(sourcePortName);
	//ComponentInstance target =
	//    global.getArena().getComponentInstance(targetName);
	//Port targetPort =
	//    target.getPort(targetPortName);
        //if (source == null || target == null ||
        //    sourcePort == null || targetPort == null) {
        //    return;
        //}
	//global.getArena().successfulRemoveConnection
	//    (new Connection(source, sourcePort,
	//		    target, targetPort, global));
        this.broadcastDisconnect
            (sourceComponentName,
             sourcePortName,
             targetComponentName,
             targetPortName);

    } // doIt

} // CmdActionGUIConnect
