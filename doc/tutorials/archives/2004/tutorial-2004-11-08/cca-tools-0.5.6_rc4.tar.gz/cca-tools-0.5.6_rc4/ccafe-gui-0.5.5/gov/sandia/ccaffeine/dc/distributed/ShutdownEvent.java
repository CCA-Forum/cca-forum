package gov.sandia.ccaffeine.dc.distributed;

import java.util.EventObject;


/**
 * Used to pass a shutdown command or shutdown notice from
 * one object to another object.
 */

public class ShutdownEvent extends EventObject {


   /**
    * Create shutdown object.
    * @param source The object that created this
    * ShutdowntEvent.
    */
    public ShutdownEvent(Object source) {
      super(source);
    }
}
