package gov.sandia.ccaffeine.dc.user_iface.MVC.event;


/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * This event can be used to notify components
 * that the cca server is changing the value
 * of one of these data fields.  
 * A view entity might
 * respond by displaying the current value on the screen.
 * <p>
 * This event is also used to notify components
 * that an entity wants to set the value of one of the
 * data fields.  A view entity might
 * respond by sending a "parameters" message
 * to the cca server.
 * <p>
 * Possible Scenario: <br>
 * An end-user clicks on a blue port inside of a component <br>
 * client sends "parameters" to server <br>
 * serer- sends "ParamDialog" to client <br>
 * client responds by creating an empty dialog box <br>
 * server sends "ParamTab" to client <br>
 * client responds by inserting a new tab in the dialog box <br>
 * server sends "ParamField" to client <br>
 * client responds by inserting a blank data line into the dialog box <br>
 * server sends "ParamCurrent" to client <br>
 * client responds by inserting the data's value into the dialog box <br>
 * server sends "ParamHelp" to client <br>
 * client responds by setting the text that is displayed if the help button is clicked <br>
 * server sends "ParamPrompt" to client <br>
 * client responds by displaying a prompt to the left of the data's value <br>
 * server sends "ParamDefault" to client <br>
 * client responds by setting the data's default value <br>
 * server sends "ParamStringChoice" to client <br>
 * client responds by setting an item in the value's choice box <br>
 * server sends "ParamNumberRange" to client <br>
 * client responds by setting the data value's range of allowed values <br>
 * server sends  "ParamEndDialog" to client <br>
 * client responds by displaying the dialog box on the screen <br>
 */

import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPortParameterValue;

public class CcaPortParameterSetValueEvent 
       extends java.util.EventObject {

    CcaPortParameterValue ccaPortParameterValue = null;

    public CcaPortParameterValue
           getCcaPortParameterValue() {
              return(this.ccaPortParameterValue);
    }

    public void setCcaPortParameterValue
        (CcaPortParameterValue ccaPortParameterValue) {
        this.ccaPortParameterValue = ccaPortParameterValue;
    }

    public CcaPortParameterSetValueEvent(Object source) {
        super(source);
        this.ccaPortParameterValue = null;
    }

    public CcaPortParameterSetValueEvent
           (Object source,
            CcaPortParameterValue ccaPortParameterValue) {
        super(source);
        this.ccaPortParameterValue = ccaPortParameterValue;
    }
}