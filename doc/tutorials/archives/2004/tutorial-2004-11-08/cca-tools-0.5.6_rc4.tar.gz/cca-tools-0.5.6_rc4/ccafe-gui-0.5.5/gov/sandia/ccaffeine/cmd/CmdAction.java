package gov.sandia.ccaffeine.cmd;

import java.util.*;
import java.io.*;

/** Interface to be implemented by each command added to a Cmd interpreter. */
public interface CmdAction {

  /** Does the action, called with the global context of the interpreter
  // and with a vector that matches the signature given by argtype().
  // The exit Action throws the EOFException. */
  public abstract void doIt(CmdContext cc, Vector args) throws EOFException;

  /** Returns a string containing the description of this command. */
  public abstract String help();

  /** Describes the args Vector wanted by this Command.
  // This is our hack to get around stupid varargs-lessness in java.
  // Each character indicates a separate user argument and its type.
  // Type checked user input:
  //   C --> class named by user.
  //   c --> optional class named by user.
  //   I --> instance named by user.
  //   i --> optional instance named by user.
  //   S --> string token from user.
  //   s --> optional string token from user.
  //   K,k --> Long value, optional Long.
  //   D,d --> Integer value, optional Integer.
  //   B,b --> Boolean value, optional Boolean.
  //   G,g --> Double value, optional Double.
  //   * --> repeat previous character ad infinitum. can only appear last. 
  // Special (cannot be followed directly by *):
  //   A --> all of the line after as a single string.
  //   a --> all of the line (if any) as a single string.
  //   L --> the list of known CmdActions.
  //   P --> the command parser itself.
  A more extensible scheme of tags for the parser is desirable.
  */
  public abstract String argtype();

  /** name(s) of the function. */
  public abstract String[] names();

}
