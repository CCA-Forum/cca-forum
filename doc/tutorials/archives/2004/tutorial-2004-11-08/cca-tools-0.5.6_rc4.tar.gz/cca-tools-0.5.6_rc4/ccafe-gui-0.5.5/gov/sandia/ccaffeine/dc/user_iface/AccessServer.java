package gov.sandia.ccaffeine.dc.user_iface;

import gov.sandia.ccaffeine.dc.user_iface.MVC.event.InstantiateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisconnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamCurrentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ExitEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.InstantiateEvent;


import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GoEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ConnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GetInstancesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamGetCurrentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetDebugEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayPaletteEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayChainEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayStateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GoComponentPortEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.NukeAllEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GetComponentPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetComponentPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.StringEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.HeartbeatEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PathEvent;

/**
 * This class allows the client to send querries
 * and commands to the cca server.
 */

public class AccessServer {


  public AccessServer() {
  }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    java.util.Vector guiListeners = new java.util.Vector();

    synchronized public void addGuiListener(GuiListener listener) {
        guiListeners.add(listener);
    }

    synchronized public void removeGuiListener(GuiListener listener) {
        guiListeners.remove(listener);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to remove
     * an instantiation of a cca component.  The
     * client's view will respond by sending a "remove" command
     * to the cca server.
     * @param componentInstanceName
     * The name of the component that was removed.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    public void broadcastRemove
             (String componentInstanceName) {
         RemoveEvent event = new RemoveEvent
             (this,
              componentInstanceName);
        this.broadcastRemoveEvent(event);
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to remove
     * an instantiation of a cca component.  The
     * client's view will respond by sending a "remove" command
     * to the cca server.
     * @param event The event that is generated whenever
     * the GUI is requesting that a component be removed.
     */
    protected void broadcastRemoveEvent(RemoveEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.remove(event);
        }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The client wants the cca server to lanuch
     * the applicaton.  The client's view will send
     * a "run" command to the cca server.  
     */
    public void broadcastGo() {
        GoEvent event = new GoEvent(this);
        broadcastGo(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to lanuch
     * the applicaton.  The client's view will respond
     * by sending a "run" command to the cca server.
     * @param The event that is generated whenever the
     * GUI is requesting that the application be launched.
     */
    public void broadcastGo(GoEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.go(event);
        }
    }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to instantatiate
     * a component.  The client's view will respond by sending
     * a "pull down" command to the cca server.  
     * @param className The name of the component's class.
     * The name is actually the name of the component's
     * java class.
     * EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
     * @param instanceName The name of the
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     */
    public void broadcastInstantiate
           (String className,
            String instanceName) {
        InstantiateEvent event = new InstantiateEvent
            (this, className, instanceName);
        broadcastInstantiate(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to instantatiate
     * a component.  The client's view will respond by sending
     * a "pull down" command to the cca server.  
     * @param The event that is generated whenever the
     * GUI is requesting that a component be instantiated.
     */
    public void broadcastInstantiate(InstantiateEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.instantiate(event);
        }
    }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to connect
     * two ports.  The two ports may be on different
     * components or may be on the same component.
     * The client's view will respond by sending
     * a "connect" command to the cca server.  
     * @param sourceComponentName The name of the component
     * that houses the source port. The "source" is the entity
     * that is requesting the connection.  The "source" 
     * is to be connected to the "target."
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param sourcePortName The name of the source port.
     * The "source" is the entity that is requesting the connection.  
     * The "source" is to be connected to the "target."
     * Example:  "out0"
     * @param targetComponentName The name of the component
     * that houses the target port.  The "target" is the entity
     * that receives the connection request.  The "source"
     * is to be connected to the "target."
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "PrinterComponent0"
     * @param targetPortName the name of the target port.
     * The "target" is the entity
     * that receives the connection request.  The "source"
     * is to be connected to the "target."
     * Example:  "out0"
     */
    public void broadcastConnect
           (String sourceComponentName,
            String sourcePort,
            String targetComponentName,
            String targetPort) {
        ConnectEvent event = new ConnectEvent
            (this,
             sourceComponentName,
             sourcePort,
             targetComponentName,
             targetPort);
        broadcastConnect(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to connect
     * two ports.  The two ports may be on different
     * components or may be on the same component.
     * The client's view will respond by sending
     * a "connect" command to the cca server.  
     * @param The event that is generated whenever the
     * GUI wants to connect a ProvidesPort to a
     * UsesPort.
     */
    public void broadcastConnect(ConnectEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.connect(event);
        }
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to break the
     * connection that exists between two ports.  
     * The client's view will respond by sending a "disconnect"
     * command to the cca server.     
     * @param sourceComponentName The name of the component
     * that houses the source port. The "source" is the entity
     * that originally requested the connection.  The "source" 
     * is connected to the "target."
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param sourcePortName The name of the source port.
     * The "source" is the entity that originally requested the connection.  
     * The "source" is connected to the "target."
     * Example:  "out0"
     * @param targetComponentName The name of the component
     * that houses the target port.  The "target" is the entity
     * that originally received the connection request.  The "source"
     * is to be connected to the "target."
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "PrinterComponent0"
     * @param targetPortName the name of the target port.
     * The "target" is the entity that originally received
     * the connection request.  The "source"
     * is connected to the "target."
     * Example:  "out0"
     */
    public void broadcastDisconnect
           (String sourceComponentName,
            String sourcePort,
            String targetComponentName,
            String targetPort) {
        DisconnectEvent event = new DisconnectEvent
            (this,
             sourceComponentName,
             sourcePort,
             targetComponentName,
             targetPort);
        broadcastDisconnect(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to break the
     * connection that exists between two ports.  
     * The client's view will respond by sending a "disconnect"
     * command to the cca server.     
     * @param The event that is generated whenever the
     * GUI wants to disconnect the connection between a ProvidesPort
     * and a UsesPort.
     */
    public void broadcastDisconnect(DisconnectEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.disconnect(event);
        }
    }










    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to retrieve
     * information on all components that are inside 
     * the arena.  The client's view will respond by sending
     * an "instances" command to the cca server.  
     */
    public void broadcastGetAllInstancesInArena() {
        GetInstancesEvent event = new GetInstancesEvent(this);
        broadcastGetAllInstancesInArena(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to retrieve
     * information on all components that are inside 
     * the arena.  The client's view will respond by sending
     * an "instances" command to the cca server.  
     * @param event The event that is generated whenever
     * the GUI wants to get information on all of the instantiated
     * components.
     */
    public void broadcastGetAllInstancesInArena(GetInstancesEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.getAllInstancesInArena(event);
        }
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to set the
     * value of one of the parameters that are
     * inside a port.  A client's view will
     * respond by sending a "port-properties" command
     * to the cca server.
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The name of a port that contains the parameter.
     *  Example: "configure_port"
     * @param dataFieldName
     * The name of the parameter.
     */
    public void broadcastSetPortParameter
           (String componentInstanceName,
            String portInstanceName,
            String dataFieldName,
            String dataFieldValue) {
        ParamCurrentEvent event = new ParamCurrentEvent
            (this,
             componentInstanceName,
             portInstanceName,
             dataFieldName,
             dataFieldValue);
        broadcastSetPortParameter(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to set the
     * value of one of the parameters that are
     * inside a port.  A client's view will
     * respond by sending a "port-properties" command
     * to the cca server.
     * @param The event that is generated whenever the
     * GUI wants to set the value of a port parameter.
     */
    public void broadcastSetPortParameter(ParamCurrentEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.setPortParameter(event);
        }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to retrieve the
     * value of one of the parameters that are
     * inside a port.  A client's view will
     * respond by sending a "configure" or a "parameters" command
     * to the cca server.
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The name of a port that contains the parameter.
     *  Example: "configure_port"
     * @param dataFieldName
     * The name of the parameter.
     */
    public void broadcastGetPortParameter
         (String componentInstanceName,
          String portInstanceName,
          String dataFieldName) {
        ParamGetCurrentEvent event =
            new ParamGetCurrentEvent
            (this,
             componentInstanceName,
             portInstanceName,
             dataFieldName);
        broadcastGetPortParameter(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to retrieve the
     * value of one of the parameters that are
     * inside a port.  A client's view will
     * respond by sending a "configure" or a "parameters" command
     * to the cca server.
     * @param event The event that is created when the GUI
     * wants to get the value of a parameter.
     */
    public void broadcastGetPortParameter(ParamGetCurrentEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.getPortParameter(event);
        }
    }









    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to print
     * debugging statements.  A client's view will
     * respond by sending a "debug" or "noisy" command
     * to the cca server.
     */
    public void broadcastSetDebug() {
        SetDebugEvent event =
            new SetDebugEvent(this);
        broadcastSetDebug(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to print
     * debugging statements.  A client's view will
     * respond by sending a "debug" or "noisy" command
     * to the cca server.
     * @event The event that is generated whenever
     * the GUI wants the cca server to print debugging
     * statements.
     */
    public void broadcastSetDebug(SetDebugEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.setDebug(event);
        }
    }








    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to stop printing
     * debugging statements.  A client's view will
     * respond by sending a "nodebug" or "quiet" command
     * to the cca server.
     */
    public void broadcastSetNoDebug() {
        SetDebugEvent event =
            new SetDebugEvent(this);
        broadcastSetNoDebug(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to stop printing
     * debugging statements.  A client's view will
     * respond by sending a "nodebug" or "quiet" command
     * to the cca server.
     * @event The event that is generated whenever
     * the GUI wants the server to stop printing debugging
     * statements.
     */
    public void broadcastSetNoDebug(SetDebugEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.setNoDebug(event);
        }
    }









    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to retrieve
     * information on every component that is inside
     * the palette.  A client's view will
     * respond by sending a "display palette" command
     * to the cca server.
     */
    public void broadcastDisplayPalette() {
        DisplayPaletteEvent event =
            new DisplayPaletteEvent(this);
        broadcastDisplayPalette(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to retrieve
     * information on every component that is inside
     * the palette.  A client's view will
     * respond by sending a "display palette" command
     * to the cca server.
     * @param event The event that is generated whenever
     * the GUI wants to know what components
     * are in the palette.
     */
    public void broadcastDisplayPalette(DisplayPaletteEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.displayPalette(event);
        }
    }





























    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to retrieve
     * information on every connection that is inside
     * the arena.  A connection connects a "uses" port
     * with a "provides" port.  A client's view will
     * respond by sending a "links" command
     * to the cca server.
     */
    public void broadcastLinks() {
        DisplayChainEvent event =
            new DisplayChainEvent(this);
        broadcastLinks(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to retrieve
     * information on every connection that is inside
     * the arena.  A connection connects a "uses" port
     * with a "provides" port.  A client's view will
     * respond by sending a "links" command
     * to the cca server.
     * @param event The event that is created
     * whenever the GUI wants to know what connections
     * are in the arena.
     */
    public void broadcastLinks(DisplayChainEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.links(event);
        }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to retrieve
     * information on a specific component.  
     * A client's view will
     * respond by sending a "display component" command
     * to the cca server.
     * @param componentInstanceName
     * The name of the
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     */
     public void broadcastDisplayComponent
           (String componentInstanceName) {
        DisplayComponentEvent event =
            new DisplayComponentEvent(this, componentInstanceName);
        broadcastDisplayComponent(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to retrieve
     * information on a specific component.  
     * A client's view will
     * respond by sending a "display component" command
     * to the cca server.
     * @param event The event that is created
     * whenever the GUI wants some information
     * on a cca component.
     */
    public void broadcastDisplayComponent(DisplayComponentEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.displayComponent(event);
        }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to retrieve
     * information on every component and every
     * connection that is in the arena.  A
     * connection connects a "uses" port with a
     * "provides" port.  
     * A client's view will
     * respond by sending a "display state" command
     * to the cca server.
     */
     public void broadcastDisplayState() {
        DisplayStateEvent event =
            new DisplayStateEvent(this);
        broadcastDisplayState(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to retrieve
     * information on every component and every
     * connection that is in the arena.  A
     * connection connects a "uses" port with a
     * "provides" port.  
     * A client's view will
     * respond by sending a "display state" command
     * to the cca server.
     * @param event The event that is created whenever
     * the GUI wants to know the state of the arena.
     */
     public void broadcastDisplayState(DisplayStateEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.displayState(event);
        }
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to launch
     * by application by invoking the "go" command
     * on a specific port that is inside a specific
     * component.  A client's view will
     * respond by sending a "go" command
     * to the cca server.
     * @param componentInstanceName
     * The name of the
     * cca component object that 
     * contains the "go" port.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     * @param portInstanceName
     * The name of the GO port
     */
     public void broadcastGoComponentPort
            (String componentInstanceName,
             String portInstanceName) {
        GoComponentPortEvent event =
            new GoComponentPortEvent
            (this,
             componentInstanceName,
             portInstanceName);
        broadcastGoComponentPort(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to launch
     * by application by invoking the "go" command
     * on a specific port that is inside a specific
     * component.  A client's view will
     * respond by sending a "go" command
     * to the cca server.
     * @param event The event that is generated whenever
     * the GUI wants to invoke the "go" command.
     */
    public void broadcastGoComponentPort(GoComponentPortEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.goComponentPort(event);
        }
    }








    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to destroy
     * all of the instantiated components (i.e. all
     * of the components that are in the arena).
     * A client's view will
     * respond by sending a "nuke all" command
     * to the cca server.
     */
     public void broadcastNukeAll() {
        NukeAllEvent event = new NukeAllEvent(this);
        broadcastNukeAll(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to destroy
     * all of the instantiated components (i.e. all
     * of the components that are in the arena).
     * A client's view will
     * respond by sending a "nuke all" command
     * to the cca server.
     * param event The event that is created
     * when the GUI wants to to delete
     * all components.
     */
    public void broadcastNukeAll(NukeAllEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.nukeAll(event);
        }
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



     /**
      * The client wants the cca server to retrieve
      * the value of a specific property that is contained
      * inside a specific component.  A client's view will
      * respond by sending a "property" or a 
      * "set property" command
      * to the cca server.
      * @param componentInstanceName
      * The name of the component that contains the property
      * The name is usually the java class name of the component
      * (without the package name) concatenated with an index number.
      * Example:  "StartComponent0"
      * @param propertyName The name of the property.
      */
     public void broadcastGetComponentProperty
           (String componentInstanceName,
            String propertyName) {
        GetComponentPropertyEvent event = new GetComponentPropertyEvent
            (this,
             componentInstanceName,
             propertyName);
        broadcastGetComponentProperty(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
      * The client wants the cca server to retrieve
      * the value of a specific property that is contained
      * inside a specific component.  A client's view will
      * respond by sending a "property" or a 
      * "set property" command
      * to the cca server.
      * @param event The event that is generated
      * whenever the GUi wants the value of a
      * property.
     */
    public void broadcastGetComponentProperty(GetComponentPropertyEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.getComponentProperty(event);
        }
    }










    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to set
     * the value of a specific property that is contained
     * inside a specific component.  A client's view will
     * respond by sending a "property" or a 
     * "set property" command
     * to the cca server.
     * @param componentInstanceName
     * The name of the component that contains the property.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param propertyName The name of the property.
     * @param propertyValue The value of the property.
     */
     public void broadcastSetComponentProperty
           (String componentInstanceName,
            String propertyName,
            String propertyValue) {
        SetComponentPropertyEvent event = new SetComponentPropertyEvent
            (this,
             componentInstanceName,
             propertyName,
             propertyValue);
        broadcastSetComponentProperty(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to set
     * the value of a specific property that is contained
     * inside a specific component.  A client's view will
     * respond by sending a "property" or a 
     * "set property" command
     * to the cca server.
     * @param event The event that is created whenever
     * the GUI wants to set the value of a property.
     */
    public void broadcastSetComponentProperty(SetComponentPropertyEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.setComponentProperty(event);
        }
    }


























    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants to send a message to the cca server.
     * A client's view will
     * respond by sending a "message" command
     * to the cca server.
     * @param message The message that is to
     * be sent to the cca server.
     */
     public void broadcastMessage
           (String message) {
        StringEvent event = new StringEvent
            (this,
             message);
        broadcastMessage(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants to send a message to the cca server.
     * A client's view will
     * respond by sending a "message" command
     * to the cca server.
     * @param event The event that is created
     * whenever the GUi wants to send
     * a string to the cca server.
     */
    public void broadcastMessage(StringEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.sendMessage(event);
        }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants to send a heartbeat to the cca server.
     * The server uses the heartbeat to determine if the
     * client dies unexpectedly.  A client's view will
     * respond by sending a "heartbeat" command
     * to the cca server.
     */
     public void broadcastHeartbeat() {
        HeartbeatEvent event = new HeartbeatEvent(this);
        broadcastHeartbeat(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants to send a heartbeat to the cca server.
     * The server uses the heartbeat to determine if the
     * client dies unexpectedly.  A client's view will
     * respond by sending a "heartbeat" command
     * to the cca server.
     * @param event The event that is fabricated
     * whenever the GUI wants to send a heartbeat to the cca server.
     */
    public void broadcastHeartbeat(HeartbeatEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.heartbeat(event);
        }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants to tell the cca server that it is
     * shutting down.  A client's view will
     * respond by sending an "exit" command
     * to the cca server.
     */
     public void broadcastExit() {
        ExitEvent event = new ExitEvent(this);
        broadcastExit(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants to tell the cca server that it is
     * shutting down.  A client's view will
     * respond by sending an "exit" command
     * to the cca server.
     * @param event The event that is generated whenever
     * the GUI wants to exit the application.
     */
    public void broadcastExit(ExitEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.exit(event);
        }
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/






    /**
     * The client wants either to tell the cca
     * server the name of the folder that contains
     * cca component or to ask the cca server to
     * retrieve the name of the folder.
     * A client's view will
     * respond by sending a "path" command
     * to the cca server.
     * @param event The event that is
     * generated whenever the GUI
     * wants the cca server either to set the path
     * to a new value or to query
     * for the path value.
     */
    public void broadcastPath(PathEvent event) {
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



}