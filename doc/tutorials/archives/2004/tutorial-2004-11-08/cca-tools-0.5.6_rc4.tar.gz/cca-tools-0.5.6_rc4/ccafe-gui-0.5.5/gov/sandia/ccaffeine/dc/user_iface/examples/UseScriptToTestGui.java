
package gov.sandia.ccaffeine.dc.user_iface.examples;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

import java.net.Socket;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.IOException;

import gov.sandia.ccaffeine.dc.user_iface.BuilderClient;

/**
 * Simulator for a CCA Server
 * <p>
 * The constructor launches both the simulator and the cca client.
 * <p>
 * The purpose of the simulator is to test the cca client.  
 * Commands and data travel across a communication link between
 * the server and the client.  In a typical exchange, the client
 * sends a query to the cca server; the cca server responds by
 * sending the results of the query to the client.  For example,
 * the client can ask for a list of all the components that are
 * in the palette.  
 * <p>
 * The simulator's actions are controlled by the script file
 * scriptToTestClient.xml.  This file contains 3 types of
 * instructions:  <br>
 * &nbsp;&nbsp;writeToClient anyString <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;the simulator uses the communication line <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;to send anyString to the client. <br>
 * &nbsp;&nbsp;readFromClient anyString <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;simulator waits for the client <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;to use the communiction link to send anyString. <br>
 * &nbsp;&nbsp;command anyString <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;simulator invokes a method on the client. <br>
 */
public class UseScriptToTestGui {
	
        /* The simulator will set up a ServerSocket on this port. */
	protected int port = 0;
	

        /**
         * Launch the simulator and launch the client. 
         * <p>
         * The simulator sets up a ServerSocket on a port. 
         * The ServerSocket waits for a cca client to request a connection.
         * Once the connection is established, the simulator follows
         * the instructions in the script file, scriptToTestClient.xml.  
         * <p>
         * This constructor also launches a cca client.  
         * The cca client creates a client Socket.  
         * A connection request is then be sent to the 
         * simulator's ServerSocket.  If the simulator accecpts the
         * request, then a communication link is establed between
         * the ServerSocket and the ccc client.
         * <p>
         * @param port The simulator sets up a ServerSocket on this port.
         */
	public UseScriptToTestGui(int port){

            /* The simulator will set up a ServerSocket on port */
      	    this.port = port;
            ThreadServerSocket threadServerSocket = new ThreadServerSocket(port);
            threadServerSocket.start();

            /* Wait for the ServerSocket to spin up */
            try {Thread.sleep(1000);} catch(Exception e){}

            /* Launch a cca client.  The client will launch a             */
            /* client Socket.  The client Socket will send a              */
            /* connection request to port (the simulator's ServerSocket). */
            ThreadClient threadClient = new ThreadClient(port);
            threadClient.start();		
	}
	
	
    protected class ThreadServerSocket extends Thread {
    

        /* The simulator will set up a ServerSocket on this port */
        int port = 0;
        

        /**
         * Set up a thread that will launch a ServerSocket on a port.
         * @param port A ServerSocket will be set up on this port.
         */
        public ThreadServerSocket(int port) {
            super();
            this.port = port;
        }
		
	/*
         * Listen for new clients trying to connect to us. When a new client does
         * try to connect to us then launch a new thread to service that client.
         */
	 public void run() {
	     try {
	        	
	         /* create a server socket */
	         java.net.ServerSocket serverSocket = 
	            	new java.net.ServerSocket(this.port);               
	            
                 /* 
                  * Wait for a cca client to request a communication
                  * link.  Spin off a new Thread to service the
                  * cca client.
                  */
	          while (true) {
	                new serviceNewClient(serverSocket.accept());
	          }
	                
	        }catch (IOException e) {
	            System.out.println(e);
	        }
	    } 
    
    }	
	
    
    /*
    A new client has just connected to us.
    Launch a new thread to service that client.
    */
    class serviceNewClient extends Thread {
        Socket socket;
        

        /**
         * Create and launch a Thread to service
         * the cca client.
         * @param socket The simulator's socket that
         * is connected to the cca client.
         */
        public serviceNewClient(Socket socket) {
            this.socket = socket;
            setPriority(NORM_PRIORITY-1);
            start();
        }
        

        /**
         * Service the cca client.
         * <p>
         * The simulator's actions are controlled by the
         * script file, scriptToTestClient.xml.  Each line
         * in the file contains one instruction.  If a line
         * contains a writeToClient instruction, then use the
         * communication link to send a string from the
         * simulator to the cca client.  If a line contains a
         * readFromClient instruction, then wait for the cca client
         * to use the communication link to send a string to
         * the simulator.  If a line contains a command, then
         * invoke a method on the cca client.
         */
        public void run() {
        	
        	
            BufferedReader reader = null;
            PrintWriter writer = null;
            ScriptFile scriptFile = null;
            
            
            try {
            	
            	/* 
                 * The simulator wants to be able to read and write strings 
                 * to and from the cca client.
                 */
                reader = new BufferedReader
                    (new InputStreamReader(socket.getInputStream()));
                writer = new PrintWriter
                    (new OutputStreamWriter(socket.getOutputStream()),true);
                
                
                /* 
                 * open the script file 
                 * The simulator's actions are controlled by this script file.
                 * i.e. the script file contains instructions for the simulator.
                 */
                scriptFile = new ScriptFile();
                scriptFile.open();
                
                /* throw away the first line of the script file */
                scriptFile.readLine();
                
                while(true) {
                
                	
                	/* read one line from the script file*/
                	String oneLine = scriptFile.readLine();              	
                	
                	/* did we get to the script file's EOF */
                	if (oneLine==null) break;
                	
                	/* did we get to the last line of the script file? */
                	if (oneLine.equals("</scriptToTestGui>")) break;
                	            	
                	
                	/* The one line will either be:                  */
                	/* an instruction to read a line from the client */
                	/* or                                            */
                	/* an instruction to write a line to the client  */
                	
                        /* Is this an instruction to read a line from the client? */
                       
                	Pattern pattern = Pattern.compile
						    ("<readFromClient>(.*?)</readFromClient>");
                	Matcher matcher = pattern.matcher(oneLine);
                	if (matcher.find()){
                	
                	    /* parse the instruction to determine the */
                            /* contents of the line that we are       */
                	    /* suppose to read from the client        */
                	    String expectedLine = matcher.group(1);
                		
                	   /* display the line we are waiting for */
                	   System.out.println
                               ("WAITING FROM CLIENT:" + expectedLine);	                	
                		
                		
                	    /* read a line from the client */
                	    String actualLine = reader.readLine();
                		
                	    /* If the expected line  */
                	    /* does not match        */
                	    /* the expected line     */
                	    /* then display an error */
                	    if (expectedLine.equals(actualLine)==false){
                		System.out.println("*****ERROR*****");
                		System.out.println
			          ("     We were expecting to read:" + expectedLine);
                		System.out.println
				  ("     We actually read:" + actualLine);
                		break;
                	   }//if equals
                		
                        }//if read a line
                	

                	/* is the instruction to write a line to the client? */
                	pattern = Pattern.compile
				 ("<writeToClient>(.*?)</writeToClient>");
                	matcher = pattern.matcher(oneLine);
                	if (matcher.find()){
                		
                	    /* extract the contents of the text          */
                	    /* that we are suppose to send to the client */
                	    String line = matcher.group(1);
                		
                	    /* send the contents to the client */
                	    writer.println(line);
                	    writer.flush();
                		
                	    /* display the line we sent to the client */
                	    System.out.println("TO CLIENT:" + line);
                		
                	}//if write
                	
                	
                	
                	/* is the instruction a command? */
                	pattern = Pattern.compile("<command>(.*?)</command>");
                	matcher = pattern.matcher(oneLine);
                	if (matcher.find()) {
                	
                	    /* extract the command */
                	    String command = matcher.group(1);
                	    
                	    /* display the command */
                	    System.out.println("COMMAND:" + command);
                	    
                	    /* move drop location???? */
                	    if (command.equals("set drop location to 50 50")) {
                	        BuilderClient.globalData.setDropLocation
                	            (new java.awt.Point(50,50));
                	    }
                	    if (command.equals("set drop location to 150 150")) {
                	        BuilderClient.globalData.setDropLocation
                	            (new java.awt.Point(150,150));
                	    }                	    
                	    if (command.equals("set drop location to 250 250")) {
                	        BuilderClient.globalData.setDropLocation
                	            (new java.awt.Point(250,250));
                	    }           
                	    if (command.equals("exit")) {
                	    
                	    /* pause for one second */
                            try {sleep(1000);}catch (Exception e){}
                        
                            /* kill the app */    
                	        System.exit(0);
                	    }     	    
                	}
                		
                }//while                       
                
            }catch (java.io.IOException e) {
                System.out.println(e);
            }finally {
                /* close the scrip file */
                scriptFile.close();
                
                /** close the comm link with the client */
                if (writer!=null)
                    writer.close();
                if (reader!=null)
		    try {reader.close();} catch (IOException e1) {}
                if (socket!=null)
                    try {socket.close();} catch (IOException e1){}              	
            }//finally
        }
    }
        
	
    /**
     * Launch the simulator and launch the cca client.
     * @param args The command line arguments.  The first
     * argument should be the port number that the simulator
     * will use to set up a ServerSocket.
     */
    public static void main(String[] args) {
		
		/* which port are we using */
		if (args.length!=1) {
			System.out.println("USAGE:  java UseScriptToTestGUI port");
			return;
		}
		
		/* convert the port to an int */
		int port = 0;
		try {
		    port = Integer.parseInt(args[0]);
		}catch (NumberFormatException e){
			System.out.println("USAGE:  java UseScriptToTestGUI port");
			return;
		}
		
                /* launch the simulator.  launch the cca client. */
		new UseScriptToTestGui(port);
    }
}
