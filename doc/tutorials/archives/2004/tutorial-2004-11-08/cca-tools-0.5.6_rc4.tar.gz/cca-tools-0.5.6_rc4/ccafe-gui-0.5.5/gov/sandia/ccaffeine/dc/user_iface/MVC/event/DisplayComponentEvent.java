package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * This event can be used to notify components
 * that an entity wants some information on a
 * cca component.
 * A view might respond by rendering a cca
 * component in the main workspace (the arena).
 * The end-user can drag the component to a
 * new location, remove the component, draw a
 * line to/from a different component, view or
 * edit the component's properties, etc.
 * <p>
 * A view might respond by rendering a cca
 * component in the main workspace (the arena).
 * The end-user can drag the component to a
 * new location, remove the component, draw a
 * line to/from a different component, view or
 * edit the component's properties, etc.
 */

public class DisplayComponentEvent extends EventObject {

    /*
     * The name of the
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
    */
    protected String componentInstanceName = null;


    /*
     * Get the name of the
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
    */
    public String getComponentInstanceName() {
        return(this.componentInstanceName);
    }


    /**
     * Create a DisplayComponentEvent.
     * This event can be used to notify components
     * that an entity wants some information on a
     * cca component.
     * A view might respond by rendering a cca
     * component in the main workspace (the arena).
     * The end-user can drag the component to a
     * new location, remove the component, draw a
     * line to/from a different component, view or
     * edit the component's properties, etc.
     * @param source The entity that created this event.
     * @param componentInstanceName
     * The name of the
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     */
    public DisplayComponentEvent
           (Object source,
            String componentInstanceName) {

         super(source);
         this.componentInstanceName = componentInstanceName;
    }

}