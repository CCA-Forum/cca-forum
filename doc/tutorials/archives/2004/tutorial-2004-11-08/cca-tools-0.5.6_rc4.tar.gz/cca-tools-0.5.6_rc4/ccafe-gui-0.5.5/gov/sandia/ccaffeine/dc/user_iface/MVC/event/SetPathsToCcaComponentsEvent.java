package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

/**
 * Used to notify listeners that the path to the cca components
 * is set.
 */

public class SetPathsToCcaComponentsEvent extends java.util.EventObject {

    /*
     * The paths to the CCA component.
     */
    String paths[] = null;


    /**
     * Get the paths to the cca componets.
     * @return The paths to the cca components.
     */
    public String[] getPaths() {
        return(this.paths);
    }


    /**
     * Set the paths to the cca componets.
     * @param paths The paths to the cca components.
     */
    public void getPaths(String paths[]) {
        this.paths = paths;
    }


    /**
     * Construct a SetPathToCcaComponentsEvent.
     * @param source the entity that originated this event.
     */
    public SetPathsToCcaComponentsEvent(Object source) {
        super(source);
        this.paths = null;
    }

    /**
     * Construct a SetPathToCcaComponentsEvent.
     * @param source the entity that originated this event.
     * @param paths the paths to the cca components.
     */
    public SetPathsToCcaComponentsEvent(Object source, String paths[]) {
        super(source);
        this.paths = paths;
    }


}