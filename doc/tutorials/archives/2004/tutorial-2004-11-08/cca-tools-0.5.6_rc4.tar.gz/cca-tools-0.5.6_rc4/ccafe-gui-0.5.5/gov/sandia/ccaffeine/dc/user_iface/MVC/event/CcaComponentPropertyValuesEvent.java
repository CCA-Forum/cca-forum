package gov.sandia.ccaffeine.dc.user_iface.MVC.event;


/**
 * This event can be used to notify components
 * that the cca server changed the value
 * of one or more component properties. 
 * A view entity might
 * respond by sending the current value to stdout.
 * <p>
 * Possible Scenario: <br>
 * An end-user clicks on a blue port inside of a component <br>
 * client sends "parameters" to server <br>
 * serer- sends "ParamDialog" to client <br>
 * client responds by creating an empty dialog box <br>
 * server sends "ParamTab" to client <br>
 * client responds by inserting a new tab in the dialog box <br>
 * server sends "ParamField" to client <br>
 * client responds by inserting a blank data line into the dialog box <br>
 * server sends "ParamCurrent" to client <br>
 * client responds by inserting the data's value into the dialog box <br>
 * server sends "ParamHelp" to client <br>
 * client responds by setting the text that is displayed if the help button is clicked <br>
 * server sends "ParamPrompt" to client <br>
 * client responds by displaying a prompt to the left of the data's value <br>
 * server sends "ParamDefault" to client <br>
 * client responds by setting the data's default value <br>
 * server sends "ParamStringChoice" to client <br>
 * client responds by setting an item in the value's choice box <br>
 * server sends "ParamNumberRange" to client <br>
 * client responds by setting the data value's range of allowed values <br>
 * server sends  "ParamEndDialog" to client <br>
 * client responds by displaying the dialog box on the screen <br>
 */

import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaComponentPropertyValue;

public class CcaComponentPropertyValuesEvent
       extends java.util.EventObject {

    CcaComponentPropertyValue ccaComponentParameterValues[] = null;

    public CcaComponentPropertyValue[]
           getCcaComponentPropertyValues() {
              return(this.ccaComponentParameterValues);
    }

    public void setCcaComponentPropertyValue
        (CcaComponentPropertyValue ccaComponentParameterValues[]) {
        this.ccaComponentParameterValues = ccaComponentParameterValues;
    }

    public CcaComponentPropertyValuesEvent(Object source) {
        super(source);
        this.ccaComponentParameterValues = null;
    }

    public CcaComponentPropertyValuesEvent
           (Object source,
            CcaComponentPropertyValue ccaComponentParameterValues[]) {
        super(source);
        this.ccaComponentParameterValues = ccaComponentParameterValues;
    }
}
