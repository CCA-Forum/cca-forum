package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

/**
 * Tell the cca server to change the
 * path or tell the cca server to
 * retrieve the path.
 */

public class PathEvent extends java.util.EventObject {

    /*
     * The number of arguments
     * in the path command.
     */
    protected int numberOfArguments = 0;


    /**
     * Retrieve the number of arguments
     * in the path command.
     */
    public int getNumberOfArguments() {
      return(numberOfArguments);
    }


  /**
   * One of the commands than can be
   * used to alter the path.
   */
    public final String INIT = "init";

  /**
   * One of the commands than can be
   * used to alter the path.
   */
    public final String APPEND = "append";

  /**
   * One of the commands than can be
   * used to alter the path.
   */
    public final String PREPEND = "prepend";

  /**
   * One of the commands than can be
   * used to alter the path.
   */
    public final String SET = "set";

    /*
     * To alter the path,
     * specify how
     * the path is to be changed
     * by issuing
     * any of the following commands:
     * INIT, APPEND, PREPEND, SET
     */
    protected String commandToAlterPath = null;


    /*
     * If the path is to be altered,
     * retrieve the command that
     * will be used to alter the path.
     * This method will return
     * one of the following commands:
     * INIT, APPEND, PREPEND, SET
     */
    public String getCommandToAlterPath() {
        return(this.commandToAlterPath);
    }

    /**
     * To alter the path,
     * specify the value that
     * will be used to alter the path.
     */
    protected String directory = null;


    /**
     * To alter the path,
     * retrieve the value that will be
     * used to alter the path.
     */
    public String getDirectory() {
        return(this.directory);
    }



    /**
     * Tell the cca server to change the
     * path or tell the cca server to
     * retrieve the path.
     * @param source The entity that
     * created this event.
     */
    public PathEvent
           (Object source) {

        super(source);
        this.numberOfArguments = 0;
        this.commandToAlterPath = null;
        this.directory = null;
    }




    /**
     * Tell the cca server to change the
     * path or tell the cca server to
     * retrieve the path.
     * @param source The entity that
     * created this event.
     * @param numberOfArguments
     * The number of arguments in the
     * path command.
     */
    public PathEvent
           (Object source,
            int numberOfArguments) {

        super(source);
        this.numberOfArguments = numberOfArguments;
        this.commandToAlterPath = null;
        this.directory = null;
    }



    /**
     * Tell the cca server to change the
     * path or tell the cca server to
     * retrieve the path.
     * @param source The entity that
     * created this event.
     * @param commandToAlterPath
     * To alter the path,
     * specify how
     * the path is to be changed
     * by issuing
     * any of the following commands:
     * INIT, APPEND, PREPEND, SET.
     * Can be set to null.
     */
    public PathEvent
           (Object source,
            String commandToAlterPath) {

        super(source);
        this.numberOfArguments = 1;
        this.commandToAlterPath = commandToAlterPath;
        this.directory = null;

       }





    /**
     * Tell the cca server to change the
     * path or tell the cca server to
     * retrieve the path.
     * @param source The entity that
     * created this event.
     * @param numberOfArguments
     * The number of arguments
     * in the path command.
     * @param commandToAlterPath
     * To alter the path,
     * specify how
     * the path is to be changed
     * by issuing
     * any of the following commands:
     * INIT, APPEND, PREPEND, SET.
     * Can be set to null.
     */
    public PathEvent
           (Object source,
            int numberOfArguments,
            String commandToAlterPath) {

        super(source);
        this.numberOfArguments = numberOfArguments;
        this.commandToAlterPath = commandToAlterPath;
        this.directory = null;
    }




    /**
     * Tell the cca server to change the
     * path or tell the cca server to
     * retrieve the path.
     * @param source The entity that
     * created this event.
     * @param commandToAlterPath
     * To alter the path,
     * specify how
     * the path is to be changed
     * by issuing
     * any of the following commands:
     * INIT, APPEND, PREPEND, SET.
     * Can be set to null.
     * @param directory
     * To alter the path,
     * specify the new path value that
     * is to be used.
     */
    public PathEvent
           (Object source,
            String commandToAlterPath,
            String directory) {

        super(source);
        this.numberOfArguments = 2;
        this.commandToAlterPath = commandToAlterPath;
        this.directory = directory;
    }



    /**
     * Tell the cca server to change the
     * path or tell the cca server to
     * retrieve the path.
     * @param source The entity that
     * created this event.
     * @param numberOfArguments
     * The number of arguments
     * in the path command.
     * @param commandToAlterPath
     * To alter the path,
     * specify how
     * the path is to be changed
     * by issuing
     * any of the following commands:
     * INIT, APPEND, PREPEND, SET.
     * Can be set to null.
     * @param directory
     * To alter the path,
     * specify the
     * new path value.
     */
    public PathEvent
           (Object source,
            int numberOfArguments,
            String commandToAlterPath,
            String directory) {

        super(source);
        this.numberOfArguments = numberOfArguments;
        this.commandToAlterPath = commandToAlterPath;
        this.directory = directory;
    }


}