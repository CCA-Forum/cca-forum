package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Used to notify components that the cca server
 * has set the value of a property that is inside
 * a cca component.
 * A view entity might
 * respond by saving the new value of the property.
 * <p>
 * Can also be used to notify components that an entity
 * wants to set the value of a property that is inside
 * a cca component.  A view entity might respond
 * by sending a "property" or a "set property"
 * message to the cca server.
 */
public class SetComponentPropertyEvent extends EventObject {

  /**
   * The name of the component that contains the property
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "StartComponent0"
   */
    protected String componentInstanceName = null;




    /**
     * Get the name of the cca component that
     * contains the property.
     * @return the name of the compoonent that
     * contains the property.
     */
    public String getComponentInstanceName() {
        return(this.componentInstanceName);
    }

    /*
     * The name of the property.
     */
    protected String propertyName = null;


    /**
     * Get the name of the property.
     * @return The name of the property.
     */
    public String getPropertyName() {
        return(this.propertyName);
    }

    /**
     * The value of the property.
     */
    protected String propertyValue = null;


    /**
     * Get the value of the property.
     * @return The value of the property.
     */
    public String getPropertyValue() {
        return(this.propertyValue);
    }


    /**
     * Create a SetPropertyEvent.
     * The event can be used to
     * notify components that the cca server
     * has set the value of a property that is inside
     * a cca component.
     * A view entity might
     * respond by saving the new value of the property.
     * <p>
     * Can also be used to notify components that an entity
     * wants to set the value of a property that is inside
     * a cca component.  A view entity might respond
     * by sending a "property" or a "set property"
     * message to the cca server.
     * @param source The entity that created this event.
     * @param componentInstanceName
     * The name of the component that contains the property
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param propertyName The name of the property.
     * @param propertyValue The value of the property.
     */
    public SetComponentPropertyEvent
           (Object source,
            String componentInstanceName,
            String propertyName,
            String propertyValue) {

         super(source);
         this.componentInstanceName = componentInstanceName;
         this.propertyName = propertyName;
         this.propertyValue = propertyValue;
    }

}