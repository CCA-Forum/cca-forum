package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaConnectionBetweenTwoPorts;

/**
 * used to transfer cca connections from one entity to another entity
 */

public class CcaConnectionsBetweenTwoPortsEvent 
       extends java.util.EventObject {

    /**
     * Get the components
     */
    protected CcaConnectionBetweenTwoPorts ccaConnections[] = null;

    /**
     * get the cca connections
     * @return The retrieved cca connections
     */
     public CcaConnectionBetweenTwoPorts[] getCcaConnections() {
         return(this.ccaConnections);
     }

    /**
     * set the cnnections
     * @param ccaConnections The connections
     */
     public void setConnections
           (CcaConnectionBetweenTwoPorts ccaConnections[]) {
         this.ccaConnections = ccaConnections;
     }


     /**
      * Create a CcaConnectionsBetweenTwoPortsEvent.
      * @param source The entity that originated this event.
      */
     public CcaConnectionsBetweenTwoPortsEvent(Object source) {
         super(source);
         this.ccaConnections = null;
     }


     /**
      * Create a CcaConnectionsBetweenTwoPortsEvent.
      * @param source The entity that originated this event.
      * @param ccaConnections the connection
      */
     public CcaConnectionsBetweenTwoPortsEvent
            (Object source,
             CcaConnectionBetweenTwoPorts ccaConnections[]) {
         super(source);
         this.ccaConnections = ccaConnections;
     }


}