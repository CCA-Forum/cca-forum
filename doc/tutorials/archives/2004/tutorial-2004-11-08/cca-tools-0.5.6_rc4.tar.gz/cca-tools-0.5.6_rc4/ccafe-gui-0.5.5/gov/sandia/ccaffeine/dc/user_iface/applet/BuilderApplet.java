/*
 * @(#)BuilderApplet.java       1.0 99/09/02
 */
package gov.sandia.ccaffeine.dc.user_iface.applet;

import java.net.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import java.util.*;
import gov.sandia.ccaffeine.util.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.user_iface.*;
import java.io.*;

import gov.sandia.ccaffeine.dc.user_iface.MVC.CanNotCommunicateWithCcaServerException;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ControllerSocket;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ControllerPython;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ViewSocket;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ViewPython;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.Gui;
import gov.sandia.ccaffeine.dc.user_iface.gui.GlobalData;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ClientSocket;
import gov.sandia.ccaffeine.dc.user_iface.AccessServer;
import gov.sandia.ccaffeine.dc.user_iface.MVC.PythonStub;


/** An Applet version of the Builder GUI.  It contacts the server for
    the CmdLineBuilderController that drives the framework.*/
public class BuilderApplet extends JApplet implements Runnable {

  //RemoteServer server;
  ClientSocket clientSocket = null;
  
  /* if we are talking to a python server, then we need the python's stub */
  PythonStub pythonStub = null;
  


  public void init() {
     getContentPane().setLayout(new GridLayout(1,1));
     getContentPane().setBackground(Color.white);
      start();
  }


    Thread thread = null;

    public void start() {
        if (thread!=null) return;
        thread = new Thread(this);
        thread.start();
    }

    public void stop() {
        thread = null;
    }




    public void run() {


    /* clear out all components */
    this.getContentPane().removeAll();

    String argString = getParameter("args");
    LocalSystem.out.println("Arguments = "+argString);

    System.out.println("creating a remote server");
     showStatus("creating a remote server");

    //server = new RemoteServer();
    this.clientSocket = new ClientSocket();
    

    System.out.println("got a remote server");
    showStatus("got a remote server");


    Args args = getArguments(argString);
    LocalSystem.out.println("args.appletHostname = "+args.appletHostname);






    //args.builderPort = 2471;
    //args.builderPort = 1234;
    args.builderPort = Integer.parseInt(getParameter("portNumber"));
    LocalSystem.out.println("*******Trying to Connect to port "
                            + args.builderPort + "**********");





    System.out.println("setting the port");
    showStatus("settting the port");
    //server.setPort(args.builderPort);
    System.out.println("the port is set");
    showStatus("the port is set");

    URL url1 = getCodeBase();
    URL url = getDocumentBase();
    String fromHost;

    if(args.appletHostname != null) {
      fromHost = args.appletHostname;
    } else {
      fromHost = url.getHost();
    }
    showStatus("I came from this machine: "+fromHost);
    LocalSystem.out.println("about to setHost to "+fromHost);

    System.out.println("setting the host");
    showStatus("setting the host");
    //server.setHost(fromHost);
    System.out.println("the host is set");
    showStatus("the host is set");


    LocalSystem.out.println("about to create connection to "+fromHost);




    try {
        System.out.println("creating connection");
        showStatus("creating connection");

        //server.createConnection();
        this.clientSocket.open(fromHost, args.builderPort);

        System.out.println("got a connection");
        showStatus("got a connection");
    }catch (java.lang.Throwable e) {
        LocalSystem.out.println("ERROR ERROR ERROR");
        System.out.println(e.getMessage());
        showStatus(e.getMessage());
        LocalSystem.out.println("creating JPanel for error msg");
        JPanelMessage jPanelMessage =
            new JPanelMessage("Cannot establish connection to CCA backend");
        LocalSystem.out.println("adding JPanel");
        getContentPane().add(jPanelMessage);
        LocalSystem.out.println("validating");
        jPanelMessage.invalidate();
        getContentPane().validate();
        return;
    }
    LocalSystem.out.println("Connection Created To "+fromHost);

    // Set up the LocalSystem
    LocalSystem.setApplet(this);
    LocalSystem.out.println("set applet");

    LocalSystem.setCodeBaseURL(url1);
    LocalSystem.out.println("set url");

    Container appletContent = getContentPane();
    LocalSystem.out.println("got ContentPane");

    /* retrieve the heartbeat period from the html file */
    int heartbeatPeriod = Integer.parseInt(getParameter("heartbeatPeriod"));
    LocalSystem.out.println("heartbeatPeriod = " + heartbeatPeriod);

    /* are we connecting to a python server? */
    boolean serverIsPython = false;
    String serverIsPythonString = this.getParameter("serverIsPython");
    if (serverIsPythonString!=null) {
        serverIsPython = Boolean.valueOf(serverIsPythonString).booleanValue();
        this.pythonStub = new PythonStub();
        try {
			this.pythonStub.openSessionWithCcaServer(this.clientSocket);
		} catch (CanNotCommunicateWithCcaServerException e) {
	        LocalSystem.out.println("ERROR ERROR ERROR");
	        System.out.println(e.getMessage());
	        showStatus(e.getMessage());
	        LocalSystem.out.println("creating JPanel for error msg");
	        JPanelMessage jPanelMessage =
	            new JPanelMessage("Cannot establish connection to CCA backend");
	        LocalSystem.out.println("adding JPanel");
	        getContentPane().add(jPanelMessage);
	        LocalSystem.out.println("validating");
	        jPanelMessage.invalidate();
	        getContentPane().validate();
	        return;
		}
    }



    System.out.println("instantiating a builder");
    LocalSystem.out.println("Instantiating A Builder");


    Builder builder = new Builder(appletContent,
                                  heartbeatPeriod);


    //appletContent.add(new Builder(server.getInputStream(),
    //     			    server.getOutputStream(),
    //                              appletContent,
    //                              heartbeatPeriod));

       

    if (serverIsPython) {
        ViewPython viewPython = new ViewPython(this.pythonStub);
        builder.addGuiListener(viewPython);
    }else {
        ViewSocket viewSocket = new ViewSocket(clientSocket);
        builder.addGuiListener(viewSocket);
    }





    builder.doStart();

    appletContent.add(builder);

    Gui gui = builder.getGui();




    if (serverIsPython) {
        ControllerPython controllerPython = new ControllerPython(this.pythonStub);
        pythonStub.addPythonControllerListener(controllerPython);        
        controllerPython.addAccessGuiListener(gui);
        controllerPython.addControllerListener(gui);
    } else {
        ControllerSocket controllerSocket = new ControllerSocket(clientSocket);
        controllerSocket.addGuiUserListener(gui);
        controllerSocket.addControllerListener(gui);
        controllerSocket.parse();
    }



    validate();

    // A CLI for the Builder in the same applet window for debug.
    //    content.add(new JConsole(12, 80, server.getInputStream(    //		     server.getOutputStream()));


  }










  /** Assemble the arguments given as a parameter into a form that the
      Args class wants to see it. */
  private Args getArguments(String argString) {
    if(argString == null) {
      return new Args(new String[0]);
    }
    StringTokenizer st = new StringTokenizer(argString);
    Vector argVec = new Vector();
    while(st.hasMoreTokens()) {
      argVec.addElement(st.nextToken());
    }
    String[] argArray = new String[argVec.size()];
    argVec.toArray(argArray);
    return new Args(argArray);
  }
}
