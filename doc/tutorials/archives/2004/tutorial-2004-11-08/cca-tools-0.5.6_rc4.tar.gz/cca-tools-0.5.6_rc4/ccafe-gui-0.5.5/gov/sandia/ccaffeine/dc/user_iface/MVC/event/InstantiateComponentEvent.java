package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaComponent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPort;



public class InstantiateComponentEvent extends java.util.EventObject {


    /**
     * instance name of the instantiated component
     */
    protected String instanceName = null;

    /**
     * Get the instance name of the instantiated component
     * @return instance name of the instantiated component
     */
    public String getInstanceName() {
        return(instanceName);
    }

    /**
     * Set the instance name of the instantiated component
     * @param instanceName instance name of the instantiated component
     */
    public void setInstanceName(String instanceName) {
        this.instanceName = instanceName;
    }




    /**
     * class name of the instantiated component
     */
    protected String className = null;

    /**
     * Get the class name of the instantiated component
     * @return class name of the instantiated component
     */
    public String getClassName() {
        return(className);
    }

    /**
     * Set the class name of the instantiated component
     * @param className instance name of the instantiated component
     */
    public void setClassName(String className) {
        this.className = className;
    }





    /**
     * user ports of the instantiated component
     */
    protected CcaPort userPorts[] = null;

    /**
     * Get the user ports of the instantiated component
     * @return user ports of the instantiated component
     */
    public CcaPort[] getUserPorts() {
        return(userPorts);
    }

    /**
     * Set the user ports of the instantiated component
     * @param userPorts user ports of the instantiated component
     */
    public void setUserPorts(CcaPort userPorts[]) {
        this.userPorts = userPorts;
    }





    /**
     * provider ports of the instantiated component
     */
    protected CcaPort providerPorts[] = null;

    /**
     * Get the provider ports of the instantiated component
     * @return provider ports of the instantiated component
     */
    public CcaPort[] getProviderPorts() {
        return(providerPorts);
    }

    /**
     * Set the provider ports of the instantiated component
     * @param providerPorts provider ports of the instantiated component
     */
    public void setProivderPorts(CcaPort providerPorts[]) {
        this.providerPorts = providerPorts;
    }



    /**
     * Create an  InstantiateComponentEvent.
     * @param source The entity that created this event.
     */
    public InstantiateComponentEvent(Object source) {
        super(source);
        this.instanceName = null;
        this.className = null;
        this.userPorts = null;
        this.providerPorts = null;
    }

    /**
     * Create an  InstantiateComponentEvent.
     * @param source The entity that created this event.
     * @param instanceName the instance name of the instantiated 
     * component.
     * @param className the class name of the instantiated component.
     * @param userPorts the user ports of the instantiated component.
     * @param providerPorts the provider ports of the instantiated
     * component.
     */
    public InstantiateComponentEvent
           (Object source,
            String instanceName,
            String className,
            CcaPort userPorts[],
            CcaPort providerPorts[]) {
        super(source);
        this.instanceName = instanceName;
        this.className = className;
        this.userPorts = userPorts;
        this.providerPorts = providerPorts;
    }

}