package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Used to notify components that the cca server
 * added one or more Provides Ports to a component.
 * A view entity might
 * respond by rendering a box for each port.
 * The boxes could be placed on the left side
 * of the component.
 * <p>
 * Possible Scenario: <br>
 * The end-user drags a component from the palette to the arena <br>
 * The cca server instantiates a new cca component <br>
 * The cca server creates Provides Ports for the new component <br>
 * The cca server sends the Provides Ports to the client <br>
 * The client displays the new Provides Ports are small boxes
 * on the left side of the component <br>
 */


public class AddProvidesPortsEvent extends EventObject {


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


  /**
   * The name of the component that is receiving the new ports.
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "StartComponent0"
   */
    protected String componentInstanceName = null;

  /*
   * Get the name of the component that received the new ports.
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "StartComponent0"
   */
    public String getComponentInstanceName() {
        return(this.componentInstanceName);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The class name and the instance name of all the ports that
     * were added to a component.
     * <p>
     * vector[0] contains the instance name of port[0] <br>
     * vector[1] contains the class name of port[0] <br>
     * vector[2] contains the instance name of port[1] <br>
     * vector[3] contains the class name of port[1] <br>
     * etc. <br>
     * <p>
     * The class name of a port is the name of the
     * port's java class.  The class name may or may not
     * include the package name.  Examples of class names are
     * "gov.cca.componentProperties" and "GoPort."
     * <p>
     * The instance name of a port is the name of
     * an instantiation of the cca port.
     * Examples of instance names are
     * "cProps" and "go_port."
     */
    protected java.util.Vector classNameAndInstanceNameOfAllPorts = null;


    /**
     * Get the class name and the instance name of all the ports that
     * were added to a component.
     * <p>
     * vector[0] contains the instance name of port[0] <br>
     * vector[1] contains the class name of port[0] <br>
     * vector[2] contains the instance name of port[1] <br>
     * vector[3] contains the class name of port[1] <br>
     * etc. <br>
     * <p>
     * The class name of a port is the name of the
     * port's java class.  The class name may or may not
     * include the package name.  Examples of class names are
     * "gov.cca.componentProperties" and "GoPort."
     * @return The class name and the instance name of
     * all ports that were added to a cca component.
     * <p>
     * The instance name of a port is the name of
     * an instantiation of the cca port.  The name
     * is usually the name of the port's class
     * (without the package name).
     *  Examples of instance names are
     * "cProps" and "go_port."
     */
    public java.util.Vector getClassNameAndInstanceNameOfAllPorts() {
        return(this.classNameAndInstanceNameOfAllPorts);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Create an AddProvidesPortEvent.
     * The event can be used to notify components that the cca server
     * added one or more Provides Ports to a component.
     * A view entity might
     * respond by rendering a box for each component.
     * The boxes could be placed on the left side
     * of the component.
     * @param source The object that created this event.
     * @param componentInstanceName The name of the cca
     * component that received the newly created ports.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param classNameAndInstanceNameOfAllPorts
     * the class name and the instance name of all the ports that
     * were added to a component. <br>
     * vector[0] contains the instance name of port[0] <br>
     * vector[1] contains the class name of port[0] <br>
     * vector[2] contains the instance name of port[1] <br>
     * vector[3] contains the class name of port[1] <br>
     * etc. <br>
     * The class name of a port is the name of the
     * port's java class.  The class name may or may not
     * include the package name.  Examples of class names are
     * "gov.cca.componentProperties" and "GoPort." <br>
     * The instance name of a port is the name of
     * an instantiation of the cca port.
     * Examples of instance names are
     * "cProps" and "go_port."
     */
    public AddProvidesPortsEvent
             (Object source,
              String componentInstanceName,
              java.util.Vector classNameAndInstanceNameOfAllPorts) {

        super(source);
        this.componentInstanceName = componentInstanceName;
        this.classNameAndInstanceNameOfAllPorts = classNameAndInstanceNameOfAllPorts;
    }

}