package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import gov.sandia.ccaffeine.cmd.CmdAction;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ControllerListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.AddComponentClassEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.AddProvidesPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.AddUsesPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ConnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisconnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ExitEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GetComponentPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.InstantiateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.LoadEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.MessageEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamCurrentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamDefaultEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamDialogEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamEndDialogEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamFieldEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamHelpEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamNumberRangeEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamPromptEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamStringChoiceEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamTabEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RevalidateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetComponentPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetPortPropertyEvent;

/**
 * Used by the parser to parse String commands
 * from the cca server.  The results of a parse
 * are sent to all registered ControllerListeners.
 */

abstract public class CmdActionGUI extends java.lang.Object
                          implements CmdAction {

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    java.util.Vector controllerListeners = new java.util.Vector();



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Add a new ControllerListener.
     * ControllerListeners are notified whenever the cca server
     * makes changes.
     * @param listener The new ControllerListener
     */
    synchronized public void addControllerListener(ControllerListener listener) {
        controllerListeners.add(listener);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Remove a ControllerListener.
     * The input ControllerListener is no longer notified
     * whenever the cca server makes changes.
     * @param listener The ControllerListener that no lonter
      * wants to be notified when the cca server makes a change.
      */
    synchronized public void removeControllerListener(ControllerListener listener) {
        controllerListeners.remove(listener);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Tell all ControllerListeners that the cca server
     * has added a new class.  The new class can be
     * used to instantiate new cca components.  A view
     * might respond by adding a box to a palette.
     * @param className the name of the newly added class.
     * The name is actually the name of the component's
     * java class.  For example, the name could be
     * "gov.sandia.ccaffeine.dc.component.PrinterComponent"
     */
    protected void broadcastAddComponentClass(String className){
        AddComponentClassEvent event = new AddComponentClassEvent(this, className);
        broadcastAddComponentClassEvent(event);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /*
     * Tell all ControllerListeners that the cca server
     * has added a new class.  The new class can be
     * used to instantiate new cca components.  A view
     * might respond by adding a box to a palette.
     * @param event The event that is generated whenever
     * the cca server adds a new class.
     */
    protected void broadcastAddComponentClassEvent(AddComponentClassEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.addComponentClass(event);
         }
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Tell all ControllerListeners that the cca server
     * added one or more Provides Ports to a component.
     * A view entity might
     * respond by rendering a box for each component.
     * The boxes could be placed on the left side
     * of the component.
     * @param componentInstanceName The name of the cca
     * component that received the newly created ports.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param classNameAndInstanceNameOfAllPorts
     * the class name and the instance name of all the ports that
     * were added to a component. <br>
     * vector[0] contains the instance name of port[0] <br>
     * vector[1] contains the class name of port[0] <br>
     * vector[2] contains the instance name of port[1] <br>
     * vector[3] contains the class name of port[1] <br>
     * etc. <br>
     * <p>
     * The class name of a port is the name of the
     * port's java class.  The class name may or may not
     * include the package name.  Examples of class names are
     * "gov.cca.componentProperties" and "GoPort."
     * <p>
     * The instance name of a port is the name of
     * an instantiation of the cca port.
     * Examples of instance names are
     * "cProps" and "go_port."
     */
    protected void broadcastAddProvidesPorts
              (String componentInstanceName,
               java.util.Vector classNameAndInstanceNameOfAllPorts) {
        AddProvidesPortsEvent event = new AddProvidesPortsEvent
            (this,
             componentInstanceName,
             classNameAndInstanceNameOfAllPorts);
        this.broadcastAddProvidesPorts(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that the cca server
     * added one or more Provides Ports to a component.
     * A view entity might
     * respond by rendering a box for each component.
     * The boxes could be placed on the left side
     * of the component.
     * @param event That event that is generated
     * whenever the cca server adds ports
     * to a component.
     */
    protected void broadcastAddProvidesPorts
        (AddProvidesPortsEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.addProvidesPorts(event);
        }
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Tell all ControllerListeners that the cca server
     * added one or more Uses Ports to a component.
     * A view entity might
     * respond by rendering a box for each component.
     * The boxes could be placed on the right side
     * of the component.
     * @param componentInstanceName The name of the cca
     * component that received the newly created ports.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param classNameAndInstanceNameOfAllPorts
     * the class name and the instance name of all the ports that
     * were added to a component. <br>
     * vector[0] contains the instance name of port[0] <br>
     * vector[1] contains the class name of port[0] <br>
     * vector[2] contains the instance name of port[1] <br>
     * vector[3] contains the class name of port[1] <br>
     * etc. <br>
     * <p>
     * The class name of a port is the name of the
     * port's java class.  The class name may or may not
     * include the package name.  Examples of class names are
     * "gov.cca.PrintService" and "StringConsumerPort."
     * <p>
     * The instance name of a port is the name of
     * an instantiation of the cca port.
     * Examples of instance names are
     * "pSvc" and "out0"
     */
    protected void broadcastAddUsesPorts
              (String componentInstanceName,
               java.util.Vector classNameAndInstanceNameOfAllPorts) {
        AddUsesPortsEvent event = new AddUsesPortsEvent
            (this,
             componentInstanceName,
             classNameAndInstanceNameOfAllPorts);
        this.broadcastAddUsesPorts(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that the cca server
     * added one or more Uses Ports to a component.
     * A view entity might
     * respond by rendering a box for each component.
     * The boxes could be placed on the right side
     * of the component.
     * @param event That event that is generated
     * whenever the cca server adds ports
     * to a component.
     */
    protected void broadcastAddUsesPorts
        (AddUsesPortsEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.addUsesPorts(event);
        }
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Tell all ControllerListeners that the cca server
     * connected a Provides Port from one component
     * to a Uses Port.  The Uses Port may be from the
     * same component or may be from a different component.
     * A view entity might
     * respond by drawing a line between the two connected ports.
     * @param sourceComponentName The name of the component
     * that houses the source port.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param sourcePortName The name of the source port.
     * Example:  "out0"
     * @param targetComponentName The name of the component
     * that houses the target port.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "PrinterComponent0"
     * @param targetPortName the name of the target port.
     * Example:  "out0"
     */
    protected void broadcastConnect
        (String sourceComponentName,
         String sourcePortName,
         String targetComponentName,
         String targetPortName) {
        ConnectEvent event = new ConnectEvent
            (this,
             sourceComponentName,
             sourcePortName,
             targetComponentName,
             targetPortName);
        this.broadcastConnectEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that the cca server
     * connected a Provides Port from one component
     * to a Uses Port.  The Uses Port may be from the
     * same component or may be from a different component.
     * A view entity might
     * respond by drawing a line between the two connected ports.
     * @param event That event that is generated
     * whenever the cca server connects a Provides Port
     * with a Uses Port.
     */
    protected void broadcastConnectEvent(ConnectEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.connect(event);
        }
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Tell all ControllerListeners that the cca server
     * broke the connection between a Provides Port
     * and a Uses Port.  A view entity might
     * respond by drawing a line between the two connected ports.
     * @param sourceComponentName The name of the component
     * that houses the source port.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param sourcePortName The name of the source port.
     * Example:  "out0"
     * @param targetComponentName The name of the component
     * that houses the target port.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "PrinterComponent0"
     * @param targetPortName the name of the target port.
     * Example:  "out0"
     */
    protected void broadcastDisconnect
        (String sourceComponentName,
         String sourcePortName,
         String targetComponentName,
         String targetPortName) {
        DisconnectEvent event = new DisconnectEvent
            (this,
             sourceComponentName,
             sourcePortName,
             targetComponentName,
             targetPortName);
        this.broadcastDisconnectEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that the cca server
     * broke the connection between a Provides Port
     * and a Uses Port.  A view entity might
     * respond by drawing a line between the two connected ports.
     * @param event That event that is generated
     * whenever the cca server breaks the connect between a
     * a Provides Port and a Uses Port.
     */
    protected void broadcastDisconnectEvent(DisconnectEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.disconnect(event);
        }
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Tell all ControllerListeners that the cca server
     * has terminated its communication link with this client.
     * A client might
     * respond by exiting the program.
     */
    protected void broadcastExit() {
        ExitEvent event = new ExitEvent(this);
        this.broadcastExitEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that the cca server
     * has terminated its communication link with this client.
     * A client might
     * respond by exiting the program.
     * @param event That event that is generated
     * whenever the cca server breaks its communication link
     * with this client.
     */
    protected void broadcastExitEvent(ExitEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.exit(event);
        }
    }







    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Tell all ControllerListeners that the cca server
     * wants the GUI to display the value of a component
     * property.
     * The GUI might
     * respond by writing the value to stdout.
     * @param componentName The name of the component
     * that contains the property.
     * @param propertyName The name of the property.
     */
    protected void broadcastGetComponentProperty
        (String componentInstanceName,
         String propertyName) {
        GetComponentPropertyEvent event = new GetComponentPropertyEvent
            (this,
             componentInstanceName,
             propertyName);
        this.broadcastGetComponentPropertyEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that the cca server
     * wants the GUI to display the value of a
     * component property.
     * The GUI might
     * respond by writing the value to stdout.
     * @param event The event that is generated whenever
     * the cca server is querying for the value of a
     * property inside a cca component.
     */
    protected void broadcastGetComponentPropertyEvent(GetComponentPropertyEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.getComponentProperty(event);
        }
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Tell all ControllerListeners that the cca server
     * used a cca component class to instantiate a new
     * cca component object.  A view entity might
     * respond by rendering a box inside of an arena.
     * @param className The name of the class
     * that was used to instantiate a new cca component.
     * The name is actually the name of the component's
     * java class.
     * EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
     * @param instanceName The name of the newly instantiated
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     */
    protected void broadcastInstantiate
        (String className,
         String instanceName) {
        InstantiateEvent event = new InstantiateEvent
            (this,
             className,
             instanceName);
        this.broadcastInstantiateEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that the cca server
     * used a cca component class to instantiate a new
     * cca component object.  A view entity might
     * respond by rendering a box inside of an arena.
     * @param event The event that is generated whenever
     * the cca server used a cca component class to
     * instantiate a new cca component object.
     */
    protected void broadcastInstantiateEvent(InstantiateEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.instantiate(event);
        }
    }








    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Tell all ControllerListeners that the cca server loaded
     * the class of a cca widget.
     * The class can be used to instantiate
     * cca widgets.
     * A view might respond by rendering components
     * in the palette.  The end-user can drag-and-drop
     * components from the palett to the main
     * workspace (the arena).
     * @param className The name of a cca widget class.
     * The name is actually the name of the widget's
     * java class.
     * EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
     * @param arguments There must always be one
     * argument: the class name of the widget itself, other special
     * purpose arguments may follow.
     */
    protected void broadcastLoad
        (String className,
         java.util.Vector arguments) {
         LoadEvent event = new LoadEvent
            (this,
             className,
             arguments);
        this.broadcastLoadEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that the cca server loaded
     * the class of a cca widget.
     * The class can be used to instantiate
     * cca widgets.
     * A view might respond by rendering components
     * in the palette.  The end-user can drag-and-drop
     * components from the palett to the main
     * workspace (the arena).
     * @param event The event that is generated whenever
     * the cca server loads the java class of a cca widget.
     */
    protected void broadcastLoadEvent(LoadEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.load(event);
        }
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Tell all ControllerListeners that the cca server
     * sent a message to this client.
     * For example, a server might respond to a "go" command
     * by sending a message.
     * A view entity might respond by printing a string
     * on standard out.
     * @param args The contents of the message
     */
    protected void broadcastMessage(java.util.Vector args) {

         /* convert the vector into a string */
         StringBuffer MSG = new StringBuffer();
         int numberOfArgs = args.size();
         for (int i=0; i<numberOfArgs; i++) {
           MSG.append(args.get(i).toString());
           MSG.append(" ");
         }
         String msg = MSG.toString();


         MessageEvent event = new MessageEvent(this,msg);
        this.broadcastMessageEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that the cca server
     * sent a message to this client.
     * For example, a server might respond to a "go" command
     * by sending a message.
     * A view entity might respond by printing a string
     * on standard out.
     * @param event The event that is created whenever
     * the cca server sends a message to this client.
     */
    protected void broadcastMessageEvent(MessageEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.message(event);
        }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Notify all ControllerListeners that the cca server
     * is sending the value of a data field.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * The cca server is sending the value
     * of one of these data fields.  A view entity might
     * respond by displaying the current value on the screen.
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The instance name of the port
     * that contains the data field.
     * Example:  "configure_port"
     * @param dataFieldName
     * The name of the data field.
     * @param dataFieldValue
     * The value of the data field.
     */
    protected void broadcastParamCurrent
             (String componentInstanceName,
              String portInstanceName,
              String dataFieldName,
              String dataFieldValue) {
         ParamCurrentEvent event = new ParamCurrentEvent
             (this,
              componentInstanceName,
              portInstanceName,
              dataFieldName,
              dataFieldValue);
        this.broadcastParamCurrentEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Notify all ControllerListeners that the cca server
     * is sending the value of a data field.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * The cca server is sending the value
     * of one of these data fields.  A view entity might
     * respond by displaying the current value on the screen.
     * @param event The event that is created whenever
     * the cca server sends the value of a data field.
     */
    protected void broadcastParamCurrentEvent(ParamCurrentEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.paramCurrent(event);
        }
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Notify all ControllerListeners that the cca server
     * is sending the default value of a data field.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * The cca server is sending the default value
     * of one of these data fields.  A view entity
     * might respond by checking the state of a
     * data field; if the data field does not have
     * a current value then the default value is
     * displayed on the screen.
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The instance name of the port
     * that contains the data field.
     * Example:  "configure_port"
     * @param dataFieldName
     * The name of the data field.
     * @param dataFieldDefaultValue
     * The default value of the data field.
     */
    protected void broadcastParamDefault
             (String componentInstanceName,
              String portInstanceName,
              String dataFieldName,
              String dataFieldDefaultValue) {
         ParamDefaultEvent event = new ParamDefaultEvent
             (this,
              componentInstanceName,
              portInstanceName,
              dataFieldName,
              dataFieldDefaultValue);
        this.broadcastParamDefaultEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

     /**
     * Notify all ControllerListeners that the cca server
     * is sending the default value of a data field.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * The cca server is sending the default value
     * of one of these data fields.  A view entity
     * might respond by checking the state of a
     * data field; if the data field does not have
     * a current value then the default value is
     * displayed on the screen.
     * @param event The event that is created whenever
     * the cca server sends the default value of a data field.
     */
    protected void broadcastParamDefaultEvent(ParamDefaultEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.paramDefault(event);
        }
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



     /**
      * Tell all ControllerListeners that
      * the cca server wants this client
      * to create (but not display) a dialog box
      * to hold the values of all the data fields
      * that are inside a port.
      * <p>
      * Cca components contain ports.
      * Some of the ports contain data fields.
      * The cca server wants the client to
      * create (but not display) a dialog box
      * that contains the values
      * of all the data fields in the port.  A view
      * entity might respond by creating an empty
      * dialog box.
      * @param componentInstanceName
      * The name of the cca component that contains
      * the port which contains the data fields.
      * The name is usually the java class name of the component
      * (without the package name) concatenated with an index number.
      * Example:  "TimeStamper0"
      * @param portInstanceName
      * The instance name of a port that
      * contains the data fields.
      * Example: "configure_port"
      * @param titleOfDialogBox
      * The title of
      * the dialog box.
      */
    protected void broadcastParamDialog
             (String componentInstanceName,
              String portInstanceName,
              String titleOfDialogBox) {
         ParamDialogEvent event = new ParamDialogEvent
             (this,
              componentInstanceName,
              portInstanceName,
              titleOfDialogBox);
        this.broadcastParamDialogEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

     /**
      * Tell all ControllerListeners that
      * the cca server wants this client
      * to create (but not display) a dialog box
      * to hold the values of all the data fields
      * that are inside a port.
      * <p>
      * Cca components contain ports.
      * Some of the ports contain data fields.
      * The cca server wants the client to
      * create (but not display) a dialog box
      * that contains the values
      * of all the data fields in the port.  A view
      * entity might respond by creating an empty
      * dialog box.
      * @param event The event that is created whenever
      * the cca server wants the client to display a dialog
      * box.
      */
    protected void broadcastParamDialogEvent(ParamDialogEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.paramDialog(event);
        }
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



     /**
      * Tell all ControllerListeners that the
      * cca components contain ports.
      * Some of the ports contain data fields.
      * The cca server has finished sending information
      * for all the data fields in a port.  A client
      * entity might respond by displaying a dialog box
      * that was already populated with information
      * from all the data fields.
      * @param componentInstanceName
      * The name of the cca component that contains
      * the port which contains the data fields.
      * The name is usually the java class name of the component
      * (without the package name) concatenated with an index number.
      * Example:  "TimeStamper0"
      * @param portInstanceName
      * The instance name of a port that contains
      * the data fields.
      *  Example: "configure_port"
      */
    protected void broadcastParamEndDialog
             (String componentInstanceName,
              String portInstanceName) {
         ParamEndDialogEvent event = new ParamEndDialogEvent
             (this,
              componentInstanceName,
              portInstanceName);
        this.broadcastParamEndDialogEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

     /**
      * Tell all ControllerListeners that the cca server
      * wants ths client
      * to display a dialog box
      * to allow the end-user
      * to view/edit the current data field values that are stored
      * inside of a port.
      * @param event The event that is created whenever
      * the cca server wants the client to display a dialog
      * box.
      */
    protected void broadcastParamEndDialogEvent(ParamEndDialogEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.paramEndDialog(event);
        }
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/






    /**
     * Tell all ControllerListeners that the
     * cca server wants to send the name of a data
     * field to this client.
     * <br>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * The cca server is sending the name of
     * a data field.  A client
     * entity might respond by inserting a line of
     * data into a dialog box.
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The name of a port that contains the data field.
     *  Example: "configure_port"
     * @param dataFieldDataType
     * The data type of the value that is
     * stored in the data field (e.g. STRING).
     * @param dataFieldName
     * The name of the data field.
      */
    protected void broadcastParamField
             (String componentInstanceName,
              String portInstanceName,
              String dataFieldDataType,
              String dataFieldName) {
         ParamFieldEvent event = new ParamFieldEvent
             (this,
              componentInstanceName,
              portInstanceName,
              dataFieldDataType,
              dataFieldName);
        this.broadcastParamFieldEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

     /**
     * Tell all ControllerListeners that the
     * cca server wants to send the name of a data
     * field to this client.
     * <br>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * The cca server is sending the name of
     * a data field.  A client
     * entity might respond by inserting a line of
     * data into a dialog box.
     * @param event The event that is created whenever
     * the cca server sends the name of a data field.
     */
    protected void broadcastParamFieldEvent(ParamFieldEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.paramField(event);
        }
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/










    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/






    /**
     * Tell all ControllerListeners that
     * the cca server has sent this client
     * some helpful info about this data field.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * This event can be used to notify components
     * that the cca server is sending the text that
     * contains helpful information on the data field.
     * A client entity might respond by setting up a
     * help system inside of a dialog box.
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The name of a port that contains the data field.
     *  Example: "configure_port"
     * @param dataFieldName
     * The name of the data field.
     * @param dataFieldHelp
     * Contains some helpful info on this data field.
      */
    protected void broadcastParamHelp
             (String componentInstanceName,
              String portInstanceName,
              String dataFieldName,
              String dataFieldHelp) {
         ParamHelpEvent event = new ParamHelpEvent
             (this,
              componentInstanceName,
              portInstanceName,
              dataFieldName,
              dataFieldHelp);
        this.broadcastParamHelpEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

     /**
     * Tell all ControllerListeners that
     * the cca server has sent this client
     * some helpful info about this data field.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * This event can be used to notify components
     * that the cca server is sending the text that
     * contains helpful information on the data field.
     * A client entity might respond by setting up a
     * help system inside of a dialog box.
     * @param event The event that is generated
     * whenever the cca server sends this client
     * helpful info about a data field that is inside
     * a port.
     */
    protected void broadcastParamHelpEvent(ParamHelpEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.paramHelp(event);
        }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/






    /**
     * Tell all ControllerListeners that
     * the cca server sent the lowest value
     * and the highest value that the current
     * data field can have.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * Some of the data fields restrict the
     * range that a value can have.
     * The cca server is sending the lowest value
     * and the highest value that a data field value
     * can have.  A client entity might respond by verifying
     * the end-user's input is within the allowed range.
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The name of a port that contains the data field.
     * Example: "configure_port"
     * @param dataFieldName
     * The name of the data field.
     * @param dataFieldMinValue
     * The smallest value that can be inserted
     * into the data field.
     * @param datafieldMaxValue
     * The largest value that can be inserted
     * into the data field.
     */
    protected void broadcastParamNumberRange
             (String componentInstanceName,
              String portInstanceName,
              String dataFieldName,
              String dataFieldMinValue,
              String dataFieldMaxValue) {
         ParamNumberRangeEvent event = new ParamNumberRangeEvent
             (this,
              componentInstanceName,
              portInstanceName,
              dataFieldName,
              dataFieldMinValue,
              dataFieldMaxValue);
        this.broadcastParamNumberRangeEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that
     * the cca server sent the lowest value
     * and the highest value that the current
     * data field can have.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * Some of the data fields restrict the
     * range that a value can have.
     * The cca server is sending the lowest value
     * and the highest value that a data field value
     * can have.  A client entity might respond by verifying
     * the end-user's input is within the allowed range.
     * @param event The event that is generated
     * whenever the cca server sends this client
     * the lowest value and the highest value
     * the current data field can contain.
     */
    protected void broadcastParamNumberRangeEvent(ParamNumberRangeEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.paramNumberRange(event);
        }
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/






    /**
     * Tell all ControllerListeners that
     * the cca server sent us the prompt string
     * for one of the data fields in one of the
     * ports of a cca component.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * This event can be used to notify components
     * that the cca server is sending a prompt string
     * for a data field.
     * A client entity might display the string to prompt
     * the end-user for the value of this data field.
     */
    protected void broadcastParamPrompt
             (String componentInstanceName,
              String portInstanceName,
              String dataFieldName,
              String dataFieldPrompt) {
         ParamPromptEvent event = new ParamPromptEvent
             (this,
              componentInstanceName,
              portInstanceName,
              dataFieldName,
              dataFieldPrompt);
        this.broadcastParamPromptEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that
     * the cca server sent us the prompt string
     * for one of the data fields in one of the
     * ports of a cca component.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * This event can be used to notify components
     * that the cca server is sending a prompt string
     * for a data field.
     * A client entity might display the string to prompt
     * the end-user for the value of this data field.
     * @param event The event that is generated
     * whenever the cca server sends this client
     * the contents of a help string.
     */
    protected void broadcastParamPromptEvent(ParamPromptEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.paramPrompt(event);
        }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/






    /**
     * Tell all ControllerListeners that
     * the cca server is sending one, out of many,
     * possible values that can be inserted into a
     * data field.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * For some data fields, the value must be
     * one of the items in a set (e.g. "red", "green", "blue").
     * The cca server is sending one item that
     * belongs in such a set.
     * A client entity can display the items in the set
     * as a pull down menu.
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The name of a port that contains the data field.
     * Example: "configure_port"
     * @param dataFieldName
     * The name of the data field.
     * @param dataFieldElementInSetOfValues
     * One of the possible values that can be
     * inserted into this data field.
     */
    protected void broadcastParamStringChoice
             (String componentInstanceName,
              String portInstanceName,
              String dataFieldName,
              String dataFieldElementInSetOfValues) {
         ParamStringChoiceEvent event = new ParamStringChoiceEvent
             (this,
              componentInstanceName,
              portInstanceName,
              dataFieldName,
              dataFieldElementInSetOfValues);
        this.broadcastStringChoiceEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that
     * the cca server is sending one, out of many,
     * possible values that can be inserted into a
     * data field.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * For some data fields, the value must be
     * one of the items in a set (e.g. "red", "green", "blue").
     * The cca server is sending one item that
     * belongs in such a set.
     * A client entity can display the items in the set
     * as a pull down menu.
     * @param event The event that is generated
     * whenever the cca server sends this client
     * one, out of many, possible values that can be
     * inserted into this data field.
     */
    protected void broadcastStringChoiceEvent(ParamStringChoiceEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.paramStringChoice(event);
        }
    }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/






    /**
     * Tell all ControllerListeners that
     * the cca server is sending the name of tab.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * Sometimes, the data fields are grouped
     * into sets.  The cca server is sending the
     * name of such a set.
     * A client entity can display each set as a
     * tabbed pane.
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The name of a port that contains the data field.
     * Example: "configure_port"
     * @param tabName
     * The name of the tab.
     */
    protected void broadcastParamTabChoice
             (String componentInstanceName,
              String portInstanceName,
              String tabName) {
         ParamTabEvent event = new ParamTabEvent
             (this,
              componentInstanceName,
              portInstanceName,
              tabName);
        this.broadcastTabEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that
     * the cca server is sending the name of tab.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * Sometimes, the data fields are grouped
     * into sets.  The cca server is sending the
     * name of such a set.
     * A client entity can display each set as a
     * tabbed pane.
     * @event The event that is generated whenever
     * the cca server sends us the name of a tab.
     */
    protected void broadcastTabEvent(ParamTabEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.paramTab(event);
        }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/






    /**
     * Tell all ControllerListeners that
     * the cca server has removed an instantiation of a
     * cca component.
     * A view entity might
     * respond by removing the component from the arena.
     * @param componentInstanceName
     * The name of the component that was removed.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    protected void broadcastRemove
             (String componentInstanceName) {
         RemoveEvent event = new RemoveEvent
             (this,
              componentInstanceName);
        this.broadcastRemoveEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that
     * the cca server has removed an instantiation of a
     * cca component.
     * A view entity might
     * respond by removing the component from the arena.
     * @param event The event that is generated whenever
     * the cca server removes an instantiation of a cca
     * component.
     */
    protected void broadcastRemoveEvent(RemoveEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.remove(event);
        }
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/






    /**
     * Tell all ControllerListeners that
     * the cca server has revalidated all of the cca ports in
     * a cca component.
     * A view might respond by re-rendering all of the ports
     * that are inside a cca component.
     * @param componentInstanceName
     * The name of the component that was revalidated.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    protected void broadcastRevalidate
             (String componentInstanceName) {
         RevalidateEvent event = new RevalidateEvent
             (this,
              componentInstanceName);
        this.broadcastRevalidateEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that
     * the cca server has revalidated all of the cca ports in
     * a cca component.
     * A view might respond by re-rendering all of the ports
     * that are inside a cca component.
     * @param event The event that is generated
     * whenever the cca server revalidates all of the
     * cca ports in a cca component.
     */
    protected void broadcastRevalidateEvent(RevalidateEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.revalidate(event);
        }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/






    /**
     * Tell all ControllerListeners that
     * the cca server
     * has set the value of a property that is inside
     * a cca component.
     * A view entity might
     * respond by saving the new value of the property.
     * @param componentInstanceName
     * The name of the component that contains the property
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param propertyName The name of the property.
     * @param propertyValue The value of the property.
     */
    protected void broadcastSetComponentProperty
             (String componentInstanceName,
              String propertyName,
              String propertyValue) {
         SetComponentPropertyEvent event = new SetComponentPropertyEvent
             (this,
              componentInstanceName,
              propertyName,
              propertyValue);
        this.broadcastSetComponentPropertyEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that
     * the cca server
     * has set the value of a property that is inside
     * a cca component.
     * A view entity might
     * respond by saving the new value of the property.
     * @param event The event that is generated whenever
     * the cca server sets the value of property
     * that is inside a cca component.
     */
    protected void broadcastSetComponentPropertyEvent(SetComponentPropertyEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.setComponentProperty(event);
        }
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/












    /**
     * Tell all ControllerListeners that
     * the cca server
     * has set the value of a property that is inside
     * a port of a cca component.
     * A view entity might
     * respond by saving the new value of the property.
     * @param componentInstanceName
     * The name of the component that contains the property
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param portInstanceName
     * @param propertyName The name of the property.
     * @param dataType The data type of the value
     * @param propertyValue The value of the property.
     */
    protected void broadcastSetPortProperty
             (String componentInstanceName,
              String portInstanceName,
              String propertyName,
              String dataType,
              String propertyValue) {
         SetPortPropertyEvent event = new SetPortPropertyEvent
             (this,
              componentInstanceName,
              portInstanceName,
              propertyName,
              dataType,
              propertyValue);
        this.broadcastSetPortPropertyEvent(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell all ControllerListeners that
     * the cca server
     * has set the value of a property that is inside
     * of a port in a cca component.
     * A view entity might
     * respond by saving the new value of the property.
     * @param event The event that is generated whenever
     * the cca server sets the value of property
     * that is inside port of a cca component.
     */
    protected void broadcastSetPortPropertyEvent(SetPortPropertyEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)controllerListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            ControllerListener x = (ControllerListener)listeners.elementAt(i);
            x.setPortProperty(event);
        }
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/






}



