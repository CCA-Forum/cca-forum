package gov.sandia.ccaffeine.dc.user_iface.gui;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.Gui;
import gov.sandia.ccaffeine.dc.user_iface.AccessServer;

public class ConfigureDialog extends JDialog {
    public ConfigureDialog(String component,
			   String port,
			   String title,
			   GlobalData global){
	super();
	setTitle(title);
	this.component = component;
	this.port = port;
	this.global = global;
	initialize();
    }
    private void initialize(){
	content = getContentPane();
	tabbedPane = new JTabbedPane();

	names       = new Vector();
	types       = new Vector();
	dataObjects = new Vector();
	defaults    = new Vector();
	dataFields  = new Vector();

	stringChoices = new Vector();

	isFirstTab = true;
	isFirstDataField = true;

	parentComponent = global.getArena().getComponentInstance(component);

	errorDialog = new ErrorDialog(this);
    }
    private String tabTitle;
    private String paramType;
    private String paramCurrent;
    private String paramHelp;
    private String paramPrompt;
    private String paramDefault;
    private double paramLow;
    private double paramHigh;
    private Vector stringChoices;
    private JLabel helpLabel;

    private Box thisTab;
    private JPanel thisDataField;

    private boolean isFirstTab;
    private boolean isFirstDataField;

    public void newTab(String title){
	if(isFirstTab == false)
	    finishPreviousTab();
	else
	    isFirstTab = false;
	tabTitle = title;
	thisTab = Box.createVerticalBox();
	thisTab.add(Box.createVerticalStrut(10));
    }

    public void newDataField(String type, String name){
	if(isFirstDataField == false)
	    finishPreviousDataField();
	else
	    isFirstDataField = false;
	paramType = type;
	thisDataField = new JPanel();
	dataFields.add(thisDataField);
	thisDataField.setBorder(normalBorder);
	thisDataField.setLayout
	    (new BoxLayout(thisDataField, BoxLayout.X_AXIS));
	thisDataField.add(Box.createHorizontalStrut(5));
	types.add(paramType);
	names.add(name);
    }

    public void setCurrentValue(String name, String current){
	paramCurrent = current;
    }

    public void setHelpText(String name, String help){
	helpLabel = new JLabel(" ? ");
	helpLabel.setBorder(BorderFactory.createEtchedBorder());
	helpLabel.setToolTipText(help);
    }

    public void setPromptText(String name, String prompt){
	thisDataField.add(new JLabel(prompt));
	thisDataField.add(Box.createHorizontalStrut(5));
	thisDataField.add(Box.createHorizontalGlue());
    }

    public void setDefaultValue(String name, String dflt){
	paramDefault = dflt;
    }

    public void setNumberRange(String name, String lowValue, String highValue){
	paramDefault += ":" + lowValue + ":" + highValue;
	try{
	    paramLow  = Double.parseDouble( lowValue);
	    paramHigh = Double.parseDouble(highValue);
	} catch (NumberFormatException nfe){
	    nfe.printStackTrace();
	}
    }

    public void addStringChoice(String name, String choice){
	stringChoices.add(choice);
    }

    private void finishPreviousDataField(){
	defaults.add(paramDefault);
	if(paramType.equals("BOOL")){
	    JRadioButton trueButton = new JRadioButton("True");
	    JRadioButton falseButton = new JRadioButton("False");
	    trueButton.setActionCommand("true");
	    falseButton.setActionCommand("false");

	    ButtonGroup buttonGroup = new ButtonGroup();
	    buttonGroup.add(trueButton);
	    buttonGroup.add(falseButton);
	    dataObjects.add(buttonGroup);

	    thisDataField.add(trueButton);
	    thisDataField.add(falseButton);

	    if(paramCurrent.equals("false")
	       || paramCurrent.equals("0"))
		falseButton.setSelected(true);
	    else
		trueButton.setSelected(true);
	}

	else if
	    (paramType.equals("INT")   ||
	     paramType.equals("LONG")  ||
	     paramType.equals("FLOAT") ||
	     paramType.equals("DOUBLE")  ){

	    String range = "";
	    if(paramType.equals("INT"))
		range += " {" +   (int)paramLow + ", " +  (int)paramHigh + "}";
	    else if(paramType.equals("LONG"))
		range += " {" +  (long)paramLow + ", " + (long)paramHigh + "}";
	    else if(paramType.equals("FLOAT"))
		range += " {" + (float)paramLow + ", " +(float)paramHigh + "}";
	    else
		range += " {" +        paramLow + ", " +       paramHigh + "}";
	    thisDataField.add(new JLabel(range));
	    thisDataField.add(Box.createHorizontalStrut(5));

	    JTextField textField = new JTextField(paramCurrent,10);
	    textField.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
			analyzeInput();
		    }
		});
	    thisDataField.add(textField);
	    dataObjects.add(textField);
	}

	else if(paramType.equals("STRING")){
	    int choices = stringChoices.size();
	    if(choices > 1){
		JComboBox comboBox = new JComboBox();
		for(int i = 0; i < choices; i++){
		    comboBox.addItem(stringChoices.get(i));
		    if(stringChoices.get(i).equals(paramCurrent))
			comboBox.setSelectedIndex(i);
		}
		stringChoices.clear();
		thisDataField.add(comboBox);
		dataObjects.add(comboBox);
	    }else{
		JTextField textField = new JTextField(paramCurrent,10);
		textField.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
			    analyzeInput();
			}
		    });
		thisDataField.add(textField);
		dataObjects.add(textField);
	    }

	}
	thisDataField.add(Box.createHorizontalStrut(5));
	thisDataField.add(helpLabel);
	thisDataField.add(Box.createHorizontalStrut(5));
	thisDataField.setMaximumSize(new Dimension
	    (9999,thisDataField.getPreferredSize().height));
	thisTab.add(thisDataField);
	thisTab.add(Box.createVerticalStrut(10));
    }

    public void finishPreviousTab(){
	if(isFirstDataField == false)
	    finishPreviousDataField();
	thisTab.add(Box.createVerticalGlue());
	JButton     okButton = new JButton("OK");
	JButton cancelButton = new JButton("Cancel");
	okButton.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		    analyzeInput();
		}
	    });
	cancelButton.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		    dispose();
		}
	    });
	JPanel OKCancel = new JPanel();
	OKCancel.setLayout(new BoxLayout(OKCancel, BoxLayout.X_AXIS));
	OKCancel.add(Box.createHorizontalStrut(20));
	OKCancel.add(Box.createHorizontalGlue());
	OKCancel.add(okButton);
	OKCancel.add(Box.createHorizontalStrut(10));
	OKCancel.add(cancelButton);
	OKCancel.add(Box.createHorizontalStrut(10));
	OKCancel.setMaximumSize(new Dimension
	    (9999,OKCancel.getPreferredSize().height));
	thisTab.add(OKCancel);
	if(dataFields.size() == 0)
	    okButton.setEnabled(false);
	thisTab.add(Box.createVerticalStrut(10));
	tabbedPane.addTab(tabTitle,thisTab);
	isFirstDataField = true;
    }

    public void finishAndShow(){
	finishPreviousTab();
	inputGood = new boolean[dataObjects.size()];
	if(true)
	    content.add(tabbedPane);
	else{
	    setTitle("Insufficient Data (Sorry!)");
	    if(tabbedPane.getComponentCount() == 0){
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
			    dispose();
			}
		    });
		content.add(cancelButton);
	    }
	}
	int vertInsets = global.getAppFrame().getInsets().top +
	    global.getAppFrame().getInsets().bottom;
	int horizInsets = global.getAppFrame().getInsets().left +
	    global.getAppFrame().getInsets().right;
	setSize(new Dimension
	    (getPreferredSize().width + horizInsets,
	     getPreferredSize().height + vertInsets));
	show();
    }

    private void analyzeInput(){
	String dataString = "";
	allInputGood = true;
	errorsString = "";
	for(int i = 0; i < dataObjects.size(); i++){
	    String paramType = (String)types.get(i);
	    dataString += "parameters "
		+ component + " "
		+ port + " "
		+ (String)names.get(i) + " ";
	    if(paramType.equals("BOOL"))
		dataString += handleBoolean(i) + "\n";
	    else if(paramType.equals("INT"))
		dataString += (int)testRange(i,INT_VALUE) + "\n";
	    else if(paramType.equals("LONG"))
		dataString += (long)testRange(i,LONG_VALUE) + "\n";
	    else if(paramType.equals("FLOAT"))
		dataString += (float)testRange(i,FLOAT_VALUE) + "\n";
	    else if(paramType.equals("DOUBLE"))
		dataString += testRange(i,DOUBLE_VALUE) + "\n";
	    else if(paramType.equals("STRING"))
		dataString += handleString(i) + "\n";
	    else
		System.err.println("Data type " + i + " is bad.");
	}
	if(allInputGood){
	    StringTokenizer tokens = new StringTokenizer(dataString,"\n");
	    while(tokens.hasMoreTokens()){


		//global.write(tokens.nextToken());
                String token = tokens.nextToken();
                global.addToHistoryAndToDebugger(token);
                sendParametersCommandToCcaServer(token);





		global.informOfChange();
	    }
	    dispose();
	}else{
	    for(int i = 0; i < dataFields.size(); i++){
		if(inputGood[i])
		    ((JPanel)dataFields.get(i)).setBorder(normalBorder);
		else
		    ((JPanel)dataFields.get(i)).setBorder(flaggedBorder);
	    }
	    System.out.println("***********"+errorsString);
	    errorDialog.show(errorsString);
	}

    }




    protected void sendParametersCommandToCcaServer(String command) {

        /* error check */
        if (command==null) return;

        /* break string into workds */
        java.util.Vector tok = breakStringIntoWords(command);

        /* Get the Gui */
        Gui gui = global.getBuilder().getGui();
        AccessServer accessServer = global.getBuilder().getAccessServer();


       /*
        * concatenate the 5th, 6th, 7th, ... elements
        * to form the value of this data field.
        */
        if (tok.size()>5) {
                 String value = (String)tok.get(4);
                 for (int ii=5; ii<tok.size(); ii++)
                     value = value + " " + (String)tok.get(ii);
                 global.addToHistoryAndToDebugger(command);
                 accessServer.broadcastSetPortParameter
                     ( (String) tok.get(1), //componentInstanceName
                      (String) tok.get(2), //portInstanceName
                      (String) tok.get(3), //dataFieldName
                      value); //dataFieldValue
             }
        else if (tok.size()==5) {
                 global.addToHistoryAndToDebugger(command);
                 accessServer.broadcastSetPortParameter
                     ( (String) tok.get(1), //componentInstanceName
                      (String) tok.get(2), //portInstanceName
                      (String) tok.get(3), //dataFieldName
                      (String) tok.get(4)); //dataFieldValue
             }
        else if (tok.size()==4) {
                 global.addToHistoryAndToDebugger(command);
                 accessServer.broadcastGetPortParameter
                     ( (String) tok.get(1), //componentInstanceName
                      (String) tok.get(2), //portInstanceName
                      (String) tok.get(3)); //dataFieldValue
              }
        else {
                  global.addToHistoryAndToDebugger(command);
                  accessServer.broadcastMessage(command);
              }

    }





    protected java.util.Vector breakStringIntoWords(String s) {

        /* error check */
        if (s==null) return(null);

        /* store our tokens in this vector */
        java.util.Vector v = new java.util.Vector();

        /* break string into words */
        java.util.StringTokenizer tokenizer = new java.util.StringTokenizer(s);
        while(tokenizer.hasMoreTokens())
            v.add(tokenizer.nextToken());

        /* return our vector of tokens */
        return(v);

    }



    private String handleBoolean(int i){
	ButtonGroup group = (ButtonGroup)dataObjects.get(i);
	String dflt = (String)defaults.get(i);
	String current = group.getSelection().getActionCommand();
	String ret;
	inputGood[i] = true;
	if(current.equals("true"))
	    ret = "true";
	else if(current.equals("false"))
	    ret = "false";
	else{
	    errorsString += "No value for boolean at index " + i + ".\n";
	    ret = dflt;
	    inputGood[i] = false;
	    allInputGood = false;
	}
	return ret;
    }
    private final int INT_VALUE = 0;
    private final int LONG_VALUE = 1;
    private final int FLOAT_VALUE = 2;
    private final int DOUBLE_VALUE = 3;
    private double testRange(int i, int type){
	JTextField field = (JTextField)dataObjects.get(i);
	String info = (String)defaults.get(i);
	double numberTester = 0;
	try{numberTester = Double.parseDouble(field.getText());}
	catch(NumberFormatException e){
	    errorsString +=
		"Value at index " + i + " is not a valid number.\n";
	    inputGood[i] = false;
	    allInputGood = false;
	    return 0;
	}
	double current = 0;
	String typeString = "";
	switch(type){
	case INT_VALUE:
	    typeString = "Integer";
	    try{current = (double)Integer.parseInt(field.getText());}
	    catch(NumberFormatException e){
		errorsString +=
		    "Number at index " + i + " is not an integer.\n";
		inputGood[i] = false;
		allInputGood = false;
		return 0;
	    }
	    break;
	case LONG_VALUE:
	    typeString = "Long";
	    try{current = (double)Long.parseLong(field.getText());}
	    catch(NumberFormatException e){
		errorsString +=
		    "Number at index " + i + " is not a long.\n";
		inputGood[i] = false;
		allInputGood = false;
		return 0;
	    }
	    break;
	case FLOAT_VALUE:
	    typeString = "Float";
	    try{current = (double)Float.parseFloat(field.getText());}
	    catch(NumberFormatException e){
		errorsString +=
		    "Number at index " + i + " is not a float.\n";
		inputGood[i] = false;
		allInputGood = false;
		return 0;
	    }
	    break;
	case DOUBLE_VALUE:
	    typeString = "Double";
	    try{current = Double.parseDouble(field.getText());}
	    catch(NumberFormatException e){
		errorsString +=
		    "Number at index " + i + " is not a double.\n";
		inputGood[i] = false;
		allInputGood = false;
		return 0;
	    }
	    break;
	default:
	    errorsString +=
		"Programmer error at index " + i + ".\n";
	    inputGood[i] = false;
	    allInputGood = false;
	    break;
	}
	StringTokenizer tokens = new StringTokenizer(info,":");
	double dflt = 0;
	double low = 0;
	double high = 0;
	try{
	    dflt = Double.parseDouble(tokens.nextToken());
	    low  = Double.parseDouble(tokens.nextToken());
	    high = Double.parseDouble(tokens.nextToken());
	}catch(NumberFormatException e){
	    System.err.println("Failed to read range for index " + i + ".");
	}
	inputGood[i] = true;
	if(current >= low && current <= high)
	    return current;
	else{
	    errorsString +=
		typeString + " at index " + i + " is out of range.\n";
	    inputGood[i] = false;
	    allInputGood = false;
	    return dflt;
	}
    }

    private String handleString(int i){
	String dflt = (String)defaults.get(i);
	String current = "";
	if(dataObjects.get(i) instanceof JComboBox){
	    JComboBox comboBox = (JComboBox)dataObjects.get(i);
	    current = (String)comboBox.getSelectedItem();
	}else{
	    JTextField textField = (JTextField)dataObjects.get(i);
	    current = textField.getText();
	}
	inputGood[i] = true;
	if(current.length() == 0){
	    errorsString += "String at index " + i + " is empty.\n";
	    inputGood[i] = false;
	    allInputGood = false;
	    return dflt;
	}
	return current;
    }


    private void pn(String s){
	//System.err.println(s);
    }
    private class ErrorDialog extends JDialog{
	private JTextArea errorsTextArea;
	private Dialog owner;
	private boolean useButton = false;
	public ErrorDialog(Dialog owner){
	    super(owner,"Parameter Errors");
	    this.owner = owner;
	    initialize();
	}
	private void initialize(){
	    setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
	    errorsTextArea = new JTextArea();
	    errorsTextArea.setMargin(new Insets(10,10,10,10));
	    errorsTextArea.setEditable(false);
	    getContentPane().add(errorsTextArea);

        }
	public void show(String errors){
	    errorsTextArea.setText(errors);
	    errorsTextArea.setSize(errorsTextArea.getPreferredSize());
	    if(isVisible()==false){
		setLocation
		    (owner.getWidth()+5,
		     getInsets().top +5);
		setVisible(true);
	    }
	    setSize(getPreferredSize());
	}
    }


    private boolean[] inputGood;
    private boolean allInputGood;
    private String errorsString;
    private ErrorDialog errorDialog;

    private GlobalData              global;
    private ComponentInstance parentComponent;

    private Container      content;
    private JTabbedPane tabbedPane;

    private String component;
    private String port;

    private Vector names;
    private Vector types;
    private Vector dataObjects;
    private Vector dataFields;
    private Vector defaults;
    private Vector tabs;

    private final Border normalBorder = BorderFactory.createCompoundBorder
			 (BorderFactory.createLineBorder(Color.gray),
			  BorderFactory.createEmptyBorder(10,10,10,10));
    private final Border flaggedBorder = BorderFactory.createCompoundBorder
			 (BorderFactory.createLineBorder(Color.red),
			  BorderFactory.createEmptyBorder(10,10,10,10));
}
