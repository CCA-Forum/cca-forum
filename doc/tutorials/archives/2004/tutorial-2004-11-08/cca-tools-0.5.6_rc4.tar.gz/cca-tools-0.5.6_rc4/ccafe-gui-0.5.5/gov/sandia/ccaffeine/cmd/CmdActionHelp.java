package gov.sandia.ccaffeine.cmd;

import java.util.*;
import java.io.*;

/** Default standard Help command for all parsers. */
public class CmdActionHelp implements CmdAction {

  public CmdActionHelp() {
	// nothing to initialize
  }

  /** List all the names in na[] to cc.pn() */
  private void writeCmdNames(CmdContext cc, String [] na) {
    int i;
    for (i=0; i < na.length; i++) {
      cc.pn(na[i]+" -- ");
    }
  }

  /** List the arguments enumerated in argtype to cc.pn() */
  private void writeArgDesc(CmdContext cc, String argtype) {

    if (argtype.length() == 0) {
      return;
    }

    cc.p("    arguments: ");

    for (int i = 0; i < argtype.length(); i++) {
      char ch = argtype.charAt(i);
      switch (ch) 
      {
        case 'K':
          cc.p("<long value> ");
          break;
        case 'k':
          cc.p("[long value] ");
          break;
        case 'D':
          cc.p("<int value> ");
          break;
        case 'd':
          cc.p("[int value] ");
          break;
        case 'B':
          cc.p("<boolean value> ");
          break;
        case 'n':
          cc.p("[boolean value] ");
          break;
        case 'G':
          cc.p("<double value> ");
          break;
        case 'g':
          cc.p("[double value] ");
          break;
        case 'C':
          cc.p("<class> ");
          break;
        case 'c':
          cc.p("[class] ");
          break;
        case 'I':
          cc.p("<instance> ");
          break;
        case 'i':
          cc.p("[instance] ");
          break;
        case 'S':
          cc.p("<string token> ");
          break;
        case 's':
          cc.p("[string token] ");
          break;
        case 'L':
          // cc.p("@list of CmdActions in the parser@ ");
          break;
        case 'P':
          // cc.p("@the parser itself@ ");
          break;
        case 'A':
          cc.pn("[remainder of line as a single string]");
          return;
        case 'a':
          cc.pn("[remainder of line as a single string]");
          return;
        case '*':
          cc.pn("[0 or args like previous]");
          return;
        default:
          break;
      }
    }
    cc.pn("");

  }

  /** Display help on command if given or all commands if none specified. */
  public void doIt(CmdContext cc, Vector args) {

    if (args.size() == 3) {

      CmdParse p = (CmdParse)args.get(1);
      String s = (String)args.get(2);

      CmdAction c;
      c = p.getAction(s); // getAction errors are handled internally.

      if (c != null) {
        writeCmdNames(cc, c.names());
        writeArgDesc(cc, c.argtype());
        cc.pn("    "+c.help());
      } 

    } else {

      int j,i;
      Vector alist = (Vector)args.get(0);
      for (j=0; j < alist.size(); j++) {
        CmdAction c = (CmdAction)alist.get(j);
        writeCmdNames(cc, c.names());
        writeArgDesc(cc, c.argtype());
        cc.pn("    "+c.help());
      }

    }
  }
  
  public String help() {
    return "prints the help of one or all commands";
  }

  public String argtype() {
    return "LPs";
  }

  public String[] names() {
    return namelist;
  }

  private static final String[] namelist = {"?","help"};
    
}
