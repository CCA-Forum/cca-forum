package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Is used to notify entities
 * that a component is to be removed
 * or has already been removed.
 * <p>
 * Whenever the cca server removes an 
 * instantiation of a cca component, 
 * a RemoveEvent is sent to the GUI.
 * The GUI might respond by removing
 * the component from the arena.
 * <p>
 * Whenever the GUI wants to remove
 * a component from the arena, the
 * GUI sends a RemoveEvent to the view.
 * The view might respond by sending
 * a message to the cca server.
 * <p>
 * Possible Scenario <br>
 * The end-user highlights a cca component and clicks on the remove button <br>
 * The GUI sends a RemoveEvent to the view.  <br>
 * The view sends a message to the cca server <br>
 * The cca server removes the instantiation of the component. <br>
 * The cca server sends a message to the controller. <br>
 * The controller sends a RemoveEvent to the GUI <br>
 * The GUI removes the component from the arena <br>
 */

public class RemoveEvent extends EventObject {

    /*
     * The number of arguments in the "remove" command.
     */
    protected int numberOfArguments = 0;


    /**
     * Retrieve the number of arguments
     * in the "remove" command.
     * @return The number of arguments
     * in the "remove" command.
     */
    public int getNumberOfArguments() {
        return(this.numberOfArguments);
    }


  /**
   * The name of the component that has been, or will be, removed.
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "StartComponent0"
   */
    protected String componentInstanceName = null;

  /**
   * Get the name of the component that has been, or will be, removed.
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "StartComponent0"
   */
    public String getComponentInstanceName() {
        return(this.componentInstanceName);
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Create a RemoveEvent.
     * <p>
     * Is used to notify entities
     * that a component is to be removed
     * or has already been removed.
     * @param source The entity that created this event.
     * @param componentInstanceName
     * The name of the component that has been, or will be, removed.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    public RemoveEvent
           (Object source,
            String componentInstanceName) {

         super(source);
         this.numberOfArguments = 1;
         this.componentInstanceName = componentInstanceName;
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Create a RemoveEvent.
     * <p>
     * Is used to notify entities
     * that a component is to be removed
     * or has already been removed.
     * @param source The entity that created this event.
     * @param numberOfArguments The number of arguments
     * in the "remove" command.
     * @param componentInstanceName
     * The name of the component that was removed.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    public RemoveEvent
           (Object source,
            int numberOfArguments,
            String componentInstanceName) {

         super(source);
         this.numberOfArguments = numberOfArguments;
         this.componentInstanceName = componentInstanceName;
    }




}