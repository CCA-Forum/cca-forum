package gov.sandia.ccaffeine.dc.user_iface.gui;
import java.awt.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.*;
import gov.sandia.ccaffeine.util.*;
import gov.sandia.ccaffeine.dc.distributed.*;

class CcaffeineGUITestWidget extends JInternalFrame 
  implements Runnable, CcaffeineGUIWidget {
  String msg = "Hello Ccaffeine World";
  public CcaffeineGUITestWidget(){
    super("CcaffeineGUITestWidget", true, true, true, true);
  }
  public void run() {
    while(true) {
      System.sleep(1);
      System.out.println("still here ...");
    }
  }
  public void setArgs(String[] sv) {
    if(sv.length > 1) {
      msg = sv[1];
    }
    JPanel p = new JPanel(new BorderLayout());
    p.add(new JButton(msg), BorderLayout.CENTER);
    getContentPane().add(p);
    setSize(300, 300);
    setLocation(0,0);
  }
}
