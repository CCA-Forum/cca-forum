package gov.sandia.ccaffeine.dc.user_iface.applet;

import javax.swing.JPanel;
import java.awt.*;

/**
Display a message on the screen
 */

public class JPanelMessage extends JPanel {

  String message;

  public JPanelMessage(String message) {
      setBackground(Color.white);
      this.message = message;
  }


  public void paintComponent(Graphics g) {
      super.paintComponent(g);
      g.setFont(new Font("Dialog",Font.PLAIN,24));
      g.drawString(message,0,25);
  }



}