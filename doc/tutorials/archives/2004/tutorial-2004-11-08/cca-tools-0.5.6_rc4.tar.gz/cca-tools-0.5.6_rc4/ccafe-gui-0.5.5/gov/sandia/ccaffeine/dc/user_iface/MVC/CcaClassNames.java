package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CcaClassNames {

    public String classNames[] = new String[0];

    /**
     * Parse the xml contents to retrieved all &lt;className&gt;.
     * The parsed values are copied into the classNames attribute.
     * <p>
     * The XML code will contains something like this: <br>
     * &nbsp;&nbsp;&lt;classNames&gt;
     * &nbsp;&nbsp;&nbsp;&nbsp;&lt;className&gt;name1&lt;/className&gt;
     * &nbsp;&nbsp;&nbsp;&nbsp;&lt;className&gt;name2&lt;/className&gt;
     * &nbsp;&nbsp;&nbsp;&nbsp;&lt;className&gt;nam33&lt;/className&gt;
     * &nbsp;&nbsp;&lt;/classNamess&gt;
     */
     public CcaClassNames(String xmlClassNames) {

        /* We will store our extracted class names here */
        java.util.Vector vector = new java.util.Vector();

        /*
         * Extract out the contents of one or more class names
         */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<className>(.*?)</className>");
        java.util.regex.Matcher matcher =
                pattern.matcher(xmlClassNames);


        /* extract the ports and store them in our vector */
        while (matcher.find()) {
            vector.add(matcher.group(1));
        }

        /* how many paths did we extract from the xml file? */
        int numberOfPaths = vector.size();


        /* copy the vector into the classNames array */
        this.classNames = new String[numberOfPaths];
        vector.copyInto(classNames);

     }
}