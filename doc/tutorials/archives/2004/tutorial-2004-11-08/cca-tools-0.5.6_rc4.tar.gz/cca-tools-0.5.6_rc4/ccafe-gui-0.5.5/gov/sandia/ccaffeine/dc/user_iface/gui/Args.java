package gov.sandia.ccaffeine.dc.user_iface.gui;
import gov.sandia.ccaffeine.util.LocalSystem;
import gnu.getopt.*;
import java.util.*;
import java.io.*;


/** Simple argument class for the Builders.  Not all arguments make
    sense in all contexts. */
public class Args {

  public static final int DEFAULTBUILDERPORT = 2024;
  /** Port for the BuilderClient to connect to. */
  public int builderPort = DEFAULTBUILDERPORT;
  /** Remote host for connecting.  */
  public String hostName = "localhost";
  /** A previously saved .bld file that will be loaded at start-up.
      Null indicates there is no initial file.*/
  public String fileName = null;
  /** String that indicates the 0th argument of the command line (not
      provided by Java) */
  public String argv0 = "argv[0]";
  public boolean serverIsPython = false;
  /** double that indicates the scaling for the font in the GUI.      
   */
  public double scaleFont = 1.0;

  public Args() {
  }
  public Args(String argv0) {
    this.argv0 = argv0;
  }
  /** Create an Args with the String array argument; parseArgs does
      not need to be called */
  public Args(String argv0, String[] s) {
    this.argv0 = argv0;
    parseArgs(s);
  }
  public void parseArgs(String[] args) {
    String usage = argv0+
      " [--builderPort <port number>]"+
      " [--host <hostName>]"+
      " [--file <.bld file> ]"+
      " [--scaleFont <font scale factor>" +
"\n"+
"  --builderPort <port number>\n"+
"         Port on which GUI will connect, default is 2024.\n"+
"\n"+
"  --host <hostName>\n"+
"         Host to which GUI will connect, default is localhost.\n"+
"\n"+
"  --file <.bld file> \n"+
"         GUI compatible .bld file to read in at startup.\n"+
"\n"+
"  --scaleFont <font scale factor>\n" +
"              increase (>1.0) decrease (<1.0) font size.\n"+
"\n";

    StringBuffer sb = new StringBuffer();
    LongOpt[] longopts = new LongOpt[4];
    longopts[0] = new LongOpt("builderPort", LongOpt.REQUIRED_ARGUMENT, sb,
			      'u');
    longopts[1] = new LongOpt("hostName", LongOpt.REQUIRED_ARGUMENT, sb,
			      'h');
    longopts[2] = new LongOpt("file", LongOpt.REQUIRED_ARGUMENT, sb,
			      'f');
    longopts[3] = new LongOpt("pythonServer", LongOpt.NO_ARGUMENT, sb,
			      'p');
    longopts[3] = new LongOpt("scaleFont", LongOpt.REQUIRED_ARGUMENT, sb,
			      's');

    Getopt g = new Getopt(argv0, args, "n:f:t:", longopts);
    String theOption;
    int c;
    while((c = g.getopt()) != -1) {
      switch(c) {
      case 'u':
	theOption = "builderPort";
	break;
      case 'f':
	theOption = "file";
	break;
      case 'h':
	theOption = "hostName";
	break;
      case 'p':
	theOption = "pythonServer";
	break;
      case 's':
	theOption = "scaleFont";
	break;
      default:
      case '?':
	LocalSystem.err.println(usage);
	return;
      case 0:
	theOption = longopts[g.getLongind()].getName();
	break;
      }
      if(theOption == "builderPort") {
	builderPort = Integer.parseInt(g.getOptarg());
      } else if(theOption == "hostName") {
        hostName = g.getOptarg();
      } else if(theOption == "file") {
        fileName = g.getOptarg();
      } else if(theOption == "pythonServer") {
        this.serverIsPython = true;
      } else if(theOption == "scaleFont") {
	scaleFont = Double.parseDouble(g.getOptarg());
      } else {
	LocalSystem.err.println("Bad Option: "+theOption);
	LocalSystem.err.println(usage);
	return;
      }
    }
  }
}

