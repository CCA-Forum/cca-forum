package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Can be used to notify components that
 * an entity wants to launch the application.
 * A view entity might
 * respond by launching the application
 * <p>
 * Possible Scenario <br>
 * The end-user presses the RUN button <br>
 * The client responds by launching the applicaction <br>
 */

public class GoEvent extends EventObject {

    /*
     * Number of arguments in the go command
     */
    protected int numberOfArguments = 0;


    /*
     * Retrieve the number of arguments
     * in the go command.
     */
    public int getNumberOfArguments() {
        return(this.numberOfArguments);
    }


    /*
     * Tto call "go" on a specific
     * component, pass in the
     * name of the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     */
    protected String componentInstanceName = null;


    /*
     * If "go" is being invoked on a specific
     * component then retrieve the name
     * of the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     */
    public String getComponentInstanceName() {
      return(this.componentInstanceName);
    }


    /*
     * To call "go" on a specific
     * "go" port on a specific component,
     * pass in the
     * name of the "go" port.
     */
    protected String portInstanceName = null;



    /*
     * If "go" is being invoked on a specific "go"
     * port of specifi component then retrieve the name
     * of the "go" port.
     */
    public String getPortInstanceName() {
      return(this.portInstanceName);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Create a GoEvent.
     * <p>
     * This event can be used to notify components that
     * an entity wants to launch the application.
     * A view entity might
     * respond by launching the application
     * @param source The entity that created this event.
     */
    public GoEvent
           (Object source) {

         super(source);
         this.numberOfArguments = 0;
         this.componentInstanceName = null;
         this.portInstanceName = null;
    }


    /**
     * Create a GoEvent.
     * <p>
     * This event can be used to notify components that
     * an entity wants to launch the application.
     * A view entity might
     * respond by launching the application
     * @param source The entity that created this event.
     * @param numberOfArguments the number of
     * arguments in the "go" command.
     */
    public GoEvent
           (Object source,
            int numberOfArguments) {

         super(source);
         this.numberOfArguments = numberOfArguments;
         this.componentInstanceName = null;
         this.portInstanceName = null;
    }



    /**
     * Create a GoEvent.
     * <p>
     * This event can be used to notify components that
     * an entity wants to launch the application.
     * A view entity might
     * respond by launching the application
     * @param source The entity that created this event.
     * @param componentInstanceName
     * To call "go" on a specific
     * component, pass in the
     * name of the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0".
     * Can be null.
     */
    public GoEvent
           (Object source,
            String componentInstanceName) {

         super(source);
         this.numberOfArguments = 1;
         this.componentInstanceName = componentInstanceName;
         this.portInstanceName = null;
    }


    /**
     * Create a GoEvent.
     * <p>
     * This event can be used to notify components that
     * an entity wants to launch the application.
     * A view entity might
     * respond by launching the application
     * @param source The entity that created this event.
     * @param numberOfArguments the number of
     * arguments in the "go" command.
     * @param componentInstanceName
     * To call "go" on a specific
     * component, pass in the
     * name of the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0".
     * Can be null.
     */
    public GoEvent
           (Object source,
            int numberOfArguments,
            String componentInstanceName) {

         super(source);
         this.numberOfArguments = numberOfArguments;
         this.componentInstanceName = componentInstanceName;
         this.portInstanceName = null;
    }


    /**
     * Create a GoEvent.
     * <p>
     * This event can be used to notify components that
     * an entity wants to launch the application.
     * A view entity might
     * respond by launching the application
     * @param source The entity that created this event.
     * @param componentInstanceName
     * To call "go" on a specific
     * component, pass in the
     * name of the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0".
     * Can be null.
     * @param portInstanceName
     * To call "go" on a specific
     * "go" port on a specific component,
     * pass in the
     * name of the "go" port.  Can be null.
     */
    public GoEvent
           (Object source,
            String componentInstanceName,
            String portInstanceName) {

         super(source);
         this.numberOfArguments = 2;
         this.componentInstanceName = componentInstanceName;
         this.portInstanceName = portInstanceName;
    }


    /**
     * Create a GoEvent.
     * <p>
     * This event can be used to notify components that
     * an entity wants to launch the application.
     * A view entity might
     * respond by launching the application
     * @param source The entity that created this event.
     * @param numberOfArguments the number of
     * arguments in the "go" command.
     * @param componentInstanceName
     * To call "go" on a specific
     * component, pass in the
     * name of the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0".
     * Can be null.
     * @param portInstanceName
     * To call "go" on a specific
     * "go" port on a specific component,
     * pass in the
     * name of the "go" port.  Can be null.
     */
    public GoEvent
           (Object source,
            int numberOfArguments,
            String componentInstanceName,
            String portInstanceName) {

         super(source);
         this.numberOfArguments = numberOfArguments;
         this.componentInstanceName = componentInstanceName;
         this.portInstanceName = portInstanceName;
    }


}