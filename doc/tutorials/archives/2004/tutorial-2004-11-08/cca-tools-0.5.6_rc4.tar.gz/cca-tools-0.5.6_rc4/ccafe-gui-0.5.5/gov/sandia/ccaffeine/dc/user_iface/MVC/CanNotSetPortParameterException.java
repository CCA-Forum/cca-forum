package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotSetPortParameterException extends Exception {

  public CanNotSetPortParameterException() {
      super();
  }

  public CanNotSetPortParameterException(String message) {
      super(message);
  }


}