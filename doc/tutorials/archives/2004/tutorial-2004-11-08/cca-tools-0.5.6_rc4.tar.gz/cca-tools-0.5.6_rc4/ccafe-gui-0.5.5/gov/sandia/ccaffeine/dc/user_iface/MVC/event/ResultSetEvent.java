package gov.sandia.ccaffeine.dc.user_iface.MVC.event;


import java.util.EventObject;

/**
 * Used to return the result of a
 * QueryEvent.
 */

public class ResultSetEvent extends java.util.EventObject {

    /* The result set */
    Object resultSet[] = null;

    /**
     * Retrieve the result set.
     * @return The result set.
     */
    public Object[] getResultSet() {
        return(this.resultSet);
    }



    /**
     * Return the result of a
     * QueryEvent.
     * @param The entity that created this event.
     * @param resultSet The result set.
     */
    public ResultSetEvent
           (Object source,
            Object resultSet[]) {

         super(source);
         this.resultSet = resultSet;
    }

}