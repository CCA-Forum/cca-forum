// Decompiled by Jad v1.5.6f. Copyright 1997-99 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/SiliconValley/Bridge/8617/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AWTConsole.java

package gov.sandia.ccaffeine.dc.user_iface;


import java.awt.*;
import java.awt.event.*;
import java.awt.peer.TextComponentPeer;
import java.io.*;
import java.util.Vector;
import gov.sandia.ccaffeine.util.LocalSystem;

/** Adapted from the bsh package AWTConsole. */
public class AWTConsole extends TextArea
  implements Console, Runnable, KeyListener
{

  public AWTConsole()
    {
      this(12, 80, null, null);
    }

  public AWTConsole(int i, int j, InputStream inputstream, OutputStream outputstream)
    {
      super(i, j);
      line = new StringBuffer();
      textLength = 0;
      history = new Vector();
      histLine = 0;
      setFont(new Font("Monospaced", 0, 14));
      setEditable(false);
      addKeyListener(this);
      outPipe = outputstream;
      if(outPipe == null)
        {
	  outPipe = new PipedOutputStream();
	  try
            {
	      in = new PipedInputStream((PipedOutputStream)outPipe);
            }
	  catch(IOException _ex)
            {
	      print("Console internal error...");
            }
        }
      inPipe = inputstream;
      if(inPipe == null) {
	PipedOutputStream pipedoutputstream = new PipedOutputStream();
	out = pipedoutputstream;
	try {
	  inPipe = new PipedInputStream(pipedoutputstream);
	} catch(Exception e) {
	  e.printStackTrace(System.err);
	}
      }
      (new Thread(this)).start();
      requestFocus();
    }

  public AWTConsole(InputStream inputstream, OutputStream outputstream)
    {
      this(12, 80, inputstream, outputstream);
    }

  public AWTConsole(int height, int width) {
    this(height, width, null, null);
  }

  private void acceptLine(String s)
    {
      if(outPipe == null)
	print("Console internal error...");
      else
	try
	  {
	    outPipe.write(s.getBytes());
	    outPipe.flush();
	  }
      catch(IOException _ex)
	{
	  outPipe = null;
	  throw new RuntimeException("Console pipe broken...");
	}
    }

  private int countNLs()
    {
      String s = getText();
      int i = 0;
      for(int j = 0; j < s.length(); j++)
	if(s.charAt(j) == '\n')
	  i++;

      return i;
    }

  private void doChar(char c)
    {
      if(c >= ' ' && c <= '~')
        {
	  line.append(c);
	  append(String.valueOf(c));
	  textLength++;
        }
    }

  private void enter()
    {
      String s;
      if(line.length() == 0)
        {
	  s = ";\n";
        }
      else
        {
	  s = String.valueOf(line) + "\n";
	  history.addElement(line.toString());
        }
      line.setLength(0);
      histLine = 0;
      append("\n");
      textLength = getText().length();
      acceptLine(s);
      setCaretPosition(textLength);
    }

  public OutputStream getErrorStream()
    {
      return out;
    }

  public InputStream getInputStream()
    {
      return in;
    }

  public OutputStream getOutputStream()
    {
      return out;
    }

  private void historyDown()
    {
      if(histLine == 0)
        {
	  return;
        }
      else
        {
	  histLine--;
	  showHistoryLine();
	  return;
        }
    }

  private void historyUp()
    {
      if(history.size() == 0)
	return;
      if(histLine == 0)
	startedLine = line.toString();
      if(histLine < history.size())
        {
	  histLine++;
	  showHistoryLine();
        }
    }

  private void inPipeWatcher()
    throws IOException
    {
      byte abyte0[] = new byte[256];
      int i;
      while((i = inPipe.read(abyte0)) != -1) {
	String s;
	print(s = new String(abyte0, 0, i));
      }

      println("Console: Input closed...");
    }

  public void keyPressed(KeyEvent keyevent)
    {
      type(keyevent.getKeyCode(), keyevent.getKeyChar(), keyevent.getModifiers());
      keyevent.consume();
    }

  public void keyReleased(KeyEvent keyevent)
    {
    }

  public void keyTyped(KeyEvent keyevent)
    {
    }

  public static void main(String args[])
    {
      AWTConsole awtconsole = new AWTConsole();
      final Frame f = new Frame("CCA Reference Implementation");
      f.add(awtconsole, "Center");
      f.pack();
      f.show();
      f.addWindowListener(new WindowAdapter() {

	public void windowClosing(WindowEvent windowevent)
	  {
	    f.dispose();
	  }

      });
    }

  public synchronized void print(String s)
    {
      append(s);
      textLength = getText().length();
    }

  public void println(String s)
    {
      print(s + "\n");
    }

  public void run()
    {
      try
        {
	  inPipeWatcher();
        }
      catch(IOException _ex)
        {
	  println("Console: I/O Error...");
        }
    }

  public void setCaretPosition(int i)
    {
      ((TextComponentPeer)getPeer()).setCaretPosition(i + countNLs());
    }

  private void showHistoryLine()
    {
      String s;
      if(histLine == 0)
	s = startedLine;
      else
	s = (String)history.elementAt(history.size() - histLine);
      replaceRange(s, textLength - line.length(), textLength);
      line = new StringBuffer(s);
      textLength = getText().length();
    }

  public String toString()
    {
      return "BeanShell AWTConsole";
    }

  public void type(int i, char c, int j)
    {
      pn("i = "+i+" j = "+j);
      switch(i)
        {
        case 8: /* '\b' */
	  if(line.length() > 0)
            {
	      line.setLength(line.length() - 1);
	      replaceRange("", textLength - 1, textLength);
	      textLength--;
            }
	  break;

        case 10: /* '\n' */
	  enter();
	  break;

        case 85: /* 'U' */
	  if((j & 0x2) > 0)
            {
	      int k = line.length();
	      replaceRange("", textLength - k, textLength);
	      line.setLength(0);
	      histLine = 0;
	      textLength = getText().length();
            }
	  else
            {
	      doChar(c);
            }
	  break;

        case 38: /* '&' */
	  historyUp();
	  break;

        case 40: /* '(' */
	  historyDown();
	  break;

        case 9: /* '\t' */
	  line.append("    ");
	  append("    ");
	  textLength += 4;
	  break;

        case 67: /* 'C' */
	  if((j & 0x2) > 0)
            {
	      copiedText = getSelectedText();
            }
	  else
            {
	      doChar(c);
            }
	  break;
        case 86: /* 'V' */
	  if((j & 0x2) > 0)
            {
	      append(copiedText);
	      textLength += copiedText.length();
	      line.append(copiedText);
	      setCaretPosition(textLength);
            }
	  else
            {
	      doChar(c);
            }
	  break;
	case 116: /*f5*/
	  if(j == 0) {
	    copiedText = getSelectedText();  
	  }else{
	    doChar(c);
	  }
	  break;
	case 117: /*f6*/
	  if(j == 0) {
	    append(copiedText);
	    textLength += copiedText.length();
	    line.append(copiedText);
	    setCaretPosition(textLength);
	  }else{
	    doChar(c);
	  }
	  break;
        default:
	  doChar(c);
	  break;

        }
    }
  public void pn(String s) {
    if(LocalSystem.debug) {
      println(s);
    }
  }

  private String copiedText;
  private OutputStream outPipe;
  private InputStream inPipe;
  private InputStream in;
  private PipedOutputStream out;
  private StringBuffer line;
  private String startedLine;
  private int textLength;
  private Vector history;
  private int histLine;
}
