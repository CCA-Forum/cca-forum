package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotSetPathToCcaComponentsException extends Exception {

    public CanNotSetPathToCcaComponentsException() {
        super();
    }


    public CanNotSetPathToCcaComponentsException(String message) {
        super(message);
    }

}