package gov.sandia.ccaffeine.util;

import java.applet.*;
import java.io.*;
import java.net.*;

/** Only useful for creating Applets out of Java Applications, if
    LocalSystem is used instead of System for IO, then the console
    will be tied off to LocalSystem and Applets will not get a
    security exception if IO is used. Defaults to System values for
    non-applet applications. 
  @see IO.h in c++ implementation. */
public class LocalSystem {

  public static boolean debug = false;
  public static PrintStream out = System.out;
  public static PrintStream err = System.err;
  public static InputStream in = System.in;
  private static boolean appletness = false;
  private static Applet myApplet = null;
  private static URL myBaseURL = null;
  private static String gadgetInputFileLocation = null;
  private static String myGadgetInFileLocation = null;

  public static void setDebug(boolean tf) {
    debug = tf;
  }
  public static void setErr(PrintStream ps) {
    err = ps;
  }
  public static void setOut(PrintStream ps) {
    out = ps;
  }
  public static void setIn(InputStream ps) {
    in = ps;
  }
  public static boolean isApplet() { return appletness; }
  public static void setApplet(Applet myAppletx) {
    appletness = true;
    myApplet = myAppletx;
  }
  public static Applet getApplet() {return myApplet;}
  public static void printException(Exception e) {
    err.println("Exception: "+e);
    e.printStackTrace(err);
  }
  /** Can be replaced with a more benign, applet friendly, exit if desired. */
  public static void exit(int status) {
    Runtime.getRuntime().exit(status);
  }

  public static void setCodeBaseURL(URL base) {
      myBaseURL = base;
  }

  public static URL getCodeBaseURL() {return myBaseURL;}

}
