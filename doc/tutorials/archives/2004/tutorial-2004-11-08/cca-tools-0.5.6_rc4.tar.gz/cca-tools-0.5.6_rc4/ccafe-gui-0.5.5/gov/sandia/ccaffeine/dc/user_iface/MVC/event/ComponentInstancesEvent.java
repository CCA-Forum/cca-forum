package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaComponent;

/**
 * used to transfer components from one entity to another entity
 */

public class ComponentInstancesEvent extends java.util.EventObject {

    /**
     * Get the components
     */
    protected CcaComponent ccaComponents[] = null;

    /**
     * get the components
     * @return The retrieved components
     */
     public CcaComponent[] getComponents() {
         return(this.ccaComponents);
     }

    /**
     * set the components
     * @param ccaComponents The components
     */
     public void setComponents(CcaComponent ccaComponents[]) {
         this.ccaComponents = ccaComponents;
     }


     /**
      * Create a ComponentInstanceEvent.
      * @param source The entity that originated this event.
      */
     public ComponentInstancesEvent(Object source) {
         super(source);
         this.ccaComponents = null;
     }


     /**
      * Create a ComponentInstanceEvent.
      * @param source The entity that originated this event.
      * @param ccaComponents the components
      */
     public ComponentInstancesEvent
            (Object source,
             CcaComponent ccaComponents[]) {
         super(source);
         this.ccaComponents = ccaComponents;
     }


}