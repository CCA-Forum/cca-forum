package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;

public class CmdActionCCAArena
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCAArena() {
  }


  public String argtype() {
    return "";
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
    return "show what instances are in the arena currently.";
  }


  private static final String[] namelist = {"arena","instances"};


  public void doIt(CmdContext cc, Vector args) {

    //CmdContextCCA cca = (CmdContextCCA)cc;
    //cca.bv.displayInstantiatedComponents();

    broadcastGetAllInstancesInArena();

  }

}
