package gov.sandia.ccaffeine.dc.user_iface.gui;
import java.awt.*;

/**
 * This class represents a link between two <code>ComponentInstance</code>s.
 * It holds data fields representing: the source
 * <code>ComponentInstance</code>, the target <code>ComponentInstance
 * </code>, and the <code>Port</code>s on each which are connected.
 */
public class Connection{

    /**
     * Creates an instance of <code>Connection</code>. The
     * <code>Connection</code> connects the specified souceport
     * on the specified source to the specified targetport on the
     * specified target. The refearence to <code>Builder</code>
     * provides access to global variables.
     *
     */

    public Connection(ComponentInstance src, Port srcPort,
		      ComponentInstance trg, Port trgPort, 
		      GlobalData global) {
	this.global = global;

	source     = src;
	sourcePort = srcPort;
	target     = trg;
	targetPort = trgPort;

	initialize();
	setPoints();
    }
    private void initialize(){
	arena   = global.getArena();
	builder = global.getBuilder();
    }
 
  public boolean equals(Object cobj) {
    if(!(cobj instanceof Connection)) {
      return false;
    }
    Connection c = (Connection)cobj;
    if(!(source.getInstanceName().equals(c.getSource().getInstanceName()))) {
      return false;
    }
    if(!(sourcePort.getInstanceName().equals(c.getSourcePort().getInstanceName()))) {
      return false;
    }
    if(!(target.getInstanceName().equals(c.getTarget().getInstanceName()))) {
      return false;
    }
    if(!(targetPort.getInstanceName().equals(c.getTargetPort().getInstanceName()))) {
      return false;
    }
    return true;
  }
    /**
     * Recreates path to reflect source and target positions.
     * Looks at the positions of the target and source and makes
     * a right-angle path between the two ports. Called by
     * <code>Arena</code> whenever an <code>ComponentInstance</code>
     * is moved.
     */
    public void setPoints(){
	String sourcePortName = sourcePort.getInstanceName();
	String targetPortName = targetPort.getInstanceName();
	sourcePort=source.getPort(sourcePortName);
	targetPort=target.getPort(targetPortName);
	sourcePortID = sourcePort.getLocation().y/sourcePort.getSize().height;
	targetPortID = targetPort.getLocation().y/targetPort.getSize().height;
	sourceWidth = source.getWidth();
	targetWidth = target.getWidth();
	sourceHeight = source.getHeight();
	targetHeight = target.getHeight();
	isValidToDraw = (sourcePort.getWidth() != 0 &&
			 sourcePort.getHeight()!= 0 &&
			 targetPort.getWidth() != 0 &&
			 targetPort.getHeight() != 0);
	sourceLeft   = source.getX();
	targetLeft   = target.getX();
	sourceRight  = sourceLeft + sourceWidth;
	targetRight  = targetLeft + targetWidth;
	sourceTop    = source.getY();
	targetTop    = target.getY();
	sourceBottom = sourceTop  + sourceHeight;
	targetBottom = targetTop  + targetHeight;
	source.repaint();
	target.repaint();

	sourcePortX = sourceRight;	
	sourcePortY = sourceTop
	    + getComponentLocationRelative(sourcePort,source).y
	    + sourcePort.getHeight()/2;
	targetPortX = targetLeft;
	targetPortY = targetTop
	    + getComponentLocationRelative(targetPort,target).y
	    + targetPort.getHeight()/2;

	if(sourceRight + pathBuffer*(source.getOutPortCount() - 1)  <
	   targetLeft - 2*labelBuffer) {
	    xSource = new int[3];
	    ySource = new int[3];
	    xTarget = new int[2];
	    yTarget = new int[2];
	    xSource[0]=sourcePortX;
	    ySource[0]=sourcePortY;
	    xSource[1]=sourceRight + labelBuffer + pathBuffer * sourcePortID;
	    ySource[1]=sourcePortY;
	    xSource[2]=sourceRight + labelBuffer + pathBuffer * sourcePortID;
	    ySource[2]=targetPortY;
	    xTarget[0]=xSource[2];
	    yTarget[0]=ySource[2];
	    xTarget[1]=targetPortX;
	    yTarget[1]=targetPortY;
	} else {
	    determineCrossY();
	    x1 = sourceRight + labelBuffer;
	    x3 = targetLeft  - labelBuffer;
	    xSource = new int[5];
	    ySource = new int[5];
	    xTarget = new int[2];
	    yTarget = new int[2];
	    if(!(enoughBetween)){
		if(targetTop>sourceTop){
		    if(targetRight > sourceRight)
			x1 = targetRight + labelBuffer;
		} else{
		    if(targetLeft  > sourceLeft )
			x3 = sourceLeft  - labelBuffer;
		}
	    }
	    xSource[0]=sourcePortX;
	    ySource[0]=sourcePortY;
	    xSource[1]= x1    + pathBuffer*sourcePortID;
	    ySource[1]=sourcePortY;
	    xSource[2]= x1    + pathBuffer*sourcePortID;
	    ySource[2]=crossY + pathBuffer*sourcePortID;
	    xSource[3]= x3    - pathBuffer*targetPortID;
	    ySource[3]=crossY + pathBuffer*sourcePortID;
	    xSource[4]= x3    - pathBuffer*targetPortID;
	    ySource[4]=targetPortY;
	    xTarget[0]=xSource[4];
	    yTarget[0]=ySource[4];
	    xTarget[1]=targetPortX;
	    yTarget[1]=targetPortY;
        }
    }
    private Point getComponentLocationRelative(Component contained, 
					       Component container) {
	Point p1 = container.getLocationOnScreen();
	Point p2 = contained.getLocationOnScreen();
	return new Point(p2.x - p1.x, p2.y - p1.y);
    }
    private void determineCrossY(){
	//between = pathBuffer*Math.max(target.getInPortCount(),
	//			      source.getOutPortCount())
	//    + 2*labelBuffer;
	between = pathBuffer*source.getOutPortCount()
	    + 2*labelBuffer;
	lowtop = Math.max(sourceTop, targetTop);
	highbottom = Math.min(sourceBottom, targetBottom);
	lowbottom = Math.max(sourceBottom, targetBottom);
	if(highbottom + between < lowtop){
	    crossY = highbottom + labelBuffer;
	    enoughBetween = true;
	} else {
	    crossY = lowbottom + labelBuffer;
	    enoughBetween = false;
	}	    
    }
    public void setValidToDraw(boolean tf) {
	isValidToDraw = tf;
    }
    
    /**
     * Paints a path between the source and the target.
     * Takes the coordinates created by <code>SetPoints()</code> and 
     * connects them with colored lines to create a path. The path is
     * drawn on the <code>Arena</code>'s <code>Graphics</code> object.
     * The path is drawn in blue, except for the line-segment extending
     * from the source-port which is red.
     */
    public void drawPath(Graphics g){
	if(!isValidToDraw) { 
	    // We still don't have valid Java components yet because of 
	    // Swings lazy drawing algorithms.
	    setPoints();
	}
	if(g instanceof Graphics2D) {
	    ((Graphics2D)g).setStroke(new BasicStroke((float)3.));
	}
	g.setColor(Color.red);
	g.drawPolyline(xSource,ySource,xSource.length);
	g.setColor(Color.red);
	g.drawPolyline(xTarget,yTarget,xTarget.length);
	if(g instanceof Graphics2D) {
	    ((Graphics2D)g).setStroke(new BasicStroke((float)1.));
	}
    }
    
    /**
     * Returns the <code>ComponentInstance</code> which is the source
     * of this <code>Connection</code>.
     *
     * @return  an <code>ComponentInstance</code>
     */
    public ComponentInstance getSource(){
	return source;
    }
    /**
     * Returns the <code>ComponentInstance</code> which is the target
     * of this <code>Connection</code>.
     *
     * @return  an <code>ComponentInstance</code>
     */
    public ComponentInstance getTarget(){
	return target;
    }
    /**
     * Returns the <code>Port</code> which is the source-port
     * of this <code>Connection</code>.
     *
     * @return  a <code>Port</code>
     */
    public Port getSourcePort(){
	return sourcePort;
    }
    /**
     * Returns the <code>Port</code> which is the target-port
     * of this <code>Connection</code>.
     *
     * @return  a <code>Port</code>
     */
    public Port getTargetPort(){
	return targetPort;
    }

    private boolean isValidToDraw = false;

    private final int  pathBuffer = 4;
    private final int labelBuffer = 8;
    
    //This group is initialized in constructor
    private GlobalData     global;
    private Builder       builder;
    private Arena           arena;

    private ComponentInstance source;
    private ComponentInstance target;
    private Port          sourcePort;
    private Port          targetPort;

    //This group is initialized on creation
    private int sourcePortID;
    private int targetPortID;

    private int  sourceWidth;
    private int  targetWidth;
    private int sourceHeight;
    private int targetHeight;
    private int  portCenterX;
    private int  portCenterY;

    private Graphics g;

    // This group is used in updating paths' points
    private int sourceLeft;
    private int targetLeft;
    private int sourceRight;
    private int targetRight;
    private int sourceTop;
    private int targetTop;
    private int sourceBottom;
    private int targetBottom;
    private int sourcePortX;
    private int targetPortX;
    private int sourcePortY;
    private int targetPortY;
    private int x1;
    private int x3;
    private int[] xSource;
    private int[] ySource;
    private int[] xTarget;
    private int[] yTarget;

    //This group is used in determining yCross
    private int between;
    private int hightop;
    private int lowtop;
    private int highbottom;
    private int lowbottom;
    private int crossY;
    private boolean enoughBetween;
}
