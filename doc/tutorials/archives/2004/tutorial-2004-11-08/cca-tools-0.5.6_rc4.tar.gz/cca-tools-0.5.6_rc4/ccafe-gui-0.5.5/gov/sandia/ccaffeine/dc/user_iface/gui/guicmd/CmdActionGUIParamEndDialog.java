package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;

/**
 * CmdActionGUIParamEndDialog.java
 *
 * Created: Thu Dec 16 00:31:29 1999
 * @author Colin Potter
 * @version $Id: CmdActionGUIParamEndDialog.java,v 1.1.1.1 2004/09/04 00:41:02 rob Exp $
 *
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * This event can be used to notify components
 * that the cca server has finished sending information
 * for all the data fields in a port.  A client
 * entity might respond by displaying a dialog box
 * that was already populated with information
 * from all the data fields.
 * <p>
 * Possible Scenario: <br>
 * An end-user clicks on a blue port inside of a component <br>
 * client sends "parameters" to server <br>
 * serer- sends "ParamDialog" to client <br>
 * client responds by creating an empty dialog box <br>
 * server sends "ParamTab" to client <br>
 * client responds by inserting a new tab in the dialog box <br>
 * server sends "ParamField" to client <br>
 * client responds by inserting a blank data line into the dialog box <br>
 * server sends "ParamCurrent" to client <br>
 * client responds by inserting the data's value into the dialog box <br>
 * server sends "ParamHelp" to client <br>
 * client responds by setting the text that is displayed if the help button is clicked <br>
 * server sends "ParamPrompt" to client <br>
 * client responds by displaying a prompt to the left of the data's value <br>
 * server sends "ParamDefault" to client <br>
 * client responds by setting the data's default value <br>
 * server sends "ParamStringChoice" to client <br>
 * client responds by setting an item in the value's choice box <br>
 * server sends "ParamNumberRange" to client <br>
 * client responds by setting the data value's range of allowed values <br>
 * server sends  "ParamEndDialog" to client <br>
 * client responds by displaying the dialog box on the screen <br>
 */

public class CmdActionGUIParamEndDialog
       extends CmdActionGUI
       implements CmdAction {

    public CmdActionGUIParamEndDialog() {
    }


    public String argtype(){
	return "IS";
    }

    public String[] names(){
	return namelist;
    }

    public String help(){
	return "informs the ParamDialog that all relevant data has been sent.";
    }

    private static final String[] namelist = {"paramEndDialog"};

    public void doIt(CmdContext cc, Vector args) {


      /*
       * Cca components contain ports.
       * Some of the ports contain data fields.
       * This event can be used to notify components
       * that the cca server has finished sending information
       * for all the data fields in a port.  A client
       * entity might respond by displaying a dialog box
       * that was already populated with information
       * from all the data fields.
       */

	CmdContextGUI ccg = (CmdContextGUI)cc;

       /*
        * The name of the cca component that contains
        * the port which contains the data fields.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = (String)args.get(0);

       /**
        * The instance name of the port.
        * The name is usually the name of the port's class
        * (without the package name).
        *  Example: "configure_port"
        */
        String portInstanceName = (String)args.get(1);

	//String hashKey = componentInstance + ":" + portInstance;

	//ConfigureDialog dialog = global.getConfigureDialog(hashKey);
	//dialog.finishAndShow();

        this.broadcastParamEndDialog
            (componentInstanceName,
             portInstanceName);

    } // doIt


} // CmdActionGUIParamEndDialog
