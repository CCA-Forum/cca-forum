package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

public class ComponentClassNamesEvent extends java.util.EventObject {


    String componentClassNames[] = null;


    /**
     * Get the class names of components.
     * @return The class name of components.
     */
    public String[] getComponentClassName() {
        return(this.componentClassNames);
    }


    /**
     * Set the class name of components.
     * @param componentClassNames The class names of components.
     */
    public void setComponentClassNames(String componentClassNames[]) {
        this.componentClassNames = componentClassNames;
    }



    /**
     * Create a ComponentClassNamesEvent.
     * @param source The entity that created this event.
     */
    public ComponentClassNamesEvent(Object source) {
        super(source);
        this.componentClassNames = null;
    }

    /**
     * Create a ComponentClassNamesEvent.
     * @param source The entity that created this event.
     * @param componentClassNames The class names of components.
     */
    public ComponentClassNamesEvent
           (Object source,
            String componentClassNames[]) {
        super(source);
        this.componentClassNames = componentClassNames;
    }





}