package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotSetDebugFlagException extends Exception {
    public CanNotSetDebugFlagException() {
        super();
    }
    public CanNotSetDebugFlagException(String message) {
        super(message);
    }

}