package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * This event can be used to notify components
 * that an entity wants some information.
 * This event can be used to
 * request the following info: <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;display palette <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;display arena <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;display chain <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;display component <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;display state <br>
 * <p>
 * A view might respond to a "draw palette"
 * by rendering icons in a palette.  The end-user
 * can drag-and-drop icons from the palette
 * to the main workspace (the arena).
 * <p>
 * A view might respond to a "draw arena"
 * by redendering cca components in the main
 * workspace.  An end-user can drag components
 * to different locations, remove components,
 * view or set property values, draw a line between
 * two different components, etc.
 * <p>
 * A view might respond to a "draw chain"
 * by drawing a line between two ports that
 * are inside of two different cca components.
 * A port is usually rendered as a small rectangle
 * inside of a component.
 * <p>
 * A view might respond to a "draw component"
 * by rendering one cca component in the
 * main workspace (the arena).  The end-user can
 * drag the component to a new location,
 * remove the component, draw a line to/from
 * to different component, view or edit
 * the component's properties, etc.
 * <p>
 * A view might respond to a "draw state"
 * by redering components in the main
 * workspace (the arena) and by rendering
 * lines between all of the components
 * that are connected.
 */

public class DisplayEvent extends EventObject {

    /*
     * The number of arguments
     * in the request string.
     */
    protected int numberOfArguments = 0;


    /**
     * Retrieve the number of arguments
     * in the request string.
     * @return The number of arguments
     * in the request string.
     */
    public int getNumberOfArguments() {
        return(numberOfArguments);
    }


    /**
     * One of the entity values
     */
    public static final String PALETTE = "pallet";

    /**
     * One of the entity values
     */
    public static final String ARENA = "arena";

    /**
     * One of the entity values
     */
    public static final String CHAIN = "chain";

    /**
     * One of the entity values
     */
    public static final String COMPONENT = "component";

    /**
     * One of the entity values
     */
    public static final String STATE = "state";


    /*
     * We are requesting info
     * on which entity?  We can
     * request info on the PALETTE,
     * ARENA, CHAIN, COMPONENT,
     * STATE.
     */
    protected String entity = null;


    /*
     * We are requesting info
     * on which entity?  We can
     * request info on the PALETTE,
     * ARENA, CHAIN, COMPONENT,
     * STATE.
     */
     public String getEntity() {
         return (this.entity);
     }

    /*
     * If an entity wants some info on
     * a particular component, then that
     * entity has to supply the name of
     * the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
    */
    protected String componentInstanceName = null;


    /*
     * If an entity wants some info on
     * a particular component, then that
     * entity has to supply the name of
     * the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
    */
    public String getComponentInstanceName() {
        return(this.componentInstanceName);
    }


    /**
     * Create a DisplayEvent.
     * This event can be used to notify components
     * that an entity wants some information.
     * This event can be used to
     * request the following info: <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display palette <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display arena <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display chain <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display component <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display state <br>
     * @param source The entity that created this event.
     * @param entity We are requesting info
     * on which entity?  We can
     * request info on the PALETTE,
     * ARENA, CHAIN, COMPONENT,
     * STATE.
     */
    public DisplayEvent
           (Object source,
            String entity) {

         super(source);
         this.numberOfArguments = 1;
         this.entity = entity;
         this.componentInstanceName = null;
    }


    /**
     * Create a DisplayEvent.
     * This event can be used to notify components
     * that an entity wants some information.
     * This event can be used to
     * request the following info: <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display palette <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display arena <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display chain <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display component <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display state <br>
     * @param source The entity that created this event.
     * @param entity We are requesting info
     * on which entity?  We can
     * request info on the PALETTE,
     * ARENA, CHAIN, COMPONENT,
     * STATE.
     */
    public DisplayEvent
           (Object source,
            int numberOfArguments,
            String entity) {

         super(source);
         this.numberOfArguments = numberOfArguments;
         this.entity = entity;
         this.componentInstanceName = null;
    }


    /**
     * Create a DisplayEvent.
     * This event can be used to notify components
     * that an entity wants some information.
     * This event can be used to
     * request the following info: <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display palette <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display arena <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display chain <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display component <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display state <br>
     * @param source The entity that created this event.
     * @param entity We are requesting info
     * on which entity?  We can
     * request info on the PALETTE,
     * ARENA, CHAIN, COMPONENT,
     * STATE.
     * @param componentInstanceName
     * If an entity wants some info on
     * a particular component, then that
     * entity has to supply the name of
     * the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     * Can be set to null.
     */
    public DisplayEvent
           (Object source,
            int numberOfArguments,
            String entity,
            String componentInstanceName) {

         super(source);
         this.numberOfArguments = numberOfArguments;
         this.entity = entity;
         this.componentInstanceName = componentInstanceName;
    }

}