package gov.sandia.ccaffeine.dc.distributed;

import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;



public class MessageData {
    private String message;
    private String idList;
    private String prefix;
    // used to keep track of which clients have 
    // already sent this message - if they send the same message twice, we 
    // want to detect that and make two distinct copies of the message
    private HashMap clients; 
    public MessageData (String fullMessage, Client client) {
	if (((fullMessage.startsWith(ALERT_BEG)) ||
	     (fullMessage.startsWith(ERROR_BEG)) ||
	     (fullMessage.startsWith(BEG_LIST))) && 
	    (fullMessage.indexOf(END_LIST) > 0)){
	  
	    idList = fullMessage.substring(fullMessage.indexOf(BEG_LIST) + BEG_LIST.length(), fullMessage.indexOf(END_LIST));
	    message = fullMessage.substring(fullMessage.indexOf(END_LIST) + END_LIST.length());
	    prefix = fullMessage.substring(0, fullMessage.indexOf(BEG_LIST) + BEG_LIST.length());
	} else {
	    if (client != null)
		idList = client.getSourceName();
	    else
		idList = "";
	    message = fullMessage;
	    prefix = BEG_LIST;
	}
	clients = new HashMap();
	if (client != null)
	    clients.put(new Integer(client.getId()), client);
    }
    public MessageData (String message, String idList, String prefix, 
		    Client client)
    {
	clients = new HashMap();
	this.message = message;
	this.idList = idList;
	this.prefix = prefix;
	// by this point we are done adding the message, whether it came 
	// from a client directly or through a server&client. Therefore,
	// mark this client done.
	clients.put(new Integer(client.getId()), client);
	
    }
    public int numClients() { return clients.size(); }
    public String getMessage() { return message; }
    public String getIdList() { return idList; }
    public String getPrefix() { return prefix; }
    public String getFormattedMessageString() 
    { 
	return prefix + idList + END_LIST + message;
    }
    public void appendIds(String idList, Client client) { 
	this.idList = this.idList + LIST_SEP + idList; 
	// by this point we are done adding the message, Therefore,
	// mark this client done.
	clients.put(new Integer(client.getId()), client);
    }
    public boolean hasClientData( Client client )
    {
	return (clients.containsKey(new Integer(client.getId())));
    }
    
    public boolean equals (Object obj) {
	MessageData msg = (MessageData) obj;
	return (msg.getMessage().equals(message)) && 
	    (msg.getPrefix().equals(prefix));
    }

    public int hashCode() {
      
	return message.hashCode() + prefix.hashCode();
    }
    public static final String BEG_LIST = "<<";
    public static final String END_LIST = ">>";
    // no client names in the list of client names can contain this string
    // b/c it is used as a separator by the plugins
    public static final String LIST_SEP = ","; 
    public static final String ERROR_TOKEN = "!";
    public static final String SERVER_ALERT_TOKEN = "#";

    public static final String ALERT_BEG = SERVER_ALERT_TOKEN + BEG_LIST;
    public static final String ERROR_BEG = ERROR_TOKEN + BEG_LIST;
    public static String makeOutOfBandMessage(String src, String message) {
	return ALERT_BEG + src + END_LIST + message;
    }
    public static String makeNormalMessage (String src, String message) {
	return BEG_LIST + src + END_LIST + message;
    }
    public static String makeErrorMessage (String src, String message) {
	return ERROR_BEG + src + END_LIST + message;
    }

}


