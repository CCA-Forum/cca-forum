package gov.sandia.ccaffeine.dc.user_iface.MVC;

import java.net.ConnectException;

import gov.sandia.ccaffeine.dc.user_iface.MVC.event.FixSharedLibraryEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.OpenCcaFrameworkEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetPathToCcaComponentsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetPathsToCcaComponentsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PythonControllerListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.LoadComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ComponentClassNamesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.InstantiateComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ComponentInstancesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaConnectTwoPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaDisconnectTwoPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaConnectionsBetweenTwoPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.LaunchGoOnOneComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.LaunchGoOnAllComponentsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CloseComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CloseCcaFrameworkEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaComponent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPort;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveInstantiatedComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveInstantiatedComponentsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterCurrentValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterDefaultValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterDialogBoxEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterEndDialogBoxEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterNewFieldEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterOneEnumeratedValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterPromptEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterRangeOfValuesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParametersEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterTabEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterSetValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaComponentPropertySetValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaComponentPropertyValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaComponentPropertyValuesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetDebugFlagEvent;




    /**
     * This java client sends Python code to a remote interface
     * that is attached to the cca server.  The code usually
     * instructs the cca server to perform an action; for example,
     * this client can instruct the cca server to instantiate
     * component.  The remote interface
     * sends XML text to this java client; the XML text contains
     * inforation on the state of the cca server; for example,
     * the cca server can send the names of all loaded components.
     * <p>
     * This class opens a socket connection to the remote interface.
     * Python code is sent from this client to the cca server's
     * remote interface.
     */

/*
 * Programmer's Notes:
 * scenario:  GUI wants to populate the palette
 *    GUI formulates a query that asks for all the components in the palette
 *    GUI sends a query to the ViewPython
 *        NOTE: The ViewPython is a GUI Listener
 *    ViewPython sends a query to the PythonStub
 *    The PythonStub forwards the query to the server skeleton
 *    The server skeleton forwards the query to the cca server
 *    The cca server sends the components to the server skeleton
 *    The server skeleton sends the components to the PythonStub
 *    The PythonStub sends the components to the ControllerPython
 *    The ControllerPython sends the events to the GUI
 *        NOTE:  The GUI is a ControllerListener
 */
public class PythonStub {



    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/




    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/



    /*
     * The socket and streams
     * that connect this cca client to the cca server
     */
    protected ClientSocket clientSocket = null;


    ThreadRead threadRead = null;


    /**
     * Stores (methodName,ThreadWaitForReturnValue) pairs.
     * <p>
     * The pairs are needed so that a method can send a command
     * to the cca server, wait for a response from the cca server,
     * return the response to the caller.
     * <p>
     * When this client invokes a method on the cca server: <br>
     * *)This client creates a ThreadWaitForReturnValue <br>
     * *)This client saves (methodName,ThreadWaitForReturnValue) <br>
     * *)This client waits for the thread to finish its run <br>
     * When the receiver gets a response from the server,
     * the receiver looks up the response in this hashtable.
     * If a match is found then the ThreadWaitforReturnValue is
     * released.
     */
    protected java.util.Hashtable hashtable =
        new java.util.Hashtable();



    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Write a line of python code to the python server.
     * @param s The line of python code that will be
     * sent to the python server.
     */
    protected void writePython(String s){
          this.clientSocket.print(s+"\n");
    }



    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Read a line of text from the python server.
     * @return The line of text that we read from
     * the python server.
     */
    protected String readPython() {
        try {
          String oneLine = this.clientSocket.readLine();
          System.out.println("server sent us:"+oneLine);
          return(oneLine);
        }
        catch (java.lang.Throwable e) {
          System.out.println(e);
          e.printStackTrace();
          return ("");
        }
    }









    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Open a session with the cca server.
     * <p>
     * A socket communication channel is established
     * with the cca server.
     * During this session, this comm channel will be used to
     * send commands to the cca server and to receive
     * state information from the cca server.
     * <p>
     * Open a socket connection to the cca server.
     * Then send Python code to initialize this session.
     */
    public void openSessionWithCcaServer(ClientSocket clientSocket)
         throws CanNotCommunicateWithCcaServerException {


          this.clientSocket = clientSocket;

          /* tell python to import the framework */
          this.writePython("import framework");

          /* tell python to instantiate a framework */
          this.writePython("f = framework.Framework()");

          /* start the reader thread */
          this.threadRead = new ThreadRead();
          threadRead.start();

    }







    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/



    /**
     * Tell the python server to set the debug flag.
     * @param debug The value of the debug flag.
     * @return The value of the debug flag.
     */
    public boolean setDebugFlag(boolean debug)
              throws CanNotCommunicateWithCcaServerException,
                     CanNotSetDebugFlagException {

             /* create the command string */
             String command;
             if (debug)
                 command = "f.setDebug(1)";
             else
                 command = "f.setDebug(0)";

             /* send the command to the cca server              */
             /* wait for the cca server to send back a response */
             String resultSet =
                 this.sendQueryToCcaServerAndRetrieveResultSet(command);

         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */
           java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<valueOfDebugFlag>(.*?)</valueOfDebugFlag>\\s*"
              +"<status>(.*?)</status>");
           java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
           //System.out.println("RESULT SET: setDebugFlag");

        /* If the server did not send us back any info */
        /* then throw an exception.                    */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

         /* if the first word of the status tag is "not" */
         /* then throw an exception                          */
        String status = matcher.group(2);
        if (status.startsWith("not"))
            throw new CanNotSetDebugFlagException
                 ("Can not set debug");

        /* get the info that the server sent us */
        String valueOfDebugFlag = matcher.group(1);
        if (valueOfDebugFlag.equals("true"))
            debug=true;

        /* send a SetDebugEvent     */
        /* to all registered listeners            */
        broadcastSetDebugFlag(debug);

        /* Return value of the debug flag */
        return(debug);

    }




    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * fix C++ shared library problem.
     * @throws CanNotCommunicateWithCcaServerException Communication
     * error.
     * @throws CanNotFixSharedLibraryException cca's Python server
     * can not fix the shared library problem.
     */
    public void fixSharedLibrary()
           throws CanNotCommunicateWithCcaServerException,
                  CanNotFixSharedLibraryException {


         /* create the command string */
          String command = "f.fixSharedLibrary()";

         /* send the command to the cca server              */
         /* wait for the cca server to send back a response */
         String resultSet =
             this.sendQueryToCcaServerAndRetrieveResultSet(command);

         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */

         /* look for the status tag.                         */
         java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<status>(.*?)</status>");
        java.util.regex.Matcher matcher =
            pattern.matcher(resultSet);

         /* if we did not find a <status> tag then throw an exception */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

         /* if the first word of the tag's contents is "not" */
         /* then throw an exception                          */
        String status = matcher.group(1);
        if (status.startsWith("not"))
            throw new CanNotFixSharedLibraryException
                 ("cca server failed to fix shared library");

        /* send a FixSharedLibraryEvent to all registered listeners */
        broadcastFixSharedLibrary();
    }




    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/












    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Open a connection to the python server.
     * Tell the python server to instantiate
     * a framework.
     * @return the xml string the cca server
     * sent us in response to an openFramework command.
     */
    public void openFramework()
           throws CanNotCommunicateWithCcaServerException,
                  CanNotOpenCcaFrameworkException{

         /* tell python to init the framework */

         /* create the command string */
          String command = "f.openFramework()";

         /* send the command to the cca server              */
         /* wait for the cca server to send back a response */
         String resultSet =
             this.sendQueryToCcaServerAndRetrieveResultSet(command);

         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */

         /* look for the status tag.                         */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<status>(.*?)</status>");
        java.util.regex.Matcher matcher =
            pattern.matcher(resultSet);

        /* if we did NOT find a <status> tag then throw an exception */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");


         /* if the first word of the tag's contents is "not" */
         /* then throw an exception                          */
        String status = matcher.group(1);
        if (status.startsWith("not"))
            throw new CanNotOpenCcaFrameworkException
                 ("Can not open CCA Framework");

        /* send a FixSharedLibraryEvent to all registered listeners */
        broadcastOpenCcaFramework();


    }











    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/








    /**
     * Tell the python server the name of the folder
     * that contains all of the cca components.
     * @param path The name of the folder that contains
     * all of the cca components.
     * @return The path that the server echoed back to us.
     */
    public String setPathToCcaComponents(String path)
           throws CanNotCommunicateWithCcaServerException,
                  CanNotSetPathToCcaComponentsException {

         /* create the command string */
          String command = "f.setPathToCcaComponents('" + path + "')";

         /* send the command to the cca server              */
         /* wait for the cca server to send back a response */
         String resultSet =
             this.sendQueryToCcaServerAndRetrieveResultSet(command);

         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<path>(.*?)</path>\\s*" +
            "<status>(.*?)</status>");
        java.util.regex.Matcher matcher =
            pattern.matcher(resultSet);
        //System.out.println("RESULT SET: setPathToCcaComponents");

        /* If the server did not send us back the path */
        /* then throw an exception.                    */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

         /* if the first word of the tag's contents is "not" */
         /* then throw an exception                          */
        String status = matcher.group(2);
        if (status.startsWith("not"))
            throw new CanNotSetPathToCcaComponentsException
                 ("Can not set path to cca components");

        /* get the path */
        path = matcher.group(1);


        /* send a SetPathToCcaCompomponentsEvent */
        /* to all registered listeners           */
        broadcastSetPathToCcaComponents(path);

        /* Return the path that the server sent us */
        return(path);

    }






    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Tell the python server the names of the folders
     * that contains all of the cca components.
     * @param paths The names of all the folders that
     * contain cca components.
     * @return The paths that the server echoed back to us.
     */
    public String[] setPathsToCcaComponents(String paths[])
           throws CanNotCommunicateWithCcaServerException,
                  CanNotSetPathToCcaComponentsException {

        int numberOfPaths = paths.length;
        StringBuffer s = new StringBuffer
            ("f.setPathsToCcaComponents([");
        for (int i=0; i<numberOfPaths; i++) {
            if (i!=0) s.append(",");
            s.append("'" + paths[i] + "'");
        }
        s.append("])");


         /* create the command string */
          String command = s.toString();

         /* send the command to the cca server              */
         /* wait for the cca server to send back a response */
         String resultSet =
             this.sendQueryToCcaServerAndRetrieveResultSet(command);

         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<paths>(.*?)</paths>\\s*"
           +"<status>(.*?)</status>");
        java.util.regex.Matcher matcher =
            pattern.matcher(resultSet);
        //System.out.println("RESULT SET: setPathsToCcaComponents");

        /* If the server did not send us back the path */
        /* then throw an exception.                    */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

         /* if the first word of the tag's contents is "not" */
         /* then throw an exception                          */
        String status = matcher.group(2);
        if (status.startsWith("not"))
            throw new CanNotSetPathToCcaComponentsException
                 ("Can not set path to cca components");

        /* get all of the paths */
        CcaPathsToComponents ccaPathsToComponents
                = new CcaPathsToComponents(matcher.group(1));
        String pathsRetrievedFromServer[] = ccaPathsToComponents.paths;

        /* send a SetPathsToCcaCompomponentsEvent */
        /* to all registered listeners            */
        broadcastSetPathsToCcaComponents(pathsRetrievedFromServer);

        /* Return the paths that the server sent us */
        return(pathsRetrievedFromServer);

    }





    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Tell the python server to instantiate a cca component.
     * The newly instantiated component
     * appears in the arena.  The arena is
     * the cca's main workspace.
     * @param componentClassName
     * The class name of the component.
     * @param componentInstanceName
     * The instance name of the component.
     */
    public CcaComponent instantiateComponent
           (String componentClassName,
            String componentInstanceName)
           throws CanNotCommunicateWithCcaServerException,
                  CanNotInstantiateComponentException {

          /* create the command string */
          String command = "f.instantiateComponent(\""
                         + componentClassName
                         +"\",\""
                         + componentInstanceName
                         +"\")";

          /* send the command to the cca server              */
          /* wait for the cca server to send back a response */
          String resultSet =
              this.sendQueryToCcaServerAndRetrieveResultSet(command);


        /* If the server did not send us back the path */
        /* then throw an exception.                    */
           java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<status>(.*?)</status>");
           java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
           //System.out.println("RESULT SET: instantiate component");

        /* If the server did not send us back the path */
        /* then throw an exception.                    */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

         /* if the first word of the tag's contents is "not" */
         /* then throw an exception                          */
        String status = matcher.group(1);
        if (status.startsWith("not"))
            throw new CanNotInstantiateComponentException
                 ("Can not set path to cca components");

        /* Get the loaded component */
        CcaComponent component = new CcaComponent(resultSet);

        /* send a instantiateComponentEvent */
        /* to all registered listeners      */
        broadcastInstantiateComponent(component);

        /* Return the loaded component */
        return(component);


    }



    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Tell the python server to remove an instantiated cca component.
     * The instantiated component
     * is removed from the arena.  The arena is
     * the cca's main workspace.
     * @param componentClassName
     * The class name of the component.
     * @param componentInstanceName
     * The instance name of the component.
     */
    public void removeInstantiatedComponent
           (String componentInstanceName)
           throws CanNotCommunicateWithCcaServerException,
                  CanNotRemoveInstantiatedComponentException {

          /* create the command string */
          String command = "f.removeInstantiatedComponent(\""
                         + componentInstanceName
                         +"\")";

          /* send the command to the cca server              */
          /* wait for the cca server to send back a response */
          String resultSet =
              this.sendQueryToCcaServerAndRetrieveResultSet(command);


        /* If the server did not send us bac something useful */
        /* then throw an exception.                           */
           java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<status>(.*?)</status>");
           java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
           //System.out.println("RESULT SET: remove instantiated component");

        /* If the server did not send us back the path */
        /* then throw an exception.                    */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

         /* if the first word of the tag's contents is "not" */
         /* then throw an exception                          */
        String status = matcher.group(1);
        if (status.startsWith("not"))
            throw new CanNotRemoveInstantiatedComponentException
                 ("Can not remove cca components");

        /* send a removeIinstantiatedComponentEvent */
        /* to all registered listeners      */
        broadcastRemoveInstantiatedComponent(componentInstanceName);


    }







    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Tell the python server to remove all instantiated cca components.
     * The instantiated components
     * are removed from the arena.  The arena is
     * the cca's main workspace.
     * @return The names of the removed components.
     */
    public CcaComponentInstanceNames removeInstantiatedComponents()
           throws CanNotCommunicateWithCcaServerException,
                  CanNotRemoveInstantiatedComponentException {

          /* create the command string */
          String command = "f.removeInstantiatedComponents()";

          /* send the command to the cca server              */
          /* wait for the cca server to send back a response */
          String resultSet =
              this.sendQueryToCcaServerAndRetrieveResultSet(command);

        /* If the server did not send us back anything useful */
        /* then throw an exception.                           */
           java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<instanceNames>(.*?)</instanceNames>\\s*"
              +"<status>(.*?)</status>");
           java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
           //System.out.println("RESULT SET: remove instantiated components");

        /* If the server did not send us back the path */
        /* then throw an exception.                    */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

         /* if the first word of the status tag is "not" */
         /* then throw an exception                          */
        String status = matcher.group(2);
        if (status.startsWith("not"))
            throw new CanNotRemoveInstantiatedComponentException
                 ("Can not remove cca components");

        /* get the names of the removed components */
        CcaComponentInstanceNames instanceNames =
           new CcaComponentInstanceNames(matcher.group(1));

        /* send a removeIinstantiatedComponentsEvent */
        /* to all registered listeners      */
        broadcastRemoveInstantiatedComponents(instanceNames);

        /* return the names of the removed components */
        return(instanceNames);

    }





    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/



    /**
     * Tell the python server to load a component class.
     * The component is loaded into the palette.
     * @param componentClassName The class name
     * of the component.
     * @return the xml string the cca server
     * sent us in response to a loadComponentClass command.
     * @throws CanNotCommunicateWithServerException Thrown if
     * the server does not respond to the laod component command.
     */
    public String loadComponentClass(String componentClassName)
           throws CanNotCommunicateWithCcaServerException,
                  CanNotLoadComponentException {

      /* create the command string */
      String command = "f.loadComponentClass(\"" + componentClassName + "\")";

      /* send the command to the cca server              */
      /* wait for the cca server to send back a response */
      String resultSet =
          this.sendQueryToCcaServerAndRetrieveResultSet(command);

         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<className>(.*?)</className>\\s*"
           +"<status>(.*?)</status>");
        java.util.regex.Matcher matcher =
            pattern.matcher(resultSet);
        //System.out.println("RESULT SET: load components");

        /* If the server did not send us back the name of a component */
        /* then throw an exception.                                   */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

         /* if the first word of the tag's contents is "not" */
         /* then throw an exception                          */
        String status = matcher.group(2);
        if (status.startsWith("not"))
            throw new CanNotLoadComponentException
                 ("Can not load component");

        /* the server is suppose to send us back       */
        /* the class name of the loaded component      */
        componentClassName = matcher.group(1);


        /* send a LoadComponentEvent              */
        /* to all registered listeners            */
        broadcastLoadComponent(componentClassName);

        /* Return the class name of the compnent */
        return(componentClassName);



    }





    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Tell the python server to connect two ports;
     * the two ports may be
     * in different components.  One of the ports
     * must be a provider port; these ports provide
     * a service.  The other port must be a uses port;
     * these ports consume a service.
     * @param providesServiceComponentName The
     * name of the component that contains the providers port.
     * @param providesServicePortName The name of
     * the providers port.
     * @param usesServiceComponentName the name of the component
     * that contains the consumer port.
     * @param usesServicePortName The name of the consumer port.
     * @return The cca connection that connects the two input ports.
     */
    public CcaConnectionBetweenTwoPorts connectTwoPorts
           (String providesServiceComponentName,
            String providesServicePortName,
            String usesServiceComponentName,
            String usesServicePortName)
         throws CanNotCommunicateWithCcaServerException,
                CanNotConnectTwoPortsException {

        /* create the command string */
        String command = "f.connectTwoPorts(\""
                          + providesServiceComponentName
                          + "\", \""
                          + providesServicePortName
                          + "\", \""
                          + usesServiceComponentName
                          + "\", \""
                          + usesServicePortName
                          + "\")";

        /* send the command to the cca server              */
        /* wait for the cca server to send back a response */
        String resultSet =
            this.sendQueryToCcaServerAndRetrieveResultSet(command);

         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */
           java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<status>(.*?)</status>");
           java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
           //System.out.println("RESULT SET: connect two ports");

        /* If the server did not send us back the name of a component */
        /* then throw an exception.                                   */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

         /* if the first word of the tag's contents is "not" */
         /* then throw an exception                          */
        String status = matcher.group(1);
        if (status.startsWith("not"))
            throw new CanNotConnectTwoPortsException
                 ("Can not connect two ports");

        /* get the connection */
        CcaConnectionBetweenTwoPorts ccaConnection =
           new CcaConnectionBetweenTwoPorts(resultSet);


        /* send a ConnectTwoPortsEvent            */
        /* to all registered listeners            */
        broadcastConnectTwoPorts(ccaConnection);

        /* Return the connection */
        return(ccaConnection);
    }

    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Tell the python server to set the value of a component property.
     * @param componentInstanceName The name of the component
     * @param propertyName The name of the property
     * @param propertyValue The value of the property
     */
    public CcaComponentPropertyValue setComponentProperty
           (String componentInstanceName,
            String propertyName,
            String propertyValue)
            throws CanNotCommunicateWithCcaServerException,
                   CanNotSetComponentPropertyException {

        /* create the command string */
        String command =
             "f.setComponentProperty"
               +"(\"" + componentInstanceName + "\", "
               +"\"" + propertyName + "\", "
               +"\"" + propertyValue + "\")";

        /* send the command to the cca server              */
        /* wait for the cca server to send back a response */
        String resultSet =
           this.sendQueryToCcaServerAndRetrieveResultSet(command);

        /* Parse the resultSet.                                       */
        /* If an error occurred on the server then throw an exception */
        java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<status>(.*?)</status>");
        java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
        //System.out.println("RESULT SET:setComponentProperty");

        /* If the server did not send us back any info */
        /* then throw an exception.                    */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

        /* retrieve info from the xml status string */
        CcaComponentPropertyValue ccaComponentPropertyValue =
            new CcaComponentPropertyValue(resultSet);
        String status = matcher.group(1);

         /* if the first word of the status tag is "not" */
         /* then throw an exception                          */
        if (status.startsWith("not"))
            throw new CanNotSetComponentPropertyException
                 ("Can not set component property");

        /* send a CcaComponentPropertySetValueEvent  */
        /* to all registered listeners               */
        broadcastSetComponentProperty(ccaComponentPropertyValue);


        /* return the ccaComponentPropertyValue */
        return(ccaComponentPropertyValue);



    }




    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Ask the python server to send us the value of component property.
     * @param componentInstanceName The name of the component.
     * @param propertyName The name of the property.
     */
    public CcaComponentPropertyValue getComponentProperty
           (String componentInstanceName,
            String propertyName)
      throws CanNotCommunicateWithCcaServerException,
             CanNotGetComponentPropertyException {

     /* create the command string */
     String command = "f.getXmlComponentProperty("
                    + "'" + componentInstanceName + "'"
                    + ","
                    + "'" + propertyName + "'"
                    + ")";

     /* send the command to the cca server                        */
     /* wait for the cca server to send back a bunch of responses */
     String resultSet =
           this.sendQueryToCcaServerAndRetrieveResultSet(command);




        /* Parse the resultSet.                                       */
        /* If an error occurred on the server then throw an exception */
        java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<status>(.*?)</status>");
        java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
        //System.out.println("RESULT SET:getXmlComponentProperty");

        /* If the server did not send us back any info */
        /* then throw an exception.                    */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

        /* retrieve info from the xml status string */
        CcaComponentPropertyValue ccaComponentPropertyValue =
            new CcaComponentPropertyValue(resultSet);
        String status = matcher.group(1);

         /* if the first word of the status tag is "not" */
         /* then throw an exception                          */
        if (status.startsWith("not"))
            throw new CanNotGetComponentPropertyException
                 ("Can not get component property");

        /* send a CcaComponentPropertyValueEvent  */
        /* to all registered listeners               */
        broadcastComponentProperty(ccaComponentPropertyValue);


        /* return the ccaComponentPropertyValue */
        return(ccaComponentPropertyValue);

    }







    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/

    /**
     * Ask the python server to send us the values of all the
     * properties that belong to a component.
     * @param componentInstanceName The name of the component.
     */
    public CcaComponentPropertyValue[] getComponentProperties
           (String componentInstanceName)
      throws CanNotCommunicateWithCcaServerException,
             CanNotGetComponentPropertyException {

     /* create the command string */
     String command = "f.getXmlComponentProperties("
                    + "'" + componentInstanceName + "'"
                    + ")";

     /* send the command to the cca server                        */
     /* wait for the cca server to send back a bunch of responses */
     String resultSet =
           this.sendQueryToCcaServerAndRetrieveResultSet(command);




        /* Parse the resultSet.                                       */
        /* If an error occurred on the server then throw an exception */
        java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<status>(.*?)</status>\\s*"
              +"<properties>(.*?)</properties>");
        java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
        //System.out.println("RESULT SET:getXmlComponentProperties");

        /* If the server did not send us back any info */
        /* then throw an exception.                    */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

        /* retrieve info from the xml status string */
        //CcaComponentPropertyValue ccaComponentPropertyValue =
        //    new CcaComponentPropertyValue(resultSet);
        String status = matcher.group(1);
        String properties = matcher.group(2);

        /* We will store all of the properties here */
        java.util.Vector vector = new java.util.Vector();

        /* retrieve each and every component property */
        pattern = java.util.regex.Pattern.compile
              ("<property>(.*?)</property>");
        matcher = pattern.matcher(properties);
        while (matcher.find()) {
            String property = matcher.group(1);
            CcaComponentPropertyValue ccaComponentPropertyValue =
                new CcaComponentPropertyValue(property);
            vector.add(ccaComponentPropertyValue);
        }

        /* copy the vector into an array */
        int numberOfProperties = vector.size();
        CcaComponentPropertyValue ccaComponentPropertyValues[] =
            new CcaComponentPropertyValue[numberOfProperties];
        vector.copyInto(ccaComponentPropertyValues);


         /* if the first word of the status tag is "not" */
         /* then throw an exception                          */
        if (status.startsWith("not"))
            throw new CanNotGetComponentPropertyException
                 ("Can not get component property");

        /* send a CcaComponentPropertyValuesEvent  */
        /* to all registered listeners            */
        broadcastComponentProperties(ccaComponentPropertyValues);


        /* return the ccaComponentPropertyValues */
        return(ccaComponentPropertyValues);
    }




     /*-----------------------------------------------------------------*/
     /*-----------------------------------------------------------------*/


    /**
     * Tell the python server to launch the run.
     * @param componentInstanceName The name of the
     * component that contains a GO port.  The run
     * is launched from this port.
     * @param the go command that the server sent back to us
     */
    public CcaCommandLaunchGoOnOneComponent launchGoOnOneComponent
           (String componentInstanceName)
      throws CanNotCommunicateWithCcaServerException,
             CanNotLaunchGoCommandOnOneComponentException {

     /* create the command string */
     String command = "f.launchGoOnOneComponent"
               +"(\"" + componentInstanceName + "\")";

     /* send the command to the cca server              */
     /* wait for the cca server to send back a response */
     String resultSet =
         this.sendQueryToCcaServerAndRetrieveResultSet(command);

         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */
           java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<componentInstanceName>(.*?)</componentInstanceName>\\s*"
              +"<portInstanceName>(.*?)</portInstanceName>\\s*"
              +"<status>(.*?)</status>");
           java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
           //System.out.println("RESULT SET: launchGoOnOneComponent");

        /* If the server did not send us back any info */
        /* then throw an exception.                    */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

         /* if the first word of the tag's contents is "not" */
         /* then throw an exception                          */
        String status = matcher.group(3);
        if (status.startsWith("not"))
            throw new CanNotLaunchGoCommandOnOneComponentException
                 ("Can not launch go command from one component");

        /* get the info that the server sent us */
        CcaCommandLaunchGoOnOneComponent commandLaunchGoOnOneComponent
          = new CcaCommandLaunchGoOnOneComponent(resultSet);

        /* send a LaunchGoOnOneComponentEvent     */
        /* to all registered listeners            */
        broadcastLaunchGoOnOneComponent(commandLaunchGoOnOneComponent);

        /* Return the launch command */
        return(commandLaunchGoOnOneComponent);

    }



    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/



    /**
     * Tell the python server to launch the run.
     * @param componentInstanceName The name of the
     * component that contains a GO port.  The run
     * is launched from this port.
     * @param portInstanceName the name of the GO port.3
     * @return Information on the component and the port
     * that launched the go command.
     */
    public CcaCommandLaunchGoOnOneComponent launchGoOnOneComponent
                (String componentInstanceName,
                 String portInstanceName)
              throws CanNotCommunicateWithCcaServerException,
                     CanNotLaunchGoCommandOnOneComponentException {

             /* create the command string */
             String command = "f.launchGoOnOneComponent"
               +"(\"" + componentInstanceName + "\", "
               +"\"" + portInstanceName + "\")";

             /* send the command to the cca server              */
             /* wait for the cca server to send back a response */
             String resultSet =
                 this.sendQueryToCcaServerAndRetrieveResultSet(command);

         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */
           java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<componentInstanceName>(.*?)</componentInstanceName>\\s*"
              +"<portInstanceName>(.*?)</portInstanceName>\\s*"
              +"<status>(.*?)</status>");
           java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
           //System.out.println("RESULT SET: launchGoOnOneComponent");

        /* If the server did not send us back any info */
        /* then throw an exception.                    */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

         /* if the first word of the tag's contents is "not" */
         /* then throw an exception                          */
        String status = matcher.group(3);
        if (status.startsWith("not"))
            throw new CanNotLaunchGoCommandOnOneComponentException
                 ("Can not launch go command from one component");

        /* get the info that the server sent us */
        CcaCommandLaunchGoOnOneComponent commandLaunchGoOnOneComponent
          = new CcaCommandLaunchGoOnOneComponent(resultSet);

        /* send a LaunchGoOnOneComponentEvent     */
        /* to all registered listeners            */
        broadcastLaunchGoOnOneComponent(commandLaunchGoOnOneComponent);

        /* Return the launch command */
        return(commandLaunchGoOnOneComponent);

    }













    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/




    /**
     * Tell the python server to launch the run.
     */
    public void launchGoOnAllComponents()
      throws CanNotCommunicateWithCcaServerException,
             CanNotLaunchGoCommandOnAllComponentsException {

     /* create the command string */
     String command = "f.launchGoOnAllComponents()";

     /* send the command to the cca server              */
     /* wait for the cca server to send back a response */
     String resultSet =
         this.sendQueryToCcaServerAndRetrieveResultSet(command);

         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */
           java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<status>(.*?)</status>");
           java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
           //System.out.println("RESULT SET:launchGoOnAllComponents");

        /* If the server did not send us back any info */
        /* then throw an exception.                    */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

         /* if the first word of the tag's contents is "not" */
         /* then throw an exception                          */
        String status = matcher.group(1);
        if (status.startsWith("not"))
            throw new CanNotLaunchGoCommandOnAllComponentsException
                 ("Can not launch go command on all components");

        /* send a LaunchGoOnAllComponentsEvent     */
        /* to all registered listeners              */
        broadcastLaunchGoOnAllComponents();


    }




    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Tell the python server to disconnect two ports;
     * the two ports may be
     * in different components.  One of the ports
     * must be a provider port; these ports provide
     * a service.  The other port must be a uses port;
     * these ports consume a service.
     * @param providesServiceComponentName The
     * name of the component that contains the providers port.
     * @param providesServicePortName The name of
     * the providers port.
     * @param usesServiceComponentName the name of the component
     * that contains the consumer port.
     * @param usesServicePortName The name of the consumer port.
     * @return The cca connection that connects the two input ports.
     */
    public CcaConnectionBetweenTwoPorts disconnectTwoPorts
           (String providesServiceComponentName,
            String providesServicePortName,
            String usesServiceComponentName,
            String usesServicePortName)
         throws CanNotCommunicateWithCcaServerException,
                CanNotDisconnectTwoPortsException {

        /* create the command string */
        String command = "f.disconnectTwoPorts(\""
                          + providesServiceComponentName
                          + "\", \""
                          + providesServicePortName
                          + "\", \""
                          + usesServiceComponentName
                          + "\", \""
                          + usesServicePortName
                          + "\")";

        /* send the command to the cca server              */
        /* wait for the cca server to send back a response */
        String resultSet =
            this.sendQueryToCcaServerAndRetrieveResultSet(command);

         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */
           java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<status>(.*?)</status>");
           java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
           //System.out.println("RESULT SET: disconnect two ports");

        /* If the server did not send us back the name of a component */
        /* then throw an exception.                                   */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

         /* if the first word of the tag's contents is "not" */
         /* then throw an exception                          */
        String status = matcher.group(1);
        if (status.startsWith("not"))
            throw new CanNotDisconnectTwoPortsException
                 ("Can not connect two ports");

        /* get the connection */
        CcaConnectionBetweenTwoPorts ccaConnection =
           new CcaConnectionBetweenTwoPorts(resultSet);


        /* send a DisconnectTwoPortsEvent         */
        /* to all registered listeners            */
        broadcastDisconnectTwoPorts(ccaConnection);

        /* Return the connection */
        return(ccaConnection);
    }


    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/



    /**
     * Tell the python server to close the cca component.
     * @param componentInstanceName The name of the
     * component.
     * @return the name of the component that the server closed.
     */
    public String closeComponent(String componentInstanceName)
              throws CanNotCommunicateWithCcaServerException,
                     CanNotCloseComponentException {

             /* create the command string */
             String command =
                 "f.closeComponent(\"" + componentInstanceName + "\")";

             /* send the command to the cca server              */
             /* wait for the cca server to send back a response */
             String resultSet =
                 this.sendQueryToCcaServerAndRetrieveResultSet(command);


         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */
           java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<instanceName>(.*?)</instanceName>\\s*"
              +"<status>(.*?)</status>");
           java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
           //System.out.println("RESULT SET: Close Component");

        /* If the server did not send us back any info */
        /* then throw an exception.                    */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

         /* if the first word of the tag's contents is "not" */
         /* then throw an exception                          */
        String status = matcher.group(2);
        if (status.startsWith("not"))
            throw new CanNotCloseComponentException
                 ("Can not close component");

        /* get the name of the component that the server sent us */
        componentInstanceName = matcher.group(1);

        /* send a closeComponentEvent     */
        /* to all registered listeners    */
        broadcastCloseComponent(componentInstanceName);

        /* Get the name of the component that was closed */
        return(componentInstanceName);


    }





    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Tell the python server to send back the names
     * of all the classes that are loaded in the palette.
     */
    public String[] getComponentClassNames()
        throws CanNotCommunicateWithCcaServerException {

       /* create the command string */
       String command = "f.getXmlComponentClassNames()";

       /* send the command to the cca server              */
       /* wait for the cca server to send back a response */
       String resultSet =
           this.sendQueryToCcaServerAndRetrieveResultSet(command);

         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<classNames>(.*?)</classNames>");
        java.util.regex.Matcher matcher =
            pattern.matcher(resultSet);
        //System.out.println("RESULT SET: class names of components");

        /* If the server did not send us back class names */
        /* then throw an exception.                       */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");


        /* extract the class names */
        CcaClassNames x = new CcaClassNames(matcher.group(1));
        String classNames[] = x.classNames;

        /* send an event */
        /* to all registered listeners        */
        broadcastComponentClassNames(classNames);

        /* Return the class name of the compnent */
        return(classNames);


    }




       /*-----------------------------------------------------------------*/
       /*-----------------------------------------------------------------*/


    /**
     * Tell the python server to send back the names
     * of all the classes that are instantiated in the arena.
     */
    public CcaComponent[] getComponentInstances()
      throws CanNotCommunicateWithCcaServerException {

     /* create the command string */
     String command = "f.getXmlComponentInstances()";

     /* send the command to the cca server              */
     /* wait for the cca server to send back a response */
     String resultSet =
         this.sendQueryToCcaServerAndRetrieveResultSet(command);


         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */
           java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<component>(.*?)</component>");
           java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
           //System.out.println("RESULT SET: component");

        /* If the server did not send us back components */
        /* then throw an exception.                       */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

        /* extract the componets                      */
        /* store the components in a temporary vector */
        java.util.Vector vector = new java.util.Vector();
        while (matcher.find()) {
               String xmlComponent = matcher.group(1);
               CcaComponent component =
                  new CcaComponent(xmlComponent);
               vector.add(component);
        } //while

        /* copy the vector into an array */
        int numberOfComponents = vector.size();
        CcaComponent components[] = new CcaComponent[numberOfComponents];
        vector.copyInto(components);


        /* send an event                  */
        /* to all registered listeners    */
        broadcastComponentInstances(components);

        /* Return the compnents */
        return(components);



    }








    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Tell the python server to send back info
     * on every connection.
     * @return Every connection that is between 2 ports
     */
    public CcaConnectionBetweenTwoPorts[] getConnections()
      throws CanNotCommunicateWithCcaServerException {

     /* create the command string */
     String command = "f.getXmlConnections()";

     /* send the command to the cca server              */
     /* wait for the cca server to send back a response */
     String resultSet =
         this.sendQueryToCcaServerAndRetrieveResultSet(command);

         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */
           java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
                  ("<connection>(.*?)</connection>");
           java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
           //System.out.println("RESULT SET: connection");


        /* If the server did not send us back components */
        /* then throw an exception.                       */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

        /* extract the connections                     */
        /* store the connections in a temporary vector */
        java.util.Vector vector = new java.util.Vector();
        while (matcher.find()) {
               String xmlConnection = matcher.group(1);
               CcaConnectionBetweenTwoPorts ccaConnection =
                  new CcaConnectionBetweenTwoPorts(xmlConnection);
               vector.add(ccaConnection);
        } //while

        /* copy the vector into an array */
        int numberOfConnections = vector.size();
        CcaConnectionBetweenTwoPorts ccaConnections[] =
           new CcaConnectionBetweenTwoPorts[numberOfConnections];
        vector.copyInto(ccaConnections);

        /* send an event                  */
        /* to all registered listeners    */
        broadcastCcaConnectionsBetweenTwoPorts(ccaConnections);

        /* Return the cca connections */
        return(ccaConnections);


    }





    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    public CcaPortParameterValue setPortParameter
           (String componentInstanceName,
            String portInstanceName,
            String fieldName,
            String fieldValue)
            throws CanNotCommunicateWithCcaServerException,
                   CanNotSetPortParameterException {

         /* create the command string */
         String command =
             "f.setPortParameter"
               +"(\"" + componentInstanceName + "\", "
               +"\"" + portInstanceName + "\", "
               +"\"" + fieldName + "\", "
               +"\"" + fieldValue + "\")";

     /* send the command to the cca server              */
     /* wait for the cca server to send back a response */
     String resultSet =
         this.sendQueryToCcaServerAndRetrieveResultSet(command);

         /* Parse the resultSet.                                       */
         /* If an error occurred on the server then throw an exception */
           java.util.regex.Pattern pattern =
              java.util.regex.Pattern.compile
              ("<status>(.*?)</status>");
           java.util.regex.Matcher matcher =
               pattern.matcher(resultSet);
           //System.out.println("RESULT SET:setPortParameter");

        /* If the server did not send us back any info */
        /* then throw an exception.                    */
        if (matcher.find()==false)
            throw new CanNotCommunicateWithCcaServerException
                 ("server did not send back expected xml string");

        /* retrieve info from the xml status string */
        CcaPortParameterValue ccaPortParameterValue =
            new CcaPortParameterValue(resultSet);
        String status = matcher.group(1);

         /* if the first word of the status tag is "not" */
         /* then throw an exception                          */
        if (status.startsWith("not"))
            throw new CanNotSetPortParameterException
                 ("Can not set port parameter");

        /* send a setPortParameterEvent     */
        /* to all registered listeners      */
        broadcastSetPortParameter(ccaPortParameterValue);


        /* return the ccaPortParemeterValue */
        return(ccaPortParameterValue);

    }








    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    public String getPortParameters
           (String componentInstanceName,
            String portInstanceName)
      throws CanNotCommunicateWithCcaServerException,
             CanNotGetPortParametersException {

     /* create the command string */
     String command = "f.getXmlPortParameters("
                    + "'" + componentInstanceName + "'"
                    + ","
                    + "'" + portInstanceName + "'"
                    + ")";

      StringBuffer resultSets = new StringBuffer();

     /* send the command to the cca server                        */
     /* wait for the cca server to send back a bunch of responses */
     String resultSet =
         this.sendQueryToCcaServerAndRetrieveResultSet(command);
     resultSets.append(resultSet);

     while(true) {
         if (resultSet.indexOf("paramEndDialog")!=-1) break;
         resultSet = this.retrieveResultSetFromCcaServer(command);
         resultSets.append(resultSet);
     }


     /* tell everyone we got parameters */
     String s = resultSets.toString();

     broadcastPortParameters(s);

     return(s);



    }


    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Close out the session with the python server.
     */
    public void closeSessionWithCcaServer() {

      try {

      	  /* shut down the reader thread */
          this.threadRead.stop();

          /* close all streams and close the socket */
          this.clientSocket.close();
          this.clientSocket = null;

      }catch (java.lang.Throwable e) {
          System.out.println(e);
          e.printStackTrace();
      } finally {
          if (this.clientSocket!=null)
              try {this.clientSocket.close();} catch (Throwable e){}
      }
    }


    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Print useful information on a component.
     * @param component Information about this component
     * will be printed on the screen.
     */
    protected void printComponent(CcaComponent component) {

            /* print header */
            System.out.println("     component");

            /* print the component's instance name */
            System.out.println
                ("          instance name = " + component.instanceName);

            /* print the component's class name */
            System.out.println
                ("          class name = " + component.className);

            /* print the component's user port info */
            int numberOfUserPorts = component.userPorts.length;
            for (int i=0; i<numberOfUserPorts; i++)
                System.out.println
                    ("          user port = "
                    + component.userPorts[i].className
                    + " "
                    + component.userPorts[i].instanceName);


            /* print the component's provider port info */
            int numberOfProviderPorts = component.providerPorts.length;
            for (int i=0; i<numberOfProviderPorts; i++)
                System.out.println
                    ("          provider port = "
                    + component.providerPorts[i].className
                    + " "
                    + component.providerPorts[i].instanceName);
    }




    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Print useful information on a connection.
     * @param connection Information about this connection
     * will be printed on the screen.
     */
    protected void printConnection(CcaConnectionBetweenTwoPorts connection) {

            /* print header */
            System.out.println("     connection");

            System.out.println
                ("          provider component = "
                            + connection.providesServiceComponentName);

            System.out.println
                ("          provider port = "
                            + connection.providesServicePortName);

            System.out.println
                ("          user component = "
                            + connection.usesServiceComponentName);

            System.out.println
                ("          user port = "
                            + connection.usesServicePortName);

            System.out.println("");
    }




    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    /**
     * Print useful information on a disconnection.
     * @param connection Information about this connection
     * will be printed on the screen.
     */
    protected void printDisconnection(CcaConnectionBetweenTwoPorts connection) {

            /* print header */
            System.out.println("     disconnection");

            System.out.println
                ("          provider component = "
                            + connection.providesServiceComponentName);

            System.out.println
                ("          provider port = "
                            + connection.providesServicePortName);

            System.out.println
                ("          user component = "
                            + connection.usesServiceComponentName);

            System.out.println
                ("          user port = "
                            + connection.usesServicePortName);

            System.out.println("");
    }



    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/



   /**
    * Parse and display result set.
    * <p>
    * Whenever we send a query to the cca server,
    * the cca server will send us back a result set.
    * @param resultSet The result set that is to be
    * parsed and displayed.
    */
   protected void resultSet(String resultSet) {

    for (int i=0; i<1; i++) {
        if (resultSet.indexOf("<RESULT_SET:")==-1) break;

            /* get the name of the method that was invoked on the cca server */
            java.util.regex.Pattern pattern =
                java.util.regex.Pattern.compile("<RESULT_SET:(.*?)>");
            java.util.regex.Matcher matcher = pattern.matcher(resultSet);
            if (matcher.find()==false) break;
            String method = matcher.group(1);

            /* lookup the method in our hashtable                         */
            /* We want to get the thread that is waiting for this result set */
            if (this.hashtable.containsKey(method)==false) break;
            ThreadWaitForResultSet threadWaitForResultSet =
                (ThreadWaitForResultSet)this.hashtable.get(method);


            /* unblock the thread */
            threadWaitForResultSet.receivedResultSet(resultSet);

            /* done */
            return;
      }










   }





   /*-----------------------------------------------------------------*/
   /*-----------------------------------------------------------------*/


   /**
    * Send a query and/or command to the cca server
    * and then wait for the cca server to send back the result set.
    * @param query the query and/or command that is sent
    * to the cca server.
    * @return The result set the cca server send back.
    */
   String sendQueryToCcaServerAndRetrieveResultSet
          (String query)
          throws CanNotCommunicateWithCcaServerException {

       return(sendQueryToCcaServerAndRetrieveResultSet
                (query,
                 true)); //send query to cca server
   }



   /*-----------------------------------------------------------------*/
   /*-----------------------------------------------------------------*/


   /**
    * Send a query and/or command to the cca server
    * and then wait for the cca server to send back the result set.
    * @param query the query and/or command that was previously sent
    * to the cca server.
    * @return The result set the cca server send back.
    */
   String retrieveResultSetFromCcaServer
          (String query)
          throws CanNotCommunicateWithCcaServerException {

       return(sendQueryToCcaServerAndRetrieveResultSet
                (query,
                 false)); //send query to cca server
   }




   /*-----------------------------------------------------------------*/
   /*-----------------------------------------------------------------*/


   /**
    * Send a query and/or command to the cca server
    * and then wait for the cca server to send back the result set.
    * @param query the query and/ort command that is sent
    * to the cca server.
    * @param sendQueryToServer If true then the query
    * is sent to the server.  If not true then the we
    * do NOT send the query to the server, but we are
    * waiting for a result set from the server.
    * @return The result set the cca server send back.
    */
   String sendQueryToCcaServerAndRetrieveResultSet
          (String query,
           boolean sendQuerytoServer)
          throws CanNotCommunicateWithCcaServerException {

        /* error check */
        if (query==null) return("");
        query = query.trim();
        if (query.equals("")) return("");
        if (query.startsWith("f.")==false) return("");

        /* get the name of the method that this command is invoking */
        int index = query.indexOf("(");
        if (index==-1) return("");
        String method = query.substring(2,index);

        /* launch a Thread to wait for the cca server */
        /* to send a result set                       */
        ThreadWaitForResultSet threadWaitForResultSet = null;

        try {

            /*
             It might take a long long long time
             before we get a result set from the cca server.
             Set up a thread so that we can wait.
             */
            threadWaitForResultSet = new ThreadWaitForResultSet();
            threadWaitForResultSet.setPriority(java.lang.Thread.NORM_PRIORITY + 1);

            /*
             * Save the (methodName,ThreadWaitForResultSet) pair in
             * a hashtable.
             * Why?  When the receiver receives a result set from the cca
             * server, the reciever will do a lookup in the hashtable.
             * If a match is found, the receiver will unblock the
             * ThreadWaitForResultSet.
             */
            synchronized(this.hashtable) {
              this.hashtable.put(method, threadWaitForResultSet);
            }

            /*
             * Start the thread.  The thread will wait for a result set
             * from the cca server.
             */
            threadWaitForResultSet.start();
            Thread.currentThread().yield();  //start the thread

            /* send the query to the cca server */
            if (sendQuerytoServer)
                PythonStub.this.writePython(query);

            /* Wait for a result set */
            try {threadWaitForResultSet.join();}
            catch (java.lang.InterruptedException e){}

            /* Was an exception thrown? */
            java.lang.Throwable exception = threadWaitForResultSet.getException();
            if (exception != null) {
                throw new CanNotCommunicateWithCcaServerException
                      (exception.getMessage());
            }

            /* Retrieve the response */
            String value = threadWaitForResultSet.getResultSet();

            /* return the retrieved value */
            return(value);

          }finally {
              /* make sure the thread is garbage collected */
              threadWaitForResultSet = null;
          }


   }




    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/

    java.util.Vector pythonControllerListeners = new java.util.Vector();

    public void addPythonControllerListener
         (PythonControllerListener listener) {
         synchronized(pythonControllerListeners) {
             pythonControllerListeners.add(listener);
         }
    }



    public void removePythonControllerListener(PythonControllerListener listener) {
        synchronized(pythonControllerListeners) {
            pythonControllerListeners.remove(listener);
        }
    }

    protected void broadcastFixSharedLibrary(){
        FixSharedLibraryEvent event = new FixSharedLibraryEvent(this);
        broadcastFixSharedLibrary(event);
    }

    protected void broadcastFixSharedLibrary(FixSharedLibraryEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.fixSharedLibrary(event);
         }
     }


    protected void broadcastOpenCcaFramework(){
        OpenCcaFrameworkEvent event = new OpenCcaFrameworkEvent(this);
        broadcastOpenCcaFramework(event);
    }

    protected void broadcastOpenCcaFramework(OpenCcaFrameworkEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.openCcaFramework(event);
         }
     }





    protected void broadcastSetDebugFlag(boolean debug){
        SetDebugFlagEvent event = new SetDebugFlagEvent(this, debug);
        broadcastSetDebugFlag(event);
    }

    protected void broadcastSetDebugFlag(SetDebugFlagEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
         	PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.setDebugFlag(event);
         }
     }




    protected void broadcastSetPathToCcaComponents(String path) {
        SetPathToCcaComponentsEvent event =
            new SetPathToCcaComponentsEvent(this,path);
        broadcastSetPathToCcaComponents(event);
    }


    protected void broadcastSetPathToCcaComponents
              (SetPathToCcaComponentsEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.setPathToCcaComponents(event);
         }

    }


    protected void broadcastSetPathsToCcaComponents(String paths[]) {
        SetPathsToCcaComponentsEvent event =
            new SetPathsToCcaComponentsEvent(this, paths);
        broadcastSetPathsToCcaComponents(event);
    }


    protected void broadcastSetPathsToCcaComponents
              (SetPathsToCcaComponentsEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.setPathsToCcaComponents(event);
         }

    }



    protected void broadcastLoadComponent(String componentClassName) {
        LoadComponentEvent event =
            new LoadComponentEvent(this,componentClassName);
        broadcastLoadComponent(event);
    }


    protected void broadcastLoadComponent
              (LoadComponentEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.loadComponent(event);
         }

    }



    protected void broadcastComponentClassNames
                   (String componentClassNames[]) {
        ComponentClassNamesEvent event =
            new ComponentClassNamesEvent(this,componentClassNames);
        broadcastComponentClassNames(event);
    }


    protected void broadcastComponentClassNames
              (ComponentClassNamesEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.receivedComponentClassNames(event);
         }

    }




    protected void broadcastInstantiateComponent
                   (CcaComponent ccaComponent) {
        String componentInstanceName = ccaComponent.instanceName;
        String componentClassName = ccaComponent.className;
        CcaPort providerPorts[] = ccaComponent.providerPorts;
        CcaPort userPorts[] = ccaComponent.userPorts;


        InstantiateComponentEvent event = new InstantiateComponentEvent
		    (this,
		    componentInstanceName,
			componentClassName,
			userPorts,
			providerPorts);
        broadcastInstantiateComponent(event);
    }


    protected void broadcastInstantiateComponent
              (InstantiateComponentEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.instantiateComponent(event);
         }

    }



    protected void broadcastRemoveInstantiatedComponent
	(String componentInstanceName) {
    	RemoveInstantiatedComponentEvent event =
    		new RemoveInstantiatedComponentEvent(this, componentInstanceName);
    	broadcastRemoveInstantiatedComponent(event);
    }


    protected void broadcastRemoveInstantiatedComponent
	(RemoveInstantiatedComponentEvent event) {

  	    //loop through each listener and pass on the event if needed
    	java.util.Vector listeners;
    	synchronized (pythonControllerListeners) {
    		listeners = (java.util.Vector)pythonControllerListeners.clone();
    	}
    	int numberOfListeners = listeners.size();
    	for (int i=0; i<numberOfListeners; i++){
    		PythonControllerListener x =
    			(PythonControllerListener)listeners.elementAt(i);
    		x.removeInstantiatedComponent(event);
    	}

    }





    protected void broadcastRemoveInstantiatedComponents
                   (CcaComponentInstanceNames componentInstanceNames) {
        RemoveInstantiatedComponentsEvent event =
            new RemoveInstantiatedComponentsEvent
                (this, componentInstanceNames);
        broadcastRemoveInstantiatedComponents(event);
    }


    protected void broadcastRemoveInstantiatedComponents
              (RemoveInstantiatedComponentsEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
         	PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.removeInstantiatedComponents(event);
         }

    }



    protected void broadcastComponentInstances
                   (CcaComponent componentInstances[]) {
       ComponentInstancesEvent event =
            new ComponentInstancesEvent(this,componentInstances);
        broadcastComponentInstances(event);
    }

    protected void broadcastComponentInstances
        (ComponentInstancesEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.receivedComponentInstances(event);
         }

    }




    protected void broadcastConnectTwoPorts
                   (CcaConnectionBetweenTwoPorts ccaConnection) {
       CcaConnectTwoPortsEvent event =
            new CcaConnectTwoPortsEvent(this,ccaConnection);
        broadcastConnectTwoPorts(event);
    }

    protected void broadcastConnectTwoPorts
        (CcaConnectTwoPortsEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.connectTwoPorts(event);
         }

    }


    protected void broadcastCcaConnectionsBetweenTwoPorts
                   (CcaConnectionBetweenTwoPorts ccaConnections[]) {
       CcaConnectionsBetweenTwoPortsEvent event =
            new CcaConnectionsBetweenTwoPortsEvent(this,ccaConnections);
        broadcastCcaConnectionsBetweenTwoPorts(event);
    }

    protected void broadcastCcaConnectionsBetweenTwoPorts
        (CcaConnectionsBetweenTwoPortsEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.receivedCcaConnectionsBetweenTwoPorts(event);
         }

    }




    protected void broadcastLaunchGoOnOneComponent
                   (CcaCommandLaunchGoOnOneComponent commandGo) {
       LaunchGoOnOneComponentEvent event =
            new LaunchGoOnOneComponentEvent(this,commandGo);
        broadcastLaunchGoOnOneComponent(event);
    }

    protected void broadcastLaunchGoOnOneComponent
        (LaunchGoOnOneComponentEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.launchGoOnOneComponent(event);
         }

    }




    protected void broadcastLaunchGoOnAllComponents() {
      LaunchGoOnAllComponentsEvent event =
            new LaunchGoOnAllComponentsEvent(this);
        broadcastLaunchGoOnAllComponents(event);
    }

    protected void broadcastLaunchGoOnAllComponents
        (LaunchGoOnAllComponentsEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.launchGoOnAllComponents(event);
         }
    }


	protected void broadcastDisconnectTwoPorts(
			CcaConnectionBetweenTwoPorts ccaConnection) {
		CcaDisconnectTwoPortsEvent event = new CcaDisconnectTwoPortsEvent
		     (this,
			  ccaConnection);
		broadcastDisconnectTwoPorts(event);
	}
	protected void broadcastDisconnectTwoPorts(CcaDisconnectTwoPortsEvent event) {
		// loop through each listener and pass on the event if needed
		java.util.Vector listeners;
		synchronized (pythonControllerListeners) {
			listeners = (java.util.Vector) pythonControllerListeners.clone();
		}
		int numberOfListeners = listeners.size();
		for (int i = 0; i < numberOfListeners; i++) {
			PythonControllerListener x = (PythonControllerListener) listeners
					.elementAt(i);
			x.disconnectTwoPorts(event);
		}
	}


    protected void broadcastCloseComponent(String componentInstanceName) {
      CloseComponentEvent event =
            new CloseComponentEvent(this);
        broadcastCloseComponent(event);
    }

    protected void broadcastCloseComponent
        (CloseComponentEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.closeComponent(event);
         }
    }





    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    protected void broadcastPortParameters
            (String xmlPortParameters) {
      CcaPortParametersEvent event =
          new CcaPortParametersEvent
             (this,
              xmlPortParameters);
        broadcastPortParameters(event);
    }

    protected void broadcastPortParameters
        (CcaPortParametersEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.receivedPortParameters(event);
         }
    }


    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/




    protected void broadcastSetPortParameter
            (CcaPortParameterValue ccaPortParameterValue) {
      CcaPortParameterSetValueEvent event =
          new CcaPortParameterSetValueEvent
             (this,
              ccaPortParameterValue);
        broadcastSetPortParameter(event);
    }

    protected void broadcastSetPortParameter
        (CcaPortParameterSetValueEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.setPortParameterValue(event);
         }
    }




    protected void broadcastSetComponentProperty
            (CcaComponentPropertyValue ccaComponentPropertyValue) {
      CcaComponentPropertySetValueEvent event =
          new CcaComponentPropertySetValueEvent
             (this,
              ccaComponentPropertyValue);
        broadcastSetComponentProperty(event);
    }

    protected void broadcastSetComponentProperty
        (CcaComponentPropertySetValueEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.setComponentPropertyValue(event);
         }
    }




    protected void broadcastComponentProperty
            (CcaComponentPropertyValue ccaComponentPropertyValue) {
      CcaComponentPropertyValueEvent event =
          new CcaComponentPropertyValueEvent
             (this,
              ccaComponentPropertyValue);
        broadcastComponentProperty(event);
    }

    protected void broadcastComponentProperty
        (CcaComponentPropertyValueEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.receivedComponentPropertyValue(event);
         }
    }




    protected void broadcastComponentProperties
            (CcaComponentPropertyValue ccaComponentPropertyValues[]) {
      CcaComponentPropertyValuesEvent event =
          new CcaComponentPropertyValuesEvent
             (this,
              ccaComponentPropertyValues);
        broadcastComponentProperties(event);
    }

    protected void broadcastComponentProperties
        (CcaComponentPropertyValuesEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (pythonControllerListeners) {
            listeners = (java.util.Vector)pythonControllerListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             PythonControllerListener x =
                 (PythonControllerListener)listeners.elementAt(i);
             x.receivedComponentPropertyValues(event);
         }
    }


    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/











    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/



    /**
     * test the Framework
     */
    public void test(ClientSocket clientSocket) {

        /* Verify that this class sends PythonServer events. */
        /* Every time the PythonServer sends an event,       */
        /* print a message on the screen.                    */
        addPythonControllerListener
               (new MyPythonControllerListener());

        /* open a session with the cca server */
        System.out.print("OPENING session with cca server...");
        try {
            openSessionWithCcaServer(clientSocket);
        } catch (CanNotCommunicateWithCcaServerException e) {
            System.out.println(e);
            e.printStackTrace();
            return;
        }
        System.out.print("\n\n\n");


        ThreadWrite threadWrite = new ThreadWrite();
        threadWrite.start();

        try {
           threadWrite.join();
        }catch(java.lang.InterruptedException e){}


        writePython("print 'stop'");
        System.out.print("\n\n\n");

        System.out.print("CLOSING Session with cca server...");
        closeSessionWithCcaServer();
        System.out.print("\n\n\n");
    }



    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    class ThreadWrite implements Runnable {
        Thread thread = null;
        public void start() {
            if (thread!=null) return;
            thread = new Thread(this);
            thread.start();
        }
        public void stop() {
            thread = null;
        }
        public void join() throws java.lang.InterruptedException {
            thread.join();
        }
        public void yield() {
            //thread.yield();
        }

        public void run() {

            try {

                String resultSet;

                System.out.print("FIXING shared library...");
                fixSharedLibrary();
                System.out.println("FINISHED fixing shared library");
                System.out.print("\n\n\n");

                System.out.print("OPENING Framework...");
                openFramework();
                System.out.println("FINISHED opening Framework");
                System.out.print("\n\n\n");

                System.out.print("SETTING debug flag...");
                setDebugFlag(true);
                System.out.println("FINISHED setting debug flag");
                System.out.print("\n\n\n");


                //System.out.print("SETTING COMPONENT PATH\n");
                //String path = setPathToCcaComponents(".");
                //System.out.println
                //    ("FINISHED setting Path to cca components:");
                //System.out.println("     "+path);
                //System.out.println("\n\n\n");


                System.out.print("SETTING COMPONENT PATH\n");
                String paths[] = setPathsToCcaComponents
                                (new String[] {"."});
                int numberOfPaths = paths.length;
                System.out.println
                    ("FINISHED setting component path:");
                for (int i=0; i<numberOfPaths; i++)
                    System.out.println("     "+paths[i]);
                System.out.println("\n\n\n");

                System.out.print("LOADING StarterComponent class\n");
                String componentClassName =
                       loadComponentClass("StarterComponent");
                System.out.println("FINISHED loading StarterComponent:");
                System.out.println("    "+componentClassName);
                System.out.println("\n\n\n");

                System.out.print("LOADING PrinterComponent class\n");
                componentClassName =
                       loadComponentClass("PrinterComponent");
                System.out.println("FINISHED loading PrinterComponent:");
                System.out.println("    "+componentClassName);
                System.out.println("\n\n\n");

                System.out.print("LOADING TimeStamper class\n");
                componentClassName =
                       loadComponentClass("TimeStamper");
                System.out.println("FINISHED loading TimeStamper:");
                System.out.println("    "+componentClassName);
                System.out.println("\n\n\n");

                System.out.print("LOADING Timer class\n");
                componentClassName =
                       loadComponentClass("Timer");
                System.out.println("FINISHED loading Timer:");
                System.out.println("    "+componentClassName);
                System.out.println("\n\n\n");


                System.out.print("QUERY get names of classes\n");
                String componentClassNames[] = getComponentClassNames();
                int numberOfComponents = componentClassNames.length;
                System.out.println("FINISHED getting names of classes:");
                for (int i=0; i<numberOfComponents; i++)
                    System.out.println("     "+componentClassNames[i]);
                System.out.println("\n\n\n");

                instantiateCcaComponent
                            ("StarterComponent", //class name
                             "aStarter");        //instance name


                instantiateCcaComponent
                            ("PrinterComponent", //class name
                             "aPrinter");        //instance name

                instantiateCcaComponent
                            ("TimeStamper", //class name
                             "aStamper");   //instance name

                instantiateCcaComponent("Timer",   //class name
                                        "aTimer"); //instance name

                System.out.print("QUERY get all instances");
                CcaComponent ccaComponents[]
                      = getComponentInstances();
                System.out.println
                    ("FINISHED getting instantiated components");
                numberOfComponents = ccaComponents.length;
                for (int i=0; i<numberOfComponents; i++) {
                    printComponent(ccaComponents[i]);

                    System.out.println("\n");
                }
                System.out.println("\n\n\n");



                System.out.print("CONNECTING Stamper to Starter\n");
                CcaConnectionBetweenTwoPorts ccaConnection =
                    connectTwoPorts
                  ("aStamper", "in_port", "aStarter", "out0");
                System.out.println("FINISHED connecting Stamper to Starter");
                printConnection(ccaConnection);
                System.out.println("\n\n\n");

                System.out.print("CONNECTING Timer to Stamper\n");
                ccaConnection = connectTwoPorts
                   ("aTimer", "time_port", "aStamper", "time0");
                System.out.println("FINISHED connecting Timer to Stamper");
                printConnection(ccaConnection);
                System.out.println("\n\n\n");

                System.out.print("CONNECTING Printer to Stamper\n");
                ccaConnection = connectTwoPorts
                   ("aPrinter", "printer_port", "aStamper", "out0");
                System.out.println
                   ("FINISHED connecting Printer to Stamper");
                printConnection(ccaConnection);
                System.out.println("\n\n\n");

                System.out.print("QUERY get all connections");
                CcaConnectionBetweenTwoPorts ccaConnections[] =
                     getConnections();
                System.out.println("FINISHED retrieving all connections");
                int numberOfConnections = ccaConnections.length;
                for (int i=0; i< numberOfConnections; i++) {
                    printConnection(ccaConnections[i]);
                }
                System.out.print("\n\n\n");




                System.out.print("SET component property\n");
                CcaComponentPropertyValue ccaComponentPropertyValue =
                     setComponentProperty
                        ("aStamper",       //component name
                         "myProperty",     //property name
                         "My Property");   //property value
                System.out.println("\n");
                System.out.println(ccaComponentPropertyValue);
                System.out.print("\n\n\n");


                System.out.print("GET component property\n");
                ccaComponentPropertyValue = getComponentProperty
                        ("aStamper",       //component name
                         "gov.ccafe.instanceName"); //property name
                System.out.println("\n");
                System.out.println(ccaComponentPropertyValue);
                System.out.print("\n\n\n");


                System.out.print("GET component property\n");
                ccaComponentPropertyValue = getComponentProperty
                        ("aStamper",       //component name
                         "myProperty");    //property name
                System.out.println("\n");
                System.out.println(ccaComponentPropertyValue);
                System.out.print("\n\n\n");


                System.out.print("GET component properties\n");
                CcaComponentPropertyValue ccaComponentPropertyValues[] =
                    getComponentProperties
                        ("aStamper");       //component name
                System.out.println("\n");
                int numberOfProperties =
                    ccaComponentPropertyValues.length;
                for (int i=0; i<numberOfProperties; i++)
                    System.out.println(ccaComponentPropertyValues[i]);
                System.out.print("\n\n\n");



                System.out.print("RUN\n");
                CcaCommandLaunchGoOnOneComponent commandGo
                    = launchGoOnOneComponent("aStarter");
                System.out.println("FINISHED launching run");
                System.out.println("    "
                                   + commandGo.componentInstanceName
                                   + " "
                                   + commandGo.componentInstanceName);
                System.out.print("\n\n\n");

                System.out.print("RUN\n");
                commandGo = launchGoOnOneComponent("aStarter", "go_port");
                System.out.println("FINISHED launching run");
                System.out.println("    launched "
                                   + commandGo.componentInstanceName
                                   + " "
                                   + commandGo.componentInstanceName);
                System.out.print("\n\n\n");



                System.out.print("RUN\n");
                launchGoOnAllComponents();
                System.out.println("FINISHED launching run");
                System.out.println("    launched");
                System.out.print("\n\n\n");

                System.out.print("GET port parameters\n");
                String xmlPortParameters =
                    getPortParameters("aStamper", "configure_port");
                System.out.println("FINISHED getting port parameters");
                System.out.println(xmlPortParameters);
                System.out.println("\n\n\n");

                System.out.print("SET port parameter\n");
                CcaPortParameterValue ccaPortParameterValue =
                    setPortParameter
                       ("aStamper","configure_port","prefix","MST");
                System.out.println("FINISHED setting port parameter");
                System.out.println(ccaPortParameterValue);
                System.out.println("\n\n\n");

                System.out.print("SET port parameter\n");
                ccaPortParameterValue = setPortParameter
                       ("aStamper","configure_port","commie","true");
                System.out.println("FINISHED setting port parameter");
                System.out.println(ccaPortParameterValue);
                System.out.println("\n\n\n");

                System.out.print("SET port parameter\n");
                 ccaPortParameterValue = setPortParameter
                       ("aStamper","configure_port","dtest","0.0");
                System.out.println("FINISHED setting port parameter");
                System.out.println(ccaPortParameterValue);
                System.out.println("\n\n\n");

                System.out.print("SET port parameter\n");
                ccaPortParameterValue = setPortParameter
                       ("aStamper","configure_port","anything","goodbye");
                System.out.println("FINISHED setting port parameter");
                System.out.println(ccaPortParameterValue);
                System.out.println("\n\n\n");

                System.out.print("SET port parameter\n");
                ccaPortParameterValue = setPortParameter
                       ("aStamper","configure_port","utest","false");
                System.out.println("FINISHED setting port parameter");
                System.out.println(ccaPortParameterValue);
                System.out.println("\n\n\n");

                System.out.print("GET port parameters\n");
                xmlPortParameters =
                    getPortParameters("aStamper", "configure_port");
                System.out.println("FINISHED getting port parameters");
                System.out.println(xmlPortParameters);
                System.out.println("\n\n\n");

                System.out.print("DISCONNECTING Printer to Stamper\n");
                ccaConnection = disconnectTwoPorts
                   ("aPrinter", "printer_port", "aStamper", "out0");
                System.out.println
                   ("FINISHED dicconnecting Printer to Stamper");
                printDisconnection(ccaConnection);
                System.out.println("\n\n\n");

                System.out.print("DISCONNECTING Timer to Stamper\n");
                ccaConnection = disconnectTwoPorts
                   ("aTimer", "time_port", "aStamper", "time0");
                System.out.println
                   ("FINISHED disconnecting Timer to Stamper");
                printDisconnection(ccaConnection);
                System.out.println("\n\n\n");

                System.out.print("DISCONNECTING Stamper to Starter\n");
                ccaConnection =
                    disconnectTwoPorts
                  ("aStamper", "in_port", "aStarter", "out0");
                System.out.println
                    ("FINISHED disconnecting Stamper to Starter");
                printDisconnection(ccaConnection);
                System.out.println("\n\n\n");



                System.out.print("REMOVING Starter component\n");
                removeInstantiatedComponent("aStarter");
                System.out.println("FINISHED removing Starter");
                System.out.println("\n\n\n");

                System.out.print("REMOVING Printer component\n");
                removeInstantiatedComponent("aPrinter");
                System.out.println("FINISHED removing Printer");
                System.out.println("\n\n\n");

                System.out.print("REMOVING Timer component\n");
                removeInstantiatedComponent("aTimer");
                System.out.println("FINISHED removing Timer");
                System.out.println("\n\n\n");


                System.out.print("REMOVING Stamper component\n");
                removeInstantiatedComponent("aStamper");
                System.out.println("FINISHED removing Stamper");
                System.out.println("\n\n\n");



                System.out.print("CLOSING Printer component\n");
                String componentInstanceName = closeComponent("aPrinter");
                System.out.println("FINISHED closing "
                                  + componentInstanceName);
                System.out.println("\n\n\n");

                System.out.print("CLOSING Timer component\n");
                componentInstanceName = closeComponent("aTimer");
                System.out.println("FINISHED closing "
                                  + componentInstanceName);
                System.out.println("\n\n\n");

                System.out.print("CLOSING Stamper component\n");
                componentInstanceName = closeComponent("aStamper");
                System.out.println("FINISHED closing "
                                  + componentInstanceName);
                System.out.println("\n\n\n");

                System.out.print("CLOSING Framework\n");
                closeSessionWithCcaServer();
                System.out.println("FINISHED closeing framework");
                System.out.println("\n\n\n");


            }catch (CanNotCommunicateWithCcaServerException e) {
                System.out.println(e);
                e.printStackTrace();
            }catch (CanNotFixSharedLibraryException e) {
                System.out.println(e);
                e.printStackTrace();
            }catch (CanNotOpenCcaFrameworkException e) {
                System.out.println(e);
                e.printStackTrace();
            }catch (CanNotSetPathToCcaComponentsException e) {
                System.out.println(e);
                e.printStackTrace();
            }catch (CanNotLoadComponentException e) {
                System.out.println(e);
                e.printStackTrace();
            }catch (CanNotInstantiateComponentException e) {
                System.out.println(e);
                e.printStackTrace();
            } catch (CanNotConnectTwoPortsException e) {
                System.out.println(e);
                e.printStackTrace();
            } catch (CanNotLaunchGoCommandOnOneComponentException e) {
                System.out.println(e);
                e.printStackTrace();
            } catch (CanNotLaunchGoCommandOnAllComponentsException e) {
                System.out.println(e);
                e.printStackTrace();
            } catch (CanNotDisconnectTwoPortsException e) {
                System.out.println(e);
                e.printStackTrace();
            } catch (CanNotCloseComponentException e) {
                System.out.println(e);
                e.printStackTrace();
            } catch (CanNotRemoveInstantiatedComponentException e) {
                    System.out.println(e);
                    e.printStackTrace();;
            } catch (CanNotGetPortParametersException e){
                System.out.println(e);
                e.printStackTrace();
            } catch (CanNotSetPortParameterException e){
                System.out.println(e);
                e.printStackTrace();
            } catch (CanNotSetComponentPropertyException e) {
                System.out.println(e);
                e.printStackTrace();
            } catch (CanNotGetComponentPropertyException e) {
                System.out.println(e);
                e.printStackTrace();
            } catch (CanNotSetDebugFlagException e) {
                System.out.println(e);
                e.printStackTrace();
            }

        }//run






    /**
     * Instantiate a cca component.
     * @param className the class name of the instantiated component.
     * @param instanceName the instance name of the instantiated
              component.
     */
    protected void instantiateCcaComponent
         (String className,
          String instanceName)
          throws CanNotCommunicateWithCcaServerException,
                 CanNotInstantiateComponentException{

                //System.out.print("INSTANITATING " + instanceName + "\n");
                CcaComponent ccaComponent
                      = instantiateComponent
                            (className, //class name
                             instanceName);        //instance name
                //System.out.println
                //    ("FINISHED instantiating " + instanceName);

                printComponent(ccaComponent);

                //System.out.print("\n\n\n");

        }//run_InstantiateCcaComponent








    }//class


    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/




    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/

    class MyPythonControllerListener implements PythonControllerListener {

        public void fixSharedLibrary(FixSharedLibraryEvent event) {
            System.out.println("received FixedSharedLibraryEvent");
        }

        public void openCcaFramework(OpenCcaFrameworkEvent event) {
            System.out.println("received OpenCcaFrameworkEvent");
        }

        public void setPathToCcaComponents
               (SetPathToCcaComponentsEvent event) {
            System.out.println("received SetPathToCcaComponentsEvent");
        }

        public void setPathsToCcaComponents
               (SetPathsToCcaComponentsEvent event) {
            System.out.println("received SetPathsToCcaComponentsEvent");
        }

        public void loadComponent
               (LoadComponentEvent event) {
            System.out.println("received LoadComponentEvent");
        }

        public void receivedComponentClassNames
               (ComponentClassNamesEvent event) {
            System.out.println("received ComponentClassNamesEvent");
        }

        public void instantiateComponent
                (InstantiateComponentEvent event) {
            System.out.println("received InstantiateComponentEvent");
        }

        public void receivedComponentInstances
                (ComponentInstancesEvent event) {
            System.out.println("received ComponentInstancesEvent");
        }

        public void connectTwoPorts(CcaConnectTwoPortsEvent event) {
            System.out.println("received CcaConnectTwoPortsEvent");
        }

        public void receivedCcaConnectionsBetweenTwoPorts
          (CcaConnectionsBetweenTwoPortsEvent event){
            System.out.println
              ("received CcaConnectionsBetweenTwoPortsEvent");
        }


        public void launchGoOnOneComponent
            (LaunchGoOnOneComponentEvent event){
            System.out.println
               ("recieved LaunchGoOnOneComponentEvent");
        }

        public void launchGoOnAllComponents
            (LaunchGoOnAllComponentsEvent event){
            System.out.println
               ("recieved LaunchGoOnAllComponentsEvent");
        }

        public void disconnectTwoPorts(CcaDisconnectTwoPortsEvent event) {
            System.out.println("received CcaDisconnectTwoPortsEvent");
        }

        public void removeInstantiatedComponent
		    (RemoveInstantiatedComponentEvent event) {
        	System.out.println
			("received RemoveInstantiatedComponentEvent");
        }


        public void removeInstantiatedComponents
            (RemoveInstantiatedComponentsEvent event) {
            System.out.println
            ("received RemoveInstantiatedComponentsEvent");
}


        public void closeComponent(CloseComponentEvent event) {
            System.out.println
               ("recieved CloseComponentEvent");
        }

        public void closeCcaFramework(CloseCcaFrameworkEvent event) {
            System.out.println
               ("recieved CloseCcaFrameworkEvent");
        }


		public void receivedPortParameters(CcaPortParametersEvent event) {
			System.out.println
			    ("received CcaPortParametersEvent");
		}

        public void setPortParameterValue
            (CcaPortParameterSetValueEvent event) {
            System.out.println
               ("recieved CcaPortParameterSetValueEvent");
        }

        public void setComponentPropertyValue
        (CcaComponentPropertySetValueEvent event) {
        System.out.println
           ("recieved CcaComponentPropertySetValueEvent");
	    }

	    public void receivedComponentPropertyValue
	        (CcaComponentPropertyValueEvent event) {
	        System.out.println
	           ("recieved CcaComponentPropertyValueEvent");
	    }


	    public void receivedComponentPropertyValues
	        (CcaComponentPropertyValuesEvent event) {
	        System.out.println
	           ("recieved CcaComponentPropertyValuesEvent");
	    }



        public void setDebugFlag(SetDebugFlagEvent event) {
            System.out.println
               ("received SetDebugEvent");
       }

    }


    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    class ThreadRead implements Runnable {
        Thread thread = null;
        public void start() {
            if (thread!=null) return;
            thread = new Thread(this);
            thread.start();
        }
        public void stop() {
            thread = null;
        }
        public void join() throws java.lang.InterruptedException {
            thread.join();
        }
        public void yield() {
            //thread.yield();
        }
        public void run() {
            while(thread == Thread.currentThread()) {
                String oneLine = readPython();
                if (oneLine.equals("null")) {
                   try {thread.sleep(100);}catch (Exception e){}
                   continue;
                }
                if (oneLine.indexOf("<RESULT_SET:")!=-1) {
                    resultSet(oneLine);
                    //System.out.println("\n\n\n");
                }
                else {
                  //System.out.println("READ:"+oneLine);
                }

            }
        }
    }




    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    public PythonStub() {
    }




    /*-----------------------------------------------------------------*/
    /*-----------------------------------------------------------------*/


    public static void main(String args[]) {

        try {
			/* The name of the computer that contains the python server */
			String computerThatContainsPythonServer = "localhost";

			/* the port number that the python server is listening on */
			int portThatContainsPythonServer = 1236;

			/* create a clientSocket connection to the server */
			ClientSocket clientSocket = new ClientSocket();
			clientSocket.open
			        (computerThatContainsPythonServer,
			        portThatContainsPythonServer);

			/* create the framework */
			PythonStub pythonStub =new PythonStub();


			/* connect to the framework, create a run, execute the run */
			pythonStub.test(clientSocket);

		} catch (ConnectException e) {
			e.printStackTrace();
		}
    }
}
