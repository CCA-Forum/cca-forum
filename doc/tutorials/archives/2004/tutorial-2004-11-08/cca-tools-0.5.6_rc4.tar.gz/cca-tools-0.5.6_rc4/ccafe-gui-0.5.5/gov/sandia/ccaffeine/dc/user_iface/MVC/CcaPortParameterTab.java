package gov.sandia.ccaffeine.dc.user_iface.MVC;



/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * Sometimes, the data fields are grouped
 * into sets.  A client entity can display 
 * a set as a tabbed pane.  This class contains
 * the text that appears in the tab.
 */
public class CcaPortParameterTab {
    public String componentInstanceName = null;
    public String portInstanceName = null;
    public String dataFieldName = null;
    public String tabName = null;

    
    /**
     * Parse the xml contents of a tab that
     * is associated with a port parameter.
     * The parsed values are copied into the class's attributes.
     * <p>
     * The XML code will contains something like this: <br>
     * &lt;paramCurrent&gt; <br>
     * &nbsp;&lt;newParamTab&gt;<br>
     * &nbsp;&nbsp;&nbsp;name1 <br>
     * &nbsp;&nbsp;&nbsp;&lt;/componentInstanceName&gt; <br>
     * &nbsp;&lt;portInstanceName&gt;name2&lt;/portInstanceName&gt; <br>
     * &nbsp;&lt;dataFieldName&gt;name3&lt;/dataFieldName&gt; <br> 
     * &nbsp;&lt;tabName&gt;value1&lt;tabName&gt; <br>
     * &lt;newParamTabt&gt; <br>
     * @param xmlComponent The xml code of one component.
     */
    public CcaPortParameterTab(String xml) {

        /*
         * Extract out the contents of the following tags:
         *    component name
         *    port name
         *    field name
         *    tab name
         */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<componentInstanceName>(.*?)</componentInstanceName>\\s*"
           +"<portInstanceName>(.*?)</portInstanceName>\\s*"
           +"<dataFieldName>(.*?)</dataFieldName>\\s*"
           +"<tabName>(.*?)</tabName>");

        java.util.regex.Matcher matcher = pattern.matcher(xml);


        /* copy the contents of the 4 tags to our attributes */
        if (matcher.find()) {
            this.componentInstanceName = matcher.group(1);
            this.portInstanceName = matcher.group(2);
            this.dataFieldName = matcher.group(3);
            this.tabName = matcher.group(4);
        }
    }


}