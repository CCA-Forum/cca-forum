package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * An entity can use this event to
 * notify components that it wants
 * to get all of the instantiated cca components.
 * A view entity
 * might respond by rendering cca components
 * in the main workspace (the arena).  The end-user
 * can drag components to new locations, remove
 * components, draw lines between components,
 * view or edit the component's properties, etc.
 */
public class GetInstancesEvent extends EventObject {



    /**
     * Create a GetInstancesEvent.
     * An entity can use this event to
     * notify components that it wants
     * to get all of the instantiated cca components.
     * A view entity
     * might respond by rendering cca components
     * in the main workspace (the arena).  The end-user
     * can drag components to new locations, remove
     * components, draw lines between components,
     * view or edit the component's properties, etc.
     */
    public GetInstancesEvent(Object source) {
        super(source);
    }

}