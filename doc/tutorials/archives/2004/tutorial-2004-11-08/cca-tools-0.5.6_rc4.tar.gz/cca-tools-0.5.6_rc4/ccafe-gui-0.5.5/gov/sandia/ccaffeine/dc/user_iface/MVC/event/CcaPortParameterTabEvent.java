package gov.sandia.ccaffeine.dc.user_iface.MVC.event;


/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * Sometimes, the data fields are grouped
 * into sets.  This event can be used to notify
 * components that the cca server is sending the
 * name of such a set.
 * A client entity can display each set as a
 * tabbed pane.
 * <p>
 * This event is also used to notify components
 * that an entity wants to set the value of one of the
 * data fields.  A view entity might
 * respond by sending a "parameters" message
 * to the cca server.
 * <p>
 * Possible Scenario: <br>
 * An end-user clicks on a blue port inside of a component <br>
 * client sends "parameters" to server <br>
 * serer- sends "ParamDialog" to client <br>
 * client responds by creating an empty dialog box <br>
 * server sends "ParamTab" to client <br>
 * client responds by inserting a new tab in the dialog box <br>
 * server sends "ParamField" to client <br>
 * client responds by inserting a blank data line into the dialog box <br>
 * server sends "ParamCurrent" to client <br>
 * client responds by inserting the data's value into the dialog box <br>
 * server sends "ParamHelp" to client <br>
 * client responds by setting the text that is displayed if the help button is clicked <br>
 * server sends "ParamPrompt" to client <br>
 * client responds by displaying a prompt to the left of the data's value <br>
 * server sends "ParamDefault" to client <br>
 * client responds by setting the data's default value <br>
 * server sends "ParamStringChoice" to client <br>
 * client responds by setting an item in the value's choice box <br>
 * server sends "ParamNumberRange" to client <br>
 * client responds by setting the data value's range of allowed values <br>
 * server sends  "ParamEndDialog" to client <br>
 * client responds by displaying the dialog box on the screen <br>
 */

import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPortParameterTab;

public class CcaPortParameterTabEvent 
       extends java.util.EventObject {

    CcaPortParameterTab ccaPortParameterTab = null;

    public CcaPortParameterTab
           getCcaPortParameterTab() {
              return(this.ccaPortParameterTab);
    }

    public void setCcaPortParameterTab
        (CcaPortParameterTab ccaPortParameterTab) {
        this.ccaPortParameterTab = ccaPortParameterTab;
    }

    public CcaPortParameterTabEvent(Object source) {
        super(source);
        this.ccaPortParameterTab = null;
    }

    public CcaPortParameterTabEvent
           (Object source,
            CcaPortParameterTab ccaPortParameterTab) {
        super(source);
        this.ccaPortParameterTab = ccaPortParameterTab;
    }
}
