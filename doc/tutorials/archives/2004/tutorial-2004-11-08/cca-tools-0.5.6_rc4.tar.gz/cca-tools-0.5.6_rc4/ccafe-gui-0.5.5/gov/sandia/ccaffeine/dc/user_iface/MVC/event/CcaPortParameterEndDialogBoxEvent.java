package gov.sandia.ccaffeine.dc.user_iface.MVC.event;


/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * This event can be used to notify components
 * that the cca server has finished sending information
 * for all the data fields in a port.  A client
 * entity might respond by displaying a dialog box
 * that was already populated with information
 * from all the data fields.
 * <p>
 * Possible Scenario: <br>
 * An end-user clicks on a blue port inside of a component <br>
 * client sends "parameters" to server <br>
 * serer- sends "ParamDialog" to client <br>
 * client responds by creating an empty dialog box <br>
 * server sends "ParamTab" to client <br>
 * client responds by inserting a new tab in the dialog box <br>
 * server sends "ParamField" to client <br>
 * client responds by inserting a blank data line into the dialog box <br>
 * server sends "ParamCurrent" to client <br>
 * client responds by inserting the data's value into the dialog box <br>
 * server sends "ParamHelp" to client <br>
 * client responds by setting the text that is displayed if the help button is clicked <br>
 * server sends "ParamPrompt" to client <br>
 * client responds by displaying a prompt to the left of the data's value <br>
 * server sends "ParamDefault" to client <br>
 * client responds by setting the data's default value <br>
 * server sends "ParamStringChoice" to client <br>
 * client responds by setting an item in the value's choice box <br>
 * server sends "ParamNumberRange" to client <br>
 * client responds by setting the data value's range of allowed values <br>
 * server sends  "ParamEndDialog" to client <br>
 * client responds by displaying the dialog box on the screen <br>
 */

import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPortParameterEndDialogBox;

public class CcaPortParameterEndDialogBoxEvent 
       extends java.util.EventObject {

    CcaPortParameterEndDialogBox ccaPortParameterEndDialogBox = null;

    public CcaPortParameterEndDialogBox
           getCcaPortParameterEndDialogBox() {
              return(this.ccaPortParameterEndDialogBox);
    }

    public void setCcaPortParameterEndDialogBox
        (CcaPortParameterEndDialogBox ccaPortParameterEndDialogBox) {
        this.ccaPortParameterEndDialogBox = ccaPortParameterEndDialogBox;
    }

    public CcaPortParameterEndDialogBoxEvent(Object source) {
        super(source);
        this.ccaPortParameterEndDialogBox = null;
    }

    public CcaPortParameterEndDialogBoxEvent
           (Object source,
            CcaPortParameterEndDialogBox ccaPortParameterEndDialogBox) {
        super(source);
        this.ccaPortParameterEndDialogBox = ccaPortParameterEndDialogBox;
    }
}