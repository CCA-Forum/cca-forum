package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;

public class CmdActionCCAShell
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCAShell() {
  }


  public String argtype() {
    return "A";
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
  return
      "On cplant: does nothing on cplant public access demo.\n"
      +"On other machines:  executes shell commands (no globbing, though)";
  }


  private static final String[] namelist = {"shell","system"};


  public void doIt(CmdContext cc, Vector args) {

      /* the number of arguments in the "shell" command */
      int numberOfArguments = args.size();

      /* The command that is to be executed */
      String command = null;
      if (numberOfArguments>0) {
          StringBuffer buffer = new StringBuffer((String)args.get(0));
          for (int i=1; i<numberOfArguments; i++) {
              buffer.append(" ");
              buffer.append( (String) args.get(i));
          }
          command = buffer.toString();
      }


      this.broadcastShell
          (numberOfArguments,
           command);
  }

}
