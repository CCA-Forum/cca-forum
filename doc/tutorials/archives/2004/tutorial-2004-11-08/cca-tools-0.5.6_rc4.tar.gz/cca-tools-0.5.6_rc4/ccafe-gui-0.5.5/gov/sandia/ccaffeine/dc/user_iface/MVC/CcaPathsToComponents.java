package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CcaPathsToComponents {

    public String paths[] = new String[0];

    /**
     * Parse the xml contents of a component.
     * The parsed values are copied into the class's attributes.
     * <p>
     * The XML code will contains something like this: <br>
     * &nbsp;&nbsp;&lt;paths&gt;
     * &nbsp;&nbsp;&nbsp;&nbsp;&lt;path&gt;path1&lt;/path&gt;
     * &nbsp;&nbsp;&nbsp;&nbsp;&lt;path&gt;path2&lt;/path&gt;
     * &nbsp;&nbsp;&nbsp;&nbsp;&lt;path&gt;path3&lt;/path&gt;
     * &nbsp;&nbsp;&lt;/paths&gt;
     */
     public CcaPathsToComponents(String xmlPaths) {

        /* We will store our extracted paths here */
        java.util.Vector vector = new java.util.Vector();

        /*
         * Extract out the contents of one or more paths
         */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<path>(.*?)</path>");
        java.util.regex.Matcher matcher =
                pattern.matcher(xmlPaths);


        /* extract the ports and store them in our vector */
        while (matcher.find()) {
            vector.add(matcher.group(1));
        }

        /* how many paths did we extract from the xml file? */
        int numberOfPaths = vector.size();


        /* copy the vector into the paths array */
        this.paths = new String[numberOfPaths];
        vector.copyInto(paths);

     }
}