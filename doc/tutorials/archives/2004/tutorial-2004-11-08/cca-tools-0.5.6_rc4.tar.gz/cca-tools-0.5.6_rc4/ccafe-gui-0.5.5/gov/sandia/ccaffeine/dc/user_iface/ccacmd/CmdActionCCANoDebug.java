package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.util.LocalSystem;
import gov.sandia.ccaffeine.dc.user_iface.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;

public class CmdActionCCANoDebug
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCANoDebug() {
  }


  public String argtype() {
    return "";
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
    return "turns off debugging print statements.";
  }


  private static final String[] namelist = {"nodebug","quiet"};


  public void doIt(CmdContext cc, Vector args) {

      this.broadcastSetNoDebug();

  }

}
