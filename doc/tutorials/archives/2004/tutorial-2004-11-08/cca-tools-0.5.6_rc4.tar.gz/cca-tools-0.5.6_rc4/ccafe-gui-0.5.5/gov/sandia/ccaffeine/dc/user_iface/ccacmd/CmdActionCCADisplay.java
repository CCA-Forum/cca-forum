package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;


public class CmdActionCCADisplay
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCADisplay() {
  }


  public String argtype() {
    return "Si";
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
    return
"display pallet\n"+
"       - show what is in the pallet currently.\n"+
"display arena\n"+
"       - show what is in the arena currently.\n"+
"display component <component instance name>\n"+
"       - show the ports and class name associated with a component\n"+
"display chain <component instance name>\n"+
"       - show the connections associated with a particular component instance"+
"display state\n"+
"       - equivalent to \"display arena\" and then \"display chain\"\n";

  }


  private static final String[] namelist = {"display"};


  public void doIt(CmdContext cc, Vector args) {

    /*
     * The number of arguments
     * in the request string.
     */
    int numberOfArguments = args.size();

    /*
     * We are requesting info
     * on which entity?  We can
     * request info on the PALETTE,
     * ARENA, CHAIN, COMPONENT,
     * STATE.
     */
    String entity = null;
    if (numberOfArguments>0)
      entity = (String) args.get(0);

    /*
     * If an entity wants some info on
     * a particular component, then that
     * entity has to supply the name of
     * the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     */
    String componentInstanceName = null;
    if (numberOfArguments>1)
        componentInstanceName = (String)args.get(1);


    this.broadcastDisplay
        (numberOfArguments,
         entity,
         componentInstanceName);
  }



}
