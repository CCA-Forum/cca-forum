
package gov.sandia.ccaffeine.dc.user_iface.MVC.event;


import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaComponent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPort;



public class RemoveInstantiatedComponentEvent extends java.util.EventObject {


    /**
     * instance name of the removed component
     */
    protected String instanceName = null;

    /**
     * Get the instance name of the removed component
     * @return instance name of the revmoed component
     */
    public String getInstanceName() {
        return(instanceName);
    }

    /**
     * Set the instance name of the removed component
     * @param instanceName instance name of the removed component
     */
    public void setInstanceName(String instanceName) {
        this.instanceName = instanceName;
    }







    /**
     * Create an  RemoveInstantiatedComponentEvent.
     * @param source The entity that created this event.
     */
    public RemoveInstantiatedComponentEvent(Object source) {
        super(source);
        this.instanceName = null;
    }

    /**
     * Create an  RemoveInstantiatedComponentEvent.
     * @param source The entity that created this event.
     * @param instanceName the instance name of the removed 
     * component.
     * component.
     */
    public RemoveInstantiatedComponentEvent
           (Object source,
            String instanceName) {
        super(source);
        this.instanceName = instanceName;
    }

}
