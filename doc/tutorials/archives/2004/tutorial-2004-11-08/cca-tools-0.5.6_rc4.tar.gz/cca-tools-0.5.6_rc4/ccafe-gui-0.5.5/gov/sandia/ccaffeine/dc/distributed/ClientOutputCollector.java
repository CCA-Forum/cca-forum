package gov.sandia.ccaffeine.dc.distributed;

import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;

/** Multiplexes Server IO with multiply connected clients.  Reads
    lines of text from the clients and compresses output by
    comparison. */				 
						 
interface ClientOutputCollector extends OutOfBandListener {
    public void computeClientOutput(ClientOutputEvent evt);
    public void controllerClientOutput(ClientOutputEvent evt);
    public void setClientOutputRelay( ClientOutputRelay cR);
}						 
