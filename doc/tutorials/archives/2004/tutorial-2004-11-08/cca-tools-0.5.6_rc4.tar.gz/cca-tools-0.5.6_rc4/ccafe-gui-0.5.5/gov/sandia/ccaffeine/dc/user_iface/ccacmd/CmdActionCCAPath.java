package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;

public class CmdActionCCAPath
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCAPath() {
  }


  public String argtype() {
    return "ss";
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
    return
        "path init\n"
        +"       - set framework path from env(CCA_COMPONENT_PATH).\n"
        +"    path append <directory>\n"
        +"       - add directory to path.\n"
        +"    path prepend <directory>\n"
        +"       - insert directory before path.\n"
        +"    path set\n"
        +"       - replace path. format input as env()\n"
        +"    path\n"
        +"       - show path";
  }


  private static final String[] namelist = {"path"};


  public void doIt(CmdContext cc, Vector args) {

      /*
       * The number of arguments
       * in the path command.
       */
      int numberOfArguments = args.size();

    /*
     * ITo alter the path,
     * specify how the path
     * is to be changed by
     * issuing
     * any of the following commands:
     * INIT, APPEND, PREPEND, SET
     */
     String commandToAlterPath = null;
     if (numberOfArguments>0)
         commandToAlterPath = (String)args.get(0);

    /**
     * To alter path,
     * specify the value
     * of the new path.
     */
    String directory = null;
    if (numberOfArguments>1)
        directory = (String)args.get(1);

    this.broadcastPath
        (numberOfArguments,
         commandToAlterPath,
         directory);
  }

}
