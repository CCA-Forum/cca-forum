package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;

public class CmdActionCCARemove
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCARemove() {
  }


  public String argtype() {
    return "i";
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
    return "remove <component instance name>";

  }


  private static final String[] namelist = {"remove"};


  public void doIt(CmdContext cc, Vector args) {

      /*
       * The number of arguments in the "remove" command.
       */
      int numberOfArguments = args.size();


      /**
       * The name of the component that was removed.
       * The name is usually the java class name of the component
       * (without the package name) concatenated with an index number.
       * Example:  "StartComponent0"
       */
      String componentInstanceName = null;
      if (numberOfArguments > 0)
          componentInstanceName = (String)args.get(0);

      this.broadcastRemove(componentInstanceName);

  }
}
