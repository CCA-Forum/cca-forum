package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Used to notify components that the cca server
 * added a new class that can be used to instantiate
 * cca components.  A view entity might
 * respond by rendering a box inside of a palette.
 * <p>
 * Possible Scenario <br>
 * A client establishes a communication link with the cca server <br>
 * The cca server sends the class of cca component to the client <br>
 * The client displays the class in the palette. <br>
 */

public class AddComponentClassEvent extends EventObject {

    /*
    The name of the newly added class.
    The name is actually the name of the component's
    java class.
    EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
    */
    String className = null;


    /**
     * Get the name of the newly added class.
     * The name is actually the name of the component's
     * java class.  For exmaple, the name could be
     * "gov.sandia.ccaffeine.dc.component.PrinterComponent"
     * @return The name of the newly added class.
     */
    public String getClassName() {
        return(className);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Create an AddComponentClassEvent.
     * Can be used to notify components that
     * the cca server has added a new class.
     * The class can be used to instantiate
     * new cca components.
     * @param source The entity that created this event.
     * @param className The name of the newly added class.
     * The name is actually the name of the component's
     * java class.  For example, the name could be
     * "gov.sandia.ccaffeine.dc.component.PrinterComponent"
     */
    public AddComponentClassEvent
           (Object source,
            String className) {

         super(source);
         this.className = className;
    }

}