package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Used to notify components
 * that an entity wants to
 * delete all components.
 * A view might respond by
 * removing all components from
 * the main workspace (the arena).
 */

public class NukeAllEvent extends EventObject {

    /*
     * The number of arguments in the nuke command
     */
    protected int numberOfArguments = 0;


    /**
     * Retrieve the number of arguments in the nuke command.
     * @return The number of arguments in the nuke command.
     */
    public int getNumberOfArguments() {
        return(this.numberOfArguments);
    }

    /**
     * The entity that is to be removed.
     * NOTE:  As of Oct 2003, "all" is the
     * only entity that can be nuked.
     */
    protected String entity = null;


    /**
     * Get the entity that is to be removed.
     * NOTE:  As of Oct 2003, "all" is the
     * only entity that can be nuked.
     */
    public String getEntity() {
        return(this.entity);
    }

   /**
    * Create a NukeEvent.
    * The event can be
    * used to notify components
    * that an entity wants to
    * delete all components.
    * A view might respond by
    * sending a "nuke all" message
    * to the cca server.
    * @param source The entity that created
   * this event.
   */
    public NukeAllEvent(Object source) {
        super(source);
        this.entity = "all";
        this.numberOfArguments = 1;
    }



   /**
    * Create a NukeEvent.
    * The event can be
    * used to notify components
    * that an entity wants to
    * delete all components.
    * A view might respond by
    * sending a "nuke all" message
    * to the cca server.
    * @param source The entity that created
    * this event.
    * @param entity
    * The entity that is to be removed.
    * NOTE:  As of Oct 2003, "all" is the
    * only entity that can be nuked.
    */
    public NukeAllEvent
           (Object source,
            String entity) {
        super(source);
        this.entity = entity;
        this.numberOfArguments = 1;
    }


   /**
    * Create a NukeEvent.
    * The event can be
    * used to notify components
    * that an entity wants to
    * delete all components.
    * A view might respond by
    * removing all components from
    * the main workspace (the arena).
    * @param source The entity that created
    * this event.
    * @param numberOfArguments The number of
    * arguments in the nuke command.
    * @param entity
    * The entity that is to be removed.
    * NOTE:  As of Oct 2003, "all" is the
    * only entity that can be nuked.
    */
    public NukeAllEvent
           (Object source,
            int numberOfArguments,
            String entity) {
        super(source);
        this.numberOfArguments = numberOfArguments;
        this.entity = entity;
        this.numberOfArguments = 1;
    }


}