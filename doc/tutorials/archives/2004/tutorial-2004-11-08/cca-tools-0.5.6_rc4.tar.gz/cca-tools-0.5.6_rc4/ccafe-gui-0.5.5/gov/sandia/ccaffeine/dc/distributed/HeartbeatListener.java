package gov.sandia.ccaffeine.dc.distributed;

import java.util.EventListener;

/**
HeartbeatListeners can listen for heartbeats.
 */

public interface HeartbeatListener extends EventListener {
    public void receivedHeartbeat(HeartbeatEvent event);
    public void didNotReceiveHeartbeat(HeartbeatEvent event);
}
