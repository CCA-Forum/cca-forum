package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotConnectTwoPortsException extends Exception {

    public CanNotConnectTwoPortsException() {
       super();
    }

    public CanNotConnectTwoPortsException(String message) {
       super(message);
    }

}