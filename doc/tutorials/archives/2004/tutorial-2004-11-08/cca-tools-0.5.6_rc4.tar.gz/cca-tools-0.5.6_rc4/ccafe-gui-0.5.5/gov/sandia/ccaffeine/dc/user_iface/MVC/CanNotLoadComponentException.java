package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotLoadComponentException extends Exception {

    public CanNotLoadComponentException() {
        super();
    }



    public CanNotLoadComponentException(String message) {
        super(message);
    }
}