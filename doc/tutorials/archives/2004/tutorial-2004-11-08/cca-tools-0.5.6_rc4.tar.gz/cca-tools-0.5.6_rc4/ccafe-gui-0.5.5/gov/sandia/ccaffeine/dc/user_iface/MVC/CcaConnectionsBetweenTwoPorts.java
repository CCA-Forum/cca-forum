package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CcaConnectionsBetweenTwoPorts {

    public CcaConnectionBetweenTwoPorts ccaConnections[] = null;

    /**
     * Parse the xml contents of a component.
     * The parsed values are copied into the class's attributes.
     * <p>
     * The XML code will contains something like this: <br>
     * &nbsp;&lt;connection&gt; <br>
     * &nbsp;&nbsp;&lt;providesServiceComponentName&gt; <br>
     * &nbsp;&nbsp;&nbsp;providerComponentName <br>
     * &nbsp;&ngsp;&lt;/providesServiceComponentName&gt; <br>
     * &nbsp;&nbsp;&lt;providesServicePortName&gt; <br>
     * &nbsp;&nbsp;&nbsp;providerPortName <br>
     * &nbsp;&ngsp;&lt;/providesServicePortName&gt; <br>
     * &nbsp;&nbsp;&lt;usesServiceComponentName&gt; <br>
     * &nbsp;&nbsp;&nbsp;userComponentName <br>
     * &nbsp;&ngsp;&lt;/usesServiceComponentName&gt; <br>
     * &nbsp;&nbsp;&lt;usesServicePortName&gt; <br>
     * &nbsp;&nbsp;&nbsp;userPortName <br>
     * &nbsp;&ngsp;&lt;/usesServicePortName&gt; <br>
     * &nbsp;&lt;/connection&gt; <br>
     * &nbsp;&lt;connection&gt; <br>
     * &nbsp;&nbsp;&lt;providesServiceComponentName&gt; <br>
     * &nbsp;&nbsp;&nbsp;providerComponentName <br>
     * &nbsp;&ngsp;&lt;/providesServiceComponentName&gt; <br>
     * &nbsp;&nbsp;&lt;providesServicePortName&gt; <br>
     * &nbsp;&nbsp;&nbsp;providerPortName <br>
     * &nbsp;&ngsp;&lt;/providesServicePortName&gt; <br>
     * &nbsp;&nbsp;&lt;usesServiceComponentName&gt; <br>
     * &nbsp;&nbsp;&nbsp;userComponentName <br>
     * &nbsp;&ngsp;&lt;/usesServiceComponentName&gt; <br>
     * &nbsp;&nbsp;&lt;usesServicePortName&gt; <br>
     * &nbsp;&nbsp;&nbsp;userPortName <br>
     * &nbsp;&ngsp;&lt;/usesServicePortName&gt; <br>
     * &nbsp;&lt;/connection&gt; <br>
     */
     public CcaConnectionsBetweenTwoPorts(String xmlConnections) {

        /* We will store our extracted paths here */
        java.util.Vector vector = new java.util.Vector();

        /*
         * Extract out the contents of one or more paths
         */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<connection>(.*?)</connection>");
        java.util.regex.Matcher matcher =
                pattern.matcher(xmlConnections);


        /* extract the ports and store them in our vector */
        while (matcher.find()) {
            vector.add(matcher.group(1));
        }

        /* how many connections did we extract from the xml file? */
        int numberOfConnections = vector.size();


        /* copy the vector into the connections array */
        this.ccaConnections = 
            new CcaConnectionBetweenTwoPorts[numberOfConnections];
        vector.copyInto(this.ccaConnections);

     }
}