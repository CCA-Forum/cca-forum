package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

public class LoadComponentEvent extends java.util.EventObject {


    String componentClassName = null;


    /**
     * Get the class name of the loaded component.
     * @return The class name of the loaded component.
     */
    public String getComponentClassName() {
        return(this.componentClassName);
    }


    /**
     * Set the class name of the loaded component.
     * @param componentClassName The class name of the loaded component.
     */
    public void setComponentClassName(String componentClassName) {
        this.componentClassName = componentClassName;
    }



    /**
     * Create a LoadComponentEvent.
     * @param source The entity that created this event.
     */
    public LoadComponentEvent(Object source) {
        super(source);
        this.componentClassName = null;
    }

    /**
     * Create a LoadComponentEvent.
     * @param source The entity that created this event.
     * @param componentClassName The class name of the loaded component.
     */
    public LoadComponentEvent(Object source,
                              String componentClassName) {
        super(source);
        this.componentClassName = componentClassName;
    }





}