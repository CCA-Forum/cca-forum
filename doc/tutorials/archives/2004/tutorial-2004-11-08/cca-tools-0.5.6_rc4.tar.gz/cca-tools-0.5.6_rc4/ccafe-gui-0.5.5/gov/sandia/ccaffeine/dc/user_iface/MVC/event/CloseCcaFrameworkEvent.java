package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

public class CloseCcaFrameworkEvent extends java.util.EventObject {



    /**
     * Create a CloseCcaFrameworkEvent.
     * @param source The entity that created this event.
     */
    public CloseCcaFrameworkEvent(Object source) {
        super(source);
    }






}