package gov.sandia.ccaffeine.dc.distributed;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;


/** The main out of band listener for the ServerMux, this class
    sets the dataCollector instance on the Servermux and handles 
    shutdown and remove client messages */
class ServerOutOfBandListener implements OutOfBandListener {
    private ServerMux server;
    ServerOutOfBandListener(ServerMux server) 
    {
	this.server = server;
    }
  /** Process the out of band message sent to a Client.  The String
      cmd does not include the out of band token that originally
      indicated the presence of the out of band command. */
  public void processOutOfBand(OutOfBandEvent evt)
    {
	String str = evt.getOutOfBandCommand();
	Client src = (Client) evt.getSource();

	if (str.startsWith(ServerMux.DATA_COLLECTOR_MSG)) {
	    // from after the = to just before the >>
	    String className = str.substring(ServerMux.DATA_COLLECTOR_MSG.length());
	    server.setDataCollectorByName(className);
	    src.write(MessageData.makeOutOfBandMessage(ServerMux.SERVER_SRC, 
						       ServerMux.DATA_COLLECTOR_ACK));
	    
	} else if (str.startsWith(ServerMux.SHUTDOWN_MSG)) {
	    LocalSystem.out.println("Got shutdown message for server");
	    server.shutdown();
	}else if (str.startsWith(ServerMux.REMOVE_CLIENT_MSG)) {
	    src.disconnect();

        /* 
        The GUI client is no longer sending heartbeats to the muxer.
        Shutdown the server.
        */
	}else if (str.startsWith(ServerMux.DID_NOT_RECEIVE_HEARTBEAT_FROM_GUI_CLIENT)) {
            LocalSystem.out.println("GUI client no longer sending heartbeats to Muxer.");
            LocalSystem.out.println("I will now shut down the server.");
            server.shutdown();
        }


	else
	    return;
    }
}
