package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUI;

/**
 * CmdActionGUIParamDefault.java
 *
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * The cca server is sending the default value
 * of one of these data fields.  A view entity
 * might respond by checking the state of a
 * data field; if the data field does not have
 * a current value then the default value is
 * displayed on the screen.
 * <p>
 * Possible Scenario: <br>
 * An end-user clicks on a blue port inside of a component <br>
 * client sends "parameters" to server <br>
 * serer- sends "ParamDialog" to client <br>
 * client responds by creating an empty dialog box <br>
 * server sends "ParamTab" to client <br>
 * client responds by inserting a new tab in the dialog box <br>
 * server sends "ParamField" to client <br>
 * client responds by inserting a blank data line into the dialog box <br>
 * server sends "ParamCurrent" to client <br>
 * client responds by inserting the data's value into the dialog box <br>
 * server sends "ParamHelp" to client <br>
 * client responds by setting the text that is displayed if the help button is clicked <br>
 * server sends "ParamPrompt" to client <br>
 * client responds by displaying a prompt to the left of the data's value <br>
 * server sends "ParamDefault" to client <br>
 * client responds by setting the data's default value <br>
 * server sends "ParamStringChoice" to client <br>
 * client responds by setting an item in the value's choice box <br>
 * server sends "ParamNumberRange" to client <br>
 * client responds by setting the data value's range of allowed values <br>
 * server sends  "ParamEndDialog" to client <br>
 * client responds by displaying the dialog box on the screen <br>
 */

public class CmdActionGUIParamDefault
      extends CmdActionGUI
      implements CmdAction {

    public CmdActionGUIParamDefault() {
    }
    public String argtype(){
	return "ISSA";
    }

    public String[] names(){
	return namelist;
    }

    public String help(){
	return "sets the default value of the current data field.";
    }

    private static final String[] namelist = {"paramDefault"};

    public void doIt(CmdContext cc, Vector args) {

      /*
       * Cca components contain ports.
       * Some of the ports contain data fields.
       * The cca server is sending the default value
       * of one of these data fields.  A view entity
       * might respond by checking the state of a
       * data field; if the data field does not have
       * a current value then the default value is
       * displayed on the screen.
       */

	CmdContextGUI ccg = (CmdContextGUI)cc;

       /*
        * The name of the cca component that contains
        * the port which contains the data field.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = (String)args.get(0);

       /**
        * The instance name of the port.
        * The name is usually the name of the port's class
        * (without the package name).
        *  Example: "configure_port"
        */
        String portInstanceName = (String)args.get(1);

       /**
        * The name of the data field.
        */
        String dataFieldName = (String)args.get(2);

       /*
        * The default value of the data field.
        */
       String dataFieldDefaultValue = (String)args.get(3);

	//String hashKey = componentInstance + ":" + portInstance;

	//ConfigureDialog dialog = global.getConfigureDialog(hashKey);
	//dialog.setDefaultValue(name, defaultValue);
        this.broadcastParamDefault
            (componentInstanceName,
             portInstanceName,
             dataFieldName,
             dataFieldDefaultValue);

    } // doIt

} // CmdActionGUIParamDefault
