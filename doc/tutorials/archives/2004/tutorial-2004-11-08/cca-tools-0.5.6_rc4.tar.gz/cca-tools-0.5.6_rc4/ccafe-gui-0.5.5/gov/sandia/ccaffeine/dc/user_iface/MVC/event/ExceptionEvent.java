package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

/**
 * This event can be used to notify entities
 * that an exception was thrown.
 */

public class ExceptionEvent extends java.util.EventObject {


    protected java.lang.Throwable exception = null;


    /**
     * Retrieve the exception.
     * @return The Exception
     */
    public java.lang.Throwable getException() {
        return(this.exception);
    }

    public ExceptionEvent
           (Object source,
            Exception exception) {

        super(source);
        this.exception = exception;
    }

}