package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotCloseComponentException extends Exception {

  public CanNotCloseComponentException() {
      super();
  }

  public CanNotCloseComponentException(String message) {
      super(message);
  }


}