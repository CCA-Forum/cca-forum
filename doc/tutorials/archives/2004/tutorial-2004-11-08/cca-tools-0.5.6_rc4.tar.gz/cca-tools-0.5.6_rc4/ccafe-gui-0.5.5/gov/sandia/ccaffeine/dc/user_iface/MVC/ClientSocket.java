package gov.sandia.ccaffeine.dc.user_iface.MVC;

import gov.sandia.ccaffeine.dc.user_iface.applet.RemoteServer;

public class ClientSocket {


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /* input stream from the cca server */
    protected java.io.InputStream inputStream = null;
    protected java.io.LineNumberReader lineNumberReader = null;

    /* output stream to the cca server */
    protected java.io.OutputStream outputStream = null;
    protected java.io.PrintStream printStream = null;

    /* the client socket that is connected to the cca server */
    protected java.net.Socket socket = null;

    protected Object lockRead = new Object();
    protected Object lockWrite = new Object();


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Create a ClientSocket.
     */
    public ClientSocket() {
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Open a connection link to the cca server.
     * @param nameOfServerMachine The name of the machine
     * that contains the cca server.
     * @param port The port number that the cca server is
     * using to provide services
     * @throws java.net.ConnectException Thrown if we can not
     * establish a connection with the cca server.
     */
    synchronized public void open
                 (String nameOfServerMachine,
                  int port)
                  throws java.net.ConnectException {

        openAndSetTimeout(nameOfServerMachine, port, 0);
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Open a connection link to the cca server.
     * @param nameOfServerMachine The name of the machine
     * that contains the cca server.
     * @param port The port number that the cca server is
     * using to provide services
     * @throws java.net.ConnectException Thrown if we can not
     * establish a connection with the cca server.
     */
    synchronized public void openAndSetTimeout
                 (String nameOfServerMachine,
                  int port,
                  int timeout)
                  throws java.net.ConnectException {

        close();

        RemoteServer client = new RemoteServer();
        client.setHost(nameOfServerMachine);
        client.setPort(port);
        client.setTimeout(timeout);
        client.createConnection();
        this.inputStream = client.getInputStream();
        this.lineNumberReader =
            new java.io.LineNumberReader
            (new java.io.InputStreamReader
             (this.inputStream));
        this.outputStream = client.getOutputStream();
        this.printStream =
            new java.io.PrintStream(this.outputStream, true);

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Open a connection link to the cca server.
     * @param nameOfServerMachine The name of the machine
     * that contains the cca server.
     * @param port The port number that the cca server is
     * using to provide services
     * @throws java.net.ConnectException Thrown if we can not
     * establish a connection with the cca server.
     */
    synchronized public void open
                 (java.io.InputStream inputStream,
                  java.io.OutputStream outputStream){

        close();

        this.socket = null;

        this.inputStream = inputStream;
        this.lineNumberReader =
            new java.io.LineNumberReader
            (new java.io.InputStreamReader
             (this.inputStream));

        this.outputStream = outputStream;
        this.printStream =
            new java.io.PrintStream(this.outputStream, true);

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Close the communication link with the cca server.
     */
    public void close() {

        if (this.printStream!=null){
          this.printStream.flush();
          this.printStream.close();
          this.printStream = null;
          try {this.outputStream.close();} catch(java.io.IOException e){}
          this.outputStream = null;
        }
        if (this.outputStream!=null) {
          try {this.outputStream.flush();} catch(java.io.IOException e){}
          try {this.outputStream.close();} catch(java.io.IOException e){}
          this.outputStream = null;
        }

        if (this.lineNumberReader!=null) {
            try {this.lineNumberReader.close();} catch(java.io.IOException e){}
            this.lineNumberReader = null;
            try {this.inputStream.close();} catch(java.io.IOException e){}
            this.inputStream = null;
        }
        if (this.inputStream!=null) {
            try {this.inputStream.close();} catch(java.io.IOException e){}
            this.inputStream = null;
        }

        if (this.socket!=null) {
            try {this.socket.close();} catch(java.io.IOException e){}
        }

    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    synchronized public String readLine() throws java.io.IOException {

        synchronized(this.lockRead) {
          return (this.lineNumberReader.readLine());
        }
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Send a message to the cca server
     * @param message The string we are sending
     * to the cca server.
     */
    public void print(String message) {
        synchronized(this.lockWrite) {
          this.printStream.print(message);
          this.printStream.flush();
        }
    }    
    
    
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Send a message to the cca server
     * @param message The string we are sending
     * to the cca server.
     */
    public void println(String message) {
        synchronized(this.lockWrite) {
          this.printStream.println(message);
          this.printStream.flush();
        }
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Writes len bytes from the specified byte array
     * starting at offset off to this output stream.
     * The general contract for write(b, off, len)
     * is that some of the bytes in the array b are written
     * to the output stream in order;
     * element b[off] is the first byte written
     * and b[off+len-1] is the last byte written
     * by this operation.
     * @param buffer The data
     * @param offset The start offset in the data
     * @param length The number of bytes to write
     * @throws java.io.IOException if an I/O error occurs.
     * In particular, an IOException is thrown
     * if the output stream is closed.
     */
    public void write
                (byte buffer[],
                 int offset,
                 int length)
           throws java.io.IOException {

       synchronized(this.lockWrite) {
         this.outputStream.write(buffer, offset, length);
         this.outputStream.flush();
       }
     }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Reads some number of bytes from the input stream
     * and stores them into the buffer array b.
     * The number of bytes actually read is returned as an integer.
     * This method blocks until input data is available,
     * end of file is detected, or an exception is thrown.
     * @param buffer the buffer into which the data is read.
     * @return the total number of bytes read into the buffer,
     * or -1 is there is no more data
     * because the end of the stream has been reached.
     * @throws java.io.IOException if an I/O error occurs.
     */
    synchronized public int read(byte buffer[])
                 throws java.io.IOException {
        synchronized(this.lockRead) {
          return (this.inputStream.read(buffer));
        }
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Get the IP address of the socket
     * @return The IP address of the socket.
     */
    synchronized public java.net.InetAddress getInetAddress() {
        return(this.socket.getInetAddress());
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Return the input stream from the cca server.
     * @return The input stream from the cca server
     */
    synchronized public java.io.InputStream getInputStream() {
        return(this.inputStream);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Return the output stream to the cca server.
     * @return The output stream to the cca server
     */
    synchronized public java.io.OutputStream getOutputStream() {
        return(this.outputStream);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


}