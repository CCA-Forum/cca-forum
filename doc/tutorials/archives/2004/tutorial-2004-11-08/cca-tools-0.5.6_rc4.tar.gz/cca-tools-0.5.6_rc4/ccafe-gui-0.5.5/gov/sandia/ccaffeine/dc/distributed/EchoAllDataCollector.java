package gov.sandia.ccaffeine.dc.distributed;

import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;

class EchoAllDataCollector implements ClientOutputCollector
{
    private ClientOutputRelay cRelay;
    public EchoAllDataCollector ()
    {
    }
    public EchoAllDataCollector (ClientOutputRelay cR)
    {
	this.cRelay = cR;
    }
    public void setClientOutputRelay( ClientOutputRelay cR) 
    {
	this.cRelay = cR;
    }
    public void controllerClientOutput(ClientOutputEvent evt)
    {
	String s = evt.getString();
	cRelay.relayMessageFromController(s);
    }
    public void computeClientOutput(ClientOutputEvent evt)
    {
	if ( cRelay == null ) {
	    // BUGBUG - log an exception
	    return;
	}

	Client src = (Client) evt.getSource();
	String s = evt.getString();
	
	// pass on all output
	cRelay.relayMessageFromDataProducers(s);
    }
    public void processOutOfBand(OutOfBandEvent evt)
    {
    }
}

