package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotLaunchGoCommandOnOneComponentException extends Exception {

    public CanNotLaunchGoCommandOnOneComponentException() {
        super();
    }


    public CanNotLaunchGoCommandOnOneComponentException(String message) {
        super(message);
    }


}