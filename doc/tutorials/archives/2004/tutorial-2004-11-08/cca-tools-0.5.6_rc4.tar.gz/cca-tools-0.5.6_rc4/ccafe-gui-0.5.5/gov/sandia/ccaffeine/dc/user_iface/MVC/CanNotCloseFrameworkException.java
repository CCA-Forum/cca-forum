package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotCloseFrameworkException extends Exception {

  public CanNotCloseFrameworkException() {
      super();
  }

  public CanNotCloseFrameworkException(String message) {
      super(message);
  }


}