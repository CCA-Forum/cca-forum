package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotCommunicateWithCcaServerException extends Exception {

  public CanNotCommunicateWithCcaServerException() {
      super();
  }

  public CanNotCommunicateWithCcaServerException(String message) {
      super(message);
  }


}