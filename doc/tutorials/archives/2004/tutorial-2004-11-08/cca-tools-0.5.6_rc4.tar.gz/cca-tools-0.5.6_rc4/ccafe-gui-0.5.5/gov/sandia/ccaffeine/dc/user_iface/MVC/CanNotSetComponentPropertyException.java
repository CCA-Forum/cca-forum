package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotSetComponentPropertyException extends Exception {

  public CanNotSetComponentPropertyException() {
      super();
  }

  public CanNotSetComponentPropertyException(String message) {
      super(message);
  }


}