package gov.sandia.ccaffeine.cmd;

import java.util.*;
import java.io.*;

/** The actions for any useful command-line interface ultimately depend
    on some context information;
    each specific interpreter will subclass CmdContext differently,
    and write CmdActions that use interpreter specific data or methods.
  */
public abstract class CmdContext {

  /** every interpreter has a debug switch, for development mostly. */
  private boolean debug = false;

  /** every interpreter has a verbose switch for error message style. */
  private boolean verbose = true;

  /** Set the debug switch value. */
  public boolean setDebug(boolean d) {
    debug = d;
    return debug;
  }
  /** Get the debug switch value. */
  public boolean debug() {
    return debug;
  }

  /** Set the verbose switch value. */
  public boolean setVerbose(boolean v) {
    verbose = v;
    return verbose;
  }
  /** Get the verbose switch value. */
  public boolean verbose() {
    return verbose;
  }

  /** Interpreter has a function for writing line from a String. */
  public abstract void pn(String s);

  /** Interpreter has a function for writing from a String. */
  public abstract void p(String s);

  /** prompt string */
  public abstract String prompt();

  /** Interpreter has to get input from somewhere, line at a time.
   Dearly wish this could support command and name completions. */
  public abstract String readLine() throws IOException;

  /** Interpreter can define a restricted set of classes as qualified
   for command-line use. May return null.
   This takes care of changing approximate class names to exact.
   If a string is returned, it will be exactly defined in the
   CmdContext, but the partial-matching is not guaranteed unique. */
  public abstract String getClass(String className);

  /** Interpreter can define a restricted set of instances as qualified
   for command-line use. May return null.
   This takes care of changing approximate instance names to exact.
   If a string is returned, it will be exactly defined in the
   CmdContext, but the partial-matching is not guaranteed unique. */
  public abstract String getInstance(String instanceName);

}
