
package gov.sandia.ccaffeine.dc.user_iface.examples.event;

import java.util.EventObject;


public class MessageEvent extends EventObject {
	
	String message = null;
	
	public String getMessage() {
		return(this.message);
	}
	
	public void setMessage(String message){
		this.message = message;
	}
	
	
	public MessageEvent(Object source){
		super(source);
		this.message = null;
	}
	
	public MessageEvent(Object source, String message){
		super(source);
		this.message = message;
	}

}
