package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.CmdParse;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdContextCcaOneCommand;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiUserListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiListener;

import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCAArena;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCAConfig;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCAConnect;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCADebug;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCADisconnect;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCADisplay;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCAGo;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCAInstantiate;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCALinks;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCANoDebug;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCANuke;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCAPallet;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCAPath;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCAPortProperties;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCAProperties;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCARemove;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCARepository;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCAShell;


public class CcaOneCommandParser {

    CmdContextCcaOneCommand cmdContext = null;
    CmdParse parser = null;
    java.util.Vector vectorCmdActionCCA = null;


    public CcaOneCommandParser() {

      this.cmdContext = new CmdContextCcaOneCommand();
      this.parser = new CmdParse(cmdContext);
      attachActions(parser);

    }


    /**
     * parse one command
     * @param oneCommand The one command that is parsed
     * @throws java.io.IOException Thrown if an
     * i/o error occurs.
     */
    public void parse(String oneCommand) throws java.io.IOException {
        this.cmdContext.setOneCommand(oneCommand);
        parser.parse();
    }



  private void attachActions(CmdParse parser) {

    parser.setContextVerbose(false);

    this.vectorCmdActionCCA = new java.util.Vector();

    CmdActionCCAArena cmdActionCCAArenaAction =
        new CmdActionCCAArena();
    parser.addAction(cmdActionCCAArenaAction);
    this.vectorCmdActionCCA.add(cmdActionCCAArenaAction);


    CmdActionCCAConfig cmdActionCCAConfigAction =
        new CmdActionCCAConfig();
    parser.addAction(cmdActionCCAConfigAction);
    this.vectorCmdActionCCA.add(cmdActionCCAConfigAction);


    CmdActionCCAConnect cmdActionCCAConnectAction =
        new CmdActionCCAConnect();
    parser.addAction(cmdActionCCAConnectAction);
    this.vectorCmdActionCCA.add(cmdActionCCAConnectAction);


    CmdActionCCADebug cmdActionCCADebugAction =
        new CmdActionCCADebug();
    parser.addAction(cmdActionCCADebugAction);
    this.vectorCmdActionCCA.add(cmdActionCCADebugAction);


    CmdActionCCADisconnect cmdActionCCADisconnectAction =
        new CmdActionCCADisconnect();
    parser.addAction(cmdActionCCADisconnectAction);
    this.vectorCmdActionCCA.add(cmdActionCCADisconnectAction);


    CmdActionCCADisplay cmdActionCCADisplayAction =
        new CmdActionCCADisplay();
    parser.addAction(cmdActionCCADisplayAction);
    this.vectorCmdActionCCA.add(cmdActionCCADisplayAction);



    CmdActionCCAGo cmdActionCCAGoAction =
        new CmdActionCCAGo();
    parser.addAction(cmdActionCCAGoAction);
    this.vectorCmdActionCCA.add(cmdActionCCAGoAction);


    CmdActionCCAInstantiate cmdActionCCAInstantiateAction =
        new CmdActionCCAInstantiate();
    parser.addAction(cmdActionCCAInstantiateAction);
    this.vectorCmdActionCCA.add(cmdActionCCAInstantiateAction);

    CmdActionCCALinks cmdActionCCALinksAction =
        new CmdActionCCALinks();
    parser.addAction(cmdActionCCALinksAction);
    this.vectorCmdActionCCA.add(cmdActionCCALinksAction);


    CmdActionCCANoDebug cmdActionCCANoDebugAction =
        new CmdActionCCANoDebug();
    parser.addAction(cmdActionCCANoDebugAction);
    this.vectorCmdActionCCA.add(cmdActionCCANoDebugAction);

    CmdActionCCANuke cmdActionCCANukeAction =
        new CmdActionCCANuke();
    parser.addAction(cmdActionCCANukeAction);
    this.vectorCmdActionCCA.add(cmdActionCCANukeAction);



    CmdActionCCAPallet cmdActionCCAPalletAction =
        new CmdActionCCAPallet();
    parser.addAction(cmdActionCCAPalletAction);
    this.vectorCmdActionCCA.add(cmdActionCCAPalletAction);


    CmdActionCCAPath cmdActionCCAPathAction =
        new CmdActionCCAPath();
    parser.addAction(cmdActionCCAPathAction);
    this.vectorCmdActionCCA.add(cmdActionCCAPathAction);

    CmdActionCCAPortProperties cmdActionCCAPortPropertiesAction =
        new CmdActionCCAPortProperties();
    parser.addAction(cmdActionCCAPortPropertiesAction);
    this.vectorCmdActionCCA.add(cmdActionCCAPortPropertiesAction);


    CmdActionCCAProperties cmdActionCCAPropertiesAction =
        new CmdActionCCAProperties();
    parser.addAction(cmdActionCCAPropertiesAction);
    this.vectorCmdActionCCA.add(cmdActionCCAPropertiesAction);

    CmdActionCCARemove cmdActionCCARemoveAction =
        new CmdActionCCARemove();
    parser.addAction(cmdActionCCARemoveAction);
    this.vectorCmdActionCCA.add(cmdActionCCARemoveAction);

    CmdActionCCARepository cmdActionCCARepositoryAction =
        new CmdActionCCARepository();
    parser.addAction(cmdActionCCARepositoryAction);
    this.vectorCmdActionCCA.add(cmdActionCCARepositoryAction);

    CmdActionCCAShell cmdActionCCAShellAction =
        new CmdActionCCAShell();
    parser.addAction(cmdActionCCAShellAction);
    this.vectorCmdActionCCA.add(cmdActionCCAShellAction);

  }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    synchronized public void addGuiUserListener(GuiUserListener listener) {
       this.cmdContext.addGuiUserListener(listener);
    }

    synchronized public void removeGuiUserListener(GuiUserListener listener) {
       this.cmdContext.removeGuiUserListener(listener);
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    synchronized public void addGuiListener(GuiListener listener) {

         /* error check */
         if (this.vectorCmdActionCCA == null) return;

         /* how many CmdActionCCA components do we have? */
         int numberOfComponents = this.vectorCmdActionCCA.size();

         /* add the listener to each CmdActionGui component */
         for (int i=0; i<numberOfComponents; i++) {
             CmdActionCCA x = (CmdActionCCA)(this.vectorCmdActionCCA.get(i));
             x.addGuiListener(listener);
         }

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    synchronized public void removeGuiListener(GuiListener listener) {

         /* error check */
         if (this.vectorCmdActionCCA == null) return;

         /* how many CmdActionGui components do we have? */
         int numberOfComponents = this.vectorCmdActionCCA.size();

         /* remove the listener from each CmdActionCCA component */
         for (int i=0; i<numberOfComponents; i++) {
             CmdActionCCA x = (CmdActionCCA)(this.vectorCmdActionCCA.get(i));
             x.removeGuiListener(listener);
         }

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

}