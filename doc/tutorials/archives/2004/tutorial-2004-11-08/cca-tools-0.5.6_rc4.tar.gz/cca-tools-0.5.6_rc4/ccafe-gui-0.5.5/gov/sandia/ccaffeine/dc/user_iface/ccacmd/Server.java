package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GoEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.InstantiateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ConnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisconnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamCurrentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GetInstancesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamGetCurrentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetDebugEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayPaletteEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayChainEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.NukeAllEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ExitEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.HeartbeatEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.StringEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetComponentPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GetComponentPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayStateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GoComponentPortEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PathEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PortPropertiesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ComponentPropertiesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RepositoryEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ShellEvent;

import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdContextCCA;
import gov.sandia.ccaffeine.util.LocalSystem;

/**
 * Interface to Server
 */
public class Server
       extends Object
       implements GuiListener {


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    CmdContextCCA cmdContextCCA = null;


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    public Server(CmdContextCCA cmdContextCCA) {
        this.cmdContextCCA = cmdContextCCA;
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The GUI wants the cca server to remove an instantiation of a
     * cca component.
     * @param event The event that is generated whenever
     * the GUI wants to remove an instantiation of a cca
     * component.
     */
    public void remove(RemoveEvent event){

      /*
       * The number of arguments in the "remove" command.
       */
      int numberOfArguments = event.getNumberOfArguments();


      /**
       * The name of the component that was removed.
       * The name is usually the java class name of the component
       * (without the package name) concatenated with an index number.
       * Example:  "StartComponent0"
       */
      String componentInstanceName = event.getComponentInstanceName();


    //if(args.size() > 1) {
    //  cca.bv.error("remove should have only one or two arguments");
    //  return;
    //}
    if(numberOfArguments > 1) {
      this.cmdContextCCA.bv.error("remove should have only one or two arguments");
      return;
    }


    //String instanceName = (String)args.get(0);
    //cca.bm.removeInstantiatedComponent(instanceName);
    //cca.bv.pn("remove "+instanceName);
    this.cmdContextCCA.bm.removeInstantiatedComponent
        (componentInstanceName);
    this.cmdContextCCA.bv.pn
        ("remove "+componentInstanceName);


    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The GUI wants the cca server to launch an application.
     * @param event The event that is generated whenever
     * the GUI wants to launch the application.
     */
     public void go(GoEvent event){


       /*
        * Number of arguments in the go command
        */
       int numberOfArguments = event.getNumberOfArguments();

       /*
        * To call "go" on a specific
        * component, pass in the
        * name of the component.
        * The instance
        * name is usually the name of the component's
        * java class (without the package name)
        * concatenated with an index number.
        * EXAMPLE:  "StarterComponent0"
        */
        String componentInstanceName = event.getComponentInstanceName();


        /*
         * To call "go" on a specific
         * "go" port on a specific component,
         * pass in the
         * name of the "go" port.
         */
         String portInstanceName = event.getPortInstanceName();

         go(numberOfArguments,
            componentInstanceName,
            portInstanceName);
     }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Launch the application.
     * @param numberOfArguments the number of
     * arguments in the "go" command.
     * @param componentInstanceName
     * ITo call "go" on a specific
     * component, pass in the
     * name of the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0".
     * Can be null.
     * @param portInstanceName
     * To call "go" on a specific
     * "go" port on a specific component,
     * pass in the
     * name of the "go" port.  Can be null.     */
     public void go
           (int numberOfArguments,
            String componentInstanceName,
            String portInstanceName){


      //CmdContextCCA cca = (CmdContextCCA)cc;

      try {


        //if (args.size() == 2) {
          //cca.bm.goOne( (String) args.get(0), (String) args.get(1));
        //}
        if (numberOfArguments==2) {
          this.cmdContextCCA.bm.goOne
              ( componentInstanceName,
                portInstanceName);
        }

        //if (args.size() == 1) {
        //  cca.bm.goOne( (String) args.get(0), "go_port");
        //}
        if (numberOfArguments==1) {
          this.cmdContextCCA.bm.goOne
              ( componentInstanceName,
                "go_port");
        }



        //if (args.size() == 0) {
        //  cca.bm.go();
        //}
        if (numberOfArguments==0){
            this.cmdContextCCA.bm.go();
        }

      }
      catch (Exception e) {
        this.cmdContextCCA.bv.error("go command failed");
        this.cmdContextCCA.bv.error(e);
        return;
      }
      this.cmdContextCCA.bv.pn("go command successful");

     }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

     /**
      * The GUI is asking the cca server to retrieve a cca component.
      * @param event The event that is generated whenever
      * the GUI wants to retrieve a cca component.
      */
     public void instantiate(InstantiateEvent event){

       /*
        * The name of the class that we will use to
        * instantiate a new cca component.
        * The name is actually the name of the component's
        * java class.
        * EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
        */
       String className = event.getClassName();

       /*
        * The name of the newly instantiated
        * cca component object.  The instance
        * name is usually the name of the component's
        * java class (without the package name)
        * concatenated with an index number.
        * EXAMPLE:  "StarterComponent0"
        */
       String instanceName = event.getInstanceName();


       //String cpath = (String) args.get(0);
       //String iname = (String) args.get(1);

       //try {
         //cca.bm.pullDownFromPallet(cpath, iname);
         //cca.bv.pullDownComponent(cpath.intern(), iname.intern());
       //}
       //catch (Exception e) {
         //cca.bv.error("instantiation unsuccessful");
         //cca.bv.error(e);
       //}
       try {
         this.cmdContextCCA.bm.pullDownFromPallet
             (className,
              instanceName);
         this.cmdContextCCA.bv.pullDownComponent
             (className.intern(),
              instanceName.intern());
       }
       catch (Exception e) {
         this.cmdContextCCA.bv.error("instantiation unsuccessful");
         this.cmdContextCCA.bv.error(e);
       }

     }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
     
     
     /**
      * The GUI is asking the cca server to connect the
      * Provides Port of a cca component to a Uses Port.
      * The Uses Port may be one the
      * same component or may be on a different component.
      * @param event The event that is sent whenever
      * the GUI wants to connect a Uses Port with a
      * Provides Port.
      */
     public void connect(ConnectEvent event){


       /*
        * This is the name of the component that houses the
        * source port.  The source port is one of the two
        * connected ports.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
       String sourceComponentName = event.getSourceComponentName();

       /**
        * This is the name of the source port.
        * The source port is connected to the target port.
        * Example:  "out0"
        */
       String sourcePortName = event.getSourcePortName();

       /*
        * The name of the component that houses the target port.
        * The target port is one of the two connected ports.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "PrinterComponent0"
        */
       String targetComponentName = event.getTargetComponentName();

       /*
        * This is the name of the target port.
        * The target port is connected to the source port.
        * Example:  "printer_port"
        */
       String targetPortName = event.getTargetPortName();


    //toInstance = (String)args.get(0);
    //usesInstance = (String)args.get(1);
    //fromInstance = (String)args.get(2);
    //providesInstance = (String)args.get(3);
    //
    //CmdContextCCA cca = (CmdContextCCA)cc;
    //try {
    //  cca.bm.connect(fromInstance.intern(), providesInstance.intern(),
    //                 toInstance.intern(), usesInstance.intern());
    //  cca.bv.connect(fromInstance.intern(), providesInstance.intern(),
    //                 toInstance.intern(), usesInstance.intern());
    //} catch(Exception e) {
    //  cca.bv.displayConnectionFailed(e);
    //}

    try {
        this.cmdContextCCA.bm.connect
            (targetComponentName.intern(),
             targetPortName.intern(),
             sourceComponentName.intern(),
             sourcePortName.intern());
        this.cmdContextCCA.bv.connect
            (targetComponentName.intern(),
             targetPortName.intern(),
             sourceComponentName.intern(),
             sourcePortName.intern());
      } catch(Exception e) {
      this.cmdContextCCA.bv.displayConnectionFailed(e);

     }

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

     /**
      * The GUI is asking the cca server to
      * disconnect the connection between a Provides Port
      * of a cca component
      * and a Uses Port.
      * @param event The event that is sent whenever
      * the GUI wants to connect a Uses Port with a
      * Provides Port.
      */
     public void disconnect(DisconnectEvent event){

       /*
        * This is the name of the component that houses the
        * source port.  The source port is one of the two
        * connected ports.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
       String sourceComponentName = event.getSourceComponentName();

       /**
        * This is the name of the source port.
        * The source port is connected to the target port.
        * Example:  "out0"
        */
       String sourcePortName = event.getSourcePortName();

       /*
        * The name of the component that houses the target port.
        * The target port is one of the two connected ports.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "PrinterComponent0"
        */
       String targetComponentName = event.getTargetComponentName();

       /*
        * This is the name of the target port.
        * The target port is connected to the source port.
        * Example:  "printer_port"
        */
       String targetPortName = event.getTargetPortName();

       //toInstance = (String)args.get(0);
       //usesInstance = (String)args.get(1);
       //fromInstance = (String)args.get(2);
       //providesInstance = (String)args.get(3);

       //CmdContextCCA cca = (CmdContextCCA)cc;
       //try {
       //  cca.bm.disconnect(fromInstance.intern(), providesInstance.intern(),
       //                 toInstance.intern(), usesInstance.intern());
       //  cca.bv.disconnect(fromInstance.intern(), providesInstance.intern(),
       //                 toInstance.intern(), usesInstance.intern());
       //} catch(Exception e) {
       //  cca.bv.displayDisconnectionFailed(e);
       //}


       try {
         this.cmdContextCCA.bm.disconnect
             (targetComponentName.intern(),
              targetPortName.intern(),
              sourceComponentName.intern(),
              sourcePortName.intern());
         this.cmdContextCCA.bv.disconnect
             (targetComponentName.intern(),
              targetPortName.intern(),
              sourceComponentName.intern(),
              sourcePortName.intern());
       }
       catch (Exception e) {
         this.cmdContextCCA.bv.displayDisconnectionFailed(e);
       }

     }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

     /**
      * The GUI is asking the cca server to set one of the
      * parameters of a port that is on a cca component.
      * @param event The event that is generated
      * whenever the GUI wants to set the value of
      * a data field.
      */
     public void setPortParameter(ParamCurrentEvent event){

      /*
       * The number of arguments.
       *
       * If we are tying to get the value of a
       * parameter then we need 3 arguments
       * (instanceName, portName, parameterName).
       * If we are trying to set the value of a
       * parameter then we need 4 or more arguments
       */
      int numberOfArguments = 4;

      /*
       * The name of the cca component that contains
       * the port which contains the data field.
       * The name is usually the java class name of the component
       * (without the package name) concatenated with an index number.
       * Example:  "TimeStamper0"
       */
       String componentInstanceName =
           event.getComponentInstanceName();

       /**
        * The name of the port that contains the data field.
        *  Example: "configure_port"
        */
        String portInstanceName =
            event.getPortInstanceName();

        /**
         * The name of a data field.
         */
        String dataFieldName =
            event.getDataFieldName();

        /*
         * If an entity is setting the value
         * of a data field then that value
         * stored here.
         */
        String dataFieldValue =
            event.getDataFieldValue();


        portParameter
            (numberOfArguments,
             componentInstanceName,
             portInstanceName,
             dataFieldName,
             dataFieldValue);

     }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


     /**
      * The GUI is asking the cca server to send back
      * the value of one of the parameters of a port that
      * is on a cca component.
      * @param event The event that is generated whenever
      * the GUI wants the value of one of the data fields.
      */
    public void getPortParameter(ParamGetCurrentEvent event){

      /*
       * The number of arguments.
       *
       * If we are tying to get the value of a
       * parameter then we need 3 arguments
       * (instanceName, portName, parameterName).
       * If we are trying to set the value of a
       * parameter then we need 4 or more arguments
       */
      int numberOfArguments = 3;

      /*
       * The name of the cca component that contains
       * the port which contains the data field.
       * The name is usually the java class name of the component
       * (without the package name) concatenated with an index number.
       * Example:  "TimeStamper0"
       */
       String componentInstanceName =
           event.getComponentInstanceName();

       /**
        * The name of the port that contains the data field.
        *  Example: "configure_port"
        */
        String portInstanceName =
            event.GetPortInstanceName();

        /**
         * The name of a data field.
         */
        String dataFieldName =
            event.getDataFieldName();

        this.portParameter
            (numberOfArguments,
             componentInstanceName,
             portInstanceName,
             dataFieldName,
             null);

    }




    /**
     * The GUI is asking the cca server to get or set
     * one of the parameters of a port that is on a 
     * cca port.
     * @param event The event that is generated whenever
     * the GUI wants to get or set the value of one
     * of the data fields.
     */
    public void portParameter(ParamEvent event){

      /*
       * The number of arguments.
       *
       * If we are tying to get the value of a
       * parameter then we need 3 arguments
       * (instanceName, portName, parameterName).
       * If we are trying to set the value of a
       * parameter then we need 4 or more arguments
       */
      int numberOfArguments = event.getNumberOfArguments();

      /*
       * The name of the cca component that contains
       * the port which contains the data field.
       * The name is usually the java class name of the component
       * (without the package name) concatenated with an index number.
       * Example:  "TimeStamper0"
       */
       String componentInstanceName =
           event.getComponentInstanceName();

       /**
        * The name of the port that contains the data field.
        *  Example: "configure_port"
        */
        String portInstanceName =
            event.getPortInstanceName();

        /**
         * The name of a data field.
         */
        String dataFieldName =
            event.getDataFieldName();

        /*
         * If an entity is setting the value
         * of a data field then that value
         * stored here.
         */
        String dataFieldValue =
            event.getDataFieldValue();

        portParameter
            (numberOfArguments,
             componentInstanceName,
             portInstanceName,
             dataFieldName,
             dataFieldValue);
    }

    /**
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * Get or set the value of one of the
     * data fields.
     * @param numberOfArguments
     * If we are tying to get the value of a
     * parameter then we need 3 arguments
     * (instanceName, portName, parameterName).
     * If we are trying to set the value of a
     * parameter then we need 4 or more arguments
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The name of a port that contains the data field.
     *  Example: "configure_port"
     * @param dataFieldName
     * The name of the data field.
     * @param dataFieldValue
     * If an entity is setting the value
     * of a data field then we need to
     * know what that value is.
     * Can be set to null;
     */
    public void portParameter
        (int numberOfArguments,
          String componentInstanceName,
          String portInstanceName,
          String dataFieldName,
          String dataFieldValue){

        //if (args.size() < 3) {
        if (numberOfArguments < 3) {

          //cca.bv.pn("need a component instance name, port name, and parameter name arguments");
          this.cmdContextCCA.bv.pn(
              "need a component instance name, port name, and parameter name arguments");

         //  return;
          return;

        //}
        }

        // cca.bv.pn("1configuring "+instanceName+":"+portName);

        //if (args.size() < 4) {
        if (numberOfArguments < 4) {

          //if ( fieldName.equals("ALL") ) { // dump all parameters
          if (dataFieldName.equals("ALL")) { // dump all parameters

          //String configuration = cca.bm.getConfiguration
          //    (instanceName,portName);
          String configuration = this.cmdContextCCA.bm.getConfiguration
                (componentInstanceName,
                 portInstanceName);

            //if (configuration.length() == 0) {
            if (configuration.length() == 0) {

             //return;
              return;

            //}
            }

            //cca.bv.displayConfiguration
            //   (instanceName,portName,configuration);
            this.cmdContextCCA.bv.displayConfiguration
                (componentInstanceName,
                 portInstanceName,
                 configuration);

           //return;
            return;

          //}
          }

          // else dump named parameter


          //String configuration =
          //    cca.bm.getConfiguration(instanceName,portName,fieldName);
          String configuration =
              this.cmdContextCCA.bm.getConfiguration
                  (componentInstanceName,
                   portInstanceName,
                   dataFieldName);

          //  if (configuration.length() == 0) {
          if (configuration.length() == 0) {

             //return;
             return;

          //}
          }

          //cca.bv.displayConfiguration(instanceName,portName,configuration);
          this.cmdContextCCA.bv.displayConfiguration
              (componentInstanceName,
               portInstanceName,
               configuration);

           //return;
           return;

        //}
        }

        // cca.bv.pn("2b configuring "+instanceName+":"+portName);

        //if ( fieldName.equals("ALL")) {
        if (dataFieldName.equals("ALL")) {

          // set all parameters not allowed

          //cca.bv.pn("'ALL' cannot be used to set a parameter value.");
          this.cmdContextCCA.bv.pn("'ALL' cannot be used to set a parameter value.");

          //return;
          return;

        //}
        }

        // with luck, always 1 trip through loop.
        //StringBuffer sb = new StringBuffer();
        //for (int i=3; i < args.size(); i++) {
        //  if (i >= 4) { sb.append(" "); }//reduce all whitespace to singlespace
        //  sb.append((String)args.get(i));
        // }
        StringBuffer sb = new StringBuffer(dataFieldValue);



       //String configuration =
       //   cca.bm.setConfiguration
       //      (instanceName,portName,fieldName,sb.toString());
        String configuration =
            this.cmdContextCCA.bm.setConfiguration
              (componentInstanceName,
               portInstanceName,
               dataFieldName,
               sb.toString());

        //if (configuration.length() == 0) {
        if (configuration.length() == 0) {

          // no configure interface on instance name and port. punt.

          //return;
          return;

       //}
        }

        //cca.bv.setConfiguration(instanceName,portName,fieldName,configuration);
        this.cmdContextCCA.bv.setConfiguration
            (componentInstanceName,
             portInstanceName,
             dataFieldName,
             configuration);

       //cca.bv.pn("updated parameter " + instanceName+":"+portName+" "+fieldName);
        this.cmdContextCCA.bv.pn
            ("updated parameter "
             + componentInstanceName + ":"
             + portInstanceName + " "
             + dataFieldName);
      //}
      }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    
    
    
    /**
     * The GUI is asking the cca server to send back
     * all of the instantiated cca components.
     * @param event That event that is generated
     * whenever the GUI wants to get all of the
     * instantiated cca components.
     */
    public void getAllInstancesInArena(GetInstancesEvent event){

        //cca.bv.displayInstantiatedComponents();
        this.cmdContextCCA.bv.displayInstantiatedComponents();
    }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    
    
    /**
     * The GUI is asking the cca server to turn on debugging.
     * @event The event that is generated whenever
     * the GUI wants debugging turned on.
     */
    public void setDebug(SetDebugEvent event){

    //cca.bm.setDebug(true);
    this.cmdContextCCA.bm.setDebug(true);

    LocalSystem.setDebug(true);
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The GUI is asking the cca server to turn off debugging
     * @event The event that is generated whenever
     * the GUI wants the debugging turned off.
     */
    public void setNoDebug(SetDebugEvent event){


        //cca.bm.setDebug(false);
        this.cmdContextCCA.bm.setDebug(false);

        //LocalSystem.setDebug(false);
        LocalSystem.setDebug(false);
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The GUI is requesting some information from the cca server.
     * The GUI can request the following info: <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display palette <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display arena <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display chain <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display component <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display state <br>
     * <p>
     * If the GUI sends the server a "draw palette" request,
     * the server will send back all of the cca classes
     * that are in the palette.  The GUI can respond by
     * rendering an icon, in the palette, for each cca class.
     * <p>
     * If the GUI sends the server a "draw arena" request,
     * the server will send back all of the cca instances
     * that are in the work area.  The GUI can respond by
     * rendering an icon, in the work area, for each cca instance.
     * <p>
     * If the GUI sends the server a "draw chain" request,
     * the server will send back a connection, or a line, 
     * that connects two different ports; the two ports
     * may be on the same cca component or may be on 
     * different components.  The GUI can respond by
     * drawing a line between the two ports.
     * <p>
     * If the GUI sends the server a "draw component" request,
     * the server will send back one instantiated component.
     * The GUI can respond by rendering the component
     * in the work area.
     * <p>
     * If the GUI sends the server a "draw state" request,
     * the server will send back all of the components
     * that are in the work area and will send back
     * all of the connections that are attached to two ports.
     * The GUI can respond by rendering the components and the
     * connections in the work area. 
     * @param DisplayEvent The event that is
     * generated whenever an entity is requesting
     * some information from the server.
     */
    public void display(DisplayEvent event){


      /*
       * The number of arguments
       * in the request string.
       */
      int numberOfArguments = event.getNumberOfArguments();

      /*
       * We are requesting info
       * on which entity?  We can
       * request info on the PALETTE,
       * ARENA, CHAIN, COMPONENT,
       * STATE.
       */
       String entity = event.getEntity();

      /*
       * If an entity wants some info on
       * a particular component, then that
       * entity has to supply the name of
       * the component.
       * The instance
       * name is usually the name of the component's
       * java class (without the package name)
       * concatenated with an index number.
       * EXAMPLE:  "StarterComponent0"
       */
      String componentInstanceName = event.getComponentInstanceName();




    //String s = (String)args.get(0);

    //String sub = new String("pallet");
    //if (sub.startsWith(s)) {
    //  cca.bv.displayPallet();
    //  return;
    //}
    if (entity.equals("pallet")) {
      this.cmdContextCCA.bv.displayPallet();
      return;
    }


    //sub = new String("arena");
    //if(sub.startsWith(s)) {
    //  cca.bv.displayInstantiatedComponents();
    //  return;
    //}
    if (entity.equals("arena")){
        this.cmdContextCCA.bv.displayInstantiatedComponents();
        return;
    }

    //sub = new String("chain");
    //if(sub.startsWith(s)) {
    //  cca.bv.displayChain();
    //  return;
    //}
    if (entity.equals("chain")) {
        this.cmdContextCCA.bv.displayChain();
        return;
    }


    //sub = new String("component");
    //if(sub.startsWith(s)) {
    //  if (args.size() != 2) {
    //    cca.bv.pn("need a component instance name argument");
    //    return;
    //  }
    //  String instanceName = (String)args.get(1);
    //  cca.bv.displayComponentInfo(instanceName.intern());
    //  return;
    //}
    if (entity.equals("component")){
        if (numberOfArguments!=2) {
          this.cmdContextCCA.bv.pn("need a component instance name argument");
          return;
        }
        this.cmdContextCCA.bv.displayComponentInfo
            (componentInstanceName.intern());
        return;
    }

    //sub = new String("state");

    //if(sub.startsWith(s)) {
    if (entity.equals("state")) {

      // This will cause components living on the far end to be
      // (re)instantiated in the GUI.

      //cca.bv.displayInstantiatedComponents();
      this.cmdContextCCA.bv.displayInstantiatedComponents();

      //Enumeration keys = cca.bm.getArena().keys(); // Instance names of cmpts
      //while(keys.hasMoreElements()) {
	//String name = (String)keys.nextElement();
	//cca.bv.displayComponentProperties(name);
      //}
      java.util.Enumeration keys = this.cmdContextCCA.bm.getArena().keys(); // Instance names of cmpts
      while(keys.hasMoreElements()) {
	String name = (String)keys.nextElement();
	this.cmdContextCCA.bv.displayComponentProperties(name);
      }

      //cca.bv.displayChain();
      this.cmdContextCCA.bv.displayChain();

      //return;
      return;
    }

    //cca.bv.pn("display option " + s + "unknown");
    this.cmdContextCCA.bv.pn("display option " + entity + "unknown");

    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    
    
    
    /**
     * The GUI is requesting the cca server to send
     * back all of the components that are in the palette.
     * A palette is a menu of
     * cca components; the end-user can drag components
     * from the palette to the arena (workspace).
     * <p>
     * The cca server will send back all of the components
     * that are in the palette.  A GUI might respond
     * by rending an icon, in the palette, for each component.  
     * @param event The event that is generated whenever
     * the GUI wants to know what components
     * are in the palette.
     */
    public void displayPalette(DisplayPaletteEvent event){


      //cca.bv.displayPallet();
      this.cmdContextCCA.bv.displayPallet();
    }







    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /** 
     * The GUI is requesting the cca server to send 
     * back all connections.  A connection connects
     * a user port of a component to a provider port;
     * the two ports may be on the same cca component
     * or may be on different components.
     * @param event The event that is created
     * whenever the GUI wants to know what connections
     * are in the arena.
     */
  public void links(DisplayChainEvent event){

    //CmdContextCCA cca = (CmdContextCCA)cc;

    //cca.bv.displayChain();
    this.cmdContextCCA.bv.displayChain();

  }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


  /**
   * The GUI is requesting the cca server to 
   * send back a cca component. 
   * <p>
   * The cca server will respond by sending
   * back one cca component.  The GUI might
   * respond by rendering the component
   * in the workspace.
   * @param source The entity that created this event.
   * @param componentInstanceName
   * The name of the
   * cca component object.  The instance
   * name is usually the name of the component's
   * java class (without the package name)
   * concatenated with an index number.
   * EXAMPLE:  "StarterComponent0"
   * @param event The event that is created whenever
   * the GUI wants some information on a cca component.
   */
    public void displayComponent(DisplayComponentEvent event){


        String componentInstanceName = event.getComponentInstanceName();


        //sub = new String("component");
        //if(sub.startsWith(s)) {
        //  if (args.size() != 2) {
        //    cca.bv.pn("need a component instance name argument");
        //    return;
        //  }
        //  String instanceName = (String)args.get(1);
        //  cca.bv.displayComponentInfo(instanceName.intern());
        //  return;
        //}
        this.cmdContextCCA.bv.displayComponentInfo
            (componentInstanceName.intern());

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    
    
    /**
     * The GUI is requesting the cca server to 
     * send back all components that are in the 
     * arena and to send back all connections.  A connection
     * connects a user port of a component with a provider
     * port; the two ports may be on the same cca component
     * or may be on different components.
     * <p>
     * The cca server will respond by sending back all of
     * the components that are in the workspace and all of the
     * connections.  A GUI might respond by rendering an icon,
     * in the work area, for each component and by drawing lines
     * between the components to connect them.
     * @param event The event that is created whenever
     * we want to know the state of the arena.
     */
    public void displayState(DisplayStateEvent event){

      //sub = new String("state");

      //if(sub.startsWith(s)) {

        // This will cause components living on the far end to be
        // (re)instantiated in the GUI.

        //cca.bv.displayInstantiatedComponents();
        this.cmdContextCCA.bv.displayInstantiatedComponents();

        //Enumeration keys = cca.bm.getArena().keys(); // Instance names of cmpts
        //while(keys.hasMoreElements()) {
        //String name = (String)keys.nextElement();
        //cca.bv.displayComponentProperties(name);
        //}
        java.util.Enumeration keys = this.cmdContextCCA.bm.getArena().keys(); // Instance names of cmpts
        while (keys.hasMoreElements()) {
          String name = (String) keys.nextElement();
          this.cmdContextCCA.bv.displayComponentProperties(name);
        }

        //cca.bv.displayChain();
        this.cmdContextCCA.bv.displayChain();

        //return;
        return;


    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The GUI is requesting that the cca server
     * execute the "go" command"
     * on a specific port that is located
     * on a specific component.
     * @param event The event that is generated whenever
     * the GUI wants to invoke the "go" command.
     */
     public void goComponentPort(GoComponentPortEvent event){


       /*
        * Number of arguments in the go command
        */
       int numberOfArguments = 2;

       /*
        * To call "go" on a specific
        * component, pass in the
        * name of the component.
        * The instance
        * name is usually the name of the component's
        * java class (without the package name)
        * concatenated with an index number.
        * EXAMPLE:  "StarterComponent0"
        */
        String componentInstanceName = event.getComponentInstanceName();


        /*
         * To call "go" on a specific
         * "go" port on a specific component,
         * pass in the
         * name of the "go" port.
         */
         String portInstanceName = event.getPortInstanceName();

         go(numberOfArguments,
            componentInstanceName,
            portInstanceName);


     }







    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


     /**
      * The GUI is requesting the cca server to
      * delete all components.
      * <p>
      * The server will respond by deleting all components.
      * The GUI might respond by removing all components
      * from the workspace.
      * param event The event that is created
      * whenever the GUI wants to to delete
      * all components.
      */
     public void nukeAll(NukeAllEvent event){

       /* The number of arguments in the nuke command */
       int numberOfArguments = event.getNumberOfArguments();

       /*
        * The entity that is to be removed.
        * NOTE:  As of Oct 2003, "all" is the
        * only entity that can be nuked.
        */
        String entity = event.getEntity();



        //if (args.size() > 1) {
        //  cca.bv.error("remove should have only one or two arguments");
        //  return;
        //}
        if (numberOfArguments > 1) {
          this.cmdContextCCA.bv.error("remove should have only one or two arguments");
          return;
        }


        //String all = (String) args.get(0);

        //if ("all".compareTo(all) != 0) {
        //  cca.bv.error("to delete all components in the arena: \"nuke all\"");
        //  return;
        //}
        if (!(entity.equals("all"))) {
          this.cmdContextCCA.bv.error("to delete all components in the arena: \"nuke all\"");
          return;
        }


        //cca.bm.removeAllInstantiatedComponents();
        //cca.bv.pn("Removed all instantiated components from the arena");
        this.cmdContextCCA.bm.removeAllInstantiatedComponents();
        this.cmdContextCCA.bv.pn("Removed all instantiated components from the arena");


  }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


     /**
      * The GUI is requesting the cca server to send back or to set
      * the value of a port
      * property.
      * @param event The event that is generated
      * whenever an entity wants to either get or
      * set the value of a port property.
      */
     public void portProperties(PortPropertiesEvent event){

       /*
        * The number of arguments in the "port-property"
        * command.
        */
       int numberOfArguments = event.getNumberOfArguments();

       /**
        * The name of the component that contains the property
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
       String componentInstanceName = event.getComponentInstanceName();
       
       /*
        * The name of the port that contains the property.
        */
       String portName = event.getPortName();

       /*
        * If we are getting or setting the value
        * of a specific property then we need the
        * name of the property.
        */
       String propertyName = event.getPropertyName();

       /**
        * If we are setting the value of a
        * property then we need the datatype
        * of the value.
        */
       String dataTypeOfPropertyValue = event.getDataTypeOfPropertyValue();


       /*
        * If we are setting the value of a
        * property then we need the new value.
        */
       String propertyValue = event.getPropertyValue();

       System.err.println
           ("ERROR.  \"port-property\" command not yet implemented.");


    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


     /**
      * The GUI is requesting the cca server to send back
      * or to set the value of a component property.
      * An example of a component property is the "name"
      * of the component.
      * @param event The event that is generated
      * whenever the GUI wants to either get or
      * set the value of a component property.
      */
     public void componentProperties(ComponentPropertiesEvent event){

       /*
        * The number of arguments in the "property"
        * command.
        */
       int numberOfArguments = event.getNumberOfArguments();

       /**
        * The name of the component that contains the property
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
       String componentInstanceName = event.getComponentInstanceName();

       /*
        * If we are getting or setting the value
        * of a specific property then we need the
        * name of the property.
        */
       String propertyName = event.getPropertyName();


       /*
        * If we are setting the value of a
        * property then we need the new value.
        */
       String propertyValue = event.getPropertyValue();

       componentProperties
         (numberOfArguments,
          componentInstanceName,
          propertyName,
          propertyValue);
     }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Retrieve the value of a component
     * property or set the value of a component
     * property.
     * A view entity might
     * respond by either displaying the current
     * value of a component property or by setting the value
     * of a component property.
     * <p>
     * An example of a component property is "name" of component,
     * the component's "key" value, and "value" of the component.
     * @param event The event that is generated
     * whenever an entity wants to either get or
     * set the value of a component property.
     * @param numberOfArguments
     * The number of arguments in the "properties"
     * command.
     * @param componentInstanceName
     * The name of the component that contains the property
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param propertyName If we want to
     * get or set the value of a specific
     * component property, then we need the
     * name of the property.
     * @param propertyValue If we are
     * setting the value of a specific component property,
     * then we need the value of the property.
     */
     public void componentProperties
         (  int numberOfArguments,
            String componentInstanceName,
            String propertyName,
            String propertyValue){


    //if (args.size() < 1) {
    //  cca.bv.pn("need a component instance name.");
    //  return;
    //}
    if (numberOfArguments < 1) {
      this.cmdContextCCA.bv.pn("need a component instance name.");
      return;
    }

    //String instanceName = (String)args.get(0);
    //if (args.size() == 1) {
    //  Vector props = cca.bm.getComponentProperties(instanceName);
    //  cca.bv.displayComponentProperties(instanceName,props);
    //  return;
    //}
    if (numberOfArguments == 1) {
      java.util.Vector props = this.cmdContextCCA.bm.getComponentProperties
          (componentInstanceName);
      this.cmdContextCCA.bv.displayComponentProperties
          (componentInstanceName,props);
      return;
    }



    //String key = (String)args.get(1);
    //if (args.size() == 2) {
    //  String value = cca.bm.getComponentProperty(instanceName,key);
    //  cca.bv.displayComponentProperty(instanceName,key,value);
    //  return;
    //}
    if (numberOfArguments == 2) {
      String value = this.cmdContextCCA.bm.getComponentProperty
          (componentInstanceName,
           propertyName);
      this.cmdContextCCA.bv.displayComponentProperty
          (componentInstanceName,
           propertyName,
           value);
      return;
    }


    //String value = (String)args.get(2);
    //int err = cca.bm.setComponentProperty(instanceName,key,value);
    //cca.bv.setComponentProperty(instanceName,key,value,err);
    int err = this.cmdContextCCA.bm.setComponentProperty
        (componentInstanceName,
         propertyName,
         propertyValue);
    this.cmdContextCCA.bv.setComponentProperty
        (componentInstanceName,
         propertyName,
         propertyValue,
         err);
  }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


     /**
      * The GUI is requesting the cca server to send back
      * the value of a property that is inside a cca component.
      * @param event The event that is generated
      * whenever the GUI wants the value of a
      * property that is inside a component.
      */
    public void getComponentProperty(GetComponentPropertyEvent event){

       /*
        * The number of arguments in the "property"
        * command.
        */
       int numberOfArguments = 2;

       /**
        * The name of the component that contains the property
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
       String componentInstanceName = event.getComponentInstanceName();

       /*
        * If we are getting or setting the value
        * of a specific property then we need the
        * name of the property.
        */
       String propertyName = event.getPropertyName();


       /*
        * If we are setting the value of a
        * property then we need the new value.
        */
       String propertyValue = null;

       componentProperties
         (numberOfArguments,
          componentInstanceName,
          propertyName,
          propertyValue);

    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The GUI wants the server to set the value of 
     * a property that is inside of a cca component.
     * @param event The event that is created whenever
     * the GUI wants to set the value of a property.
     */
    public void setComponentProperty(SetComponentPropertyEvent event){

       /*
        * The number of arguments in the "property"
        * command.
        */
       int numberOfArguments = 3;

       /**
        * The name of the component that contains the property
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
       String componentInstanceName = event.getComponentInstanceName();

       /*
        * If we are getting or setting the value
        * of a specific property then we need the
        * name of the property.
        */
       String propertyName = event.getPropertyName();


       /*
        * If we are setting the value of a
        * property then we need the new value.
        */
       String propertyValue = event.getPropertyValue();

       componentProperties
         (numberOfArguments,
          componentInstanceName,
          propertyName,
          propertyValue);

    }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The GUI wants to send a message to the cca server.
     * @param event The event that is created
     * the GUI wants to send
     * a string to the cca server.
     */
    public void sendMessage(StringEvent event){

        System.err.println
            ("ERROR.  The cca server can not send a message to itself.");
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The GUI wants to send a heartbeat to the cca server.
     * @param event The event that is fabricated
     * the GUI wants to emit a heartbeat.
     */
    public void heartbeat(HeartbeatEvent event){

        System.err.println("ERROR.  Heartbeat not yet implemented.");
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The GUI wants to tell the cca server that the GUI
     * is shutting down.
     * @param event The event that is generated whenever
     * the GUI wants to exit the application.
     */
    public void exit(ExitEvent event){
        System.err.println("ERROR.  \"Exit\" command not yet implemented.");
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/







    /**
     * The GUI wants to tell the cca server to 
     * send back or to set the file path
     * that contains cca components.
     * @param event The event that is
     * generated whenever the GUI
     * wants either to set the path
     * to a new value or to query
     * for the path value.
     */
    public void path(PathEvent event){

      /*
       * The number of arguments
       * in the path command.
       */
      int numberOfArguments = event.getNumberOfArguments();

      /*
       * To alter the path,
       * specify how
       * the path is to be changed
       * by issuing
       * any of the following commands:
       * INIT, APPEND, PREPEND, SET
       */
      String commandToAlterPath = event.getCommandToAlterPath();

      /**
       * To alter the path,
       * specify the value that
       * will be used to change the path.
       */
      String directory = event.getDirectory();

      System.err.println("ERROR.  \"path\" command not yet implemented.");
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The GUI wants the cca server to send back all
     * components that are in the repository or to send
     * back one specific compnonent that is in the repository.
     * @param event The event that is created whenever
     * the GUI wants to get one component or all components
     * from the repository,
     */
    public void repository(RepositoryEvent event){

      /*
       * The number of arguments in the "repository" command
       */
      int numberOfArguments = event.getNumberOfArguments();

      /*
       * The command.  The command can be one of the following
       * values:  LIST, GET, GET_GLOBAL, GET_LAZY, GET_LAZY_GLOBAL
       */
      String command = event.getCommand();

      /*
       * If we are retrieving the value of one class,
       * then we need the name of the class.
       */
      String className = event.getClassName();


      System.err.println("ERROR.  \"repository\" command not yet implemented.");

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The GUI wants to send an O.S. command to the cca server.
     * The cca server will execute the command.
     * @param event The event that is
     * created whenever the GUI wants
     * an O.S. command executed.
     */
    public void shell(ShellEvent event){

      /* the number of arguments in the "shell" command */
      int numberOfArguments = event.getNumberOfArguments();

      /* The command that is to be executed */
      String command = event.getCommand();

      System.err.println("ERROR.  \"shell\" command not yet implemented.");

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


}