
package gov.sandia.ccaffeine.dc.user_iface.examples;

import gov.sandia.ccaffeine.dc.user_iface.BuilderClient;

public class ThreadClient extends Thread {
	
	int port = 0;
	
	public ThreadClient(int port){
		super();
		this.port = port;		
	}
	
	public void run() {
		
		
		/* launch the cca client */
        try {
			BuilderClient.main(new String[]{"--builderPort",
					                 String.valueOf(this.port)});
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}      
		
	}
	
	
	public static void main(String[] args) {
	}
}
