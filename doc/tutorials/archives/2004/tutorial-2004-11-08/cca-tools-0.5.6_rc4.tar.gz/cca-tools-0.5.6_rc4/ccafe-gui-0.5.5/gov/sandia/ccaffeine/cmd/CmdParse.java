package gov.sandia.ccaffeine.cmd;

import java.util.*;
import java.io.*;

/** The Cmd classes implement a simple Vector
    driven parser for command line applications.

by Ben Allan, Sandia National Laboratories, May 1999.
This code is based on the ASCEND IV command-line interpreter
by Tom Epperly. It should be released to the public domain
(or preferably the GNU License domain) as soon as possible.

CmdContext is an abstract class for application specific
data that will be defined in more detail by the application
programmer.

CmdAction is an interface class used in defining individual
command objects. An interpreter is a collection of such
objects sharing a common assumption about the subclass of
CmdContext they are called in.

CmdParse defines the interpreter which provides argument
marshaling and checking services, supports command
abbreviations, and provides help functionality.

The overall scheme is that the application defines a bunch
of CmdAction objects and hands them to the interpreter.

This is not a highly intelligent scheme. It does keep a
"hand-coded" interactive command-line manageable as each
major command gets a separate class and implementation,
and the control loop logic is abstracted. Unlike lex/yacc,
it scales easily to multiple developers.

 */
public class CmdParse {

  private Vector alist = new Vector();
  /** Commands in this parser. */
  private CmdContext cc;
  /** Parser-instance-global functions, data, io and others */


  /** Actions in the constructed parser will be called with icc as their context. */
  public CmdParse(CmdContext icc) {

    CmdActionHelp cah = new CmdActionHelp(); // must be first.
    alist.add(cah);

    CmdActionExit cae = new CmdActionExit();
    alist.add(cae);

    cc = icc;

  }


  /** Adds a command to the parser. Presently does not check the sanity of
      the command.
   This function needs to do some insertion with checking for
   duplicates if we're paranoid. As it is, this comes out in
   the wash at getAction. Duplication will make commands useless.
  */
  public void addAction(CmdAction c) {

    alist.add(c);

  }


  /** Returns the nearest match (by leading characters) of commands
      stored in the list. */
  public CmdAction getAction(String s) {

    // filter out comments #, !, interior //
    if ((s.length() >= 1 && (s.charAt(0) == '#' || s.charAt(0) == '!' )) ||
        (s.length() >= 2 && s.charAt(0) == '/' && s.charAt(1) =='/')) {
      return null;
    }
    Vector matches = new Vector();
    CmdAction c;
    int i,j,k;

    j = alist.size();
    for (i=0; i < j; i++) {
      c = (CmdAction)alist.get(i);
      String [] na = c.names();
      for (k=0; k < na.length; k++) {
        if (na[k].startsWith(s)) {
          matches.add(c);
        }
      }
    }

    // got it.
    if (matches.size() == 1) {
      return (CmdAction)matches.get(0);
    }

    // bogosity.
    if (matches.size() == 0) {
      cc.pn("Command "+s+" is undefined. Type 'help' for assistance.");
      if (cc.verbose()) {
        // call the help function here.
        Vector dummy = new Vector();
        dummy.add(alist);
        c = (CmdAction)alist.get(0); // Help command is always 0.
        try {
          c.doIt(cc,dummy);
        } catch(Exception e) {
          System.exit(2); // Help throwing an exception is bad.
        }

      }
      return null;
    }

    // ambiguity
    j = matches.size();
    cc.pn("Ambiguous command '"+s+"', try one of: ");
    for (i=0; i < j; i++) {
      c = (CmdAction)matches.get(i);
      String [] na = c.names();
      cc.p("   ");
      for (k=0; k < na.length; k++) {
        cc.p(na[k]+" ");
      }
    }
    return null;
  }


  // The following holds for all addXxxArg functions:
  // returns 0 if ok, -1 if error in next token, 1 if no next token.

  /** Converts the next token to a class (per app. definition) and adds to
      arg list. */
  private int addClassArg(StringTokenizer st, Vector args, StringBuffer cb) {

    if (!st.hasMoreTokens()) {
      return 1;
    }

    String tok = st.nextToken();

    String className = cc.getClass(tok);
    if (className == null) {
      cc.p("Unknown class {");
      cc.p(tok);
      cc.pn("}");
      return -1;
    }
    args.add(className);
    cb.append(" "+className);
    return 0;
  }

  /** Converts the next token to a Double and adds to arg list. */
  private int addDoubleArg(StringTokenizer st, Vector args, StringBuffer cb) {
    if (!st.hasMoreTokens()) {
      return 1;
    }
    String tok = st.nextToken();
    try {
      Double dval = new Double(tok);
      args.add(dval);
      cb.append(" "+dval);
    } catch (Exception e) {
      return -1;
    }
    return 0;
  }

  /** Converts the next token to a Integer and adds to arg list. */
  private int addIntegerArg(StringTokenizer st, Vector args, StringBuffer cb) {
    if (!st.hasMoreTokens()) {
      return 1;
    }
    String tok = st.nextToken();
    try {
      Integer ival = new Integer(tok);
      args.add(ival);
      cb.append(" "+ival);
    } catch (Exception e) {
      return -1;
    }
    return 0;
  }

  /** Converts the next token to a Integer and adds to arg list. */
  private int addLongArg(StringTokenizer st, Vector args, StringBuffer cb) {
    if (!st.hasMoreTokens()) {
      return 1;
    }
    String tok = st.nextToken();
    try {
      Long lval = new Long(tok);
      args.add(lval);
      cb.append(" "+lval);
    } catch (Exception e) {
      return -1;
    }
    return 0;
  }

  /** Converts the next token to a Boolean (more usefully than the
      broken java version and adds to arg list. */
  private int addBooleanArg(StringTokenizer st, Vector args, StringBuffer cb) {
    if (!st.hasMoreTokens()) {
      return 1;
    }
    boolean value;
    boolean assigned;
    value = false;
    assigned = false;
    String val = st.nextToken();
      if (val.compareToIgnoreCase("n")==0 ||
          val.compareToIgnoreCase("no")==0 ||
          val.compareToIgnoreCase("nyet")==0 ||
          val.compareToIgnoreCase("nada")==0 ||
          val.compareToIgnoreCase("zip")==0 ||
          val.compareToIgnoreCase("f")==0 ||
          val.compareToIgnoreCase("FALSE")==0 ||
          val.compareToIgnoreCase("0")==0 ||
          val.compareToIgnoreCase("wrong")==0 ||
          val.compareToIgnoreCase("buzz")==0) {

          value = false;
          assigned = true;

      }
      if (val.compareToIgnoreCase("y")==0 ||
          val.compareToIgnoreCase("yes")==0 ||
          val.compareToIgnoreCase("da")==0 ||
          val.compareToIgnoreCase("si")==0 ||
          val.compareToIgnoreCase("yep")==0 ||
          val.compareToIgnoreCase("t")==0 ||
          val.compareToIgnoreCase("TRUE")==0 ||
          val.compareToIgnoreCase("1")==0 ||
          val.compareToIgnoreCase("right")==0 ||
          val.compareToIgnoreCase("correct")==0 ||
          val.compareToIgnoreCase("ok")==0 ||
          val.compareToIgnoreCase("ding!")==0) {

        value = true;
        assigned = true;
      }

    if (assigned) {
      Boolean bval = new Boolean(value);
      args.add(bval);
      cb.append(" "+bval);
    } else {
      return -1;
    }
    return 0;
  }


  /** Converts the next token to an instance (per app. definition) and adds
      to arg list. */
  private int addInstanceArg(StringTokenizer st, Vector args, StringBuffer cb) {

    if (!st.hasMoreTokens()) {
      return 1;
    }

    String tok = st.nextToken();

    String instanceName = cc.getInstance(tok);
    if (instanceName == null) {
      cc.p("Unknown instance {");
      cc.p(tok);
      cc.pn("}");
      return -1;
    }
    args.add(instanceName);
    cb.append(" "+instanceName);
    return 0;
  }


  /** Converts the remaining tokens to a string and adds to arg list. */
  private int addLine(StringTokenizer st, Vector args, StringBuffer cb) {

    if (!st.hasMoreTokens()) {
      return 1;
    }

    StringBuffer sb = new StringBuffer(st.nextToken());
    while (st.hasMoreTokens()) {
      sb.append(" " + st.nextToken());
    }
    args.add(sb.toString());
    cb.append(" "+sb.toString());

    return 0;

  }


  /** Adds the next token as a string to the arg list */
  private int addStringArg(StringTokenizer st, Vector args, StringBuffer cb) {

    if (!st.hasMoreTokens()) {
      return 1;
    }

    String tok = st.nextToken();
    args.add(tok);
    cb.append(" "+tok);

    return 0;

  }

  public void setContextVerbose(boolean noisyHelp) {
    cc.setVerbose(noisyHelp);
  }

  /** Main command-line processing loop. Throws an IOException if
      app. readLine fails. Returns if the exit command throws an EOFException.
   */
  public void parse() throws IOException {



    while (true) {


      cc.p(cc.prompt());


      String read = cc.readLine();


      if (read == null) return;

      try {
          parse(read);                  


      }catch (EndOfFileException e){
          return;
      }



    }//while
  }//method





  /**
   * Parse one line of text.
   * @param read  one line of text that is to be parsed.
   * @throws EndOfFileException Thrown when we enounter
   * the end-of-file.
   * @throws java.io.IOException Thrown if an io error occurs.
   */
    public void parse(String read)
           throws EndOfFileException, java.io.IOException {

      StringTokenizer st = new StringTokenizer(read);

      if (!st.hasMoreTokens()) return;

      String tok = st.nextToken();

      CmdAction c = getAction(tok);

      if (c == null) return;

      StringBuffer sb = new StringBuffer(tok);

      String argtype = c.argtype();

      char ch, lastch;
      int err = 0;
      int alen, acount;

      acount = st.countTokens();
      alen = argtype.length();

      if ((alen <= 0 && acount != 0 ) ||
          (alen > 0 &&
           (lastch = argtype.charAt(alen-1)) != 'A' &&
           (lastch = argtype.charAt(alen-1)) != 'a' &&
           lastch != '*' &&
           alen < acount
          )
         ) {
        cc.pn("Too many arguments to "+tok);
        return;
      }

      lastch = 'A'; // so that * will kick out an error if it appears first.
      Vector args = new Vector();

      for (int i = 0; i < argtype.length(); i++) {

        ch = argtype.charAt(i);

        switch (ch)
        {
          case '*':
            switch (lastch)
            {
              case 'C':
              case 'c':
              case 'I':
              case 'i':
              case 'S':
              case 's':
              case 'D':
              case 'd':
              case 'K':
              case 'k':
              case 'B':
              case 'b':
              case 'G':
              case 'g':
                // FALLTHRU
                i -= 2;
                break;
              default:
                cc.pn("Error in CmdAction " + tok + ": argtype misdefined (" + argtype + ").");
                break;
            }//switch lastch
            break;
          case 'C':
            err = addClassArg(st,args,sb);
            break;
          case 'c':
            err = addClassArg(st,args,sb);
            if (err == 1) {
              err = 2;
            }
            break;
          case 'I':
            err = addInstanceArg(st,args,sb);
            break;
          case 'i':
            err = addInstanceArg(st,args,sb);
            if (err == 1) {
              err = 2;
            }
            break;
          case 'S':
            err = addStringArg(st,args,sb);
            break;
          case 's':
            err = addStringArg(st,args,sb);
            if (err == 1) {
              err = 2;
            }
            break;

          case 'K':
            err = addLongArg(st,args,sb);
            break;
          case 'k':
            err = addLongArg(st,args,sb);
            if (err == 1) {
              err = 2;
            }
            break;
          case 'D':
            err = addIntegerArg(st,args,sb);
            break;
          case 'd':
            err = addIntegerArg(st,args,sb);
            if (err == 1) {
              err = 2;
            }
            break;
          case 'B':
            err = addBooleanArg(st,args,sb);
            break;
          case 'b':
            err = addBooleanArg(st,args,sb);
            if (err == 1) {
              err = 2;
            }
            break;
          case 'G':
            err = addDoubleArg(st,args,sb);
            break;
          case 'g':
            err = addDoubleArg(st,args,sb);
            if (err == 1) {
              err = 2;
            }
            break;

          case 'A':
            err = addLine(st,args,sb);
            break;
          case 'a':
            err = addLine(st,args,sb);
            err = 0;
            break;
          case 'L':
            args.add(alist);
            err = 0;
            break;
          case 'P':
            args.add(this);
            err = 0;
            break;
          default:
            cc.pn("Unknown parser argtype (" + ch +")");
        }//switch ch

        if (err == -1) {
          // type specific errors will be printed in addXxxArg()
          break;
          // cc.pn("Skipping '" + read + "'");
        }
        if (err == 1) {
          cc.pn("Missing argument(s) in: '" + read + "'");
          break; // exit the for loop, bogus args.
        }
        if (err == 2) {
          err = 0;
          break; // exit the for loop, no more optional args.
        }

        lastch = ch;

      }

      if (err != 0) {
        return; // skip bogus input.
      }

      try {
	// cc.pn(sb.toString());
        c.doIt(cc,args);
      } catch (EOFException e) {
        //return;
        throw new EndOfFileException(e.getMessage());
      }


    }//method

}//class
