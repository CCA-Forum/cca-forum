package gov.sandia.ccaffeine.dc.distributed;

import java.util.EventObject;


/**
 * Used to pass a heartbeat from
 * one object to another object.
 */

public class HeartbeatEvent extends EventObject {


   /**
    * Create a heartbeat object.
    * @param source The object that created this
    * HeartbeatEvent.
    */
    public HeartbeatEvent(Object source) {
      super(source);
    }
}
