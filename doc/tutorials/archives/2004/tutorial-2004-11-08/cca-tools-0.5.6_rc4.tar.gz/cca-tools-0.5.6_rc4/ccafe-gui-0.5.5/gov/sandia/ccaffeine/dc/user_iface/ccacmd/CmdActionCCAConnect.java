package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;

public class CmdActionCCAConnect
       extends CmdActionCCA
       implements CmdAction {

  public CmdActionCCAConnect() {
  }

  public void doIt(CmdContext cc, Vector args) {

     /*
      * The number of arguments in the "connect" command
      */
     int numberOfArguments = args.size();

    /*
     * This is the name of the component that houses the
     * source port.  The source port is one of the two
     * connected ports.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    String sourceComponentName = null;
    if (numberOfArguments>0)
        sourceComponentName = (String)args.get(0);

    /**
     * This is the name of the source port.
     * The source port is connected to the target port.
     * Example:  "out0"
     */
      String sourcePortName = null;
      if (numberOfArguments>1)
          sourcePortName = (String)args.get(1);

      /*
       * The name of the component that houses the target port.
       * The target port is one of the two connected ports.
       * The name is usually the java class name of the component
       * (without the package name) concatenated with an index number.
       * Example:  "PrinterComponent0"
       */
      String targetComponentName = null;
      if (numberOfArguments>2)
          targetComponentName = (String)args.get(2);

      /*
       * This is the name of the target port.
       * The target port is connected to the source port.
       * Example:  "printer_port"
       */
      String targetPortName = null;
      if (numberOfArguments>3)
          targetPortName = (String)args.get(3);

      broadcastConnect
          (sourceComponentName,
           sourcePortName,
           targetComponentName,
           targetPortName);

  }

  public String help() {
    return
"<user instance> <UsesPort inst.> <provider inst.> <ProvidesPort inst.>\n"+
"          - make a connection between two instantiated components \n"+
"            residing in the arena.";
  }

  public String argtype() {
    return "ISIS";
  }

  public String[] names() {
    return namelist;
  }

  private static final String[] namelist = {"connect"};

}
