package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaConnectionBetweenTwoPorts;

public class CcaDisconnectTwoPortsEvent extends java.util.EventObject {

    /* The connection that is between two ports */
    protected CcaConnectionBetweenTwoPorts ccaConnection = null;

    /**
     * Get the cca connection that is between two ports.
     * @return The cca connection
     */
    public CcaConnectionBetweenTwoPorts getCcaConnection() {
       return(this.ccaConnection);
    }


    /**
     * Set the cca connection that is between two ports.
     * @param ccaConnection The cca connection
     */
    public void setCcaConnection(CcaConnectionBetweenTwoPorts ccaConnect) {
       this.ccaConnection = ccaConnection;
    }

    
    

    /**
     * Create a CcaDisconnectTwoPorts Event.
     * @param event The entity that generated this event.
     */
    public CcaDisconnectTwoPortsEvent(Object source) {
        super(source);
        this.ccaConnection = null;
    }


    /**
     * Create a CcaDisconnectTwoPorts Event.
     * @param event The entity that generated this event.
     * @param ccaConnect The cca connection that is between two ports.
     */
    public CcaDisconnectTwoPortsEvent
           (Object source,
            CcaConnectionBetweenTwoPorts ccaConnection) {
        super(source);
        this.ccaConnection = ccaConnection;
    }


}