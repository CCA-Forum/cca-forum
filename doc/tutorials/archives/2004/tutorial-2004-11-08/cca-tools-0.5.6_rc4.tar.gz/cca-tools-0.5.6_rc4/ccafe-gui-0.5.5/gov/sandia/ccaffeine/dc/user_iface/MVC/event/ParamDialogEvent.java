package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * This event can be used to notify components
 * that the cca server wants the client to
 * create (but not display) a dialog box
 * that contains the values
 * of all the data fields in the port.  A view
 * entity might respond by creating an empty
 * dialog box.
 * <p>
 * Possible Scenario: <br>
 * An end-user clicks on a blue port inside of a component <br>
 * client sends "parameters" to server <br>
 * serer- sends "ParamDialog" to client <br>
 * client responds by creating an empty dialog box <br>
 * server sends "ParamTab" to client <br>
 * client responds by inserting a new tab in the dialog box <br>
 * server sends "ParamField" to client <br>
 * client responds by inserting a blank data line into the dialog box <br>
 * server sends "ParamCurrent" to client <br>
 * client responds by inserting the data's value into the dialog box <br>
 * server sends "ParamHelp" to client <br>
 * client responds by setting the text that is displayed if the help button is clicked <br>
 * server sends "ParamPrompt" to client <br>
 * client responds by displaying a prompt to the left of the data's value <br>
 * server sends "ParamDefault" to client <br>
 * client responds by setting the data's default value <br>
 * server sends "ParamStringChoice" to client <br>
 * client responds by setting an item in the value's choice box <br>
 * server sends "ParamNumberRange" to client <br>
 * client responds by setting the data value's range of allowed values <br>
 * server sends  "ParamEndDialog" to client <br>
 * client responds by displaying the dialog box on the screen <br> *
 */

public class ParamDialogEvent extends EventObject {

  /*
   * The name of the cca component that contains
   * the port which contains the data fields.
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "TimeStamper0"
   */
    protected String componentInstanceName = null;

  /*
   * Ghe name of the cca component that contains
   * the port which contains the data fields.
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "TimeStamper0"
   * @return The name of a component.
   */
    public String getComponentInstanceName() {
        return(this.componentInstanceName);
    }

    /**
     * The instance name of a port that contains
     * the data fields.
     *  Example: "configure_port"
     */
    protected String portInstanceName = null;

    /**
     * Get the instance name of a port that
     * contains the data fields.
     *  Example: "configure_port"
     * @return The instance name of a port.
     */
    public String GetPortInstanceName() {
        return(this.portInstanceName);
    }


    /**
     * The title of
     * the dialog box.
     */
    protected String titleOfDialogBox = null;

    /**
     * Get the title of
     * the dialog box.
     * @return The title of the dialog box.
     */
    public String getTitleOfDialogBox() {
        return(this.titleOfDialogBox);
    }



    /**
     * Create a ParamDialogEvent.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * This event can be used to notify components
     * that the cca server wants the client to
     * create (but not display) a dialog box
     * that contains the values
     * of all the data fields in the port.  A view
     * entity might respond by creating an empty
     * dialog box.
     * @param source The entity that created this event.
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port which contains the data fields.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The instance name of a port that contains
     * the data fields.
     *  Example: "configure_port"
     * @param titleOfDialogBox
     * The title of
     * the dialog box.
     */
    public ParamDialogEvent
         (Object source,
          String componentInstanceName,
          String portInstanceName,
          String titleOfDialogBox) {

         super(source);
         this.componentInstanceName = componentInstanceName;
         this.portInstanceName = portInstanceName;
         this.titleOfDialogBox = titleOfDialogBox;
  }

}