package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;

public class CmdActionCCAPortProperties
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCAPortProperties() {
  }


  public String argtype() {
    return "ISssa";
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
    return
         "port-property <component-instance-name> <port-name>\n"
        +"   - show all the properties of a port on a component.\n"
        +"port-property <component-instance-name> <port-name> <key>\n"
        +"   - show all the named property of a component port, if it exists.\n"
        +"port-property <component-instance-name> <port-name> <key> <type> <value>\n"
        +"   - set the named property of a component port.";
  }


  private static final String[] namelist = {"port-property"};


  public void doIt(CmdContext cc, Vector args) {

       /*
        * The number of arguments in the "port-property"
        * command.
        */
       int numberOfArguments = args.size();

       /**
        * The name of the component that contains the property
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
       String componentInstanceName = null;
       if (numberOfArguments>0)
           componentInstanceName = (String)args.get(0);
       
       /**
        * The name of the port that contains the property
        */
       String portName = null;
       if (numberOfArguments>1)
           portName = (String)args.get(1);       

       /*
        * If we are getting or setting the value
        * of a specific property then we need the
        * name of the property.
        */
       String propertyName = null;
       if (numberOfArguments>2)
           propertyName = (String)args.get(2);

       /**
        * If we are setting the value of a
        * property then we need the datatype
        * of the value.
        */
       String dataTypeOfPropertyValue = null;
       if (numberOfArguments>3)
           dataTypeOfPropertyValue = (String)args.get(3);


       /*
        * If we are setting the value of a
        * property then we need the new value.
        */
       String propertyValue = null;
       if (numberOfArguments>3) {
           StringBuffer buffer = new StringBuffer((String)args.get(4));
           for (int i=5; i<numberOfArguments; i++) {
             buffer.append(" ");
             buffer.append(args.get(i));
           }
           propertyValue = buffer.toString();
       }

       this.broadcastPortProperties
           (numberOfArguments,
            componentInstanceName,
			portName,
            propertyName,
            dataTypeOfPropertyValue,
            propertyValue
            );


  }

}
