
package gov.sandia.ccaffeine.dc.user_iface.examples;

import gov.sandia.ccaffeine.dc.user_iface.BuilderClient;

import javax.swing.JFrame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.FlowLayout;
import java.lang.InterruptedException;

import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JPanel;


import java.util.Vector;
import gov.sandia.ccaffeine.dc.user_iface.examples.event.MessageEvent;
import gov.sandia.ccaffeine.dc.user_iface.examples.event.MessageListener;


/**
 * Display a GUI that will emulate a cca server.  You can use the GUI
 * to 1) send commands to the cca client 
 * and to 2) view data that the cca client sends to the cca server.
 * <p>
 * The purpose of this GUI is to test and/or debug the cca client.  
 * Instead of launching a cca server, this program launches a GUI.
 * You can use the GUI as a poor-man's cca server; i.e. you can use
 * the GUI's textboxes to type commands to the cca client and to
 * view query requests from the cca client.
 * <p>
 * Because most end-users are not familiar with commands that the
 * cca server can send to the cca client, I populated the GUI with
 * some buttons.  Each button generates commands to perform an
 * operation.  For example, the LOAD button generates all of the 
 * commands to populate the cca client's palette.
 */

public class InteractivelyTestGui extends JFrame implements MessageListener {
	
	
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/	
	
	/* contains the text that we want to send to the GUI */
	JTextArea textAreaToGui =  null;
	
	/* contains the text that we receive from the GUI */
	JTextArea textAreaFromGui = null;

	
	
	
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/	
	

        /**
         * Create, initialize, and render all of the GUI components.
         * <p>
         */
	public InteractivelyTestGui() {
		
		
		this.setSize(640,400);
		this.setVisible(true);
		this.addWindowListener(new MyWindowAdapter());
		
		GridBagLayout layout = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets.top = 10;
		gbc.insets.right = 10;
		gbc.insets.bottom = 10;
		gbc.insets.left = 10;
		
		this.getContentPane().setLayout(layout);

		/* button: send to GUI                                    */
                /* Sends the contents of textAreaToGui to the cca client. */
		JButton buttonToGui = new JButton("send to GUI");
		gbc.gridx = 0;
		gbc.gridy = 0;
		layout.setConstraints(buttonToGui, gbc);
		this.getContentPane().add(buttonToGui);
		buttonToGui.addActionListener(new ActionListenerToGui());
		
		/* textbox: send to GUI                               */
                /* The end-user can use this textbox to type commands */
                /* to the cca client.                                 */
		textAreaToGui = new JTextArea(5,40);
		JScrollPane scrollPaneToGui = new JScrollPane();
		scrollPaneToGui.getViewport().add(textAreaToGui);
		gbc.gridx = 1;
		gbc.gridy = 0;
		layout.setConstraints(scrollPaneToGui, gbc);
		this.getContentPane().add(scrollPaneToGui);

		/* label: msg frmo GUI */              
		JLabel labelFromGui = new JLabel("msg from GUI");
		gbc.gridx = 0;
		gbc.gridy = 1;
		layout.setConstraints(labelFromGui, gbc);
		this.getContentPane().add(labelFromGui);
		
		/* textbox: msg from GUI                                */
                /* If the cca client sends a query or some data to the  */
                /* cca server, it will be displayed inside of this      */
                /* textbox.                                             */
		textAreaFromGui = new JTextArea(5,40);		
		JScrollPane scrollPaneFromGui = new JScrollPane();
		scrollPaneFromGui.getViewport().add(textAreaFromGui);
		gbc.gridx = 1;
		gbc.gridy = 1;
		layout.setConstraints(scrollPaneFromGui, gbc);
		this.getContentPane().add(scrollPaneFromGui);
		
		/* control buttons:                                       */
                /* Most end-user's don't know what commands               */
                /* to type inside the textbox.  To help the end-user      */
                /* I gathered together a small set of the most frequently */
                /* used commands.  Pressing one of these buttons will     */
                /* populate the textbox with commands.  For example, the  */
                /* LOAD button populates the textbox will all of the      */
                /* commands needed to populate the cca client's palette.  */
		JPanel panelButtons = new JPanel();
		panelButtons.setLayout(new FlowLayout(FlowLayout.LEFT));
		
                /* Pressing this button generates the commands to */
                /* populate the cca client's palette.             */
		JButton buttonLoadComponents = 
			new JButton("<html>load<br>components</html>");
		panelButtons.add(buttonLoadComponents);
		buttonLoadComponents.addActionListener
		    (new ActionListenerLoadComponents());
		
                /* Pressing this button places 2 cca components */
                /* inside the cca client's arena, or workspace. */
		JButton buttonInstantiateComponents = 
			new JButton("<html>instantiate<br>components</html>");
		panelButtons.add(buttonInstantiateComponents);
		buttonInstantiateComponents.addActionListener
		    (new ActionListenerInstantiateComponents());
		
                /* Pressing this buton connects 2 components.       */
                /* The cca client renders the connections as lines; */
                /* i.e. lines are drawn between the components.     */
		JButton buttonConnectComponents =
			new JButton("<html>connect<br>components</html>");
		panelButtons.add(buttonConnectComponents);
		buttonConnectComponents.addActionListener
		    (new ActionListenerConnectComponents());	
		
                /* Pressing this button terminates this application */
		JButton buttonExit = new JButton("<html>exit<br> </html>");
		panelButtons.add(buttonExit);
		buttonExit.addActionListener(new ActionListenerExit());
		
		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.fill = gbc.HORIZONTAL;
		layout.setConstraints(panelButtons, gbc);
		this.getContentPane().add(panelButtons);;
		gbc.fill = gbc.NONE;
		
		validate();
		
		
	
	}


	
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/    
	
	/**
         * The end-user clicked on the "Exit" button.
         * Shut this application down.
         */
	protected class ActionListenerExit implements ActionListener {
		
		public void actionPerformed(ActionEvent event){
            System.exit(0);			
		}
	}

	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/    
	
	
	/**
         * The end-user has pressed the "Connect" button.
         * Send commands to the cca client that will connect
         * the 2 components which are displayed in the cca client's arena.
         * The cca client will render the connections by drawing
         * lines between the components.
         */
	protected class ActionListenerConnectComponents
	          implements ActionListener {		
		public void actionPerformed(ActionEvent event){

			BuilderClient.globalData.setDropLocation
	            (new java.awt.Point(50,50));
			StringBuffer s = new StringBuffer();
			s.append("connect StarterComponent0 out0 PrinterComponent0 printer_port\n");
			InteractivelyTestGui.this.textAreaToGui.setText(s.toString());
			InteractivelyTestGui.this.broadcastMessage(s.toString());
		}		
	}
	
	
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/    
	
	
        /**
         * The end-user has pressed the "Instantiate" button.
         * Send commands to the cca client that will render
         * 2 components in the cca client's arena.
         */
	protected class ActionListenerInstantiateComponents
	          implements ActionListener {
		public void actionPerformed(ActionEvent event){

			BuilderClient.globalData.setDropLocation
	            (new java.awt.Point(50,50));
			StringBuffer s = new StringBuffer();
			s.append("pulldown StarterComponent StarterComponent0\n");
			s.append("addProvidesPorts StarterComponent0 cProps ::classic::gov::cca::KeyValuePort go_port classic::gov::cca::GoPort\n");
			s.append("addUsesPorts StarterComponent0 out0 StringConsumerPort\n");
			InteractivelyTestGui.this.textAreaToGui.setText(s.toString());
			InteractivelyTestGui.this.broadcastMessage(s.toString());
			
			try {Thread.sleep(1000);}catch (InterruptedException e){}
			
			BuilderClient.globalData.setDropLocation
                (new java.awt.Point(150,150));
			s = new StringBuffer();
			s.append("pulldown PrinterComponent PrinterComponent0\n");
			s.append("addProvidesPorts PrinterComponent0 cProps ::classic::gov::cca::KeyValuePort printer_port StringConsumerPort\n");
			s.append("addUsesPorts PrinterComponent0\n");
			InteractivelyTestGui.this.textAreaToGui.append(s.toString());
			InteractivelyTestGui.this.broadcastMessage(s.toString());			
						
		}
	}
			
	
	
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/    
    	

        /**
         * The end-user has pressed the "load" button.
         * Send commands to the cca client that will 
         * populate the cca client's palette.
         */	
	protected class ActionListenerLoadComponents implements ActionListener {
		public void actionPerformed(ActionEvent event){
			
			StringBuffer s = new StringBuffer();
			s.append("Loaded StarterComponent NOW  GLOBAL\n"); 
			s.append("Loaded TimeStamper NOW  GLOBAL\n");
			s.append("Loaded Timer NOW  GLOBAL\n"); 
			s.append("Loaded PrinterComponent NOW  GLOBAL\n"); 
			s.append("Loaded ccafe1.StarterComponent NOW  PRIVATE\n"); 
			s.append("Loaded ccafe0.PrinterComponent NOW  PRIVATE\n");
			s.append("Loaded ccafe_eg.PortTranslatorStarter NOW  PRIVATE\n"); 
			s.append("addClass ccafe_eg.PortTranslatorStarter\n");
			s.append("addClass ccafe0.PrinterComponent\n");
			s.append("addClass ccafe1.StarterComponent\n");
			s.append("addClass TimeStamper\n");
			s.append("addClass Timer\n");
			s.append("addClass PrinterComponent\n");
			s.append("addClass StarterComponent\n");
			
			InteractivelyTestGui.this.textAreaToGui.setText(s.toString());
			InteractivelyTestGui.this.broadcastMessage(s.toString());
		}
	}
	
	
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/    
    
        /**
         * The end-user has pressed the "send" button.
         * Retrieve the text that is inside the textbox
         * and send that text to the cca client.
         */		
	protected class ActionListenerToGui implements ActionListener {
		public void actionPerformed(ActionEvent event){
			String message = InteractivelyTestGui.this.textAreaToGui.getText();
			InteractivelyTestGui.this.broadcastMessage(message);
		}
	}
	

        /**
         * The end-user clicked the x that is in the upper right
         * hand corner of the window.  Shut this application down.
         */
	protected class MyWindowAdapter extends WindowAdapter {
		public void windowClosing(WindowEvent event){
			System.exit(0);
		}
	}
	
	
	
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/    
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/    
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/    
	
    
    
    Vector messageListeners = new Vector();
    synchronized public void addMessageListener(MessageListener listener) 
    {
         messageListeners.add(listener);        
    }
    synchronized public void removeMessageListener(MessageListener listener) 
    {
         messageListeners.remove(listener);
    }
     
    public void broadcastMessage(String message){
        MessageEvent event = new MessageEvent(this, message);
        broadcastMessageEvent(event);
    }
     
    protected void broadcastMessageEvent(MessageEvent event) 
    {
         // loop through each listener and pass on the event if needed
         Vector listeners;
            synchronized (this) {
                listeners = (Vector)messageListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             MessageListener x = (MessageListener)listeners.elementAt(i);
             x.receivedMessage(event);         
         }
    }
     
  
    public void receivedMessage(MessageEvent event) {
        String message = event.getMessage();
        this.textAreaFromGui.append(message + "\n");
    }	

    
    
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/    
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/    
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/       
	
	public static void main(String[] args) {
		
		/* which port are we using */
		if (args.length!=1) {
			System.out.println("USAGE:  java UseScriptToTestGUI port");
			return;
		}
		
		/* convert the port to an int */
		int port = 0;
		try {
		    port = Integer.parseInt(args[0]);
		}catch (NumberFormatException e){
			System.out.println("USAGE:  java UseScriptToTestGUI port");
			return;
		}		

                System.out.println("setting up serverSocket on port " + port);
		
                /* Create the GUI components */
		InteractivelyTestGui interactivelyTestGui 
		    = new InteractivelyTestGui();

                /* Create the ServerSocket                                  */
                /* Create a server                                          */
                /* Create the the handler that will service the cca client. */
                /* The handler sends information from the GUI to the client.*/
                /* The handler also sends info from the client to the GUI.  */
		ServerSocketToTestGui serverSocketToTestGui 
		    = new ServerSocketToTestGui(port); 
		interactivelyTestGui.addMessageListener(serverSocketToTestGui);
		serverSocketToTestGui.addMessageListener(interactivelyTestGui);

                /* give the server some time to spin up */
  	        try {Thread.sleep(1000);} catch(Exception e){}

                /* launch the cca client */
  	        ThreadClient threadClient = new ThreadClient(port);
	        threadClient.start();
		
	}
}
