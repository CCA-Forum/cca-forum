package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Tthis event can be used to notify all listeners
 * that the cca server has revalidated all of the cca ports
 * in a cca component.
 * A view might respond by re-rendering all of the ports
 * that are inside a cca component.
 */

public class RevalidateEvent extends EventObject {


  /**
   * The name of the component that was revalidated.
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "StartComponent0"
   */
    protected String componentInstanceName = null;

  /*
   * Get the name of the component that was revalidated.
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "StartComponent0"
   */
    public String getComponentInstanceName() {
        return(this.componentInstanceName);
    }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Create a RevalidateEvent.
     * <p>
     * The cca server has revalidated all of the cca ports in
     * a cca component.
     * A view might respond by re-rendering all of the ports
     * that are inside a cca component.
     * <p>
     * @param source The entity that created this event.
     * @param componentInstanceName
     * The name of the component that was revalidated.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    public RevalidateEvent
           (Object source,
            String componentInstanceName) {

         super(source);
         this.componentInstanceName = componentInstanceName;
    }

}