package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotInstantiateComponentException extends Exception {


    public CanNotInstantiateComponentException() {
        super();
    }


    public CanNotInstantiateComponentException(String message) {
        super(message);
    }
}