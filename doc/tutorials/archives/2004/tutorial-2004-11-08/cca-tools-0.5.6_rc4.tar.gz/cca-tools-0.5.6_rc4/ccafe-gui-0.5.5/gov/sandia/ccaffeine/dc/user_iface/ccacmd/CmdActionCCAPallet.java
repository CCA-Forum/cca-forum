package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;

public class CmdActionCCAPallet
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCAPallet() {
  }


  public String argtype() {
    return "";
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
    return "show what component classes are in the pallet currently.";
  }


  private static final String[] namelist = {"pallet","classes"};


  public void doIt(CmdContext cc, Vector args) {

      this.broadcastDisplayPalette();

  }

}
