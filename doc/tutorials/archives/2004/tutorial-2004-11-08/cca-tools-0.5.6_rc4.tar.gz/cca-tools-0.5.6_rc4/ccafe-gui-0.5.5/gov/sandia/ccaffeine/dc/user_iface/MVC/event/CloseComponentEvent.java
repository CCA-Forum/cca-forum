package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

public class CloseComponentEvent extends java.util.EventObject {


    String componentClassName = null;


    /**
     * Get the class name of the closed component.
     * @return The class name of the closed component.
     */
    public String getComponentClassName() {
        return(this.componentClassName);
    }


    /**
     * Set the class name of the closed component.
     * @param componentClassName The class name of the closed component.
     */
    public void setComponentClassName(String componentClassName) {
        this.componentClassName = componentClassName;
    }



    /**
     * Create a CloseComponentEvent.
     * @param source The entity that created this event.
     */
    public CloseComponentEvent(Object source) {
        super(source);
        this.componentClassName = null;
    }

    /**
     * Create a CloseComponentEvent.
     * @param source The entity that created this event.
     * @param componentClassName The class name of the closed component.
     */
    public CloseComponentEvent(Object source,
                              String componentClassName) {
        super(source);
        this.componentClassName = componentClassName;
    }





}