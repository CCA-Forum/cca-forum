package gov.sandia.ccaffeine.dc.distributed;

import java.net.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;

/** Interface for a client of the ServerMux.  When the CLient receives
    output it notifies its ClientOutputListener's with an
    ClientOutputEvent. */
interface Client extends Runnable {
  /** Add a listener for Output from this client. */
  public void addClientOutputListener(ClientOutputListener l);
  /** Write a string to a client.*/
  public void write(String s);
  /** Flush the output already written to the client. */
  public void flush();
  /** Get the int ID unique over the ServerMux's clients */
  public int getId();
  /** Get the int ID unique over the ServerMux's clients */
  public String getSourceName();
  /** Finish IO and close input and output streams, does not terminate
      the thread.*/
  public void disconnect();
  /** Finish IO and close input and output streams, does not terminate
      the thread (but does signal the thread to stop when it gets a chance).*/
  public void shutdown();
}						 
