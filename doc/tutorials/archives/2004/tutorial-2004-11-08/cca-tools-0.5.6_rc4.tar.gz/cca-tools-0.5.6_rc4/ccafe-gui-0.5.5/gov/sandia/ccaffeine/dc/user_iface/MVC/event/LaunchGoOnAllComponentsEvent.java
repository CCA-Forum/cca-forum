package gov.sandia.ccaffeine.dc.user_iface.MVC.event;


public class LaunchGoOnAllComponentsEvent extends java.util.EventObject {



    /**
     * Create a LaunchGoOnAllComponentsEvent.
     * @param source The entity that created this event.
     */
    public LaunchGoOnAllComponentsEvent(Object source) {
        super(source);
    }



}