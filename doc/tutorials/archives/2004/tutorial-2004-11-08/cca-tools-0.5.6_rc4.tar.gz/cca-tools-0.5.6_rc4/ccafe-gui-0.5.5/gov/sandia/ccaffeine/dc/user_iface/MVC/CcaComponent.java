package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CcaComponent {


    public String className = "";
    public String instanceName = "";
    public CcaPort userPorts[] = new CcaPort[0];
    public CcaPort providerPorts[] = new CcaPort[0];
    public String status = "";



 


    /**
     * Parse the xml contents of a component.
     * The parsed values are copied into the class's attributes.
     * <p>
     * The XML code will contains something like this: <br>
     * &lt;component&gt; <br>
     * &nbsp;&lt;instanceName&gt;name1&lt;/instanceName&gt; <br>
     * &nbsp;&lt;className&gt;name2&lt;/className&gt; <br>
     * &nbsp;&lt;userPorts&gt; <br>
     * &nbsp;&nbsp;&lt;port&gt; <br>
     * &nbsp;&nbsp;&nbsp;&lt;instanceName&gt;x11&lt;/instanceName&gt; <br>
     * &nbsp;&nbsp;&nbsp;&lt;className&gt;x12&lt;/className&gt; <br>
     * &nbsp;&nbsp;&lt;/port&gt; <br>
     * &nbsp;&nbsp;&lt;port&gt; <br>
     * &nbsp;&nbsp;&nbsp;&lt;instanceName&gt;x21&lt;/instanceName&gt; <br>
     * &nbsp;&nbsp;&nbsp;&lt;className&gt;x22&lt;/className&gt; <br>
     * &nbsp;&nbsp;&lt;/port&gt; <br>
     * &nbsp;&lt;/userPorts&gt; <br>
     * &nbsp;&lt;providerPorts&gt; <br>
     * &nbsp;&nbsp;&lt;port&gt; <br>
     * &nbsp;&nbsp;&nbsp;&lt;instanceName&gt;y11&lt;/instanceName&gt; <br>
     * &nbsp;&nbsp;&nbsp;&lt;className&gt;y12&lt;/className&gt; <br>
     * &nbsp;&nbsp;&lt;/port&gt; <br>
     * &nbsp;&nbsp;&lt;port&gt; <br>
     * &nbsp;&nbsp;&nbsp;&lt;instanceName&gt;y21&lt;/instanceName&gt; <br>
     * &nbsp;&nbsp;&nbsp;&lt;className&gt;y22&lt;/className&gt; <br>
     * &nbsp;&nbsp;&lt;/port&gt; <br>
     * &nbsp;&lt;/providerPorts&gt; <br>
     * &lt;/component&gt; <br>
     * @param xmlComponent The xml code of one component.
     */
    public CcaComponent(String xmlComponent) {

        /*
         * Extract out the contents of the following tags:
         *    instanceName
         *    className
         *    userPorts
         *    providerPorts
         */
        java.util.regex.Pattern pattern = 
           java.util.regex.Pattern.compile
           ("<instanceName>(.*?)</instanceName>\\s*"
           +"<className>(.*?)</className>\\s*"
           +"<userPorts>(.*?)</userPorts>\\s*"
           +"<providerPorts>(.*?)</providerPorts>\\s*"
           +"<status>(.*?)</status>");

        java.util.regex.Matcher matcher = 
                pattern.matcher(xmlComponent);

        
        /* copy the contents of the 4 tags to our attributes */
        if (matcher.find()) {
            this.instanceName = matcher.group(1);
            this.className = matcher.group(2);
            this.userPorts = toCcaPorts(matcher.group(3));
            this.providerPorts = toCcaPorts(matcher.group(4));        
            this.status = matcher.group(5);
        }
    }




    /**
     * Parse the xml contents of several ports.
     * The parsed values are copied into the class's attributes.
     * <p>
     * The XML code will contains something like this: <br>
     * &lt;port&gt; <br>
     * &nbsp;&nbsp&lt;instanceName&gt;x1&lt;/instanceName&gt; <br>
     * &nbsp;&nbsp&lt;className&gt;x2&lt;/className&gt; <br>
     * &lt;/port&gt; <br>
     * &lt;port&gt; <br>
     * &nbsp;&nbsp&lt;instanceName&gt;y1&lt;/instanceName&gt; <br>
     * &nbsp;&nbsp&lt;className&gt;y2&lt;/className&gt; <br>
     * &lt;/port&gt; <br>
     * <p>
     * In this example, we will return an array of two ports.
     * The 1st port has an instance name of x1 and a classname of x2.
     * The 2nd port has an instance name of y1 and a classname of y2.
     * @param xmlPorts The xml code for one or more ports.
     * @return An arra the contains the ports we extracted
     * from the xml code.
     */
    protected CcaPort[] toCcaPorts(String xmlPorts) {

        /* We will store our extracted ports here */
        java.util.Vector vector = new java.util.Vector();

        /*
         * Extract out the contents of one or more ports
         */
        java.util.regex.Pattern pattern = 
           java.util.regex.Pattern.compile
           ("<port>(.*?)</port>");
        java.util.regex.Matcher matcher = 
                pattern.matcher(xmlPorts);

        
        /* extract the ports and store them in our vector */
        while (matcher.find()) {
            CcaPort ccaPort = new CcaPort(matcher.group(1));
            vector.add(ccaPort);
        }

        /* how many ports did we extract from the xml file? */
        int numberOfPorts = vector.size();
       

        /* copy the vector into an array */
        CcaPort ports[] = new CcaPort[numberOfPorts];
        vector.copyInto(ports);

        /* return the array of ports */
        return(ports);
    
    }



}