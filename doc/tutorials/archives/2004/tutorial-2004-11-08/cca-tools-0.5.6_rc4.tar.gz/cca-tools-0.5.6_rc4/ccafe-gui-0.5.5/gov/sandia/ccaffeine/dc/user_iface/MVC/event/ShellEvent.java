package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

/**
 * An entity can use this event to request
 * an O.S. command be executed.
 */

public class ShellEvent extends java.util.EventObject {

    /* the number of arguments in the "shell" command */
    protected int numberOfArguments = 0;

    /**
     * Retrieve the number of arguments in the "shell" command.
     * @return The number of arguments in the "shell" command.
     */
    public int getNumberOfArguments() {
        return(this.numberOfArguments);
    }


    /* The command that is to be executed */
    protected String command = null;


    /**
     * Return the command that is to be executed.
     * @return The command that is to be executed.
     */
    public String getCommand() {
        return(this.command);
    }



    /**
     * Create a ShellEvent.
     * This ShellEvent can be used
     * to transport an O.S. command
     * to a listener.
     * @param source The entity that created this event.
     * @param numberOfArguments The number of arguments
     * in the "shell" command.
     * @param command The command that is to be
     * executed.
     */
    public ShellEvent
           (Object source,
            int numberOfArguments,
            String command) {

         super(source);
         this.numberOfArguments = numberOfArguments;
         this.command = command;
    }

}