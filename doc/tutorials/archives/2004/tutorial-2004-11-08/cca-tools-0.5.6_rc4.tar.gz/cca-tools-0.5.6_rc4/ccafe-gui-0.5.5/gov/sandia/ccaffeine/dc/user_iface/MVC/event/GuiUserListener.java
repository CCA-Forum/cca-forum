package gov.sandia.ccaffeine.dc.user_iface.MVC.event;


/**
 * Request access to the GUI.
 */

public interface GuiUserListener extends java.util.EventListener {


  /**
   * The end-user wants to print a string.
   * A GUI might respond by writing the
   * string to standard out.
   * @param event The event that is generated whenever the
   * end-user wants to print a string.
   */
    public void print(PrintEvent event);

  /**
   * The end-user wants to print a string.
   * A GUI might respond by writing the
   * string to standard out.
   * @param event The event that is generated whenever 
   * the end-user wants to print a string.
   */
    public void println(PrintEvent event);


    /**
     * The end-user
     * wants to send a query to fetch a component instance.
     * A GUI might
     * respond by sending back a
     * ResultSetEvent.
     * @param event The event that is created whenever
     * an entity wants to fetch a component instance.
     */
    public void getComponentInstance
                (QueryEvent event);

    /**
     * The end-user
     * wants to send a query to fetch the class of
     * cca component.
     * A view entity might
     * respond by sending back a
     * ResultSetEvent.
     * @param event The event that is created whenever
     * the end-user wants to fetch the class of a component.
     */
    public void getComponentClass(QueryEvent event);

    /**
     * The end-user wants to send a query to fetch the
     * "waitingForPorts" flag.
     * A GUI might
     * respond by sending back a
     * ResultSetEvent.
     * @param event The event that is created whenever
     * the end-user wants to fetch the "waitingForPorts" flag.
     */
    public void getWaitingForPorts(QueryEvent event);

}