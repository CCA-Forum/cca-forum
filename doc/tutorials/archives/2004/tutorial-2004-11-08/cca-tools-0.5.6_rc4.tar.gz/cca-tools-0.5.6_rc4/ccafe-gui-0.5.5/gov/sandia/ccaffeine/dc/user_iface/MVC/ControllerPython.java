package gov.sandia.ccaffeine.dc.user_iface.MVC;

/**
 * An MVC controller.
 * This controller receives commands and data from
 * the cca server.
 */

import java.util.StringTokenizer;

import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUI;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIAddComponentClass;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIAddProvidesPorts;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIAddUsesPorts;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIConnect;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIDisconnect;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIExit;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIGetProperty;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIInstantiate;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUILoad;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIMessage;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamCurrent;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamDefault;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamDialog;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamEndDialog;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamField;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamHelp;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamNumberRange;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamPrompt;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamStringChoice;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIParamTab;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIRemove;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUIRevalidate;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUISetProperty;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdContextGUI;
import gov.sandia.ccaffeine.cmd.CmdParse;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaComponentPropertySetValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaComponentPropertyValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaComponentPropertyValuesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaConnectTwoPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaDisconnectTwoPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaConnectionsBetweenTwoPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CloseCcaFrameworkEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CloseComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ComponentClassNamesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ComponentInstancesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.FixSharedLibraryEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.InstantiateComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveInstantiatedComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveInstantiatedComponentsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.LaunchGoOnAllComponentsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.LaunchGoOnOneComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.LoadComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.OpenCcaFrameworkEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PythonControllerListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetPathToCcaComponentsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetPathsToCcaComponentsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ClientSocket;
import gov.sandia.ccaffeine.dc.user_iface.MVC.PythonStub;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ControllerListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiUserListener;

import gov.sandia.ccaffeine.dc.user_iface.MVC.event.AddComponentClassEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.InstantiateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.AddProvidesPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.AddUsesPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ConnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisconnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaComponent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaConnection;


import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaComponentInstanceNames;

import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPortParameterCurrentValue;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPortParameterDefaultValue;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPortParameterDialogBox;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPortParameterEndDialogBox;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPortParameterNewField;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPortParameterOneEnumeratedValue;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPortParameterPrompt;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPortParameterRangeOfValues;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterTabEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterCurrentValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterDefaultValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterDialogBoxEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterEndDialogBoxEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterNewFieldEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterOneEnumeratedValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterPromptEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterRangeOfValuesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParametersEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterTabEvent;

import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamCurrentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamDefaultEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamTabEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamNumberRangeEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamFieldEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamPromptEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamEndDialogEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamDialogEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamHelpEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterSetValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.MessageEvent;

import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetComponentPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GetComponentPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetDebugFlagEvent;


/*
 * Programmer's Notes:
 * scenario:  GUI wants to populate the palette
 *    GUI formulates a query that asks for all the components in the palette
 *    GUI sends a query to the ViewPython
 *        NOTE: The ViewPython is a GUI Listener
 *    ViewPython sends a query to the PythonStub
 *    The PythonStub forwards the query to the server skeleton
 *    The server skeleton forwards the query to the cca server
 *    The cca server sends the components to the server skeleton
 *    The server skeleton sends the components to the PythonStub
 *    The PythonStub sends the components to the ControllerPython
 *    The ControllerPython sends the events to the GUI
 *        NOTE:  The GUI is a ControllerListener
 */

public class ControllerPython implements PythonControllerListener {

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Create an MVC controller.
     * This controller receives input from the cca server.
     * @param pythonStub The stub for a python client
     */
    public ControllerPython(PythonStub pythonStub) {

        pythonStub.addPythonControllerListener(this);


    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/




    /**
     * The cca's python server has opened the cca framework.
     * @param event The event that is generated whenever the python
     * server is finished opening the cca framework.
     */
    public void openCcaFramework(OpenCcaFrameworkEvent event){
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The cca's python server has set the path to the cca components.
     * @param event The event that is generated whenever the python
     * server is finished setting the path to the cca components.
     */
    public void setPathToCcaComponents(SetPathToCcaComponentsEvent event){
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
      * The cca's python server has loaded a component.
      * A GUI might respond by displaying the component
      * in a palette.
      * @param event The event that is generated whenever the python
      * server is finished loading a component.
      */
    public void loadComponent(LoadComponentEvent event){
        String componentClassName = event.getComponentClassName();
        this.broadcastSetComponentClass(componentClassName);
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * the cca server is sending this client one instantiated
     * component.  A GUI might respond by displaying the
     * component in an arena(i.e workspace).
      * @param event The event that is generated whenever the python
      * server instantiates a component.
     */
    public void instantiateComponent
                (InstantiateComponentEvent event){

        String componentClassName = event.getClassName();
        String componentInstanceName = event.getInstanceName();
        CcaPort userPorts[] = event.getUserPorts();
        int numberOfUserPorts = userPorts.length;
        CcaPort providerPorts[] = event.getProviderPorts();
        int numberOfProviderPorts = providerPorts.length;

        /* tell the GUI to render this component in the arena */
        this.broadcastInstantiateComponentInArena
		    (componentClassName,
		     componentInstanceName);

        java.util.Vector vectorPorts = null;




        /* tell the GUI to render this component's provider ports */
        vectorPorts = new java.util.Vector();
        for (int i=0; i<numberOfProviderPorts; i++) {
        	vectorPorts.add(providerPorts[i].instanceName);
        	vectorPorts.add(providerPorts[i].className);
        }
        this.broadcastAddProvidesPorts(componentInstanceName, vectorPorts);



        /* tell the GUI to render this component's user ports */
        vectorPorts = new java.util.Vector();
        for (int i=0; i<numberOfUserPorts; i++) {
        	vectorPorts.add(userPorts[i].instanceName);
        	vectorPorts.add(userPorts[i].className);
        }
        this.broadcastAddUsesPorts(componentInstanceName, vectorPorts);
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The cca server is removing an instantiated component.
     * A GUI might respond by removing the component
     * from the arena (i.e. workspace).
     * @param event The event that is generated whenever the python
     * server removes an instantiated component.
     */
    public void removeInstantiatedComponent
                (RemoveInstantiatedComponentEvent event){

        String componentInstanceName = event.getInstanceName();

        this.broadcastRemovedInstantiateComponentFromArena
		    (componentInstanceName);
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The cca server is removing all instantiated components.
     * A GUI might respond by removing the components
     * from the arena (i.e. workspace).
     * @param event The event that is generated whenever the python
     * server removes an instantiated component.
     */
    public void removeInstantiatedComponents
                (RemoveInstantiatedComponentsEvent event){

        String instanceNames[] =
        	event.getInstanceNames().instanceNames;

        int numberOfComponents = instanceNames.length;
        for (int i=0; i<numberOfComponents; i++)
            this.broadcastRemovedInstantiateComponentFromArena(instanceNames[i]);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The cca server is connecting two ports.
     * A GUI might respond by drawing a line between the two ports.
     */
    public void connectTwoPorts(CcaConnectTwoPortsEvent event) {
    	String providerComponentName =
    		event.getCcaConnection().providesServiceComponentName;
    	String providerPortName =
    		event.getCcaConnection().providesServicePortName;
    	String userComponentName =
    		event.getCcaConnection().usesServiceComponentName;
    	String userPortName =
    		event.getCcaConnection().usesServicePortName;

    	this.broadcastConnection
		    (providerComponentName,
		     providerPortName,
			 userComponentName,
			 userPortName);
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The cca server is disconnecting two ports.
     * A GUI might respond by removing the line that
     * connects the two ports.
     */
    public void disconnectTwoPorts(CcaDisconnectTwoPortsEvent event){

    	this.broadcastDisconnectTwoPorts(event);

    }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The cca server is sending us all of the parameters for a port.
     * The GUI will display the parameters inside a dialog box.
     */
     public void receivedPortParameters(CcaPortParametersEvent event){
     	String xmlPortParameters = event.getXmlPortParameters();
     	if ((xmlPortParameters.startsWith("'"))
		 && (xmlPortParameters.endsWith("'")))
     		xmlPortParameters = xmlPortParameters.substring(1,xmlPortParameters.length()-2);
     	String tokens[] = xmlPortParameters.split("\\\\n");
        int numberOfTokens = tokens.length;
     	for (int i=0; i<numberOfTokens; i++){

     		String token = tokens[i];

     		if (token.indexOf("paramCurrent")!=-1){
    			CcaPortParameterCurrentValue x =
     				new CcaPortParameterCurrentValue(token);
    			this.broadcastCcaPortParameterCurrentValue(x);
    			continue;
     		}

     		if (token.indexOf("paramDefault")!=-1){
    			CcaPortParameterDefaultValue x =
     				new CcaPortParameterDefaultValue(token);
    			this.broadcastCcaPortParameterDefaultValue(x);
    			continue;
     		}


     		if (token.indexOf("newParamTab")!=-1){
    			CcaPortParameterTab x = new CcaPortParameterTab(token);
    			this.broadcastCcaPortParameterTab(x);
    			continue;
     		}

     		if (token.indexOf("paramPrompt")!=-1){
    			CcaPortParameterPrompt x = new CcaPortParameterPrompt(token);
    			this.broadcastCcaPortParameterPrompt(x);
    			continue;
     		}

     		if (token.indexOf("paramHelp")!=-1){
    			CcaPortParameterHelp x =
     				new CcaPortParameterHelp(token);
    			this.broadcastCcaPortParameterHelp(x);
    			continue;
     		}

     		if (token.indexOf("paramNumberRange")!=-1){
    			CcaPortParameterRangeOfValues x =
    				  new CcaPortParameterRangeOfValues(token);
    			this.broadcastCcaPortParameterRangeOfValues(x);
    			continue;
     		}

     		if (token.indexOf("newParamField")!=-1){
    			CcaPortParameterNewField x =
    				  new CcaPortParameterNewField(token);
    			this.broadcastCcaPortParameterNewField(x);
    			continue;
     		}

     		if (token.indexOf("paramEndDialog")!=-1){
     			CcaPortParameterEndDialogBox x =
    				  new CcaPortParameterEndDialogBox(token);
    			this.broadcastCcaPortParameterEndDialog(x);
    			continue;
     		}

     		if (token.indexOf("newParamDialog")!=-1){
     			CcaPortParameterDialogBox x =
    				  new CcaPortParameterDialogBox(token);
    			this.broadcastCcaPortParameterDialog(x);
    			continue;
     		}


     	}//for
     }



     /*-------------------------------------------------------------------*/
     /*-------------------------------------------------------------------*/


     /**
      * The server has set the value of a port parameter.
      * The GUI will write the value to stdout.
      */
     public void setPortParameterValue
         (CcaPortParameterSetValueEvent event){

     	CcaPortParameterValue ccaPortParameterValue =
     		event.getCcaPortParameterValue();
     	String componentInstanceName = ccaPortParameterValue.componentInstanceName;
     	String portInstanceName = ccaPortParameterValue.portInstanceName;
     	String dataFieldName = ccaPortParameterValue.dataFieldName;
     	String dataFieldValue = ccaPortParameterValue.dataFieldValue;

         this.broadcastMessage
 		   ( "updated  "
 		   + componentInstanceName + " "
 		   + portInstanceName + " "
 		   + dataFieldName + " "
 		   + dataFieldValue);


     }

     /*-------------------------------------------------------------------*/
     /*-------------------------------------------------------------------*/



     /**
      * The server wants the GUI to write the current
      * value of a component property to stdout.
      * @param event The event that is generated whenever
      * the cca server sends the value of component property.
      */
     public void receivedComponentPropertyValue(CcaComponentPropertyValueEvent event) {
     	CcaComponentPropertyValue ccaComponentPropertyValue =
     		event.getCcaComponentPropertyValue();
     	this.broadcastComponentPropertyValue
 		    (ccaComponentPropertyValue);

     }






     /**
      * The server wants the GUI to write the values
      * of all component properties to stdout.
      * @param event The event that is generated whenever
      * the cca server sends the values of one or more component properties.
      */
     public void receivedComponentPropertyValues(CcaComponentPropertyValuesEvent event) {
     	CcaComponentPropertyValue ccaComponentPropertyValues[] =
     		event.getCcaComponentPropertyValues();
     	this.broadcastComponentPropertyValues
 		    (ccaComponentPropertyValues);

     }

     /*-------------------------------------------------------------------*/
     /*-------------------------------------------------------------------*/



     /**
      * The cca server has set the value of a component property.
      * @param event The event that is generated whenever
      * the cca server sets the value of component property.
      */
     public void setComponentPropertyValue(CcaComponentPropertySetValueEvent event) {

     	CcaComponentPropertyValue ccaComponentPropertyValue =
     		event.getCcaComponentPropertyValue();

     	this.broadcastSetComponentPropertyValue
 		    (ccaComponentPropertyValue);

     }


     /*-------------------------------------------------------------------*/
     /*-------------------------------------------------------------------*/

     /**
      * The serer has set the value of the debug flag.
      */
     public void setDebugFlag(SetDebugFlagEvent event) {
     }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/





     /*-------------------------------------------------------------------*/
     /*-------------------------------------------------------------------*/



    /**
     * The cca's python server has fixed the shared library problem.
     * @param event The event that is generated whenever the python
     * server is finished fixing the shared library problem.
     */
    public void fixSharedLibrary(FixSharedLibraryEvent event){
    	System.out.println("GOT HERE");
    }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The cca's python server has set the paths to the cca components.
     * @param event The event that is generated whenever the python
     * server is finished setting the paths to the cca components.
     */
    public void setPathsToCcaComponents
        (SetPathsToCcaComponentsEvent event){
    	System.out.println("GOT HERE");
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * the cca server is sending this client the class names of
     * some components.  A GUI might respond by displaying the
     * components in a palette.
      * @param event The event that is generated whenever the python
      * server sends the class names of components.
     */
    public void receivedComponentClassNames
                (ComponentClassNamesEvent event){
    	System.out.println("GOT HERE");
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The cca server is sending this client some component instances.
     * A GUI might respond by displaying the components
     * in the arena (i.e workspace).
     */
    public void receivedComponentInstances
                (ComponentInstancesEvent event){
    	System.out.println("GOT HERE");
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The cca server is sending us info on all connections that
     * are between two ports.
     */
    public void receivedCcaConnectionsBetweenTwoPorts
          (CcaConnectionsBetweenTwoPortsEvent event){
    	System.out.println("GOT HERE");
    }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The cca server is launching the go command
     * from one component.
     */
    public void launchGoOnOneComponent(LaunchGoOnOneComponentEvent event){
    	String componentInstanceName =
    		event.getCommandGo().componentInstanceName;
    	String portInstanceName =
    		event.getCommandGo().portInstanceName;
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The cca server is launching the go command
     * on all components
     */
    public void launchGoOnAllComponents(LaunchGoOnAllComponentsEvent event){
    	System.out.println("GOT HERE");
    }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The cca server has closed a component.
     */
    public void closeComponent(CloseComponentEvent event){
    	System.out.println("GOT HERE");
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/




    /**
     * The cca framework is closed
     */
     public void closeCcaFramework(CloseCcaFrameworkEvent event){
     	System.out.println("GOT HERE");
     }



     /*-------------------------------------------------------------------*/
     /*-------------------------------------------------------------------*/
     /*-------------------------------------------------------------------*/
     /*-------------------------------------------------------------------*/
     /*-------------------------------------------------------------------*/
     /*-------------------------------------------------------------------*/

  /**
   * Connect two components by drawing a line from
   * a port on one of the components to a port on the
   * other component.
   * @param sourceComponent The source component
   * @param sourcePort The source port
   * @param targetComponent The target component
   * @param targetPort The target port
   */
  protected void broadcastConnection
      (String sourceComponentName,
       String sourcePortName,
       String targetComponentName,
       String targetPortName) {

    ConnectEvent event = new ConnectEvent
        (this,
         sourceComponentName,
         sourcePortName,
         targetComponentName,
         targetPortName);
    broadcastConnection(event);

  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * Connect two components.
   * @param event The event that is generated
   * whenever uses ports are to be added to a component.
   */
  protected void broadcastConnection
      (ConnectEvent event) {

    // loop through each listener and pass on the event if needed
    java.util.Vector listeners;
    synchronized (this) {
      listeners = (java.util.Vector) serverListeners.clone();
    }
    int numberOfListeners = listeners.size();
    for (int i = 0; i < numberOfListeners; i++) {
      ControllerListener x = (ControllerListener) listeners.elementAt(i);
      x.connect(event);
    }

  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * Add provides ports to a component.
   * @param componentInstanceName The name of the component
   * that is getting the new ports.
   * @param classNameAndNameOfAllPorts.  A vector that contains
   * the (className,instanceName) pair of every new port.
   */
  protected void broadcastAddProvidesPorts
      (String componentInstanceName,
       java.util.Vector classNameAndInstanceNameOfAllPorts) {

    AddProvidesPortsEvent event = new AddProvidesPortsEvent
        (this,
         componentInstanceName,
         classNameAndInstanceNameOfAllPorts);
    broadcastAddProvidesPorts(event);

  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * Add uses ports to a component.
   * @param componentInstanceName The name of the component
   * that is getting the new ports.
   * @param classNameAndNameOfAllPorts.  A vector that contains
   * the (className,instanceName) pair of every new port.
   */
  protected void broadcastAddUsesPorts
      (String componentInstanceName,
       java.util.Vector classNameAndInstanceNameOfAllPorts) {

    AddUsesPortsEvent event = new AddUsesPortsEvent
        (this,
         componentInstanceName,
         classNameAndInstanceNameOfAllPorts);
    broadcastAddUsesPorts(event);

  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * Add uses ports to a component.
   * @param event The event that is generated
   * whenever uses ports are to be added to a component.
   */
  protected void broadcastAddProvidesPorts
      (AddProvidesPortsEvent event) {

    // loop through each listener and pass on the event if needed
    java.util.Vector listeners;
    synchronized (this) {
      listeners = (java.util.Vector) serverListeners.clone();
    }
    int numberOfListeners = listeners.size();
    for (int i = 0; i < numberOfListeners; i++) {
      ControllerListener x = (ControllerListener) listeners.elementAt(i);
      x.addProvidesPorts(event);
    }

  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * Add uses ports to a component.
   * @param event The event that is generated
   * whenever uses ports are to be added to a component.
   */
  protected void broadcastAddUsesPorts
      (AddUsesPortsEvent event) {

    // loop through each listener and pass on the event if needed
    java.util.Vector listeners;
    synchronized (this) {
      listeners = (java.util.Vector) serverListeners.clone();
    }
    int numberOfListeners = listeners.size();
    for (int i = 0; i < numberOfListeners; i++) {
      ControllerListener x = (ControllerListener) listeners.elementAt(i);
      x.addUsesPorts(event);
    }

  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * Add a component instance to the arena.
   * @param componentIntanceName The name
   * of the component that will be placed
   * on the arena.
   */
  protected void broadcastInstantiateComponentInArena
      (String componentClassName,
       String componentInstanceName) {

    InstantiateEvent event = new InstantiateEvent
        (this,
         componentClassName,
         componentInstanceName);
    broadcastInstantiateComponentInArena(event);

  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * Add a component instance to the arena.
   * @param event The event that is generated whenever
   * a component is instantiated.
   */
  protected void broadcastInstantiateComponentInArena
      (InstantiateEvent event) {

    // loop through each listener and pass on the event if needed
    java.util.Vector listeners;
    synchronized (this) {
      listeners = (java.util.Vector) serverListeners.clone();
    }
    int numberOfListeners = listeners.size();
    for (int i = 0; i < numberOfListeners; i++) {
      ControllerListener x = (ControllerListener) listeners.elementAt(i);
      x.instantiate(event);
    }

  }



  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * Remove an instantiated component from the arena.
   * @param componentIntanceName The name
   * of the component that will be removed from
   * the arena.
   */
  protected void broadcastRemovedInstantiateComponentFromArena
      (String componentInstanceName) {

    RemoveEvent event = new RemoveEvent(this, componentInstanceName);
    broadcastRemovedInstantiateComponentFromArena(event);

  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * Remove an instantiated component from the arena.
   * @param event The event that is generated whenever
   * an instantiated component is removed.
   */
  protected void broadcastRemovedInstantiateComponentFromArena
      (RemoveEvent event) {

    // loop through each listener and pass on the event if needed
    java.util.Vector listeners;
    synchronized (this) {
      listeners = (java.util.Vector) serverListeners.clone();
    }
    int numberOfListeners = listeners.size();
    for (int i = 0; i < numberOfListeners; i++) {
      ControllerListener x = (ControllerListener) listeners.elementAt(i);
      x.remove(event);
    }

  }






  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * Add a component class to the palette.
   * @param componentClassName The name
   * of the class that will be placed
   * on the palette.
   */
  protected void broadcastSetComponentClass
      (String componentClassName) {

    AddComponentClassEvent event = new AddComponentClassEvent
        (this,
         componentClassName);
    broadcastSetComponentClass(event);

  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * Add a class to the palette.
   * @param event The event that is generated
   * whenever a class is to be added to the palette.
   */
  protected void broadcastSetComponentClass
      (AddComponentClassEvent event) {

    // loop through each listener and pass on the event if needed
    java.util.Vector listeners;
    synchronized (this) {
      listeners = (java.util.Vector) serverListeners.clone();
    }
    int numberOfListeners = listeners.size();
    for (int i = 0; i < numberOfListeners; i++) {
      ControllerListener x = (ControllerListener) listeners.elementAt(i);
      x.addComponentClass(event);

    }

  }


  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * Disconnect two ports.
   * @param sourceComponentName the component where
   * the disconnect originated from.
   * @param sourcePortName the port where the
   * disconnect originated from.
   * @param targetComponentName the component that is
   * at the other end of the connection.
   * @param targetPortName the port that is
   * at the other end of the connection
   */
  protected void broadcastDisconnectTwoPorts
  (CcaDisconnectTwoPortsEvent event) {

	String userComponentName =
		event.getCcaConnection().usesServiceComponentName;
	String userPortName =
		event.getCcaConnection().usesServicePortName;
	String providerComponentName =
		 event.getCcaConnection().providesServiceComponentName;
	String providerPortName =
		event.getCcaConnection().providesServicePortName;

     DisconnectEvent event1 = new DisconnectEvent
         (this,
          providerComponentName,
          providerPortName,
          userComponentName,
          userPortName);
     broadcastDisconnectTwoPorts(event1);


  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * Disconnect two ports.
   * @param DisconnectEvent The event that is generated
   * whenever a connection is to be broken.
   */
  protected void broadcastDisconnectTwoPorts
      (DisconnectEvent event) {

    // loop through each listener and pass on the event if needed
    java.util.Vector listeners;
    synchronized (this) {
      listeners = (java.util.Vector) serverListeners.clone();
    }
    int numberOfListeners = listeners.size();
    for (int i = 0; i < numberOfListeners; i++) {
      ControllerListener x = (ControllerListener) listeners.elementAt(i);
      x.disconnect(event);

    }

  }





  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/


  /**
   * Tell the GUI to display the current value of a specific
   * port parameter
   * @param x Contains information on the port parameter.
   */
  protected void broadcastCcaPortParameterCurrentValue
      (CcaPortParameterCurrentValue x) {
  	ParamCurrentEvent event = new ParamCurrentEvent
	    (this,
	     x.componentInstanceName,
		 x.portInstanceName,
		 x.dataFieldName,
		 x.dataFieldValue);
  	broadcastCcaPortParameterCurrentValue(event);
  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

 /**
  * Tell the GUI to display the current value of a specific
  * port parameter
  * @param event The event that is generated whenever the cca server
  * wants the GUI to display the current value of a port parameter.
  */
  protected void broadcastCcaPortParameterCurrentValue(ParamCurrentEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector) serverListeners.clone();
        }
        int numberOfListeners = listeners.size();
        for (int i = 0; i < numberOfListeners; i++) {
            ControllerListener x = (ControllerListener) listeners.elementAt(i);
            x.paramCurrent(event);
        }

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


  /**
   * Tell the GUI the default value of a specific port parameter.
   * @param x Contains information on the port parameter.
   */
    protected void broadcastCcaPortParameterDefaultValue
    (CcaPortParameterDefaultValue x) {
	ParamDefaultEvent event = new ParamDefaultEvent
	    (this,
	     x.componentInstanceName,
		 x.portInstanceName,
		 x.dataFieldName,
		 x.dataFieldDefaultValue);
	broadcastCcaPortParameterDefaultValue(event);
}

/*-------------------------------------------------------------------*/
/*-------------------------------------------------------------------*/


    /**
     * Tell the GUI the default value of a specific port parameter.
     * @param event The event that is generated whenever the cca server
     * generates the default value of a port parameter.
     */
    protected void broadcastCcaPortParameterDefaultValue(ParamDefaultEvent event) {

      // loop through each listener and pass on the event if needed
      java.util.Vector listeners;
      synchronized (this) {
          listeners = (java.util.Vector) serverListeners.clone();
      }
      int numberOfListeners = listeners.size();
      for (int i = 0; i < numberOfListeners; i++) {
          ControllerListener x = (ControllerListener) listeners.elementAt(i);
          x.paramDefault(event);
      }

  }


  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/


    /**
     * Tell the GUI to create a tabbed pane.  The cca server will later
     * use the tabbed pane to dispay the values of port parameters.
     * @param x Contains information about the tabbed pane.
     */
    protected void broadcastCcaPortParameterTab(CcaPortParameterTab x) {
  	  ParamTabEvent event = new ParamTabEvent
	      (this,
	       x.componentInstanceName,
	       x.portInstanceName,
		   x.tabName);
  	  broadcastCcaPortParameterTab(event);

  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/
    /**
     * Tell the GUI to create a tabbed pane.  The cca server will later
     * use the tabbed pane to dispay the values of port parameters.
     * @param event The event that is generated whenever the cca server
     * wants the GUI to create a tabbed pane.
     */
    protected void broadcastCcaPortParameterTab(ParamTabEvent event){
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector) serverListeners.clone();
        }
        int numberOfListeners = listeners.size();
        for (int i = 0; i < numberOfListeners; i++) {
            ControllerListener x = (ControllerListener) listeners.elementAt(i);
            x.paramTab(event);
        }

    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

   /**
    * Tell the GUI the lower and upper bounds that the value of
    * a specific port parameter is allowed to have.
    * @param x Contains information about the parameter.
    */
    protected void broadcastCcaPortParameterRangeOfValues
	     (CcaPortParameterRangeOfValues x) {
    	ParamNumberRangeEvent event = new ParamNumberRangeEvent
  	      (this,
  	       x.componentInstanceName,
  	       x.portInstanceName,
		   x.dataFieldName,
  		   x.dataFieldMinValue,
		   x.dataFieldMaxValue);
    	broadcastCcaPortParameterRangeOfValues(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell the GUI the lower and upper bounds that the value of
     * a specific port parameter is allowed to have.
     * @param event The event that is generated whenever the cca server
     * determines the lower and upper bounds of a port parameter.
     */
      protected void broadcastCcaPortParameterRangeOfValues
	      (ParamNumberRangeEvent event){

          // loop through each listener and pass on the event if needed
          java.util.Vector listeners;
          synchronized (this) {
              listeners = (java.util.Vector) serverListeners.clone();
          }
          int numberOfListeners = listeners.size();
          for (int i = 0; i < numberOfListeners; i++) {
              ControllerListener x = (ControllerListener) listeners.elementAt(i);
              x.paramNumberRange(event);
          }

      }


      /*-------------------------------------------------------------------*/
      /*-------------------------------------------------------------------*/



    /**
     * Tell the GUI to create a field to hold a new port parameter.
     * @param x Contains information on the parameter.
     */
      protected void broadcastCcaPortParameterNewField
  	     (CcaPortParameterNewField x) {
      	ParamFieldEvent event = new ParamFieldEvent
    	      (this,
    	       x.componentInstanceName,
    	       x.portInstanceName,
			   x.dataFieldDataType,
			   x.dataFieldName);
      	broadcastCcaPortParameterNewField(event);

      }

      /*-------------------------------------------------------------------*/
      /*-------------------------------------------------------------------*/


    /**
     * Tell the GUI to create a field to hold a new port parameter.
     * @param event The event that is created whenever the cca server
     * creates a new port parameter.
     */
        protected void broadcastCcaPortParameterNewField
  	      (ParamFieldEvent event){

            // loop through each listener and pass on the event if needed
            java.util.Vector listeners;
            synchronized (this) {
                listeners = (java.util.Vector) serverListeners.clone();
            }
            int numberOfListeners = listeners.size();
            for (int i = 0; i < numberOfListeners; i++) {
                ControllerListener x = (ControllerListener) listeners.elementAt(i);
                x.paramField(event);
            }

        }


        /*-------------------------------------------------------------------*/
        /*-------------------------------------------------------------------*/


    /**
     * Tell the GUI the value of the prompt of a specific port parameter.
     * The GUI will display the prompt to the left of the parameter.
     * @param x Contains information on the parameter.
     */
        protected void broadcastCcaPortParameterPrompt
    	     (CcaPortParameterPrompt x) {
        	ParamPromptEvent event = new ParamPromptEvent
      	      (this,
      	       x.componentInstanceName,
      	       x.portInstanceName,
    		   x.dataFieldName,
      		   x.dataFieldPrompt);
        	broadcastCcaPortParameterPrompt(event);

        }

        /*-------------------------------------------------------------------*/
        /*-------------------------------------------------------------------*/

        /**
         * Tell the GUI the value of the prompt of a specific port parameter.
         * The GUI will display the prompt to the left of the parameter.
         * @param event The event that is generated whenever the cca server
         * creates a prompt for a port parameter.
         */
        protected void broadcastCcaPortParameterPrompt
	      (ParamPromptEvent event){

          // loop through each listener and pass on the event if needed
          java.util.Vector listeners;
          synchronized (this) {
              listeners = (java.util.Vector) serverListeners.clone();
          }
          int numberOfListeners = listeners.size();
          for (int i = 0; i < numberOfListeners; i++) {
              ControllerListener x = (ControllerListener) listeners.elementAt(i);
              x.paramPrompt(event);
          }

      }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Tell the GUI that the cca server is finished
     * creating all of the parameters that belong to a port.
     * The GUI will finish constructing the dialog box
     * (i.e. the dialog box contains information on the parameters).
     * @param x Information on the port parameters.
     */
    protected void broadcastCcaPortParameterEndDialog
	     (CcaPortParameterEndDialogBox x) {
    	ParamEndDialogEvent event = new ParamEndDialogEvent
 	      (this,
 	       x.componentInstanceName,
 	       x.portInstanceName);
    	broadcastCcaPortParameterEndDialog(event);

   }



	    /*-------------------------------------------------------------------*/
	    /*-------------------------------------------------------------------*/

   /**
    * Tell the GUI that the cca server is finished
    * creating all of the parameters that belong to a port.
    * The GUI will finish constructing the dialog box
    * (i.e. the dialog box contains information on the parameters).
    * @param event The event that is generated whenever the cca server
    * is finished creating all of the parameters of a specific port.
    */
    protected void broadcastCcaPortParameterEndDialog
        (ParamEndDialogEvent event){

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector) serverListeners.clone();
        }
        int numberOfListeners = listeners.size();
        for (int i = 0; i < numberOfListeners; i++) {
            ControllerListener x = (ControllerListener) listeners.elementAt(i);
            x.paramEndDialog(event);
       }

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Tell the GUI to create an empty dialog box.
     * The cca server will later use the dialog box
     * to display the values of all the parameters that
     * belong to a port.
     * @param x Information about the dialog box
     */
    protected void broadcastCcaPortParameterDialog
	     (CcaPortParameterDialogBox x) {
    	ParamDialogEvent event = new ParamDialogEvent
 	      (this,
 	       x.componentInstanceName,
 	       x.portInstanceName,
		   x.titleOfDialogBox);
    	broadcastCcaPortParameterDialog(event);

   }



	    /*-------------------------------------------------------------------*/
	    /*-------------------------------------------------------------------*/

    /**
     * Tell the GUI to create an empty dialog box.
     * The cca server will later use the dialog box
     * to display the values of all the parameters that
     * belong to a port.
     * @param event The event that is created whenever the cca server
     * wants the GUI to display the values of all the paramters
     * of a specific port.
     */
    protected void broadcastCcaPortParameterDialog
        (ParamDialogEvent event){

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector) serverListeners.clone();
        }
        int numberOfListeners = listeners.size();
        for (int i = 0; i < numberOfListeners; i++) {
            ControllerListener x = (ControllerListener) listeners.elementAt(i);
            x.paramDialog(event);
       }

    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Tell the GUI to construct a tooltip for a port parameter.
     * @param x Contains information about the parameter.
     */
    protected void broadcastCcaPortParameterHelp
	     (CcaPortParameterHelp x) {
    	ParamHelpEvent event = new ParamHelpEvent
 	      (this,
 	       x.componentInstanceName,
 	       x.portInstanceName,
		   x.dataFieldName,
		   x.dataFieldHelp);
    	broadcastCcaPortParameterHelp(event);

   }



	    /*-------------------------------------------------------------------*/
	    /*-------------------------------------------------------------------*/


    /**
     * Tell the GUI to construct a tooltip for a port parameter.
     * @param event The event that is created whenever the cca server
     * constructs a helpful message for a port parameter.
     */
    protected void broadcastCcaPortParameterHelp
        (ParamHelpEvent event){

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector) serverListeners.clone();
        }
        int numberOfListeners = listeners.size();
        for (int i = 0; i < numberOfListeners; i++) {
            ControllerListener x = (ControllerListener) listeners.elementAt(i);
            x.paramHelp(event);
       }

    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Tell the GUI to write a message to stdout.
     * @param message The contents of the message.
     */
    protected void broadcastMessage
	     (String message) {
    	MessageEvent event = new MessageEvent
 	      (this,
 	       message);
    	broadcastMessage(event);

   }



	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/


    /**
     * Tell the GUI to write a message to stdout.
     * @param event The event that is generated whenever the
     * cca server wants the GUI to write a message to stdout.
     */
    protected void broadcastMessage
        (MessageEvent event){

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector) serverListeners.clone();
        }
        int numberOfListeners = listeners.size();
        for (int i = 0; i < numberOfListeners; i++) {
            ControllerListener x = (ControllerListener) listeners.elementAt(i);
            x.message(event);
       }

    }



	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/


    /**
     * Tell the GUI the value of a component property.
     * @param ccaComponentPropertyValue Contains
     * information on a component property.
     */
    protected void broadcastSetComponentPropertyValue
        (CcaComponentPropertyValue ccaComponentPropertyValue){

		String componentInstanceName =
			ccaComponentPropertyValue.componentInstanceName;

		String propertyName =
			ccaComponentPropertyValue.propertyName;

		String propertyValue =
			ccaComponentPropertyValue.propertyValue;

		SetComponentPropertyEvent event =
			new SetComponentPropertyEvent
			(this,
			 componentInstanceName,
			 propertyName,
			 propertyValue);

		broadcastSetComponentPropertyValue(event);


	}


	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/

    /**
     * Tell the GUI the value of a component property.
     * @param event The event that is generated whenever the cca server
     * constructs a new component property or whenever the server changes
     * the value of the component property.
     */
    protected void broadcastSetComponentPropertyValue
        (SetComponentPropertyEvent event){

	    // loop through each listener and pass on the event if needed
	    java.util.Vector listeners;
	    synchronized (this) {
	        listeners = (java.util.Vector) serverListeners.clone();
	    }
	    int numberOfListeners = listeners.size();
	    for (int i = 0; i < numberOfListeners; i++) {
	        ControllerListener x = (ControllerListener) listeners.elementAt(i);
	        x.setComponentProperty(event);
	   }

	}




	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/


    /**
     * Tell the GUI to write the value of the component
     * property to stdout.
     * @param ccaComponentPropertyValue Contains the
     * name of the property that we are interested in.
     */
	protected void broadcastComponentPropertyValue
        (CcaComponentPropertyValue ccaComponentPropertyValue){

		String componentInstanceName =
			ccaComponentPropertyValue.componentInstanceName;

		String propertyName =
			ccaComponentPropertyValue.propertyName;

		String propertyValue =
			ccaComponentPropertyValue.propertyValue;

		GetComponentPropertyEvent event =
			new GetComponentPropertyEvent
			(this,
			 componentInstanceName,
			 propertyName);

		broadcastComponentPropertyValue(event);


	}


	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/


	/**
	 * Tell the GUI to write, to stdout, the current value of a
	 * specific component property.
	 * @param event The event that is generated whenever the cca
	 * server wants the GUI to display the current value of a
	 * component property.
	 */
    protected void broadcastComponentPropertyValue
        (GetComponentPropertyEvent event){

	    // loop through each listener and pass on the event if needed
	    java.util.Vector listeners;
	    synchronized (this) {
	        listeners = (java.util.Vector) serverListeners.clone();
	    }
	    int numberOfListeners = listeners.size();
	    for (int i = 0; i < numberOfListeners; i++) {
	        ControllerListener x = (ControllerListener) listeners.elementAt(i);
	        x.getComponentProperty(event);
	   }

	}



	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/







	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/


    /**
     * Tell the GUI to display information on several
     * properties.
     * @param ccaComponentPropertyValues Contains the names
     * of several properties.
     */
	protected void broadcastComponentPropertyValues
        (CcaComponentPropertyValue ccaComponentPropertyValues[]){

		int numberOfProperties = ccaComponentPropertyValues.length;

		for (int i=0; i<numberOfProperties; i++){
			broadcastComponentPropertyValue(ccaComponentPropertyValues[i]);
		}
	}




  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  java.util.Vector serverListeners = new java.util.Vector();

  synchronized public void addControllerListener(ControllerListener listener) {
    serverListeners.add(listener);
  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  synchronized public void removeControllerListener(ControllerListener listener) {
    serverListeners.remove(listener);
  }


  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  java.util.Vector accessGuiListeners = new java.util.Vector();

  synchronized public void addAccessGuiListener(ControllerListener listener) {
    accessGuiListeners.add(listener);
  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  synchronized public void removeAccessGuiListener(ControllerListener listener) {
    accessGuiListeners.remove(listener);
  }







}
