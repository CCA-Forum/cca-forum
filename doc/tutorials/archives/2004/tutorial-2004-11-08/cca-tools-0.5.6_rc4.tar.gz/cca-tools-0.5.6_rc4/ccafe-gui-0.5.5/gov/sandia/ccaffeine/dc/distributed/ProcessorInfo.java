package gov.sandia.ccaffeine.dc.distributed;

public class ProcessorInfo {
  private String name;
  private boolean isServer;
  public ProcessorInfo(String name, boolean isServer) {
    this.name = name;
    this.isServer = isServer;
  }
  String getName() {return name;}
  boolean isServer(){return isServer;}
  public String toString() {
    String type;
    if(isServer) {
      type = "is a server";
    } else {
      type = "is a client";
    }
    return "ProcessorInfo: name = "+name+", "+type+"\n";
  }
}
