package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Tis event can be used
 * to notify components that this entity
 * wants to invoke the "go" command
 * on a specific port that is located
 * on a specific component.  A view might
 * respond by sending a "go" or a "run" message
 * to the cca server.
 */

public class GoComponentPortEvent extends EventObject {

    /*
     * The name of the
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
    */
    protected String componentInstanceName = null;


    /*
     * Get the name of the
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
    */
    public String getComponentInstanceName() {
        return(this.componentInstanceName);
    }


    /**
     * The name of the GO port.
     */
    protected String portInstanceName = null;

    /**
     * Get the name of the GO port.
     * @return The instance name of the GO port.
     */
    public String getPortInstanceName() {
        return(this.portInstanceName);
    }



    /**
     * Create a GoComponentPortEvent.
     * This event can be used
     * to notify components that this entity
     * wants to invoke the "go" command
     * on a specific port that is located
     * on a specific component.  A view might
     * respond by sending a "go" or a "run" message
     * to the cca server.
     * @param source The entity that created this event
     * @param componentInstanceName
     * The name of the
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     * @param portInstanceName
     * The name of the GO port
     */
    public GoComponentPortEvent
        (Object source,
         String componentInstanceName,
         String portInstanceName) {

        super(source);
        this.componentInstanceName = componentInstanceName;
        this.portInstanceName = portInstanceName;
    }

}