package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * This event can be used to notify components
 * that an entity wants to know what components
 * are in the palette.  A palette is a menu of
 * cca components; the end-user can drag components
 * from the palette to the arena (workspace).
 * A view might respond
 * by rending icons in the palette.  The end-user
 * can drag icons from the palette onto the
 * main workspace (the arena).
 */

public class DisplayPaletteEvent extends EventObject {

  /**
   * Create a DisplayPaletteEvent.
   * This event can be used to notify components
   * that an entity wants to know what components
   * are in the palette.  A palette is a menu of
   * cca components; the end-user can drag components
   * from the palette to the arena (workspace).
   * A view might respond
   * by rending icons in the palette.  The end-user
   * can drag icons from the palette onto the
   * main workspace (the arena).
   * @param source The entity that created this event.
   */
    public DisplayPaletteEvent(Object source) {
        super(source);
    }

}