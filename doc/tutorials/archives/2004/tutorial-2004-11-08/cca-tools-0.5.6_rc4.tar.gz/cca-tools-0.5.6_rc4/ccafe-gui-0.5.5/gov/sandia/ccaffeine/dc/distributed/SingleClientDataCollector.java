package gov.sandia.ccaffeine.dc.distributed;

import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;

class SingleClientDataCollector implements ClientOutputCollector
{
    private ClientOutputRelay cRelay;
    public SingleClientDataCollector ()
    {
    }
    public SingleClientDataCollector (ClientOutputRelay cR)
    {
	this.cRelay = cR;
    }
    public void setClientOutputRelay( ClientOutputRelay cR) 
    {
	this.cRelay = cR;
    }
    public void controllerClientOutput(ClientOutputEvent evt)
    {
	String s = evt.getString();
	cRelay.relayMessageFromController(s);
    }
    public void computeClientOutput(ClientOutputEvent evt)
    {
	if ( cRelay == null ) {
	    // BUGBUG - log an exception
	    return;
	}
	// Only pay attention to client[0] at this point.  Should compare
	// output with the other clients and make sure it is the same.
	Client src = (Client) evt.getSource();
	String s = evt.getString();
	//If we are the first client pass on the output, ignore the others.
	if(src.getId() == 0) {
	    cRelay.relayMessageFromDataProducers(s);
	} else {
	    return;
	}
    }
    public void processOutOfBand(OutOfBandEvent evt)
    {
    }
}

