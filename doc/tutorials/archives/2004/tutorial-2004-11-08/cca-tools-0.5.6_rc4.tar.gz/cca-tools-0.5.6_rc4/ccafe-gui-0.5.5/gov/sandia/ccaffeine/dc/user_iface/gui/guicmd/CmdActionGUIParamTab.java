package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;

/**
 * CmdActionGUIParamTab.java
 *
 *
 * Created: Mon Dec 13 16:50:07 1999
 *
 * @author  Colin Potter
 * @version 1.0.0b1
 */

public class CmdActionGUIParamTab
       extends CmdActionGUI
       implements CmdAction {

    public CmdActionGUIParamTab() {
    }


    public String argtype(){
	return "ISa";
    }

    public String[] names(){
	return namelist;
    }

    public String help(){
	return "creates a new tab in a pre-existing ConfigureDialog to be filled with forthcoming data.";
    }

    private static final String[] namelist = {"newParamTab"};
    public void doIt(CmdContext cc, Vector args) {

	CmdContextGUI ccg = (CmdContextGUI)cc;


       /*
        * The name of the cca component that contains
        * the port which contains the data field.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = (String)args.get(0);

       /*
        * The name of the port that contains the data field.
        * Example: "configure_port"
        */
        String portInstanceName = (String)args.get(1);


        /*
         * Get the name of the tab.
         */
        String dataFieldTabName = (String)args.get(2);

	//String hashKey = componentInstance + ":" + portInstance;

	//ConfigureDialog dialog = global.getConfigureDialog(hashKey);
	//dialog.newTab(tabTitle);

        this.broadcastParamTabChoice
            (componentInstanceName,
             portInstanceName,
             dataFieldTabName);



    } // doIt

} // CmdActionGUIParamTab
