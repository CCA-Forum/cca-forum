package gov.sandia.ccaffeine.dc.user_iface.MVC;



/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * When the server wants a VIEW to display a
 * dialog box, the server will 1) send a "newParamDialog",
 * 2) the contents of the dialog box, and
 * 3) a "endParamDialog"
 */
public class CcaPortParameterDialogBox {
    public String componentInstanceName = null;
    public String portInstanceName = null;
    public String titleOfDialogBox = null;

    
    /**
     * Parse the xml contents of a port parameter dialog box..
     * The parsed values are copied into the class's attributes.
     * <p>
     * The XML code will contains something like this: <br>
     * &lt;newParamDialog&gt; <br>
     * &nbsp;&lt;componentInstanceName&gt;<br>
     * &nbsp;&nbsp;&nbsp;name1 <br>
     * &nbsp;&nbsp;&nbsp;&lt;/componentInstanceName&gt; <br>
     * &nbsp;&lt;portInstanceName&gt;name2&lt;/portInstanceName&gt; <br>
     * &nbsp;&lt;title&gt;title1&lt;/title&gt; <br> 
     * &lt;newParamDialog&gt; <br>
     * @param xmlComponent The xml code of one component.
     */
    public CcaPortParameterDialogBox(String xml) {

        /*
         * Extract out the contents of the following tags:
         *    component name
         *    port name
         *    titleOfDialogBox
         */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<componentInstanceName>(.*?)</componentInstanceName>\\s*"
           +"<portInstanceName>(.*?)</portInstanceName>\\s*"
           +"<title>(.*?)</title>");

        java.util.regex.Matcher matcher = pattern.matcher(xml);


        /* copy the contents of the 3 tags to our attributes */
        if (matcher.find()) {
            this.componentInstanceName = matcher.group(1);
            this.portInstanceName = matcher.group(2);
            this.titleOfDialogBox = matcher.group(3);
        }
    }


}