package gov.sandia.ccaffeine.dc.distributed;

class OutOfBandEvent extends java.util.EventObject {
  private String cmd;
  public OutOfBandEvent(Object src, String cmd) {
    super(src);
    this.cmd = cmd;
  }
  public String getOutOfBandCommand() {
    return cmd;
  }
}
