package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUI;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.AddProvidesPortsEvent;

/**
 * CmdActionGUIAddProvidesPorts.java
 *
 * When the client drags a cca component from the
 * palette to the arena, the cca server instantiates
 * a new cca component, creates the Provides Ports for
 * the cca component, and creates the Uses Ports for the
 * cca component.  The cca server sends the Provides Ports
 * to the client.  The client renders the Provides ports
 * are small boxes on the left side of the component.
 */

public class CmdActionGUIAddProvidesPorts
       extends CmdActionGUI
       implements CmdAction {

    public CmdActionGUIAddProvidesPorts() {
    }


    public String argtype(){
	return "Is*";
    }

    public String[] names(){
	return namelist;
    }

    public String help(){
	return "adds provides ports to an existing ComponentInstance.";
    }

    private static final String[] namelist = {"addProvidesports", "addProvidesPorts"};
    public void doIt(CmdContext cc, Vector args) {

	CmdContextGUI ccg = (CmdContextGUI)cc;


       /*
        * Get the name of the component that is receiving the new ports.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
	String componentInstanceName = (String)args.get(0);


       /*
        * Get the class name and the instance name of all the ports that
        * were added to a component.
        *
        * vector[0] contains the instance name of port[0]
        * vector[1] contains the class name of port[0]
        * vector[2] contains the instance name of port[1]
        * vector[3] contains the class name of port[1]
        * etc.
        *
        * The class name of a port is the name of the
        * port's java class.  The class name may or may not
        * include the package name.  Examples of class names are
        * "gov.cca.componentProperties" and "GoPort."
        *
        * The instance name of a port is the name of
        * an instantiation of the cca port.  The name
        * is usually the name of the port's class
        * (without the package name).
        * Examples of instance names are
        * "cProps" and "go_port."
        */
	java.util.Vector classNameAndInstanceNameOfAllPorts = new java.util.Vector();
	for(int i = 1; i < args.size(); i++){
	    classNameAndInstanceNameOfAllPorts.add(args.get(i));
	}

	//Arena arena = global.getArena();
	//ComponentInstance instance =
	//    global.getArena().getComponentInstance(instanceName);
	//instance.addProvidesPorts(ports);
        this.broadcastAddProvidesPorts
            (componentInstanceName,
             classNameAndInstanceNameOfAllPorts);





    } // doIt

} // CmdActionGUIDialog

