package gov.sandia.ccaffeine.dc.distributed;

import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;

class LineMessageDataCollector implements ClientOutputCollector
{
    public static final String TIME_DELAY_MSG = "TIME_DELAY=";
    private LineTable messages;
    private Thread tTable;
    private ClientOutputRelay cRelay;
    public LineMessageDataCollector ()
    {
	LocalSystem.err.println("Started line message data collector...");
    }
    public LineMessageDataCollector (ClientOutputRelay cRelay)
    {
	LocalSystem.out.println("Started line message data collector...");
	this.cRelay = cRelay;
	messages = new LineTable(cRelay);
    }

    public void setClientOutputRelay( ClientOutputRelay cR) 
    {
	this.cRelay = cR;
	messages = new LineTable(cRelay);
    }

    public void controllerClientOutput(ClientOutputEvent evt)
    {
	String s = evt.getString();
	cRelay.relayMessageFromController(s);
    }
    /******************************************************************
     Notes: method is always called from ServerMux.clientOutput which
     is synchronized. It should, therefore, already be thread safe, but 
     just in case...
     
     The events coming in here should be from the "muxee" clients - ie,
     we should get a whole series of messages which need to be 
     combined into one and sent to the muxor.

     This particular data collector has the following interesting qualities:
     1) each message is held for at least a set time delay - if any other 
     message which match the message text exactly come along during this
     delay, they are combined and sent on as one message.

     message format:

     combination of messages:

     setting the time delay:
     *****************************************************************/
    public void computeClientOutput(ClientOutputEvent evt)
    {
	Client src = (Client) evt.getSource();
	String s = evt.getString();
	messages.addClientOutput( src, s );
    }


    public void processOutOfBand(OutOfBandEvent evt)
    {
    }

}


class LineTable {
    
    private LinkedList waitingLines; 
    private ClientOutputRelay cRelay;

    public LineTable (ClientOutputRelay cRelay)
    {
	this.cRelay = cRelay;
	waitingLines = new LinkedList();
    }

    public synchronized void addClientOutput(Client client, String s)
    {
	if (cRelay == null) {
	    // BUGBUG - log an exception (but there is no relay to send 
	    // it to!)
	    return;
	}

	// all messages should start with identifying information, in
	// one of the following formats: 
	//       <<idlist>>, !<<idlist>> or #<<idlist>>
	addMessage(s, client);
	

	// print out a list of all unique messages, with the ids of the 
	// computers which generated them
	checkSendMessages();
    }

    public synchronized void checkSendMessages() {
	// format the message
	String dataString = "";
	ListIterator respIter = waitingLines.listIterator();
	while (respIter.hasNext()) {
	    
	    LineData lineData = (LineData) respIter.next();
	    LocalSystem.out.println("DONE? " + lineData.getFormattedMessageString() + " with " + lineData.getNumClients());
	    if(lineData.getNumClients() == cRelay.getNumClients()) {
		dataString = lineData.getFormattedMessageString();
		cRelay.relayMessageFromDataProducers(dataString);
		respIter.remove();
		dataString = "";
	    }

	}
    }

    public synchronized void addMessage(String message, Client client)
    {
	// look for the first message (line) in the list of messages (lines)
	// that doesn't have a response from this client. If we find one,
	// add this client to it.
	boolean foundData = false;
	ListIterator respIter = waitingLines.listIterator();
	while (respIter.hasNext()) {
	    
	    LineData lineData = (LineData) respIter.next();
	    LocalSystem.out.println("CHECKING for client " + client.getId() + " : " + lineData.getFormattedMessageString());
	    if (!lineData.hasClient(client)) {
		lineData.addMessage(message, client);
		foundData = true;
		break;
	    }
	}
	// create a new line/message if needed
	if (!foundData) {
	    LineData lineData = new LineData(message, client);
	    LocalSystem.out.println("ADDING: " + lineData.getFormattedMessageString());
	    waitingLines.addLast(lineData);
	}
	
    }
    
}


class LineData {
    private LinkedList messageTable = new LinkedList();

    public LineData(String message, Client client)
    {
	MessageData msgData = new MessageData(message, client);
	messageTable.add(msgData);
    };

    // adds the clients from each message recieved for this line.
    public int getNumClients() 
    {
	int count = 0;
	Iterator respIter = messageTable.iterator();
	while (respIter.hasNext()) {
	    
	    MessageData msgData = (MessageData) respIter.next();
	    count += msgData.numClients();
	}
	return count;
    }; 
    public boolean hasClient(Client client)
    {
	Iterator respIter = messageTable.iterator();
	while (respIter.hasNext()) {
	    
	    MessageData msgData = (MessageData) respIter.next();
	    if (msgData.hasClientData(client))
		return true;
	}
	return false;
    };
    public void addMessage (String message, Client client)
    {
	MessageData msgData = new MessageData(message, client);
	if (messageTable.contains(msgData)) {
	    MessageData oldMsgData = (MessageData) messageTable.get(messageTable.indexOf(msgData));
	    oldMsgData.appendIds(msgData.getIdList(), client);
	} else {
	    messageTable.add(msgData);
	}
    };
    public String getFormattedMessageString()
    {
	String message = "";
	Iterator respIter = messageTable.iterator();
	boolean firstIteration = true;
	while (respIter.hasNext()) {
	    if (!firstIteration) {
		message += "\n";
		firstIteration = false;
	    }
	    MessageData msgData = (MessageData) respIter.next();
	    message += msgData.getFormattedMessageString();
	}
	return message;
    }
}














