package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

/**
 * Used to notify listeners that the debug flag is set.
 */

public class SetDebugFlagEvent extends java.util.EventObject {

    boolean debug = false;


    /**
     * Get the value of the debug flag.
     * @return The value of the debug flag.
     */
    public boolean getDebug() {
        return(this.debug);
    }


    /**
     * Set the value of the debug flag.
     * @param debug The value of the debug flag.
     */
    public void getDebug(boolean debug) {
        this.debug = debug;
    }


    /**
     * Construct a SetDebugFlagEvent.
     * @param source the entity that originated this event.
     */
    public SetDebugFlagEvent(Object source) {
        super(source);
        this.debug = false;
    }

    /**
     * Construct a SetDebugFlagEvent.
     * @param source the entity that originated this event.
     * @param debug The value of the debug flag.
     */
    public SetDebugFlagEvent(Object source, boolean debug) {
        super(source);
        this.debug = debug;
    }


}