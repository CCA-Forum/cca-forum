package gov.sandia.ccaffeine.dc.user_iface.MVC;

import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GoEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.InstantiateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ConnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisconnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamCurrentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GetInstancesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamGetCurrentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetDebugEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayPaletteEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayChainEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayStateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GoComponentPortEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.NukeAllEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GetComponentPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetComponentPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.StringEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.HeartbeatEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ExitEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PathEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PortPropertiesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ComponentPropertiesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RepositoryEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ShellEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.PythonStub;

/**
 * An MVC view.
 * This view is used to send querries, commands and data
 * to a client stub.  The client stub transports
 * the information to a server skeleton.
 * The server skeleton delivers the information
 * the cca server.
 *
 */

/*
 * Programmer's Notes:
 * scenario:  GUI wants to populate the palette
 *    GUI formulates a query that asks for all the components in the palette
 *    GUI sends a query to the ViewPython
 *        NOTE: The ViewPython is a GUI Listener
 *    ViewPython sends a query to the PythonStub
 *    The PythonStub forwards the query to the server skeleton
 *    The server skeleton forwards the query to the cca server
 *    The cca server sends the components to the server skeleton
 *    The server skeleton sends the components to the PythonStub
 *    The PythonStub sends the components to the ControllerPython
 *    The ControllerPython sends the events to the GUI
 *        NOTE:  The GUI is a ControllerListener
 */

public class ViewPython
    implements GuiListener {

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/


  PythonStub pythonStub = null;






  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * Create an MVC View.
   * This view writes commands and data to the cca server.
   * @param pythonStub The stub for a python client
   */
  public ViewPython(PythonStub pythonStub) {

    this.pythonStub = pythonStub;



    try {

		//pythonStub.openSessionWithCcaServer(clientSocket);

		pythonStub.openFramework();

		pythonStub.setPathToCcaComponents(".");

		pythonStub.loadComponentClass("StarterComponent");

		pythonStub.loadComponentClass("PrinterComponent");

		pythonStub.loadComponentClass("TimeStamper");

		pythonStub.loadComponentClass("Timer");

	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotOpenCcaFrameworkException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotSetPathToCcaComponentsException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotLoadComponentException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}


  }



  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI is asking the cca server to retrieve a cca component.
   * @param event The event that is generated whenever
   * the GUI wants to retrieve a cca component.
   */
  public void instantiate(InstantiateEvent event) {

    /*
     * The name of the component's class.
     * The name is actually the name of the component's
     * java class.
     * EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
     */

  	String className = event.getClassName();

    /*
     * The name of the
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     */
    String instanceName = event.getInstanceName();

    try {

		this.pythonStub.instantiateComponent(className, instanceName);

	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotInstantiateComponentException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}


  }


  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI is asking the cca server to connect the
   * Provides Port of a cca component to a Uses Port.
   * The Uses Port may be one the
   * same component or may be on a different component.
   * @param event The event that is sent whenever
   * the GUI wants to connect a Uses Port with a
   * Provides Port.
   */
  public void connect(ConnectEvent event) {

    /*
     * This is the name of the component that houses the
     * source port.  The source port is one of the two
     * connected ports.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    String sourceComponentName = event.getSourceComponentName();

    /**
     * This is the name of the source port.
     * The source port is connected to the target port.
     * Example:  "out0"
     */
    String sourcePortName = event.getSourcePortName();

    /*
     * The name of the component that houses the target port.
     * The target port is one of the two connected ports.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "PrinterComponent0"
     */
    String targetComponentName = event.getTargetComponentName();

    /*
     * This is the name of the target port.
     * The target port is connected to the source port.
     * Example:  "printer_port"
     */
    String targetPortName = event.getTargetPortName();

    try {

		this.pythonStub.connectTwoPorts
		    (sourceComponentName,
		     sourcePortName,
			 targetComponentName,
			 targetPortName);

	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotConnectTwoPortsException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

  }


  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI is requesting that the cca server
   * execute the "go" command"
   * on a specific port that is located
   * on a specific component.
   * @param event The event that is generated whenever
   * the GUI wants to invoke the "go" command.
   */
  public void goComponentPort(GoComponentPortEvent event) {

    /*
     * The name of the
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     */
    String componentInstanceName = event.getComponentInstanceName();

    /**
     * The name of the GO port.
     */
    String portInstanceName = event.getPortInstanceName();

    try {

		this.pythonStub.launchGoOnOneComponent
		    (componentInstanceName,
		     portInstanceName);

	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotLaunchGoCommandOnOneComponentException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

  }




  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI wants the cca server to launch an application.
   * @param event The event that is generated whenever
   * the GUI wants to launch the application.
   */
  public void go(GoEvent event) {

    /*
     * Number of arguments in the go command
     */
    int numberOfArguments = event.getNumberOfArguments();

    /*
     * To call "go" on a specific
     * component, pass in the
     * name of the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     */
    String componentInstanceName = event.getComponentInstanceName();

    /*
     * To call "go" on a specific
     * "go" port on a specific component,
     * pass in the
     * name of the "go" port.
     */
    String portInstanceName = event.getPortInstanceName();


    try {

		if (numberOfArguments == 0) {
		    this.pythonStub.launchGoOnAllComponents();
		}
		else if (numberOfArguments == 1) {
			this.pythonStub.launchGoOnOneComponent(componentInstanceName);
		}
		else if (numberOfArguments == 2) {
			this.pythonStub.launchGoOnOneComponent
			    (componentInstanceName,
			     portInstanceName);
		}

	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotLaunchGoCommandOnAllComponentsException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotLaunchGoCommandOnOneComponentException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

  }








  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI wants the cca server to remove an instantiation of a
   * cca component.
   * @param event The event that is generated whenever
   * the GUI wants to remove an instantiation of a cca
   * component.
   */
  public void remove(RemoveEvent event) {

    /*
     * The name of the component that was removed.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    String componentInstanceName = event.getComponentInstanceName();

    try {
		this.pythonStub.removeInstantiatedComponent(componentInstanceName);
	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotRemoveInstantiatedComponentException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

  }






  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI is asking the cca server to
   * disconnect the connection between a Provides Port
   * of a cca component
   * and a Uses Port.
   * @param event The event that is sent whenever
   * the GUI wants to connect a Uses Port with a
   * Provides Port.
   */
  public void disconnect(DisconnectEvent event) {

    /*
     * This is the name of the component that houses the
     * source port.  The source port is one of the two
     * connected ports.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    String sourceComponentName = event.getSourceComponentName();

    /**
     * This is the name of the source port.
     * The source port is connected to the target port.
     * Example:  "out0"
     */
    String sourcePortName = event.getSourcePortName();

    /*
     * The name of the component that houses the target port.
     * The target port is one of the two connected ports.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "PrinterComponent0"
     */
    String targetComponentName = event.getTargetComponentName();

    /*
     * This is the name of the target port.
     * The target port is connected to the source port.
     * Example:  "printer_port"
     */
    String targetPortName = event.getTargetPortName();

    try {
		this.pythonStub.disconnectTwoPorts
		    (sourceComponentName,
		     sourcePortName,
			 targetComponentName,
			 targetPortName);
	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotDisconnectTwoPortsException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI is asking the cca server to send back
   * all of the instantiated cca components.
   * @param event That event that is generated
   * whenever the GUI wants to get all of the
   * instantiated cca components.
   */
  public void getAllInstancesInArena(GetInstancesEvent event) {

  	  try {

		this.pythonStub.getComponentInstances();

	} catch (CanNotCommunicateWithCcaServerException e) {
		e.printStackTrace();
	}

  }



  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI is requesting the cca server to send
   * back all of the components that are in the palette.
   * A palette is a menu of
   * cca components; the end-user can drag components
   * from the palette to the arena (workspace).
   * <p>
   * The cca server will send back all of the components
   * that are in the palette.  A GUI might respond
   * by rending an icon, in the palette, for each component.
   * @param event The event that is generated whenever
   * the GUI wants to know what components
   * are in the palette.
   */
  public void displayPalette(DisplayPaletteEvent event) {

  	  try {

		this.pythonStub.getComponentClassNames();

	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }



  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI is requesting the cca server to send
   * back all connections.  A connection connects
   * a user port of a component to a provider port;
   * the two ports may be on the same cca component
   * or may be on different components.
   * @param event The event that is created
   * whenever the GUI wants to know what connections
   * are in the arena.
   */
  public void links(DisplayChainEvent event) {

  	  try {

		this.pythonStub.getConnections();

	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }


  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/


  /**
   * The GUI is asking the cca server to send back
   * the value of one of the parameters of a port that
   * is on a cca component.
   * @param event The event that is generated whenever
   * the GUI wants the value of one of the data fields.
   */
  public void getPortParameter(ParamGetCurrentEvent event) {

    /*
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     */
    String componentInstanceName =
        event.getComponentInstanceName();

    /**
     * The name of the port that contains the data field.
     *  Example: "configure_port"
     */
    String portInstanceName = event.GetPortInstanceName();

    /**
     * The name of a data field.
     */
    String dataFieldName = event.getDataFieldName();

    if (dataFieldName.equalsIgnoreCase("All")){
    	try {
			this.pythonStub.getPortParameters
			    (componentInstanceName,
			     portInstanceName);
		} catch (CanNotCommunicateWithCcaServerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CanNotGetPortParametersException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }


  }


  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/


  /**
   * The GUI is asking the cca server to set one of the
   * parameters of a port that is on a cca component.
   * @param event The event that is generated
   * whenever the GUI wants to set the value of
   * a data field.
   */
  public void setPortParameter(ParamCurrentEvent event) {

    /*
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     */
    String componentInstanceName = event.getComponentInstanceName();

    /**
     * The name of the port that contains the data field.
     *  Example: "configure_port"
     */
    String portInstanceName = event.getPortInstanceName();

    /**
     * The name of a data field.
     */
    String dataFieldName = event.getDataFieldName();

    /*
     * The cca server is sending this value
     * of a data field to this client.
     */
    String dataFieldValue = event.getDataFieldValue();


    try {
		this.pythonStub.setPortParameter
		  (componentInstanceName,
		   	     portInstanceName,
		   		 dataFieldName,
		   		 dataFieldValue);
	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotSetPortParameterException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }





  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI is requesting the cca server to send back
   * or to set the value of a component property.
   * An example of a component property is the "name"
   * of the component.
   * @param event The event that is generated
   * whenever the GUI wants to either get or
   * set the value of a component property.
   */
  public void componentProperties(ComponentPropertiesEvent event) {

    /*
     * The number of arguments in the "property"
     * command.
     */
    int numberOfArguments = event.getNumberOfArguments();

    /**
     * The name of the component that contains the property
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    String componentInstanceName = event.getComponentInstanceName();

    /*
     * If we are getting or setting the value
     * of a specific property then we need the
     * name of the property.
     */
    String propertyName = event.getPropertyName();

    /*
     * If we are setting the value of a
     * property then we need the new value.
     */
    String propertyValue = event.getPropertyValue();

    try {
		if (numberOfArguments>=3)
			this.pythonStub.setComponentProperty
			    (componentInstanceName,
			     propertyName,
				 propertyValue);
		else if (numberOfArguments==2)
			this.pythonStub.getComponentProperty
			    (componentInstanceName,
			     propertyName);
		else if (numberOfArguments==1)
			this.pythonStub.getComponentProperties
			    (componentInstanceName);
	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotSetComponentPropertyException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotGetComponentPropertyException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}


  }




  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI is requesting the cca server to send back
   * the value of a property that is inside a cca component.
   * @param event The event that is generated
   * whenever the GUI wants the value of a
   * property that is inside a component.
   */
  public void getComponentProperty(GetComponentPropertyEvent event) {

    /**
     * The name of the component that contains the property
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    String componentInstanceName = event.getComponentInstanceName();

    /*
     * The name of the property.
     */
    String propertyName = event.getPropertyName();


    try {
		if (propertyName!=null)
		    this.pythonStub.getComponentProperty
		        (componentInstanceName,
		         propertyName);
		else
			this.pythonStub.getComponentProperties
			    (componentInstanceName);
	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotGetComponentPropertyException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

  }




  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/


  /**
   * The GUI is requesting the cca server to
   * delete all components.
   * <p>
   * The server will respond by deleting all components.
   * The GUI might respond by removing all components
   * from the workspace.
   * param event The event that is created
   * whenever the GUI wants to to delete
   * all components.
   */
  public void nukeAll(NukeAllEvent event) {

    /*
     * The number of arguments in the nuke command
     */
    int numberOfArguments = event.getNumberOfArguments();

    /**
     * The entity that is to be removed.
     * NOTE:  As of Oct 2003, "all" is the
     * only entity that can be nuked.
     */
    String entity = event.getEntity();

    try {
		this.pythonStub.removeInstantiatedComponents();
	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotRemoveInstantiatedComponentException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

  }



  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/


  /**
   * The GUI is asking the cca server to turn on debugging.
   * @event The event that is generated whenever
   * the GUI wants debugging turned on.
   */
  public void setDebug(SetDebugEvent event) {
    try {
		//write("debug");
		this.pythonStub.setDebugFlag(true);
	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotSetDebugFlagException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/


  /**
   * The GUI is asking the cca server to turn off debugging
   * @event The event that is generated whenever
   * the GUI wants the debugging turned off.
   */
  public void setNoDebug(SetDebugEvent event) {
    try {
		//write("nodebug");
		this.pythonStub.setDebugFlag(false);
	} catch (CanNotCommunicateWithCcaServerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CanNotSetDebugFlagException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }


  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/






  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI is asking the cca server to get or set
   * one of the parameters of a port that is on a
   * cca port.
   * @param event The event that is generated whenever
   * the GUI wants to get or set the value of one
   * of the data fields.
   */
  public void portParameter(ParamEvent event) {

    /*
     * The number of arguments.
     *
     * If we are tying to get the value of a
     * parameter then we need 3 arguments
     * (instanceName, portName, parameterName).
     * If we are trying to set the value of a
     * parameter then we need 4 arguments
     */
    int numberOfArguments = event.getNumberOfArguments();

    /*
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     */
    String componentInstanceName =
        event.getComponentInstanceName();

    /**
     * The name of the port that contains the data field.
     *  Example: "configure_port"
     */
    String portInstanceName = event.getPortInstanceName();

    /**
     * The name of a data field.
     */
    String dataFieldName = event.getDataFieldName();

    /**
     * The vzlue of a data field.
     */
    String dataFieldValue = event.getDataFieldValue();

    /*
     * Create the command that we want to send
     * to the cca server.
     */
    //StringBuffer command = new StringBuffer("parameters");
    //if (componentInstanceName!=null) {
    //  command.append(" " + componentInstanceName);
    //  if (portInstanceName!=null) {
    //     command.append(" " + portInstanceName);
    //     if (dataFieldName!=null) {
    //         command.append(" " + dataFieldName);
    //         if (dataFieldValue!=null) {
    //             command.append(" " + dataFieldValue);
    //         }
    //     }
    //}
    //}

    /* send the command to the cca server */
    //write(command.toString());
  }



  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/


  /**
   * Request some information from the server.
   * We can
   * request the following info: <br>
   * &nbsp;&nbsp;&nbsp;&nbsp;display palette <br>
   * &nbsp;&nbsp;&nbsp;&nbsp;display arena <br>
   * &nbsp;&nbsp;&nbsp;&nbsp;display chain <br>
   * &nbsp;&nbsp;&nbsp;&nbsp;display component <br>
   * &nbsp;&nbsp;&nbsp;&nbsp;display state <br>
   * <p>
   * If the GUI wants to get information on the components
   * that are in the palette, or on the components that are
   * in the arena, or on the connections that are established
   * inside the arena, or on a particular component, or on
   * the components and the connections that are in the arena,
   * then the GUI will encapsulate the request as a DisplayEvent
   * and will then invoke this method.  This method will send
   * the request to the cca server.
   * @param DisplayEvent The event that is
   * generated whenever an entity is requesting
   * some information from the server.
   */
  public void display(DisplayEvent event) {

    /*
     * The number of arguments
     * in the request string.
     */
    int numberOfArguments = event.getNumberOfArguments();

    /*
     * We are requesting info
     * on which entity?  We can
     * request info on the PALETTE,
     * ARENA, CHAIN, COMPONENT,
     * STATE.
     */
    String entity = event.getEntity();

    /*
     * If an entity wants some info on
     * a particular component, then that
     * entity has to supply the name of
     * the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     */
    String componentInstanceName = event.getComponentInstanceName();

    //String command =
    //    "display "
    //    + entity;
    //if (componentInstanceName!=null)
    //    command = command + " " + componentInstanceName;
    //write(command);
  }





  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI is requesting the cca server to
   * send back a cca component.
   * <p>
   * The cca server will respond by sending
   * back one cca component.  The GUI might
   * respond by rendering the component
   * in the workspace.
   * @param source The entity that created this event.
   * @param componentInstanceName
   * The name of the
   * cca component object.  The instance
   * name is usually the name of the component's
   * java class (without the package name)
   * concatenated with an index number.
   * EXAMPLE:  "StarterComponent0"
   * @param event The event that is created whenever
   * the GUI wants some information on a cca component.
   */
  public void displayComponent(DisplayComponentEvent event) {

    /*
     * The name of the
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     */
    String componentInstanceName = event.getComponentInstanceName();

    /* Create the command that we will send to the cca server */
    //String command = "display component " + componentInstanceName;

    /* Send the command to the cca server */
    //write(command);

  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI is requesting the cca server to
   * send back all components that are in the
   * arena and to send back all connections.  A connection
   * connects a user port of a component with a provider
   * port; the two ports may be on the same cca component
   * or may be on different components.
   * <p>
   * The cca server will respond by sending back all of
   * the components that are in the workspace and all of the
   * connections.  A GUI might respond by rendering an icon,
   * in the work area, for each component and by drawing lines
   * between the components to connect them.
   * @param event The event that is created whenever
   * we want to know the state of the arena.
   */
  public void displayState(DisplayStateEvent event) {

    //write("display state");

  }



  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/


  /**
   * The GUI is requesting the cca server to send back or to set
   * the value of a port
   * property.
   * @param event The event that is generated
   * whenever an entity wants to either get or
   * set the value of a port property.
   */
  public void portProperties(PortPropertiesEvent event) {

    /*
     * The number of arguments in the "port-property"
     * command.
     */
    int numberOfArguments = event.getNumberOfArguments();

    /**
     * The name of the component that contains the property
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    String componentInstanceName = event.getComponentInstanceName();

    /*
     * The name of the port that contains the property
     */
    String portName = event.getPortName();

    /*
     * If we are getting or setting the value
     * of a specific property then we need the
     * name of the property.
     */
    String propertyName = event.getPropertyName();

    /**
     * If we are setting the value of a
     * property then we need the datatype
     * of the value.
     */
    String dataTypeOfPropertyValue = event.getDataTypeOfPropertyValue();

    /*
     * If we are setting the value of a
     * property then we need the new value.
     */
    String propertyValue = event.getPropertyValue();

    /* create the command */
    //StringBuffer command = new StringBuffer("port-property");
    //if (numberOfArguments>0) {
    //    command.append(" ");
    //   command.append(componentInstanceName);
    //}
    //if (numberOfArguments>1) {
    //   command.append(" ");
    //    command.append(propertyName);
    //}
    //if (numberOfArguments>2) {
    //    command.append(" ");
    //    command.append(dataTypeOfPropertyValue);
    //}
    //if (numberOfArguments>3) {
    //    command.append(" ");
    //   command.append(propertyValue);
    //}

    /* send the command to the server */
    //this.write(command.toString());

  }



  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/



  /**
   * The GUI wants the server to set the value of
   * a property that is inside of a cca component.
   * @param event The event that is created whenever
   * the GUI wants to set the value of a property.
   */
  public void setComponentProperty(SetComponentPropertyEvent event) {

    /**
     * The name of the component that contains the property
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    String componentInstanceName = event.getComponentInstanceName();

    /*
     * The name of the property.
     */
    String propertyName = event.getPropertyName();

    /**
     * The value of the property.
     */
    String propertyValue = event.getPropertyValue();

    /* Create the command that we will send to the cca server */
    //String command = "property "
    //               + componentInstanceName + " "
    //               + propertyName + " "
    //               + propertyValue;

    /* send the command to the cca server */
    //write(command);

  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI wants to send a message to the cca server.
   * @param event The event that is created
   * the GUI wants to send
   * a string to the cca server.
   */
  public void sendMessage(StringEvent event) {

    /*
     * The string that we want to send to the cca server
     */
    //String message = event.getMessage();

    /* send the message */
    //write(message);

  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI wants to send a heartbeat to the cca server.
   * @param event The event that is fabricated
   * the GUI wants to emit a heartbeat.
   */
  public void heartbeat(HeartbeatEvent event) {
    //write("heartbeat");
  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI wants to tell the cca server that the GUI
   * is shutting down.
   * @param event The event that is generated whenever
   * the GUI wants to exit the application.
   */
  public void exit(ExitEvent event) {
    //write("exit");
  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI wants to tell the cca server to
   * send back or to set the file path
   * that contains cca components.
   * @param event The event that is
   * generated whenever the GUI
   * wants either to set the path
   * to a new value or to query
   * for the path value.
   */
  public void path(PathEvent event) {

    /*
     * The number of arguments
     * in the path command.
     */
    int numberOfArguments = event.getNumberOfArguments();

    /*
     * To alter the path,
     * specify how
     * the path is to be changed
     * by issuing
     * any of the following commands:
     * INIT, APPEND, PREPEND, SET
     */
    String commandToAlterPath = event.getCommandToAlterPath();

    /**
     * To alter the path,
     * specify the new
     * path value.
     */
    String directory = event.getDirectory();

    /* create the command that we will send to the cca server */
    //StringBuffer command =  new StringBuffer("path");
    //if (numberOfArguments>0) {
    //    command.append(" ");
    //    command.append(commandToAlterPath);
    //}
    //if (numberOfArguments>1) {
    //    command.append(" ");
    //   command.append(directory);
    //}

    //write(command.toString());
  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI wants the cca server to send back all
   * components that are in the repository or to send
   * back one specific compnonent that is in the repository.
   * @param event The event that is created whenever
   * the GUI wants to get one component or all components
   * from the repository,
   */
  public void repository(RepositoryEvent event) {

    /*
     * The number of arguments in the "repository" command
     */
    int numberOfArguments = event.getNumberOfArguments();

    /*
     * The command.  The command can be one of the following
     * values:  LIST, GET, GET_GLOBAL, GET_LAZY, GET_LAZY_GLOBAL
     */
    String command = event.getCommand();

    /*
     * If we are retrieving the value of one class,
     * then we need the name of the class.
     */
    String className = event.getClassName();

    /* construct the command */
    //StringBuffer buffer = new StringBuffer("repository");
    //if (numberOfArguments>0) {
    //    buffer.append(" ");
    //   buffer.append(command);
    //}
    //if (numberOfArguments>1) {
    //    buffer.append(" ");
    //    buffer.append(className);
    //}

    /* send the command to the server */
    //write(buffer.toString());
  }

  /*-------------------------------------------------------------------*/
  /*-------------------------------------------------------------------*/

  /**
   * The GUI wants to send an O.S. command to the cca server.
   * The cca server will execute the command.
   * @param event The event that is
   * created whenever the GUI wants
   * an O.S. command executed.
   */
  public void shell(ShellEvent event) {

    /* the number of arguments in the "shell" command */
    int numberOfArguments = event.getNumberOfArguments();

    /* The command that is to be executed */
    String command = event.getCommand();

    /* create the command */
    //StringBuffer buffer = new StringBuffer("shell");
    //if (numberOfArguments>0){
    //    buffer.append(" ");
    //    buffer.append(command);
    //}

    /* send the command to the cca server */
    //write(buffer.toString());

  }





}
