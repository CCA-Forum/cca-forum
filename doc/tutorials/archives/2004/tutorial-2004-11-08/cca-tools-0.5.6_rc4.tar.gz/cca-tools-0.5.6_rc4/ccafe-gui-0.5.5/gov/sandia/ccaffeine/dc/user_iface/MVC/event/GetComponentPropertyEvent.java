package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Used to notify components that the cca server
 * wants the GUI to display the value of a component
 * property.  A view might respond
 * by writing the value to stdout.
 * <p>
 * This event can also be used to inform components
 * that an entity wants the value of a
 * property.  A view entity might
 * respond by sending a "property"
 * message to the cca server.
 */
public class GetComponentPropertyEvent extends EventObject {

  /**
   * The name of the component that contains the property
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "StartComponent0"
   */
    protected String componentInstanceName = null;



    /**
     * Get the name of the component that contains the property
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @return the name of the compoonent that
     * contains the property.
     */
    public String getComponentInstanceName() {
        return(this.componentInstanceName);
    }



    /*
     * The name of the property.
     */
    protected String propertyName = null;


    /**
     * Get the name of the property.
     * @return The name of the property.
     */
    public String getPropertyName() {
        return(this.propertyName);
    }


    /**
     * Create a GetPropertyEvent.
     * The event can be used to inform
     * the GUI to display the value of 
     * component property.
     * <p>
     * This event can also be used to inform components
     * that an entity wants the cca server to send 
     * the value of a
     * property.  A view entity might
     * respond by sending a "property"
     * message to the cca server.
     * @param source The entity that created this event.
     * @param componentInstanceName
     * The name of the component that contains the property
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param propertyName The name of the property.
     */
    public GetComponentPropertyEvent
           (Object source,
            String componentInstanceName,
            String propertyName) {

         super(source);
         this.componentInstanceName = componentInstanceName;
         this.propertyName = propertyName;
    }

}