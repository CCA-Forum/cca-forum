package gov.sandia.ccaffeine.dc.user_iface.MVC;

/**
 * We sent a query and/or a command to the cca server.
 * Wait for that cca server to respond.
 * The cca server will either send us the result set
 * or send us an exception.
 * <p>
 * We have two possible scenarios.  In the first scenario,
 * this thread is started BEFORE the cca server sends
 * back a result set in response to the query.  In the
 * second scenario, this thread is started AFTER the
 * cca server sends back a result set.
 * <p>
 * SCENARIO:  <br>
 * this thread is started <br>
 * this thread waits for the ResultSetEvent to arrive <br>
 * cca server processes query and sends ResultSetEvent <br>
 * This thread terminates <br>
 * <p>
 * SCENARIO:  <br>
 * cca server processes query and sends ResultSetEvent <br>
 * this thread is started <br>
 * this thread immediately terminates <br>
 */



public class ThreadWaitForResultSet extends Thread {


    /* mutex or semaphore */
    Object lock = new Object();


    /* the result set that the cca server sent */
    protected String resultSet = null;


    /**
     * Retrieve the result set that the cca server sent.
     * If an error occurs then return null.
     * @return The result set from the cca server.
     * If an error occurs then the result set is null.
     */
    public String getResultSet() {
        return(resultSet);
    }


    /* If something goes wrong then store an exception here */
    protected Exception exception = null;


    /**
     * Retrieve the exception.
     * A null value means that no errors occcurred.
     * @return The exception.  A null value is
     * returned if no errors occurred.
     */
    public Exception getException() {
      return(exception);
    }


    /**
     * Start the thread.
     */
    /*
    * How do we know
    * if the result set arrived BEFORE
    * or AFTER the run() method is invoked?
    * The run() method can check the state of the result set.
    * If the result set is null then run() was invoked
    * before the query arrived.  If the result set is not
    * null then run() was invoked after the query arrived.
    */
    public void start() {
        this.resultSet = null;
        this.exception = null;
        super.start();
    }

    /**
     *  Wait for a result set or an exception or a time out
     */
    /*
    * How do we know
    * if the result set arrived BEFORE
    * or AFTER the run() method is invoked?
    * The run() method can check the state of the result set.
    * If the result set is null then run() was invoked
    * before the query arrived.  If the result set is not
    * null then run() was invoked after the query arrived.
    */
    public void run() {
        synchronized(this.lock) {

            /* if the result set has already arrived,   */
            /* then terminate this thread immediately   */
            if (this.resultSet!=null) return;
            if (this.exception!=null) return;

            /* The result set has not yet arrived, */
            /* wait for it.                        */
            try {this.lock.wait(10000);}
            catch(java.lang.InterruptedException e){
                this.exception = e;
            }

            /* if we timed out then set exception  */
            if ((resultSet==null) && (exception==null)) {
                 this.exception = new java.lang.Exception
                     ("Error.  Could not retrieve value.\nTimed out.");
            }//if timeout

        }//synchronized
    }//run


    /**
     * The cca server is returning a result set.
     * @param returnValue The value that the cca server
     * is sending to us.
     */
    public void receivedResultSet(String resultSet){
        synchronized(this.lock) {
          if (!this.isAlive()) return;
          this.resultSet = resultSet;
          this.lock.notify();
        }
    }


    /**
     * An error occurred.  The cca server can not send
     * us a result set.
     * @param exception The exception that the cca server
     * is sending us.
     */
    public void receivedException(Exception exception){
        synchronized(this.lock) {
          if (!this.isAlive()) return;
          this.exception = exception;
          this.lock.notify();
        }
    }


  public ThreadWaitForResultSet() {
  }

}