package gov.sandia.ccaffeine.dc.distributed;

import java.net.*;
import gov.sandia.ccaffeine.util.*;
import gnu.getopt.*;
import java.util.*;
import java.io.*;


public class TestClientServer {
  public static String DEFAULTPROCFILEPATH = "processors";
  public static int DEFAULTPORT = 3141;
  public static int CLIENTPORT = 3142;
  private String procFile;
  private int myProcIndex = -1;
  private ProcessorInfo[] machines;
  private boolean isServer;

  public TestClientServer() {
    procFile = DEFAULTPROCFILEPATH;
  }

  /* Tests ClientServerSockets (no ServerMux involved yet) by
     sending 4 lines of text from each client to the server and
     vice versa. */

  public void doTest0(String myName, String fileName) throws Exception {
    procFile = DEFAULTPROCFILEPATH;
    if (fileName != null)
      procFile = fileName;
    File f = new File(procFile);
    Properties p = new Properties();
    if (f.canRead()) {
      InputStream in = new FileInputStream(f);
      p.load(in);
      in.close();
    }
    else {
      throw new RuntimeException("File: " + f.getAbsolutePath() +
                                 " cannot be read");
    }
    doSetup(p, myName);
    LocalSystem.err.println("My Machine:" + machines[myProcIndex]);
    dumpMachines();

    ClientServerSocket css = new ClientServerSocket(myProcIndex,
        DEFAULTPORT, machines);
    css.makeConnection();
    InputStream[] inpS = css.getIn();
    OutputStream[] outpS = css.getOut();
    if (css.isServer()) {
      BufferedReader[] in = new BufferedReader[inpS.length];
      PrintWriter[] out = new PrintWriter[inpS.length];
      for (int i = 0; i < inpS.length; i++) {
        in[i] = new BufferedReader(new InputStreamReader(inpS[i]));
        out[i] = new PrintWriter(outpS[i], true /* Line Buffered */);
      }
      for (int client = 0; client < in.length; client++) {
        for (int i = 0; i < 5; i++) {
          String line = in[client].readLine();
          LocalSystem.out.println("Output from client#" + client
                                  + ": " + line);
        }
        for (int i = 0; i < 5; i++) {
          out[client].println("Here is line #" + i);
        }
      }
      out[0].close();
      in[0].close();
    }
    else { // client
      BufferedReader in = new BufferedReader(new InputStreamReader(inpS[0]));
      PrintWriter out = new PrintWriter(outpS[0], true /* Line Buffered */);
      for (int i = 0; i < 5; i++) {
        out.println("Here is line #" + i);
      }
      for (int i = 0; i < 5; i++) {
        String line = in.readLine();
        LocalSystem.out.println("Output from server: " + line);
      }
      in.close();
      out.close();
    }
  }

  /* This test runs one server with clients. The server sents out 6 lines of
     output (counting the one that sets the plugin). The clients echo 6 lines
     of output back to the server, tagging the output with their id, and
     then remove themselves from the server. The server then waits for the
     user to type in exit, shuts down the server, and exits. */
  public void doTest1(String myName, String fileName, String pluginName) throws
      Exception {
    procFile = DEFAULTPROCFILEPATH;
    if (fileName != null)
      procFile = fileName;
    File f = new File(procFile);
    Properties p = new Properties();
    if (f.canRead()) {
      InputStream in = new FileInputStream(f);
      p.load(in);
      in.close();
    }
    else {
      throw new RuntimeException("File: " + f.getAbsolutePath() +
                                 " cannot be read");
    }
    doSetup(p, myName);
    LocalSystem.err.println("My Machine:" + machines[myProcIndex]);
    dumpMachines();

    SocketConnectionMgr css = new SocketConnectionMgr(myProcIndex,
        DEFAULTPORT, machines);
    css.connect(0);
    if (css.isServer()) {
      // this stream goes from the Muxer Client out to this method
      PipedOutputStream p1Out = new PipedOutputStream();
      PipedInputStream p1In = new PipedInputStream(p1Out);
      BufferedReader readStream = new BufferedReader(new InputStreamReader(p1In));
      // this stream goes in from this method to the Muxer client
      PipedOutputStream p2Out = new PipedOutputStream();
      PipedInputStream p2In = new PipedInputStream(p2Out);
      PrintWriter writeStream = new PrintWriter(p2Out, true);
      StaticIOConnection connect = new StaticIOConnection(p2In, p1Out, "test",
          -1);
      ServerMux sm = new ServerMux(css,
                                   connect, null);
      sm.doClientIO();
      if (pluginName != null) {
        writeStream.println(MessageData.makeOutOfBandMessage("controller",
            ServerMux.DATA_COLLECTOR_MSG + pluginName));
        // we don't know what plugin was added, but if it was a time
        // delay plugin, we do want to set the time delay. Other plugins
        // should ignore this message.
        writeStream.println(MessageData.makeOutOfBandMessage("controller",
            "TIME_DELAY=200"));
      }
      String line;
      int clients = 0;
      while (! (line =
                readStream.readLine()).
             equals(MessageData.makeOutOfBandMessage(ServerMux.SERVER_SRC,
          ServerMux.DATA_COLLECTOR_ACK)))
        ;
      for (int i = 0; i < 6; i++) {
        writeStream.println("Here is line #" + i);
      }
      while ( (line = readStream.readLine()) != null) {
        LocalSystem.out.println("Server got message: " + line);
        if (line.indexOf(ServerMux.REMOVE_CLIENT_MSG) > 0) {
          clients++;
          LocalSystem.out.println("Num Clients: " + clients);

        }
        if (clients == css.getConnections().size())
          break;
      }
      // We read from the LocalSystem only to be able to exit gracefully
      LocalSystem.out.println("Accepting input");
      BufferedReader in =
          new BufferedReader(new InputStreamReader(LocalSystem.in));

      while (! (line = in.readLine()).equals("exit")) {
      }
      LocalSystem.out.println("Normal Termination...");
      sm.shutdown();
      LocalSystem.out.println("Normal Termination");
    }
    else { // client
      Connection conn = (Connection) css.getConnections().elementAt(0);
      BufferedReader in = new BufferedReader(new InputStreamReader(conn.getIn()));
      PrintWriter out = new PrintWriter(conn.getOut(), true /* Line Buffered */);
      // Echo Server
      String line;
      for (int i = 0; i < 6; i++) {
        line = in.readLine();
        LocalSystem.out.println("Echoing to Server: " + line);
        out.println(MessageData.makeNormalMessage(myName, line));
      }
      out.println(MessageData.makeOutOfBandMessage(myName,
          ServerMux.REMOVE_CLIENT_MSG));
      LocalSystem.out.println("Normal Termination");
      while (true)
        ;
    }
  }

  public void doTest2(String myName, String fileName) throws Exception {
    procFile = DEFAULTPROCFILEPATH;
    if (fileName != null)
      procFile = fileName;
    File f = new File(procFile);
    Properties p = new Properties();
    if (f.canRead()) {
      InputStream in = new FileInputStream(f);
      p.load(in);
      in.close();
    }
    else {
      throw new RuntimeException("File: " + f.getAbsolutePath() +
                                 " cannot be read");
    }
    doSetup(p, myName);
    LocalSystem.err.println("My Machine:" + machines[myProcIndex]);
    dumpMachines();

    ClientServerSocket css = new ClientServerSocket(myProcIndex,
        DEFAULTPORT, machines);
    css.makeConnection();
    InputStream[] inpS = css.getIn();
    OutputStream[] outpS = css.getOut();
    InetAddress[] addrs = css.getProcessorAddresses();
    if (css.isServer()) {
      PipedOutputStream p2Out = new PipedOutputStream();
      PipedInputStream p2In = new PipedInputStream(p2Out);
      PrintWriter out = new PrintWriter(p2Out, true);
      ServerMux sm = new ServerMux(inpS, outpS,
                                   p2In, LocalSystem.out);
      // We read from the LocalSystem only to be able to exit gracefully
      BufferedReader in =
          new BufferedReader(new InputStreamReader(LocalSystem.in));
      sm.doClientIO();
      String line;
      LocalSystem.out.println("Type \"x\" on a line by itself to quit");
      while ( (line = in.readLine()) != null) {
        // "x" to quit:
        if (line.compareTo("x") == 0)
          break;
        out.println(line);
      }
      LocalSystem.out.println("Normal Termination ...");
      sm.shutdown();
      LocalSystem.out.println("Normal Termination Completed");
    }
    else { // client
      BufferedReader in = new BufferedReader(new InputStreamReader(inpS[0]));
      PrintWriter out = new PrintWriter(outpS[0], true /* Line Buffered */);
      // Echo Server
      String line;
      while ( (line = in.readLine()) != null) {
        LocalSystem.out.println("Echoing to Server: " + line);
        out.println(line);
      }
      LocalSystem.out.println("Normal Termination");
      out.close();
      in.close();
    }
  }

  /* this test should enable testing of two ServerMuxes, chained
     together. The first ServerMux in the chain should read from the
     DEFAULTPROCFILEPATH file, the second should read from a config
     file called "clients" and will also be client 0 in
     the DEFAULTPROCFILEPATH config file
     Once the test is started, it will send out commands to the clients,
     which exec them and send back their data through the
     MessageBasedDataCollector. The "first" server mux collects the
     results, formats them, and prints them out.*/

  public void doTest3(String myName, String fileName, String pluginName) throws
      Exception {
    LocalSystem.out.println("file name is: " + fileName);
    procFile = DEFAULTPROCFILEPATH;
    if (fileName != null)
      procFile = fileName;
    File f = new File(procFile);
    Properties p = new Properties();
    if (f.canRead()) {
      InputStream in = new FileInputStream(f);
      p.load(in);
      in.close();
    }
    else {
      throw new RuntimeException("File: " + f.getAbsolutePath() +
                                 " cannot be read");
    }
    doSetup(p, myName);
    LocalSystem.err.println("My Machine:" + machines[myProcIndex]);
    dumpMachines();

    SocketConnectionMgr css;
    if (procFile.startsWith("client")) {
      LocalSystem.out.println("Connecting to the secondary server mux at port " +
                              CLIENTPORT);
      css = new SocketConnectionMgr(myProcIndex,
                                    CLIENTPORT, machines);
    }
    else {
      LocalSystem.out.println("Connecting to the main server mux at port " +
                              DEFAULTPORT);
      css = new SocketConnectionMgr(myProcIndex,
                                    DEFAULTPORT, machines);
    }
    css.connect(0);
    if (css.isServer()) {
      if (procFile.startsWith("client")) { // we are the 2nd server in the chain
        // this is a server machine that is also
        // a client of the machine in the "processors" config file
        procFile = DEFAULTPROCFILEPATH;
        File fClient = new File(procFile);
        Properties pClient = new Properties();
        if (fClient.canRead()) {
          InputStream inClient = new FileInputStream(f);
          pClient.load(inClient);
          inClient.close();
        }
        else {
          throw new RuntimeException("File: " + fClient.getAbsolutePath() +
                                     " cannot be read");
        }
        doSetup(p, "0");
        LocalSystem.err.println("My Machine:" + machines[myProcIndex]);
        dumpMachines();

        SocketConnectionMgr cssClient = new SocketConnectionMgr(myProcIndex,
            DEFAULTPORT, machines);
        cssClient.connect(0);

        // read the data coming in on the client stream and pass it
        // on to the server
        // coming from the server ahead in the chain
        Connection connect0 = (Connection) (cssClient.getConnections().
                                            elementAt(0));
        BufferedReader in = new BufferedReader(new InputStreamReader(connect0.
            getIn()));

        // make a server connected to the input output streams of the client
        // we just constructed
        PipedOutputStream p2Out = new PipedOutputStream();
        PipedInputStream p2In = new PipedInputStream(p2Out);
        PrintWriter out = new PrintWriter(p2Out, true);
        Connection connect1 = (Connection) (cssClient.getConnections().
                                            elementAt(0));
        Connection connect = new StaticIOConnection(p2In, connect1.getOut(), -1);
        ServerMux sm = new ServerMux(css, connect, null);
        sm.doClientIO();
        // Catch the data on the way by and
        // print it out, so that we don't shutdown right away
        String line;
        while ( (line = in.readLine()) != null) {
          LocalSystem.out.println("Intermediate  " + line);
          out.println(line);
        }
        LocalSystem.out.println("Normal Termination ...");
        //in.close();
        //out.close();
        sm.shutdown();
        LocalSystem.out.println("Normal Termination Completed");

      }
      else { // we are the end server in the chain

        PipedOutputStream p2Out = new PipedOutputStream();
        PipedInputStream p2In = new PipedInputStream(p2Out);
        PrintWriter out = new PrintWriter(p2Out, true);
        // this stream goes from the Muxer Client out to this method
        PipedOutputStream p1Out = new PipedOutputStream();
        PipedInputStream p1In = new PipedInputStream(p1Out);
        BufferedReader readStream = new BufferedReader(new InputStreamReader(
            p1In));
        Connection connect = new StaticIOConnection(p2In, p1Out, -1);
        ServerMux sm = new ServerMux(css, connect, null);
        // We read from the LocalSystem only to be able to exit gracefully
        BufferedReader in =
            new BufferedReader(new InputStreamReader(LocalSystem.in));
        sm.doClientIO();
        String line;

        // set the plugin
        if (pluginName != null) {
          out.println(MessageData.makeOutOfBandMessage("controller",
              ServerMux.DATA_COLLECTOR_MSG + pluginName));
          // we don't know what plugin was added, but if it was a time
          // delay plugin, we do want to set the time delay. Other plugins
          // should ignore this message.
          out.println(MessageData.makeOutOfBandMessage("controller",
              "TIME_DELAY=200"));
        }
        int clients = 0;
        while (! (line = readStream.readLine()).equals(MessageData.
            makeOutOfBandMessage(ServerMux.SERVER_SRC,
                                 ServerMux.DATA_COLLECTOR_ACK)))
          ;

        LocalSystem.out.println("Type \"exit\" on a line by itself to quit");
        Runnable runnable = new ReadLooper(readStream);
        Thread tMuxee =
            new Thread(runnable); // new Thread
        tMuxee.start();

        while ( (line = in.readLine()) != null) {
          // "x" to quit:
          LocalSystem.out.println("Sending line: " + line);
          out.println(line);
          if (line.compareTo("exit") == 0)
            break;
          LocalSystem.out.println("Next command: ");
        }
        LocalSystem.out.println("Normal Termination ...");
        p2In.close();
        p1Out.close();
        sm.shutdown();
        LocalSystem.out.println("Normal Termination Completed");
      }
    }
    else { // client
      Connection connect0 = (Connection) (css.getConnections().elementAt(0));
      BufferedReader in = new BufferedReader(new InputStreamReader(connect0.
          getIn()));
      PrintWriter out = new PrintWriter(connect0.getOut(),
                                        true /* Line Buffered */);
      // Echo Server
      String line;

      Runtime runtime = Runtime.getRuntime();

      while ( (line = in.readLine()) != null) {
        if (line.startsWith("#")) {
          continue;
        }
        /*
            String fullLine = "bash -c \"" + line + "\"";
            LocalSystem.out.println(fullLine);
            Process proc = runtime.exec(fullLine);
            OutputStream resOut = proc.getOutputStream();
            PrintWriter resWrite = new PrintWriter(resOut);
            InputStream resIn = proc.getInputStream();
             BufferedReader readerIn = new BufferedReader(new InputStreamReader(resIn));
            InputStream resErr = proc.getErrorStream();
             BufferedReader readerErr = new BufferedReader(new InputStreamReader(resErr));
            // resWrite.println( line );
            //resWrite.println( "echo \\#END_OF_MESSAGE" );
            String resLine;
            while ((resLine = readerIn.readLine()) != null)
          {
            out.println("+"+resLine);
          }
            while ((resLine = readerErr.readLine()) != null)
          {
            out.println("-"+resLine);
          }
            int result = proc.exitValue();
            LocalSystem.out.println("result is: " + result);
            out.println( "#END_OF_MESSAGE");*/
        out.println(line);
      }

      LocalSystem.out.println("Normal Termination");
      out.close();
      in.close();
    }
  }

  /* this test should enable testing of two ServerMuxes, chained
     together. The first ServerMux in the chain should read from the
     DEFAULTPROCFILEPATH file, the second should read from a config
     file called "clients" and will also be client 0 in
     the DEFAULTPROCFILEPATH config file.
     Once the test is started, it will send out commands to the clients,
     which exec them and send back their data through the
     CollationDataCollectionHandler. The "first" server mux collects the
     results, formats them, and prints them out.*/

  public void doTest4(String myName, String fileName) throws Exception {
    LocalSystem.out.println("file name is: " + fileName);
    procFile = DEFAULTPROCFILEPATH;
    if (fileName != null)
      procFile = fileName;
    File f = new File(procFile);
    Properties p = new Properties();
    if (f.canRead()) {
      InputStream in = new FileInputStream(f);
      p.load(in);
      in.close();
    }
    else {
      throw new RuntimeException("File: " + f.getAbsolutePath() +
                                 " cannot be read");
    }
    doSetup(p, myName);
    LocalSystem.err.println("My Machine:" + machines[myProcIndex]);
    dumpMachines();

    ClientServerSocket css;
    if (procFile.startsWith("client")) {
      LocalSystem.out.println("Connecting to the secondary server mux at port " +
                              CLIENTPORT);
      css = new ClientServerSocket(myProcIndex,
                                   CLIENTPORT, machines);
    }
    else {
      LocalSystem.out.println("Connecting to the main server mux at port " +
                              DEFAULTPORT);
      css = new ClientServerSocket(myProcIndex,
                                   DEFAULTPORT, machines);
    }
    css.makeConnection();
    InputStream[] inpS = css.getIn();
    OutputStream[] outpS = css.getOut();
    InetAddress[] addrs = css.getProcessorAddresses();
    if (css.isServer()) {
      if (procFile.startsWith("client")) { // we are the 2nd server in the chain
        // this is a server machine that is also
        // a client of the machine in the "processors" config file
        procFile = DEFAULTPROCFILEPATH;
        File fClient = new File(procFile);
        Properties pClient = new Properties();
        if (fClient.canRead()) {
          InputStream inClient = new FileInputStream(f);
          pClient.load(inClient);
          inClient.close();
        }
        else {
          throw new RuntimeException("File: " + fClient.getAbsolutePath() +
                                     " cannot be read");
        }
        doSetup(p, "0");
        LocalSystem.err.println("My Machine:" + machines[myProcIndex]);
        dumpMachines();

        ClientServerSocket cssClient = new ClientServerSocket(myProcIndex,
            DEFAULTPORT, machines);
        cssClient.makeConnection();
        InputStream[] inpSClient = cssClient.getIn();
        OutputStream[] outpSClient = cssClient.getOut();
        InetAddress[] addrsClient = cssClient.getProcessorAddresses();

        // read the data coming in on the client stream and pass it
        // on to the server
        // coming from the server ahead in the chain
        BufferedReader in = new BufferedReader(new InputStreamReader(inpSClient[
            0]));

        // make a server connected to the input output streams of the client
        // we just constructed
        PipedOutputStream p2Out = new PipedOutputStream();
        PipedInputStream p2In = new PipedInputStream(p2Out);
        PrintWriter out = new PrintWriter(p2Out, true);
        ServerMux sm = new ServerMux(inpS, outpS,
                                     p2In, outpSClient[0]);
        sm.doClientIO();
        // what should I wait for here? Catch the data on the way by and
        // print it out? (Needs another set of input/output streams btw
        // client and server)
        String line;
        while ( (line = in.readLine()) != null) {
          LocalSystem.out.println("Intermediate  " + line);
          out.println(line);
        }
        LocalSystem.out.println("Normal Termination ...");
        sm.shutdown();
        LocalSystem.out.println("Normal Termination Completed");

      }
      else { // we are the end server in the chain

        PipedOutputStream p2Out = new PipedOutputStream();
        PipedInputStream p2In = new PipedInputStream(p2Out);
        PrintWriter out = new PrintWriter(p2Out, true);
        // this stream goes from the Muxer Client out to this method
        PipedOutputStream p1Out = new PipedOutputStream();
        PipedInputStream p1In = new PipedInputStream(p1Out);
        BufferedReader readStream = new BufferedReader(new InputStreamReader(
            p1In));
        ServerMux sm = new ServerMux(inpS, outpS,
                                     p2In, p1Out);
        // We read from the LocalSystem only to be able to exit gracefully
        BufferedReader in =
            new BufferedReader(new InputStreamReader(LocalSystem.in));
        sm.doClientIO();
        String line;
        LocalSystem.out.println("Type \"x\" on a line by itself to quit");
        out.println("#MuxerCommand:DATA_COLLECTOR=gov.sandia.ccaffeine.dc.distributed.CollationDataCollectionHandler>");
        String message;
        while ( (line = in.readLine()) != null) {
          // "x" to quit:
          out.println(line);
          if (line.compareTo("x") == 0)
            break;
          message = readStream.readLine();
          while (!message.startsWith("#END_OF_MESSAGE")) {
            LocalSystem.out.println("Server recieved: " + message);
          }
        }
        LocalSystem.out.println("Normal Termination ...");
        sm.shutdown();
        LocalSystem.out.println("Normal Termination Completed");
      }
    }
    else { // client
      BufferedReader in = new BufferedReader(new InputStreamReader(inpS[0]));
      PrintWriter out = new PrintWriter(outpS[0], true /* Line Buffered */);
      // Echo Server
      String line;
      while ( (line = in.readLine()) != null) {
        if (line.startsWith("#")) {
          continue;
        }
        Runtime runtime = Runtime.getRuntime();
        LocalSystem.out.println("Executing line: " + line);

        Process proc = runtime.exec("bash");
        InputStream resIn = proc.getInputStream();
        OutputStream resOut = proc.getOutputStream();
        PrintWriter resWrite = new PrintWriter(resOut);
        resWrite.println(line);
        BufferedReader reader = new BufferedReader(new InputStreamReader(resIn));
        String resLine;
        while ( (resLine = reader.readLine()) != null) {
          out.println(resLine);
        }
        out.println("#END_OF_MESSAGE");
      }
      LocalSystem.out.println("Normal Termination");
      out.close();
      in.close();
    }
  }

  public void doSetup(Properties p, String myName) {
    Vector tmp = new Vector();
    for (Enumeration e = p.propertyNames(); e.hasMoreElements(); ) {
      String procName = (String) e.nextElement();
      if (procName.compareTo(myName) == 0)
        myProcIndex = tmp.size();
      String type = p.getProperty(procName);
      if (type.compareTo("client") == 0) {
        isServer = false;
      }
      else if (type.compareTo("server") == 0) {
        isServer = true;
      }
      else {
        throw new RuntimeException("Got a different type other than " +
                                   "\"client\" or \"server\" in file" +
                                   "The type is: " + type);
      }
      tmp.addElement(new ProcessorInfo(procName, isServer));
    }
    machines = new ProcessorInfo[tmp.size()];
    tmp.copyInto(machines);
  }

  public void dumpMachines() {
    for (int i = 0; i < machines.length; i++) {
      LocalSystem.out.println(machines[i]);
    }
  }

  public void dumpProcTable(Properties p) {
    p.list(LocalSystem.out);
  }

  public final static void main(String[] arg) throws Exception {
    String usage = "TestClientServer --name MyHostName " +
        "[--file procDefinitionFile]" +
        " [--testName nameOfTest] [--pluginName pluginClassName]";
    String myName = null;
    String procFile = null;
    String pluginName = null;

    StringBuffer sb = new StringBuffer();
    LongOpt[] longopts = new LongOpt[4];
    longopts[0] = new LongOpt("name", LongOpt.REQUIRED_ARGUMENT, sb, 'n');
    longopts[1] = new LongOpt("file", LongOpt.REQUIRED_ARGUMENT, sb, 'f');
    longopts[2] = new LongOpt("testName", LongOpt.REQUIRED_ARGUMENT, sb, 't');
    longopts[3] = new LongOpt("pluginName", LongOpt.REQUIRED_ARGUMENT, sb, 'p');
    Getopt g = new Getopt("TestClientServer", arg, "n:f:t:", longopts);
    String theOption;
    String testName = "0";
    int c;
    while ( (c = g.getopt()) != -1) {
      switch (c) {
        case 'n':

          //Name of processor I am on.
          theOption = "name";
          break;
        case 'f':

          //Name of the Processor file
          theOption = "file";
          break;
        case 't':
          theOption = "testName";
          break;
        case 'p':
          theOption = "pluginName";
          break;
        default:
        case '?':
          LocalSystem.err.println(usage);
          return;
        case 0:
          theOption = longopts[g.getLongind()].getName();
          break;
      }
      if (theOption == "name") {
        myName = g.getOptarg();
      }
      else if (theOption == "file") {
        procFile = g.getOptarg();
      }
      else if (theOption == "testName") {
        testName = g.getOptarg();
      }
      else if (theOption == "pluginName") {
        pluginName = g.getOptarg();
      }
      else {
        LocalSystem.err.println("Bad Option: " + theOption);
        LocalSystem.err.println(usage);
        return;
      }
    }
    if (myName == null) {
      LocalSystem.err.println(usage);
      return;
    }
    TestClientServer tst = new TestClientServer();
    if (testName.compareTo("0") == 0) {
      LocalSystem.out.println("Doing Test0");
      tst.doTest0(myName, procFile);
    }
    else if (testName.compareTo("1") == 0) {
      LocalSystem.out.println("Doing Test1");
      tst.doTest1(myName, procFile, pluginName);
    }
    else if (testName.compareTo("2") == 0) {
      LocalSystem.out.println("Doing Test2");
      tst.doTest2(myName, procFile);
    }
    else if (testName.compareTo("3") == 0) {
      LocalSystem.out.println("Doing Test3");
      tst.doTest3(myName, procFile, pluginName);
    }
    else if (testName.compareTo("4") == 0) {
      LocalSystem.out.println("Doing Test4");
      tst.doTest4(myName, procFile);
    }
    else {
      LocalSystem.err.println(usage);
    }
  }

  class ReadLooper
      implements Runnable {
    BufferedReader readStream;
    public ReadLooper(BufferedReader readStream) {
      this.readStream = readStream;
    }

    public void run() {
      try {
        String message = "";
        String messageLine;
        while ( (messageLine = readStream.readLine()) != null) {
          if (messageLine.startsWith("#+++++END_OF_MESSAGE")) {
            LocalSystem.out.println("New message");
            continue;
          }
          LocalSystem.out.println("CONTROLLER GOT MESSAGE: " + messageLine);
          message += messageLine;
        }
        LocalSystem.out.println("Shutting down reader thread");
      }
      catch (Exception e) {
        LocalSystem.out.println("Exception");
      }
    }
  } // new Runnable()
}

