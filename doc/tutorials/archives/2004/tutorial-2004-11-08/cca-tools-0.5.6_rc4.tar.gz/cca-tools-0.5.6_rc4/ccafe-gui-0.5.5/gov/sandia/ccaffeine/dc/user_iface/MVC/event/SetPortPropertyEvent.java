package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Used to notify components that the cca server
 * has set the value of a property that is inside
 * a port of a cca component.
 * A view entity might
 * respond by saving the new value of the property.
 */
public class SetPortPropertyEvent extends EventObject {

  /**
   * The name of the component that contains the property
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "StartComponent0"
   */
    protected String componentInstanceName = null;




    /**
     * Get the name of the cca component that
     * contains the property.
     * @return the name of the compoonent that
     * contains the property.
     */
    public String getComponentInstanceName() {
        return(this.componentInstanceName);
    }


    /*
     * The name of the port that contains the property.
     */
    protected String portInstanceName = null;

    /**
     * Get the name of the port that
     * contains the property.
     * @return String the name of the port that
     * contains the property.
     */
    public String getPortInstanceName() {
      return(this.portInstanceName);
    }


    /*
     * The name of the property.
     */
    protected String propertyName = null;


    /**
     * Get the name of the property.
     * @return The name of the property.
     */
    public String getPropertyName() {
        return(this.propertyName);
    }

    /*
     * The datatype of the property value
     */
    protected String dataType = null;


    /**
     * Get the data type of the property's value.
     * @return The data type of the property's value.
     */
    public String getDataType() {
        return(this.dataType);
    }



    /*
     * The value of the property.
     */
    protected String propertyValue = null;


    /**
     * Get the value of the property.
     * @return The value of the property.
     */
    public String getPropertyValue() {
        return(this.propertyValue);
    }


    /**
     * Create a SetPropertyEvent.
     * The event can be used to
     * notify components that the cca server
     * has set the value of a property that is inside
     * a port of a cca component.
     * A view entity might
     * respond by saving the new value of the property.
     * @param source The entity that created this event.
     * @param componentInstanceName
     * The name of the component that contains the property
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param portInstanceName the name of the port
     * that contains the property.
     * @param propertyName The name of the property.
     * @param dataType The data type of the property's value.
     * @param propertyValue The value of the property.
     */
    public SetPortPropertyEvent
           (Object source,
            String componentInstanceName,
            String portInstanceName,
            String propertyName,
            String dataType,
            String propertyValue) {

         super(source);
         this.componentInstanceName = componentInstanceName;
         this.portInstanceName = portInstanceName;
         this.propertyName = propertyName;
         this.dataType = dataType;
         this.propertyValue = propertyValue;
    }

}
