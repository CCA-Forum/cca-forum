package gov.sandia.ccaffeine.dc.distributed;

import java.awt.*;
import java.awt.event.*;
import javax.swing.Timer;
import java.util.*;

/**
 * This class listens for the arrival of heartbeats.
 * If no heartbeat is received within a reasonable
 * amount of time then a HeartbeatEvent is sent
 * to every HeartbeatListener.
 * <p>
 * This class can be used by a server to monitor
 * its connection to a client.  The client can
 * periodically sending heartbeats to the server.
 * When the client dies or is disconnected then the
 * client can no longer send heartbeats to the server.
 * This client monitors the amount of time between
 * heartbeats.  If a long amount of time passes without
 * a heartbeat then the server can be notified that the
 * client has lost its connection to the server.
 * <p>
 * SAMPLE CODE: <br>
 * HeartbeatMonitor heartbeatMonitor = new HeartbeatMonitor(); <br>
 * heartbeatMonitor.setNumberOfMillisecondsToWaitForHeartbeat(5000);<br>
 * heartbeatMonitor.addHeartbeatListener(this); <br>
 * heartbeatMonitor.start(); <br>
 * :
 * this.heartbeatMonitor.receivedHeartbeat <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;(new HeartbeatEvent(this)); <br>
 * :
 * public void didNotReceiveHeartbeat(HeartbeatEvent event) { <br>
 * &nbsp;&nbsp;&nbsp;&nbsp;System.out.println("did not recieve heartbeat"); <br>
 * } <br>
 * <p>
*/
public class HeartbeatMonitor
       extends Object
       implements ActionListener, HeartbeatListener {

    /*
    This timer tracks the amount of time that has
    expired since the arrival of the last heartbeat.
    If no heartbeat arrives after a very long time
    then the timer will send out an ActionEvent.
    We will respond to the action event by
    sending a HeartbeatEvent to every
    HeartbeatListener.
    */
    protected javax.swing.Timer timer = null;

    /*
    This is the number of milliseconds the timer
    will wait for the arrival of the next heartbeat.
    If no heartbeat arrives within this amount of time
    then an ActionEvent is generated.
        If no heartbeat arrives after a very long time
    then the timer will send out an ActionEvent.
    We will respond to the action event by
    sending a HeartbeatEvent to every
    HeartbeatListener.
    */
    protected int numberOfMillisecondsToWaitForHeartbeat = 0;

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Retrieve the number of milliseconds that we will
     * wait for a heartbeat.  A return value of 0
     * indicates that we will wait forever.  If no
     * heartbeat is received within this amount
     * of millseconds then a HeartbeatEvent is
     * sent to all HeartbeatListeners.
     * @return The number of milliseconds we will wait
     * for the arrival of a heartbeat.
     */
     synchronized public int getNumberOfMillisecondsToWaitForHeartbeat() {
         return(this.numberOfMillisecondsToWaitForHeartbeat);
     }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



     /**
      * Set the number of milliseconds that we will
      * wait for a heartbeat.  A value of 0 indicates
      * that we will wait forever.  If no
      * heartbeat is received within this amount
      * of millseconds then a HeartbeatEvent is
      * sent to all HeartbeatListeners.
      * @param numberOfMillisecondsToWaitForHeartbeat
      * The number of milliseconds we will wait
      * for the arrival of a heartbeat.
      */
     synchronized public void setNumberOfMillisecondsToWaitForHeartbeat
            (int numberOfMillisecondsToWaitForHeartbeat){

         this.numberOfMillisecondsToWaitForHeartbeat =
             numberOfMillisecondsToWaitForHeartbeat;
     }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Call this method whenever you want to notify
     * this class that you received a heartbeat.
     */
    synchronized public void receivedHeartbeat(HeartbeatEvent event) {

        /*
        Reset the clock that times how long
        we have waited for the arrival of a
        heartbeat.
        */
        start();

        /*
        Send the heartbeat to all registered
        Heartbeat listeners.
        */
        this.broadcastReceviedHeartbeatEvent();
    }

    /**
     * Call this method whenever you want to notify
     * this class that you did NOT receive a heartbeat.
     */
    synchronized public void
         didNotReceiveHeartbeat(HeartbeatEvent event) {
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/




     /**
      * Start monitoring the arrival of heartbeats.
      * If a heartbeat does not arrive before
      * the timeout period then send a
      * DidNotReceiveHeartbeatEvent to all
      * DidNotReceiveHeartbeatListeners.
      */
     synchronized public void start() {
         stop();

         if (this.getNumberOfMillisecondsToWaitForHeartbeat() <= 0)
             return;
         timer = new javax.swing.Timer
             (this.getNumberOfMillisecondsToWaitForHeartbeat(),
              this);
         timer.start();
         //System.out.println("started timer");
     }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Stop monitoring the arrival of heartbeats.
     * If a heartbeat does not arrive before
     * the timeout period then do NOT send a
     * DidNotReceiveHeartbeatEvent to all
     * DidNotReceiveHeartbeatListeners.
     */
    synchronized public void stop() {
        if (timer==null) return;
        timer.stop();
        //System.out.println("stopped timer");
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * It has been a very long time since the arrival
     * of the last heartbeat.  Send a HeartbeatEvent
     * to every registered Heartbeat Listener.
     * @param event
     */
    synchronized public void actionPerformed(ActionEvent event) {
        Object source = event.getSource();
        if (source==this.timer) {
            this.broadcastDidNotRecevieHeartbeatEvent();
        }
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    Vector heartbeatListeners = new Vector();

    /**
     * Register a Heartbeat Listener.
     * Whenever this class receives a heartbeat
     * then all Heartbeat Listeners will be notified.
     * Whenever a very long time passes without the
     * arrival of a heartbeat then all Heartbeat
     * listeners will be notified.
     * @param listener The Heartbeat Listener
     * that wants to be notified whenever this class
     * recieves a heartbeat or when a very long
     * time passes without the arrival of a heartbeat.
     */
    synchronized public void addHeartbeatListener(HeartbeatListener listener)
    {
         heartbeatListeners.add(listener);
    }

    /**
     * Unregister a Heartbeat Listener.
     * Whenever this class receives a heartbeat
     * then do NOT notify this class.
     * Whenever a very long time passes without the
     * arrival of a heartbeat then do NOT
     * notify this class.
     * @param listener The Heartbeat Listener
     * that no longer wants to be notified
     * whenever this class
     * recieves a heartbeat or when a very long
     * time passes without the arrival of a heartbeat.
     */
    synchronized public void removeHeartbeatListener(HeartbeatListener listener)
    {
         heartbeatListeners.remove(listener);
    }


    /**
     * Tell all registered Heartbeat listeners
     * that a heartbeat arrived.
     */
    public void broadcastReceviedHeartbeatEvent(){
        HeartbeatEvent event = new HeartbeatEvent(this);
        broadcastReceivedHeartbeatEvent(event);
    }

    /**
     * Tell all registered Heartbeat listeners
     * that a heartbeat arrived.
     * @param event The event that is generated
     * whenever a heartbeat arrives
     */
    protected void broadcastReceivedHeartbeatEvent(HeartbeatEvent event)
    {
         // loop through each listener and pass on the event if needed
         Vector listeners;
            synchronized (this) {
                listeners = (Vector)heartbeatListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             HeartbeatListener x = (HeartbeatListener)listeners.elementAt(i);
             x.receivedHeartbeat(event);
         }
    }


    /**
     * Tell all registered Heartbeat listeners
     * that it has been a very long time since
     * the last heartbeat arrived.
     * @param event The event that is generated
     * whenever a heartbeat does NOT arrive
     * for a very long time.
     */
    public void broadcastDidNotRecevieHeartbeatEvent(){
        HeartbeatEvent event = new HeartbeatEvent(this);
        broadcastDidNotReceiveHeartbeatEvent(event);
    }


    /**
     * Tell all registered Heartbeat listeners
     * that it has been a very long time since
     * the last heartbeat arrived.
     * @param event The event that is generated
     * whenever a heartbeat does NOT arrive
     * for a very long time.
     */
    protected void broadcastDidNotReceiveHeartbeatEvent(HeartbeatEvent event)
    {
         // loop through each listener and pass on the event if needed
         Vector listeners;
            synchronized (this) {
                listeners = (Vector)heartbeatListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             HeartbeatListener x = (HeartbeatListener)listeners.elementAt(i);
             x.didNotReceiveHeartbeat(event);
         }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    public HeartbeatMonitor() {
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/




}