
package gov.sandia.ccaffeine.dc.user_iface.examples.event;

import java.util.EventListener;

public interface MessageListener extends EventListener{
	public void receivedMessage(MessageEvent event);
}
