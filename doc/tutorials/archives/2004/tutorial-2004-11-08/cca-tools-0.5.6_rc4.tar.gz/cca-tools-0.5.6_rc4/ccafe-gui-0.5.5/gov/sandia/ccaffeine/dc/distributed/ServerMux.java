package gov.sandia.ccaffeine.dc.distributed;

import java.net.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;

/**

				    |--in--| client1
|-------------|---in----|-----------|-out--|	    
|controllerClient  |--out----|ServerMux  |--in--| client2 
|-------------|	        |-----------|-out--|	    
				       .        .   
                                       .	.
				       .	.
 */						 
						 
						 
public class ServerMux implements ClientOutputListener, ClientOutputRelay, ConnectionNotification, HeartbeatListener, ShutdownListener {
    private static String outOfBandToken = MessageData.ALERT_BEG;
    public static final String SERVER_SRC = "ServerMux";
    public static final String DATA_COLLECTOR_ACK = "DATA_COLLECTOR_ACK";
    public static final String REMOVE_CLIENT_MSG = "REMOVE_CLIENT_MSG";
    public static final String SHUTDOWN_MSG = "SHUTDOWN_MSG";
    public static final String DATA_COLLECTOR_MSG = "DATA_COLLECTOR=";
    public static final String DID_NOT_RECEIVE_HEARTBEAT_FROM_GUI_CLIENT = 
                               "DID_NOT_RECEIVE_HEARTBEAT_FROM_GUI_CLIENT";
    private Vector listeners = new Vector();
    private Client controllerClient;			 
    private Thread controllerThread;			 
    private Client[] clients;	// BUGBUG - change to vector		 
    private Thread[] threads;	// BUGBUG - change to vector		 
    private int numClients;			 
    private boolean isStarted = false;
    private ClientOutputCollector dataCollector; 
    private ClientOutputListener xLsnr;
    private ConnectionManager computeClientMgr;
    private ClientFactory clientFactory;

    protected HeartbeatMonitor heartbeatMonitor = null;
    protected int builderPort = -1; //port to GUI client

    Object lockHeartbeat = new Object(); 


    public ServerMux(InputStream[] in, OutputStream[] out, 
		     InputStream controllerInput, 
		     OutputStream controllerOutput) {

	// construct StaticIOConnections for all streams and use the 
	// default client factory

	this.clientFactory = new LinewiseClientFactory();
	dataCollector = new SingleClientDataCollector(this);

	// create the controller client & connection
	Connection connect = new StaticIOConnection(controllerInput, controllerOutput, -1);
	controllerClient = clientFactory.makeClient(connect);
	controllerThread = new Thread(controllerClient);


 
	addOutOfBandListener(new ServerOutOfBandListener(this));

	// create the computeClient clients and connections
	numClients = in.length;
	clients = new LinewiseClient[numClients];
	threads = new Thread[numClients];
	for(int i = 0;i < numClients;i++) {
	    connect = new StaticIOConnection(in[i], out[i], i);
	    // Replace with Factory for Clients
	    clients[i] = clientFactory.makeClient(connect);
	    threads[i] = new Thread(clients[i]);
	}

	
    }



    /**
     @param computeClientMgr connections to MPI nodes
     @param controllerConnect connection to GUI client
     @param clientFactory factory that can create socket connections
     @param heartbeatTimout number of milliseconds we will wait
            for a heartbeat from the GUI client
     @param builderPort The Muxer port that the GUI client connects to
     */
    public ServerMux(ConnectionManager computeClientMgr, 
		     Connection controllerConnect, 
		     ClientFactory clientFactory,
                     int heartbeatTimeout,
                     int builderPort) {

        this(computeClientMgr, controllerConnect, clientFactory);
    
        /* save the builderPort */
        this.builderPort = builderPort;



        LocalSystem.err.println("starting heartbeat monitor");
        LocalSystem.err.flush(); 
        /* create a heartbeat monitor to monitor heartbeats from the GUI client */
        synchronized(lockHeartbeat) {
            
            heartbeatMonitor = new HeartbeatMonitor(); 
            heartbeatMonitor.setNumberOfMillisecondsToWaitForHeartbeat(heartbeatTimeout);
            heartbeatMonitor.addHeartbeatListener(this); 
            heartbeatMonitor.start(); 
            LocalSystem.err.println("started heartbeat monitor");
            LocalSystem.err.flush();
        }

    }


    public ServerMux(ConnectionManager computeClientMgr, 
		     Connection controllerConnect, 
		     ClientFactory clientFactory) {
	
	dataCollector = new SingleClientDataCollector(this);
	addOutOfBandListener(new ServerOutOfBandListener(this));

	if (clientFactory == null)
	    this.clientFactory = new LinewiseClientFactory();
	else
	    this.clientFactory = clientFactory;
	
	this.computeClientMgr = computeClientMgr;
	computeClientMgr.setConnectionNotification(this);
	if (!computeClientMgr.isConnected())
	    {
		computeClientMgr.connect(0); // infinite timeout
	    }
	Vector connections = computeClientMgr.getConnections();

	numClients = connections.size();
	clients = new Client[numClients];
	threads = new Thread[numClients];
	for (int i = 0; i < numClients; i++) {
	    clients[i] = this.clientFactory.makeClient((Connection)connections.elementAt(i));
	    threads[i] = new Thread(clients[i]);
	}
      

        /* controller is the GUI client.  It is a Linewise GUI client. */
	controllerClient = this.clientFactory.makeClient(controllerConnect);
        LocalSystem.err.println("Got a GUI client:" + controllerClient);

        /* if this server goes down then we want to know about it */
        if (controllerClient instanceof LinewiseClient) {
            LinewiseClient server = (LinewiseClient)controllerClient;
            server.addShutdownListener(this);
        }
	controllerThread = new Thread(controllerClient);
    }
    



   /**
   This method is invoked whenever the controllerClient shuts down.
   We want to respond by shutting down all of the MPI nodes.
   @param event The event that is generated when the controllerClient shuts down.
   */
   public void serverShuttingDown(ShutdownEvent event) {
       
        /* We don't need to hear messages from a dead server */
        if (event.getSource() == controllerClient) {
            LinewiseClient server = (LinewiseClient)controllerClient;
            server.removeShutdownListener(this);

        }

       /* Shut everybody down */
       shutdown();
   }



    public void shutdown() {

    LocalSystem.err.println("Shutting down ServerMux");
    LocalSystem.err.flush();


        /* shutdown the MPI nodes */
	for(int i = 0;i < numClients;i++) {
	    clients[i].shutdown();
	}

        /* shutdown the GUI client */
	controllerClient.shutdown();
	try {
	    if (computeClientMgr != null) {
		computeClientMgr.shutdown(); // shutdown any remaining sockets and
		// the server socket
	    }
	    // Any pending output from client should be flushed by this time.
	    Thread.sleep(5); 
	} catch(InterruptedException e) {
	    LocalSystem.err.println("ServerMux::shutdown: "+ e);
	    e.printStackTrace(LocalSystem.err);
	} catch(IOException e) {
	    LocalSystem.err.println("ServerMux::shutdown: "+ e);
	    e.printStackTrace(LocalSystem.err);
	}


        /* kill all the MPI nodes */
        killAllMpiNodes(this.builderPort);

    }
  




    /**
     * Kill all MPI nodes
     * @param builderPort the port number, on the Muxer, that the
     * GUI client uses to connect to the Muxer.
     */
    protected void killAllMpiNodes(int builderPort) {

        /* do we have a builderPort? */
        if (builderPort < 0) return;

        /* get the name of the shell script that can kill the MPI nodes */
        ResourceBundle resourceBundle = 
          ResourceBundle.getBundle("gov.sandia.ccaffeine.dc.distributed.muxer");
        String command = resourceBundle.getString("killMpiNodes.sh") + " "
                       + String.valueOf(builderPort);
        /* launch the os command */
        try {   
            LocalSystem.err.println("Executing " + command);
            Process p = Runtime.getRuntime().exec(command);

            /* save the command's output */
            DataInputStream dis = new DataInputStream
                                   (new BufferedInputStream
                                   (p.getInputStream()));
            while(true) {
                String oneLine = dis.readLine();
                if (oneLine==null) break;
                LocalSystem.err.println(oneLine);
            }
            dis.close();
        }catch (java.io.IOException e){
            LocalSystem.err.println("Error.  Could not execute command.");
        }



    }
       
        
          







  public void setExternalClientOutputListener(ClientOutputListener xLsnr) {
    this.xLsnr = xLsnr;
  }




  public Thread getControllerClientThread() {
    return controllerThread;
  }




  /** Initiate listening and multiplexing client output now. */
  public void doClientIO() {
    for(int i = 0;i < numClients;i++) {
      if(xLsnr != null) {
	clients[i].addClientOutputListener(xLsnr);
      } else {
	clients[i].addClientOutputListener(this);
      }
      threads[i].start();
    }
    if(xLsnr != null) {
      controllerClient.addClientOutputListener(xLsnr);
    } else {
      controllerClient.addClientOutputListener(this);
    }
    controllerThread.start();
    isStarted = true;
  }




  public void broadcastToClients(String s) {
    for(int i = 0;i < clients.length;i++) {
      clients[i].write(s);
    }
  }




  public boolean isRunning() {
    if(isStarted) return true;
    for(int i = 0;i < clients.length;i++) {
      if(threads[i].isAlive()) return true;
    }
    return false;
  }




  /**
  If the heartbeat monitor notices that the GUI client has
  stopped sending heartbeats to the Muxer then the 
  heartbeat monitor will invoke this method.  We want to
  notify the ServerOutOfboundListener that the client
  is no longer connected to the Muxer.
  @param event The event that gets generated whenever the
  heartbeat monitor notices that the GUI client is no longer
  sending heartbeats to the Muxer.
  */
  synchronized public void didNotReceiveHeartbeat(HeartbeatEvent event) {
    LocalSystem.out.println("Did NOT receive a heartbeat from the client.");
    LocalSystem.out.flush();
    doOutOfBandCommands(DID_NOT_RECEIVE_HEARTBEAT_FROM_GUI_CLIENT, null);
  }



  public void receivedHeartbeat(HeartbeatEvent event) {
      //LocalSystem.out.println("got heartbeat from GUI client");
      //LocalSystem.out.flush();
  }



  public synchronized void clientOutput(ClientOutputEvent evt) {

    Object src = evt.getSource();
    String s = evt.getString();

    //LocalSystem.out.println("!s="+s);
    LocalSystem.out.flush();

    if (s.equals("heartbeat")){
        //LocalSystem.out.println("!h");
        //LocalSystem.out.flush();
        synchronized(lockHeartbeat) {
            if (heartbeatMonitor!=null)
                heartbeatMonitor.receivedHeartbeat(new HeartbeatEvent(this));
            //else
                //LocalSystem.out.println("hearbeatMonitor is NULL");
        }
        return;
    }



    // If we are coming from the controller client, then broadcast to
    // compute clients.
    if(src == (Object)controllerClient) {
	dataCollector.controllerClientOutput(evt);
    }
    else {
	// If we are a controller client, send the result data on to the 
	// data collating object.
	dataCollector.computeClientOutput(evt);
    }

    // there is a reason for doing the out of band commands last -
    // one of the out of band commands is "shutdown this server" -
    // if we execute this command first, it becomes rather difficult
    // to propagate the command to everyone else.
    doOutOfBandCommands(s, (Client) src);
  }









    // ConnectionNotification methods
    public void newConnect (Connection newConnection)
    {
	LocalSystem.out.println("Got a new connection in the server mux - not implemented yet");
    }
    




    // ClientOutputRelay methods
    public void relayMessageFromDataProducers(String s)
    {
	controllerClient.write(s);
    }




    // ClientOutputRelay methods
    public void relayMessageFromController(String s)
    {
	broadcastToClients(s);
    }




    public int getNumClients()
    {
	return numClients;
    }




    public  synchronized void setDataCollectorByName( String className )
    {
	ClientOutputCollector oldHandler = dataCollector;
	try {
	    Class collectorClass = Class.forName(className);
	    dataCollector = (ClientOutputCollector) collectorClass.newInstance();
	    dataCollector.setClientOutputRelay (this);
	} catch (Exception e) { 
	    // ClassNotFound, Instanciation and IllegalAccess exceptions
	    // if construction of the class didn't work, assume the 
	    // name given was incorrect.
	    relayMessageFromDataProducers(MessageData.makeErrorMessage(SERVER_SRC, "ServerException:Couldn't create data collector class : " + className + " because " + e.toString() ));
	    return;
	}
	addOutOfBandListener(dataCollector);
	removeOutOfBandListener(oldHandler);
    }














    // OutOfBandListener functions

  /** Register a listener to receive out of band messages recognized
      as lines beginning with an out of band token. */


  public void addOutOfBandListener(OutOfBandListener l) {
    listeners.addElement(l);
  }


  public void removeOutOfBandListener(OutOfBandListener l) {
    listeners.removeElement(l);
  }


  /** Set the out of band token that gets recognized and passed on to
      outOfBandListeners that may be interested in special commands.
      These commands will not be written on the normal output Writer.
      This could be improved by having any number of different tokens
      that would be associated with any number of listener classes.
      In this way there could be a variety of out of band listeners
      for different contexts.  The out of band token must appear first
      on a line with the subsequent command completed with out
      breaking the line.*/
    /** BUGBUG remove this? or actually use it? I'd hate to see it changed after 
     initialization... */
    /*public void setOutOfBandToken(String tok) {
    outOfBandToken = tok;
    }*/


  /** Return the out of band token. */
  public static String getOutofBandToken() {
    return outOfBandToken;
  }




  /** Check for the presence of out of band command, if not just return. */
  private void doOutOfBandCommands(String line, Client src) {
    if(!line.startsWith(outOfBandToken)) return;
    MessageData msg = new MessageData(line, src);
    String cmd = msg.getMessage();
    LocalSystem.out.println("Got out of band message: " + cmd);

    fireOOBListeners(cmd, src);
  }




  private void fireOOBListeners(String cmd, Client client) {
    OutOfBandEvent evt = new OutOfBandEvent(client, cmd);
    for(Enumeration e = listeners.elements();e.hasMoreElements();){
      OutOfBandListener l = (OutOfBandListener) e.nextElement();
      l.processOutOfBand(evt);
    }
  }

}
