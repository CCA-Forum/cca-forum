package gov.sandia.ccaffeine.dc.distributed;

import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;

/** Multiplexes Server IO with multiply connected clients.  Reads
    lines of text from the clients and compresses output by
    comparison. */				 
						 
interface ClientOutputListener extends EventListener {
    public void clientOutput(ClientOutputEvent evt);
}						 
