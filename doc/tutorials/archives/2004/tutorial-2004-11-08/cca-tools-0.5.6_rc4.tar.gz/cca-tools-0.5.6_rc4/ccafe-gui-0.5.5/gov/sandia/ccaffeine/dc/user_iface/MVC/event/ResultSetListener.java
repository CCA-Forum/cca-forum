package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

/**
 * Can listen for responses to queries.
 */

public interface ResultSetListener extends java.util.EventListener {

    public void receivedResultSet(ResultSetEvent event);
    public void receivedException(ExceptionEvent e);

}