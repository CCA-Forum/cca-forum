package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ResultSetListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ExceptionEvent;



    /**
     * We sent a query to an entity.
     * Wait for that entity to respond.
     * The entity will either send us the result set
     * or send us an exception.
     * <p>
     * We have two possible scenarios.  In the first scenario,
     * this thread is started BEFORE the entity sends
     * back a result set in response to the query.  In the
     * second scenario, this thread is started AFTER the
     * entity sens back a result set.
     * <p>
     * SCENARIO:  <br>
     * this thread is started <br>
     * this thread waits for the ResultSetEvent to arrive <br>
     * entity processes query and sends ResultSetEvent <br>
     * This thread terminates <br>
     * <p>
     * SCENARIO:  <br>
     * entity processes query and sends ResultSetEvent <br>
     * this thread is started <br>
     * this thread immediately terminates <br>
     */


public class ThreadWaitForResultSet
       extends Thread
       implements ResultSetListener {

    /* The GUI will send us back one of these events */
    ResultSetEvent resultSetEvent = null;
    ExceptionEvent exceptionEvent = null;

    /**
     * Retrieve the ResultSetEvent.
     * The event will contain the result set of a query.
     * @return the ResultSetEvent.
     */
    public ResultSetEvent getResultSetEvent() {
        return(this.resultSetEvent);
    }





    /**
     * Retrieve the ExceptionEvent.
     * @return The ExceptionEvent.
     */
    public ExceptionEvent getExceptionEvent() {
        return(this.exceptionEvent);
    }


    /* mutex or semaphore */
    Object lock = new Object();


    /**
     * Start the thread.
     */
     /*
     * How do we know
     * if the ResultSetEvent arrived BEFORE
     * or AFTER the run() method is invoked?
     * The run() method can check the state of the ResultSetEvent.
     * If the ResultSetEvent is null then run() was invoked
     * before the query arrived.  If the ResultSetEvent is not
     * null then run() was invoked after the query arrived.
     */
    public void start() {
        this.resultSetEvent = null;
        this.exceptionEvent = null;
        super.start();
    }


    /**
     *  Wait for a result set or an exception or a time out
     */
    /*
     * How do we know
     * if the ResultSetEvent arrived BEFORE
     * or AFTER the run() method is invoked?
     * The run() method can check the state of the ResultSetEvent.
     * If the ResultSetEvent is null then run() was invoked
     * before the query arrived.  If the ResultSetEvent is not
     * null then run() was invoked after the query arrived.
     */
    public void run() {
        synchronized(this.lock) {

            /* if the resultSet has already arrived, */
            /* then terminate this thread immediately     */
            if (this.resultSetEvent!=null) return;
            if (this.exceptionEvent!=null) return;

            /* The resultSet has not yet arrived, */
            /* then wait for it.                  */
            try {this.lock.wait(10000);}
            catch(java.lang.InterruptedException e){
                this.exceptionEvent = new ExceptionEvent(this,e);
            }


            /* if we timed out then throw an InterruptedException */
            if ((resultSetEvent==null) && (exceptionEvent==null)) {
                 java.lang.Exception exception = new java.lang.Exception
                     ("Error.  Could not retrieve value.\nTimed out.");
                 this.exceptionEvent = new ExceptionEvent
                     (this,
                      exception);
            }//if timeout

        }//synchronized
    }//run


    public void receivedResultSet(ResultSetEvent event){
        synchronized(this.lock) {
          if (!this.isAlive()) return;
          this.resultSetEvent = event;
          this.lock.notify();
        }
    }


    public void receivedException(ExceptionEvent event){
        synchronized(this.lock) {
          if (!this.isAlive()) return;
          this.exceptionEvent = event;
          this.lock.notify();
        }
    }
}