package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventListener;

/**
 ControllerListeners can respond to events
 from the client side controller.  The controller
 intercepts messages from the cca server, parses
 the messages, and responds to the messages
 by sending events to a ControllerListener.  A GUI
 class usually implements the ControllerListener.
 */


/*
 * Programmer's Notes:
 * scenario:  GUI wants to populate the palette
 *    GUI formulates a query that asks for all the components in the palette
 *    GUI sends the query to the ViewSocket
 *        NOTE:  The ViewSocket is a GuiListener
 *    ViewSocket forwards the query to the cca server
 *    cca server sends the components to the ControllerSocket
 *    ControllerSocket sends the data to CmdParse
 *    CmdParse invokes one of the CmdActionXXX classes
 *    CmdActionXXX invokes the CmdAction class
 *    CmdAction sends an event to the GUI
 *        NOTE:  The GUI is a ControllerListener
 * scenario:  GUI wants to populate the palette
 *    GUI formulates a query that asks for all the components in the palette
 *    GUI sends the query to the ViewPython
 *        NOTE: The ViewPython is a GuiListener
 *    ViewPython sends a query to the PythonStub
 *    The PythonStub forwards the query to the server skeleton
 *    The server skeleton forwards the query to the cca server
 *    The cca server sends the components to the server skeleton
 *    The server skeleton sends the components to the PythonStub
 *    The PythonStub sends the components to the ControllerPython
 *    The ControllerPython sends the events to the GUI
 *        NOTE:  The GUI is a ControllerListener
 */


public interface ControllerListener extends EventListener {

  /**
   * The cca server added a new component class.
   * The client's controller will instruct the GUI to
   * render the class as a box inside the palette.
   * @param event The event that is generated
   * when the cca server adds a new class.
   */
    public void addComponentClass(AddComponentClassEvent event);


    /**
     * The cca server added one or more Provides Ports
     * to a component.  the client's controller will
     * instruct the GUI to render a box for each port;
     * the boxes are placed on the left side
     * of the component.
     * @param event The event that is generated whenever
     * the cca server adds one or more ports to a component.
     */
    public void addProvidesPorts(AddProvidesPortsEvent event);

    /**
     * The cca server added one or more Uses Ports
     * to a component.  The client's controller will
     * instruct the GUI to render a box for each port;
     * the boxes are placed on the right side
     * of the component.
     * @param event The event that is generated whenever
     * the cca server adds one or more ports to a component.
     */
    public void addUsesPorts(AddUsesPortsEvent event);


    /**
     * The cca server connected a Provides Port
     * to a Uses Port.  The two ports may be on different
     * component or may be on the same component.
     * The client's controller will instruct
     * the GUI to draw a line between the two ports.
     * @param event The event that is generated whenever
     * the cca server connects a Provides Port with a Uses Port.
     */
    public void connect(ConnectEvent event);

   /**
     * The cca server broke the connection between a Provides Port
     * to a Uses Port.
     * The client's controller will instruct
     * the GUI to remove the line between the two ports.
     * @param event The event that is generated whenever
     * the cca server breaks the connection between a Provides Port
     * and a Uses Port.
     */
    public void disconnect(DisconnectEvent event);



  /**
    * The cca server has terminated its communication link with
    * this client.  The client's controller will instruct
    * the GUI to shutdown.
    * @param event The event that is generated whenever
    * the cca server breaks its communication link
    * with this client.
   */
    public void exit(ExitEvent event);


    /**
     * The cca server
     * wants the GUI to write, to stdout,
     * the value of a component property.
     * The client's controller will pass the
     * request to the GUI.
     * @param event The event that is generated whenever
     * the cca server wants the GUI to write,
     * to stdout, the value of a component property.
     */
    public void getComponentProperty(GetComponentPropertyEvent event);

    /**
     * The cca server
     * used a cca component class to instantiate a new
     * cca component object.  The client's controller
     * will instruct the GUI to render the component
     * as a box inside the arena.
     * @param event The event that is generated whenever
     * the cca server used a cca component class to
     * instantiate a new cca component object.
     */
    public void instantiate(InstantiateEvent event);


    /**
     * The cca server loaded the class of a cca widget.
     * The client's controller will instruct the GUI
     * to render the component as a box inside the palette.
     * @param event The event that is generated whenever
     * the cca server loads the java class of a cca widget.
     */
    public void load(LoadEvent event);



    /**
     * The cca server sent a message to this client.
     * The client's controller will instruct the GUI
     * to send the string to stdout.
     * @param event The event that is created whenever
     * the cca server wants the client to display
     * a message on stdout.
     */
    public void message(MessageEvent event);


     /**
      * The cca server is sending, to the client,
      * the current value
      * of a parameter that is contained inside the
      * port of a component.  The client's controller
      * will instruct the GUI to display the value.
      * @param event The event that is created whenever
      * the cca server wants to send the current value
      * of a data field.
      */
    public void paramCurrent(ParamCurrentEvent event);


     /**
      * The cca server is sending the
      * default value of a parameter that is contained
      * inside the port of a component.  The client's
      * controller will send the value to the GUI.
      * @param event The event that is created whenever
      * the cca server sends the default value of a data field.
      */
    public void paramDefault(ParamDefaultEvent event);

    /**
     * The cca server wants the client to create an
     * empty dialog box.  The cca server will later use
     * the dialog box to display port parameters.
     * The client's controller will instruct the GUI
     * to create an empty dialog box.
     * @param event The event that is created whenever
     * the cca server wants the client to create
     * an empty dialog box.
     */
    public void paramDialog(ParamDialogEvent event);


    /**
     * The cca server has finished sending,
     * to the client,
     * information for all the parameters
     * that are inside a specific port.  The client's controller
     * will instruct the GUI to render the finished
     * dialog box on the screen.  NOTE:  The dialog
     * box is used to display the values of the
     * data fields.
     * @param event The event that is created whenever
     * the cca server wants the client to display
     * a dialog box that contains the values of all
     * the data fields inside of a port.
     */
    public void paramEndDialog(ParamEndDialogEvent event);




    /**
     * The cca server has sent this client
     * the name of a parameter that is
     * inside a port.  The client's controller
     * will instruct the GUI to display the
     * name.
     * @param event The event that is created whenever
     * the cca server sends the name of a data field.
     */
    public void paramField(ParamFieldEvent event);


    /**
     * The cca server has sent this client
     * some helpful info about the current
     * port parameter.
     * The client's controller will instruct the
     * GUI to create a tooltip.
     * @param event The event that is generated
     * whenever the cca server sends this client
     * helpful info about a data field that is inside
     * a port.
     */
    public void paramHelp(ParamHelpEvent event);


    /**
    * The cca server sent the lowest value
    * and the highest value that the current
    * port parameter can have.  The client's controller
    * will forward the values to the GUI.
    * @param event The event that is generated
    * whenever the cca server sends this client
    * the lowest value and the highest value
    * the current data field can contain.
    */
    public void paramNumberRange(ParamNumberRangeEvent event);


    /**
     * The cca server sent us the prompt string
     * for one of the parameters in one of the
     * ports of a cca component.  The client's
     * controller will instruct the GUI to display
     * the prompt to the left of the data field.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * This event can be used to notify components
     * that the cca server is sending a prompt string
     * for a data field.
     * A GUI might display the string to prompt
     * the end-user for the value of this data field.
     * @param event The event that is generated
     * whenever the cca server sends this client
     * the contents of a help string.
     */
    public void paramPrompt(ParamPromptEvent event);


    /**
     * The cca server is sending one, out of many,
     * possible values that can be inserted into a
     * data field.  The client's controller will
     * instruct the GUI to insert the value
     * into a choice box.
     * @param event The event that is generated
     * whenever the cca server sends this client
     * one, out of many, possible values that can be
     * inserted into this data field.
     */
    public void paramStringChoice(ParamStringChoiceEvent event);


    /**
     * The cca server is sending the name of tab.
     * The client's controller will instruct the
     * GUI to create a tabbed pane.  The cca server
     * will later use the tabbed pane to display
     * the values of port parameters.
     * @event The event that is generated whenever
     * the cca server sends us the name of a tab.
     */
    public void paramTab(ParamTabEvent event);


    /**
     * The cca server has removed an instantiation of a
     * cca component.  The client's controller will instruct
     * the GUI to remove the component from the arena.
     * @param event The event that is generated whenever
     * the cca server removes an instantiation of a cca
     * component.
     */
    public void remove(RemoveEvent event);

    /**
     * The cca server has revalidated all of the cca ports in
     * a cca component.  The client's controller will instruct
     * the GUI to re-render all of the ports that are
     * inside the cca component.
     * @param event The event that is generated
     * whenever the cca server revalidates all of the
     * cca ports in a cca component.
     */
    public void revalidate(RevalidateEvent event);



    /**
     * The cca server
     * has set the value of a property that is inside
     * a cca component.  The client's controller will
     * forward the value to the GUI.
     * @param event The event that is generated whenever
     * the cca server sets the value of a property
     * that is inside a cca component.
     */
    public void setComponentProperty(SetComponentPropertyEvent event);



    /**
     * The cca server
     * has set the value of a property that is inside
     * a port of a cca component.  The client's controller will
     * forward the value to the GUI.
     * @param event The event that is generated whenever
     * the cca server sets the value of a property
     * that is inside a port of a cca component.
     */
    public void setPortProperty(SetPortPropertyEvent event);



}
