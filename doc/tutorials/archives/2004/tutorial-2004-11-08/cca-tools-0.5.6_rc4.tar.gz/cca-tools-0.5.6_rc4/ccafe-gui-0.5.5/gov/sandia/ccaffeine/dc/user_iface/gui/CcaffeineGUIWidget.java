package gov.sandia.ccaffeine.dc.user_iface.gui;

import java.util.*;

public interface CcaffeineGUIWidget {
  /** Set the arguments for this widget.  There must always be one
   * argument: the class name of the widget itself, other special
   * purpose arguments may follow. */
  void setArguments(String[] args);
}
