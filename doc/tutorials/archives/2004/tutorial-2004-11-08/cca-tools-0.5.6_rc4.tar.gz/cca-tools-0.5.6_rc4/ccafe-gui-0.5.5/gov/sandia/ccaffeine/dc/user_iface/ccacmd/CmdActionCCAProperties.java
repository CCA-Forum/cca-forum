package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;

public class CmdActionCCAProperties
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCAProperties() {
  }

  public String argtype() {
    return "Isa"; // component [key] [value]
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
    return
"property <component-instance-name>\n"+
"   - show all the properties of a component.\n"+
"property <component-instance-name> <key>\n"+
"   - show all the named property of a component, if it exists.\n"+
"property <component-instance-name> <key> <value>\n"+
"   - set the named property of a component.";
  }


  private static final String[] namelist = {"property", "setProperty"};


  public void doIt(CmdContext cc, Vector args) {



       /*
        * The number of arguments in the "property"
        * command.
        */
       int numberOfArguments = args.size();

       /**
        * The name of the component that contains the property
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
       String componentInstanceName = null;
       if (numberOfArguments>0)
           componentInstanceName = (String)args.get(0);

       /*
        * If we are getting or setting the value
        * of a specific property then we need the
        * name of the property.
        */
       String propertyName = null;
       if (numberOfArguments>1)
           propertyName = (String)args.get(1);



       /*
        * If we are setting the value of a
        * property then we need the new value.
        */
       String propertyValue = null;
       if (numberOfArguments>2) {
           StringBuffer buffer = new StringBuffer((String)args.get(2));
           for (int i=3; i<numberOfArguments; i++) {
             buffer.append(" ");
             buffer.append(args.get(i));
           }
           propertyValue = buffer.toString();
       }

       this.broadcastComponentProperties
           (numberOfArguments,
            componentInstanceName,
            propertyName,
            propertyValue);


  }

}
