package gov.sandia.ccaffeine.dc.distributed;

/** This interface is used by the DataCollectors to relay messages to clients
    and get information about the current number of active clients */
interface ClientOutputRelay {
    public void relayMessageFromDataProducers(String s);
    public void relayMessageFromController(String s);
    public void setDataCollectorByName( String className );
    public int getNumClients();
}
