package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * This event can be used to notify components
 * that an entity wants the value
 * of one of these data fields.  A view entity might
 * respond by sending a "configure" or a "parameters"
 * message to the cca server.
 */

public class ParamGetCurrentEvent extends EventObject {

  /*
   * The name of the cca component that contains
   * the port which contains the data field.
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "TimeStamper0"
   */
    protected String componentInstanceName = null;

  /*
   * Get the name of the cca component that contains
   * the port which contains the data field.
   * <p>
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "TimeStamper0"
   * @return The name of the cca component.
   */
    public String getComponentInstanceName() {
        return(this.componentInstanceName);
    }

    /**
     * The name of the port that contains the data field.
     *  Example: "configure_port"
     */
    protected String portInstanceName = null;

    /**
     * Get the name of the port that contains the data field.
     * @return The instance name of the port.
     */
    public String GetPortInstanceName() {
        return(this.portInstanceName);
    }


    /**
     * The name of a data field.
     */
    protected String dataFieldName = null;

    /**
     * Get the name of a data field.
     * @return The name of the data field.
     */
    public String getDataFieldName() {
        return(this.dataFieldName);
    }




    /**
     * Create a ParamGetCurrentEvent.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * This event can be used to notify components
     * that an entity wants to get the value of one of the
     * data fields.  A view entity might
     * respond by sending a "configure" or a "parameters"
     * message to the cca server.
     * @param source The entity that created this event.
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The name of a port that contains the data field.
     *  Example: "configure_port"
     * @param dataFieldName
     * The name of the data field.
     */
    public ParamGetCurrentEvent
         (Object source,
          String componentInstanceName,
          String portInstanceName,
          String dataFieldName) {

         super(source);
         this.componentInstanceName = componentInstanceName;
         this.portInstanceName = portInstanceName;
         this.dataFieldName = dataFieldName;
  }

}