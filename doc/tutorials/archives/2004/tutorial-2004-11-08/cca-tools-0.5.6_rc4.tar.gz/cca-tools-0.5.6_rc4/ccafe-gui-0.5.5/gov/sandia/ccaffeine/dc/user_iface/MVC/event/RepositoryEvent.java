package gov.sandia.ccaffeine.dc.user_iface.MVC.event;


/**
 * An entity can use this event to request a list of
 * all components that are in the repository or to
 * request one specific component.
 */


public class RepositoryEvent extends java.util.EventObject {

    /*
     * The number of arguments in the "repository" command
     */
    protected int numberOfArguments = 0;

    /**
     * Request the number of arguments in the "repository" command.
     * @return The number of arguments in the "repository" command.
     */
    public int getNumberOfArguments() {
        return(this.numberOfArguments);
    }


    /**
     * A command value
     */
    public static final String LIST = "list";

    /**
     * A command value
     */
    public static final String GET = "get";

    /**
     * A command value
     */
    public static final String GET_GLOBAL = "get-global";

    /**
     * A command value
     */
    public static final String GET_LAZY = "get-lazy";

    /**
     * A command value
     */
    public static final String GET_LAZY_GLOBAL = "get-lazy-global";


    /*
     * The command.  The command can be one of the following
     * values:  LIST, GET, GET_GLOBAL, GET_LAZY, GET_LAZY_GLOBAL
     */
    protected String command = "list";

    /**
     * Retrieve the command.
     * The command can be one of the following values:
     * LIST, GET, GET_GLOBAL, GET_LAZY, GET_LAZY_GLOBAL
     * @return The command.
     * The command can be one of the following values:
     * LIST, GET, GET_GLOBAL, GET_LAZY, GET_LAZY_GLOBAL
     */
    public String getCommand() {
      return(command);
    }


    /*
     * If we are retrieving the value of one class,
     * then we need the name of the class.
     */
    protected String className = null;

    /*
     * If we are retrieving the value of one class,
     * then we need the name of the class.
     * @return The name of one class.  Can be set to null.
     */
    public String getClassName() {
      return(this.className);
    }



    /**
     * Construct a RepositoryEvent.
     * An entity can use this event to request a list of
     * all components that are in the repository.
     * @param source The entity that created this event.
     */
    public RepositoryEvent
        (Object source) {

      super(source);
      this.numberOfArguments = 1;
      this.command = this.LIST;
      this.className = null;
    }



    /**
     * Construct a RepositoryEvent.
     * An entity can use this event to request a list of
     * all components that are in the repository.
     * @param source The entity that created this event.
     * @param command the command.
     * The command must be LIST.
     */
    public RepositoryEvent
        (Object source,
         String command) {

      super(source);
      this.numberOfArguments = 1;
      this.command = command;
      this.className = null;
    }



    /**
     * Construct a RepositoryEvent.
     * An entity can use this event to request a list of
     * all components that are in the repository.
     * @param source The entity that created this event.
     * @param numberOfArguments The number of arguments
     * in the command line.
     * @param command the command.
     * The command must be LIST.
     */
    public RepositoryEvent
        (Object source,
         int numberOfArguments,
         String command) {

      super(source);
      this.numberOfArguments = numberOfArguments;
      this.command = command;
      this.className = null;
    }





    /**
     * Construct a RepositoryEvent.
     * An entity can use this event to request a list of
     * all components that are in the repository or to
     * request one specific component.
     * @param source The entity that created this event.
     * @param command the command.
     * The command can be one of the following values:
     * LIST, GET, GET_GLOBAL, GET_LAZY, GET_LAZY_GLOBAL
     * @param className
     * If we are retrieving the value of one class,
     * then we need the name of the class.
     */
    public RepositoryEvent
        (Object source,
         String command,
         String className) {

      super(source);
      this.numberOfArguments = 2;
      this.command = command;
      this.className = className;
    }




    /**
     * Construct a RepositoryEvent.
     * An entity can use this event to request a list of
     * all components that are in the repository or to
     * request one specific component.
     * @param source The entity that created this event.
     * @param numberOfArguments The number of arguments
     * in the command line.
     * @param command the command.
     * The command can be one of the following values:
     * LIST, GET, GET_GLOBAL, GET_LAZY, GET_LAZY_GLOBAL
     * @param className
     * If we are retrieving the value of one class,
     * then we need the name of the class.
     */
    public RepositoryEvent
        (Object source,
         int numberOfArguments,
         String command,
         String className) {

      super(source);
      this.numberOfArguments = numberOfArguments;
      this.command = command;
      this.className = className;
    }

}