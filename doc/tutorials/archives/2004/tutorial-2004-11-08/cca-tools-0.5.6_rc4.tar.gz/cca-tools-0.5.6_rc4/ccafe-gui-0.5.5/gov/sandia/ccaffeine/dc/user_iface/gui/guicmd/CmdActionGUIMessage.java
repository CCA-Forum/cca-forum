package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUI;

/**
 * CmdActionGUIMessage.java
 *
 * If the end-user clicks on the GO button,
 * the cca server executes the go command.
 * The cca server also sends a Message to this client.
 * The client responds by writing the message to standard out.
 */

public class CmdActionGUIMessage
       extends CmdActionGUI
       implements CmdAction {

    public CmdActionGUIMessage() {
    }


    public String argtype(){
	return "s*";
    }

    public String[] names(){
	return namelist;
    }

    public String help(){
	return "reports server messages.";
    }

    private static final String[] namelist = {"Skipping", "delayed", "updated", "parameters", "display", "Too", "go", "Unknown", "Loaded"};

    public void doIt(CmdContext cc, Vector args) {
	//global.pn("***MESSAGE***");
        //this.broadcastMessage(args);
    } // doIt


} // CmdActionGUIConnect
