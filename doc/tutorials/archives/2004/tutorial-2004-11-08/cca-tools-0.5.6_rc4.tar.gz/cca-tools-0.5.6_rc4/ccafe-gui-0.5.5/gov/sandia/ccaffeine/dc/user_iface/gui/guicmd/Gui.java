
package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ControllerListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiUserListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ResultSetListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.AddComponentClassEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.AddProvidesPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.AddUsesPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ConnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisconnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ExitEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GetComponentPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.InstantiateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.LoadEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.MessageEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamCurrentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamDefaultEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamDialogEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamEndDialogEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamFieldEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamHelpEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamNumberRangeEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamPromptEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamStringChoiceEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamTabEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RevalidateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetComponentPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetPortPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PrintEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.QueryEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ResultSetEvent;


import gov.sandia.ccaffeine.dc.user_iface.gui.GlobalData;
import gov.sandia.ccaffeine.dc.user_iface.gui.ComponentInstance;
import gov.sandia.ccaffeine.dc.user_iface.gui.Port;
import gov.sandia.ccaffeine.dc.user_iface.gui.Connection;
import gov.sandia.ccaffeine.dc.distributed.MessageData;
import gov.sandia.ccaffeine.dc.distributed.ServerMux;
import gov.sandia.ccaffeine.dc.user_iface.gui.CcaffeineGUIWidget;
import gov.sandia.ccaffeine.util.LocalSystem;
import gov.sandia.ccaffeine.dc.user_iface.gui.ConfigureDialog;
import gov.sandia.ccaffeine.dc.user_iface.gui.Arena;


import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GoEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ConnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GetInstancesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamGetCurrentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetDebugEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayPaletteEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayChainEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayStateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GoComponentPortEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.NukeAllEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.StringEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.HeartbeatEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PortPropertiesEvent;

import gov.sandia.ccaffeine.dc.user_iface.AccessServer;



/**
 * Interface to the GUI.
 */


/*
 * Programmer's Notes:
 * scenario:  GUI wants to populate the palette
 *    GUI formulates a query that asks for all the components in the palette
 *    GUI sends the query to the ViewSocket
 *        NOTE:  The ViewSocket is a GuiListener
 *    ViewSocket forwards the query to the cca server
 *    cca server sends the components to the ControllerSocket
 *    ControllerSocket sends the data to CmdParse
 *    CmdParse invokes one of the CmdActionXXX classes
 *    CmdActionXXX invokes the CmdAction class
 *    CmdAction sends an event to the GUI
 *        NOTE:  The GUI is a ControllerListener
 * scenario:  GUI wants to populate the palette
 *    GUI formulates a query that asks for all the components in the palette
 *    GUI sends the query to the ViewPython
 *        NOTE: The ViewPython is a GuiListener
 *    ViewPython sends a query to the PythonStub
 *    The PythonStub forwards the query to the server skeleton
 *    The server skeleton forwards the query to the cca server
 *    The cca server sends the components to the server skeleton
 *    The server skeleton sends the components to the PythonStub
 *    The PythonStub sends the components to the ControllerPython
 *    The ControllerPython sends the events to the GUI
 *        NOTE:  The GUI is a ControllerListener
 */

public class Gui extends java.lang.Object
                 implements ControllerListener,
                            GuiUserListener {



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /* global data store */
    GlobalData globalData = null;

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    //java.util.Vector accessServerListeners = new java.util.Vector();
    AccessServer accessServer = new AccessServer();

    synchronized public void addGuiListener(GuiListener listener) {
        //accessServerListeners.add(listener);
        this.accessServer.addGuiListener(listener);
    }

    synchronized public void removeGuiListener(GuiListener listener) {
        //accessServerListeners.remove(listener);
        this.accessServer.removeGuiListener(listener);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Create a Gui object.
     * The object can be used to interact with the GUI.
     * @param globalData Global data store.
     */
    public Gui(GlobalData globalData) {

        /* save the global data store */
        this.globalData = globalData;
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The cca server added a new class.
     * The class can be used to instantiate new
     * cca components.  A GUI might respond by
     * rendering a box inside of a palette; the
     * box represents the component's class.
     * @param event The event that is generated
     * when the cca server adds a new class.
     */
      public void addComponentClass(AddComponentClassEvent event){

        /*
         Get the name of the newly added class.
         The name is actually the name of the component's
         java class.  For example, the name could be
         "gov.sandia.ccaffeine.dc.component.PrinterComponent"
        */
	    String  className = event.getClassName();

        /*
        Tell the GUI to render the newly added class
        as a box inside the palette.
        */
        this.globalData.getPalette().addComponentClass(className);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

      /**
       * The cca server added one or more Provides Ports
       * to a component.  A GUI might
       * respond by rendering a box for each component.
       * The boxes could be placed on the left side
       * of the component.
       * @param event The event that is generated whenever
       * the cca server adds one or more ports to a component.
       */
    public void addProvidesPorts(AddProvidesPortsEvent event){

       /*
        * Get the name of the component that is receiving the new ports.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
        String componentInstanceName = event.getComponentInstanceName();

       /*
        * Get the class name and the instance name of all the ports that
        * were added to a component.
        *
        * vector[0] contains the instance name of port[0]
        * vector[1] contains the class name of port[0]
        * vector[2] contains the instance name of port[1]
        * vector[3] contains the class name of port[1]
        * etc.
        *
        * The class name of a port is the name of the
        * port's java class.  The class name may or may not
        * include the package name.  Examples of class names are
        * "gov.cca.PrintService" and "StringConsumerPort."
        *
        * The instance name of a port is the name of
        * an instantiation of the cca port.
        * Examples of instance names are
        * "pSvc" and "out0"
        */
        java.util.Vector classNameAndInstanceNameOfAllPorts =
            event.getClassNameAndInstanceNameOfAllPorts();

	ComponentInstance instance =
	    this.globalData.getArena().getComponentInstance(componentInstanceName);
	instance.addProvidesPorts(classNameAndInstanceNameOfAllPorts);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The cca server added one or more Uses Ports
     * to a component.  A GUI might
     * respond by rendering a box for each component.
     * The boxes could be placed on the right side
     * of the component.
     * @param event The event that is generated whenever
     * the cca server adds one or more ports to a component.
     */
    public void addUsesPorts(AddUsesPortsEvent event){

       /*
        * Get the name of the component that is receiving the new ports.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
        String componentInstanceName = event.getComponentInstanceName();

       /*
        * Get the class name and the instance name of all the ports that
        * were added to a component.
        *
        * vector[0] contains the instance name of port[0]
        * vector[1] contains the class name of port[0]
        * vector[2] contains the instance name of port[1]
        * vector[3] contains the class name of port[1]
        * etc.
        *
        * The class name of a port is the name of the
        * port's java class.  The class name may or may not
        * include the package name.  Examples of class names are
        * "gov.cca.PrintService" and "StringConsumerPort."
        *
        * The instance name of a port is the name of
        * an instantiation of the cca port.
        * Examples of instance names are
        * "pSvc" and "out0"
        */
        java.util.Vector classNameAndInstanceNameOfAllPorts =
            event.getClassNameAndInstanceNameOfAllPorts();

	ComponentInstance instance =
	    this.globalData.getArena().getComponentInstance(componentInstanceName);
	instance.addUsesPorts(classNameAndInstanceNameOfAllPorts);


    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The cca server connected a Provides Port from one component
     * to a Uses Port.  The Uses Port may be from the
     * same component or may be from a different component.
     * A GUI might
     * respond by drawing a line between the two connected ports.
     * @param event The event that is generated whenever
     * the cca server connects a Provides Port with a Uses Port.
     */
    public void connect(ConnectEvent event){

        /*
         * The name of the component that houses the source port.
         * The source port is one of the two connected ports.
         * The name is usually the java class name of the component
         * (without the package name) concatenated with an index number.
         * Example:  "StartComponent0"
         */
        String sourceComponentName = event.getSourceComponentName();

         /*
          * This is the name of the source port.
          * The source port is connected to the target port.
          * Example:  "out0"
          */
        String sourcePortName = event.getSourcePortName();

        /*
         * The name of the component that houses the target port.
         * The target port is one of the two connected ports.
         * The name is usually the java class name of the component
         * (without the package name) concatenated with an index number.
         * Example:  "Printer0"
         */
        String targetComponentName = event.getTargetComponentName();

         /*
          * This is the name of the target port.
          * The target port is conencted to the source port.
          * Example:  "printer_port"
          */
        String targetPortName = event.getTargetPortName();

	ComponentInstance sourceComponent =
	    this.globalData.getArena().getComponentInstance(sourceComponentName);
	Port sourcePort =
	    sourceComponent.getPort(sourcePortName);
	ComponentInstance targetComponent =
	    this.globalData.getArena().getComponentInstance(targetComponentName);
	Port targetPort =
	    targetComponent.getPort(targetPortName);
        if (sourceComponent == null || targetComponent == null ||
            sourcePort == null || targetPort == null) {
            return;
        }
	this.globalData.getArena().addConnection
	    (new Connection
                 (sourceComponent,
                  sourcePort,
                  targetComponent,
                  targetPort,
                  globalData));

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The cca server broke a connection between a Provides Port
     * and a Uses Port. A GUI might
     * respond by erasing the line that was drawn
     * between the two ports.
     * @param event The event that is generated whenever
     * the cca server breaks the connection between a Provides Port
     * and a Uses Port.
     */
    public void disconnect(DisconnectEvent event){

        /*
         * The name of the component that houses the source port.
         * The source port is no longer connected to the target port.
         * This is the name of the component that houses the source port.
         * The name is usually the java class name of the component
         * (without the package name) concatenated with an index number.
         * Example:  "StartComponent0"
         */
        String sourceComponentName = event.getSourceComponentName();

         /*
          * This is the name of the source port.
          * The source port is no longer connected to the
          * target port.
          * Example:  "out0"
          */
        String sourcePortName = event.getSourcePortName();

        /*
         * The name of the component that houses the target port.
         * The target port is no longer connected to the source port.
         * The name is usually the java class name of the component
         * (without the package name) concatenated with an index number.
         * Example:  "Printer0"
         */
        String targetComponentName = event.getTargetComponentName();

         /*
          * This is the name of the target port.
          * The target port is no longer connected to the source port.
          * Example:  "printer_port"
          */
        String targetPortName = event.getTargetPortName();

	ComponentInstance source =
	    this.globalData.getArena().getComponentInstance(sourceComponentName);
	Port sourcePort =
	    source.getPort(sourcePortName);
	ComponentInstance target =
	    this.globalData.getArena().getComponentInstance(targetComponentName);
	Port targetPort =
	    target.getPort(targetPortName);
        if (source == null || target == null ||
            sourcePort == null || targetPort == null) {
            return;
        }
	this.globalData.getArena().successfulRemoveConnection
	    (new Connection(source, sourcePort,
			    target, targetPort, this.globalData));

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The cca server has terminated its communication link with
     * this client.  A GUI might respond by
     * exiting tht program.
     * @param event The event that is generated whenever
     * the cca server breaks its communication link
     * with this client.
    */
    public void exit(ExitEvent event){

	//this.globalData.write
        //    (MessageData.makeOutOfBandMessage
        //         ("gui",
        //          ServerMux.SHUTDOWN_MSG));

        String message = MessageData.makeOutOfBandMessage
                 ("gui",
                  ServerMux.SHUTDOWN_MSG);
        this.globalData.addToHistoryAndToDebugger(message);
        this.accessServer.broadcastMessage(message);
	System.exit(0);

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The cca server
     * wants the GUI to write, to stdout, the
     * value of a component property.
     * @param event The event that is generated whenever
     * the cca server is querying for the value of a
     * property inside a cca component.
     */
    public void getComponentProperty(GetComponentPropertyEvent event){

       /*
        * The name of the component that contains the property
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        * @return the name of the compoonent that
        * contains the property.
        */
        String componentInstanceName = event.getComponentInstanceName();

       /*
        * The name of the property.
        */
        String propertyName = event.getPropertyName();




        java.util.Hashtable cis = this.globalData.getArena().getComponentInstances();
        ComponentInstance ci = (ComponentInstance)cis.get(componentInstanceName);
        if(ci != null) {
            String value = (String)ci.getProperty(propertyName);

            //this.globalData.write("property "+componentInstanceName+" "+value);
            this.globalData.addToHistoryAndToDebugger
                ("property "+componentInstanceName+" "+propertyName);
            this.message(new MessageEvent
            	 (this,
            	  "property "+componentInstanceName+" "+propertyName + " "+value));

        }

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The cca server
     * used a cca component class to instantiate a new
     * cca component object.  A GUI might
     * respond by rendering a box inside of an arena; the
     * box represents the instantiated component.
     * @param event The event that is generated whenever
     * the cca server used a cca component class to
     * instantiate a new cca component object.
     */
    public void instantiate(InstantiateEvent event){

       /*
        * The name of the class that was used to
        * instantiate a new cca component.
        * The name is actually the name of the component's
        * java class.
        * EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
        */
        String className = event.getClassName();

       /*
        * The name of the newly instantiated
        * cca component object.  The instance
        * name is usually the name of the component's
        * java class (without the package name)
        * concatenated with an index number.
        * EXAMPLE:  "StarterComponent0"
        */
        String instanceName = event.getInstanceName();


	this.globalData.setWaitingForPorts(true);
        this.globalData.pn("gui:Instantiating component, set WaitingForPorts flag");

	this.globalData.getArena().addComponentInstance
	    (new ComponentInstance
		(className,
		 instanceName,
		 this.globalData.getDropLocation(),
		 this.globalData));


    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The cca server loaded the class of a cca widget.
     * The class can be used to instantiate
     * cca widgets.
     * A GUI might respond by rendering a box inside of
     * a palette; the box represents the class of a
     * cca component.  The end-user might be able to
     * drag-and-drop components from the palett to the main
     * workspace (the arena).

     * @param event The event that is generated whenever
     * the cca server loads the java class of a cca widget.
     */
    public void load(LoadEvent event) {

       /*
        The name of a cca component class.
        The class can be used to instantiate new cca components.
        The name is actually the name of the component's
        java class.
        EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
        */
        String className = event.getClassName();


       /*
        * The arguments for this widget.  There must always be one
        * argument: the class name of the widget itself, other special
        * purpose arguments may follow.
        */
       java.util.Vector arguments = event.getArguments();



        try {
            Class widgetClass = Class.forName(className);
            Object widget = widgetClass.newInstance();
            if(widget instanceof CcaffeineGUIWidget) {
	      String[] arg = new String[arguments.size()];
      	      arguments.copyInto(arg);
	      ((CcaffeineGUIWidget)widget).setArguments(arg);
            }
            if(widget instanceof Runnable) {
  	        (new Thread((Runnable)widget)).start();
            }
            if(widget instanceof javax.swing.JInternalFrame) {
	        javax.swing.JInternalFrame frame = (javax.swing.JInternalFrame)widget;
	        frame.setVisible(true);
  	        try {
	            frame.setSelected(true);
	        } catch (java.beans.PropertyVetoException e) {}
	        java.awt.Container c = this.globalData.getAppFrame();
	        // Pretty bad design from the Java folks, the JXXXFrame should
	        // be an interface.
	        if(c instanceof javax.swing.JApplet) {
	            javax.swing.JApplet a = (javax.swing.JApplet)c;
	            a.getContentPane().add(frame);
	            a.repaint();
	        } else if(c instanceof javax.swing.JFrame){
	            javax.swing.JFrame f = (javax.swing.JFrame)c;
	            f.getContentPane().add(frame);
	            f.repaint();
	        } else if(c instanceof javax.swing.JInternalFrame) {
	            javax.swing.JInternalFrame f = (javax.swing.JInternalFrame)c;
	            f.getContentPane().add(frame);
	            f.repaint();
	        }
            }//if widget
        } catch(Exception e) {
            LocalSystem.printException(e);
            LocalSystem.err.println("continuing ...");
        }

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The cca server sent a message to this client.
     * A GUI might respond by printing a string
     * on standard out.
     * @param event The event that is created whenever
     * the cca server sends a message to this client.
     */
    public void message(MessageEvent event){

        if (event==null) return;
        if (event.getMessage()==null) return;
        if (event.getMessage().equals("")) return;

	this.globalData.pn("***MESSAGE***");
        this.globalData.pn(event.getMessage());

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The cca server is sending the current value
     * of a data field.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * The cca server is sending the value
     * of one of these data fields.  A GUI might
     * respond by displaying the current value on the screen.
     * @param event The event that is created whenever
     * the cca server wants to send the current value
     * of a data field.
     */
    public void paramCurrent(ParamCurrentEvent event){

       /*
        * The name of the component that contains
        * port which contains the data fields.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = event.getComponentInstanceName();

       /**
        * The instance name of the port
        * that contains the data field.
        *  Example: "configure_port."
        */
        String portInstanceName = event.getPortInstanceName();


       /**
        * The name of the data field.
        */
        String dataFieldName = event.getDataFieldName();


       /*
        * The value of the data field.
        */
       String dataFieldValue = event.getDataFieldValue();



	String hashKey = componentInstanceName + ":" + portInstanceName;

	ConfigureDialog dialog = this.globalData.getConfigureDialog(hashKey);
        if (dialog!=null)
	    dialog.setCurrentValue(dataFieldName, dataFieldValue);


    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The cca server wants to send the
     * default value of a data field.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * The cca server is sending the default value
     * of one of these data fields.  A GUI
     * might respond by checking the state of a
     * data field; if the data field does not have
     * a current value then the default value is
     * displayed on the screen.
     * @param event The event that is created whenever
     * the cca server sends the default value of a data field.
     */
    public void paramDefault(ParamDefaultEvent event){

       /*
        * The name of the component that contains the
        * port which contains the data field.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = event.getComponentInstanceName();

       /**
        * The instance name of the port
        * that contains the data fields.
        *  Example: "configure_port"
        */
        String portInstanceName = event.GetPortInstanceName();


       /**
        * The name of the data field.
        */
        String dataFieldName = event.getDataFieldName();


       /*
        * The default value of the data field.
        */
       String dataFieldDefaultValue = event.getDataFieldDefaultValue();



	String hashKey = componentInstanceName + ":" + portInstanceName;

	ConfigureDialog dialog = this.globalData.getConfigureDialog(hashKey);
        if (dialog!=null)
  	    dialog.setDefaultValue(dataFieldName, dataFieldDefaultValue);


    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The cca server wants this client
     * to create (but not display) a dialog box
     * to hold the values of all the data fields
     * that are inside a port.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * This event can be used to notify components
     * that the cca server wants the client to
     * create (but not display) a dialog box
     * that contains the values
     * of all the data fields in the port.  A GUI
     * might respond by creating an empty
     * dialog box.
     * @param event The event that is created whenever
     * the cca server wants the client to create
     * an empty dialog box.
     */
    public void paramDialog(ParamDialogEvent event){

       /*
        * The name of a component that contains
        * the port which contains the data fields.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = event.getComponentInstanceName();

       /**
        * The instance name of a port
        * that contains the data fields.
        *  Example: "configure_port"
        */
        String portInstanceName = event.GetPortInstanceName();

       /**
        * The title of
        * the dialog box.
        */
        String titleOfDialogBox = event.getTitleOfDialogBox();



	Arena arena = this.globalData.getArena();

	String hashKey = componentInstanceName + ":" + portInstanceName;

	ConfigureDialog dialog = new ConfigureDialog
            (componentInstanceName,
             portInstanceName,
             titleOfDialogBox,
             this.globalData);
	this.globalData.addConfigureDialog(dialog,hashKey);
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/




    /**
     * The cca server has finished sending
     * information for all the data fields
     * that are inside a port.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * The cca server has finished sending information
     * for all the data fields in a port.  A GUI
     * might respond by displaying a dialog box
     * that is populated with information
     * from all the data fields.
     * @param event The event that is created whenever
     * the cca server wants the client to display
     * a dialog box that contains the values of all
     * the data fields inside of a port.
     */
    public void paramEndDialog(ParamEndDialogEvent event){

       /*
        * The name of a component that contains
        * the port which contains the data fields.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = event.getComponentInstanceName();

       /**
        * The instance name of a port
        * that contains the data fields.
        *  Example: "configure_port"
        */
        String portInstanceName = event.GetPortInstanceName();



	String hashKey = componentInstanceName + ":" + portInstanceName;

	ConfigureDialog dialog = this.globalData.getConfigureDialog(hashKey);
        if (dialog!=null)
  	    dialog.finishAndShow();


    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The cca server has sent this client
     * the name of a data field that is
     * inside a port.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * This event can be used to notify components
     * that the cca server is sending the name of
     * a data field.  A GUI
     * might respond by inserting a line of
     * data into a dialog box.
     * @param event The event that is created whenever
     * the cca server sends the name of a data field.
     */
    public void paramField(ParamFieldEvent event) {

       /*
        * The name of the cca component that contains
        * the port which contains the data field.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = event.getComponentInstanceName();

       /*
        * The name of the port that contains the data field.
        *  Example: "configure_port"
        */
        String portInstanceName = event.GetPortInstanceName();



       /*
        The data type of the value that is
        stored in the data field (e.g. STRING).
        */
        String dataFieldDataType = event.getDataFieldDataType();


       /*
        * The name of a data field.
        */
        String dataFieldName = event.getDataFieldName();



	String hashKey = componentInstanceName + ":" + portInstanceName;

	ConfigureDialog dialog = this.globalData.getConfigureDialog(hashKey);
        if (dialog!=null)
  	   dialog.newDataField(dataFieldDataType,dataFieldName);

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The cca server has sent this client
     * some helpful info about this data field.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * This event can be used to notify components
     * that the cca server is sending the text that
     * contains helpful information on the data field.
     * A GUI might respond by setting up a
     * help system inside of a dialog box.
     * @param event The event that is generated
     * whenever the cca server sends this client
     * helpful info about a data field that is inside
     * a port.
     */
    public void paramHelp(ParamHelpEvent event) {

       /*
        * The name of the cca component that contains
        * the port which contains the data field.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = event.getComponentInstanceName();

       /*
        * The name of the port that contains the data field.
        *  Example: "configure_port"
        */
        String portInstanceName = event.GetPortInstanceName();

       /*
        * The name of a data field.
        */
        String dataFieldName = event.getDataFieldName();

       /*
        Contains some helpful info on this data field.
        */
        String dataFieldHelp = event.getDataFieldHelp();



	String hashKey = componentInstanceName + ":" + portInstanceName;

	ConfigureDialog dialog = this.globalData.getConfigureDialog(hashKey);
        if (dialog!=null)
  	    dialog.setHelpText(dataFieldName, dataFieldHelp);

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/




    /**
     * The cca server sent the lowest value
     * and the highest value that the current
     * data field can have.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * Some of the data fields restrict the
     * range that a value can have.
     * The cca server is sending the lowest value
     * and the highest value that a data field value
     * can have.  A GUI can use to information
     * to might respond by verify that the input
     * values for this data field
     * is within the allowed range.
     * @param event The event that is generated
     * whenever the cca server sends this client
     * the lowest value and the highest value
     * the current data field can contain.
      * @param componentInstanceName
      * The name of the cca component that contains
      * the port which contains the data field.
      * The name is usually the java class name of the component
      * (without the package name) concatenated with an index number.
      * Example:  "TimeStamper0"
      * @param portInstanceName
      * The name of a port that contains the data field.
      * Example: "configure_port"
      * @param dataFieldName
      * The name of the data field.
      * @param dataFieldMinValue
      * The smallest value that can be inserted
      * into the data field.
      * @param dataFieldPrompt
      * The prompt string; a view entity
      * might display the string to prompt the
      * end-user for the value of this data field.
     */
    public void paramNumberRange(ParamNumberRangeEvent event) {

       /*
        * The name of the cca component that contains
        * the port which contains the data field.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = event.getComponentInstanceName();


       /*
        * The name of the port that contains the data field.
        *  Example: "configure_port"
        */
        String portInstanceName = event.GetPortInstanceName();

       /*
        * The name of a data field.
        */
        String dataFieldName = event.getDataFieldName();

       /*
        The smallest value that can be inserted
        into thd data field.
        */
        String dataFieldMinValue = event.getDataFieldMinValue();



       /*
        The largest value that can be inserted
        into thd data field.
        */
        String dataFieldMaxValue = event.getDataFieldMaxValue();




	String hashKey = componentInstanceName + ":" + portInstanceName;

	ConfigureDialog dialog = this.globalData.getConfigureDialog(hashKey);
        if (dialog!=null)
   	    dialog.setNumberRange(dataFieldName, dataFieldMinValue, dataFieldMaxValue);


    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The cca server sent us the prompt string
     * for one of the data fields in one of the
     * ports of a cca component.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * This event can be used to notify components
     * that the cca server is sending a prompt string
     * for a data field.
     * A GUI might display the string to prompt
     * the end-user for the value of this data field.
     * @param event The event that is generated
     * whenever the cca server sends this client
     * the contents of a help string.
     */
    public void paramPrompt(ParamPromptEvent event) {


       /*
        * The name of the cca component that contains
        * the port which contains the data field.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = event.getComponentInstanceName();


       /*
        * The name of the port that contains the data field.
        *  Example: "configure_port"
        */
        String portInstanceName = event.GetPortInstanceName();


       /*
        * The name of a data field.
        */
        String dataFieldName = event.getDataFieldName();


      /*
       * The prompt string; a view entity
       * might display the string to prompt the
       * end-user for the value of this data field.
       */
        String dataFieldPrompt = event.getDataFieldPrompt();



	String hashKey = componentInstanceName + ":" + portInstanceName;

	ConfigureDialog dialog = this.globalData.getConfigureDialog(hashKey);
        if (dialog!=null)
        	dialog.setPromptText(dataFieldName, dataFieldPrompt);

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The cca server is sending one, out of many,
     * possible values that can be inserted into a
     * data field.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * For some data fields, the value must be
     * one of the items in a set (e.g. "red", "green", "blue").
     * The cca server is sending one item that
     * belongs in such a set.
     * A GUI can display the items in the set
     * as a pull down menu.
     * @param event The event that is generated
     * whenever the cca server sends this client
     * one, out of many, possible values that can be
     * inserted into this data field.
     */
    public void paramStringChoice(ParamStringChoiceEvent event){


       /*
        * The name of the cca component that contains
        * the port which contains the data field.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = event.getComponentInstanceName();


       /*
        * The name of the port that contains the data field.
        *  Example: "configure_port"
        */
        String portInstanceName = event.GetPortInstanceName();


       /*
        * The name of a data field.
        */
        String dataFieldName = event.getDataFieldName();



       /*
        * One of the possible values that can be
        * inserted into this data field.
        */
        String dataFieldElementInSetOfValues =
            event.getDataFieldElementInSetOfValues();




	String hashKey = componentInstanceName + ":" + portInstanceName;

	ConfigureDialog dialog = this.globalData.getConfigureDialog(hashKey);
        if (dialog!=null)
  	    dialog.addStringChoice(dataFieldName, dataFieldElementInSetOfValues);

    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The cca server is sending the name of tab.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * Sometimes, the data fields are grouped
     * into sets.  The cca server is sending the
     * name of such a set.
     * A GUI can display each set as a
     * tabbed pane.
     * @event The event that is generated whenever
     * the cca server sends us the name of a tab.
     */
    public void paramTab(ParamTabEvent event){

       /*
        * The name of the cca component that contains
        * the port which contains the data field.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = event.getComponentInstanceName();


       /*
        * The name of the port that contains the data field.
        *  Example: "configure_port"
        */
        String portInstanceName = event.GetPortInstanceName();

        /*
         * Get the name of the tab.
         */
        String tabName = event.getTabName();




	String hashKey = componentInstanceName + ":" + portInstanceName;

	ConfigureDialog dialog = this.globalData.getConfigureDialog(hashKey);
        if (dialog!=null)
  	    dialog.newTab(tabName);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The cca server has removed an instantiation of a
     * cca component.
     * A GUI might
     * respond by removing the component from the arena.
     * @param event The event that is generated whenever
     * the cca server removes an instantiation of a cca
     * component.
     */
    public void remove(RemoveEvent event){


       /**
        * The name of the component that was removed.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
        String componentInstanceName = event.getComponentInstanceName();


	ComponentInstance componentInstance =
	    this.globalData.getArena().getComponentInstance(componentInstanceName);

	this.globalData.getArena().removeComponentInstance(componentInstance);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The cca server has revalidated all of the cca ports in
     * a cca component.
     * A GUI might respond by re-rendering all of the ports
     * that are inside a cca component.
     * @param event The event that is generated
     * whenever the cca server revalidates all of the
     * cca ports in a cca component.
     */
    public void revalidate(RevalidateEvent event){


       /**
        * The name of the component that was revalidated.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
        String componentInstanceName = event.getComponentInstanceName();


	ComponentInstance componentInstance =
	    this.globalData.getArena().getComponentInstance(componentInstanceName);

	this.globalData.setWaitingForPorts(true);
        this.globalData.pn("gui:revalidating component, set WaitingForPorts flag");

	componentInstance.refreshPorts();
    }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The cca server
     * has set the value of a property that is inside
     * a cca component.
     * A GUI might
     * respond by saving the new value of the property.
     * @param event The event that is generated whenever
     * the cca server sets the value of a property
     * that is inside a cca component.
     */
    public void setComponentProperty(SetComponentPropertyEvent event) {

       /*
        * The name of the component that contains the property
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        * @return the name of the compoonent that
        * contains the property.
        */
        String componentInstanceName = event.getComponentInstanceName();

       /*
        * The name of the property.
        */
        String propertyName = event.getPropertyName();


       /**
        * The value of the property.
        */
        String propertyValue = event.getPropertyValue();


    //LocalSystem.err.println("CmdActionGUISetProperty::doIt: "+
	//		    "name = "+componentInstanceName+
        //                    " key = "+propertyName+
        //                    " value = "+propertyValue);

    java.util.Hashtable cis = this.globalData.getArena().getComponentInstances();
    ComponentInstance ci = (ComponentInstance)cis.get(componentInstanceName);
    if(ci != null) {
      ci.setProperty(propertyName, propertyValue);
    }
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The cca server
     * has set the value of a property that is inside
     * a port of a cca component.
     * A GUI might
     * respond by saving the new value of the property.
     * @param event The event that is generated whenever
     * the cca server sets the value of a property
     * that is inside a port of a cca component.
     */
    public void setPortProperty(SetPortPropertyEvent event) {

       /*
        * The name of the component that contains the property
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        * @return the name of the compoonent that
        * contains the property.
        */
        String componentInstanceName = event.getComponentInstanceName();

        /*
         * The name of the port that contains the property.
         */
        String portInstanceName = event.getPortInstanceName();

       /*
        * The name of the property.
        */
        String propertyName = event.getPropertyName();


        /*
         * Get the data type of the property's value.
         */
        String dataType = event.getDataType();


       /**
        * The value of the property.
        */
        String propertyValue = event.getPropertyValue();


    //LocalSystem.err.println("CmdActionGUISetPortProperty::doIt: "+
    //                        "component = "+componentInstanceName+
    //                        " port = " + portInstanceName+
    //                        " key = "+propertyName+
    //                        " data type = " +dataType+
    //                        " value = "+propertyValue);

    java.util.Hashtable cis = this.globalData.getArena().getComponentInstances();
    ComponentInstance ci = (ComponentInstance)cis.get(componentInstanceName);
    if (ci==null) return;
    Port port = ci.getPort(portInstanceName);
    if (port==null) return;
    port.putPortProperty(propertyName, propertyValue);
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The end-user wants to print a string.
     * A GUI might respond by writing the
     * string to standard out.
     * @param event The event that is generated whenever the
     * end-user wants to print a string.
     */
    public void print(PrintEvent event) {

        /* The string that is to be printed */
        String message = event.getMessage();

        this.globalData.p(message);

    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The end-user wants to print a string.
     * A GUI might respond by writing the
     * string to standard out.
     * @param event The event that is generated whenever
     * the end-user wants to print a string.
     */
    public void println(PrintEvent event){

        /* The string that is to be printed */
        String message = event.getMessage();

        this.globalData.pn(message);

    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The end-user
     * wants to send a query to fetch a component instance.
     * A GUI might
     * respond by sending back a
     * ResultSetEvent.
     * @param event The event that is created whenever
     * an entity wants to fetch a component instance.
     */
    public void getComponentInstance(QueryEvent event) {

        /* Who is requesting this info? */
        ResultSetListener requester = event.getRequester();

       /*
        * The name of the cca component that we are searching for.
        * The instance
        * name is usually the name of the component's
        * java class (without the package name)
        * concatenated with an index number.
        * EXAMPLE:  "StarterComponent0"
        */
        String nameOfComponentInstance = (String)event.getQuery();




	if(this.globalData.getArena().getComponentInstances().containsKey(nameOfComponentInstance)) {

            /* wrap the name of the component instance inside an event */
            ResultSetEvent resultSetEvent =
                new ResultSetEvent
                (this, new Object[] {nameOfComponentInstance});
            /* send the event to the requester */
            /* NOTE:  requester will be null after timeout  */
            try {
                requester.receivedResultSet(resultSetEvent);
            }catch (java.lang.NullPointerException e){}
        }

        /* We do not have a component instance--sent null back to the requester */
	else {
             /* send null to the requester */
            /* NOTE:  requester will be null after timeout  */
            ResultSetEvent resultSetEvent =
                new ResultSetEvent
                (this, new Object[] {null});
            try {
                requester.receivedResultSet(resultSetEvent);
            }catch (java.lang.NullPointerException e){}
        }

    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The end-user
     * wants to send a query to fetch the class of
     * cca component.
     * A view entity might
     * respond by sending back a
     * ResultSetEvent.
     * @param event The event that is created whenever
     * the end-user wants to fetch the class of a component.
     */
    public void getComponentClass(QueryEvent event) {

        /* Who is requesting this info? */
        ResultSetListener requester = event.getRequester();

        /*
        * The name of the class that was used to
        * instantiate a new cca component.
        * The name is actually the name of the component's
        * java class.
        * EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
        */
        String nameOfComponentClass = (String)event.getQuery();




	if(this.globalData.getPalette().getComponentClasses().containsKey(nameOfComponentClass)) {

            /* wrap the name of the component instance inside an event */
            ResultSetEvent resultSetEvent =
                new ResultSetEvent
                (this, new Object[] {nameOfComponentClass});
            /* send the event to the requester */
            /* NOTE:  requester will be null after timeout  */
            try {
                requester.receivedResultSet(resultSetEvent);
            }catch (java.lang.NullPointerException e){}
        }

        /* We do not have a component class--sent null back to the requester */
	else {
             /* send null to the requester */
            /* NOTE:  requester will be null after timeout  */
            ResultSetEvent resultSetEvent =
                new ResultSetEvent
                (this, new Object[] {null});
            try {
                requester.receivedResultSet(resultSetEvent);
            }catch (java.lang.NullPointerException e){}
        }

    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The end-user wants to send a query to fetch the
     * "waitingForPorts" flag.
     * A GUI might
     * respond by sending back a
     * ResultSetEvent.
     * @param event The event that is created whenever
     * the end-user wants to fetch the "waitingForPorts" flag.
     */
    public void getWaitingForPorts(QueryEvent event) {

        /* Who is requesting this info? */
        ResultSetListener requester = event.getRequester();

        /* Wrap the state of the "waitingForPorts" flag */
        /* inside of an event.                          */
        ResultSetEvent resultSetEvent = new ResultSetEvent
            (this, new Object[]
               {new Boolean(this.globalData.getWaitingForPorts())});

        /* send the event */
        requester.receivedResultSet(resultSetEvent);
    }



}
