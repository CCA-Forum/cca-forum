package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CcaPort {


    public String className = "";
    public String instanceName = "";






    /**
     * Parse the xml contents of a port.
     * The parsed values are copied into the class's attributes.
     * <p>
     * The XML code will contains something like this: <br>
     * &nbsp;&nbsp;&lt;port&gt; <br>
     * &nbsp;&nbsp;&nbsp;&lt;instanceName&gt;x1&lt;/instanceName&gt; <br>
     * &nbsp;&nbsp;&nbsp;&lt;className&gt;x2&lt;/className&gt; <br>
     * &nbsp;&nbsp;&lt;/port&gt; <br>
     * @param xmlPort the XML code that contains one port
     */
    public CcaPort(String xmlPort) {

        /*
         * Extract out the contents of the port tag
         */
        java.util.regex.Pattern pattern = 
           java.util.regex.Pattern.compile
           ("<instanceName>(.*?)</instanceName>\\s+"
           +"<className>(.*?)</className>");

        java.util.regex.Matcher matcher = 
                pattern.matcher(xmlPort);

        
        /* copy the contents of the 2 tags to our attributes */
        if (matcher.find()) {
            this.instanceName = matcher.group(1);
            this.className = matcher.group(2);
        }
    }

}