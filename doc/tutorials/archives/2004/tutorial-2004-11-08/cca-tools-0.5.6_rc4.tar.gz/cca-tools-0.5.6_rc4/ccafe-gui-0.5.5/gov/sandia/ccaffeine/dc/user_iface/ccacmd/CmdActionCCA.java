package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.CmdAction;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GetInstancesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ConnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetDebugEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisconnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GoEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.InstantiateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayChainEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.NukeAllEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayPaletteEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PathEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PortPropertiesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ComponentPropertiesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RepositoryEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ShellEvent;

/**
 * Used by the parser to parse String commands
 * from the cca server.  The results of a parse
 * are sent to all registered AccessServerListeners.
 */
abstract public class CmdActionCCA extends java.lang.Object
                      implements CmdAction{

    public CmdActionCCA() {
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    java.util.Vector guiListeners = new java.util.Vector();



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Add a new GuiListener.
     * GuiListeners are notified whenever
     * someone wants to access the server.
     * @param listener The new GuiListener
     */
    synchronized public void addGuiListener(GuiListener listener) {
        guiListeners.add(listener);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Remove an GuiListener.
     * The input GuiListener is no longer notified
     * whenever someone accesses the server.
     * @param listener The AccesServerListener that no lonter
      * wants to be notified whenever someone
      * accesses the server.
      */
    synchronized public void removeGuiListener(GuiListener listener) {
        guiListeners.remove(listener);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to retrieve
     * information on all components that are inside 
     * the arena.  The client's view will respond by sending
     * an "instances" command to the cca server.  
     */
    public void broadcastGetAllInstancesInArena() {
        GetInstancesEvent event = new GetInstancesEvent(this);
        broadcastGetAllInstancesInArena(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to retrieve
     * information on all components that are inside 
     * the arena.  The client's view will respond by sending
     * an "instances" command to the cca server.  
     * @param event The event that is generated whenever
     * the GUI wants to get information on all of the instantiated
     * components.
     */
    public void broadcastGetAllInstancesInArena(GetInstancesEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.getAllInstancesInArena(event);
         }
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The client wants the cca server either to retrieve or to set 
     * the value of one of the parameters that are
     * inside a port.  A client's view will
     * respond by sending a "configure" or a "parameters" command
     * to the cca server.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * This event can be used to notify components
     * that an entity is either sending the value
     * of one of these data fields or is querying
     * for the value of one of these data fields.
     * @param numberOfArguments
     * If we are tying to get the value of a
     * parameter then we need 3 arguments
     * (instanceName, portName, parameterName).
     * If we are trying to set the value of a
     * parameter then we need 4 or more arguments
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The name of a port that contains the parameter.
     *  Example: "configure_port"
     * @param dataFieldName
     * The name of the parameter.
     * Tell all GuiListeners that we
     * want to either get or set the value
     * of a parameter.
     * @param dataFieldValue
     * If we are setting the value
     * of a data field then we need to
     * know what that value is.
     * Can be set to null;
     */
    public void broadcastPortParam
         (int numberOfArguments,
          String componentInstanceName,
          String portInstanceName,
          String dataFieldName,
          String dataFieldValue) {

        ParamEvent event = new ParamEvent
            (this,
             numberOfArguments,
             componentInstanceName,
             portInstanceName,
             dataFieldName,
             dataFieldValue);
        broadcastPortParam(event);

     }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The client wants the cca server either to retrieve or to set 
     * the value of one of the parameters that are
     * inside a port.  A client's view will
     * respond by sending a "configure" or a "parameters" command
     * to the cca server.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * This event can be used to notify components
     * that an entity is either sending the value
     * of one of these data fields or is querying
     * for the value of one of these data fields.
     * @param event The event that is generated
     * whenever the GUI wants either to set the value of
     * a port parameter or to query for the value of a
     * port parameter.
     */
    public void broadcastPortParam
         (ParamEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.portParameter(event);
         }


     }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to connect
     * two ports.  The two ports may be on different
     * components or may be on the same component.
     * The client's view will respond by sending
     * a "connect" command to the cca server.  
     * @param sourceComponentName The name of the component
     * that houses the source port. The "source" is the entity
     * that is requesting the connection.  The "source" 
     * is to be connected to the "target."
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param sourcePortName The name of the source port.
     * The "source" is the entity that is requesting the connection.  
     * The "source" is to be connected to the "target."
     * Example:  "out0"
     * @param targetComponentName The name of the component
     * that houses the target port.  The "target" is the entity
     * that receives the connection request.  The "source"
     * is to be connected to the "target."
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "PrinterComponent0"
     * @param targetPortName the name of the target port.
     * The "target" is the entity
     * that receives the connection request.  The "source"
     * is to be connected to the "target."
     * Example:  "out0"
     */
    public void broadcastConnect
        (String sourceComponentName,
         String sourcePortName,
         String targetComponentName,
         String targetPortName) {

        ConnectEvent event = new ConnectEvent
            (this,
             sourceComponentName,
             sourcePortName,
             targetComponentName,
             targetPortName);
        broadcastConnect(event);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to connect
     * two ports.  The two ports may be on different
     * components or may be on the same component.
     * The client's view will respond by sending
     * a "connect" command to the cca server.  
     * @param The event that is generated whenever the
     * GUI wants to connect a ProvidesPort to a
     * UsesPort.
     */
    public void broadcastConnect(ConnectEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.connect(event);
         }
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to print
     * debugging statements.  A client's view will
     * respond by sending a "debug" or "noisy" command
     * to the cca server.
     */
    public void broadcastSetDebug() {
        SetDebugEvent event = new SetDebugEvent(this);
        broadcastSetDebug(event);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to print
     * debugging statements.  A client's view will
     * respond by sending a "debug" or "noisy" command
     * to the cca server.
     * @event The event that is generated whenever
     * the GUI wants the cca server to print debugging
     * statements.
     */
    public void broadcastSetDebug(SetDebugEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.setDebug(event);
         }

    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to break the
     * connection that exists between two ports.  
     * The client's view will respond by sending a "disconnect"
     * command to the cca server.     
     * @param sourceComponentName The name of the component
     * that houses the source port. The "source" is the entity
     * that originally requested the connection.  The "source" 
     * is connected to the "target."
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param sourcePortName The name of the source port.
     * The "source" is the entity that originally requested the connection.  
     * The "source" is connected to the "target."
     * Example:  "out0"
     * @param targetComponentName The name of the component
     * that houses the target port.  The "target" is the entity
     * that originally received the connection request.  The "source"
     * is to be connected to the "target."
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "PrinterComponent0"
     * @param targetPortName the name of the target port.
     * The "target" is the entity that originally received
     * the connection request.  The "source"
     * is connected to the "target."
     * Example:  "out0"
     */
    public void broadcastDisconnect
        (String sourceComponentName,
         String sourcePortName,
         String targetComponentName,
         String targetPortName) {

        DisconnectEvent event = new DisconnectEvent
            (this,
             sourceComponentName,
             sourcePortName,
             targetComponentName,
             targetPortName);
        broadcastDisconnect(event);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to break the
     * connection that exists between two ports.  
     * The client's view will respond by sending a "disconnect"
     * command to the cca server.     
     * @param The event that is generated whenever the
     * GUI wants to disconnect the connection between a ProvidesPort
     * and a UsesPort.
     */
    public void broadcastDisconnect(DisconnectEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.disconnect(event);
         }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to 
     * retrieve some information.
     * The client's view will respond by sending one of the
     * following commands to the cca server: <br>   
     * &nbsp;&nbsp;&nbsp;&nbsp;display palette <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display arena <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display chain <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display component <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display state <br>
     * <p>
     * The cca server will respond to a "display palette"
     * command by retrieving information on every component
     * that is inside the palette.
     * <p>
     * The cca server will respond to a "display arena"
     * command by retrieving information on every component
     * that is inside the arena.
     * <p>
     * The cca server will respond to a "display chain"
     * command by retrieving information on every connection
     * that is inside the arena.  A connection connects
     * a "uses" port with a "provides" port.
     * <p>
     * The cca server will respond to a "display component"
     * command by retrieving information on a specific 
     * component.
     * <p>
     * The cca server will respond to a "display state"
     * command by retrieving information on every component
     * and on every connection that is inside the arena.
     * @param source The entity that created this event.
     * @param entity We are requesting info
     * on which entity?  We can
     * request info on the PALETTE,
     * ARENA, CHAIN, COMPONENT,
     * STATE.
     * @param componentInstanceName
     * If an entity wants some info on
     * a particular component, then that
     * entity has to supply the name of
     * the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     * Can be set to null.
     */
    public void broadcastDisplay
        (int numberOfArguments,
         String entity,
         String componentInstanceName) {

      DisplayEvent event = new DisplayEvent
          (this,
           numberOfArguments,
           entity,
           componentInstanceName);

      broadcastDisplay(event);
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to 
     * retrieve some information.
     * The client's view will respond by sending one of the
     * following commands to the cca server: <br>   
     * &nbsp;&nbsp;&nbsp;&nbsp;display palette <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display arena <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display chain <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display component <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display state <br>
     * <p>
     * The cca server will respond to a "display palette"
     * command by retrieving information on every component
     * that is inside the palette.
     * <p>
     * The cca server will respond to a "display arena"
     * command by retrieving information on every component
     * that is inside the arena.
     * <p>
     * The cca server will respond to a "display chain"
     * command by retrieving information on every connection
     * that is inside the arena.  A connection connects
     * a "uses" port with a "provides" port.
     * <p>
     * The cca server will respond to a "display component"
     * command by retrieving information on a specific 
     * component.
     * <p>
     * The cca server will respond to a "display state"
     * command by retrieving information on every component
     * and on every connection that is inside the arena.
     * @param source The entity that created this event.
     * @param entity We are requesting info
     * on which entity?  We can
     * request info on the PALETTE,
     * ARENA, CHAIN, COMPONENT,
     * STATE.
     * @param DisplayEvent The event that is
     * generated whenever the GUI is requesting
     * some information from the server.
     */
     public void broadcastDisplay(DisplayEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.display(event);
         }

     }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to lanuch
     * the applicaton.  The client's view will send
     * a "run" command to the cca server. 
     * @param numberOfArguments the number of
     * arguments in the "go" command.
     * @param componentInstanceName
     * To call "go" on a specific
     * component, pass in the
     * name of the component.
     * The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0".
     * Can be null.
     * @param portInstanceName
     * To call"go" on a specific
     * "go" port on a specific component
     * then, pass in the
     * name of the "go" port.  Can be null.
     */
    public void broadcastGo
        (int numberOfArguments,
         String componentInstanceName,
         String portInstanceName) {

      GoEvent event = new GoEvent
          (this,
           numberOfArguments,
           componentInstanceName,
           portInstanceName);

      broadcastGo(event);

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to lanuch
     * the applicaton.  The client's view will send
     * a "run" command to the cca server. 
     * @param event The event that is created
     * whenever the GUI wants the cca server to
     * launch the application.
     */
    public void broadcastGo(GoEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.go(event);
         }


    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to instantatiate
     * a component.  The client's view will respond by sending
     * a "pull down" command to the cca server.  
     * @param className The name of the component's class.
     * The name is actually the name of the component's
     * java class.
     * EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
     * @param instanceName The name of the
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     */
    public void broadcastInstantiateComponent
                (String className,
                 String instanceName) {

        InstantiateEvent event = new InstantiateEvent
            (this,
             className,
             instanceName);

        broadcastInstantiateComponent(event);

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The client wants the cca server to instantatiate
     * a component.  The client's view will respond by sending
     * a "pull down" command to the cca server.  
     * @param The event that is generated whenever the
     * GUI is requesting that a component be instantiated.
     */
    public void broadcastInstantiateComponent
                (InstantiateEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.instantiate(event);
         }
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to retrieve
     * information on every connection that is inside
     * the arena.  A connection connects a "uses" port
     * with a "provides" port.  A client's view will
     * respond by sending a "links" command
     * to the cca server.
     */
    public void broadcastLinks() {

      DisplayChainEvent event = new DisplayChainEvent(this);

      broadcastLinks(event);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to retrieve
     * information on every connection that is inside
     * the arena.  A connection connects a "uses" port
     * with a "provides" port.  A client's view will
     * respond by sending a "links" command
     * to the cca server.
     * @param event The event that is created
     * whenever the GUI wants to know what connections
     * are in the arena.
     */
    public void broadcastLinks(DisplayChainEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.links(event);
        }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to stop printing
     * debugging statements.  A client's view will
     * respond by sending a "nodebug" or "quiet" command
     * to the cca server.
     */
    public void broadcastSetNoDebug() {
        SetDebugEvent event =
            new SetDebugEvent(this);
        broadcastSetNoDebug(event);
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to stop printing
     * debugging statements.  A client's view will
     * respond by sending a "nodebug" or "quiet" command
     * to the cca server.
     * @event The event that is generated whenever
     * the GUI wants the server to stop printing debugging
     * statements.
     */
    public void broadcastSetNoDebug(SetDebugEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.setNoDebug(event);
        }

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to remove
     * an instantiation of a cca component.  The
     * client's view will respond by sending a "remove" command
     * to the cca server.
     * @param componentInstanceName
     * The name of the component that was removed.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     */
    public void broadcastRemove
             (String componentInstanceName) {
         RemoveEvent event = new RemoveEvent
             (this,
              componentInstanceName);
        this.broadcastRemoveEvent(event);
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to remove
     * an instantiation of a cca component.  The
     * client's view will respond by sending a "remove" command
     * to the cca server.
     * @param event The event that is generated whenever
     * the GUI is requesting that a component be removed.
     */
    protected void broadcastRemoveEvent(RemoveEvent event) {
        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.remove(event);
        }
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server to destroy
     * all of the instantiated components (i.e. all
     * of the components that are in the arena).
     * A client's view will
     * respond by sending a "nuke all" command
     * to the cca server.
     * @param numberOfArguments The number of
     * arguments in the nuke command.
     * @param entity
     * The entity that is to be removed.
     * NOTE:  As of Oct 2003, "all" is the
     * only entity that can be nuked.
     */
     public void broadcastNukeAll
            (int numberOfArguments,
             String entity) {
        NukeAllEvent event = new NukeAllEvent
            (this,
             numberOfArguments,
             entity);
        broadcastNukeAll(event);
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The client wants the cca server to destroy
     * all of the instantiated components (i.e. all
     * of the components that are in the arena).
     * A client's view will
     * respond by sending a "nuke all" command
     * to the cca server.
     * param event The event that is created
     * when the GUI wants to to delete
     * all components.
     */
     public void broadcastNukeAll(NukeAllEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.nukeAll(event);
        }
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The client wants the cca server to retrieve
     * information on every component that is inside
     * the palette.  A client's view will
     * respond by sending a "display palette" command
     * to the cca server.
     */
    public void broadcastDisplayPalette() {
        DisplayPaletteEvent event =
            new DisplayPaletteEvent(this);
        broadcastDisplayPalette(event);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The client wants the cca server to retrieve
     * information on every component that is inside
     * the palette.  A client's view will
     * respond by sending a "display palette" command
     * to the cca server.
     * @param event The event that is generated whenever
     * the GUI wants to know what components
     * are in the palette.
     */
    public void broadcastDisplayPalette(DisplayPaletteEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.displayPalette(event);
        }
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The client wants either to tell the cca
     * server the name of the folder that contains
     * cca component or to ask the cca server to
     * retrieve the name of the folder.
     * A client's view will
     * respond by sending a "path" command
     * to the cca server.
     * @param numberOfArguments
     * The number of arguments
     * in the path command.
     * @param commandToAlterPath
     * To alter the path,
     * specify how the path
     * is to be chagned by
     * issuing
     * any of the following commands:
     * INIT, APPEND, PREPEND, SET.
     * Can be set to null.
     * @param directory
     * To alter the path,
     * specify the value
     * of the new path.
     * Can be set to null.
     */
    public void broadcastPath
            (int numberOfArguments,
            String commandToAlterPath,
            String directory) {

        PathEvent event = new PathEvent
            (this,
             numberOfArguments,
             commandToAlterPath,
             directory);

        broadcastPath(event);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/





    /**
     * The client wants either to tell the cca
     * server the name of the folder that contains
     * cca component or to ask the cca server to
     * retrieve the name of the folder.
     * A client's view will
     * respond by sending a "path" command
     * to the cca server.
     * @param event The event that is
     * generated whenever the GUI
     * wants the cca server either to set the path
     * to a new value or to query
     * for the path value.
     */
    public void broadcastPath(PathEvent event){

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.path(event);
        }
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The client wants the cca server either to
     * get or to set the
     * value of one of the parameters that are
     * inside a port.  A client's view will
     * respond by sending a "port-parameters" command
     * to the cca server.
     * @param numberOfArguments
     * The number of arguments in the "port-properties"
     * command.
     * @param componentInstanceName
     * The name of the component that contains the property.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param portName
     * The name of the port that contains the property.
     * @param propertyName If we want to
     * get or set the value of a specific
     * port property, then we need the
     * name of the property.
     * @param dataTypeOfPropertyValue If we are
     * setting the value of a specific port property,
     * then we need the datatype
     * of the property value.
     * @param propertyValue If we are
     * setting the value of a specific port property,
     * then we need the value of the property.     */
     public void broadcastPortProperties
           (int numberOfArguments,
            String componentInstanceName,
			String portName,
            String propertyName,
            String dataTypeOfPropertyValue,
            String propertyValue) {

         PortPropertiesEvent event =
             new PortPropertiesEvent
               (this,
                numberOfArguments,
                componentInstanceName,
				portName,
                propertyName,
                dataTypeOfPropertyValue,
                propertyValue);

           broadcastPortProperties(event);
     }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The client wants the cca server to set the
     * value of one of the parameters that are
     * inside a port.  A client's view will
     * respond by sending a "port-properties" command
     * to the cca server.
     * @param The event that is generated whenever the
     * GUI wants to set the value of a port parameter.
     */
     public void broadcastPortProperties(PortPropertiesEvent event){

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.portProperties(event);
        }
     }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The client wants the cca server either to get
     * or to set the value
     * of a specific property that is contained
     * inside a specific component.  A client's view will
     * respond by sending a "property" or a 
     * "set property" command
     * to the cca server.
     * @param numberOfArguments
     * The number of arguments in the "properties"
     * command.
     * @param componentInstanceName
     * The name of the component that contains the property
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "StartComponent0"
     * @param propertyName If we want to
     * get or set the value of a specific
     * port property, then we need the
     * name of the property.
     * @param propertyValue If we are
     * setting the value of a specific port property,
     * then we need the value of the property.     */
     public void broadcastComponentProperties
           (int numberOfArguments,
            String componentInstanceName,
            String propertyName,
            String propertyValue) {

         ComponentPropertiesEvent event =
             new ComponentPropertiesEvent
               (this,
                numberOfArguments,
                componentInstanceName,
                propertyName,
                propertyValue);

           broadcastComponentProperties(event);
     }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The client wants the cca server either to get
     * the value of or to set the value
     * of a specific property that is contained
     * inside a specific component.  A client's view will
     * respond by sending a "property" or a 
     * "set property" command
     * to the cca server.
     * @param event The event that is generated
     * whenever the GUI wants to either get or
     * set the value of a component property.
     */
     public void broadcastComponentProperties(ComponentPropertiesEvent event){

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.componentProperties(event);
        }
     }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server either to
     * send informaton on every component that is inside
     * the repository or to send information on one
     * specific component that is inside the repository.
     * The client's view will
     * respond by sending a "repository" command
     * to the cca server.
     * @param source The entity that created this event.
     * @param numberOfArguments The number of arguments
     * in the command line.
     * @param command the command.
     * The command can be one of the following values:
     * LIST, GET, GET_GLOBAL, GET_LAZY, GET_LAZY_GLOBAL
     * @param className
     * If we are retrieving the value of one class,
     * then we need the name of the class.
     */
    public void broadcastRepository
        (int numberOfArguments,
         String command,
         String className) {

      RepositoryEvent event = new RepositoryEvent
          (this,
           numberOfArguments,
           command,
           className);

      broadcastRepository(event);

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * The client wants the cca server either to
     * send informaton on every component that is inside
     * the repository or to send information on one
     * specific component that is inside the repository.
     * The client's view will
     * respond by sending a "repository" command
     * to the cca server.
     * @param event The event that is created whenever
     * the GUI wants to get one component or all components
     * from the repository,
     */
    public void broadcastRepository
        (RepositoryEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.repository(event);
        }

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to execute
     * a specific command.  The client's view will
     * respond by sending a "shell" command to the cca server.
     * @param numberOfArguments The number of arguments
     * in the "shell" command.
     * @param command The command that is to be
     * executed.
     */
    public void broadcastShell
           (int numberOfArguments,
            String command) {

         ShellEvent event = new ShellEvent
             (this,
              numberOfArguments,
              command);

         broadcastShell(event);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The client wants the cca server to execute
     * a specific command.  The client's view will
     * respond by sending a "shell" command to the cca server.
     * @param event The event that is
     * created whenever the GUI wants
     * an O.S. command executed.
     */
    public void broadcastShell(ShellEvent event) {

        // loop through each listener and pass on the event if needed
        java.util.Vector listeners;
        synchronized (this) {
            listeners = (java.util.Vector)guiListeners.clone();
         }
        int numberOfListeners = listeners.size();
        for (int i=0; i<numberOfListeners; i++){
            GuiListener x = (GuiListener)listeners.elementAt(i);
            x.shell(event);
        }
    }

}