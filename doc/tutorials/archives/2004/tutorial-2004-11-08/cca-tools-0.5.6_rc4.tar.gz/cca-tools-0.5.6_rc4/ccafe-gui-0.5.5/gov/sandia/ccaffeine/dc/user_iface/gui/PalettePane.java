package gov.sandia.ccaffeine.dc.user_iface.gui;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;


public class PalettePane extends JPanel {
    
    public PalettePane(GlobalData global) {
	super();
	this.global = global;
	initialize();
    }
    public void initialize(){
	setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
	setBorder(paletteBorder);
	componentClasses = new Hashtable();
	
	thePalette = new JPanel();
	thePalette.setLayout(new BoxLayout(thePalette, BoxLayout.Y_AXIS));
	add(thePalette);
	add(Box.createVerticalGlue());
    }	
    public void addComponentClass(String classpath){
	ComponentClass cc = new ComponentClass(classpath, global);
	cc.setMaximumSize(cc.getPreferredSize());
	JPanel panel = new JPanel();
	panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
	panel.add(cc);
	panel.add(Box.createHorizontalGlue());
	thePalette.add(panel);
	thePalette.add(Box.createVerticalStrut(5));
 	componentClasses.put(cc.getClassPath(), cc);
	thePalette.setSize(thePalette.getPreferredSize());
	setMaximumSize(new Dimension(getPreferredSize().width, 9999));
	global.getBuilder().arrange();
    }
    public Hashtable getComponentClasses(){
	return componentClasses;
    }
    private GlobalData          global;
    private Hashtable componentClasses;
    private JPanel          thePalette;
    private int             classCount;
    private final Border paletteBorder = BorderFactory.createCompoundBorder
	 (BorderFactory.createTitledBorder("Palette"),
	  BorderFactory.createEmptyBorder(5,5,5,5));
} // Palette
