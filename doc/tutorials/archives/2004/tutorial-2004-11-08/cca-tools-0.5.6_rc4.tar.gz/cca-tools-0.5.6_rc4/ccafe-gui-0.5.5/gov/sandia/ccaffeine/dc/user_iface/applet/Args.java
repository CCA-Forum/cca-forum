package gov.sandia.ccaffeine.dc.user_iface.applet;
import gov.sandia.ccaffeine.util.LocalSystem;
import gnu.getopt.*;
import java.util.*;
import java.io.*;


/** Simple argument class for the Builders.  Not all arguments make
    sense in all contexts. */
public class Args {
  public static final String DEFAULTPROCFILEPATH = "processors";
  public static final int DEFAULTPORT = 2023;
  public static final int DEFAULTBUILDERPORT = 2024;
  /** Port to listen on. */
  public int portNumber = DEFAULTPORT;
  /** Name of the type of run to be done. */
  public static String type; 
  /** Path to the processor file. */
  public static String procFile;
  /** The name, found in the processor file, that refers to this process */
  public static String myProcName = null;
  /** Special mode for debugging. */
  public static String appletHostname = null;
  /** Port number for the builder to contact the MuxingProcess. */
  public static int builderPort = DEFAULTBUILDERPORT;
  /** Timeout that a server should wait for the client to
      connect. Zero means infinity. */
  public long timeout = -1;

  public Args() {
  }
  /** Create an Args with the String array argument; parseArgs does
      not need to be called */
  public Args(String[] s) {
    parseArgs(s);
  }
  public void parseArgs(String[] args) {
    String usage = "<MuxingProcess> --name MyHostName "+
      "[--file procDefinitionFile]"+
      "[--timeout]"+"[--builderPort port]"+
      "[--port port]";
    procFile = DEFAULTPROCFILEPATH;

    StringBuffer sb = new StringBuffer();
    LongOpt[] longopts = new LongOpt[6];
    longopts[0] = new LongOpt("name", LongOpt.REQUIRED_ARGUMENT, sb, 'n');
    longopts[1] = new LongOpt("file", LongOpt.REQUIRED_ARGUMENT, sb, 'f');
    longopts[2] = new LongOpt("builderPort", LongOpt.REQUIRED_ARGUMENT, sb, 
			      'u');
    longopts[3] = new LongOpt("port", LongOpt.REQUIRED_ARGUMENT, sb, 
			      'p');
    longopts[4] = new LongOpt("timeout", LongOpt.REQUIRED_ARGUMENT, sb, 
			      'w');
    longopts[5] = new LongOpt("appletHostname", LongOpt.REQUIRED_ARGUMENT, sb, 
			      'a');
    Getopt g = new Getopt("TestClientServer", args, "n:f:t:", longopts);
    String theOption;
    type = "0";
    int c;
    while((c = g.getopt()) != -1) {
      switch(c) {
      case 'n':
	//Name of processor I am on.
	theOption = "name";
	break;
      case 'a':
	//Name of processor I am on.
	theOption = "appletHostname";
	break;
      case 'f':
	//File to read
	theOption = "file";
	break;
      case 'u':
	theOption = "builderPort";
	break;
      case 'p':
	theOption = "port";
	break;
      case 'i':
	theOption = "timeout";
	break;
      default:
      case '?':
	LocalSystem.err.println(usage);
	return;
      case 0:
	theOption = longopts[g.getLongind()].getName();
	break;
      }
      if(theOption == "name") {
	myProcName = g.getOptarg();
      } else if(theOption == "file") {
	procFile = g.getOptarg();
      } else if(theOption == "port") {
	portNumber = Integer.parseInt(g.getOptarg());
      } else if(theOption == "builderPort") {
	builderPort = Integer.parseInt(g.getOptarg());
      } else if(theOption == "timeout") {
	timeout = Long.parseLong(g.getOptarg());
      } else if(theOption == "appletHostname") {
	appletHostname = g.getOptarg();
      } else {
	LocalSystem.err.println("Bad Option: "+theOption);
	LocalSystem.err.println(usage);
	return;
      }
    }
    if(myProcName == null) {
      LocalSystem.err.println(usage);
      return;
    }

  }
}

