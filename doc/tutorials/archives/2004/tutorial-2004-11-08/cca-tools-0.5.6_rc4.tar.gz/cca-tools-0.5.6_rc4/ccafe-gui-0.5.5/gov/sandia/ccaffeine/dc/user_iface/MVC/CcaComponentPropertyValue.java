package gov.sandia.ccaffeine.dc.user_iface.MVC;

/**
 * This class holds the name and the value
 * of one component property. 
 */
public class CcaComponentPropertyValue {


    public String componentInstanceName = null;
    public String propertyName = null;
    public String propertyValue = null;


    /**
     * Parse the xml contents of a component property.
     * The parsed values are copied into the class's attributes.
     * <p>
     * The XML code will contains something like this: <br>
     * &nbsp;&lt;componentIntanceName&gt;<br>
     * &nbsp;&nbsp;&nbsp;name1 <br>
     * &nbsp;&nbsp;&nbsp;&lt;/componentInstanceName&gt; <br>
     * &nbsp;&lt;propertyName&gt;name2&lt;/propertyName&gt; <br>
     * &nbsp;&lt;propertyValue&gt;value2&lt;/propertyValue&gt; <br> 
     * @param xmlComponent The xml code of one component.
     */
    public CcaComponentPropertyValue(String xml) {


        /*
         * Extract out the contents of the following tags:
         *    component name
         *    property name
         *    property value
         */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<componentInstanceName>(.*?)</componentInstanceName>\\s*"
           +"<propertyName>(.*?)</propertyName>\\s*"
           +"<propertyValue>(.*?)</propertyValue>");

        java.util.regex.Matcher matcher = pattern.matcher(xml);


        /* copy the contents of the 3 tags to our attributes */
        if (matcher.find()) {
            this.componentInstanceName = matcher.group(1);
            this.propertyName = matcher.group(2);
            this.propertyValue = matcher.group(3);
        }
    }


    public String toString() {
        StringBuffer S = new StringBuffer();
        S.append("CcaComponentPropertyValue:");
        S.append("component="); S.append(this.componentInstanceName);
        S.append(" name="); S.append(this.propertyName);
        S.append(" value="); S.append(this.propertyValue); 
        return(S.toString());       
    }

}  