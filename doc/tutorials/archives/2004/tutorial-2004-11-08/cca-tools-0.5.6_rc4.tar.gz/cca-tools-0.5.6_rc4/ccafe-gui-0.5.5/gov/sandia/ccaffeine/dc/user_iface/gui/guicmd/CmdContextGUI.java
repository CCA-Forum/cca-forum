package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.io.*;
import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiUserListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ResultSetListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PrintEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ExceptionEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.QueryEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ResultSetEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ThreadWaitForResultSet;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ControllerSocket;



/*
 * Programmer's NOTES: <br>
 * If we get a "pulldown","instantiate", or "create" create command then: <br>
 * 1) an empty box is drawn inside the arena <br>
 * 2) the waitingForPorts is set to true <br>
 * <p>
 * If get a command that does NOT add a port to the instantiated component <br>
 * then the waitingForPorts flag will prevent that command from being <br>
 * forwarded to the parser.  (e.g. if we get a "connect" command then <br>
 * that command is not processed).  Instead, the command is pushed into <br>
 * a hashtable.  Once the we get all of the ports for the <br>
 * instantiated command, then the stored commands are released from <br>
 * the hashtable <br>
 * <p>
 * If we get a "addProvidesports" or "addProvidesPorts" command then: <br>
 * 1) the new ports are added to the model of the component <br>
 * 2) the new ports are NOT rendered on the screen <br>
 * 3) the waitingForPorts flag is still set to true <br>
 * <p>
 * If we get a "addUsesports" or "addUsesPorts" command then: <br>
 * 1) the new ports are added to the model of the component <br>
 * 2) both the provides ports and the uses ports are rendered <br>
 * 3) the waitingForPorts flag is turned off <br>
 * <p>
 *
 */

public class CmdContextGUI
       extends CmdContext {

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    //private LineNumberReader in;
    protected ControllerSocket controllerSocket = null;

    private LinkedList delayedCommands;

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    //public CmdContextGUI(InputStream in){
    //  this.in = new LineNumberReader(new InputStreamReader(in));
    //  delayedCommands = new LinkedList();
    //}
    public CmdContextGUI(ControllerSocket controllerSocket){
        this.controllerSocket = controllerSocket;
	delayedCommands = new LinkedList();
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    public void pn(String s){
	this.broadcastPrintln(s);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    public void p(String s){
	this.broadcastPrint(s);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    protected boolean displayPrompt = true;

    public boolean isPromptDisplayed() {
      return(this.displayPrompt);
    }

    public void setPromptDisplayed(boolean displayPrompt) {
      this.displayPrompt = displayPrompt;
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    public String prompt() {
        if (this.displayPrompt)
  	    return "\ngui>";
        return("");
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    public String readLine() throws IOException {
	String command;


	//if(!global.getWaitingForPorts() && delayedCommands.size() > 0) //emptying stored commands
        //if we are not busy constructing a component
        //and if we have stored any commands in our hashtable
        //then pop a command off the hashtable and
        //send that command to the parser.
        if(!this.getWaitingForPorts() && delayedCommands.size() > 0) {//emptying stored commands

          command = (String) delayedCommands.removeFirst();
          pn("gui:uncaching " + command);
        }

	else{
	    //command = in.readLine();
            command = this.controllerSocket.readLine();

	    //if(global.getWaitingForPorts() && //not ready, add to stored commands
            //We do NOT want any non "add port" commands to be processed
            //while we are in the middle of constructing a component. Those commands
            //will be pushed into a hashtable.  Once the component is fully
            //constructed, we will pop the commands out of
            //the hashtable.
            if(getWaitingForPorts() && //not ready, add to stored commands

	       !(command.startsWith("addProvidesPorts") || command.startsWith("addUsesPorts"))){
		delayedCommands.add(command);
		command = "delayed " + command;
                pn("gui:caching " + command);
	    }
	}

	//global.pn(command);
        //pn(command);

	return command;
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /** Get the state of the "waitingForPorts" flag from the GUI */
    public boolean getWaitingForPorts() throws java.io.IOException {

        //return(global.getWaitingForPorts());

        ThreadWaitForResultSet threadWaitForResultSet = null;

        try {

            /*
             It might take a long long long time
             before we a response from our query.
             Set up a thread so that we can wait.
             */
            threadWaitForResultSet = new ThreadWaitForResultSet();
            threadWaitForResultSet.setPriority(java.lang.Thread.NORM_PRIORITY + 1);
            threadWaitForResultSet.start();
            Thread.currentThread().yield(); //start the thread


            /* send the query */
            QueryEvent event = new QueryEvent
                (this,
                 null,
                 threadWaitForResultSet);
            this.broadcastWaitingForPortsEvent(event);

            /* Wait for a response */
            try {threadWaitForResultSet.join();}catch (java.lang.InterruptedException e){}

            /* Was an exception thrown? */
            ExceptionEvent exceptionEvent = threadWaitForResultSet.getExceptionEvent();
            if (exceptionEvent != null) {
                //got an error.  handle it.
                java.lang.Throwable exception = exceptionEvent.getException();
                throw new java.io.IOException(exception.getMessage());
            }

            /* Retrieve the result set */
            ResultSetEvent resultSetEvent =
                threadWaitForResultSet.getResultSetEvent();
            if (resultSetEvent == null) {
                //got an error.   handle it.
                throw new java.io.IOException("GUI did not send waitingForPorts");
            }

            /* We want the first object in the result set */
            Object resultSet[] = resultSetEvent.getResultSet();
            Object temp = resultSet[0];
            if (temp==null) {
                //got an error.   handle it.
                throw new java.io.IOException("GUI did not send waitingForPorts");
            }
            Boolean b = (Boolean)temp;
            boolean waitingForPort = ((Boolean)temp).booleanValue();

            /* return the retrieved value */
            return(waitingForPort);

        }finally {

            /* make sure the thread is garbage collected */
            threadWaitForResultSet = null;

        }
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /** Retrieve the Component Instance from the GUI */
    public String getInstance(String instanceName)
           throws java.lang.RuntimeException {

	//if(global.getArena().getComponentInstances().containsKey(instanceName))
	//    return instanceName;
	//return null;

        ThreadWaitForResultSet threadWaitForResultSet = null;

        try {

            /*
             It might take a long long long time
             before we a response from our query.
             Set up a thread so that we can wait.
             */
            threadWaitForResultSet = new ThreadWaitForResultSet();
            threadWaitForResultSet.setPriority(java.lang.Thread.NORM_PRIORITY + 1);
            threadWaitForResultSet.start();
            Thread.currentThread().yield(); //start the thread


            /* send the query */
            QueryEvent event = new QueryEvent
                (this,
                 instanceName,
                 threadWaitForResultSet);
            this.broadcastGetComponentInstanceEvent(event);

            /* Wait for a response */
            try {threadWaitForResultSet.join();}catch (java.lang.InterruptedException e){}

            /* Was an exception thrown? */
            ExceptionEvent exceptionEvent = threadWaitForResultSet.getExceptionEvent();
            if (exceptionEvent != null) {
                //got an error.  handle it.
                java.lang.Throwable exception = exceptionEvent.getException();
                throw new java.lang.RuntimeException
                    ("Error.  GUI did not send the instance name");

            }

            /* Retrieve the result set */
            ResultSetEvent resultSetEvent =
                threadWaitForResultSet.getResultSetEvent();
            if (resultSetEvent == null) {
                //got an error.  handle it.
                throw new java.lang.RuntimeException
                    ("Error.  GUI did not send the instance name");
            }

            /* We want the first object in the result set */
            /* A null object means the component instance does not exist */
            Object resultSet[] = resultSetEvent.getResultSet();
            Object temp = resultSet[0];
            if (temp==null) {
                return(null);
            }
            instanceName = (String)temp;

            /* return the retrieved value */
            return(instanceName);

        }finally {

            /* make sure the thread is garbage collected */
            threadWaitForResultSet = null;

        }
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /** Retrieve the Component Class from the GUI */
    public String getClass(String className) throws java.lang.RuntimeException {

	//if(global.getPalette().getComponentClasses().containsKey(className))
	//    return className;
	//return null;

        ThreadWaitForResultSet threadWaitForResultSet = null;

        try {

            /*
             It might take a long long long time
             before we a response from our query.
             Set up a thread so that we can wait.
             */
            threadWaitForResultSet = new ThreadWaitForResultSet();
            threadWaitForResultSet.setPriority(java.lang.Thread.NORM_PRIORITY + 1);
            threadWaitForResultSet.start();
            Thread.currentThread().yield(); //start the thread


            /* send the query */
            QueryEvent event = new QueryEvent
                (this,
                 className,
                 threadWaitForResultSet);
            this.broadcastGetComponentClassEvent(event);

            /* Wait for a response */
            try {threadWaitForResultSet.join();}catch (java.lang.InterruptedException e){}

            /* Was an exception thrown? */
            ExceptionEvent exceptionEvent = threadWaitForResultSet.getExceptionEvent();
            if (exceptionEvent != null) {
                //got an error.  handle it.
                java.lang.Throwable exception = exceptionEvent.getException();
                throw new java.lang.RuntimeException(exception.getMessage());
            }

            /* Retrieve the result set */
            ResultSetEvent resultSetEvent =
                threadWaitForResultSet.getResultSetEvent();
            if (resultSetEvent == null) {
                //got an error.  handle it.
                throw new java.lang.RuntimeException
                    ("Error.  GUI did not send the class name");
            }

            /* We want the first object in the result set */
            /* A null object means the component instance does not exist */
            Object resultSet[] = resultSetEvent.getResultSet();
            Object temp = resultSet[0];
            if (temp==null) {
                return(null);
            }
            className = (String)temp;

            /* return the retrieved value */
            return(className);

        }finally {

            /* make sure the thread is garbage collected */
            threadWaitForResultSet = null;

        }
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    java.util.Vector guiUserListeners = new Vector();

    synchronized public void addGuiUserListener(GuiUserListener listener) {
       guiUserListeners.add(listener);
    }

    synchronized public void removeGuiUserListener(GuiUserListener listener) {
        guiUserListeners.remove(listener);
    }

    protected void broadcastPrint(String message){
        PrintEvent event = new PrintEvent(this, message);
        broadcastPrintEvent(event);
    }

    protected void broadcastPrintEvent(PrintEvent event) {
       // loop through each listener and pass on the event if needed
       Vector listeners;
          synchronized (this) {
              listeners = (java.util.Vector)guiUserListeners.clone();
         }
         int numberOfListeners = listeners.size();
             for (int i=0; i<numberOfListeners; i++){
                 GuiUserListener x = (GuiUserListener)listeners.elementAt(i);
             x.print(event);
         }
    }


    protected void broadcastPrintln(String message){
        PrintEvent event = new PrintEvent(this, message);
        broadcastPrintlnEvent(event);
    }

    protected void broadcastPrintlnEvent(PrintEvent event) {
       // loop through each listener and pass on the event if needed
       Vector listeners;
          synchronized (this) {
              listeners = (Vector)guiUserListeners.clone();
         }
         int numberOfListeners = listeners.size();
             for (int i=0; i<numberOfListeners; i++){
                 GuiUserListener x = (GuiUserListener)listeners.elementAt(i);
             x.println(event);
         }
    }




    protected void broadcastGetComponentInstanceEvent(QueryEvent event) {
       // loop through each listener and pass on the event if needed
       Vector listeners;
          synchronized (this) {
              listeners = (Vector)guiUserListeners.clone();
         }
         int numberOfListeners = listeners.size();
             for (int i=0; i<numberOfListeners; i++){
                 GuiUserListener x = (GuiUserListener)listeners.elementAt(i);
             x.getComponentInstance(event);
         }
    }



    protected void broadcastGetComponentClassEvent(QueryEvent event) {
       // loop through each listener and pass on the event if needed
       Vector listeners;
          synchronized (this) {
              listeners = (Vector)guiUserListeners.clone();
         }
         int numberOfListeners = listeners.size();
             for (int i=0; i<numberOfListeners; i++){
                 GuiUserListener x = (GuiUserListener)listeners.elementAt(i);
             x.getComponentClass(event);
         }
    }


    protected void broadcastWaitingForPortsEvent(QueryEvent event) {
       // loop through each listener and pass on the event if needed
       Vector listeners;
          synchronized (this) {
              listeners = (Vector)guiUserListeners.clone();
         }
         int numberOfListeners = listeners.size();
             for (int i=0; i<numberOfListeners; i++){
                 GuiUserListener x = (GuiUserListener)listeners.elementAt(i);
             x.getWaitingForPorts(event);
         }
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/




}



