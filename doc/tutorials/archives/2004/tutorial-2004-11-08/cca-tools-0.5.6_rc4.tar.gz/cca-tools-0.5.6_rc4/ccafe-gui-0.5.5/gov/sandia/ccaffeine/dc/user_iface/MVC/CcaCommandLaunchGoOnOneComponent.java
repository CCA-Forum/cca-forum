package gov.sandia.ccaffeine.dc.user_iface.MVC;


public class CcaCommandLaunchGoOnOneComponent {

    public String componentInstanceName = "";
    public String portInstanceName = ""; 



    /**
     * Parse the xml contents of a go command.
     * The parsed values are copied into the class's attributes.
     * <p>
     * The XML code will contains something like this: <br>
     * &lt;component&gt; <br>
     * &nbsp;&lt;componentInstanceName&gt; <br>
     * &nbsp;&nbsp;name1 <br>
     * &nbsp;&lt;/componentInstanceName&gt; <br>
     * &nbsp;&lt;portInstanceName&gt; <br>
     * &nbsp;&nbsp;name2 <br>
     * &nbsp;&lt;/className&gt; <br>
     * @param xmlLaunchGoOnOneComponent The xml code of the go command
     */
    public CcaCommandLaunchGoOnOneComponent
           (String xmlLaunchGoOnOneComponent) {

        /*
         * Extract out the contents of the following tags:
         *    componentInstanceName
         *    portInstanceName
         */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<componentInstanceName>(.*?)</componentInstanceName>\\s*"
           +"<portInstanceName>(.*?)</portInstanceName>");

        java.util.regex.Matcher matcher =
                pattern.matcher(xmlLaunchGoOnOneComponent);


        /* copy the contents of the 4 tags to our attributes */
        if (matcher.find()) {
            this.componentInstanceName = matcher.group(1);
            this.portInstanceName = matcher.group(2);
        }
    }



}