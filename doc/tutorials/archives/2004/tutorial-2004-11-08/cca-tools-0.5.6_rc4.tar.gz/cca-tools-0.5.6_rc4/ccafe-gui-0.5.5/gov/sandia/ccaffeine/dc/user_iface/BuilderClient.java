package gov.sandia.ccaffeine.dc.user_iface;

import javax.swing.*;
import java.awt.*;
import gov.sandia.ccaffeine.util.*;
import gnu.getopt.*;
import java.util.*;
import java.io.*;
import java.net.*;
import java.awt.event.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.distributed.*;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ControllerSocket;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ControllerPython;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ClientSocket;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ViewSocket;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ViewPython;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.Gui;
import gov.sandia.ccaffeine.dc.user_iface.gui.GlobalData;
import gov.sandia.ccaffeine.dc.user_iface.AccessServer;
import gov.sandia.ccaffeine.dc.user_iface.MVC.PythonStub;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CanNotCommunicateWithCcaServerException;

import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;
import java.awt.Font; 


/** BuilderClient is a main program for building the GUI and
    connecting remotely to a ccaffeine framework or a MuxingProcess
    that is a ccaffeine framework proxy.*/


/*
 * Programmer's Notes:
 * scenario:  GUI wants to populate the palette
 *    GUI formulates a query that asks for all the components in the palette
 *    GUI sends the query to the ViewSocket
 *        NOTE:  The ViewSocket is a GuiListener
 *    ViewSocket forwards the query to the cca server
 *    cca server sends the components to the ControllerSocket
 *    ControllerSocket sends the data to CmdParse
 *    CmdParse invokes one of the CmdActionXXX classes
 *    CmdActionXXX invokes the CmdAction class
 *    CmdAction sends an event to the GUI
 *        NOTE:  The GUI is a ControllerListener
 * scenario:  GUI wants to populate the palette
 *    GUI formulates a query that asks for all the components in the palette
 *    GUI sends the query to the ViewPython 
 *        NOTE: The ViewPython is a GuiListener
 *    ViewPython sends a query to the PythonStub
 *    The PythonStub forwards the query to the server skeleton
 *    The server skeleton forwards the query to the cca server
 *    The cca server sends the components to the server skeleton
 *    The server skeleton sends the components to the PythonStub
 *    The PythonStub sends the components to the ControllerPython
 *    The ControllerPython sends the events to the GUI
 *        NOTE:  The GUI is a ControllerListener
 */

class SocketInfo extends JDialog{
  public int port;
  public String host;
  public boolean quit;
  public boolean done = false;
  JTextField hostTF;
  JTextField portTF;
  
  SocketInfo(Args arg) {
    super();
    host = arg.hostName;
    port = arg.builderPort;
    quit = false;
    JPanel jp = new JPanel(new GridLayout(3,2));
    jp.add(new JLabel("Host:",JLabel.RIGHT));
    hostTF = new JTextField(host, 10);
    jp.add(hostTF);
    jp.add(new JLabel("Port:",JLabel.RIGHT));
    portTF = new JTextField(Integer.toString(port), 10);
    jp.add(portTF);
    JButton jc = new JButton("Connect");
    jc.addActionListener( 
			 new ActionListener()
			 {
			   public void actionPerformed(ActionEvent event) {
			     port = Integer.parseInt(portTF.getText());
			     host = hostTF.getText();
			     done = true;
			     setVisible(false);
			   }
			 }
			 );
    jp.add(jc);
    JButton jq = new JButton("Quit");
    jq.addActionListener(
			 new ActionListener()  
			 {
			   public void actionPerformed(ActionEvent event) {
			     quit = true;
			     done = true;
			     setVisible(false);
			   }
			 }
			 );
    jp.add(jq);
    setContentPane(jp);
  }
}


public class BuilderClient {
	
	
  public static GlobalData globalData = null;	
	

  public static final void main(String[] args) throws Exception {
    Args arg = new Args();
    arg.parseArgs(args);
    Socket s = null;



    /**
     * If the font size multiplier is NOT 1.0
     * then, for every component, multiply the component's default
     * font size with the multiplier.  For example, to double
     * the font size of every compnent, set scaleFont to 2.
     */
    if (arg.scaleFont !=1.0){
        scaleFontSizeOfEveryComponent(arg.scaleFont );
    } 


    if(arg.mode.compareTo("benMode") != 0) {

      SocketInfo si = new SocketInfo(arg);
      si.pack();
      ClientSocket clientSocket = new ClientSocket();
      int port = arg.builderPort;
      String host = arg.hostName;
      boolean successful = false;
      while(! successful ) {
	try {

	  clientSocket.open(host, port);
	  successful = true;

	} catch(Exception e) {
	  LocalSystem.err.println("Exception:"+e);
	  clientSocket.close();
	}
	if(! successful) {
	  clientSocket.close();
	  si.setVisible(true);
	  while(si.isVisible());
	  host = si.host;
	  port = si.port;
	  if(si.quit) System.exit(0);
	}
      }
      LocalSystem.err.println("About to create the Builder");
      runGUI(clientSocket, arg);
    } else {
      //we're in benMode, it is a real pain, we create two threads to
      //handle the IO.
      final InputStream in = s.getInputStream();
      final OutputStream out = s.getOutputStream();
      Runnable toRemote = new Runnable() {
	  public void run() {
	    try {
	      int len;
	      byte[] buf = new byte[1024];
	      while((len = System.in.read(buf)) != -1) {
		out.write(buf, 0, len);
	      }
	      out.close();
	    } catch(Exception e) {
	      LocalSystem.err.println("Exception:"+e);
	      e.printStackTrace(LocalSystem.err);
	      LocalSystem.exit(-1);
	    }
	  }
	};
      Runnable fromRemote = new Runnable() {
	  public void run() {
	    try {
	      int len;
	      byte[] buf = new byte[1024];
	      while((len = in.read(buf)) != -1) {
		System.out.write(buf, 0, len);
	      }
	      in.close();
	    } catch(Exception e) {
	      LocalSystem.err.println("Exception:"+e);
	      e.printStackTrace(LocalSystem.err);
	      LocalSystem.exit(-1);
	    }
	  }
	};
      new Thread(fromRemote).start();
      Thread joinMe = new Thread(toRemote);
      joinMe.start();
      joinMe.join();
    }
  }

  public static void runGUI(ClientSocket clientSocket, Args args) {

    new Frame_O_Matic(clientSocket, args).show();
  }


  /**
   * Scale the font size of every component.
   * For example, to double the font size of e
   * @param fontSizeMultiplier The new font size is
   * the default font size multiplied by this scaling factor.
   */
  protected static void scaleFontSizeOfEveryComponent(double fontSizeMultiplier) {
    java.util.Enumeration keys = UIManager.getDefaults().keys();
    while (keys.hasMoreElements()) {
      Object key = keys.nextElement();
      Object value = UIManager.get (key);
      if (value instanceof javax.swing.plaf.FontUIResource) {
        FontUIResource fontUIResource = (FontUIResource)value;
        String name = fontUIResource.getName();
        int style = fontUIResource.getStyle();
        int size = fontUIResource.getSize();
        size = (int)Math.round((double)size * fontSizeMultiplier);
        //Font font = fontUIResource.deriveFont(size);
        //fontUIResource = new FontUIResource(font);           
        fontUIResource = new FontUIResource(name, style, size);
        UIManager.put (key, fontUIResource);
      }//if
    }//while
  }//method      
  


}//class

class Frame_O_Matic extends JFrame {
  public Frame_O_Matic(ClientSocket clientSocket, Args args) {
    super();
    setSize(900,700);
    setTitle("Common Component Architecture");
    setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

    //final Builder builder = new Builder(in, out, (java.awt.Container)this);
    final Builder builder = new Builder((java.awt.Container)this);

    
    /* if we are talking to a python server, then we need the python's stub */
    PythonStub pythonStub = null;    
    
    
    /* are we connecting to a python server? */
    if (args.serverIsPython) {
        pythonStub = new PythonStub();
		try {
			pythonStub.openSessionWithCcaServer(clientSocket);
		} catch (CanNotCommunicateWithCcaServerException e) {
		      LocalSystem.err.println("Exception attempting to connect to host: "+
				      args.hostName+" port: "+args.builderPort);
	          e.printStackTrace(LocalSystem.out);
	          LocalSystem.exit(-1);
	          return;
		}
    }  




    if (args.serverIsPython) {
        ViewPython viewPython = new ViewPython(pythonStub);
        builder.addGuiListener(viewPython);
    } else {
        ViewSocket viewSocket = new ViewSocket(clientSocket);
        builder.addGuiListener(viewSocket);
    }

    builder.doStart();
    BuilderClient.globalData = builder.getGlobal();
    


    Gui gui = builder.getGui();




    if (args.serverIsPython) {
        ControllerPython controllerPython = new ControllerPython(pythonStub);
        pythonStub.addPythonControllerListener(controllerPython);
        controllerPython.addAccessGuiListener(gui);
        controllerPython.addControllerListener(gui);
  } else {
       ControllerSocket controllerSocket = new ControllerSocket(clientSocket);
       controllerSocket.addGuiUserListener(gui);
       controllerSocket.addControllerListener(gui);
       controllerSocket.parse();
  }



    final Args xargs = args;
    addWindowListener(new WindowAdapter() {
	public void windowClosing(WindowEvent e) {System.exit(0);}
	public void windowOpened(WindowEvent e) {
	  if(xargs.buildFile != null) {
	    builder.loadFile(xargs.buildFile);
	  }
	}
      }
		      ); // addWindowListener
    JDesktopPane desktop = new JDesktopPane();
    desktop.add(builder);
    getContentPane().add(desktop);
  }
}
