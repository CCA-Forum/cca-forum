package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * This event can be used to notify components
 * that an entity wants to know what components
 * are in the arena and what connections exist
 * between the component.  The arena is the workspace
 * canvas; the end-user can drag components
 * from the palette to the arena.  The end-user
 * can connect components by drawing lines
 * between the components.
 * A view might respond
 * by rendering cca components in the main
 * workspace (the arena) and by rendering lines between
 * components that are connected togeter.  The
 * end-user can drag components to a new location,
 * remove components, draw lines between
 * components, view or edit the properties of
 * components, etc.
 */

public class DisplayStateEvent extends EventObject {

  /**
   * Create a DisplayArenaEvent.
   * This event can be used to notify components
   * that an entity wants to know what components
   * are in the arena and what connections exist
   * between the components.  The arena is the workspace
   * canvas; the end-user can drag components
   * from the palette to the arena.  The end-user
   * can connect components by drawing lines
   * between the components.
   * A view might respond
   * by rendering cca components in the main
   * workspace (the arena) and by rendering lines between
   * components that are connected togeter.  The
   * end-user can drag components to a new location,
   * remove components, draw lines between
   * components, view or edit the properties of
   * components, etc.
   * @param source The entity that created this event.
   */
    public DisplayStateEvent(Object source) {
        super(source);
    }

}