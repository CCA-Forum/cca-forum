package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * This event can be used to notify components
 * that an entity wants to know what connections
 * are in the arena.  The arena is the workspace
 * canvas; the end-user can drag components
 * from the palette to the arena.  The end-user
 * can connect components by drawing lines
 * between the components.
 * A view might respond
 * drawing a line between two components
 * that are rendered inside the main
 * workspace (the arena).
 */

public class DisplayChainEvent extends EventObject {

  /**
   * Create a DisplayChainEvent.
   * This event can be used to notify components
   * that an entity wants to know what connections
   * are in the arena.  The arena is the workspace
   * canvas; the end-user can drag components
   * from the palette to the arena.  The end-user
   * can connect components by drawing lines
   * between the components.
   * A view might respond
   * drawing a line between two components
   * that are rendered inside the main
   * workspace (the arena).
   * @param source The entity that created this event.
   */
    public DisplayChainEvent(Object source) {
        super(source);
    }

}