package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUI;
import gov.sandia.ccaffeine.util.LocalSystem;

/**
 * CmdActionGUISetProperty.java
 */

public class CmdActionGUISetProperty
       extends CmdActionGUI
       implements CmdAction{

  private static final String[] namelist = {"setProperty", "property", "SetComponentProperty", "ComponentProperty"};


  public CmdActionGUISetProperty(){
  }

  /** setProperty <component instance> <key string> <value string> */
  public String argtype(){
    return "ISS";
  }

  public String[] names(){
    return namelist;
  }

  public String help(){
    return "Sets a key value pair onto the gui representation of "+
      "a component";
  }

  public void doIt(CmdContext cc, Vector args) {

    CmdContextGUI ccg = (CmdContextGUI)cc;


  /**
   * The name of the component that contains the property
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "StartComponent0"
   */
    String componentInstanceName = (String)args.get(0);

    /*
     * The name of the property.
     */
    String propertyName = (String)args.get(1);

    /*
     * The value of the property.
     */
    String propertyValue = (String)args.get(2);

    //LocalSystem.err.println("CmdActionGUISetProperty::doIt: "+
    //		    "name = "+name+" key = "+key+" value = "+value);

    //Hashtable cis = global.getArena().getComponentInstances();
    //ComponentInstance ci = (ComponentInstance)cis.get(name);
    //if(ci != null) {
    //  ci.setProperty(key, value);
    //}

    this.broadcastSetComponentProperty
        (componentInstanceName,
         propertyName,
         propertyValue);


  }
}
