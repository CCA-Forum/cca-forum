package gov.sandia.ccaffeine.dc.distributed;

import gov.sandia.ccaffeine.util.*;
import java.net.*;
import java.io.*;
import java.util.*;

public class ClientServerSocket {
  private InputStream[] in;
  private OutputStream[] out;
  private ProcessorInfo[] machines;
    private InetAddress[] processorAddrs;
  private int myProcNumber;
  private int serverProcNumber; // The processor number for the Server
  private int serverPort; // Port on which the server will be listening.
  private int buffering;

  public ClientServerSocket(String processorName, String procFile, int port)
  throws Exception {
    serverPort = port;
    File f = new File(procFile);
    Properties p = new Properties();
    if(f.canRead()) {
      InputStream in = new FileInputStream(f);
      p.load(in);
      in.close();
    } else {
      throw new RuntimeException("File: "+f.getAbsolutePath()+
				 " cannot be read");
    }
    int myProcIndex = -1;
    Vector tmp = new Vector();
    boolean isServer;
    for(Enumeration e = p.propertyNames();e.hasMoreElements();) {
      String procName = (String)e.nextElement();
      if(procName.compareTo(processorName) == 0) myProcIndex = tmp.size();
      String type = p.getProperty(procName);
      if(type.compareTo("client") == 0) {
	isServer = false;
      } else if(type.compareTo("server") == 0) {
	isServer = true;
      } else {
	throw new RuntimeException("Got a different type other than "+
				   "\"client\" or \"server\" in file"+
				   "The type is: "+type);
      }
      tmp.addElement(new ProcessorInfo(procName, isServer));
    }
    machines = new ProcessorInfo[tmp.size()];
    tmp.copyInto(machines);
    if(myProcIndex == -1) {
      throw new RuntimeException("Apparently I do not appear in the "+
				 "processor file:"+procFile);
    }
    myProcNumber = myProcIndex;
    for(int i = 0;i < machines.length;i++) {
      if(machines[i].isServer()) serverProcNumber = i;
    }
    if(isServer()) {
      in = new InputStream[machines.length - 1];
      out = new OutputStream[machines.length - 1];
      processorAddrs = new InetAddress[machines.length - 1];
    } else {
      in = new InputStream[1];
      out = new OutputStream[1];
      processorAddrs = new InetAddress[1];
    }
  }

  public ClientServerSocket(int  myProcNumber, int serverPort,
			    ProcessorInfo[] machines) {
    this.serverPort = serverPort;
    this.machines = machines;
    this.myProcNumber = myProcNumber;
    for(int i = 0;i < machines.length;i++) {
      if(machines[i].isServer()) serverProcNumber = i;
    }
    if(isServer()) {
      in = new InputStream[machines.length - 1];
      out = new OutputStream[machines.length - 1];
      processorAddrs = new InetAddress[machines.length - 1];
    } else {
      in = new InputStream[1];
      out = new OutputStream[1];
      processorAddrs = new InetAddress[1];
    }
  }
  public void acceptConnections() throws Exception {
    ServerSocket t;
    try {
    t = new ServerSocket(serverPort, 100);
    } catch(Exception e) {
      LocalSystem.err.println("Exception: "+e);
      LocalSystem.err.println("attempted to listen on port:"+serverPort);
      e.printStackTrace(LocalSystem.err);
      return;
    }
    for(int i = 0;i < machines.length - 1;i++) {
      Socket s = t.accept();
      //      InetAddress addr = s.getLocalAddress();
      InetAddress addr = s.getInetAddress();
      processorAddrs[i] = addr;
      //int port = s.getLocalPort();
      int port = s.getPort();
      LocalSystem.out.println("connected to: "+addr.getHostName()+"(port = "+
			      port+")");
      in[i] = s.getInputStream();
      out[i] = s.getOutputStream();
    }
  }
  public void connectToServer() throws Exception {
    ProcessorInfo serv = machines[serverProcNumber];
    Socket s = new Socket(serv.getName(), serverPort);
    in[0] = s.getInputStream();
    out[0] = s.getOutputStream();
    processorAddrs[0] = s.getInetAddress();
  }
  public boolean isServer() {
    return myProcNumber == serverProcNumber;
  }
  public void  makeConnection() {
    if(isServer()) {
      try {
	acceptConnections();
      } catch(Exception e) {
	LocalSystem.printException(e);
	throw new RuntimeException("ClientServerSocket: "+
				   "Socket accept failed.");
      }
    } else {
      try {
	connectToServer();
      } catch(Exception e) {
	LocalSystem.printException(e);
	throw new RuntimeException("ClientServerSocket: "+
				   "SocketConnection could not be made");
      }
    }
  }
  public InputStream[] getIn() {return in;}
  public OutputStream[] getOut() {return out;}
    public InetAddress[] getProcessorAddresses() {return processorAddrs;}
};


