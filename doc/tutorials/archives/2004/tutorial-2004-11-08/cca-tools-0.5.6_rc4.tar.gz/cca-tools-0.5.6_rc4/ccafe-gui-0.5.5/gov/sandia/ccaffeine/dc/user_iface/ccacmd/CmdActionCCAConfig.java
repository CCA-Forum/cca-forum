package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;

public class CmdActionCCAConfig
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCAConfig() {
  }

  public String argtype() {
    return "ISSs*";
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
    return "query or set the configuration parameters of a component port";
  }


  private static final String[] namelist = {"configure","parameters"};


  public void doIt(CmdContext cc, Vector args) {



      String componentInstanceName = null;
      String portInstanceName = null;
      String dataFieldName = null;
      String dataFieldValue = null;

      int numberOfArguments = args.size();

      if (numberOfArguments>0)
          componentInstanceName = (String)args.get(0);

      if (numberOfArguments>1)
          portInstanceName = (String)args.get(1);

      if (numberOfArguments>2)
          dataFieldName = (String)args.get(2);

      if (numberOfArguments>3) {
          StringBuffer sb = new StringBuffer();
          for (int i=3; i < args.size(); i++) {
              if (i >= 4) { sb.append(" "); }//reduce all whitespace to singlespace
             sb.append((String)args.get(i));
          }
          dataFieldValue = sb.toString();
      }

      this.broadcastPortParam
          (numberOfArguments,
           componentInstanceName,
           portInstanceName,
           dataFieldName,
           dataFieldValue);
  }

}
