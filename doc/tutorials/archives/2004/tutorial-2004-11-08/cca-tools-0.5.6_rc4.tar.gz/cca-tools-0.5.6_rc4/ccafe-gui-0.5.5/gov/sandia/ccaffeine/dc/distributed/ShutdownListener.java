package gov.sandia.ccaffeine.dc.distributed;

import java.util.EventListener;

/**
ShutdownListeners can listen for shutdown events.
 */

public interface ShutdownListener extends EventListener {
    public void serverShuttingDown(ShutdownEvent event);
}
