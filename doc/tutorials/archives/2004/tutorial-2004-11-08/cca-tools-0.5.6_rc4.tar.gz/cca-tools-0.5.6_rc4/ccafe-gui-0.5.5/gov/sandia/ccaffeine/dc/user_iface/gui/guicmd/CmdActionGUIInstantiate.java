package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;

/**
 * CmdActionGUIInstantiate.java
 *
 * The end-user drags a component from the palette to the arena.
 * The cca server uses the component's class to instantiate a
 * brand new cca component object.  The cca server sends the
 * new component to this client.  This client responds by
 * rendering the new component inside the arena.
 */

public class CmdActionGUIInstantiate
       extends CmdActionGUI
       implements CmdAction{

    public CmdActionGUIInstantiate(){
    }

    public String argtype(){
	return "CS";
    }

    public String[] names(){
	return namelist;
    }

    public String help(){
	return "creates an arena instance from a class.";
    }

    private static final String[] namelist = {"pulldown","instantiate","create"};
    public void doIt(CmdContext cc, Vector args) {

	CmdContextGUI ccg = (CmdContextGUI)cc;

       /*
        * The name of the class that was used to
        * instantiate a new cca component.
        * The name is actually the name of the component's
        * java class.
        * EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
        */
	String    className = (String)args.get(0);

       /*
        * The name of the newly instantiated
        * cca component object.  The instance
        * name is usually the name of the component's
        * java class (without the package name)
        * concatenated with an index number.
        * EXAMPLE:  "StarterComponent0"
       */
	String instanceName = (String)args.get(1);

	//global.setWaitingForPorts(true);
	//global.getArena().addComponentInstance
	//    (new ComponentInstance
	//	(className,
	//	 instanceName,
	//	 global.getDropLocation(),
	//	 global));
        this.broadcastInstantiate(className, instanceName);
    }

}
