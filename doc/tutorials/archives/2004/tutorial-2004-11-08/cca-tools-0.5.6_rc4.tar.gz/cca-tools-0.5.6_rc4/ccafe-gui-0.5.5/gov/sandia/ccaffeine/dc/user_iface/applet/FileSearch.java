package gov.sandia.ccaffeine.dc.user_iface.applet;

import javax.swing.*;
import java.util.*;
import java.io.*;
import javax.swing.tree.*;
import java.awt.*;

/**
Search a folder hierarchy for filenames that end with
the desired extensions.  For example, if the
desired filename extensions are {"txt", "text", "htm", "html"}
then we will search for files whose names end with .txt, .text,
.htm, or .html.
<p>
EXAMPLE: <br>
FileSearch x = new FileSearch(); <br>
x.setFolderName("c:/myData"); <br>
x.setExtension(new String[] {"txt","text","htm","html"}); <br>
x.doStart(); <br>
String foundFilenames[] = x.getFoundFilenames();
*/

public class FileSearch
       extends java.lang.Object
       implements Serializable, Cloneable {

    protected boolean debug = true;

    /* Which folder are we going to search ? */
    protected String folderName = "";

    /* Which filename extensions are we searching for? */
    protected String filenameExtensions[] = new String[0];

    /* This array contains the name of every file we found */
    protected String[] foundFilenames = new String[0];











    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Retrieve an array that contains the names of
     * all the files we are searching for.
     * @return The names of all the files
     * we are searching for.
     */
    public String[] getFoundFilenames() {
        return(this.foundFilenames);
    }


    /**
     * Set the names of all the files that
     * we have found.
     * @param filenames The names of all the
     * files that we have found.
     */
    public void setFoundFilenames(String filenames[]) {
        this.foundFilenames = filenames;
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    public Object clone() {
        FileSearch x = new FileSearch();
        x.folderName = new String(folderName);
        x.filenameExtensions =
            (String[])this.getFilenameExtensions().clone();
        x.foundFilenames = (String[])this.foundFilenames;
        return(x);
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Search for files whose names end with these extensions.
     * For example, if the filnemameExtensions contains
     * {"txt", "text", "html", htm"} then we are searching
     * for filenames that end with either ".txt", ".text",
     * ".html", or ".htm".
     * @return The filename extensions that are we searching for.
     */
    synchronized public String[] getFilenameExtensions() {
        if (this.filenameExtensions==null) return(null);
        return((String[])this.filenameExtensions.clone());
    }


    /**
     * Search for files whose names end with one of these extensions.
     * For example, if one of filnemameExtensions contains "txt"
     * then we are searching for filenames that end with .txt.
     * NOTE:  There may or may not be other filenames that
     * we are searching for.
     * If getFilenameExtension(int index) returns the empty
     * string then we are seaching for all filenames
     * that are in the target folder.
     * @param index Which filename extension do we want
     * to return.  The first filename extension has an index
     * value of 0.  The 2nd filename extension has an index
     * value of 1.  etc.
     * @return The filename extensions that are we searching for.
     */
    synchronized public String getFilenameExtension(int index) {
        if (this.filenameExtensions==null) return(null);
        if (index<0) return("");
        if (index >= this.filenameExtensions.length) return("");
        return((String)this.filenameExtensions[index]);
    }



        /**
         * Search for files whose names end with these extensions.
         * For example, if the filnemameExtensions contains
         * {"txt", "text", "html", htm"} then we are searching
         * for filenames that end with either ".txt", ".text",
         * ".html", or ".htm".
         * @param filenameExtensions
         * The filename extensions that are we searching for.
     */
    synchronized public void setFilenameExtensions(String filenameExtensions[]) {
         if (filenameExtensions==null) this.filenameExtensions=null;
         this.filenameExtensions = (String[])filenameExtensions.clone();
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Retrieve the name of the folder that we are going to search.
     * @return The name of the folder that will be searched.
     */
    synchronized public String getFolderName() {
        if (this.folderName==null) return(null);
        return(new String(folderName));
    }


    /**
     * Set the name of the folder we are going to search.
     * @param name The name of the folder we are going to search.
     */
    synchronized public void setFolderName(String folderName) {
        if (folderName==null) this.folderName=null;
        this.folderName = new String(folderName);
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Search the target folder for filenames
     * that end with one of the target extensions.
     */
    public void doStart() {

        synchronized(this) {
            String folderName = this.getFolderName();
            String filenameExtensions[] = this.getFilenameExtensions();
        }

        String foundFilenames[] = this.searchFolderForFilenamesWithExtensions
                            (folderName, filenameExtensions);

        synchronized(this) {
            this.setFoundFilenames(foundFilenames);
        }


    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Search the input folder (and all subfolders) for
     * filenames with the correct extensions.
     * @param folderName The name of the folder
     * we are going to search
     * @param extensions A list of all the extensions
     * we are searching for.  If a filename ends with
     * one of these extensions then the name of that
     * file will be included in the Vector of filenames
     * that is returned.
     * @return An array that contains the names of all the
     * files that we have found.
     */
    protected String[] searchFolderForFilenamesWithExtensions
              (String folderName,
               String extensions[]) {

        /* search this folder and all subfolders */
        Vector v = searchFolderForFilenamesWithExtensions
                   (folderName, extensions, new Vector());

        /* how many files did we find? */
        int numberOfFiles = v.size();
        if (numberOfFiles==0) return(new String[0]);

        /* allocate some memory to hold our array */
        String foundFilenames[] = new String[numberOfFiles];

        /* copy our vector into our array */
        v.copyInto(foundFilenames);

        /* return the array of found filenames */
        return(foundFilenames);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Search the input folder (and all subfolders) for
     * filenames with the correct extensions.
     * @param folderName The name of the folder
     * we are going to search
     * @param extensions A list of all the extensions
     * we are searching for.  If a filename ends with
     * one of these extensions then the name of that
     * file will be included in the Vector of filenames
     * that is returned.
     * @param namesOfFoundFiles A vector that contains the
     * names of all the files we have already found.  If we
     * find any more files with the correct filename extension,
     * then we will add the name of that file to this vector.
     * @return A vector that contains the names of all the
     * files that we have found.
     */
    protected Vector searchFolderForFilenamesWithExtensions
              (String folderName,
               String extensions[],
               Vector namesOfFoundFiles) {


        /* error check */
        if (folderName==null) folderName = ".";
        if (extensions==null) extensions = new String[0];
        if (namesOfFoundFiles==null)
            namesOfFoundFiles = new Vector();

        /* does the folder exist? */
        File file = new File(folderName);
        if (!(file.exists())) return(namesOfFoundFiles);

        /* get every entry that is in the folder */
        String entries[] = file.list();
        int numberOfEntries = entries.length;

        /*
        The array entries[] contains the names
        of files and folders.
        We need to do two passes.
        In the first pass, we will search through
        all of the filenames.  In the second pass,
        we will search through all of the folders.
        */

        /*
        First pass.
        Search through all of the files that are in this folder.
        If the name of a file ends with the correct extension
        then add the name of that file to our vector.
        */
        for (int i=0; i<numberOfEntries; i++) {

            /* if entry is not a file then reloop */
            file = new File(folderName,entries[i]);
            if (!(file.isFile())) continue;

            /*
            entry is a file
            if the filename does not end with the
            correct extension then reloop
            */
            if (!(filenameEndsWithOneOfTheseExtensions
                    (entries[i],extensions))) continue;

            /*
            We found a filename with the correct extension.
            Add the filename to our vector
            */
            namesOfFoundFiles.add(file.getAbsolutePath());
        }

        /*
        Second pass.
        Search through all of the folders that are in this
        folder.
        */
        for (int i=0; i<numberOfEntries; i++) {

            /* Don't mess with "." and ".." */
            if (entries[i].equals(".")) continue;
            if (entries[i].equals("..")) continue;

            /* if the entry is not a folder then reloop */
            file = new File(folderName, entries[i]);
            if (!(file.isDirectory())) continue;

            /*
            search this folder for filenames with
            the correct extensions
            */
            entries[i] = file.getAbsolutePath();
            namesOfFoundFiles =
                this.searchFolderForFilenamesWithExtensions
                (entries[i], extensions, namesOfFoundFiles);
        }

        /*
        namesOfFoundFiles is a vector that contains
        the names of all the files we found
        */
        return(namesOfFoundFiles);

    }//method







    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Construct a new FileSearch object.
     * You should invoke setFilename(String),
     * setExtensions(String[]), doStart(),
     * and getNode() on your new FileSearch
     * object.
     */
    public FileSearch() {
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Return true if the filename ends with one
     * of the extensions in the extensions[] array.
     * If the extensions[] array is empty then
     * return true.
     * @param filename
     * @param extensions
     * @return True if the filename ends with one
     * of the extensions in the extensions[] array.
     */
    protected boolean filenameEndsWithOneOfTheseExtensions
              (String filename, String[] extensions) {

      /* error check */
      if (filename==null) return(true);
      if (extensions==null) return(true);
      filename = filename.trim();
      if (filename.equals("")) return(true);

      /* how many extensions do we have to check? */
      int numberOfExtensions = extensions.length;
      if (numberOfExtensions==0) return(true);

      /* combine all of the extensions into one string */
      StringBuffer S = new StringBuffer();
      for (int i=0; i<numberOfExtensions; i++) {
          S.append(extensions[i]);
          S.append("\t");
      }

      /* extract the extension from the filename */
      String extension = "";
      int index = filename.lastIndexOf(".");
      if (index==-1) return(false);
      if (index!=-1)
          if (index!=filename.length()-1)
              extension = filename.substring(index+1);

      /* does the filename end with one of the extensions? */
      index = S.toString().indexOf(extension + "\t");
      boolean returnValue = index!=-1;
      return(returnValue);
    }


    /**
     * Generate some useful info on this object.
     * @return Some useful info on this object.
     */
    public String toString() {

        String folderName = null;
        String filenameExtensions[] = null;
        String foundFilenames[] = null;
        synchronized(this) {
           folderName = this.getFolderName();
           filenameExtensions = this.getFilenameExtensions();
           foundFilenames = this.getFoundFilenames();
        }
        StringBuffer S = new StringBuffer();
        S.append("FileSearch: ");

        S.append("folderName=");
        S.append(folderName);

        S.append(" filenameExtensions=");
        if (filenameExtensions==null)
            S.append("null ");
        else {
            int numberOfExtensions = filenameExtensions.length;
            for (int i=0; i<numberOfExtensions; i++) {
                S.append(filenameExtensions[i]);
                S.append(" ");
            }//for
        }//else


        S.append("filenames=");
        if (foundFilenames==null)
            S.append("null ");
        else {
            int numberOfFilenames = foundFilenames.length;
            for (int i=0; i<numberOfFilenames; i++) {
                S.append(foundFilenames[i]);
                S.append(" ");
            }//for
        }//else


        return(S.toString());

    }








    public static void main(String args[]) {
        FileSearch x = new FileSearch();
        x.setFolderName("c:/Edward");
        x.setFilenameExtensions(new String[] {"txt"});
        x.doStart();
        String foundFilenames[] = x.getFoundFilenames();
        int numberOfFoundFiles = foundFilenames.length;
        for (int i=0; i<numberOfFoundFiles; i++)
            System.out.println(foundFilenames[i]);
        System.out.println("----------------------------------");
        System.out.println(x.toString());
    }

}
