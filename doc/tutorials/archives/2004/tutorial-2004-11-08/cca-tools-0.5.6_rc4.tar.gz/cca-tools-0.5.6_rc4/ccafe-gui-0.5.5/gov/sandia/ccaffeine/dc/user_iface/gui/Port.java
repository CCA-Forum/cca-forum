package gov.sandia.ccaffeine.dc.user_iface.gui;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Hashtable;

/**
 * Represents either an inport or an outport on an
 * <code>ArenaComponent</code>. Contains data fields that
 * represent this <code>Port</code>'s: instance name, class
 * name, type(inport/outport), and position within the
 * parent <code>ArenaComponent</code>.
 */
public class Port extends JButton implements MouseListener {

  Hashtable hashtablePortProperties = null;


  /**
   * Creates a new <code>Port</code> instance. The new <code>
   * Port</code> has the specified ID (within <code>Port</code>s
   * of the same type[in/out] in this <code>ArenaComponent</code>.
   *
   * @param type  inport/outport
   * @param iname  instance name of this <code>Port</code>
   * @param cname  class name of this port
   */
  public Port(int initialIndex, int type,
              String iname, String cname,
              ComponentInstance parent, GlobalData global){
    super();
    INITIALINDEX = initialIndex;
    SIDE   = type; // inport or outport only, baa.
    TYPE   = type; // initially inport or outport, but mods by class/side
    NAME   = iname;
    CLASS  = cname;
    PARENT = parent;
    arena  = global.getArena();
    this.global = global;

    this.hashtablePortProperties = new Hashtable();

    if(TYPE == INPORT) {
      hue = bluegreen;
    } else {
      hue = yellow; //outport
    }
    if ( (
           CLASS.equals("ccafeopq::ParameterPort") ||
           CLASS.equals("::ccafeopq::ParameterPort") ||
           CLASS.equals("classic::gov::cca::ParameterPort") ||
           CLASS.equals("::classic::gov::cca::ParameterPort") ||
           CLASS.equals("ccaffeine::ParameterPort") ||
           CLASS.equals("::ccaffeine::ParameterPort") ||
           CLASS.equals("ParameterPort")
         )
         && SIDE == INPORT) {
      hue = blue;
      setForeground(Color.white);
      TYPE = PARAMPORT;
    }
    if(CLASS.endsWith("GoPort") && SIDE == INPORT) {
      hue = green;
      TYPE = GOPORT;
    }
    typeHue = hue;
    setBackground(dark(hue));

    /* We want the font size that is in the style sheet       */
    /* We want the font name and & style that is in plainFont */
    String name = plainFont.getName();
    int style = plainFont.getStyle();
    int size = this.getFont().getSize();
    plainFont = new Font(name, style, size);
    setFont(plainFont);

    setText(NAME);
    setToolTipText(NAME + " (" + CLASS + ")");
    ports.addElement(this);
    addMouseListener(new PortWatcher(this));
    addMouseListener(this);
  }



  /**
   * Add or change a port property.
   * @param key String The name of the port property
   * @param property String The value of the port property
   */
  public void putPortProperty(String name, String value) {

    this.hashtablePortProperties.put(name, value);

    /* if the name is "gov.ccafe.visible"      */
    /* then change the visibility of this port */
    if (name.equals("gov.ccafe.visible")) {
      this.setVisible(toBoolean(value));
      this.invalidate();
      this.validate();
    }

  }


  /**
   * Convert a string value to a boolean value.
   * The following string values are converted to a boolean false:
   * "0"  "f"  "F"  "false"  "False"  "FALSE"
   * @param value String The value to be converted to a boolean value.
   * @return boolean The string value converted to a boolean value.
   */
  protected boolean toBoolean(String value) {
      value = value.toLowerCase();
      if (value.equals("0")) return(false);
      if (value.equals("f")) return(false);
      if (value.equals("F")) return(false);
      if (value.equals("false")) return(false);
      return(true);
  }


  /**
   * Add or change a port property.
   * @param key String The name of the port property
   * @param property String The value of the port property
   */
  public void setPortProperty(String name, String value) {
    this.putClientProperty(name, value);
  }



  /**
   * Given the name of a port property,
   * return the property's value.
   * @param name String The name of the port property.
   * @return String The port propery's value.
   */
  public String getPortProperty(String name) {
       return((String)this.hashtablePortProperties.get(name));
  }


  /**
   * Remove or delete a port property,
   * @param name String The name of the port property.
   */
  public void removePortProperty(String name) {
    this.hashtablePortProperties.remove(name);
  }



  /**
   * Return all of the properties that belong to this port.
   * @return Hashtable All of the properties that belong
   * to this port.
   */
  public Hashtable getAllPortProperties() {
    return(this.hashtablePortProperties);
  }







  /**
   * Returns the instance name of this <code>Port</code>.
   * This is used in making a <code>Connection</code> and for
   * tool-tips.
   */
  public String getInstanceName(){
    return NAME;
  }
  public String getComponentInstanceName() {
    return PARENT.getInstanceName();
  }
  /**
   * Returns the class name of this <code>Port</code>.
   * This is used in making a <code>Connection</code> and for
   * tool-tips.
   */
  public String getClassName(){
    return CLASS;
  }
  /**
   * Returns this <code>Port</code>'s side.
   */
  public int getSide(){
    return SIDE;
  }
  /**
   * Returns this <code>Port</code>'s type.
   */
  public int getType(){
    return TYPE;
  }
  /**
   * Returns this <code>Port</code>'s default hue by type.
   */
  public float getTypeHue(){
    return typeHue;
  }
  public int getInitialIndex(){
    return INITIALINDEX;
  }
  /** reset the port hue to default based on type. */
  public void resetHue(){
    setHue(typeHue);
  }
  public void setHue(float h){
    hue = h;
    if(isBright) {
      setBackground(bright(hue));
    } else {
      setBackground(dark(hue));
    }
  }
  private Color dark(float h){
    return Color.getHSBColor(h,(float).75,(float).75);
  }
  private Color bright(float h){
    return Color.getHSBColor(h,(float)1,(float)1);
  }
  public void highlight() {
    isBright = true;
    setBackground(bright(hue));
    repaint();
  }
  public void unhighlight() {
    isBright = false;
    setBackground(dark(hue));
    repaint();
  }

  /** Implement MouseListener. */
  public void mouseClicked(MouseEvent e) {
    int mod = e.getModifiers();
    if((MouseEvent.BUTTON1_MASK & mod) > 0) {
      if ( (InputEvent.ALT_MASK & mod)   > 0 ||
           (InputEvent.CTRL_MASK & mod)  > 0 ||
           (InputEvent.SHIFT_MASK & mod) > 0 ){
        PARENT.doPortAltLeftClick(this);
	return;
      } else {
        PARENT.doPortLeftClick(this);
	return;
      }
    }
    if((MouseEvent.BUTTON2_MASK & mod) > 0) {
      PARENT.doPortRightClick(this);
      return;
    }
    if((MouseEvent.BUTTON3_MASK & mod) > 0) {
      PARENT.doPortRightClick(this);
      return;
    }

  }
  public void mouseEntered(MouseEvent e) {}
  public void mouseExited(MouseEvent e) {}
  public void mousePressed(MouseEvent e) {}
  public void mouseReleased(MouseEvent e) {}
  public void pn(String s) {
    System.err.println(s);
  }


  private GlobalData     global;
  private Arena           arena;

  private int         INITIALINDEX;
  private int                 SIDE;
  private int                 TYPE;
  private String             CLASS;
  private String              NAME;
  private ComponentInstance PARENT;

  private float             hue;
  private float             typeHue;
  private boolean      isBright;

  final static float red    = (float)0;
  final static float yellow = (float)1/6;
  final static float green  = (float)1/3;
  final static float bluegreen = (float)1/2;
  final static float blue   = (float)2/3;

  // enumerated values for side and type
  final static int    INPORT = 0;
  final static int   OUTPORT = 1;
  // enumerated values for type only
  final static int    GOPORT = 2;
  final static int PARAMPORT = 3;


  /* NO NO NO...we are overriding our style sheet */
  /* We have reset plainFont in the constructor   */
  //final Font plainFont = new Font("Dialog", Font.PLAIN, 10);
  protected Font plainFont = new Font("Dialog", Font.PLAIN, 10);

  static java.util.Vector ports = new java.util.Vector();

  class PortWatcher extends MouseAdapter{
    Port port;
    public PortWatcher(Port p){
      super();
      port = p;
    }
    public void mouseEntered(MouseEvent e){
      if(global.getDragOccurring() == false){
        isBright = true;
        highlight(CLASS);
      }
    }
    public void mouseExited(MouseEvent e){
      if(global.getDragOccurring() == false){
        isBright = false;
        unhighlight(CLASS);
      }
    }
    /** part of highlighting matching ports for possible connections */
    public void highlight(String clazz) {
      for(java.util.Enumeration e  = ports.elements();e.hasMoreElements();){
        Port p = (Port)e.nextElement();
        if ((p.CLASS.compareTo(clazz) == 0) && (p.TYPE != port.TYPE)) {
          p.highlight();
        }
      }
    }
    /** part of highlighting matching ports for possible connections */
    public void unhighlight(String clazz) {
      for(java.util.Enumeration e  = ports.elements();e.hasMoreElements();){
        Port p = (Port)e.nextElement();
        if ((p.CLASS.compareTo(clazz) == 0) && (p.TYPE != port.TYPE)) {
          p.unhighlight();
        }
      }
    }
  }
  class PortWatcherx extends MouseAdapter{
    Port port;
    public PortWatcherx(Port p){
      super();
      port = p;
    }
    public void mouseEntered(MouseEvent e){
      if(global.getDragOccurring() == false){
        isBright = true;
        port.setBackground(bright(hue));
        port.repaint();
      }
    }
    public void mouseExited(MouseEvent e){
      if(global.getDragOccurring() == false){
        isBright = false;
        port.setBackground(dark(hue));
        port.repaint();
      }
    }
  }
}

