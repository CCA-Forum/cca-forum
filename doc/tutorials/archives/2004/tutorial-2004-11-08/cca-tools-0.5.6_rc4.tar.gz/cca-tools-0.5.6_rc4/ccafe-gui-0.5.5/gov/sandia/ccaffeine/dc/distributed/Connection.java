package gov.sandia.ccaffeine.dc.distributed;

import java.net.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;

public interface Connection {
  public String getSourceName();
  public InputStream getIn();
  public OutputStream getOut();
  public int getId();
  public boolean isDisabled();
  public void disconnect() throws java.io.IOException;
  public void reconnect(int timeout) throws Exception; // timeout is in millisecs
  public ConnectionManager getConnectionManager();
}

