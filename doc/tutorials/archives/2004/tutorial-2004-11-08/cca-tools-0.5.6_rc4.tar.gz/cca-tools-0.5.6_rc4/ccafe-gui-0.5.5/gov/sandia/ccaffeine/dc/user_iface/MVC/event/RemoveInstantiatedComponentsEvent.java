package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaComponentInstanceNames;




public class RemoveInstantiatedComponentsEvent extends java.util.EventObject {


    /**
     * instance names of the removed component
     */
    CcaComponentInstanceNames instanceNames = null;

    /**
     * Get the instance names of the removed component
     * @return instance names of the revmoed component
     */
    public CcaComponentInstanceNames getInstanceNames() {
        return(instanceNames);
    }

    /**
     * Set the instance names of the removed components
     * @param instanceNames instance name of the removed components
     */
    public void setInstanceNames
       (CcaComponentInstanceNames instanceNames) {
        this.instanceNames = instanceNames;
    }







    /**
     * Create an  RemoveInstantiatedComponentsEvent.
     * @param source The entity that created this event.
     */
    public RemoveInstantiatedComponentsEvent(Object source) {
        super(source);
        this.instanceNames = null;
    }

    /**
     * Create an  RemoveInstantiatedComponentsEvent.
     * @param source The entity that created this event.
     * @param instanceNames the instance name of the removed 
     * components.
     * component.
     */
    public RemoveInstantiatedComponentsEvent
           (Object source,
            CcaComponentInstanceNames instanceNames) {
        super(source);
        this.instanceNames = instanceNames;
    }

}