package gov.sandia.ccaffeine.dc.user_iface.MVC;



/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * A view might display the value of a data field
 * inside a textbox.  The view might also display
 * a prompt to the left of the textbox.  This
 * class contains the contents of such a prompt.
 */
public class CcaPortParameterPrompt {
    public String componentInstanceName = null;
    public String portInstanceName = null;
    public String dataFieldName = null;
    public String dataFieldPrompt = null;

    
    /**
     * Parse the xml contents of the contents of a prompt
     * that is associated with a field parameter.
     * The parsed values are copied into the class's attributes.
     * <p>
     * The XML code will contains something like this: <br>
     * &lt;paramPrompt&gt; <br>
     * &nbsp;&lt;componentInstanceName&gt;<br>
     * &nbsp;&nbsp;&nbsp;name1 <br>
     * &nbsp;&nbsp;&nbsp;&lt;/componentInstanceName&gt; <br>
     * &nbsp;&lt;portInstanceName&gt;name2&lt;/portInstanceName&gt; <br>
     * &nbsp;&lt;dataFieldName&gt;name3&lt;/dataFieldName&gt; <br> 
     * &nbsp;&lt;dataFieldPrompt&gt;value1&lt;/dataFieldPrompt&gt; <br>
     * &lt;paramPrompt&gt; <br>
     * @param xmlComponent The xml code of one component.
     */
    public CcaPortParameterPrompt(String xml) {

        /*
         * Extract out the contents of the following tags:
         *    component name
         *    port name
         *    field name
         *    prompt
         */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<componentInstanceName>(.*?)</componentInstanceName>\\s*"
           +"<portInstanceName>(.*?)</portInstanceName>\\s*"
           +"<dataFieldName>(.*?)</dataFieldName>\\s*"
           +"<dataFieldPrompt>(.*?)</dataFieldPrompt>");

        java.util.regex.Matcher matcher = pattern.matcher(xml);


        /* copy the contents of the 4 tags to our attributes */
        if (matcher.find()) {
            this.componentInstanceName = matcher.group(1);
            this.portInstanceName = matcher.group(2);
            this.dataFieldName = matcher.group(3);
            this.dataFieldPrompt = matcher.group(4);
        }
    }


}