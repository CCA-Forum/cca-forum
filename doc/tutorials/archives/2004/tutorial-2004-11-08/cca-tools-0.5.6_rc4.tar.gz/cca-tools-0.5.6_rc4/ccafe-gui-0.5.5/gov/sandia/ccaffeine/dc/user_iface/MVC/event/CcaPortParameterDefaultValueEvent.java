package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPortParameterDefaultValue;


/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * This event can be used to notify components
 * that the cca server is sending the default value
 * of one of these data fields.  The "default" value is the
 * that value that is displayed on the screen
 * when the parameter is initially displayed 
 * on the screen.  A view entity might
 * respond by displaying the default value on the screen.
 * <p>
 * Possible Scenario: <br>
 * An end-user clicks on a blue port inside of a component <br>
 * client sends "parameters" to server <br>
 * serer- sends "ParamDialog" to client <br>
 * client responds by creating an empty dialog box <br>
 * server sends "ParamTab" to client <br>
 * client responds by inserting a new tab in the dialog box <br>
 * server sends "ParamField" to client <br>
 * client responds by inserting a blank data line into the dialog box <br>
 * server sends "ParamCurrent" to client <br>
 * client responds by inserting the data's value into the dialog box <br>
 * server sends "ParamHelp" to client <br>
 * client responds by setting the text that is displayed if the help button is clicked <br>
 * server sends "ParamPrompt" to client <br>
 * client responds by displaying a prompt to the left of the data's value <br>
 * server sends "ParamDefault" to client <br>
 * client responds by setting the data's default value <br>
 * server sends "ParamStringChoice" to client <br>
 * client responds by setting an item in the value's choice box <br>
 * server sends "ParamNumberRange" to client <br>
 * client responds by setting the data value's range of allowed values <br>
 * server sends  "ParamEndDialog" to client <br>
 * client responds by displaying the dialog box on the screen <br>
 */

public class CcaPortParameterDefaultValueEvent 
       extends java.util.EventObject {

    CcaPortParameterDefaultValue ccaPortParameterDefaultValue = null;

    public CcaPortParameterDefaultValue
           getCcaPortParameterDefaultValue() {
              return(this.ccaPortParameterDefaultValue);
    }

    public void setCcaPortParameterDefaultValue
        (CcaPortParameterDefaultValue ccaPortParameterDefaultValue) {
        this.ccaPortParameterDefaultValue = ccaPortParameterDefaultValue;
    }

    public CcaPortParameterDefaultValueEvent(Object source) {
        super(source);
        this.ccaPortParameterDefaultValue = null;
    }

    public CcaPortParameterDefaultValueEvent
           (Object source,
            CcaPortParameterDefaultValue ccaPortParameterDefaultValue) {
        super(source);
        this.ccaPortParameterDefaultValue = ccaPortParameterDefaultValue;
    }
}
