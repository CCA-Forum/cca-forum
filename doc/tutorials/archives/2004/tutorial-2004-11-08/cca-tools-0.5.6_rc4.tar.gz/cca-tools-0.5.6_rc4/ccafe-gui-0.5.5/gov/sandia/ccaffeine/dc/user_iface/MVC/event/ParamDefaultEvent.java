package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * This event can be used to notify components
 * that the cca server is sending the default value
 * of one of these data fields.  A view entity
 * might respond by checking the state of a
 * data field; if the data field does not have
 * a current value then the default value is
 * displayed on the screen.
 * <p>
 * Possible Scenario: <br>
 * An end-user clicks on a blue port inside of a component <br>
 * client sends "parameters" to server <br>
 * serer- sends "ParamDialog" to client <br>
 * client responds by creating an empty dialog box <br>
 * server sends "ParamTab" to client <br>
 * client responds by inserting a new tab in the dialog box <br>
 * server sends "ParamField" to client <br>
 * client responds by inserting a blank data line into the dialog box <br>
 * server sends "ParamCurrent" to client <br>
 * client responds by inserting the data's value into the dialog box <br>
 * server sends "ParamHelp" to client <br>
 * client responds by setting the text that is displayed if the help button is clicked <br>
 * server sends "ParamPrompt" to client <br>
 * client responds by displaying a prompt to the left of the data's value <br>
 * server sends "ParamDefault" to client <br>
 * client responds by setting the data's default value <br>
 * server sends "ParamStringChoice" to client <br>
 * client responds by setting an item in the value's choice box <br>
 * server sends "ParamNumberRange" to client <br>
 * client responds by setting the data value's range of allowed values <br>
 * server sends  "ParamEndDialog" to client <br>
 * client responds by displaying the dialog box on the screen <br>
 */

public class ParamDefaultEvent extends EventObject {

  /*
   * The name of the cca component that contains
   * the port which contains the data field.
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "StartComponent0"
   */
    protected String componentInstanceName = null;

  /*
   * Ghe name of the cca component that contains
   * the port which contains the data field.
   * <p>
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "StartComponent0"
   * @return The name of the component that received the new default value.
   */
    public String getComponentInstanceName() {
        return(this.componentInstanceName);
    }

    /**
     * The instance name of the port that contains
     * the data field.
     *  Examples of instance names are
     * "cProps" and "go_port."
     */
    protected String portInstanceName = null;

    /**
     * Get the instance name of the port
     * that contains the data field.
     *  Examples of instance names are
     * "cProps" and "go_port."
     * @return The instance name of the port.
     */
    public String GetPortInstanceName() {
        return(this.portInstanceName);
    }


    /**
     * The name of the data field.
     */
    protected String dataFieldName = null;

    /**
     * Get the name of the data field.
     * @return The name of the data field.
     */
    public String getDataFieldName() {
        return(this.dataFieldName);
    }


    /*
     * The default value of the data field.
     */
    protected String dataFieldDefaultValue = null;


    /*
     * Get the default value of the data field.
     */
    public String getDataFieldDefaultValue() {
        return(this.dataFieldDefaultValue);
    }


    /**
     * Create a ParamCurrentEvent.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * This event can be used to notify components
     * that the cca server is sending the default value
     * of one of these data fields.  A view entity
     * might respond by checking the state of a
     * data field; if the data field does not have
     * a current value then the default value is
     * displayed on the screen.
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The name of the port that contains the data field.
     * Example: "configure_port"
     * @param dataFieldName
     * The name of the data field.
     * @param dataFieldDefaultValue
     * The default value of the data field.
     */
    public ParamDefaultEvent
         (Object source,
          String componentInstanceName,
          String portInstanceName,
          String dataFieldName,
          String dataFieldDefaultValue) {

         super(source);
         this.componentInstanceName = componentInstanceName;
         this.portInstanceName = portInstanceName;
         this.dataFieldName = dataFieldName;
         this.dataFieldDefaultValue = dataFieldDefaultValue;
  }

}