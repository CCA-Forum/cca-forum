package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * For some data fields, the value must be
 * one of the items in a set (e.g. "red", "green", "blue").
 * This event can be used to notify components
 * that the cca server is sending one item that
 * belongs in such a set.
 * A client entity can display the items in the set
 * as a pull down menu.
 * <p>
 * Possible Scenario: <br>
 * An end-user clicks on a blue port inside of a component <br>
 * client sends "parameters" to server <br>
 * serer- sends "ParamDialog" to client <br>
 * client responds by creating an empty dialog box <br>
 * server sends "ParamTab" to client <br>
 * client responds by inserting a new tab in the dialog box <br>
 * server sends "ParamField" to client <br>
 * client responds by inserting a blank data line into the dialog box <br>
 * server sends "ParamCurrent" to client <br>
 * client responds by inserting the data's value into the dialog box <br>
 * server sends "ParamHelp" to client <br>
 * client responds by setting the text that is displayed if the help button is clicked <br>
 * server sends "ParamPrompt" to client <br>
 * client responds by displaying a prompt to the left of the data's value <br>
 * server sends "ParamDefault" to client <br>
 * client responds by setting the data's default value <br>
 * server sends "ParamStringChoice" to client <br>
 * client responds by setting an item in the value's choice box <br>
 * server sends "ParamNumberRange" to client <br>
 * client responds by setting the data value's range of allowed values <br>
 * server sends  "ParamEndDialog" to client <br>
 * client responds by displaying the dialog box on the screen <br>

 */

public class ParamStringChoiceEvent extends EventObject {


  /*
   * The name of the cca component that contains
   * the port which contains the data field.
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "TimeStamper0"
   */
    protected String componentInstanceName = null;

  /**
   * Get the name of the cca component that contains
   * the port which contains the data field.
   * <p>
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "TimeStamper0"
   * @return The name of the cca component.
   */
    public String getComponentInstanceName() {
        return(this.componentInstanceName);
    }

    /*
     * The name of the port that contains the data field.
     *  Example: "configure_port"
     */
    protected String portInstanceName = null;

    /**
     * Get the name of the port that contains the data field.
     * @return The instance name of the port.
     */
    public String GetPortInstanceName() {
        return(this.portInstanceName);
    }

    /*
     * The name of a data field.
     */
    protected String dataFieldName = null;

    /**
     * Get the name of a data field.
     * @return The name of the data field.
     */
    public String getDataFieldName() {
        return(this.dataFieldName);
    }


    /*
     * One of the possible values that can be
     * inserted into this data field.
     */
    protected String dataFieldElementInSetOfValues = null;


    /*
     * Get one of the possible values that can be
     * inserted into this data field.
     * @return One of the possible values for this
     * data field.
     */
    public String getDataFieldElementInSetOfValues() {
      return (this.dataFieldElementInSetOfValues);
    }





    /**
     * Create a ParamStringChoiceEvent.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * For some data fields, the value must be
     * one of the items in a set (e.g. "red", "green", "blue").
     * The cca server is sending one item that
     * belongs in such a set.
     * A client entity can display the items in the set
     * as a pull down menu.
     * @param source The entity that created this event.
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The name of a port that contains the data field.
     *  Example: "configure_port"
     * @param dataFieldName
     * The name of the data field.
     * @param dataFieldElementInSetOfValues
     * One of the possible values that can be
     * inserted into this data field.
     */
    public ParamStringChoiceEvent
         (Object source,
          String componentInstanceName,
          String portInstanceName,
          String dataFieldName,
          String dataFieldElementInSetOfValues) {

         super(source);
         this.componentInstanceName = componentInstanceName;
         this.portInstanceName = portInstanceName;
         this.dataFieldName = dataFieldName;
         this.dataFieldElementInSetOfValues = dataFieldElementInSetOfValues;

  }


}