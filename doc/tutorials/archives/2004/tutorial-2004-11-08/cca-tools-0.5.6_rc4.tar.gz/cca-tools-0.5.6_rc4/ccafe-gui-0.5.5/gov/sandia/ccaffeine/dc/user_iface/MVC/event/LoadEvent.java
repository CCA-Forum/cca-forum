package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

/**
 * Used to notify components that the cca server
 * loaded the class of a cca component.
 * The class can be used to instantiate
 * cca components.
 * <p>
 * A view might respond by rendering components
 * in the palette.  The end-user can drag-and-drop
 * components from the palett to the main
 * workspace (the arena).
 */

public class LoadEvent extends java.util.EventObject {

    /*
    The name of the cca widget class that was loaded.
    The name is actually the name of the widget's
    java class.
    EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
    */
    String className = null;


    /*
    Get the name of the cca widget class that was loaded.
    The name is actually the name of the widget's
    java class.
    EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
    */
    public String getClassName() {
        return(this.className);
    }


   /*
    * The arguments for this widget.  There must always be one
    * argument: the class name of the widget itself, other special
    * purpose arguments may follow.
    */
    protected java.util.Vector arguments = null;

   /*
    * Get the arguments for this widget.  There must always be one
    * argument: the class name of the widget itself, other special
    * purpose arguments may follow.
    */
    public java.util.Vector getArguments() {
        return(this.arguments);
    }




    /**
     * Create a LoadEvent.
     * The event can be used to notify components
     * that the cca server loaded the class of a cca widget.
     * The class can be used to instantiate
     * cca widgets.
     * A view might respond by rendering components
     * in the palette.  The end-user can drag-and-drop
     * components from the palett to the main
     * workspace (the arena).
     * @param source The entity that created this event.
     * @param className The name of a cca widget class.
     * The name is actually the name of the widget's
     * java class.
     * EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
     * @param arguments There must always be one
     * argument: the class name of the widget itself, other special
     * purpose arguments may follow.
     */
    public LoadEvent
           (Object source,
            String className,
            java.util.Vector arguments) {
         super(source);
         this.className = className;
         this.arguments = arguments;
    }

}