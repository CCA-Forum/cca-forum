package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

import javax.swing.*;
import gov.sandia.ccaffeine.util.LocalSystem;
import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUI;

/**
 * CmdActionGUILoad.java
 */

public class CmdActionGUILoad
       extends CmdActionGUI
       implements CmdAction {

  public CmdActionGUILoad() {
  }


  public String argtype(){
    return "Ss*";
  }

  public String[] names(){
    return namelist;
  }

  public String help(){
    return "loads a java class";
  }

  private static final String[] namelist = {"load"};

  public void doIt(CmdContext cc, Vector args) {

    CmdContextGUI ccg = (CmdContextGUI)cc;

    String className = (String)args.get(0);

    //try {
      //Class widgetClass = Class.forName(className);
      //Object widget = widgetClass.newInstance();
      //if(widget instanceof CcaffeineGUIWidget) {
	//String[] arg = new String[args.size()];
	//args.copyInto(arg);
	//((CcaffeineGUIWidget)widget).setArguments(arg);
      //}
      //if(widget instanceof Runnable) {
	//(new Thread((Runnable)widget)).start();
      //}
      //if(widget instanceof JInternalFrame) {
	//JInternalFrame frame = (JInternalFrame)widget;
	//frame.setVisible(true);
	//try {
	  //frame.setSelected(true);
	//} catch (java.beans.PropertyVetoException e) {}
	//Container c = global.getAppFrame();
	// Pretty bad design from the Java folks, the JXXXFrame should
	// be an interface.
	//if(c instanceof JApplet) {
	  //JApplet a = (JApplet)c;
	  //a.getContentPane().add(frame);
	  //a.repaint();
	//} else if(c instanceof JFrame){
	  //JFrame f = (JFrame)c;
	  //f.getContentPane().add(frame);
	  //f.repaint();
	//} else if(c instanceof JInternalFrame) {
	  //JInternalFrame f = (JInternalFrame)c;
	  //f.getContentPane().add(frame);
	  //f.repaint();
	//}
      //}
    //} catch(Exception e) {
      //LocalSystem.printException(e);
      //LocalSystem.err.println("continuing ...");
    //}


    this.broadcastLoad(className, args);


  } // doIt

} // CmdActionGUILoad
