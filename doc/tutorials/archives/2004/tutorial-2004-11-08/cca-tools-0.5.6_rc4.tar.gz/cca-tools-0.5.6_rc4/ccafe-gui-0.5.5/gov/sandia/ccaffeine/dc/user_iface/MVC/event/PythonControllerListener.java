package gov.sandia.ccaffeine.dc.user_iface.MVC.event;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.FixSharedLibraryEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.OpenCcaFrameworkEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetPathToCcaComponentsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetPathsToCcaComponentsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.LoadComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ComponentClassNamesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.LaunchGoOnOneComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CloseComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CloseCcaFrameworkEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveInstantiatedComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.LoadComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.InstantiateComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveInstantiatedComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveInstantiatedComponentsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ComponentInstancesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaConnectTwoPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaDisconnectTwoPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaConnectionsBetweenTwoPortsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.LaunchGoOnAllComponentsEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParametersEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaPortParameterSetValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaComponentPropertySetValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaComponentPropertyValueEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.CcaComponentPropertyValuesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetDebugFlagEvent;


/**
 * Listens for events from a ControllerPython.
 * When a PythonStub method returns, 
 * the PythonStub usually sends the return value to the ControllerPython.
 * The ControllerPython processes the return value.  Sometimes the return
 * requires the GUI to be updated; if that is the case, a message is sent
 * the GUI.
 */

/*
 * Programmer's Notes:
 * scenario:  GUI wants to populate the palette
 *    GUI formulates a query that asks for all the components in the palette
 *    GUI sends a query to the ViewPython 
 *        NOTE: The ViewPython is a GUI Listener
 *    ViewPython sends a query to the PythonStub
 *    The PythonStub forwards the query to the server skeleton
 *    The server skeleton forwards the query to the cca server
 *    The cca server sends the components to the server skeleton
 *    The server skeleton sends the components to the PythonStub
 *    The PythonStub sends the components to the ControllerPython
 *    The ControllerPython sends the events to the GUI
 *        NOTE:  The GUI is a ControllerListener
 */


public interface PythonControllerListener extends java.util.EventListener {

    /**
     * The cca's python server has fixed the shared library problem.
     * @param event The event that is generated whenever the python
     * server is finished fixing the shared library problem.
     */
    public void fixSharedLibrary(FixSharedLibraryEvent event);


    /**
     * The cca's python server has opened the cca framework.
     * @param event The event that is generated whenever the python
     * server is finished opening the cca framework.
     */
    public void openCcaFramework(OpenCcaFrameworkEvent event);


    /**
     * The cca's python server has set the path to the cca components.
     * @param event The event that is generated whenever the python
     * server is finished setting the path to the cca components.
     */
    public void setPathToCcaComponents(SetPathToCcaComponentsEvent event);

    /**
     * The cca's python server has set the paths to the cca components.
     * @param event The event that is generated whenever the python
     * server is finished setting the paths to the cca components.
     */
    public void setPathsToCcaComponents
        (SetPathsToCcaComponentsEvent event);


    /**
      * The cca's python server has loaded a component.
      * The client's controller will instruct the
      * GUI to display the component
      * in a palette.
      * @param event The event that is generated whenever the python
      * server is finished loading a component.
      */
    public void loadComponent(LoadComponentEvent event);


    /**
     * the cca server is sending this client the class names of
     * some components.  
      * @param event The event that is generated whenever the python
      * server sends the class names of components.
     */
    public void receivedComponentClassNames
                (ComponentClassNamesEvent event);

    /**
     * the cca server is sending this client one instantiated
     * component.  The client's controller will instruct the GUI 
     * to display the component in an arena(i.e workspace).
     * @param event The event that is generated whenever the python
     * server instantiates a component.
     */
    public void instantiateComponent
                (InstantiateComponentEvent event);
    
    /**
     * The cca server is removing an instantiated component.
     * The client's controller will instruct the GUI
     * to remove the component from the arena (i.e. workspace).
     * @param event The event that is generated whenever the python
     * server removes an instantiated component.
     */
    public void removeInstantiatedComponent
                (RemoveInstantiatedComponentEvent event);    
    
    
    /**
     * The cca server is removing all instantiated components.
     * The client's controller will instruct the GUI
     * to remove all components
     * from the arena (i.e. workspace).
     * @param event The event that is generated whenever the python
     * server removes all instantiated components.
     */
    public void removeInstantiatedComponents
                (RemoveInstantiatedComponentsEvent event);    
    
    

    /**
     * The cca server is sending this client some component instances.
     */   
    public void receivedComponentInstances
                (ComponentInstancesEvent event);

    /**
     * The cca server is connecting two ports.
     * The client's controller will instruct the GUI 
     * to draw a line between the two ports.
     */
    public void connectTwoPorts(CcaConnectTwoPortsEvent event);

    
    /**
     * The cca server is sending us info on all connections that
     * are between two ports.
     */
    public void receivedCcaConnectionsBetweenTwoPorts
          (CcaConnectionsBetweenTwoPortsEvent event);


    /**
     * The cca server is launching the go command
     * from one component. 
     */   
    public void launchGoOnOneComponent(LaunchGoOnOneComponentEvent event);



    /**
     * The cca server is launching the go command
     * on all components
     */   
    public void launchGoOnAllComponents(LaunchGoOnAllComponentsEvent event);
    
    
    /**
     * The cca server is sending us all of the parameters for a port.
     * The client's controller will instruct the GUI to display the
     * parameters in a dialog box.
     */
     public void receivedPortParameters(CcaPortParametersEvent event);      
    
   
    
    /**
     * The cca server is disconnecting two ports.
     * The client's controller will instruct the GUI
     * to remove the line that
     * connects the two ports.
     */
    public void disconnectTwoPorts(CcaDisconnectTwoPortsEvent event);    


    /**
     * The cca server has closed a component.
     */
    public void closeComponent(CloseComponentEvent event);

    /**
     * The cca framework is closed
     */
     public void closeCcaFramework(CloseCcaFrameworkEvent event);
     
     
     /**
      * The server has set the value of a port parameter.
      * The client's controller will instruct the GUI
      * to write the value to stdout.
      */
     public void setPortParameterValue
         (CcaPortParameterSetValueEvent event);  
     
     
     /**
      * The server has set the value of a component property.
      * The client's controller will send the value to the GUI.
      */
      public void setComponentPropertyValue
             (CcaComponentPropertySetValueEvent event);


     /**
      * The server wants the GUI to write the current
      * value of a component property to stdout.
      * The client's controller will forward request
      * to the GUI. 
      */
      public void receivedComponentPropertyValue
             (CcaComponentPropertyValueEvent event);


     /**
      * The server wants the GUI to write the values
      * of all component properties to stdout.  The
      * client's controller will forward the request to 
      * the GUI.
      */
      public void receivedComponentPropertyValues
             (CcaComponentPropertyValuesEvent event);     
      
      
      /**
       * The serer has set the value of the debug flag.
       */
       public void setDebugFlag(SetDebugFlagEvent event);
            
}
