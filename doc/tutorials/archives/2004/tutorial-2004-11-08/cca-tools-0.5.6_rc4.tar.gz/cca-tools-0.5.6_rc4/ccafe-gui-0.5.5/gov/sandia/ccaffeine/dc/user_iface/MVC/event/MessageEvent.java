package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Used to notify components that the cca server
 * sent a message to this client.  For example,
 * a server might respond to a "go" command
 * by sending a message.
 * A view entity might
 * respond by printing a string on standard out.
 * <p>
 * Possible Scenario <br>
 * The end-user clicked on one of the GO ports <br>
 * The cca server executes the GO command <br>
 * The cca server sends a Message to this client <br>
 * The client responds by displaying the message in standard out. <br>
 */

public class MessageEvent extends EventObject {
	
	
	String message = null;
	
	/**
	 * Return the contents of the message
	 * @return The contents of the message
	 */
	public String getMessage() {
		return(this.message);
	}
	
	
	/**
	 * Set the contents of the message. 
	 * @param message the contents of the message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

  /**
   * Create a MessageEvent.
   * This event can be used to notify components that the cca
   * server sent a message to this client.    For example,
   * a server might respond to a "go" command
   * by sending a message.  A view entity might
   * respond by printing a string on standard out.
   * @param source the entity that created this MessageEvent.
   */
    public MessageEvent(Object source) {
        super(source);
        this.message = null;
    }

    /**
     * Create a MessageEvent.
     * This event can be used to notify components that the cca
     * server sent a message to this client.    For example,
     * a server might respond to a "go" command
     * by sending a message.  A view entity might
     * respond by printing a string on standard out.
     * @param source the entity that created this MessageEvent.
     */
      public MessageEvent(Object source, String message) {
          super(source);
          this.message = message;
      }
    
    
}