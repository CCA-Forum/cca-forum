package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;



public class CmdActionCCAGo
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCAGo() {
  }


  public String argtype() {
    return "is";
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
    return "cause the connection framework to run the framed components.";
  }


  private static final String[] namelist = {"go","run"};


  public void doIt(CmdContext cc, Vector args) {



       /*
        * Number of arguments in the go command
        */
       int numberOfArguments = args.size();

       /*
        * To call "go" on a specific
        * component, pass in the
        * name of the component.
        * The instance
        * name is usually the name of the component's
        * java class (without the package name)
        * concatenated with an index number.
        * EXAMPLE:  "StarterComponent0"
        */
       String componentInstanceName = null;
        if (numberOfArguments>0)
            componentInstanceName = (String)args.get(0);


        /*
         * To call "go" on a specific
         * "go" port on a specific component,
         * pass in the
         * name of the "go" port.
         */
         String portInstanceName = null;
         if (numberOfArguments>1)
           portInstanceName = (String)args.get(1);


         this.broadcastGo
             (numberOfArguments,
              componentInstanceName,
              portInstanceName);

  }

}
