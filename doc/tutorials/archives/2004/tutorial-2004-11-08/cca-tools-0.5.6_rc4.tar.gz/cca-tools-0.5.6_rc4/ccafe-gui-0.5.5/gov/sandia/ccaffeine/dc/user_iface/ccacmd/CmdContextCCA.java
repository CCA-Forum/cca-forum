package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.*;
import java.util.*;
import java.io.*;

/** The CCA demo command-line interpreter has some messy data.  */
public class CmdContextCCA extends CmdContext {

  // specific interpreters define different globals like so.
  public LineNumberReader in;
  public DefaultBuilderModel bm;
  public CmdLineBuilderView bv;

  // instantiation of interpreters has specific details.
  public CmdContextCCA(InputStream in, CmdLineBuilderView bv) {
    this.in = new LineNumberReader(new InputStreamReader(in));
    this.bv = bv;
    try{
      bm = new DefaultBuilderModel();
      bv.setBuilderModel(bm);
    } catch(Exception e) {
      bv.error(e);
    }
  }

  public void pn(String s) {
      //System.out.println("FWKWRITE<"+s+">");
    bv.pn(s);
  }

  public void p(String s) {
      // System.out.println("FWKWRITE<"+s+">");
    bv.p(s);
  }

  public String prompt() {
    return "\ncca>";
  }

  public String readLine() throws IOException {
    return in.readLine();
  }

  public String getInstance(String instanceName) {

    // exact match
    if (bm.getArena().containsKey(instanceName)) {
       return instanceName;
    }

    Object[] stringNames = bm.getArena().keySet().toArray();

    // caseless match.
    for (int i=0; i < stringNames.length; i++) {
      String s = (String)stringNames[i];
      if (instanceName.compareToIgnoreCase(s) == 0) {
        return s;
      }
    }

    // leading partial match (caseless)
    String iname = instanceName.toLowerCase();
    for (int i=0; i < stringNames.length; i++) {
      String s = ((String)stringNames[i]).toLowerCase();
      if (s.startsWith(iname) == true) {
        return (String)stringNames[i];
      }
    }

    // poor partial match (caseless)
    for (int i=0; i < stringNames.length; i++) {
      String s = ((String)stringNames[i]).toLowerCase();
      if (s.indexOf(iname) != -1) {
        return (String)stringNames[i];
      }
    }

    return null;
  }

  public String getClass(String className) {

    String[] pallet = bm.getPallet();

    // exact match
    for (int i=0; i < pallet.length; i++) {
      if (className.compareTo(pallet[i]) == 0) {
        return pallet[i];
      }
    }

    // caseless match.
    for (int i=0; i < pallet.length; i++) {
      String s = (String)pallet[i];
      if (className.compareToIgnoreCase(s) == 0) {
        return s;
      }
    }

    // leading partial match (caseless)
    String cname = className.toLowerCase();

    for (int i=0; i < pallet.length; i++) {
      String s = ((String)pallet[i]).toLowerCase();
      if (cname.startsWith(s) == true) {
        return (String)pallet[i];
      }
    }

    // poor partial match (caseless)
    for (int i=0; i < pallet.length; i++) {
      String s = ((String)pallet[i]).toLowerCase();
      if (s.indexOf(cname) != -1) {
        return (String)pallet[i];
      }
    }

    return null;

  }

}
