package gov.sandia.ccaffeine.dc.user_iface.gui;


/** An interface for a Bean to be loaded into the GUI upon a "load" *
 command from the remote framework.  The bean is loaded with the *
 generic class loader and it is then tested to see if it supports *
 one or all of three interfaces: 

   (1) java.lang.Runnable If this interface is implemented then it is
   placed in its own Thread and started.

   (2) javax.swing.JInternalFrame If this interface is implemented it
   is placed into the Application Frame of the GUI as a visible
   component.

   (3) gov.sandia.ccaffeine.dc.user_iface.gui.GUILoadable If this
   interface is implemented, any arguments given with the "load"
   command from the calling component in the remote framework will be
   set upon this Bean through the "setArgs" method.
 */

interface GUILoadable {
  /** Arguments set upon this widget if it has been loaded dynamically
   * from a component in the framework. */
  void setArgs(String argv[]);
}
