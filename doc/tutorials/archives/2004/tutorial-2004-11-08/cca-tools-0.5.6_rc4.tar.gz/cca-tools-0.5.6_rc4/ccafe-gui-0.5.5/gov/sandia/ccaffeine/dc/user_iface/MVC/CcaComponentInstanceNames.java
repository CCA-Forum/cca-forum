package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CcaComponentInstanceNames {

    public String instanceNames[] = new String[0];

    /**
     * Parse the xml contents to retrieved all &lt;instanceName&gt;.
     * The parsed values are copied into the instanceNames attribute.
     * <p>
     * The XML code will contains something like this: <br>
     * &nbsp;&nbsp;&lt;instanceNames&gt; <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;&lt;instanceName&gt; <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;name1 <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;&lt;/className&gt; <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;&lt;instanceName&gt; <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;name2 <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;&lt;/className&gt; <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;&lt;instanceName&gt; <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;name3 <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;&lt;/className&gt; <br>
     * &nbsp;&nbsp;&lt;/instanceNames&gt;
     */
     public CcaComponentInstanceNames(String xmlInstanceNames) {

        /* We will store our extracted class names here */
        java.util.Vector vector = new java.util.Vector();

        /*
         * Extract out the contents of one or more class names
         */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<instanceName>(.*?)</instanceName>");
        java.util.regex.Matcher matcher =
                pattern.matcher(xmlInstanceNames);


        /* extract the ports and store them in our vector */
        while (matcher.find()) {
            vector.add(matcher.group(1));
        }

        /* how many paths did we extract from the xml file? */
        int numberOfPaths = vector.size();


        /* copy the vector into the classNames array */
        this.instanceNames = new String[numberOfPaths];
        vector.copyInto(instanceNames);

     }


     public String toString() {
         StringBuffer s = new StringBuffer("CcaComponentInstanceNames:");
         int numberOfNames = instanceNames.length;
         for (int i=0; i<numberOfNames; i++) {
             s.append(instanceNames[i]);
             s.append(" ");
         }
         return(s.toString());
     }
}
