package gov.sandia.ccaffeine.dc.user_iface.MVC.event;


/**
 GuiListeners can respond to events
 from the GUI.
 */

public interface GuiListener extends java.util.EventListener {

    /**
     * The GUI wants the cca server to remove an instantiation of a
     * cca component.
     * @param event The event that is generated whenever
     * the GUI wants to remove an instantiation of a cca
     * component.
     */
    public void remove(RemoveEvent event);


    /**
     * The GUI wants the cca server to launch an application.
     * @param event The event that is generated whenever
     * the GUI wants to launch the application.
     */
     public void go(GoEvent event);





     /**
      * The GUI is asking the cca server to retrieve a cca component.
      * @param event The event that is generated whenever
      * the GUI wants to retrieve a cca component.
      */
     public void instantiate(InstantiateEvent event);





     /**
      * The GUI is asking the cca server to connect the
      * Provides Port of a cca component to a Uses Port.
      * The Uses Port may be one the
      * same component or may be on a different component.
      * @param event The event that is sent whenever
      * the GUI wants to connect a Uses Port with a
      * Provides Port.
      */
     public void connect(ConnectEvent event);


     /**
      * The GUI is asking the cca server to
      * disconnect the connection between a Provides Port
      * of a cca component
      * and a Uses Port.
      * @param event The event that is sent whenever
      * the GUI wants to connect a Uses Port with a
      * Provides Port.
      */
     public void disconnect(DisconnectEvent event);


    /**
     * The GUI is asking the cca server to set one of the
     * parameters of a port that is on a cca component.
     * @param event The event that is generated
     * whenever the GUI wants to set the value of
     * a data field.
     */
     public void setPortParameter(ParamCurrentEvent event);




    /**
     * The GUI is asking the cca server to send back
     * the value of one of the parameters of a port that
     * is on a cca component.
     * @param event The event that is generated whenever
     * the GUI wants the value of one of the data fields.
     */
    public void getPortParameter(ParamGetCurrentEvent event);


    /**
     * The GUI is asking the cca server to get or set
     * one of the parameters of a port that is on a 
     * cca port.
     * @param event The event that is generated whenever
     * the GUI wants to get or set the value of one
     * of the data fields.
     */
    public void portParameter(ParamEvent event);




    /**
     * The GUI is asking the cca server to send back
     * all of the instantiated cca components.
     * @param event That event that is generated
     * whenever the GUI wants to get all of the
     * instantiated cca components.
     */
    public void getAllInstancesInArena(GetInstancesEvent event);











    /**
     * The GUI is asking the cca server to turn on debugging.
     * @event The event that is generated whenever
     * the GUI wants debugging turned on.
     */
    public void setDebug(SetDebugEvent event);





    /**
     * The GUI is asking the cca server to turn off debugging
     * @event The event that is generated whenever
     * the GUI wants the debugging turned off.
     */
    public void setNoDebug(SetDebugEvent event);




    /**
     * Request some information from the server.
     * We can
     * request the following info: <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display palette <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display arena <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display chain <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display component <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display state <br>
     * <p>
     * If the GUI wants to get information on the components
     * that are in the palette, or on the components that are
     * in the arena, or on the connections that are established
     * inside the arena, or on a particular component, or on
     * the components and the connections that are in the arena,
     * then the GUI will encapsulate the request as a DisplayEvent
     * and will then invoke this method.  This method will send
     * the request to the cca server.
     * @param DisplayEvent The event that is
     * generated whenever an entity is requesting
     * some information from the server.
     */

    public void display(DisplayEvent event);


    /**
     * The GUI is requesting the cca server to send
     * back all of the components that are in the palette.
     * A palette is a menu of
     * cca components; the end-user can drag components
     * from the palette to the arena (workspace).
     * <p>
     * The cca server will send back all of the components
     * that are in the palette.  A GUI might respond
     * by rending an icon, in the palette, for each component.  
     * @param event The event that is generated whenever
     * the GUI wants to know what components
     * are in the palette.
     */
    public void displayPalette(DisplayPaletteEvent event);












  /** 
   * The GUI is requesting the cca server to send 
   * back all connections.  A connection connects
   * a user port of a component to a provider port;
   * the two ports may be on the same cca component
   * or may be on different components.
   * @param event The event that is created
   * whenever the GUI wants to know what connections
   * are in the arena.
   */
  public void links(DisplayChainEvent event);







    /**
     * The GUI is requesting the cca server to 
     * send back a cca component. 
     * <p>
     * The cca server will respond by sending
     * back one cca component.  The GUI might
     * respond by rendering the component
     * in the workspace.
     * @param source The entity that created this event.
     * @param componentInstanceName
     * The name of the
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     * @param event The event that is created whenever
     * the GUI wants some information on a cca component.
     */
    public void displayComponent(DisplayComponentEvent event);

  /**
   * The GUI is requesting the cca server to 
   * send back all components that are in the 
   * arena and to send back all connections.  A connection
   * connects a user port of a component with a provider
   * port; the two ports may be on the same cca component
   * or may be on different components.
   * <p>
   * The cca server will respond by sending back all of
   * the components that are in the workspace and all of the
   * connections.  A GUI might respond by rendering an icon,
   * in the work area, for each component and by drawing lines
   * between the components to connect them.
   * @param event The event that is created whenever
   * we want to know the state of the arena.
   */
    public void displayState(DisplayStateEvent event);

    /**
     * The GUI is requesting that the cca server
     * execute the "go" command"
     * on a specific port that is located
     * on a specific component.
     * @param event The event that is generated whenever
     * the GUI wants to invoke the "go" command.
     */
     public void goComponentPort(GoComponentPortEvent event);






  /**
   * The GUI is requesting the cca server to
   * delete all components.
   * <p>
   * The server will respond by deleting all components.
   * The GUI might respond by removing all components
   * from the workspace.
   * param event The event that is created
   * whenever the GUI wants to to delete
   * all components.
   */
     public void nukeAll(NukeAllEvent event);



    /**
     * The GUI is requesting the cca server to send back or to set
     * the value of a port
     * property.
     * @param event The event that is generated
     * whenever an entity wants to either get or
     * set the value of a port property.
     */
     public void portProperties(PortPropertiesEvent event);


    /**
     * The GUI is requesting the cca server to send back
     * or to set the value of a component property.
     * An example of a component property is the "name"
     * of the component.
     * @param event The event that is generated
     * whenever the GUI wants to either get or
     * set the value of a component property.
     */
     public void componentProperties(ComponentPropertiesEvent event);


     /**
      * The GUI is requesting the cca server to send back
      * the value of a property that is inside a cca component.
      * @param event The event that is generated
      * whenever the GUI wants the value of a
      * property that is inside a component.
      */
    public void getComponentProperty(GetComponentPropertyEvent event);






    /**
     * The GUI wants the server to set the value of 
     * a property that is inside of a cca component.
     * @param event The event that is created whenever
     * the GUI wants to set the value of a property.
     */
    public void setComponentProperty(SetComponentPropertyEvent event);



















    /**
     * The GUI wants to send a message to the cca server.
     * @param event The event that is created
     * the GUI wants to send
     * a string to the cca server.
     */
    public void sendMessage(StringEvent event);


    /**
     * The GUI wants to send a heartbeat to the cca server.
     * @param event The event that is fabricated
     * the GUI wants to emit a heartbeat.
     */
    public void heartbeat(HeartbeatEvent event);

  /**
   * The GUI wants to tell the cca server that the GUI
   * is shutting down.
   * @param event The event that is generated whenever
   * the GUI wants to exit the application.
   */
    public void exit(ExitEvent event);



    /**
     * The GUI wants to tell the cca server to 
     * send back or to set the file path
     * that contains cca components.
     * @param event The event that is
     * generated whenever the GUI
     * wants either to set the path
     * to a new value or to query
     * for the path value.
     */
    public void path(PathEvent event);



    /**
     * The GUI wants the cca server to send back all
     * components that are in the repository or to send
     * back one specific compnonent that is in the repository.
     * @param event The event that is created whenever
     * the GUI wants to get one component or all components
     * from the repository,
     */
    public void repository(RepositoryEvent event);



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * The GUI wants to send an O.S. command to the cca server.
     * The cca server will execute the command.
     * @param event The event that is
     * created whenever the GUI wants
     * an O.S. command executed.
     */
    public void shell(ShellEvent event);

}



