package gov.sandia.ccaffeine.dc.user_iface.MVC.event;


/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * For some data fields, the value must be
 * one of the items in a set (e.g. "red", "green", "blue").
 * This event can be used to notify components
 * that the cca server is sending one item that
 * belongs in such a set.
 * A client entity can display the items in the set
 * as a pull down menu.
 * <p>
 * This event is also used to notify components
 * that an entity wants to set the value of one of the
 * data fields.  A view entity might
 * respond by sending a "parameters" message
 * to the cca server.
 * <p>
 * Possible Scenario: <br>
 * An end-user clicks on a blue port inside of a component <br>
 * client sends "parameters" to server <br>
 * serer- sends "ParamDialog" to client <br>
 * client responds by creating an empty dialog box <br>
 * server sends "ParamTab" to client <br>
 * client responds by inserting a new tab in the dialog box <br>
 * server sends "ParamField" to client <br>
 * client responds by inserting a blank data line into the dialog box <br>
 * server sends "ParamCurrent" to client <br>
 * client responds by inserting the data's value into the dialog box <br>
 * server sends "ParamHelp" to client <br>
 * client responds by setting the text that is displayed if the help button is clicked <br>
 * server sends "ParamPrompt" to client <br>
 * client responds by displaying a prompt to the left of the data's value <br>
 * server sends "ParamDefault" to client <br>
 * client responds by setting the data's default value <br>
 * server sends "ParamStringChoice" to client <br>
 * client responds by setting an item in the value's choice box <br>
 * server sends "ParamNumberRange" to client <br>
 * client responds by setting the data value's range of allowed values <br>
 * server sends  "ParamEndDialog" to client <br>
 * client responds by displaying the dialog box on the screen <br>
 */

import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPortParameterOneEnumeratedValue;

public class CcaPortParameterOneEnumeratedValueEvent 
       extends java.util.EventObject {

    CcaPortParameterOneEnumeratedValue ccaPortParameterOneEnumeratedValue
              = null;

    public CcaPortParameterOneEnumeratedValue
           getCcaPortParameterOneEnumeratedValue() {
              return(this.ccaPortParameterOneEnumeratedValue);
    }

    public void setCcaPortParameterOneEnumeratedValue
        (CcaPortParameterOneEnumeratedValue 
         ccaPortParameterOneEnumeratedValue) {
        this.ccaPortParameterOneEnumeratedValue =
          ccaPortParameterOneEnumeratedValue;
    }

    public CcaPortParameterOneEnumeratedValueEvent(Object source) {
        super(source);
        this.ccaPortParameterOneEnumeratedValue = null;
    }

    public CcaPortParameterOneEnumeratedValueEvent
           (Object source,
            CcaPortParameterOneEnumeratedValue
               ccaPortParameterOneEnumeratedValue) {
        super(source);
        this.ccaPortParameterOneEnumeratedValue =
           ccaPortParameterOneEnumeratedValue;
    }
}
