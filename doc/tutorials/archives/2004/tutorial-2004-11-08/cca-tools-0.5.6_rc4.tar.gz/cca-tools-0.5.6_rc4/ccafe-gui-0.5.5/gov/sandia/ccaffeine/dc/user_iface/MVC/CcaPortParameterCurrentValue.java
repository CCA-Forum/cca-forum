package gov.sandia.ccaffeine.dc.user_iface.MVC;



/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * This class holds the name and the current value
 * of one data field.  The "current" value is the
 * value that is currently displayed on the screen.
 */
public class CcaPortParameterCurrentValue {
    public String componentInstanceName = null;
    public String portInstanceName = null;
    public String dataFieldName = null;
    public String dataFieldValue = null;

    
    /**
     * Parse the xml contents of a current port parameter.
     * The parsed values are copied into the class's attributes.
     * <p>
     * The XML code will contains something like this: <br>
     * &lt;paramCurrent&gt; <br>
     * &nbsp;&lt;componentInstanceName&gt;<br>
     * &nbsp;&nbsp;&nbsp;name1 <br>
     * &nbsp;&nbsp;&nbsp;&lt;/componentInstanceName&gt; <br>
     * &nbsp;&lt;portInstanceName&gt;name2&lt;/portInstanceName&gt; <br>
     * &nbsp;&lt;dataFieldName&gt;name3&lt;/dataFieldName&gt; <br> 
     * &nbsp;&lt;dataFieldValue&gt;value1&lt;/dataFieldValue&gt; <br>
     * &lt;paramCurrent&gt; <br>
     * @param xmlComponent The xml code of one component.
     */
    public CcaPortParameterCurrentValue(String xml) {

        /*
         * Extract out the contents of the following tags:
         *    component name
         *    port name
         *    field name
         *    field value
         */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<componentInstanceName>(.*?)</componentInstanceName>\\s*"
           +"<portInstanceName>(.*?)</portInstanceName>\\s*"
           +"<dataFieldName>(.*?)</dataFieldName>\\s*"
           +"<dataFieldValue>(.*?)</dataFieldValue>");

        java.util.regex.Matcher matcher = pattern.matcher(xml);


        /* copy the contents of the 4 tags to our attributes */
        if (matcher.find()) {
            this.componentInstanceName = matcher.group(1);
            this.portInstanceName = matcher.group(2);
            this.dataFieldName = matcher.group(3);
            this.dataFieldValue = matcher.group(4);
        }
    }


}