package gov.sandia.ccaffeine.dc.distributed;

import java.net.*;
import gov.sandia.ccaffeine.util.*;
import gnu.getopt.*;
import java.util.*;
import java.io.*;


class RunMuxer {
  public static String DEFAULTPROCFILEPATH = "processors";

  public void startServer(String myName, String fileName, int port, String clientName, String clientFile, int clientPort) throws Exception {
      if (fileName == null)
	  fileName = DEFAULTPROCFILEPATH;

    SocketConnectionMgr css;
    css = new SocketConnectionMgr(myName,fileName, port);
    css.connect(0);
    if(css.isServer()) {
	if ((clientFile != null) && (clientName != null)) { // we are a link in the chain - need to start a client and a server and connect the two
	    SocketConnectionMgr cssClient = 
		new SocketConnectionMgr (clientName, clientFile, clientPort);
	    cssClient.connect(0); // infinite timeout
	    
	    // make a server connected to the input/output streams of the
	    // client we just constructed
	    ServerMux sm = new ServerMux(css, (Connection) cssClient.getConnections().elementAt(0), null); 
	    sm.doClientIO();

	    // BUGBUG - now that clients can reconnect, need
	    // an explicit shutdown message!! (this _will_ break 
	    // other code)
	    Thread t = sm.getControllerClientThread();
	    t.join();
      	    LocalSystem.out.println("Normal Termination ...");
	    sm.shutdown();
	    LocalSystem.out.println("Normal Termination Completed");
	} else { // we are the end server in the chain
	    
	    PipedOutputStream p2Out = new PipedOutputStream();
	    PipedInputStream p2In = new PipedInputStream(p2Out);
	    PrintWriter out = new PrintWriter(p2Out, true);
	    // this stream goes from the Muxer Client out to this method
	    PipedOutputStream p1Out = new PipedOutputStream();
	    PipedInputStream p1In = new PipedInputStream(p1Out);
	    BufferedReader readStream = new BufferedReader(new InputStreamReader(p1In));
	    Connection connect = new StaticIOConnection (p2In, p1Out, -1);
	    ServerMux sm = new ServerMux(css, connect, null);
	    // We read from the LocalSystem only to be able to exit gracefully
	    BufferedReader in = 
		new BufferedReader(new InputStreamReader(LocalSystem.in));
	    sm.doClientIO();
	    String line;
	    LocalSystem.out.println("Type \"exit\" on a line by itself to quit");
	    out.println(MessageData.makeOutOfBandMessage("Bash Controller", ServerMux.DATA_COLLECTOR_MSG + "gov.sandia.ccaffeine.dc.distributed.MessageBasedDataCollector"));
	    out.println("export PS1=");
	    // start reading from the stream and writing out to stdout
	    Runnable runnable = new ReadLooper( readStream );
	    Thread tMuxee = 
		new Thread( runnable ); // new Thread
	    tMuxee.start();


	    // read from std in and write to the server mux
	    while((line = in.readLine()) != null) {
		// "exit" to quit:
	      LocalSystem.out.println("Sending line: " + line);
	      out.println(line);
	      if(line.compareTo("exit") == 0) break;
		LocalSystem.out.println("Next command: ");
	    }

	    LocalSystem.out.println("Normal Termination ...");
       	    out.println(MessageData.makeOutOfBandMessage("Muxer Process", ServerMux.SHUTDOWN_MSG));
	    sm.shutdown();
	    LocalSystem.out.println("Normal Termination Completed");
	}
    } else {
	throw new RuntimeException("Bash controller must be configured to run as a server");
    }
  }


  public final static void main(String[] arg) throws Exception {
    String usage = "TestClientServer --name MyHostName "+
      "[--file procDefinitionFile]"+
      " [--portNumber portNumber] [--nextServerFile procDefinitionFile]" +
	" [--clientName myClientName]";
    String myName = null;
    String procFile = null;
    int portNumber = 0;
    String nextServer = null;
    String clientName = null;
    int clientPort = 0;

    StringBuffer sb = new StringBuffer();
    LongOpt[] longopts = new LongOpt[6];
    longopts[0] = new LongOpt("name", LongOpt.REQUIRED_ARGUMENT, sb, 'n');
    longopts[1] = new LongOpt("file", LongOpt.REQUIRED_ARGUMENT, sb, 'f');
    longopts[2] = new LongOpt("portNumber", LongOpt.REQUIRED_ARGUMENT, sb, 'p');
    longopts[3] = new LongOpt("nextServerFile", LongOpt.REQUIRED_ARGUMENT, sb, 's');
    longopts[4] = new LongOpt("clientName", LongOpt.REQUIRED_ARGUMENT, sb, 'c');
    longopts[5] = new LongOpt("clientPort", LongOpt.REQUIRED_ARGUMENT, sb, 'x');
    Getopt g = new Getopt("TestClientServer", arg, "n:f:p:s:c:x", longopts);
    String theOption;
    int c;
    while((c = g.getopt()) != -1) {
      switch(c) {
      case 'n':
	//Name of processor I am on.
	theOption = "name";
	break;
      case 'f':
	//Name of the Processor file
	theOption = "file";
	break;
      case 'p':
	theOption = "portNumber";
	break;
      case 's':
	theOption = "nextServerFile";
	break;
      case 'c':
	theOption = "clientName";
	break;
      default:
      case '?':
	LocalSystem.err.println(usage);
	return;
      case 0:
	theOption = longopts[g.getLongind()].getName();
	break;
      }
      if(theOption == "name") {
	myName = g.getOptarg();
      } else if(theOption == "file") {
	procFile = g.getOptarg();
      } else if(theOption == "portNumber") {
	portNumber = Integer.parseInt(g.getOptarg());
      } else if(theOption == "nextServerFile") {
	nextServer = g.getOptarg();
      } else if(theOption == "clientName") {
	clientName = g.getOptarg();
      } else if(theOption == "clientPort") {
	clientPort = Integer.parseInt(g.getOptarg());
      } else {
	LocalSystem.err.println("Bad Option: "+theOption);
	LocalSystem.err.println(usage);
	return;
      }
    }
    if(myName == null) {
      LocalSystem.err.println(usage);
      return;
    }
    RunMuxer tst = new RunMuxer();
    tst.startServer(myName, procFile, portNumber, clientName, nextServer, clientPort);
  }
}

class ReadLooper implements Runnable {
    BufferedReader readStream;
    public ReadLooper ( BufferedReader readStream )
    {
	this.readStream = readStream;
    }
    public void run() {
	try {
	    String message = "";
	    String messageLine;
	    while ((messageLine = readStream.readLine()) != null)
		{
		    if (messageLine.startsWith (MessageBasedDataCollector.END_OF_MESSAGE))
			{
			    LocalSystem.out.println("New message");
			    continue;
			}
		    LocalSystem.out.println("CONTROLLER GOT MESSAGE: " + messageLine);
		    message += messageLine;
		}
	    LocalSystem.out.println("Shutting down reader thread");
	} catch (Exception e) {
	    LocalSystem.out.println("Exception");
	}
    }
} // new Runnable() 

