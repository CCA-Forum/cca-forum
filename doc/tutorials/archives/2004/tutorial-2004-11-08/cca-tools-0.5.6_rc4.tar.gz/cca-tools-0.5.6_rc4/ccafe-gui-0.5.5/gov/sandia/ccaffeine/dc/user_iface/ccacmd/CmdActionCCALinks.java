package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;

public class CmdActionCCALinks
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCALinks() {
  }


  public String argtype() {
    return "";
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
    return "show what connections are in the arena currently.";
  }


  private static final String[] namelist = {"chain","links"};


  public void doIt(CmdContext cc, Vector args) {

    this.broadcastLinks();

  }

}
