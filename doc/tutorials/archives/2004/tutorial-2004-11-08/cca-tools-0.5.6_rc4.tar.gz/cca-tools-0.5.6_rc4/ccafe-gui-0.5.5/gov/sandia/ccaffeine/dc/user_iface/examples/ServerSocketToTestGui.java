
package gov.sandia.ccaffeine.dc.user_iface.examples;

import java.net.Socket;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.IOException;

import java.util.Vector;
import gov.sandia.ccaffeine.dc.user_iface.examples.event.MessageEvent;
import gov.sandia.ccaffeine.dc.user_iface.examples.event.MessageListener;



/**
 * Create a server that will service a cca client.
 * <p>
 * The server uses a ServerSocket.
 * <p>
 * The server can send commands to the cca client.
 * Whenever the cca client sends a query or information to the server,
 * the server will send it to all listeners.                        
 */


public class ServerSocketToTestGui implements MessageListener {


    /* Because there may be more than one client connected */
    /* to this server, we need a vector of readers.  Each  */
    /* reader reads queries or information that the client */
    /* sends to the server.                                */
    Vector vectorReaders = new Vector();


    /* Because there may be more than one client connected */
    /* to this server, we need a vector of writer.  Each   */
    /* write can send commands to a client.                */
    Vector vectorWriters = new Vector();

	
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/	

	
        /**
         * Create a ServerSocket.  
         * Whenever a cca client requests a connection,
         * spin off a handler to service that client.
         * @param port The port that clients will send
         * connection requests to.
         */
	public ServerSocketToTestGui(int port) {
	
	    ThreadServerSocket threadServerSocket = new ThreadServerSocket(port);
	    threadServerSocket.start();
	
	    
	}

	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/	
	
	
        /**
         * The main thread of the server.
         * This thread listens for client connections.
         * Whenever a client requests a connection, 
         * this thread will spawn a service thread to
         * service that client.
         */
        protected class ThreadServerSocket extends Thread {
        
            /*
             * the port that clients use to request a connection.
             */
            int port = 0;
            

            /**
             * The main thread of the server.
             * This thread listens for connection requests
             * that arrive at a port.  
             * @param port clients will send connection
             * requests to this port.  Whenever a connection
             * request is granted, this thread will spawn a
             * service thread to service that client.
             */
            public ThreadServerSocket(int port) {
                super();
                this.port = port;
            }
    		
    	    /*
             * Listen for new clients trying to connect to us. When a new client does
    	     * try to connect to us then launch a new thread to service that client.
    	     */
    	    public void run() {
    	        try {
    	        	
    	            /* create a server socket */
    	            java.net.ServerSocket serverSocket = 
    	            	new java.net.ServerSocket(this.port);               
    	            
    	            while (true) {
    	                new serviceNewClient(serverSocket.accept());
    	            }
    	                
    	        }catch (IOException e) {
    	            System.out.println(e);
    	        }
    	    } 
        
        }	
    	

    
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/    
    
    /*
    A new client has just connected to us.
    Launch a new thread to service that client.
    */
    class serviceNewClient extends Thread {

        /* This socket is connected to the cca client. */
        /* The service handler can this socket to send */
        /* commands to the cca client and to receive   */
        /* querries from the cca client.               */
        Socket socket;
        
        /**
         * Launch the handler that will service the client.
         * @param socket This socket is connected to the 
         * cca client.
         */
        public serviceNewClient(Socket socket) {
            this.socket = socket;
            setPriority(NORM_PRIORITY-1);
            start();
        }
        

        /**
         * Service the cca client.
         * <p>
         * Create a reader to read queries from the client.
         * Create a write to write commands to the client.
         * Wait for the client to send queries to the cca server.
         * Whenever we receive a query, send that query to 
         * all listeners.
         */
        public void run() {
        	
        	
            BufferedReader reader = null;
            PrintWriter writer = null;
            ScriptFile scriptFile = null;
                        
            
            try {
            	
            	/** open a comm link with the client */
                reader = new BufferedReader
                    (new InputStreamReader(socket.getInputStream()));
                synchronized(ServerSocketToTestGui.this.vectorReaders) {
                    ServerSocketToTestGui.this.vectorReaders.add(reader);
                }
                    
                writer = new PrintWriter
                    (new OutputStreamWriter(socket.getOutputStream()),true);
                synchronized(ServerSocketToTestGui.this.vectorWriters) {
                    ServerSocketToTestGui.this.vectorWriters.add(writer);
                }
                    
                                   

                /**
                 * Wait for the client to send us a query.
                 * When it arrives, notify all listeners.
                 */             
                while(true) {
                
                    /* wait for the client to send us a message */
                    String messageFromClient = reader.readLine();
                    
                    /* are we done? */
                    if (messageFromClient==null) break;
                    
                    /* send the message to all registered listeners */
                    ServerSocketToTestGui.this.broadcastMessage(messageFromClient);
                	
                }//while                       
                
            }catch (java.io.IOException e) {
                System.out.println(e);
            }finally {

                /* close the comm link with the client */
            
            
                /* We are no longer reading from this GUI */
                if (reader!=null) {
                    synchronized(ServerSocketToTestGui.this.vectorReaders) {
                        ServerSocketToTestGui.this.vectorReaders.remove(reader);                
                    }
		    try {reader.close();} catch (IOException e1) {}                
                    reader = null;
                }
  
                /* We are no longer writing to this GUI */
                if (writer!=null) {                
                    synchronized(ServerSocketToTestGui.this.vectorWriters) {
                        ServerSocketToTestGui.this.vectorWriters.remove(writer);
                     }
                    writer.close();
                    writer = null;                        
                }
            
                /* close the communication link with the cca client */
                if (socket!=null)
                    try {socket.close();} catch (IOException e1){}              	
            }//finally
        }//run
    }//class    

    
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/    
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/    
	/*-------------------------------------------------------------------*/
	/*-------------------------------------------------------------------*/    
	
    
    
    Vector messageListeners = new Vector();
    synchronized public void addMessageListener(MessageListener listener) 
    {
         messageListeners.add(listener);        
    }
    synchronized public void removeMessageListener(MessageListener listener) 
    {
         messageListeners.remove(listener);
    }
     
    public void broadcastMessage(String message){
        MessageEvent event = new MessageEvent(this, message);
        broadcastMessageEvent(event);
    }
     
    protected void broadcastMessageEvent(MessageEvent event) 
    {
         // loop through each listener and pass on the event if needed
         Vector listeners;
            synchronized (this) {
                listeners = (Vector)messageListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             MessageListener x = (MessageListener)listeners.elementAt(i);
             x.receivedMessage(event);         
         }
    }
     
  
  
    /**
     * Send a message to every client.
     * @param event Contains the text of the message
     * that will be sent to every cca client.
     */
    public void receivedMessage(MessageEvent event) {
    
        /* Get the message that we will send to every client */
        String message = event.getMessage();
        
        /* send the message to every client */
        Vector writers;
        synchronized(this.vectorReaders) {
            writers = (Vector)this.vectorWriters.clone();
         }
         int numberOfClients = writers.size();
         for (int i=0; i<numberOfClients; i++){
             PrintWriter writer = (PrintWriter)writers.get(i);
             writer.write(message);    
             writer.flush();
         }                        
    }
    
    
	public static void main(String[] args) {
	}
}
