package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUI;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.AddComponentClassEvent;

/**
 * CmdActionGUIAddComponentClass.java
 *
 * When this client establishes a communication link
 * with the cca server, the cca server sends the classes
 * of all the cca components to the client.  The classes
 * are sent one class at a time.  When the client
 * receives a class, the client displays the class
 * in the palette.
 */

public class CmdActionGUIAddComponentClass
       extends CmdActionGUI implements CmdAction{

    public CmdActionGUIAddComponentClass(){
    }

    public String argtype(){
	return "S";
    }

    public String[] names(){
	return namelist;
    }

    public String help(){
	return "adds a class to the palette.";
    }

    private static final String[] namelist = {"addClass", "addComponentClass"};
    public void doIt(CmdContext cc, Vector args) {

	CmdContextGUI ccg = (CmdContextGUI)cc;

        /*
         Get the name of the newly added class.
         The name is actually the name of the component's
         java class.  For example, the name could be
         "gov.sandia.ccaffeine.dc.component.PrinterComponent"
        */
	String  className = (String)args.get(0);

	//global.getPalette().addComponentClass(className);
        /*
         Notify all registered ServerListeners that the
         cca server added a new class.  A view might respond
         by rendering a box inside of a palette.
        */
        this.broadcastAddComponentClass(className);

    }

}
