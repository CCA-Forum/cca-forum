package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

public class OpenCcaFrameworkEvent extends EventObject {

    public OpenCcaFrameworkEvent(Object source) {
        super(source);
    }

}