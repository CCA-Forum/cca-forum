package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Used to notify components that the cca server
 * used a cca component class to instantiate a new
 * cca component object.  A view entity might
 * respond by rendering a box inside of an arena.
 * <p>
 * Also used to notify components that an entity
 * wants to retrieve a cca component.  A view entity
 * might respond by sending a "pulldown," "instantiate",
 * or "create" message
 * to the cca server.
 * <p>
 * Possible Scenario <br>
 * The end-user drags a component from the palette to the arena <br>
 * The cca server instantiates a new cca component <br>
 * The cca server sends the new component to this client <br>
 * The client responds by display the component in the arena. <br>
 */

public class InstantiateEvent extends EventObject {


    /*
     * The name of the class that was used to
     * instantiate a new cca component.
     * The name is actually the name of the component's
     * java class.
     * EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
    */
    String className = null;


    /**
     * Get the name of the class that was used to
     * instantiate a new cca component.
     * The name is actually the name of the component's
     * java class.
     * EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
     * @return The name of the newly added class.
     */
    public String getClassName() {
        return(className);
    }

    /*
     * The name of the newly instantiated
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
    */
    protected String instanceName = null;


    /*
     * Get the name of the newly instantiated
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
    */
    public String getInstanceName() {
        return(this.instanceName);
    }


    /**
     * Create an InstantiateEvent.
     * The event can be used to notify components
     * that the cca server
     * used a cca component class to instantiate a new
     * cca component object.  A view entity might
     * respond by rendering a box inside of an arena.
     * Also used to notify components that an entity
     * wants to retrieve a cca component.  A view entity
     * might respond by sending a "pulldown," "instantiate",
     * or "create" message
     * @param source The entity that created this event.
     * @param className The name of the class
     * that was used to instantiate a new cca component.
     * The name is actually the name of the component's
     * java class.
     * EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
     * @param instanceName The name of the newly instantiated
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     */
    public InstantiateEvent
           (Object source,
            String className,
            String instanceName) {
         super(source);
         this.className = className;
         this.instanceName = instanceName;
    }

}