package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotOpenCcaFrameworkException extends Exception {

  public CanNotOpenCcaFrameworkException() {
      super();
  }

  public CanNotOpenCcaFrameworkException(String message) {
      super(message);
  }


}