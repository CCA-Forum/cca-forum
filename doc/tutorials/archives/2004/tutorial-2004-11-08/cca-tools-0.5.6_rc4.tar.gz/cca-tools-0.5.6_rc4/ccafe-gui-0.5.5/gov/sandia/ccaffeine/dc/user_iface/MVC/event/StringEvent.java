package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Used to notify components
 * that an entity wants to send
 * a string to the cca server.
 */

public class StringEvent extends EventObject {

    /*
     * The string that we want to send to the cca server
     */
    protected String message = null;

    /**
     * Retrieve the message that we want to send
     * to the cca server.
     * @return The message that we want to send
     * to the cca server.
     */
    public String getMessage() {
       return(this.message);
    }


    /**
     * Create a StringEvent.
     * This event can be
     * used to notify components
     * that an entity wants to send
     * a string to the cca server.
     * @param source The entity that created this event.
     * @param message The message that is to
     * be sent to the cca server.
     */
    public StringEvent
           (Object source,
            String message) {
        super(source);
        this.message = message;
    }

}