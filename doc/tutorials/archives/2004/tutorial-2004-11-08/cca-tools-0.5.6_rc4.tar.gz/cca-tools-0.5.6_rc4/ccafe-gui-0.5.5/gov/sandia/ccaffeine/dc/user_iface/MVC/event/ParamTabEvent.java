package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * Sometimes, the data fields are grouped
 * into sets.  This event can be used to notify
 * components that the cca server is sending the
 * name of such a set.
 * A client entity can display each set as a
 * tabbed pane.
 * <p>
 * Possible Scenario: <br>
 * An end-user clicks on a blue port inside of a component <br>
 * client sends "parameters" to server <br>
 * serer- sends "ParamDialog" to client <br>
 * client responds by creating an empty dialog box <br>
 * server sends "ParamTab" to client <br>
 * client responds by inserting a new tab in the dialog box <br>
 * server sends "ParamField" to client <br>
 * client responds by inserting a blank data line into the dialog box <br>
 * server sends "ParamCurrent" to client <br>
 * client responds by inserting the data's value into the dialog box <br>
 * server sends "ParamHelp" to client <br>
 * client responds by setting the text that is displayed if the help button is clicked <br>
 * server sends "ParamPrompt" to client <br>
 * client responds by displaying a prompt to the left of the data's value <br>
 * server sends "ParamDefault" to client <br>
 * client responds by setting the data's default value <br>
 * server sends "ParamStringChoice" to client <br>
 * client responds by setting an item in the value's choice box <br>
 * server sends "ParamNumberRange" to client <br>
 * client responds by setting the data value's range of allowed values <br>
 * server sends  "ParamEndDialog" to client <br>
 * client responds by displaying the dialog box on the screen <br>

 */

public class ParamTabEvent extends EventObject {


  /*
   * The name of the cca component that contains
   * the port which contains the data field.
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "TimeStamper0"
   */
    protected String componentInstanceName = null;

  /**
   * Get the name of the cca component that contains
   * the port which contains data fields.
   * <p>
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "TimeStamper0"
   * @return The name of the cca component.
   */
    public String getComponentInstanceName() {
        return(this.componentInstanceName);
    }

    /*
     * The name of the port that contains data fields.
     *  Example: "configure_port"
     */
    protected String portInstanceName = null;

    /**
     * Get the name of the port that contains the data field.
     * @return The instance name of the port.
     */
    public String GetPortInstanceName() {
        return(this.portInstanceName);
    }





    /*
     * The name of the tab.
     */
    protected String tabName = null;



    /*
     * Get the name of the tab.
     */
    public String getTabName() {
        return(this.tabName);
    }


    /**
     * Create a ParamTabEvent.
     * <p>
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * Sometimes, the data fields are grouped
     * into sets.  This event can be used to notify
     * components that the cca server is sending the
     * name of such a set.
     * A client entity can display each set as a
     * tabbed pane.
     * @param source The entity that created this event.
     * @param componentInstanceName
     * The name of the cca component that contains
     * the port which contains the data field.
     * The name is usually the java class name of the component
     * (without the package name) concatenated with an index number.
     * Example:  "TimeStamper0"
     * @param portInstanceName
     * The name of a port that contains the data field.
     *  Example: "configure_port"
     * @param dataFieldName
     * The name of the data field.
     * @param tabName
     * The name of the tab.
     */
    public ParamTabEvent
         (Object source,
          String componentInstanceName,
          String portInstanceName,
          String tabName) {

         super(source);
         this.componentInstanceName = componentInstanceName;
         this.portInstanceName = portInstanceName;
         this.tabName = tabName;

  }


}