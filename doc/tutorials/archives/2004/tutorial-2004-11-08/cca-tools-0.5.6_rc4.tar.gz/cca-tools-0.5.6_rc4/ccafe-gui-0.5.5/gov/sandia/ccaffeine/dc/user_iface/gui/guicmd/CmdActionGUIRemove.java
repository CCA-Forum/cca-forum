package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUI;

/**
 * CmdActionGUIRemove.java
 */

public class CmdActionGUIRemove
       extends CmdActionGUI
       implements CmdAction {

    public CmdActionGUIRemove() {
    }


    public String argtype(){
	return "I";
    }

    public String[] names(){
	return namelist;
    }

    public String help(){
	return "removes a ComponentInstance from the arena.";
    }

    private static final String[] namelist = {"remove"};

    public void doIt(CmdContext cc, Vector args) {

	CmdContextGUI ccg = (CmdContextGUI)cc;

       /**
        * The name of the component that was removed.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
        String componentInstanceName = (String)args.get(0);


	//ComponentInstance componentInstance =
	//    global.getArena().getComponentInstance(componentInstanceName);

	//global.getArena().removeComponentInstance(componentInstance);
        this.broadcastRemove(componentInstanceName);

    } // doIt


} // CmdActionGUIRemove
