package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CcaConnection {


    String providesServiceComponentName = "";
    String providesServicePortName = "";
    String usesServiceComponentName = "";
    String usesServicePortName = "";
    String status = "";





    /**
     * Parse the xml contents of a connection.
     * The parsed values are copied into the class's attributes.
     * <p>
     * The XML code will contains something like this: <br>
     * &nbsp;&lt;connection&gt; <br>
     * &nbsp;&nbsp;&lt;providesServiceComponentName&gt; <br>
     * &nbsp;&nbsp;&nbsp;providerComponentName <br>
     * &nbsp;&ngsp;&lt;/providesServiceComponentName&gt; <br>
     * &nbsp;&nbsp;&lt;providesServicePortName&gt; <br>
     * &nbsp;&nbsp;&nbsp;providerPortName <br>
     * &nbsp;&ngsp;&lt;/providesServicePortName&gt; <br>
     * &nbsp;&nbsp;&lt;usesServiceComponentName&gt; <br>
     * &nbsp;&nbsp;&nbsp;userComponentName <br>
     * &nbsp;&ngsp;&lt;/usesServiceComponentName&gt; <br>
     * &nbsp;&nbsp;&lt;usesServicePortName&gt; <br>
     * &nbsp;&nbsp;&nbsp;userPortName <br>
     * &nbsp;&ngsp;&lt;/usesServicePortName&gt; <br>
     * &nbsp;&lt;/connection&gt; <br>
     */
    public CcaConnection(String xmlConnection) {

        /*
         * Extract out the contents of the following tags:
         *     providesServiceComponentName
         *     providesServicePortName
         *     usesServiceComponentName
         *     usesServicePortName
         */
        java.util.regex.Pattern pattern = 
           java.util.regex.Pattern.compile
           ("<providesServiceComponentName>"
           +    "(.*?)"
           +"</providesServiceComponentName>\\s*"
           +"<providesServicePortName>"
           +    "(.*?)"
           +"</providesServicePortName>\\s*"
           +"<usesServiceComponentName>"
           +   "(.*?)"
           +"</usesServiceComponentName>\\s*"
           +"<usesServicePortName>"
           +   "(.*?)"
           +"</usesServicePortName>\\s*"
           +"<status>"
           +    "(.*?)"
           +"</status>");

        java.util.regex.Matcher matcher = 
                pattern.matcher(xmlConnection);
        
        /* copy the contents of the 4 tags to our attributes */
        if (matcher.find()) {
            this.providesServiceComponentName = matcher.group(1);
            this.providesServicePortName = matcher.group(2);
            this.usesServiceComponentName = matcher.group(3);
            this.usesServicePortName = matcher.group(4);            
            this.status = matcher.group(5);
        }
    }

}