package gov.sandia.ccaffeine.dc.user_iface.MVC;

import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RemoveEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GoEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.InstantiateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ConnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisconnectEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamCurrentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GetInstancesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamGetCurrentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetDebugEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayPaletteEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayChainEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayComponentEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayStateEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GoComponentPortEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.NukeAllEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GetComponentPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.SetComponentPropertyEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.StringEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.HeartbeatEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ExitEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ParamEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.DisplayEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PathEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PortPropertiesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ComponentPropertiesEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.RepositoryEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ShellEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ClientSocket;

/**
 * An MVC view.
 * This view is used to send commands and data
 * to the cca server.
 */


/*
 * Programmer's Notes:
 * scenario:  GUI wants to populate the palette
 *    GUI formulates a query that asks for all the components in the palette
 *    GUI sends the query to the ViewSocket
 *        NOTE:  The ViewSocket is a GuiListener
 *    ViewSocket forwards the query to the cca server
 *    cca server sends the components to the ControllerSocket
 *    ControllerSocket sends the data to CmdParse
 *    CmdParse invokes one of the CmdActionXXX classes
 *    CmdActionXXX invokes the CmdAction class
 *    CmdAction sends an event to the GUI
 *        NOTE:  The GUI is a ControllerListener
 */


public class ViewSocket implements GuiListener {

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    ClientSocket clientSocket = null;

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Create an MVC View.
     * This view writes commands and data to the cca server.
     * @param outputStream The output stream that is
     * used to send commands and data to the cca server.
     */
    public ViewSocket(ClientSocket clientSocket) {

        this.clientSocket = clientSocket;
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Send a message to the cca server
     * @param message The string we are sending
     * to the cca server.
     */
    synchronized public void write(String message) {
        System.out.println("OUT: " + message + "\n");
        this.clientSocket.print(message+"\n");
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The end-user wants to remove an instantiation of a
     * cca component.
     * We will
     * respond by sending a message to the cca server.
     * @param event The event that is generated whenever
     * the GUI wants to remove an instantiation of a cca
     * component.
     */
    public void remove(RemoveEvent event) {

      /*
       * The name of the component that was removed.
       * The name is usually the java class name of the component
       * (without the package name) concatenated with an index number.
       * Example:  "StartComponent0"
       */
        String componentInstanceName = event.getComponentInstanceName();

        /*
         * Create the command that we want to send to the cca server.
        */
        String command = "remove " + componentInstanceName;

        /*
         * Send the command to the cca server
        */
        write(command);

    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * The end-user,
     * via the GUI, wants to launch the application.
     * A view entity might
     * respond by launching the application
     * @param event The event that is generated whenever
     * the GUI wants to launch the application.
     */
     public void go(GoEvent event){

       /*
        * Number of arguments in the go command
        */
       int numberOfArguments = event.getNumberOfArguments();

       /*
        * To call "go" on a specific
        * component, pass in the
        * name of the component.
        * The instance
        * name is usually the name of the component's
        * java class (without the package name)
        * concatenated with an index number.
        * EXAMPLE:  "StarterComponent0"
        */
       String componentInstanceName = event.getComponentInstanceName();

        /*
         * To call "go" on a specific
         * "go" port on a specific component,
         * pass in the
         * name of the "go" port.
         */
         String portInstanceName = event.getPortInstanceName();

         /* create the command */
         StringBuffer command = new StringBuffer("go");

         if (numberOfArguments > 0) {
           command.append(" ");
           command.append(componentInstanceName);
         }

         if (numberOfArguments > 1) {
           command.append(" ");
           command.append(portInstanceName);
         }


          /* send the "go" command to the cca server */
          this.write(command.toString());
     }








    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


     /**
      * The end-user, via the GUI, wants to retrieve
      * a cca component.  A view entity might respond
      * by sending a "pull down" message to the cca server.
      * @param event
      */
     public void instantiate(InstantiateEvent event) {

       /*
        * The name of the component's class.
        * The name is actually the name of the component's
        * java class.
        * EXAMPLE: "gov.sandia.ccaffeine.dc.component.PrinterComponent"
        */
        String className = event.getClassName();

       /*
        * The name of the
        * cca component object.  The instance
        * name is usually the name of the component's
        * java class (without the package name)
        * concatenated with an index number.
        * EXAMPLE:  "StarterComponent0"
        */
        String instanceName = event.getInstanceName();

        /*
         construct the command that we will send
         to the cca server
         */
        String command = "instantiate " + className + " " + instanceName;

        /* send the command to the cca server */
        this.write(command);
     }







    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


     /*
      * The end-user, via the GUI, wants to connect
      * the Provides Port of a cca component to a
      * Uses Port.  The Uses Port may be from the
      * same component or may be from a different component.
      * A view entity might
      * respond by sending a "connect" message to the
      * cca server.
      * @param event The event that is sent whenever
      * an entity wants to connect a Uses Port with a
      * Provides Port.
      */
     public void connect(ConnectEvent event){

       /*
        * This is the name of the component that houses the
        * source port.  The source port is one of the two
        * connected ports.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
        String sourceComponentName = event.getSourceComponentName();

        /**
         * This is the name of the source port.
         * The source port is connected to the target port.
         * Example:  "out0"
         */
         String sourcePortName = event.getSourcePortName();

         /*
          * The name of the component that houses the target port.
          * The target port is one of the two connected ports.
          * The name is usually the java class name of the component
          * (without the package name) concatenated with an index number.
          * Example:  "PrinterComponent0"
          */
          String targetComponentName = event.getTargetComponentName();

          /*
           * This is the name of the target port.
           * The target port is connected to the source port.
           * Example:  "printer_port"
           */
           String targetPortName = event.getTargetPortName();

           /*
            * Construct the command that we will
            * send to the cca server.
            */
           String command =
               "connect "
               + sourceComponentName + " "
               + sourcePortName + " "
               + targetComponentName + " "
               + targetPortName;

           /* send the command */
           write(command);
     }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


     /*
      * The end-user, via the GUI, wants to disconnect
      * a connection between
      * a Provides Port of a cca component and a
      * Uses Port.
      * A view entity might
      * respond by sending a "disconnect" message to the
      * cca server.
      * @param event The event that is sent whenever
      * an entity wants to disconnect the connection between
      * a Uses Port with a
      * Provides Port.
      */
     public void disconnect(DisconnectEvent event){

       /*
        * This is the name of the component that houses the
        * source port.  The source port is one of the two
        * connected ports.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
        String sourceComponentName = event.getSourceComponentName();

        /**
         * This is the name of the source port.
         * The source port is connected to the target port.
         * Example:  "out0"
         */
         String sourcePortName = event.getSourcePortName();

         /*
          * The name of the component that houses the target port.
          * The target port is one of the two connected ports.
          * The name is usually the java class name of the component
          * (without the package name) concatenated with an index number.
          * Example:  "PrinterComponent0"
          */
          String targetComponentName = event.getTargetComponentName();

          /*
           * This is the name of the target port.
           * The target port is connected to the source port.
           * Example:  "printer_port"
           */
           String targetPortName = event.getTargetPortName();

           /*
            * Construct the command that we will
            * send to the cca server.
            */
           String command =
               "disconnect "
               + sourceComponentName + " "
               + sourcePortName + " "
               + targetComponentName + " "
               + targetPortName;

           /* send the command */
           write(command);
     }










    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * An entity wants
     * to get all of the instantiated cca components.
     * A view entity
     * might respond by sending an "arena"
     * or an "instances" message to the cca server.
     * @param event That event that is generated
     * whenever an entity wants to get all of the
     * instantiated cca components.
     */
    public void getAllInstancesInArena(GetInstancesEvent event){
        write("arena");
    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * The end-user, via the GUI, wants to set
     * the value of one of the
     * data fields.  A view entity might
     * respond by sending a "config" or a "parameters" message
     * to the cca server.
     * @param event The event that is generated
     * whenever an entity wants to set the value of
     * a data field.
     */
     public void setPortParameter(ParamCurrentEvent event){

       /*
        * The name of the cca component that contains
        * the port which contains the data field.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = event.getComponentInstanceName();

        /**
         * The name of the port that contains the data field.
         *  Example: "configure_port"
         */
         String portInstanceName = event.getPortInstanceName();

         /**
          * The name of a data field.
          */
          String dataFieldName = event.getDataFieldName();

          /*
           * The cca server is sending this value
           * of a data field to this client.
           */
           String dataFieldValue = event.getDataFieldValue();

           /*
            * Create the command that we will
            * send to the cca server
            */
           String command =
               "parameters "
               + componentInstanceName + " "
               + portInstanceName + " "
               + dataFieldName + " "
               + dataFieldValue;

           /* send the command to the cca server */
           write(command);
     }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/




    /**
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * An entity wants to get the value of one of the
     * data fields.  A view entity might
     * respond by sending a "configure" or a "parameters"
     * message to the cca server.
     * @param event The event that is generated whenever
     * an entity wans the value of one of the data fields.
     */
    public void getPortParameter(ParamGetCurrentEvent event){

      /*
       * The name of the cca component that contains
       * the port which contains the data field.
       * The name is usually the java class name of the component
       * (without the package name) concatenated with an index number.
       * Example:  "TimeStamper0"
       */
       String componentInstanceName =
          event.getComponentInstanceName();

      /**
       * The name of the port that contains the data field.
       *  Example: "configure_port"
       */
       String portInstanceName = event.GetPortInstanceName();


       /**
        * The name of a data field.
        */
        String dataFieldName = event.getDataFieldName();


        /*
         * Create the command that we want to send
         * to the cca server.
         */
        String command = "parameters "
                       +  componentInstanceName + " "
                       + portInstanceName + " "
                       + dataFieldName;

         /* send the command to the cca server */
         write(command);
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Retrieve the value of a component
     * property or set the value of a component
     * property.
     * <p>
     * A view entity might
     * respond by either displaying the current
     * value of a component property or by setting the value
     * of a component property.
     * <p>
     * An example of a component property is the "name"
     * of the component.
     * @param event The event that is generated
     * whenever an entity wants to either get or
     * set the value of a component property.
     */
    public void componentProperties(ComponentPropertiesEvent event){

       /*
        * The number of arguments in the "property"
        * command.
        */
       int numberOfArguments = event.getNumberOfArguments();

       /**
        * The name of the component that contains the property
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
       String componentInstanceName = event.getComponentInstanceName();

       /*
        * If we are getting or setting the value
        * of a specific property then we need the
        * name of the property.
        */
       String propertyName = event.getPropertyName();

       /*
        * If we are setting the value of a
        * property then we need the new value.
        */
        String propertyValue = event.getPropertyValue();

        /* create the command */
        StringBuffer command = new StringBuffer("property");
        if (numberOfArguments>0) {
            command.append(" ");
            command.append(componentInstanceName);
        }
        if (numberOfArguments>1) {
            command.append(" ");
            command.append(propertyName);
        }
        if (numberOfArguments>2) {
            command.append(" ");
            command.append(propertyValue);
        }

         /* send the command to the cca server */
        write(command.toString());

     }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/




    /**
     * Cca components contain ports.
     * Some of the ports contain data fields.
     * An entity wants to get the value of one of the
     * data fields.  A view entity might
     * respond by sending a "configure" or a "parameters"
     * message to the cca server.
     * @param event The event that is generated whenever
     * an entity wans the value of one of the data fields.
     */
    public void portParameter(ParamEvent event){

      /*
       * The number of arguments.
       *
       * If we are tying to get the value of a
       * parameter then we need 3 arguments
       * (instanceName, portName, parameterName).
       * If we are trying to set the value of a
       * parameter then we need 4 arguments
       */
       int numberOfArguments = event.getNumberOfArguments();

      /*
       * The name of the cca component that contains
       * the port which contains the data field.
       * The name is usually the java class name of the component
       * (without the package name) concatenated with an index number.
       * Example:  "TimeStamper0"
       */
       String componentInstanceName =
          event.getComponentInstanceName();

      /**
       * The name of the port that contains the data field.
       *  Example: "configure_port"
       */
       String portInstanceName = event.getPortInstanceName();




       /**
        * The name of a data field.
        */
        String dataFieldName = event.getDataFieldName();

        /**
         * The vzlue of a data field.
         */
        String dataFieldValue = event.getDataFieldValue();


        /*
         * Create the command that we want to send
         * to the cca server.
         */
        StringBuffer command = new StringBuffer("parameters");
        if (componentInstanceName!=null) {
          command.append(" " + componentInstanceName);
          if (portInstanceName!=null) {
              command.append(" " + portInstanceName);
              if (dataFieldName!=null) {
                  command.append(" " + dataFieldName);
                  if (dataFieldValue!=null) {
                      command.append(" " + dataFieldValue);
                  }
              }
          }
        }

         /* send the command to the cca server */
         write(command.toString());
    }







    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Tell all GuiListeners that an entity
     * wants the debugging turned on.
     * A view might respond by sending either a
     * "debug" or "noisy" command to the cca server.
     * @event The event that is generated whenever
     * an entity wants the debugging turned on.
     */
    public void setDebug(SetDebugEvent event) {
        write("debug");
    }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Tell all GuiListeners that an entity
     * wants the debugging turned off.
     * A view might respond by sending either a
     * "nodebug" or "quiet" command to the cca server.
     * @event The event that is generated whenever
     * an entity wants the debugging turned on.
     */
    public void setNoDebug(SetDebugEvent event) {
        write("nodebug");
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/





    /**
     * Request some information from the server.
     * We can
     * request the following info: <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display palette <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display arena <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display chain <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display component <br>
     * &nbsp;&nbsp;&nbsp;&nbsp;display state <br>
     * <p>
     * If the GUI wants to get information on the components
     * that are in the palette, or on the components that are
     * in the arena, or on the connections that are established
     * inside the arena, or on a particular component, or on
     * the components and the connections that are in the arena,
     * then the GUI will encapsulate the request as a DisplayEvent
     * and will then invoke this method.  This method will send
     * the request to the cca server.
     * @param DisplayEvent The event that is
     * generated whenever an entity is requesting
     * some information from the server.
     */
    public void display(DisplayEvent event){


      /*
       * The number of arguments
       * in the request string.
       */
      int numberOfArguments = event.getNumberOfArguments();

      /*
       * We are requesting info
       * on which entity?  We can
       * request info on the PALETTE,
       * ARENA, CHAIN, COMPONENT,
       * STATE.
       */
       String entity = event.getEntity();

      /*
       * If an entity wants some info on
       * a particular component, then that
       * entity has to supply the name of
       * the component.
       * The instance
       * name is usually the name of the component's
       * java class (without the package name)
       * concatenated with an index number.
       * EXAMPLE:  "StarterComponent0"
       */
      String componentInstanceName = event.getComponentInstanceName();

      String command =
          "display "
          + entity;
      if (componentInstanceName!=null)
          command = command + " " + componentInstanceName;
      write(command);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Tell all GuiListeners that an entity
     * wants wants to know what components
     * are in the palette.  A palette is a menu of
     * cca components; the end-user can drag components
     * from the palette to the arena (workspace).
     * A view might respond
     * by rending icons in the palette.  The end-user
     * can drag icons from the palette onto the
     * main workspace (the arena).
     * @param event The event that is generated whenever
     * an entity wants to know what components
     * are in the palette.
     */
    public void displayPalette(DisplayPaletteEvent event){
        write("display pallet");
    }















      /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



  /** Tell all GuiListeners
   * that an entity wants to know what connections
   * are in the arena.  The arena is the workspace
   * canvas; the end-user can drag components
   * from the palette to the arena.  The end-user
   * can connect components by drawing lines
   * between the components.
   * A view might respond
   * drawing a line between two components
   * that are rendered inside the main
   * workspace (the arena).
   */
  public void links(DisplayChainEvent event){
      write("links");
  }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Tell all GuiListeners
     * that an entity wants some information on a
     * cca component.
     * A view might respond by rendering a cca
     * component in the main workspace (the arena).
     * The end-user can drag the component to a
     * new location, remove the component, draw a
     * line to/from a different component, view or
     * edit the component's properties, etc.
     * @param source The entity that created this event.
     * @param componentInstanceName
     * The name of the
     * cca component object.  The instance
     * name is usually the name of the component's
     * java class (without the package name)
     * concatenated with an index number.
     * EXAMPLE:  "StarterComponent0"
     * @param event The event that is created whenever
     * an entity wants some information on a cca component.
     */
    public void displayComponent(DisplayComponentEvent event){

      /*
       * The name of the
       * cca component object.  The instance
       * name is usually the name of the component's
       * java class (without the package name)
       * concatenated with an index number.
       * EXAMPLE:  "StarterComponent0"
       */
       String componentInstanceName = event.getComponentInstanceName();

       /* Create the command that we will send to the cca server */
       String command = "display component " + componentInstanceName;

       /* Send the command to the cca server */
       write(command);

    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

  /**
   * Notify all GuiListeners
   * that an entity wants to know what components
   * are in the arena and what connections exist
   * between the components.  The arena is the workspace
   * canvas; the end-user can drag components
   * from the palette to the arena.  The end-user
   * can connect components by drawing lines
   * between the components.
   * A view might respond
   * by rendering cca components in the main
   * workspace (the arena) and by rendering lines between
   * components that are connected togeter.  The
   * end-user can drag components to a new location,
   * remove components, draw lines between
   * components, view or edit the properties of
   * components, etc.
   * @param source The entity that created this event.
   */
    public void displayState(DisplayStateEvent event) {

        write("display state");

    }




    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Notify all GuiListeners that this entity
     * wants to invoke the "go" command
     * on a specific port that is located
     * on a specific component.  A view might
     * respond by sending a "go" or a "run" message
     * to the cca server.
     * @param event The event that is generated whenever
     * an entity wants to invoke the "go" command.
     */
    public void goComponentPort(GoComponentPortEvent event) {

      /*
       * The name of the
       * cca component object.  The instance
       * name is usually the name of the component's
       * java class (without the package name)
       * concatenated with an index number.
       * EXAMPLE:  "StarterComponent0"
       */
       String componentInstanceName = event.getComponentInstanceName();

       /**
        * The name of the GO port.
        */
        String portInstanceName = event.getPortInstanceName();

        /* Create the command that we will send to the cca server */
        String command = "go " + componentInstanceName + " " + portInstanceName;


        /* Send the command to the cca server */
        write(command);
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


  /**
   * Notify all GuiListeners
   * that an entity wants to
   * delete all components.
   * A view might respond by
   * sending a "nuke" message
   * to the cca server.
   * param event The event that is created
   * when an entity wants to to delete
   * all components.
   */
    public void nukeAll(NukeAllEvent event) {

      /*
       * The number of arguments in the nuke command
       */
      int numberOfArguments = event.getNumberOfArguments();

      /**
       * The entity that is to be removed.
       * NOTE:  As of Oct 2003, "all" is the
       * only entity that can be nuked.
       */
      String entity = event.getEntity();

      /* construct the command */
      StringBuffer command = new StringBuffer("nuke");
      if (numberOfArguments>0) {
          command.append(" ");
          command.append(entity);
      }

      write(command.toString());
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Retrieve the value of a port
     * property or set the value of a port
     * property.
     * A view entity might
     * respond by either displaying the current
     * value of a port property or by setting the value
     * of a port property.
     * @param event The event that is generated
     * whenever an entity wants to either get or
     * set the value of a port property.
     */
     public void portProperties(PortPropertiesEvent event){


       /*
        * The number of arguments in the "port-property"
        * command.
        */
       int numberOfArguments = event.getNumberOfArguments();

       /**
        * The name of the component that contains the property
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "StartComponent0"
        */
       String componentInstanceName = event.getComponentInstanceName();

       /*
        * The name of the port that contains the property
        */
       String portName = event.getPortName();

       /*
        * If we are getting or setting the value
        * of a specific property then we need the
        * name of the property.
        */
       String propertyName = event.getPropertyName();

       /**
        * If we are setting the value of a
        * property then we need the datatype
        * of the value.
        */
       String dataTypeOfPropertyValue = event.getDataTypeOfPropertyValue();

       /*
        * If we are setting the value of a
        * property then we need the new value.
        */
       String propertyValue = event.getPropertyValue();

       /* create the command */
       StringBuffer command = new StringBuffer("port-property");
       if (numberOfArguments>0) {
           command.append(" ");
           command.append(componentInstanceName);
       }
       if (numberOfArguments>1){
       	    command.append(" ");
       	    command.append(portName);
       }
       if (numberOfArguments>2) {
           command.append(" ");
           command.append(propertyName);
       }
       if (numberOfArguments>3) {
           command.append(" ");
           command.append(dataTypeOfPropertyValue);
       }
       if (numberOfArguments>4) {
           command.append(" ");
           command.append(propertyValue);
       }

       /* send the command to the server */
       this.write(command.toString());

     }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



     /**
      * Notify all GuiListeners
      * that an entity wants the the cca server
      * to send the value of a
      * property that is inside a component.
      * A view entity might
      * respond by sending a "property"
      * message to the cca server.
      * @param event The event that is generated
      * whenever an entity wants the value of a
      * property that is inside a component.
      */
      public void getComponentProperty(GetComponentPropertyEvent event){


        /**
         * The name of the component that contains the property
         * The name is usually the java class name of the component
         * (without the package name) concatenated with an index number.
         * Example:  "StartComponent0"
         */
         String componentInstanceName = event.getComponentInstanceName();



         /*
          * The name of the property.
          */
          String propertyName = event.getPropertyName();

         /* Create the command that we will send to the cca server */
         String command = "property "
                        + componentInstanceName + " "
                        + propertyName;

         /* send the command to the cca server */
         write(command);

      }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Notify all GuiListeners that an entity
     * wants to set the value of a property that is inside
     * a cca component.  A view entity might respond
     * by sending a "properties" message to the cca server.
     * @param event The event that is created whenever
     * an entity wants to set the value of a property
     * that is inside a component.
     */
    public void setComponentProperty(SetComponentPropertyEvent event){

        /**
         * The name of the component that contains the property
         * The name is usually the java class name of the component
         * (without the package name) concatenated with an index number.
         * Example:  "StartComponent0"
         */
         String componentInstanceName = event.getComponentInstanceName();



         /*
          * The name of the property.
          */
          String propertyName = event.getPropertyName();


          /**
           * The value of the property.
           */
           String propertyValue = event.getPropertyValue();

         /* Create the command that we will send to the cca server */
         String command = "property "
                        + componentInstanceName + " "
                        + propertyName + " "
                        + propertyValue;

         /* send the command to the cca server */
         write(command);

    }















    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /**
     * Notify all GuiListeners that an entity
     * wants to send
     * a string to the cca server.
     * @param event The event that is created
     * whenever an entity wants to send
     * a string to the cca server.
     */
    public void sendMessage(StringEvent event){

      /*
       * The string that we want to send to the cca server
       */
       String message = event.getMessage();

       /* send the message */
       write(message);


    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Notify all GuiListeners that an entity
     * wants to
     * emit a heartbeat.
     * A view might respond by sending
     * a heartbeat to the cca srever.
     * @param event The event that is fabricated
     * whenever an entity wants to emit a heartbeat.
     */
    public void heartbeat(HeartbeatEvent event) {
        write("heartbeat");
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



  /**
   * Notify all GuiListeners
   * that an entity wants the application to exit.
   * A view might respond by sending a "exit"
   * message to the cca server.
   * @param event The event that is generated whenever
   * an entity wants to exit the application.
   */
    public void exit(ExitEvent event){
        write("exit");
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/




    /**
     * Tell the cca server to change the
     * path or tell the cca server to
     * retrieve the path.
     * @param event The event that is
     * generated whenever an entity
     * wants either to set the path
     * to a new value or to query
     * for the path value.
     */
    public void path(PathEvent event){

      /*
       * The number of arguments
       * in the path command.
       */
      int numberOfArguments = event.getNumberOfArguments();

      /*
       * To alter the path,
       * specify how
       * the path is to be changed
       * by issuing
       * any of the following commands:
       * INIT, APPEND, PREPEND, SET
       */
      String commandToAlterPath = event.getCommandToAlterPath();

      /**
       * To alter the path,
       * specify the new
       * path value.
       */
      String directory = event.getDirectory();

      /* create the command that we will send to the cca server */
      StringBuffer command =  new StringBuffer("path");
      if (numberOfArguments>0) {
          command.append(" ");
          command.append(commandToAlterPath);
      }
      if (numberOfArguments>1) {
          command.append(" ");
          command.append(directory);
      }

      write(command.toString());
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Send a query to the cca server.
     * The query is a request either for a list of
     * all components that are in the repository or for
     * one specific component that is in the repository.
     * @param event The event that is created whenever
     * an entity wants to get one component or all components
     * from the repository,
     */
    public void repository(RepositoryEvent event){

      /*
       * The number of arguments in the "repository" command
       */
      int numberOfArguments = event.getNumberOfArguments();


      /*
       * The command.  The command can be one of the following
       * values:  LIST, GET, GET_GLOBAL, GET_LAZY, GET_LAZY_GLOBAL
       */
      String command = event.getCommand();


      /*
       * If we are retrieving the value of one class,
       * then we need the name of the class.
       */
      String className = event.getClassName();


      /* construct the command */
      StringBuffer buffer = new StringBuffer("repository");
      if (numberOfArguments>0) {
          buffer.append(" ");
          buffer.append(command);
      }
      if (numberOfArguments>1) {
          buffer.append(" ");
          buffer.append(className);
      }

      /* send the command to the server */
      write(buffer.toString());
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    /**
     * Send an O.S. command
     * to the cca server.
     * The cca server will execute the command.
     * @param event The event that is
     * created whenever an entity wants
     * an O.S. command executed.
     */
    public void shell(ShellEvent event){


      /* the number of arguments in the "shell" command */
      int numberOfArguments = event.getNumberOfArguments();

      /* The command that is to be executed */
      String command = event.getCommand();

      /* create the command */
      StringBuffer buffer = new StringBuffer("shell");
      if (numberOfArguments>0){
          buffer.append(" ");
          buffer.append(command);
      }

      /* send the command to the cca server */
      write(buffer.toString());



    }

}
