package gov.sandia.ccaffeine.dc.user_iface.gui;
import java.io.*;
import java.net.*;
import javax.swing.*;
import gov.sandia.ccaffeine.util.*;
import gov.sandia.ccaffeine.dc.user_iface.MVC.CanNotCommunicateWithCcaServerException;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ControllerSocket;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ControllerPython;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ViewSocket;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ViewPython;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ClientSocket;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.Gui;
import gov.sandia.ccaffeine.dc.user_iface.gui.GlobalData;
import gov.sandia.ccaffeine.dc.user_iface.AccessServer;
import gov.sandia.ccaffeine.dc.user_iface.MVC.PythonStub;

import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;
import java.awt.Font; 

/**
 * AppFrame.java
 */

public class AppFrame extends JFrame {
  public AppFrame(String[] argv) {
    args.parseArgs(argv);
    System.err.println("args.filename = "+args.fileName);


    /**
     * If the font size multiplier is NOT 1.0
     * then, for every component, multiply the component's default
     * font size with the multiplier.  For example, to double
     * the font size of every compnent, set scaleFont to 2.
     */
    if (args.scaleFont !=1.0){
        scaleFontSizeOfEveryComponent(args.scaleFont );
    } 

    setSize(900,650);
    setTitle("Common Component Architecture");
    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    JDesktopPane desktop = new JDesktopPane();


        //builder = new Builder(in, out,(java.awt.Container)this);
        builder = new Builder((java.awt.Container)this);


    ClientSocket clientSocket = connectDefault();
    
    /* if we are talking to a python server, then we need the python's stub */
    PythonStub pythonStub = null;    
    
    
    /* are we connecting to a python server? */
    if (args.serverIsPython) {
        pythonStub = new PythonStub();
		try {
			pythonStub.openSessionWithCcaServer(clientSocket);
		} catch (CanNotCommunicateWithCcaServerException e) {
		      LocalSystem.err.println("Exception attempting to connect to host: "+
				      args.hostName+" port: "+args.builderPort);
	          e.printStackTrace(LocalSystem.out);
	          LocalSystem.exit(-1);
	          return;
		}
    }    


    if (args.serverIsPython) {
        ViewPython viewPython = new ViewPython(pythonStub);
        builder.addGuiListener(viewPython);
      } else {
          ViewSocket viewSocket = new ViewSocket(clientSocket);
          builder.addGuiListener(viewSocket);
      }   

    builder.doStart();

    Gui gui = builder.getGui();


    if (args.serverIsPython) {
        ControllerPython controllerPython = new ControllerPython(pythonStub);
        //pythonStub.addPythonServerListener(controllerPython);
        controllerPython.addAccessGuiListener(gui);
        controllerPython.addControllerListener(gui);
    } else {
      ControllerSocket controllerSocket = new ControllerSocket(clientSocket);
      controllerSocket.addGuiUserListener(gui);
      controllerSocket.addControllerListener(gui);
      controllerSocket.parse();
    }

            
    desktop.add(builder);
    getContentPane().add(desktop);
    if(args.fileName != null) {
      builder.loadFile(args.fileName);
    }
    show();
    
    
  }








  /**
   * Scale the font size of every component.
   * For example, to double the font size of e
   * @param fontSizeMultiplier The new font size is
   * the default font size multiplied by this scaling factor.
   */
  protected static void scaleFontSizeOfEveryComponent(double fontSizeMultiplier) {
    java.util.Enumeration keys = UIManager.getDefaults().keys();
    while (keys.hasMoreElements()) {
      Object key = keys.nextElement();
      Object value = UIManager.get (key);
      if (value instanceof javax.swing.plaf.FontUIResource) {
        FontUIResource fontUIResource = (FontUIResource)value;
        String name = fontUIResource.getName();
        int style = fontUIResource.getStyle();
        int size = fontUIResource.getSize();
        size = (int)Math.round((double)size * fontSizeMultiplier);
        //Font font = fontUIResource.deriveFont(size);
        //fontUIResource = new FontUIResource(font);           
        fontUIResource = new FontUIResource(name, style, size);
        UIManager.put (key, fontUIResource);
      }//if
    }//while
  }//method 



  public static final void main(String[] args){
    AppFrame af = new AppFrame(args);
  }




  private ClientSocket connectDefault(){
    try{

      //Socket socket = new Socket(args.hostName, args.builderPort);
      //in  = socket.getInputStream();
      //out = socket.getOutputStream();
      ClientSocket clientSocket = new ClientSocket();
      clientSocket.open(args.hostName, args.builderPort);
      return(clientSocket);


    } catch(Exception e){
      LocalSystem.err.println("Exception attempting to connect to host: "+
			      args.hostName+" port: "+args.builderPort);
      e.printStackTrace(LocalSystem.out);
      LocalSystem.exit(-1);
    }
    return(null); //we will never reach this statement
  }



  private ClientSocket connectInteractive(){
    String messageString = "Please enter host address";

    boolean unconnected = true;
    while(unconnected){
      String addressString = "";
      JOptionPane.showInputDialog(messageString);
      if(addressString == null)
	System.exit(0); // Canceled
      try{
	//InetAddress address = InetAddress.getByName(addressString);
	//Socket socket = new Socket(address,2023);
	//socket.setSoTimeout(5000);
	//in  = socket.getInputStream();
	//out = socket.getOutputStream();
	unconnected = false;
        ClientSocket clientSocket = new ClientSocket();
        clientSocket.open(addressString, 2023);
        return(clientSocket);


      //} catch(UnknownHostException e){
      //  messageString = "Unknown host. Please try again.";
      } catch (java.net.ConnectException e) {
          messageString = e.getMessage();
      } catch(IOException e){
	messageString = "I/O Error. Please try again.";
      } // try
    }
    return(null);//we will never reach this statement
  }



  //private InputStream   in;
  //private OutputStream out;
  private Args args = new Args("AppFrame");
  private Builder builder;

} // AppFrame
