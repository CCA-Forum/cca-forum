package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotFixSharedLibraryException extends Exception {
    public CanNotFixSharedLibraryException() {
        super();
    }
    public CanNotFixSharedLibraryException(String message) {
        super(message);
    }

}