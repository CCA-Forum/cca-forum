package gov.sandia.ccaffeine.dc.user_iface.applet;

import java.net.*;
import java.io.*;


/** A confusing name: RemoteServer is an object that <em> stands </em>


    for a Remote server.  */



public class RemoteServer{


    /* number of times we try to connect to the cca MUXER */
    protected final int numberOfTimesWeTryToConnectToCca = 2;

    /* number of milliseconds between connection attempts */
    protected final long numberOfMillisecondsBetweenConnectionAttempts = 500;


  private String host = "localhost";
  private int serverPort = 2024; // A default chosen by Colin.
  private InetAddress addr;
  private OutputStream out = null;
  private InputStream in = null;
  protected int timeout = 0;

  public RemoteServer() {
  }




  /**
   * Connect to the cca MUXER.
   * If a connection can not be established
   * then throw an excpetion
   * WARNING:  Depending on the settings of the
   * numberOfTimesWeTryToConnectToCca attribute
   * and the numberOfMillisecondsBetweenConnectionAttempts
   * attribute, this method could take several seconds
   * to complete.
   * @exception Throws ConnectionExcpetion
   * if a connection to the MUXER can NOT be established.
   */
  public void createConnection ()
         throws ConnectException {

            String errorMessage = "";


            for (int i=0; i<numberOfTimesWeTryToConnectToCca; i++) {

                System.out.println("connection attempt " + i);

                 try {
                     addr = InetAddress.getByName(host);
                } catch(Exception e) {
                 errorMessage =
                     "Exception in RemoteServer: problem "+
                     "with hostname: "+host+" Info: "+e;
                System.err.println(errorMessage);
                e.printStackTrace(System.err);
                System.out.println(errorMessage);
                throw new ConnectException(errorMessage);
                }//catch

                System.out.println("got host IP address");

                  if (in != null)
                     try { in.close();} catch(java.lang.Throwable e){}
                  in = null;
                  if (out != null)
                     try {out.close();} catch(java.lang.Throwable e){}
                  out = null;
                  try{
                      //Create a connection to the server.
                      Socket s = new Socket(addr, serverPort);
                      System.out.println("got a socket");
                      s.setSoTimeout(this.timeout);
                      System.out.println("set timeout");
                      out = s.getOutputStream();
                      if (out==null) throw new ConnectException("Can not connect to muxer");
                     System.out.println("got an output socket stream");
                      in = s.getInputStream();
                      if (in==null) throw new ConnectException("Can not connect to muxer");
                      System.out.println("got an input socket stream");
                } catch(java.lang.Throwable e) {
                     System.out.println("EXCEPTION:" + e);
                      errorMessage = "Exception in RemoteServer:"+e;
                      System.err.println(errorMessage);
                      //e.printStackTrace(LocalSystem.err);
                      if (in != null)
                         try { in.close();} catch(java.lang.Throwable e1){}
                      in = null;
                      if (out != null)
                         try {out.close();} catch(java.lang.Throwable e2){}
                      out = null;
                }//catch
                System.out.println("errorMessage="+errorMessage);

                /*
                Do we have a connection to the MUXER?
                If yes then mission accomplished.
                */
                if (errorMessage.equals("")){
                    return;
                }//if




                /*
                Are we wrapping up the last iteration?
                */
                if (i==numberOfTimesWeTryToConnectToCca-1)
                   break;



                /*
                sleep for a little while then try again
               */
               System.out.println("sleep");
                try {
                       Thread.currentThread().sleep(numberOfMillisecondsBetweenConnectionAttempts);
                }catch (java.lang.InterruptedException e) {}
                System.out.println("wake up");

            }//for


            /*
           Bummer.   We could not establish a connection to the Muxer.
           Send back an error message to the caller.
           */
           System.out.println("GIVE UP:  Throw an Exception");
           throw new ConnectException(errorMessage);



  }








  /** Set the host name for the server. */
  public void setHost(String host) {
    this.host = host;
  }




  /** Get the host name for the server. */
  public String getHost() {
    return host;
  }




  /** Set the port for the server. */
  public void setPort(int serverPort) {
    this.serverPort = serverPort;
  }




  /** Get the port for the server. */
  public int getPort() {
    return serverPort;
  }




  /** Get the OutputStream from the server. */
  public OutputStream getOutputStream() {
    return out;
  }




  /** Get the InputStream to the server.*/
  public InputStream getInputStream() {
    return in;
  }


  /**
   * Get the number of milliseconds a read operation
   * will wait.  A value of 0 means the socket
   * will wait forever.
   * @return The number of milliseconds a read operation
   * will wait.
   */
  public int getTimeout() {
      return(this.timeout);
  }

  /**
   * Set the number of milliseconds a read operation
   * will wait.  A value of 0 means the socket
   * will wait forever.
   * @parma timeout The number of milliseconds a read operation
   * will wait.
   */
  public void setTimeout(int timeout) {
      this.timeout = timeout;
  }

}
