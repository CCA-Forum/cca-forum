package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import java.io.*;
import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiUserListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ResultSetListener;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.PrintEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ExceptionEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.QueryEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ResultSetEvent;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.ThreadWaitForResultSet;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ControllerSocket;

public class CmdContextCcaOneCommand
       extends CmdContext {

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    String oneCommand = null;

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    public CmdContextCcaOneCommand(){
        this.oneCommand = null;
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /**
     * Set the command
     * @param oneCommand The command
     */
    public void setOneCommand(String oneCommand) {
        this.oneCommand = oneCommand;
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    public void pn(String s){
	this.broadcastPrintln(s);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    public void p(String s){
	this.broadcastPrint(s);
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    public String prompt() {
	return "\ncommand>";
    }


    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    public String readLine() throws IOException {

      /*
       The parser is going to continuously
       invoke this method until the parser sees EOF.
       We want the parse to read the "one command" only once.
       On the first iteration, we will return the "one command."
       On the 2nd iteration, we will return null (i.e. EOF).
       */
      String temp = oneCommand;
      oneCommand = null;
      return(temp);
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    /** Retrieve the Component Instance from the GUI */
    public String getInstance(String instanceName)
           throws java.lang.RuntimeException {

	//if(global.getArena().getComponentInstances().containsKey(instanceName))
	//    return instanceName;
	//return null;

        ThreadWaitForResultSet threadWaitForResultSet = null;

        try {

            /*
             It might take a long long long time
             before we a response from our query.
             Set up a thread so that we can wait.
             */
            threadWaitForResultSet = new ThreadWaitForResultSet();
            threadWaitForResultSet.setPriority(java.lang.Thread.NORM_PRIORITY + 1);
            threadWaitForResultSet.start();
            Thread.currentThread().yield(); //start the thread


            /* send the query */
            QueryEvent event = new QueryEvent
                (this,
                 instanceName,
                 threadWaitForResultSet);
            this.broadcastGetComponentInstanceEvent(event);

            /* Wait for a response */
            try {threadWaitForResultSet.join();}catch (java.lang.InterruptedException e){}

            /* Was an exception thrown? */
            ExceptionEvent exceptionEvent = threadWaitForResultSet.getExceptionEvent();
            if (exceptionEvent != null) {
                //got an error.  handle it.
                java.lang.Throwable exception = exceptionEvent.getException();
                throw new java.lang.RuntimeException
                    ("Error.  GUI did not send the instance name");

            }

            /* Retrieve the result set */
            ResultSetEvent resultSetEvent =
                threadWaitForResultSet.getResultSetEvent();
            if (resultSetEvent == null) {
                //got an error.  handle it.
                throw new java.lang.RuntimeException
                    ("Error.  GUI did not send the instance name");
            }

            /* We want the first object in the result set */
            /* A null object means the component instance does not exist */
            Object resultSet[] = resultSetEvent.getResultSet();
            Object temp = resultSet[0];
            if (temp==null) {
                return(null);
            }
            instanceName = (String)temp;

            /* return the retrieved value */
            return(instanceName);

        }finally {

            /* make sure the thread is garbage collected */
            threadWaitForResultSet = null;

        }
    }





    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    /** Retrieve the Component Class from the GUI */
    public String getClass(String className) throws java.lang.RuntimeException {

	//if(global.getPalette().getComponentClasses().containsKey(className))
	//    return className;
	//return null;

        ThreadWaitForResultSet threadWaitForResultSet = null;

        try {

            /*
             It might take a long long long time
             before we a response from our query.
             Set up a thread so that we can wait.
             */
            threadWaitForResultSet = new ThreadWaitForResultSet();
            threadWaitForResultSet.setPriority(java.lang.Thread.NORM_PRIORITY + 1);
            threadWaitForResultSet.start();
            Thread.currentThread().yield(); //start the thread


            /* send the query */
            QueryEvent event = new QueryEvent
                (this,
                 className,
                 threadWaitForResultSet);
            this.broadcastGetComponentClassEvent(event);

            /* Wait for a response */
            try {threadWaitForResultSet.join();}catch (java.lang.InterruptedException e){}

            /* Was an exception thrown? */
            ExceptionEvent exceptionEvent = threadWaitForResultSet.getExceptionEvent();
            if (exceptionEvent != null) {
                //got an error.  handle it.
                java.lang.Throwable exception = exceptionEvent.getException();
                throw new java.lang.RuntimeException(exception.getMessage());
            }

            /* Retrieve the result set */
            ResultSetEvent resultSetEvent =
                threadWaitForResultSet.getResultSetEvent();
            if (resultSetEvent == null) {
                //got an error.  handle it.
                throw new java.lang.RuntimeException
                    ("Error.  GUI did not send the class name");
            }

            /* We want the first object in the result set */
            /* A null object means the component instance does not exist */
            Object resultSet[] = resultSetEvent.getResultSet();
            Object temp = resultSet[0];
            if (temp==null) {
                return(null);
            }
            className = (String)temp;

            /* return the retrieved value */
            return(className);

        }finally {

            /* make sure the thread is garbage collected */
            threadWaitForResultSet = null;

        }
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


    java.util.Vector guiUserListeners = new Vector();

    synchronized public void addGuiUserListener(GuiUserListener listener) {
       guiUserListeners.add(listener);
    }

    synchronized public void removeGuiUserListener(GuiUserListener listener) {
        guiUserListeners.remove(listener);
    }

    protected void broadcastPrint(String message){
        PrintEvent event = new PrintEvent(this, message);
        broadcastPrintEvent(event);
    }

    protected void broadcastPrintEvent(PrintEvent event) {
       // loop through each listener and pass on the event if needed
       Vector listeners;
          synchronized (this) {
              listeners = (java.util.Vector)guiUserListeners.clone();
         }
         int numberOfListeners = listeners.size();
             for (int i=0; i<numberOfListeners; i++){
                 GuiUserListener x = (GuiUserListener)listeners.elementAt(i);
             x.print(event);
         }
    }


    protected void broadcastPrintln(String message){
        PrintEvent event = new PrintEvent(this, message);
        broadcastPrintlnEvent(event);
    }

    protected void broadcastPrintlnEvent(PrintEvent event) {
       // loop through each listener and pass on the event if needed
       Vector listeners;
          synchronized (this) {
              listeners = (Vector)guiUserListeners.clone();
         }
         int numberOfListeners = listeners.size();
             for (int i=0; i<numberOfListeners; i++){
                 GuiUserListener x = (GuiUserListener)listeners.elementAt(i);
             x.println(event);
         }
    }




    protected void broadcastGetComponentInstanceEvent(QueryEvent event) {
       // loop through each listener and pass on the event if needed
       Vector listeners;
          synchronized (this) {
              listeners = (Vector)guiUserListeners.clone();
         }
         int numberOfListeners = listeners.size();
             for (int i=0; i<numberOfListeners; i++){
                 GuiUserListener x = (GuiUserListener)listeners.elementAt(i);
             x.getComponentInstance(event);
         }
    }



    protected void broadcastGetComponentClassEvent(QueryEvent event) {
       // loop through each listener and pass on the event if needed
       Vector listeners;
          synchronized (this) {
              listeners = (Vector)guiUserListeners.clone();
         }
         int numberOfListeners = listeners.size();
             for (int i=0; i<numberOfListeners; i++){
                 GuiUserListener x = (GuiUserListener)listeners.elementAt(i);
             x.getComponentClass(event);
         }
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/




}



