package gov.sandia.ccaffeine.dc.distributed;

import java.net.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;

// this interface will be notified when a connection is 
// reconnected
interface ConnectionNotification {
    public void newConnect ( Connection newConnect );
}
