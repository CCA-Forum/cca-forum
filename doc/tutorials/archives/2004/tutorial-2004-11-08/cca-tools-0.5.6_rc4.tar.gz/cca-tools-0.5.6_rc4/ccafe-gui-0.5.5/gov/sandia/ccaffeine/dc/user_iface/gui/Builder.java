package gov.sandia.ccaffeine.dc.user_iface.gui;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import gov.sandia.ccaffeine.cmd.*;
import java.net.*;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ControllerSocket;
import gov.sandia.ccaffeine.dc.user_iface.MVC.ViewSocket;
import gov.sandia.ccaffeine.dc.user_iface.MVC.event.GuiListener;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.Gui;
import gov.sandia.ccaffeine.dc.user_iface.AccessServer;

/**
 * The parent of all classes in this group. The <code>
 * Builder</code> has three main components: an <code>Arena</code>,
 * a components palette, and an actions palette. Components are
 * dragged from the components palette and dropped into the
 * <code>Arena</code> to create a framework of
 * <code>ComponentInstance</code>s.
 */

public class Builder extends JInternalFrame
{



    /**
      * Creates a new Builder.
      */
    public Builder(Container container) {

        this(container, 0);
    }


    /**
      * Creates a new Builder.
      * You MUST invoke doStart() to launch the Builder.
      */
    public Builder(Container container,
                   int heartbeatPeriod) {
	super();
	//this.out = out;
	this.appContainer = container;
        this.heartbeatPeriod = heartbeatPeriod;
 	initialize();
 	//makeGUI();
	//syncWithFramework();

    }



    /**
     * Launch the Builder
     */
    public void doStart() {
      makeGUI();
      syncWithFramework();
    }




    private void initialize(){

	global        = new GlobalData(appContainer, this, heartbeatPeriod);

        gui           = new Gui(global);
        accessServer  = new AccessServer();

        arena         = new Arena(global);

 	actionsPanel  = new ActionsPanel(global);
        actionsPanel.addGuiUserListener(gui);

	palette       = new Palette(global);
	paletteHolder = new JScrollPane(palette);
	palette_Arena = new JPanel();
	menuBar       = new FileMenuBar(global);
        content       = (JPanel)getContentPane();

	setResizable(true);
	global.setIgnoreChanges(true);
	try{setMaximum(true);}catch(Exception e){}
	global.setIgnoreChanges(false);
	//setMaximizable(true);
	setIconifiable(true);
	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
	addInternalFrameListener(new InternalFrameAdapter() {
		public void internalFrameClosing(InternalFrameEvent e) {
		  if(actionsPanel.notCanceled("work unsaved, still want to quit?"))
			System.exit(0);
		}
	    });
	setSize(800,600);
	setVisible(true);
    }


    public void loadFile(String fileName) {
	try{
	    actionsPanel.loadFile(fileName);
	} catch(Exception e) {
	    System.err.println("Builder::loadFile: IO error");
	    e.printStackTrace(System.err);
	}
    }

    public void makeGUI(){
	setJMenuBar(menuBar);
	try{setSelected(true);}catch(Exception e){}

	palette_Arena.setLayout
	    (new BoxLayout(palette_Arena,BoxLayout.X_AXIS));
	content.setLayout
	    (new BoxLayout(content,BoxLayout.Y_AXIS));

	paletteScroll = new JScrollPane(palette);
	paletteScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
	paletteScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	paletteScroll.setPreferredSize(new Dimension(100, 600));

	arenaScroll = new JScrollPane(arena);
	arenaScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
	arenaScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	arenaScroll.setPreferredSize(new Dimension(700, 600));




	// Menu bar and buttons:
	content.add(actionsPanel);




	// Would like this adjustable by the user: use JSplitPane
	JSplitPane split_PA = new JSplitPane();
	split_PA.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
	split_PA.setLeftComponent(paletteScroll);
	split_PA.setRightComponent(arenaScroll);

 	JPanel hold = new JPanel(new BorderLayout());
 	hold.add(split_PA);
	content.add(hold);


	//	content.add(split_PA, BorderLayout.CENTER);

	//	content.add(split_PA);

// 	palette_Arena.add(paletteScroll);
//  	palette_Arena.add(arenaScroll);
// 	content.add(palette_Arena);

	//global.parse();
        //this.controllerSocket.parse();


	//global.write("display pallet");
        global.addToHistoryAndToDebugger("display pallet");
        this.accessServer.broadcastDisplayPalette();
    }

  /** Cause the remote framework to issue commands back to this GUI
      rebuilding all of the components and connections. */
    public void syncWithFramework() {
	//global.write("display state");
        global.addToHistoryAndToDebugger("display state");
        this.accessServer.broadcastDisplayState();
    }
    public void arrange(){
	validateTree();
    }

    public void setSize(String s){
	StringTokenizer tokens = new StringTokenizer(s);
	tokens.nextToken();
	int w = Integer.parseInt(tokens.nextToken());
	int h = Integer.parseInt(tokens.nextToken());
	setSize(w,h);
    }

    public void updateTitle(){
	setTitle(global.getTitle());
    }
    public void setIcon(boolean b) throws PropertyVetoException {
        if (isIcon == b) {
            return;
        }
	if(isIcon())
	    updateTitle();
	else
	    setTitle(global.getDocName().substring(0,global.getDocName().length()-4));
        Boolean oldValue = isIcon ? Boolean.TRUE : Boolean.FALSE;
        Boolean newValue = b ? Boolean.TRUE : Boolean.FALSE;
        fireVetoableChange(IS_ICON_PROPERTY, oldValue, newValue);
        isIcon = b;
        firePropertyChange(IS_ICON_PROPERTY, oldValue, newValue);
	if (b)
	  fireInternalFrameEvent(InternalFrameEvent.INTERNAL_FRAME_ICONIFIED);
	else
	  fireInternalFrameEvent(InternalFrameEvent.INTERNAL_FRAME_DEICONIFIED);
    }
    public void setMaximum(String s){
	StringTokenizer tokens = new StringTokenizer(s);
	tokens.nextToken();
	boolean bool = Boolean.valueOf(tokens.nextToken()).booleanValue();
	try{setMaximum(bool);}catch(Exception e){}
    }
    public void setMaximum(boolean b) throws PropertyVetoException {
        if (isMaximum == b) {
            return;
        }
        Boolean oldValue = isMaximum ? Boolean.TRUE : Boolean.FALSE;
        Boolean newValue = b ? Boolean.TRUE : Boolean.FALSE;
        fireVetoableChange(IS_MAXIMUM_PROPERTY, oldValue, newValue);
        isMaximum = b;
        firePropertyChange(IS_MAXIMUM_PROPERTY, oldValue, newValue);
	global.informOfChange();
    }

    //This group is for communication
    //private OutputStream             out;

    //This group deals with GUI and layout
    private Container       appContainer;
    private GlobalData            global;
    private Arena                  arena;
    private JPanel               content;
  private JScrollPane paletteHolder;
    private JPanel         palette_Arena;
  //    private JPanel         palette_Arena;
    private Palette              palette;
    private FileMenuBar          menuBar;
    private ActionsPanel    actionsPanel;
    private JScrollPane    paletteScroll;
    private JScrollPane    arenaScroll;

    protected int heartbeatPeriod = 0;

    protected Gui gui = null;
    protected AccessServer accessServer = null;


    /**
    Get the period (1/frequency) of the heartbeat.
    This is the number of milliseconds between heartbeats.
    @return The period of the heartbeat
    */
    synchronized public int getHeartbeatPeriod() {
        return(this.heartbeatPeriod);
    }

    /**
    Set the period (1/frequency) of the heartbeat.
    This is the number of seconds between heartbeats.
    @param heartbeatPeriod The period of the hearbeat.
    */
    synchronized public void setHeartbeatPeriod(int heartbeatPeriod) {
        this.heartbeatPeriod = heartbeatPeriod;
    }



    /**
     * Retrieve the global data store.
     * @return Global data store.
     */
    public GlobalData getGlobal() {
        return(this.global);
    }


    public Gui getGui() {
        return(this.gui);
    }

    public AccessServer getAccessServer() {
        return(this.accessServer);
    }



    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/



    synchronized public void addGuiListener(GuiListener listener) {
        this.actionsPanel.addGuiListener(listener);
        this.gui.addGuiListener(listener);
        this.accessServer.addGuiListener(listener);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    synchronized public void removeGuiListener(GuiListener listener) {
        this.actionsPanel.removeGuiListener(listener);
        this.gui.removeGuiListener(listener);
        this.accessServer.removeGuiListener(listener);
    }

    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/


}


