package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotGetPortParametersException extends Exception {

  public CanNotGetPortParametersException() {
      super();
  }

  public CanNotGetPortParametersException(String message) {
      super(message);
  }


}