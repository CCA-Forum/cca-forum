package gov.sandia.ccaffeine.dc.distributed;

import gov.sandia.ccaffeine.util.*;
import java.net.*;
import java.io.*;
import java.util.*;


public class StaticIOConnection implements Connection {
    InputStream inStream;
    OutputStream outStream;
    int id;
    String name;
    public StaticIOConnection( InputStream inStream, OutputStream outStream, String name, int id) {
	this.inStream = inStream;
	this.outStream = outStream;
	this.id = id;
	this.name = name;
    }
    public StaticIOConnection( InputStream inStream, OutputStream outStream, int id) {
	this.inStream = inStream;
	this.outStream = outStream;
	this.id = id;
	this.name = "IOConnection:" + id;
    }

    public String getSourceName() { return name; }
    public InputStream getIn() { return inStream; }
    public OutputStream getOut() { return outStream; }
    public int getId() { return id; }
    public boolean isDisabled() { return false; }
    public void reconnect(int timeout) throws Exception{		
	throw new RuntimeException("Cannot reconnect to client " + id + " static IO connection only");
    } 
    public void disconnect() throws IOException { 
	inStream.close(); 
	outStream.close();
    }
    public ConnectionManager getConnectionManager () {
	return null;
    }
}
