package gov.sandia.ccaffeine.dc.distributed;

import java.net.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;


interface ConnectionManager {
    
    // establish all known connections
    public void connect(int timeout);
    
    public boolean isConnected();

    // connects to any disconnected connections still present 
    public void reconnect(int timeout) throws Exception; 

    // gets the array of connection objects
    public Vector getConnections();

    // gets the number of connections we expect to 
    // be transmitting data currently
    public int getNumConnected();
 
    // setup a callback so that we are notified when connections
    // are established
    public void setConnectionNotification (ConnectionNotification notif);

    // close the server socket and any remaining connections
    public void shutdown() throws IOException;
}

