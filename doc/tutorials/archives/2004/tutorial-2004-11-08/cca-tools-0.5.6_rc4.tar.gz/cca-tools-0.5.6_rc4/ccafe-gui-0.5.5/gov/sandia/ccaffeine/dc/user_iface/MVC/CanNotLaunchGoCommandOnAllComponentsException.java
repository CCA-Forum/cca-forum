package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotLaunchGoCommandOnAllComponentsException extends Exception {

    public CanNotLaunchGoCommandOnAllComponentsException() {
        super();
    }


    public CanNotLaunchGoCommandOnAllComponentsException(String message) {
        super(message);
    }


}