package gov.sandia.ccaffeine.dc.user_iface.gui;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import gov.sandia.ccaffeine.util.LocalSystem;


/**
 * A representation of a component which exists inside the arena.
 * An <code>ComponentInstance</code> is created when a drag operation
 * is performed from a <code>PaletteButton</code>
 * to an <code>Arena</code>.
 * <p>
 * Upon creation, a query is made to the <code>ConnectionFrameWork
 * </code> to retrieve port information (port quantities, class names,
 * instance names).
 * <p>
 * An <code>ComponentInstance</code> can be configured and connected to
 * other <code>ComponentInstance</code>'s by clicking on the buttons.
 */
public class ComponentInstance extends JPanel {
                                       //  implements ActionListener{

  /**
   * Creates a <code>ComponentInstance</code> instance with the
   * specified ID, name, and reference to super-parent.
   */
  public ComponentInstance(String classPath,
                           String name,
                           Point location,
                           GlobalData global) {
    super ();
    CLASSPATH = classPath;
    NAME = name;
    setLocation(location);
    this.global = global;
    initialize();
    prepareGUI();



    //global.write("display component " + name);
    global.addToHistoryAndToDebugger("display component " + name);
    global.getBuilder().getAccessServer().broadcastDisplayComponent(name);

  }

  private void initialize(){
    arena = global.getArena();
    builder = global.getBuilder();
    mousedragger = new MouseRectDragger();
    paramsToSave = new Hashtable();
    ports = new Hashtable();
    addMouseListener(mousedragger);
    int idx = CLASSPATH.lastIndexOf('.');
    setToolTipText(NAME + " (" + CLASSPATH.substring(idx+1) + ")");
    //setToolTipText(NAME + " (" + CLASSPATH + ")");
  }








  private void prepareGUI(){
    setBackground(Color.black);
    setLayout(new BorderLayout());
    JLabel label = new JLabel(NAME);
    label.setForeground(Color.white);
    label.setHorizontalAlignment(JLabel.CENTER);
    add(label, "South");
  }

  public void addProvidesPorts(Vector portvctr){
    for(int i = 0; i < portvctr.size() / 2; i++){
      String iname =(String)portvctr.elementAt(2 * i);
      String cname =(String)portvctr.elementAt(2 * i + 1);
      Port    port = new Port(i, Port.INPORT,
                              iname, cname, this, global);
      //      port.addActionListener(this);
      ports.put(iname, port);
      this.global.pn("gui:added provides ports to component");
    }
  }

  public void addUsesPorts(Vector portvctr){
    for(int i = 0; i < portvctr.size() / 2; i++){
      String iname =(String)portvctr.elementAt(2 * i);
      String cname =(String)portvctr.elementAt(2 * i + 1);
      Port    port = new Port(i, Port.OUTPORT,
                              iname, cname, this, global);
      //      port.addActionListener(this);
      ports.put(iname, port);
    }
    putPortsInPanels();
    setSize(getPreferredSize());
    validateTree();
    updateConnections();
    if(arena.getSelectedComponentInstance() == this)
      beSelected(true);
    else
      beSelected(false);
    global.setWaitingForPorts(false);
    global.pn("gui:added uses ports to component");
    global.pn("gui:component built, clear WaitingForPorts flag");
    }

  public void putPortsInPanels(){
    inPanel  = new JPanel();
    outPanel = new JPanel();
    inPanel.setBackground(Color.black);
    outPanel.setBackground(Color.black);
    add( inPanel, "West");
    add(outPanel, "East");
        add( inPanel, "West");
        add(outPanel, "East");
        int rows = Math.max(getInPortCount(),getOutPortCount());
        //pn("rows = "+rows);
        inPanel.setLayout (new GridLayout(rows, 1));
        outPanel.setLayout(new GridLayout(rows, 1));
        // gonna rebuiild a list just like on the framework side of the world.
        int listSize = ports.size(); // baa
        int inCount = 0 ; // baa
        int outCount = 0 ; // baa
        Vector inList = new Vector(listSize); // baa
        Vector outList = new Vector(listSize); // baa
        inList.setSize(listSize); // baa
        outList.setSize(listSize); // baa
        for(Enumeration e = ports.elements(); e.hasMoreElements();){
            Port port = (Port)e.nextElement();
            int  side = port.getSide();
            if(side == Port.INPORT ){
                inList.set(port.getInitialIndex(), port);
                // global.write("#DEBUG inCount " + inCount + "index " + port.getInitialIndex()); //baa
                inCount++;
//                int place = inPanel.getComponentCount();
//                while( port.getInitialIndex() < place )
//                    place--; // FIXME
//                inPanel.add(port, place);
            } else {
               outList.set(port.getInitialIndex(), port);
               // global.write("#DEBUG outCount " + outCount + "index " + port.getInitialIndex()); //baa
               outCount++;
//                int place = outPanel.getComponentCount();
//                while( port.getInitialIndex() < place )
//                    place--;
//                outPanel.add(port, place);
            }
        }
        for (int iin = 0; iin < inCount; iin++) { // baa
          Port port = (Port)inList.get(iin); // baa
          if (port == null) { // baa
            // whine // baa
            // global.write("# BUG in gui/ComponentInstance.java inpanel " + iin);
          } else { //baa
            // global.write("# ADD in gui/ComponentInstance.java inpanel" + port.getInitialIndex());
            inPanel.add(port,-1); // baa
          } // baa
        } // baa
        for (int iout = 0; iout < outCount; iout++) { // baa
          Port port = (Port)outList.get(iout); // baa
          if (port == null) { // baa
            // whine // baa
            //global.write("# BUG in gui/ComponentInstance.java outpanel" + iout + " missing.");
          } else { //baa
            //global.write("# DEBUG in gui/ComponentInstance.java outpanel" + iout + " thinks it is " + port.getInitialIndex());
            outPanel.add(port,-1); // baa
          } // baa
        } // baa
        if(outPanel.getComponentCount()==0)
            outPanel.add(new JLabel("            "));
        if(inPanel.getComponentCount()==0)
            inPanel.add(new JLabel("            "));
    }
    public void beSelected(boolean b){
        if(b == false){
            setBackground(Color.black);
            if(inPanel != null)
                inPanel.setBackground(Color.black);
            if(outPanel != null)
                outPanel.setBackground(Color.black);
            return;
        }
    if(arena.getSelectedComponentInstance() != null){
      arena.getSelectedComponentInstance().beSelected(false);
      arena.nullifySelectedComponentInstance();
    }
    arena.setSelectedComponentOffsets(getSize());
    arena.setSelectedComponentInstance(this);
    setBackground(Color.blue);
    inPanel.setBackground(Color.blue);
    outPanel.setBackground(Color.blue);
  }

  public void refreshPorts(){
    remove(inPanel);
    remove(outPanel);
    ports = new Hashtable();



    //global.write("display component " + NAME);
    global.addToHistoryAndToDebugger("display component " + NAME);
    global.getBuilder().getAccessServer().broadcastDisplayComponent(NAME);


  }


  /**
   * Reclaims all of this <code>ComponentInstance</code>'s connections.
   * After an <code>ComponentInstance</code> is moved, this will
   * point all of its connections to the new location.
   */
  public void updateConnections(){
    connectionCount = arena.getConnections().size();

    for(int i = 0; i < connectionCount; i++){
      thisConnection = (Connection)arena.getConnections().get(i);

      if(thisConnection.getSource() == this ||
         thisConnection.getTarget() == this    ){
        thisConnection.setPoints();
      }
    }
    arena.repaint();
  }

  /** Holds the mechanism to reduce the state of this
      ComponentInstance's state to a String.  The state is represented
      as a key/value pair suitable for setting properties on the
      remote framework.*/
  public class ComponentInstanceStateProperty {

    public ComponentInstanceStateProperty() {
    }
    /** Create the key for this ComponentInstance. */
    public String getKey() {
      return "gov.sandia.ccaffeine.dc.user_iface.gui."+
        "ComponentInstanceStateData."+
        ComponentInstance.this.getInstanceName();
    }
    /** Create the string representation of the Component instance
        state.  Right now just represents the position of the icon
        drawn on the Arena.*/
    public String getValue() {
      Point where = ComponentInstance.this.getLocation();
      return "Location:"+"x="+where.x+"y="+where.y;
    }
    /** Does the key identify state data belonging to this
        ComponentInstance? */
    public boolean isKey(String key) {
      int index = key.lastIndexOf('.');
      index++;
      String name = key.substring(index);
      return ComponentInstance.this.getInstanceName().compareTo(name) == 0;
    }
    /** Set the value of the state previously saved.  This causes the
        state of the ComponentInstance to be restored. */
    public void setValue(String value) {
      int xstart = value.indexOf("x=");
      xstart += 2;
      int xend = value.indexOf("y=");
      int ystart = xend + 2;
      String xval = value.substring(xstart, xend);
      String yval = value.substring(ystart);
      int xpos = Integer.parseInt(xval);
      int ypos = Integer.parseInt(yval);
      moveComponentTo(xpos, ypos);
    }
  }






  /** Set a property on this component instance.  It only takes
      transmittable String values. */
  public void setProperty(String key, String value) {
    // Check for recognized properties first.

    ComponentInstanceStateProperty cip = new ComponentInstanceStateProperty();

    if(cip.isKey(key)) {
      cip.setValue(value);
    } else {
      properties.put(key, value);
    }

    /* if the name is "gov.ccafe.visible"           */
    /* then change the visibility of this component */
    if (key.equals("gov.ccafe.visible")) {
      this.setVisible(toBoolean(value));
      this.invalidate();
      this.validate();
    }

    this.global.pn("gui:inserted property into component");

  }






  /**
   * Convert a string value to a boolean value.
   * The following string values are converted to a boolean false:
   * "0"  "f"  "F"  "false"  "False"  "FALSE"
   * @param value String The value to be converted to a boolean value.
   * @return boolean The string value converted to a boolean value.
   */
  protected boolean toBoolean(String value) {
      value = value.toLowerCase();
      if (value.equals("0")) return(false);
      if (value.equals("f")) return(false);
      if (value.equals("F")) return(false);
      if (value.equals("false")) return(false);
      return(true);
  }







  public String getProperty(String key) {
    // Check for recognized properties first.
    ComponentInstanceStateProperty cip = new ComponentInstanceStateProperty();
    if(cip.isKey(key)) {
      return cip.getValue();
    }
    return (String)properties.get(key);
  }

  /** Move this component to another location in the Arena.  Note that
      the Arena boundaries are not checked and it is easy to put a
      component where it is not visible. */
  public void moveComponentTo(int xpos, int ypos) {
    setLocation(xpos, ypos);
    global.addToHistory("move "+NAME+" "+xpos+" "+ypos);
    global.informOfChange();
    updateConnections();
  }

  public Hashtable getParamsToSave(){
    return paramsToSave;
  }

  public void updateParamsToSave(String params){
    StringTokenizer tokens = new StringTokenizer(params);
    String theParamPortName = tokens.nextToken();
    paramsToSave.put(theParamPortName,params);
  }

  public int getOutPortCount(){
    int count = 0;
    for(Enumeration e = ports.elements(); e.hasMoreElements();){
      int side = ((Port)e.nextElement()).getSide();
      if(side == Port.OUTPORT) {
              count++;
      }
    }
    return count;
  }
  public int getInPortCount(){
    int count = 0;
    for (Enumeration e = ports.elements(); e.hasMoreElements();){
      int side = ((Port)e.nextElement()).getSide();
      if (side == Port.INPORT ) {
              count++;
      }
    }
    return count;
  }
  /**
   * Returns a specified outport.
   */
  public Port getPort(String name){
    return (Port)ports.get(name);
  }

  public String getInstanceName(){
    return NAME;
  }
  public String getClassPath(){
    return CLASSPATH;
  }
  /** Returns the location of this component in the Arena.*/
  public Point getDropLocation() {
    return dropLocation;
  }
  /** To be removed. */
  //  public void actionPerformed(ActionEvent e){}
  /** The "normal" way of clicking expected behavior. */
  public void doPortLeftClick(Port port) {
    int type = port.getType();
    if(type == Port.OUTPORT)
      outportClicked(port);
    else if(type == Port.INPORT)
      inportClicked(port);
    else if(type == Port.GOPORT)
      goportClicked(port);
    else if(type == Port.PARAMPORT)
      paramportClicked(port);
  }
  /** The "connect only" way of clicking behavior. */
  public void doPortAltLeftClick(Port port) {
    int side = port.getSide();
    if (side == Port.OUTPORT) {
      outportClicked(port);
    } else {
      inportClicked(port);
    }
  }
  public void doPortRightClick(Port p) {
    Vector con = arena.getConnectionsForPort(p);
    if(con.size() > 0) {
      int answer =
        JOptionPane.showConfirmDialog
          (this,
           "Are you sure you want to blow this connection away?",
           "Connection",
           JOptionPane.YES_NO_OPTION);
      switch(answer) {
      case JOptionPane.CANCEL_OPTION:
        return;
        //        break;
      case JOptionPane.NO_OPTION:
        return;
        //        break;
      case JOptionPane.YES_OPTION:
        Enumeration e = con.elements();
        while(e.hasMoreElements()) {
          arena.removeConnection((Connection)e.nextElement());
        }
        break;
      default:
        throw new RuntimeException("ComponentInstance::doPortRightClick:"+
                                   " bad return from confirm dialog:"+
                                   " this can't happen");
        //        break;
      }
    } else {
      return;
    }
  }
  private void outportClicked(Port p) {
    if(arena.getConnectionSourcePort() != null){ //cancel connection
      if(arena.getConnectionSourcePort()==p){
        arena.nullifyConnectionSource();
        arena.nullifyConnectionSourcePort();
        p.resetHue();
        return;
      }else{ //deselect previously selected sourceport
        arena.getConnectionSourcePort().resetHue();
      }
    }
    arena.setConnectionSource(this);
    arena.setConnectionSourcePort(p);
    p.setHue(Port.red);
    repaint();
  }



  private void goportClicked(Port p){


      //global.write("go " + NAME + " " + p.getInstanceName());
      global.addToHistoryAndToDebugger("go " + NAME + " " + p.getInstanceName());
      global.getBuilder().getAccessServer().broadcastGoComponentPort
             (NAME,
              p.getInstanceName());
  }




  private void paramportClicked(Port p){


    //global.write("parameters " +
    //             NAME + " " +
    //             p.getInstanceName() +
    //             " ALL");
    global.addToHistoryAndToDebugger
                ("parameters " +
                 NAME + " " +
                 p.getInstanceName() +
                 " ALL");
   global.getBuilder().getAccessServer().broadcastGetPortParameter
           (NAME,
            p.getInstanceName(),
            "ALL");

  }



  private void inportClicked(Port p) {
    if(arena.getConnectionSource() == null)
      return;
    source = arena.getConnectionSource();
    sourcePort = arena.getConnectionSourcePort();
    target = this;
    targetPort = p;
    targetPort.setHue(Port.red);



    //global.write
    //  ("connect "                   +
    //   source.getInstanceName()     + " " +
    //   sourcePort.getInstanceName() + " " +
    //   target.getInstanceName()     + " " +
    //   targetPort.getInstanceName() );
    global.addToHistoryAndToDebugger
      ("connect "                   +
       source.getInstanceName()     + " " +
       sourcePort.getInstanceName() + " " +
       target.getInstanceName()     + " " +
       targetPort.getInstanceName() );
    global.getBuilder().getAccessServer().broadcastConnect
      (source.getInstanceName(),
       sourcePort.getInstanceName(),
       target.getInstanceName(),
       targetPort.getInstanceName() );



    try{Thread.sleep(500);}catch(Exception e){}
    sourcePort.resetHue();
    targetPort.resetHue();
    sourcePort.unhighlight();
    targetPort.unhighlight();
    arena.nullifyConnectionSourcePort();
    arena.nullifyConnectionSource();
  }
  public void successfulConnection(){
    arena.addConnection(new Connection(source,sourcePort,
                                       target,targetPort,
                                       global));
    global.informOfChange();
    resetConnectionAttempt();
  }
  public void unsuccessfulConnection(){
    JOptionPane.showMessageDialog
      (builder,
       "Sorry, those ports are incompatible.");
    resetConnectionAttempt();
  }
  private void resetConnectionAttempt(){
    sourcePort.resetHue();
    targetPort.resetHue();
    arena.nullifyConnectionSourcePort();
    arena.nullifyConnectionTargetPort();
    arena.nullifyConnectionSource();
    arena.nullifyConnectionTarget();
    arena.repaint();
  }
  class MouseRectDragger extends MouseAdapter implements MouseMotionListener {
    public MouseRectDragger(){
      super();
    }
    public void mouseDragged(MouseEvent e) {
      updateRect(e);
    }
    public void mouseMoved(MouseEvent e) {} // ignored

    public void mousePressed(MouseEvent e) {
      global.setDragOccurring(true);
      downPoint = e.getPoint();
      Rectangle r2 = new Rectangle();
      getBounds(r2);
      r = new Rectangle(r2.x-1,r2.y-1,
                        r2.width +1,r2.height +1);
      mousePt = e.getPoint();
      Graphics g = arena.getGraphics();
      if(g == null) return;
      g.setXORMode(Color.yellow);
      g.drawRect(r.x, r.y, r.width, r.height);
      g.dispose();
      if(arena.getSelectedComponentInstance() != null &&
         arena.getSelectedComponentInstance().getInstanceName().equals(NAME))
        wasSelected = true;
      else
        beSelected(true);
      addMouseMotionListener(this);
    }
    public void mouseReleased(MouseEvent e) {
      upPoint = e.getPoint();
      e.translatePoint(1,1);
      Graphics g = arena.getGraphics();
      if(g == null) return;
      g.setXORMode(Color.yellow);
      g.drawRect(r.x, r.y, r.width, r.height);
      g.dispose();
      Rectangle button = new Rectangle(0,0,getWidth(),getHeight());
      if(upPoint.equals(downPoint)){
        if(wasSelected){
          beSelected(false);
          arena.nullifySelectedComponentInstance();
          downPoint = null;
          wasSelected = false;
        }
      }else{
        Point curPt = e.getPoint();
        int dx = curPt.x - mousePt.x;
        int dy = curPt.y - mousePt.y;
        r.x += dx;
        r.y += dy;
        Rectangle arenaRect = new Rectangle
          (0,0,arena.getWidth(),arena.getHeight());
        if(arenaRect.intersects(r))
          moveComponentTo(r.x, r.y);
      }
      removeMouseMotionListener(this);
      global.setDragOccurring(false);
    }
    private void updateRect(MouseEvent e) {
      Graphics g = arena.getGraphics();
      g.setXORMode(Color.yellow);
      g.drawRect(r.x, r.y, r.width, r.height);
      Point curPt = e.getPoint();
      int dx = curPt.x - mousePt.x;
      int dy = curPt.y - mousePt.y;
      r.x += dx;
      r.y += dy;
      g.drawRect(r.x, r.y, r.width, r.height);
      g.dispose();
      mousePt.x = curPt.x;
      mousePt.y = curPt.y;
    }
    public void moveComponentTo(int x, int y) {
      setLocation(r.x, r.y);
      global.addToHistory("move "+NAME+" "+r.x+" "+r.y);
      global.informOfChange();
      updateConnections();
      arena.repaint();
    }
    private Point downPoint;
    private Point upPoint;
    private boolean wasSelected;
    private Rectangle r = new Rectangle();
    private Point mousePt = new Point();
  }
  public void paint(Graphics g){
    super.paint(g);
  }
  private void pn(String s) {
    LocalSystem.err.println(s);
  }
  //This group contains references to containers
  private GlobalData global;
  private Builder   builder;
  private Arena       arena;

  private boolean  building;

  private MouseRectDragger mousedragger;

  JPanel inPanel;
  JPanel outPanel;

  /** Properties for this ComponentInstance, analogous to the framework. */
  Hashtable properties = new Hashtable();

  //This group contains descriptive elements
  private int              width;
  private int             height;
  private String            NAME;
  private String       CLASSPATH;
  private String        PORTINFO;
  private Hashtable        ports;
  private Hashtable paramsToSave;
  private Point     dropLocation;


  //This group is used in the adding and removing of connections
  private String  connectionStatus;
  private Port          sourcePort;
  private Port          targetPort;
  private ComponentInstance source;
  private ComponentInstance target;
  private StringTokenizer   tokens;

  //This group is used in the removing of a connection
  //  and the updating of paths after a component relocation
  private int                 connectionCount;
  private String                     thisName;
  private String        thisConnectionSrcName;
  private String        thisConnectionTrgName;
  private ComponentInstance thisConnectionSrc;
  private ComponentInstance thisConnectionTrg;
  private Connection           thisConnection;

  //This group is used in adding Ports to this component
  private String       portString;
  private String        usesPorts;
  private String    providesPorts;
  private String    portClassName;
  private String portInstanceName;
}
