package gov.sandia.ccaffeine.dc.user_iface;
import gov.sandia.ccaffeine.util.LocalSystem;
import gnu.getopt.*;
import java.util.*;
import java.io.*;


/** Simple argument class for the Builders.  Not all arguments make
    sense in all contexts. */
public class Args {

  public static final String DEFAULTPROCFILEPATH = "processors";
  public static final int DEFAULTPORT = 2023;
  public static final int DEFAULTBUILDERPORT = 2024;
  public static final double DEFAULTSCALEFONT = 1.0;
  /** Port to listen on. */
  public int portNumber = DEFAULTPORT;
  /** Port for the BuilderClient to connect to. */
  public int builderPort = DEFAULTBUILDERPORT;
  /** Name of the type of run to be done. */
  public String type;
  /** Path to .bld file to load */
  public String buildFile = null;
  /** Path to the processor file. */
  public String procFile;
  /** The name, found in the processor file, that refers to this process */
  public String myProcName = null;
  /** Special mode for debugging. */
  public String mode = "";
  /** Remote host for connecting.  */
  public String hostName = "localhost";
  /** Is this to be run as a server? */
  public boolean isServer = true;
  /** Is this to be run as xcat bridge? */
  public boolean isXCATBridge = false;
  /** are we connecting to a python cca server? */
  public boolean serverIsPython = false;
  /** the scale factor on the fonts */
  public double scaleFont = 1.0;
  /** String that indicates the 0th argument of the command line (not
      provided by Java) */
  public String argv0 = "argv[0]";

  public Args() {
  }
  public Args(String argv0) {
    this.argv0 = argv0;
  }
  /** Create an Args with the String array argument; parseArgs does
      not need to be called */
  public Args(String argv0, String[] s) {
    this.argv0 = argv0;
    parseArgs(s);
  }
  public void parseArgs(String[] args) {
    String usage = argv0+" --name MyHostName "+
      "[--file procDefinitionFile]"+
      " [--benMode]"+"[--port portNumber] "+
      "\nor\n"+
      "<BuilderClient>"+
      "[--benMode] "+
      "[--client] "+
      "[--xcat] "+
      "[--server]"+
      " [--builderPort PortNumber]"+
      " [--host HostName]"+
      " [--buildFile file]"+
      " [--pythonServer]"+
      " [--scaleFont]";
    procFile = DEFAULTPROCFILEPATH;

    StringBuffer sb = new StringBuffer();
    LongOpt[] longopts = new LongOpt[13];
    longopts[0] = new LongOpt("name", LongOpt.REQUIRED_ARGUMENT, sb, 'n');
    longopts[1] = new LongOpt("file", LongOpt.REQUIRED_ARGUMENT, sb, 'f');
    longopts[2] = new LongOpt("type", LongOpt.REQUIRED_ARGUMENT, sb, 't');
    longopts[3] = new LongOpt("benMode", LongOpt.NO_ARGUMENT, sb, 'b');
    longopts[4] = new LongOpt("port", LongOpt.REQUIRED_ARGUMENT, sb, 'p');
    longopts[5] = new LongOpt("builderPort", LongOpt.REQUIRED_ARGUMENT, sb,
			      'u');
    longopts[6] = new LongOpt("host", LongOpt.REQUIRED_ARGUMENT, sb, 'h');
    longopts[7] = new LongOpt("client", LongOpt.NO_ARGUMENT, sb, 'c');
    longopts[8] = new LongOpt("server", LongOpt.NO_ARGUMENT, sb, 's');
    longopts[9] = new LongOpt("buildFile", LongOpt.REQUIRED_ARGUMENT, sb, 'l');
    longopts[10] = new LongOpt("xcat", LongOpt.NO_ARGUMENT, sb, 'x');
    longopts[11] = new LongOpt("pythonServer", LongOpt.NO_ARGUMENT, sb, 'y');
    longopts[12] = new LongOpt("scaleFont", LongOpt.REQUIRED_ARGUMENT, sb, 'F');

    Getopt g = new Getopt("TestClientServer", args, "n:f:t:", longopts);
    String theOption;
    type = "0";
    int c;
    while((c = g.getopt()) != -1) {
      switch(c) {
      case 'b':
	//Mode for Ben
	theOption = "benMode";
	break;
      case 'n':
	//Name of processor I am on.
	theOption = "name";
	break;
      case 'f':
	//File to read
	theOption = "file";
	break;
      case 't':
	theOption = "type";
	break;
      case 'u':
	theOption = "builderPort";
	break;
      case 'p':
	theOption = "port";
	break;
      case 'i':
	theOption = "timeout";
	break;
      case 'h':
	theOption = "host";
	break;
      case 'c':
	theOption = "client";
	break;
      case 's':
	theOption = "server";
	break;
      case 'l':
	theOption = "buildFile";
	break;
      case 'x':
	theOption = "xcat";
	break;
      case 'y':
	theOption = "pythonServer";
	break;
      case 'F':
        theOption = "scaleFont";
        break;
      default:
      case '?':
	LocalSystem.err.println(usage);
	return;
      case 0:
	theOption = longopts[g.getLongind()].getName();
	break;
      }
      if(theOption == "name") {
	myProcName = g.getOptarg();
      } else if(theOption == "file") {
	procFile = g.getOptarg();
      } else if(theOption == "type") {
	type = g.getOptarg();
      } else if(theOption == "benMode") {
	mode = theOption;
      } else if(theOption == "port") {
	portNumber = Integer.parseInt(g.getOptarg());
      } else if(theOption == "builderPort") {
	builderPort = Integer.parseInt(g.getOptarg());
      } else if(theOption == "host") {
        hostName = g.getOptarg();
      } else if(theOption == "client") {
	isServer = false;
      } else if(theOption == "server") {
	isServer = true;
      } else if(theOption == "xcat") {
	isXCATBridge = true;
      } else if(theOption == "buildFile") {
	buildFile = g.getOptarg();
      } else if(theOption == "pythonServer") {
	this.serverIsPython = true;
      } else if (theOption == "scaleFont") {
        this.scaleFont = Double.parseDouble(g.getOptarg());
      } else {
	LocalSystem.err.println("Bad Option: "+theOption);
	LocalSystem.err.println(usage);
	return;
      }
    }
    if(myProcName == null) {
      LocalSystem.err.println(usage);
      return;
    }

  }






    public String toString() {
        StringBuffer s = new StringBuffer();
        s.append("portNumber="); s.append(portNumber); s.append(" ");
        s.append("builderPort="); s.append(builderPort); s.append(" ");
        s.append("type="); s.append(type); s.append(" ");
        s.append("buildFile="); s.append(buildFile); s.append(" ");
        s.append("procFile="); s.append(procFile); s.append(" ");
        s.append("myProcName="); s.append(myProcName); s.append(" ");
        s.append("mode="); s.append(mode); s.append(" ");
        s.append("hostName="); s.append(hostName); s.append(" ");
        s.append("isServer="); s.append(isServer); s.append(" ");
        s.append("isXCATBridge="); s.append(isXCATBridge); s.append(" ");
        s.append("pythonServer="); s.append(serverIsPython); s.append(" ");
        s.append("scaleFont="); s.append(scaleFont); s.append(" ");
        s.append("argv0="); s.append(argv0); s.append(" ");
        s.append("\n");
        return(s.toString());
    }
}

