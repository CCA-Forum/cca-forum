package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.util.LocalSystem;
import gov.sandia.ccaffeine.dc.user_iface.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;

public class CmdActionCCADebug
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCADebug() {
  }


  public String argtype() {
    return "";
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
    return "turns on debugging print statements.";
  }


  private static final String[] namelist = {"debug","noisy"};


  public void doIt(CmdContext cc, Vector args) {

    broadcastSetDebug();



  }

}
