package gov.sandia.ccaffeine.dc.distributed;

import gov.sandia.ccaffeine.util.*;
import gnu.getopt.*;
import java.util.*;
import java.io.*;
import java.net.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.distributed.*;

/** Meant to run in its own process, this class multiplexes multiple
    sockets (muxee) into one (muxor).  The MuxingProcess treats both
    muxee and muxor as a client.  Pays attention to several flags:
    --port \<port that the MuxingProcess listens on expecting
    connections from the muxee's\>; --builderPort \<port on which the
    MuxingProcess listens for the connection from the muxor\>.  */
public class MuxingProcess {
  private ServerMux mux = null;
  private Args arg = new Args();
  private SocketConnectionMgr controllerCSS;
  private SocketConnectionMgr computeClientsCSS;
  private long controllerTimeout = 100000;
  private long computeClientTimeout = 100000;


  /** Start listening initialize per the args, and start listening for
      connections from muxee's and muxor */
  public void initAndStartProcess(String[] args) {
    try {
      initMuxingProcess(args);
      startMuxingProcess();
    } catch(Exception e) {
      LocalSystem.err.println("Exception: "+e);
      e.printStackTrace(LocalSystem.err);
    }
  }
    /** Setup the multiplexor with command line style arguments. */
  public void initMuxingProcess(String[] args) throws Exception 
  {
    arg.parseArgs(args);


    /* open the log file */
    String logFile = arg.logFile;
    if (logFile != null) {
        PrintStream ps = new PrintStream(new FileOutputStream(logFile));
        LocalSystem.setErr(ps);
        LocalSystem.setOut(ps);
    }

    /* print command line args to our log file */    
    LocalSystem.err.println("portNumber =" + arg.portNumber);
    LocalSystem.err.println("builderPort=" + arg.builderPort);
    LocalSystem.err.println("procFile=" + arg.procFile);
    LocalSystem.err.println("myProcName=" + arg.myProcName);
    LocalSystem.err.println("myServerMachineName=" + arg.myServerMachineName);
    LocalSystem.err.println("timeout=" + arg.timeout);
    LocalSystem.err.println("logFile=" + arg.logFile);
    LocalSystem.err.println("heartbeatTimeout=" + arg.heartbeatTimeout);    
    LocalSystem.err.flush();



    if(arg.timeout >= 0) computeClientTimeout = arg.timeout;
    if(arg.timeout >= 0) controllerTimeout = arg.timeout;

    computeClientsCSS = new SocketConnectionMgr(arg.myProcName, 
				      arg.procFile,
				      arg.portNumber);
    if(!computeClientsCSS.isServer()) {
      throw new RuntimeException("Looks like I am configured "+
				 "as a client,"+
				 " I can only handle a Server");
    }

    if (arg.myServerMachineName != null) {
	controllerCSS = new SocketConnectionMgr(arg.myServerMachineName, 
						arg.builderPort);
    } else {
	// wait for 1 connection on the builder port - this will be the 
	// build manager
	controllerCSS = new SocketConnectionMgr(1, arg.builderPort);
    }

    // Get the connections from the processes to be muxed (ComputeClient), we
    // don't need to prescribe a particular order of connection, so we
    // use some threads.
    LocalSystem.err.println("creating thread to connect MPI nodes");
    Thread tComputeClient = 
      new Thread(
	 new Runnable(){
	     public void run() {
	       computeClientsCSS.connect((int)computeClientTimeout);
	     }
	   } // new Runnable() 
	 ); // new Thread
    // get the connection from the Builder (Controller)
    LocalSystem.err.println("creating thread to connect to GUI client");
    Thread tController =
      new Thread(
	 new Runnable(){
	     public void run() {
		 controllerCSS.connect((int)controllerTimeout);
	     }
	   } // new Runnable()
	 ); // new Thread
    try {
      LocalSystem.err.println("starting client thread");
      tComputeClient.start();
      LocalSystem.err.println("starting GUI client thread");
      tController.start();
      if(computeClientTimeout == 0) {
	tComputeClient.join();
      } else {
	tComputeClient.join(computeClientTimeout);
      }
      LocalSystem.err.println("do we have a connection?");
      if(controllerTimeout == 0) {
	tController.join();
      } else {
	tController.join(computeClientTimeout);
      }
      LocalSystem.err.println("do we have a connection?");
    } catch(Exception e) {
      LocalSystem.err.println("Exception while making connections: "+e);
      e.printStackTrace(LocalSystem.err);
    }
    if(tComputeClient.isAlive()) {
      die("Timeout waiting for connection "+
				 "from process(es)  being multiplexed from.");
    }
    if(tController.isAlive()) {
      die("Timeout waiting for connection "+
				 "from process being multiplexed to.");
    }

    if (controllerCSS.getConnections().size()==0){
        die("We do NOT have a connection to the GUI client");
    }

    LocalSystem.err.println
       ("We are connected to MPI nodes and to our GUI client");

    // All Connected:
    mux = new ServerMux
       (computeClientsCSS, //connection to MPI nodes
       (Connection) controllerCSS.getConnections().elementAt(0), //GUI client
        null, 
        arg.heartbeatTimeout,
        arg.builderPort);
  }




   /**
   Something is horribly wrong.  Die.
   */
   protected void die(String msg) throws RuntimeException {
       LocalSystem.err.println("Shutting down the Muxer");

       /* shutdown our connection to the GUI client */
       try {
           controllerCSS.shutdown();
	} catch(IOException e) {
	    LocalSystem.err.println("ServerMux::shutdown: "+ e);
	    e.printStackTrace(LocalSystem.err);
	}

       /* shutdown our connection to the MPI nodes */
       try {
           computeClientsCSS.shutdown();
	} catch(IOException e) {
	    LocalSystem.err.println("ServerMux::shutdown: "+ e);
	    e.printStackTrace(LocalSystem.err);
	}


       LocalSystem.err.println("The Muxer is offline");

       /* kill all mpi nodes */
       killAllMpiNodes(arg.builderPort);


       throw new RuntimeException(msg);
   }







    /**
     * Kill all MPI nodes
     * @param builderPort the port number, on the Muxer, that the
     * GUI client uses to connect to the Muxer.
     */
    protected void killAllMpiNodes(int builderPort) {

        /* do we have a builderPort? */
        if (builderPort < 0) return;

        /* get the name of the shell script that can kill the MPI nodes */
        ResourceBundle resourceBundle = 
          ResourceBundle.getBundle("gov.sandia.ccaffeine.dc.distributed.muxer");
        String command = resourceBundle.getString("killMpiNodes.sh") + " "
                       + String.valueOf(builderPort);
        /* launch the os command */
        try {   
            LocalSystem.err.println("Executing " + command);
            Process p = Runtime.getRuntime().exec(command);

            /* save the command's output */
            DataInputStream dis = new DataInputStream
                                   (new BufferedInputStream
                                   (p.getInputStream()));
            while(true) {
                String oneLine = dis.readLine();
                if (oneLine==null) break;
                LocalSystem.err.println(oneLine);
            }
            dis.close();
        }catch (java.io.IOException e){
            LocalSystem.err.println("Error.  Could not execute command.");
        }

    }
       
        
                      
       

       





  /** Start the multiplexing now: throws IOException if
      initMuxingProcess has not been called first.  This method will
      not return until the clients close. */
  public void startMuxingProcess() throws IOException, 
    InterruptedException {
    if(mux == null) {
      throw new IOException("startMuxingProcess: can't start because no"+
			    " ServerMux is defined");
    }
    mux.doClientIO();
    Thread t = mux.getControllerClientThread();
    t.join();
  }
  public static void main(String[] args) {
    new MuxingProcess().initAndStartProcess(args);
  }
}
