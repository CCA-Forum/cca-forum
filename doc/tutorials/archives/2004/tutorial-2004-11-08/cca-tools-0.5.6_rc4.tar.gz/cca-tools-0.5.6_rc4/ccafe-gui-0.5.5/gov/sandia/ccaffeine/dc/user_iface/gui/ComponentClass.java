package gov.sandia.ccaffeine.dc.user_iface.gui;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 * The items that are added to the palette.
 */
public class ComponentClass extends JPanel{

    public ComponentClass(String classPath, GlobalData global) {
	super();
	this.global = global;
	CLASSPATH = classPath;
	initialize();
    }

    private void initialize(){
	int idx = CLASSPATH.lastIndexOf('.');
	CLASS = CLASSPATH.substring(idx+1);
	if(idx > 0) {
	  prefix = CLASSPATH.substring(0, idx);
	  prefix = prefix + ".";
	} else {
	  prefix = null;
	}

	builder = global.getBuilder();
	arena   = global.getArena();
	palette = global.getPalette();

	JLabel label = new JLabel(CLASS);
	label.setForeground(Color.white);

	if(prefix != null) {
	  Font f = label.getFont();
	  int style = f.getStyle();
	  int size = f.getSize();
	  Font newf = f.deriveFont(style, (int)((double)size/1.3));
	  JLabel pLabel = new JLabel(prefix);
	  pLabel.setFont(newf);
	  pLabel.setForeground(new Color(214,111,32));
	  add(pLabel);
	}

	add(label);
	setBackground(deselected);

	mousedragger = new MouseRectDragger(this);
	addMouseListener(mousedragger);
    }
    public String getClassPath(){
	return CLASSPATH;
    }
    public String getClassName(){
	return CLASS;
    }

    private final Color deselected = Color.black;
    private final Color selected   = Color.blue;

    private GlobalData global;
    private Builder   builder;
    private Arena       arena;
    private Palette   palette;

  private String prefix;
    private String CLASS;
    private String CLASSPATH;

    private MouseRectDragger mousedragger;

    private class MouseRectDragger
	extends MouseAdapter
	implements MouseMotionListener {

	ComponentClass parent;
	Rectangle           r = new Rectangle();
	Point         mousePt = new Point();

	public MouseRectDragger(ComponentClass cc){
	    super();
	    parent = cc;
	}
	public void mouseDragged(MouseEvent e) {
	    updateRect(e);
	}
	public void mousePressed(MouseEvent e) {
	    global.setDragOccurring(true);
	    r = makeRect();
	    mousePt = e.getPoint();
	    Graphics g = builder.getGraphics();
	    if(g == null) return;
	    g.setXORMode(Color.yellow);
	    g.drawRect(r.x, r.y, r.width, r.height);
	    g.dispose();
	    if(arena.getSelectedComponentInstance() != null){
		arena.getSelectedComponentInstance().beSelected(false);
		arena.nullifySelectedComponentInstance();
	    }
	    setBackground(selected);
	    arena.setSelectedComponentClass(parent);
	    addMouseMotionListener(this);
	}
	public void mouseReleased(MouseEvent e) {
	    Graphics g = builder.getGraphics();
	    if(g == null) return;
	    g.setXORMode(Color.yellow);
	    g.drawRect(r.x, r.y, r.width, r.height);
	    g.dispose();
	    Point curPt = e.getPoint();
	    int dx = curPt.x - mousePt.x;
	    int dy = curPt.y - mousePt.y;
	    r.x += dx;
	    r.y += dy;

	    Point p = new Point(r.x, r.y);
	    Rectangle arenaRect =
		new Rectangle(arena.getLocationOnScreen().x -
			      builder.getLocationOnScreen().x,
			      arena.getLocationOnScreen().y -
			      builder.getLocationOnScreen().y,
			      arena.getWidth(),arena.getHeight());
	    if(arenaRect.intersects(r)){
		boolean badName = true;
		String messageString = "Please enter instance name";
		String defaultName = global.createInstanceName(CLASS);
		String instanceName = "";
		Point dropPoint = new Point
		    (p.x - arena.getLocationOnScreen().x +
		     builder.getLocationOnScreen().x,
		     p.y - arena.getLocationOnScreen().y +
		     builder.getLocationOnScreen().y       );
		while(badName){
		    instanceName = showInputDialog(messageString,
						   defaultName,
						   p);

		    if(instanceName == null)
			break;
		    else if (instanceName.length()==0)
			messageString = "Empty String. Please try again.";
		    else if(instanceName.indexOf(' ') > -1)
			messageString = "No spaces allowed. Please try again.";
		    else if(arena.getComponentInstance(instanceName) != null)
			messageString = "Name is taken. Please try again.";
		    else
			badName = false;
		}
		if(instanceName != null){
		    global.setDropLocation(dropPoint);



		    //global.write("pulldown "
		    //		 + CLASSPATH    + " "
		    //         	 + instanceName);/* + " "
		    //		 + dropPoint.x  + " "
		    //		 + dropPoint.y       );*/
                    global.addToHistoryAndToDebugger
                                ("pulldown "
				 + CLASSPATH    + " "
		         	 + instanceName);/* + " "
				 + dropPoint.x  + " "
				 + dropPoint.y       );*/
                    global.getBuilder().getAccessServer().broadcastInstantiate
                                 (CLASSPATH,
                                  instanceName);




		}
	    }
	    arena.nullifySelectedComponentClass();
	    setBackground(deselected);
	    global.setDragOccurring(false);
	    removeMouseMotionListener(this);
	}
	private String showInputDialog(String prompt,
				       String defaultName,
				       Point location){
	    JOptionPane pane = new JOptionPane
		(prompt,
		 JOptionPane.QUESTION_MESSAGE,
		 JOptionPane.OK_CANCEL_OPTION);
	    pane.setWantsInput(true);
	    //pane.setInitialSelectionValue(defaultName);
	    /**
	     *Here's the heirarchy of the input dialog
	     *(this is used to find the JTextField so we
	     * can selectAll by default for easy typeover
	     * name changes)
	     *
	     *javax.swing.JPanel
	     **javax.swing.plaf.basic.BasicOptionPaneUI$3
	     ***javax.swing.plaf.basic.BasicOptionPaneUI$4
	     ***javax.swing.plaf.basic.BasicOptionPaneUI$2
	     ****javax.swing.JLabel
	     ****javax.swing.JTextField
	     **javax.swing.JLabel
	     *javax.swing.JPanel
	     **javax.swing.JButton
	     **javax.swing.JButton
	     */
	    Container              jPanel = (Container)pane.getComponent(0);
	    Container basicOptionPaneUI$3 = (Container)jPanel.getComponent(0);
	    Container basicOptionPaneUI$2 = (Container)basicOptionPaneUI$3.getComponent(1);
	    JTextField          textField = (JTextField)basicOptionPaneUI$2.getComponent(1);
	    textField.setText(defaultName);
	    textField.selectAll();
	    JDialog dialog = pane.createDialog(arena, "Input");
	    dialog.setLocation(location);
	    dialog.show();

	    Object value = pane.getInputValue();
	    if(value == JOptionPane.UNINITIALIZED_VALUE)
		return null;
	    return (String)value;
	}

	private void updateRect(MouseEvent e) {
	    Graphics g = builder.getGraphics();
	    g.setXORMode(Color.yellow);
	    g.drawRect(r.x, r.y, r.width, r.height);
	    Point curPt = e.getPoint();
	    int dx = curPt.x - mousePt.x;
	    int dy = curPt.y - mousePt.y;
	    r.x += dx;
	    r.y += dy;
	    g.drawRect(r.x, r.y, r.width, r.height);
	    g.dispose();
	    mousePt.x = curPt.x;
	    mousePt.y = curPt.y;
	}
	private Rectangle makeRect(){
	    int w=getWidth();
	    int h=getHeight();
	    Point os = new Point
		(getLocationOnScreen().x - builder.getLocationOnScreen().x,
		 getLocationOnScreen().y - builder.getLocationOnScreen().y);
	    Rectangle rect = new Rectangle(os.x-1,os.y-1,w+1,h+1);
	    return rect;
	}
	public void mouseMoved(MouseEvent e) {}
    }
}
