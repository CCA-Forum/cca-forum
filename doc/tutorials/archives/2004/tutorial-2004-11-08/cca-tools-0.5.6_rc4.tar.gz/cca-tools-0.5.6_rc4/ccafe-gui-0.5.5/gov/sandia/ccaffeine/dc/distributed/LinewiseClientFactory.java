package gov.sandia.ccaffeine.dc.distributed;

import java.net.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;


class LinewiseClientFactory implements ClientFactory {
    public Client makeClient(Connection connect)
    {
	return new LinewiseClient(connect);
    }
}
