package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;

public class CmdActionCCAInstantiate
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCAInstantiate() {
  }


  public String argtype() {
    return "CS";
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
    return "create an arena instance from a class.";
  }


  private static final String[] namelist = {"pulldown","instantiate","create"};


  public void doIt(CmdContext cc, Vector args) {


    /* get the number of arguments in the "instantiate" command */
    int numberOfArguments = args.size();

    /* get the name of the component's class */
    String className = null;
    if (numberOfArguments>0)
        className = (String)args.get(0);

    /* get the name of the component's instance */
    String instanceName = null;
    if (numberOfArguments>1)
        instanceName = (String)args.get(1);

    this.broadcastInstantiateComponent
        (className,
         instanceName);

  }

}
