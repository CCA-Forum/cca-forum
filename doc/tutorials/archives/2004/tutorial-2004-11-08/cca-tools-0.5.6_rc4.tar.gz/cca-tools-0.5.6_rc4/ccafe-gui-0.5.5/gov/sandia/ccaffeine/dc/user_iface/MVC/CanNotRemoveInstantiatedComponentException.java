
package gov.sandia.ccaffeine.dc.user_iface.MVC;


public class CanNotRemoveInstantiatedComponentException extends Exception {


    public CanNotRemoveInstantiatedComponentException() {
        super();
    }


    public CanNotRemoveInstantiatedComponentException(String message) {
        super(message);
    }
}