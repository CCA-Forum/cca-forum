package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUI;

/**
 * CmdActionGUIParamField.java
 */

public class CmdActionGUIParamField
       extends CmdActionGUI
       implements CmdAction {

    public CmdActionGUIParamField() {
    }


    public String argtype(){
	return "ISSS";
    }

    public String[] names(){
	return namelist;
    }

    public String help(){
	return "creates a new data field to be filled with forthcoming data.";
    }

    private static final String[] namelist = {"newParamField"};
    public void doIt(CmdContext cc, Vector args) {

	CmdContextGUI ccg = (CmdContextGUI)cc;


       /*
        * The name of the cca component that contains
        * the port which contains the data field.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = (String)args.get(0);

       /*
        * The name of the port that contains the data field.
        *  Example: "configure_port"
        */
        String portInstanceName = (String)args.get(1);

       /*
        The data type of the value that is
        stored in the data field (e.g. STRING).
        */
        String dataFieldDataType = (String)args.get(2);

       /*
        * The name of a data field.
        */
        String dataFieldName = (String)args.get(3);

	//String hashKey = componentInstance + ":" + portInstance;

	//ConfigureDialog dialog = global.getConfigureDialog(hashKey);
	//dialog.newDataField(type,name);

        this.broadcastParamField
            (componentInstanceName,
             portInstanceName,
             dataFieldDataType,
             dataFieldName);



    } // doIt

} // CmdActionGUIParamField
