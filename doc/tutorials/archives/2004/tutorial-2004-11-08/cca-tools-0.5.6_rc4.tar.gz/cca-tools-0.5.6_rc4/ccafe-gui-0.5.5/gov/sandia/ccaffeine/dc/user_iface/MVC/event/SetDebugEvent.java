package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import java.util.EventObject;

/**
 * This event can be used to notify components
 * that an entity wants to turn on debugging or
 * turn off debugging.
 * A view might respond by sending either a
 * "debug, "noisy," "nodebug," or "quiet" command to the cca server.
 */

public class SetDebugEvent extends EventObject {

  /**
   * Create a SetDebugEvent that can be used
   * to notify components that an entity wants
   * to turn on debugging.
   * A view might respond by sending either a
   * "debug, "noisy," "nodebug," or "quiet" command to the cca server.
   * @param source The entity that created
   * this event.
   */
    public SetDebugEvent(Object source) {
        super(source);
    }

}