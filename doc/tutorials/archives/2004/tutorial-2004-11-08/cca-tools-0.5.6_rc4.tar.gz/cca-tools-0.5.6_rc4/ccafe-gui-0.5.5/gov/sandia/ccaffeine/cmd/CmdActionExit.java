package gov.sandia.ccaffeine.cmd;

import java.util.*;
import java.io.*;

/** Default standard Exit command for all parsers. */
public class CmdActionExit implements CmdAction {

  public CmdActionExit() {
  }

  /** Generates an exception with exit message. */
  public void doIt(CmdContext cc, Vector args) throws EOFException {

    int status = 0;

    cc.pn("\nbye!");
    cc.pn("exit");

    if (args.size() == 1) {
      // originally planned to have s -> int, but got lazy.
      String s = (String)args.get(0);
      EOFException e = new EOFException("User exited command interpreter ("+s+")");
      throw e;
    }

    EOFException e = new EOFException("User exited command interpreter");
    throw e; 

  }
  
  public String help() {
    return "leave the parser and the calling program, with optional return code.";
  }

  /** optional string is the exit code to use. . */
  public String argtype() {
    return "s";
  }

  public String[] names() {
    return namelist;
  }

  private static final String[] namelist = {"exit","x","bye","quit"};
    
}
