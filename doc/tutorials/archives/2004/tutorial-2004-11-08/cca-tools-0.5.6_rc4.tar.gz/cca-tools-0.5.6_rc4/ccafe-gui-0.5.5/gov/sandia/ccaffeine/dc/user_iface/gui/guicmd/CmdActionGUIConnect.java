package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUI;


/**
 * CmdActionGUIConnect.java
 *
 * When the end-user clicks on a red Uses Port and then
 * clicks on a Provides Port, the cca server connects
* the two ports.  The cca server sends a connect message
* to the client.  The client responds by drawing a line
* between the two ports.
*/

public class CmdActionGUIConnect
       extends CmdActionGUI
       implements CmdAction {

    public CmdActionGUIConnect() {
    }


    public String argtype(){
	return "ISIS";
    }

    public String[] names(){
	return namelist;
    }

    public String help(){
	return "connects a providesPort to a usesPort.";
    }

    private static final String[] namelist = {"connect"};

    /** It is not safe to assume the input to this is valid,
	as the action of the connection already done in the
        framework may invalidate the ports being connected.
    */
    public void doIt(CmdContext cc, Vector args) {

	CmdContextGUI ccg = (CmdContextGUI)cc;

        /*
         * A connection is made from a source port to a target port.
         * This is the name of the component that houses the source port.
         * The name is usually the java class name of the component
         * (without the package name) concatenated with an index number.
         * Example:  "StartComponent0"
         */
	String     sourceComponentName = (String)args.get(0);

         /*
          * A connection is made from a source port to a target port.
          * This is the name of the source port.
          * The name is usually the java class name of the port
          * (without the package name).
          * Example:  "out0"
          */
	String sourcePortName = (String)args.get(1);

        /*
         * A connection is made from a source port to a target port.
         * This is the name of the component that houses the target port.
         * The name is usually the java class name of the component
         * (without the package name) concatenated with an index number.
         * Example:  "Printer0"
         */
	String     targetComponentName = (String)args.get(2);

         /*
          * A connection is made from a source port to a target port.
          * This is the name of the target port.
          * The name is usually the java class name of the port
          * (without the package name).
          * Example:  "printer_port"
          */
	String targetPortName = (String)args.get(3);


	//ComponentInstance source =
	//    global.getArena().getComponentInstance(sourceName);
	//Port sourcePort =
	//    source.getPort(sourcePortName);
	//ComponentInstance target =
	//    global.getArena().getComponentInstance(targetName);
	//Port targetPort =
	//    target.getPort(targetPortName);
        //if (source == null || target == null ||
        //    sourcePort == null || targetPort == null) {
        //    return;
        //}
	//global.getArena().addConnection
	//    (new Connection(source, sourcePort,
	//		    target, targetPort, global));
        this.broadcastConnect
            (sourceComponentName,
             sourcePortName,
             targetComponentName,
             targetPortName);

    } // doIt

} // CmdActionGUIConnect
