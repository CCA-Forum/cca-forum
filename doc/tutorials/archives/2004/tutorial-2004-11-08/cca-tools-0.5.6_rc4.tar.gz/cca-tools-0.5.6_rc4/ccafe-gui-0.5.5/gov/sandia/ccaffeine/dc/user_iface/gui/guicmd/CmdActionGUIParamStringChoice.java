package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.guicmd.CmdActionGUI;

/**
 * CmdActionGUIParamStringChoice.java
 */

public class CmdActionGUIParamStringChoice
       extends CmdActionGUI
       implements CmdAction {

    public CmdActionGUIParamStringChoice() {
    }

    public String argtype(){
	return "ISSA";
    }

    public String[] names(){
	return namelist;
    }

    public String help(){
	return "adds a choice for a String data field.";
    }

    private static final String[] namelist = {"paramStringChoice"};

    public void doIt(CmdContext cc, Vector args) {

	CmdContextGUI ccg = (CmdContextGUI)cc;


       /*
        * The name of the cca component that contains
        * the port which contains the data field.
        * The name is usually the java class name of the component
        * (without the package name) concatenated with an index number.
        * Example:  "TimeStamper0"
        */
        String componentInstanceName = (String)args.get(0);

       /*
        * The name of the port that contains the data field.
        *  Example: "configure_port"
        */
        String portInstanceName = (String)args.get(1);



       /*
        * The name of a data field.
        */
        String dataFieldName = (String)args.get(2);


       /*
        * One of the possible values that can be
        * inserted into this data field.
        */
        String dataFieldElementInSetOfValues = (String)args.get(3);

	//String hashKey = componentInstance + ":" + portInstance;

	//ConfigureDialog dialog = global.getConfigureDialog(hashKey);
	//dialog.addStringChoice(name, stringChoice);

        this.broadcastParamStringChoice
            (componentInstanceName,
             portInstanceName,
             dataFieldName,
             dataFieldElementInSetOfValues);


    } // doIt


} // CmdActionGUIAddChoice
