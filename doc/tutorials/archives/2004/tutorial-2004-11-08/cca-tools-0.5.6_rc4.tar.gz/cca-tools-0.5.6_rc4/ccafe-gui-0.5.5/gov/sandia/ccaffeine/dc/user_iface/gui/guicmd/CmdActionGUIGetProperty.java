package gov.sandia.ccaffeine.dc.user_iface.gui.guicmd;

import java.util.*;
import gov.sandia.ccaffeine.cmd.*;
import gov.sandia.ccaffeine.dc.user_iface.gui.*;

/**
 * CmdActionGUIGetProperty.java
 */

public class CmdActionGUIGetProperty
       extends CmdActionGUI
       implements CmdAction{

  private static final String[] namelist = {"getProperty", "property"};


  public CmdActionGUIGetProperty(){
  }

  /** getProperty <component instance> <key string> */
  public String argtype(){
    return "IS";
  }

  public String[] names(){
    return namelist;
  }

  public String help(){
    return "Gets a property given a key from the gui representation of "+
      "a component";
  }

  public void doIt(CmdContext cc, Vector args) {

    CmdContextGUI ccg = (CmdContextGUI)cc;


  /**
   * The name of the component that contains the property
   * The name is usually the java class name of the component
   * (without the package name) concatenated with an index number.
   * Example:  "StartComponent0"
   */
    String componentInstanceName = (String)args.get(0);

    /*
     * The name of the property.
     */
    String propertyName = (String)args.get(1);

    //Hashtable cis = global.getArena().getComponentInstances();
    //ComponentInstance ci = (ComponentInstance)cis.get(name);
    //if(ci != null) {
    //  String value = (String)ci.getProperty(key);
    //  global.write("property "+name+" "+value);
    //}
        
    this.broadcastGetComponentProperty(componentInstanceName, propertyName);
  }
}
