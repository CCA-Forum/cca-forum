package gov.sandia.ccaffeine.dc.user_iface.ccacmd;

import gov.sandia.ccaffeine.cmd.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.dc.user_iface.ccacmd.CmdActionCCA;

public class CmdActionCCANuke
       extends CmdActionCCA
       implements CmdAction {


  public CmdActionCCANuke() {
  }


  public String argtype() {
    return "S";
  }


  public String[] names() {
    return namelist;
  }


  public String help() {
    return "nuke all\n   - deletes all components in the arena.";

  }


  private static final String[] namelist = {"nuke"};


  public void doIt(CmdContext cc, Vector args) {

    /*
     * The number of arguments in the nuke command
     */
      int numberOfArguments = args.size();

     /**
      * The entity that is to be removed.
      * NOTE:  As of Oct 2003, "all" is the
      * only entity that can be nuked.
      */
      String entity = null;
      if (numberOfArguments>0)
          entity = (String)args.get(0);

      this.broadcastNukeAll
          (numberOfArguments,
           entity);
  }
}
