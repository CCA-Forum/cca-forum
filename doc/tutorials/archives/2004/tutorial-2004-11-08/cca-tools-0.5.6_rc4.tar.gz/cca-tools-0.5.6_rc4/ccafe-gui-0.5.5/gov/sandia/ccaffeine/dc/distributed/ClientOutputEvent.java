package gov.sandia.ccaffeine.dc.distributed;

import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;

class ClientOutputEvent extends EventObject {	 
  private String s;				 
  public ClientOutputEvent(Object source, String s) {
    super(source);				 
    this.s = s;				 
  }						 
  public String getString() {			 
    return s;					 
  }						 
}
