package gov.sandia.ccaffeine.dc.distributed;

import java.awt.*;
import java.awt.event.*;

/**
Test the HeartbeatMonitor.
This class displays a frame with a button.
Each press of the button sends one HeartbeatEvent
to the HeartbeatMonitor.  If the time between
button press is less than 5 seconds then no
messages will appear in stdout.  If you do
not press the button for more than 5 seconds
then the HeartbeatMonitor will send this class
a new HeartbeatEvent.  When this class receives
the HeartbeatEvent, this class will send a message
to stdout.
<p>
 */

public class FrameTestHeartbeatMonitor
       extends Frame
       implements ActionListener, HeartbeatListener {

      HeartbeatMonitor heartbeatMonitor = null;

      /**
       * Construct a frame with a button.
       * Each press of the button sends one
       * heartbeat to our Heartbeat Monitor.
       */
      public FrameTestHeartbeatMonitor() {
          this.setSize(640, 400);
          this.setVisible(true);
          this.addWindowListener(new MyWindowAdapter());
          this.setLayout(new FlowLayout());
          Button button = new Button("push me");
          add(button);
          button.addActionListener(this);

          this.heartbeatMonitor = new HeartbeatMonitor();
          this.heartbeatMonitor.setNumberOfMillisecondsToWaitForHeartbeat(5000);
          this.heartbeatMonitor.addHeartbeatListener(this);
          this.heartbeatMonitor.start();

          validate();

      }


      /**
       * Whenever the end-user presses the button,
       * send a HearbeatEvent to the HeartbeatMonitor.
       * @param event The event that is generated
       * whenever the end-user presses the button.
       */
      public void actionPerformed(ActionEvent event) {
          this.heartbeatMonitor.receivedHeartbeat
               (new HeartbeatEvent(this));
      }


      /**
       * My window adapter to capture the Window Closing Event
       * that is generated whenever the end-user clicks on the
       * close button that is in the upper right corner of this
       * frame's title bar.
       */
      class MyWindowAdapter extends WindowAdapter {

        /**
         * This event is invoked whenever the end-user
         * clicks on the close button that is in the
         * upper right corner of the title bar.
         * @param event The event that is generated
         * whenver the end-user closes this window.
         */
          public void windowClosing(WindowEvent event) {
              System.exit(0);
          }
      }



      /**
       * This method is called whenever the heartbeat
       * monitor receives a heartbeat.
       * @param event The event that is generated
       * whenever the heartbeat monitor receives a
       * heartbeat.
       */
    public void receivedHeartbeat(HeartbeatEvent event) {
    }

    /**
     * This method is called whenever the heartbeat
     * monitor does not receive a heartbeat for a very long time.
     * @param event The event that is generated whenever
     * the heartbeat monitor does not receive a heartbeat
     * for a very long time.
     */
    public void didNotReceiveHeartbeat(HeartbeatEvent event) {
        System.out.println("did not recieve heartbeat");
    }

    /**
     * Launch a Frame that contains a button.
     * Whenever the end-user clicks on the button,
     * send a heartbeat to our HeartbeatMonitor.
     * @param args The command line arguments.
     */
    public static void main(String[] args) {
      FrameTestHeartbeatMonitor frameTest1 =
          new FrameTestHeartbeatMonitor();
  }
}
