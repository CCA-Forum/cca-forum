
package gov.sandia.ccaffeine.dc.user_iface.examples;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;



public class ScriptFile {
	
	protected BufferedReader reader = null;
	
	
	/**
	 * open the script file
	 */
	synchronized public void open(){		
		ClassLoader classLoader = ClassLoader.getSystemClassLoader();
		this.reader = new java.io.BufferedReader
		   (new java.io.InputStreamReader
			   (classLoader.getResourceAsStream
		   ("gov/sandia/ccaffeine/dc/user_iface/examples/scriptToTestClient.xml")));
		
	}
	
	/**
	 * Read one line from the script file.
	 * If we have reached EOF then return null.
	 * @return one line from the script file
	 * @throws IOException Thrown if an io error occurs.
	 */
	synchronized public String readLine() 
	    throws IOException {
	    return(this.reader.readLine());	    
	}
	
	
	/**
	 * Close the script file.
	 */
	synchronized public void close(){
		try {
			this.reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	public static void main(String[] args) {
	}
}
