package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotDisconnectTwoPortsException extends Exception {

    public CanNotDisconnectTwoPortsException() {
       super();
    }

    public CanNotDisconnectTwoPortsException(String message) {
       super(message);
    }

}