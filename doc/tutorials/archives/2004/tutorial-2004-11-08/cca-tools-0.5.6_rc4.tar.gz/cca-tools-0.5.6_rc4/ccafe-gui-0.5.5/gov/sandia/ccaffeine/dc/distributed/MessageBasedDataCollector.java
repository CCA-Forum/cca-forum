package gov.sandia.ccaffeine.dc.distributed;

import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;

class MessageBasedDataCollector implements ClientOutputCollector
{
    protected static final String END_OF_MESSAGE = "++++++END_OF_MESSAGE";
    protected static final char LINE_SEPARATOR = '\n';
    private ClientOutputRelay cRelay;
    private LinkedList messageList; // list of message tables - 
    // each message table will collect one line from each client, then 
    // send the collation of those lines back to the muxor. 
    public MessageBasedDataCollector ()
    {
	messageList = new LinkedList();
    }
    public MessageBasedDataCollector (ClientOutputRelay cRelay)
    {
	this.cRelay = cRelay;
	messageList = new LinkedList();
    }

    public void setClientOutputRelay( ClientOutputRelay cR) 
    {
	this.cRelay = cR;
    }

    public void controllerClientOutput(ClientOutputEvent evt)
    {
	String s = evt.getString();
	cRelay.relayMessageFromController(s);
    }
    /******************************************************************
     Notes: method is always called from ServerMux.clientOutput which
     is syncronized. It should, therefore, already be thread safe, but 
     just in case...
     
     The events coming in here should be from the "muxee" clients - ie,
     we should get a whole series of messages which need to be 
     combined into one and sent to the muxor.

     This particular data collector has 2 interesting qualities:
     1) each muxee can send multi-line messages, each ending in an end of 
        message line.
     2) the collector collects one message from each muxee, compares 
        them all, then constructs a message with the following 
	information: what distinct messages were recieved, and the
	machine names each was recieved from.

     Messages may also come in from other servers, which are acting as
     clients to this server. These must be parsed and re-collated 
     (probably the slowest part of the process - BUGBUG possibly could do 
     with some optimization here?)
     *****************************************************************/
    public void computeClientOutput(ClientOutputEvent evt)
    {
	Client src = (Client) evt.getSource();
	String s = evt.getString();
	int numClients = cRelay.getNumClients();
	Iterator iter = messageList.iterator();
	boolean mesgExists = false;
	MBMessageSet messages;
	while (iter.hasNext()) {
	    messages = (MBMessageSet) iter.next();
	    if (!messages.hasDataFromClient(src)) {
		messages.addClientOutput(src, s);
		mesgExists = true; // we have added this message
		if ((messages.isDone())) {
		    messageList.remove(messages);
		}
		break;
	    }
	}
	if (! mesgExists) {
	    // create a new message table for this message
	    messages = new MBMessageSet( cRelay, numClients );
	    messages.addClientOutput(src, s);
	    // make this the last message in the queue
	    messageList.addLast(messages);
	    if ((messages.isDone())) {
		messageList.remove(messages);
	    }
	}
    }

    public void processOutOfBand(OutOfBandEvent evt)
    {
    }

    // tell all pending messages that the client will not respond
    public void discardClientMessages(int clientId) {
	Iterator iter = messageList.iterator();
	MBMessageSet messages;
	while (iter.hasNext()) {
	    messages = (MBMessageSet) iter.next();
	    messages.discardClient(clientId);
	}
    }
}


/** This actually represents one "message" - it is a table of the different
   responses from the multiple clients, which should be compared and collated
   into a single response. 

   ready messages are from clients which have sent the end of message token 
   already, pending messages are from clients which have sent one or more 
   lines of text but have not yet sent the end of message token. 

   Lines of text are added to 

   numClients is the target number of clients - how many responses we should 
   have when the entire message is complete.

   The hash map of clients includes all clients which have finished 
   responding. If the message table still wants data for a client, the client
   will not be marked done - after a client is done, no more data should be 
   added to this message from this client.
*/
class MBMessageSet {
    private HashMap readyMessages;
    private HashMap pendingMessages;
    private HashMap clients;
    private ClientOutputRelay cRelay;
    private boolean done;
    private int numClients;
    public MBMessageSet (ClientOutputRelay cRelay, int numClients)
    {
	this.cRelay = cRelay;
	readyMessages = new HashMap();
	pendingMessages = new HashMap();
	clients = new HashMap();
	this.numClients = numClients;
    }

    boolean hasDataFromClient( Client client )
    {
	return (clients.containsKey(new Integer(client.getId())));
    }


  // BUGBUG: always called from the synchronous clientOutput in the 
  // ServerMux - make is sync anyway? (we are modifying the instance 
  // vars readyMessages & numMessages, which should be protected from 
  // threads)
    public void addClientOutput(Client client, String s)
    {
	if (cRelay == null) {
	    // BUGBUG - log an exception (but there is no relay to send 
	    // it to!)
	    return;
	}

	/* Put together individual lines of text to form a message from 
	   each client */

	// check to see whether we have started a message for this client yet
	// and add a new message if not
	PendingMessage pendingMessage = (PendingMessage) pendingMessages.get(new Integer(client.getId()));
	if (pendingMessage == null) {
	    pendingMessage = new PendingMessage(client);
	    pendingMessages.put(new Integer(client.getId()), pendingMessage);
	}

	// add our new line of text to the message and see if this client
	// has send us the end of message string yet.
	if (!pendingMessage.addText(s))
	    {
		return; // the message is not done, therefore don't do 
		// anything else with it yet
	    }

	// the message _is_ done (see the return above) and we can now add the
	// text to our list of messages recieved for this transaction
	String message = pendingMessage.getText();

	/* Organize messages - collect all copies of the same message and
	 record which client(s) each message came from */
	addMessage(message, client);

	// by this point we are done adding the message, whether it came 
	// from a client directly or through a server&client. Therefore,
	// mark this client done, for this response set.
	clients.put(new Integer(client.getId()), client);
	

	// print out a list of all unique messages, with the ids of the 
	// computers which generated them
	if(clients.size() == numClients) {
	    sendMessage();
	} else {
	    return;
	}
    }

    public void sendMessage() {
        // format the message
        String dataString = "";
        Iterator respIter = readyMessages.entrySet().iterator();
        while (respIter.hasNext())
            {
                Map.Entry entry = (Map.Entry) respIter.next();
                MessageData msg = (MessageData) entry.getValue();
 		dataString = msg.getFormattedMessageString() + dataString;
	    }
        cRelay.relayMessageFromDataProducers(dataString);
        cRelay.relayMessageFromDataProducers(MessageBasedDataCollector.END_OF_MESSAGE);
	readyMessages.clear();
	clients.clear();
	done = true;
    }

    public void addMessage(String fullMessage, Client client)
    {
	MessageData msg = new MessageData (fullMessage, client);
	MessageData foundMsg = (MessageData) readyMessages.get(msg);
	if (foundMsg != null) {
	    foundMsg.appendIds(msg.getIdList(), client);
	} else {
	    readyMessages.put(msg, msg);
	}
	
    }
    public boolean isDone () { return done; }
    
    public void discardClient (int clientId) {
	// BUGBUG - not impl - need to also remove from ready Messages?
	// otherwise, count may be wrong. Rely on muxee or muxor to resend?
	pendingMessages.remove(new Integer(clientId));
    }
}
/** a pending message consists of the text of the message (so far) and the 
    client it came from. The message is done when END_OF_MESSAGE is received. */
class PendingMessage {
    private boolean done;
    private String msgText;
    private Client client;
    public PendingMessage (Client client)
    {
	this.client = client;
	this.done = false;
	this.msgText = null;
    }
    public boolean isDone() { return done; }
    public Client getClient() { return client; }
    public String getText() { return msgText; }

    public boolean addText( String text )
    {
	if (text.startsWith( MessageBasedDataCollector.END_OF_MESSAGE )) {
	    done = true;
	} else {
	  if (msgText == null)
	    msgText = text;
	  else
	    msgText = msgText + MessageBasedDataCollector.LINE_SEPARATOR + text;
	}
	return done;
    }
}
