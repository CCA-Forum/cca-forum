package gov.sandia.ccaffeine.dc.user_iface.gui;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import gov.sandia.ccaffeine.dc.distributed.*;
import gov.sandia.ccaffeine.util.*;
/**
 * The menu/menubar that contains file options such as New, Open,
 * Save, Save As, and Quit.
 */
public class FileMenuBar extends JMenuBar{
    /**
     * Creates a new <code>FileMenuBar</code> instance with
     * a reference to the specified <code>Builder</code>.
     *
     * @param b  The super-parent of this <code>FileMenuBar</code>.
     */
    public FileMenuBar(GlobalData global){
	super();
	this.global = global;
	initialize();
    }
    private void initialize(){
	builder = global.getBuilder();
	arena   = global.getArena();
	actionsPanel = global.getActionsPanel();

	fileMenu    = new      JMenu("File"); 	
	newAction   = new  NewAction();
	quitAction  = new QuitAction();
	detachAction  = new DetachAction();

	fileMenu.add(    newAction);//.setAccelerator
	    //(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.ALT_MASK));
	fileMenu.addSeparator();
	fileMenu.add(   quitAction);//.setAccelerator
	    //(KeyStroke.getKeyStroke(KeyEvent.VK_Q, ActionEvent.ALT_MASK));
	fileMenu.add(   detachAction);//.setAccelerator
	    //(KeyStroke.getKeyStroke(KeyEvent.VK_D, ActionEvent.ALT_MASK));

	aboutMenu   = new JMenu("CCA Info");
	aboutAction = new AboutAction();
	aboutMenu.add(aboutAction);

	add(fileMenu);
	add(aboutMenu);

	aboutBox = new            AboutBox(new Frame());
   }

    /**
     * Called to confirm a document-closing event.
     * This method will ask the user if he/she wants
     * to save this document before it is closed. The options
     * that are offered are: Save before closing, Close without
     * saving, Cancel document-closing event.
     *
     * @return  true if not canceled; false otherwise
     */
    public boolean notCanceled() {
	if(global.getDocChanged()){
	    int confirmClose = JOptionPane.showConfirmDialog  
		( builder,                         
		  "Save changes before closing?" );
	    if(confirmClose != JOptionPane.CANCEL_OPTION){    
		if (confirmClose == JOptionPane.YES_OPTION)      
		    return(actionsPanel.saveResave());
		else
		    return true;
	    } else {
		            
		return false;
	    }
	} else {
	    return true;
	}
    }
	

    protected class NewAction extends AbstractAction{
	public NewAction(){
	    super("New");
	}
	public void actionPerformed(ActionEvent e){
	    if(notCanceled()){
		actionsPanel.clearArena();
		global.clearHistory();
		global.setDocChanged(false);
		global.setDocUnsaved(true);
		global.newName();
		builder.updateTitle();
	    }
		
	}
    }
    protected class QuitAction extends AbstractAction{
	public QuitAction(){
	    super("Quit");
	}
	public void actionPerformed(ActionEvent e){
	  global.shutdownFarEnd();
	    JOptionPane quitPane = 
		new JOptionPane("Waiting for framework to quit...");
	    quitPane.remove(1); // remove dismiss button
	    JDialog quitDialog = 
		quitPane.createDialog(global.getAppFrame(), "Quit Dialog");
	    quitDialog.setDefaultCloseOperation
		(WindowConstants.DO_NOTHING_ON_CLOSE);
	    quitDialog.show();

	    ((Component)global.getAppFrame()).setCursor
		(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
	}
    }
    protected class DetachAction extends AbstractAction{
	public DetachAction(){
	    super("Detach");
	}
	public void actionPerformed(ActionEvent e){
	  global.detachFarEnd();
	System.exit(0);
	}
    }
    protected class AboutAction extends AbstractAction{
	public AboutAction(){
	    super("About...");
	}
	public void actionPerformed(ActionEvent e){
		aboutBox.show();
	}
    }

    //This group defines parent containers
    private GlobalData         global;
    private Builder           builder;
    private Arena               arena;
    private ActionsPanel actionsPanel;

    //This group defines Menu components
    private JMenu          fileMenu;
    private NewAction     newAction;
    private QuitAction   quitAction;
    private DetachAction detachAction;
    private JMenu         aboutMenu;
    private AboutAction aboutAction;

    private AboutBox aboutBox;

    private class AboutBox extends JDialog{
	private Frame owner;
	private Container content;
	private final Color plainGray = new Color(204,204,204);
	public AboutBox(Frame owner){
	    super(owner,"About...");
	    this.owner = owner;
	    initialize();
	}
	private void initialize(){
	    JEditorPane editorPane = new JEditorPane();
	    if(LocalSystem.getCodeBaseURL()==null) // if we have an application, NOT applet
	    {
		String s = null;
		try {
		    //ResourceBundle rb = ResourceBundle.getBundle("gov.sandia.ccaffeine.dc.user_iface.gui.ccafeGUI");
		    //String path = rb.getString("aboutBoxPath");
		    //s = "file:"+path;
		    //System.err.println(s);
		    //URL aboutURL = new URL(s);
			ClassLoader classLoader = ClassLoader.getSystemClassLoader();
			java.net.URL urlAbout = classLoader.getResource("gov/sandia/ccaffeine/dc/user_iface/gui/about.html");			
		    editorPane.setPage(urlAbout);
		} catch(Exception e) {
		  System.err.println("FileMenuBar.AboutBox reports no about.html");
		    return;
		}
	    }
	    else // if we have an applet
            {
		URL cbase = LocalSystem.getCodeBaseURL() ;
		try{
		    URL aboutURL = new URL(cbase, "about.html");
		    editorPane.setPage(aboutURL);
		} catch(Exception e) {
		    e.printStackTrace(System.err);
		    return;
		}
	    }

	    editorPane.setMargin(new Insets(10,10,10,10));
	    editorPane.setEditable(false);
	    editorPane.setBackground(plainGray);

	    JScrollPane editorScrollPane = new JScrollPane(editorPane);
            editorScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
            editorScrollPane.setPreferredSize(new Dimension(500, 660));

	    JPanel dismissPanel = new JPanel();
	    dismissPanel.setLayout(new BoxLayout
		(dismissPanel,BoxLayout.X_AXIS));
	    JButton dismissButton = new JButton("Dismiss");
	    dismissButton.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
			dispose();
		    }
		});
	    dismissPanel.add(Box.createHorizontalGlue());
	    dismissPanel.add(dismissButton);
	    dismissPanel.add(Box.createHorizontalStrut(10));

	    content = getContentPane();
	    content.setLayout(new BoxLayout(content,BoxLayout.Y_AXIS));
	    content.add(editorScrollPane);
	    content.add(dismissPanel);
	    content.add(Box.createVerticalStrut(10));
	    setSize(500,660);
	}
    }
}
