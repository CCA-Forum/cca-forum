package gov.sandia.ccaffeine.dc.user_iface.MVC;



/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * When the end-user wants more information 
 * about a port, he/she can bring up some
 * helpful info.  This class holds the
 * contents of this help message.
 */
public class CcaPortParameterHelp {
    public String componentInstanceName = null;
    public String portInstanceName = null;
    public String dataFieldName = null;
    public String dataFieldHelp = null;

    
    /**
     * Parse the xml contents of the contents of the help
     * message that is attached to a port parameter.
     * The parsed values are copied into the class's attributes.
     * <p>
     * The XML code will contains something like this: <br>
     * &lt;paramCurrent&gt; <br>
     * &nbsp;&lt;componentInstanceName&gt;<br>
     * &nbsp;&nbsp;&nbsp;name1 <br>
     * &nbsp;&nbsp;&nbsp;&lt;/componentInstanceName&gt; <br>
     * &nbsp;&lt;portInstanceName&gt;name2&lt;/portInstanceName&gt; <br>
     * &nbsp;&lt;dataFieldName&gt;name3&lt;/dataFieldName&gt; <br> 
     * &nbsp;&lt;dataFieldHelp&gt;help1&lt;/dataFieldHelp&gt; <br>
     * &lt;paramCurrent&gt; <br>
     * @param xmlComponent The xml code of one component.
     */
    public CcaPortParameterHelp(String xml) {

        /*
         * Extract out the contents of the following tags:
         *    component name
         *    port name
         *    field name
         *    contents of help text
         */
        java.util.regex.Pattern pattern =
           java.util.regex.Pattern.compile
           ("<componentInstanceName>(.*?)</componentInstanceName>\\s*"
           +"<portInstanceName>(.*?)</portInstanceName>\\s*"
           +"<dataFieldName>(.*?)</dataFieldName>\\s*"
           +"<dataFieldHelp>(.*?)</dataFieldHelp>");

        java.util.regex.Matcher matcher = pattern.matcher(xml);


        /* copy the contents of the 4 tags to our attributes */
        if (matcher.find()) {
            this.componentInstanceName = matcher.group(1);
            this.portInstanceName = matcher.group(2);
            this.dataFieldName = matcher.group(3);
            this.dataFieldHelp = matcher.group(4);
        }
    }


}