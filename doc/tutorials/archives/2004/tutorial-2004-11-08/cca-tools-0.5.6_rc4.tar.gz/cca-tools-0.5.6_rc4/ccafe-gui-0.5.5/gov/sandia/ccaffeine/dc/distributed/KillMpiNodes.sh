#!/bin/sh
port=$1
#echo stomping port $port
ps -awwwx > procList-$port
#s1=`grep MuxingProcess procList-$port | grep makeItStopId_$port | awk '{print $1}'`
s2=`grep ccafe-client-$port procList-$port | awk '{print $1}'`
#echo Mux: $s1
#echo Clients: $s2
#if ! test "X$s1" = "X";  then
#	echo "kill -9 $s1"
#	kill -9 $s1
#else
#echo "No muxer found!"
#fi
if ! test "X$s2" = "X"; then
	#echo "kill -9 $s2"
	kill -9 $s2
#else
#echo "No clients found!"
fi
exit 0
