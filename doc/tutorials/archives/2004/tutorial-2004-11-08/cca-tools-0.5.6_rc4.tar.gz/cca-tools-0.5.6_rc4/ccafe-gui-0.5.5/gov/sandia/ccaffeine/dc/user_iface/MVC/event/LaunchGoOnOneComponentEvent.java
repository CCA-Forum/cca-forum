package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaCommandLaunchGoOnOneComponent;

public class LaunchGoOnOneComponentEvent extends java.util.EventObject {

    /* The go command */
    CcaCommandLaunchGoOnOneComponent commandGo = null;


    /**
     * Get the go command
     * @return The go command
     */
    public CcaCommandLaunchGoOnOneComponent getCommandGo() {
        return(this.commandGo);
    }

    /**
     * Set the go command
     * @param commandGo The go command
     */
    public void setCommandGo(CcaCommandLaunchGoOnOneComponent commandGo) {
        this.commandGo = commandGo;
    }


    /**
     * Create a LaunchGoOneOneComponentEvent.
     * @param source The entity that created this event.
     */
    public LaunchGoOnOneComponentEvent(Object source) {
        super(source);
        this.commandGo = null;
    }


    /**
     * Create a LaunchGoOneOneComponentEvent.
     * @param source The entity that created this event.
     * @param commandGo The go command.
     */
    public LaunchGoOnOneComponentEvent
          (Object source,
           CcaCommandLaunchGoOnOneComponent commandGo) {
        super(source);
        this.commandGo = commandGo;
    }


}