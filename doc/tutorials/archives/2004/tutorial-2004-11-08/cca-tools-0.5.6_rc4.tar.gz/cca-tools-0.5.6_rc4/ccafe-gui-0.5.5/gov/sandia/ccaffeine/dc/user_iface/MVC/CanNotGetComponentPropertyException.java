package gov.sandia.ccaffeine.dc.user_iface.MVC;

public class CanNotGetComponentPropertyException extends Exception {

  public CanNotGetComponentPropertyException() {
      super();
  }

  public CanNotGetComponentPropertyException(String message) {
      super(message);
  }


}