package gov.sandia.ccaffeine.dc.distributed;

import gov.sandia.ccaffeine.util.*;
import java.net.*;
import java.io.*;
import java.util.*;

/**
 * This class manages a set of connections (either one client connection to a 
 * server or many connections from clients). The connections in this manager 
 * are implemented using sockets, and can be reconnected through the manager.
 * Reconnection of a socket connection does not always mean you get a 
 * socket connected to the same client you had before you disconnected - the 
 * client sockets may connect in a different order.
 *
 *  Last modified by: $Author: rob $
 */
public class SocketConnectionMgr implements ConnectionManager {
    private Vector connections = new Vector();
    private SyncList disabledConnections = new SyncList();
    boolean isServer;
    private int serverPort; // Port on which the server will be listening.
    private String serverName;
    private int numMachines;
    private ConnectionNotification connectNotif;
    private boolean isConnected = false;
    private ServerSocket serverSocket;

    /**
       Construct a socket connection manager that acts as a server for the 
       given number of clients on the given port. */
    public SocketConnectionMgr(int numClients, int port)
    {
	isServer = true;
	this.numMachines = numClients + 1;
	this.serverPort = port;
    } 

    /**
       Construct a socket connection manager that acts as a client for the 
       given server name and port. */
    public SocketConnectionMgr(String serverName, int port)
    {
	isServer = false;
	this.serverName = serverName;
	this.serverPort = port;
    } 

    /** 
	Construct a socket connection manager based on a processor file. The 
	manager may turn out to be a server or client, depending on the 
	processor file and processor name given. 
	A processor file consists of several lines in the following format:
             <processorName> <"server" or "client">
	A typical file might look like:
	     127.0.0.1 server
	     0 client
	     1 client
    */
    public SocketConnectionMgr(String processorName, String procFile, int port) 
	throws Exception {
	serverPort = port;
	File f = new File(procFile);
	Properties p = new Properties();
	if(f.canRead()) {
	    InputStream in = new FileInputStream(f);
	    p.load(in);
	    in.close();
	} else {
	    throw new RuntimeException("File: "+f.getAbsolutePath()+
				       " cannot be read");
	}
	int myProcIndex = -1;
	Vector tmp = new Vector();
	for(Enumeration e = p.propertyNames();e.hasMoreElements();) {
	    String procName = (String)e.nextElement();
	    if(procName.compareTo(processorName) == 0) myProcIndex = tmp.size();
	    String type = p.getProperty(procName);
	    if(type.compareTo("client") == 0) {
		isServer = false;
	    } else if(type.compareTo("server") == 0) {
		isServer = true;
	    } else {
		throw new RuntimeException("Got a different type other than "+
					   "\"client\" or \"server\" in file"+
					   "The type is: "+type);
	    }
	    tmp.addElement(new ProcessorInfo(procName, isServer));
	}
	ProcessorInfo[] machines = new ProcessorInfo[tmp.size()];
	tmp.copyInto(machines);
	if(myProcIndex == -1) {
	    throw new RuntimeException("Apparently I do not appear in the "+
				       "processor file:"+procFile);
	}
	numMachines = machines.length;
	for(int i = 0;i < numMachines;i++) {
	    if(machines[i].isServer()) {
		serverName = machines[i].getName();
		if (i == myProcIndex)
		    isServer = true;
	    }
	}
    }



    /** 
	Construct a socket connection manager based on an array of
	<code>ProcessorInfo</code> objects. Typically the array will have been
	constructed using a processor file (see previous constructor).
    */
    public SocketConnectionMgr(int  myProcNumber, int serverPort, 
			       ProcessorInfo[] machines) {
	this.serverPort = serverPort;
	numMachines = machines.length;
	for(int i = 0;i < machines.length;i++) {
	    if(machines[i].isServer()) {
		serverName = machines[i].getName();
		if (i == myProcNumber)
		    isServer = true;
	    }
	}
    }




    /** 
	Disconnect all connections and close the serverSocket, if one 
	exists.
    */
    public void shutdown() throws IOException {
       /* 
       We have a SocketConnection to each MPI node.
       Disconnect each and every SocketConnection.
       */
	for (int i = 0; i < connections.size(); i++) {
	    ((Connection) connections.elementAt(i)).disconnect();
	}
	if (serverSocket != null)
	    serverSocket.close();
    }





    public void acceptConnections(int timeout) throws Exception {
    try {
	serverSocket = new ServerSocket(serverPort, 100);
	serverSocket.setSoTimeout(timeout); // time in milliseconds
    } catch(Exception e) {
	LocalSystem.err.println("Exception: "+e);
	LocalSystem.err.println("attempted to listen on port:"+serverPort);
	e.printStackTrace(LocalSystem.err);
	return;
    }
    for(int i = 0;i < numMachines - 1;i++) {
	Socket s;
	try {
	    s = serverSocket.accept();
	} catch ( java.io.InterruptedIOException e) {
	    continue; // the accept operation timed out
	}
	connections.add(new SocketConnection(s, i, this));
    }
  }



  public void connectToServer() throws Exception {
    Socket s = new Socket(serverName, serverPort);
    connections.add( new SocketConnection(s, 0, this));
  }

    protected void reconnectConnection(SocketConnection connect, int timeout) throws Exception {
	if (isServer) {
	    ServerSocket t;
	    try {
		if (serverSocket == null) {
		    serverSocket = new ServerSocket(serverPort, 100);
		}
		serverSocket.setSoTimeout(timeout); // time in milliseconds
	    } catch(Exception e) {
		LocalSystem.err.println("Exception: "+e);
		LocalSystem.err.println("attempted to listen on port:"+serverPort);
		e.printStackTrace(LocalSystem.err);
		return;
	    }
	    if (connect.isDisabled()) {
		Socket s;
		try {
		    s = serverSocket.accept();
		} catch ( java.io.InterruptedIOException e) {
		    return; // BUGBUG - error message here!!
		}
		disabledConnections.syncRemove(connect);
		connect.setSocket(s);
	    }
	} else {
	    LocalSystem.err.println("re connecting to server from client");
	    Socket s = new Socket(serverName, serverPort);
		connect.setSocket(s);
	}

    }
	    


    public boolean isServer() {
	return isServer;
    }




    public boolean isConnected() {
	return isConnected;
    }

    public void  connect(int timeout) {
        LocalSystem.err.println("I have port " + serverPort);
	if(isServer()) {
	    try {
                LocalSystem.err.println("I am a server waiting for connections");
		acceptConnections(timeout);
                LocalSystem.err.println("I am connected");
	    } catch(Exception e) {
		LocalSystem.printException(e);
		throw new RuntimeException("SocketConnectionMgr: "+
					   "Socket accept failed.");
	    }
	} else {
	    try {
                LocalSystem.err.println
                   ("I am not a server waiting for connections");
		connectToServer();
                LocalSystem.err.println("I am connected");
	    } catch(Exception e) {
		LocalSystem.printException(e);
		throw new RuntimeException("SocketConnectionMgr: "+
					   "SocketConnection could not be made");
	    }
	}
	isConnected = true;
        LocalSystem.err.println("port " + serverPort + " is connected.");
    }
    

    public Vector getConnections() {return connections;}
    

    /** temporarily takes the connection out of service */
    public void disableConnection (Connection connection)
    {
	int size = disabledConnections.syncAdd(connection);
	// if we added the first connection in the queue, restart the 
	// thread that will do reconnects.
	//	if (size == 1) 
	//	    disabledConnections.syncNotify();
	
    }

    // removes the connection entirely
    public void removeConnection (Connection connection) {
	connections.remove(connection);
	try {
	    connection.disconnect();
	} catch (IOException e) {
	    LocalSystem.err.println("Exception in LinewiseClient");
	    e.printStackTrace(LocalSystem.err);
	}
    }

  // connects to any disconnected connections still present - these
  // connections will not necessarily be connected to the same 
  // machine they were originally (ie, the connection with id 0 still
  // has id 0, but may connect to a different machine. clients can't 
  // make any assumptions about the state of a machine they reconnect to.)
  //
  // reconnect and disconnectConnection are thread safe with respect to 
  // each other.
  //
  // reconnect reconnects _all_ connections and should be run as a loop 
  // in a separate thread.
  //
  public void reconnect(int timeout) throws Exception{
      LocalSystem.out.println("Got a request to reconnect entire socket mgr " +
			      " - not implemented yet");
    if(isServer()) {
      //try { BUGBUG
	//	while (true) {
	//reacceptConnections(timeout);
	/*
	  if (disabledConnections.syncSize() == 0) {
	  disabledConnections.syncWait();
	  }*/
	//	}
      //} catch(Exception e) {
      //LocalSystem.printException(e);
      //throw new RuntimeException("SocketConnectionMgr: "+
      //			   "SocketConnection could not be remade");
      //}
    } else {
      try {
	connectToServer();
      } catch(Exception e) {
	LocalSystem.printException(e);
	throw new RuntimeException("SocketConnectionMgr: "+
				   "SocketConnection could not be made");
	    }
    }
  }

  // gets the number of connections we expect to 
  // be transimitting data currently
  public int getNumConnected() {
    return connections.size() - disabledConnections.syncSize();
  }
  
  // setup a callback so that we are notified when connections
  // are established
  public void setConnectionNotification (ConnectionNotification notif) {
    connectNotif = notif;
  }
};



/**

   This class is a thread safe wrapper around a linked list. It does
   not repeat the list interface precisely - it only provides the
   minimum amount of functionality needed by the
   <code>SocketConnectionManager</code>, with some additions not found
   in the standard List interface. Specifically, there was a need for
   an atomic add/getsize operation (provided by syncAdd, which returns
   the size of the list after the add).  

   None of these synchronized methods wait on any other sync primitives -
   they should all return promptly. (Except for sync wait).

* Last modified by: $Author: rob $ 

*/
class SyncList {
    LinkedList connections = new LinkedList();
    /** add an element to the list of disabled connections and 
	get the size of the list in one atomic operation (this way
	you get the size directly after the add - other adds and removes
	can't happen in between the add() and size() operations, as long 
	as the adds and removes always happen through these two sync methods
    */
    public synchronized int syncAdd(Connection connection) {
	connections.add(connection);
	return connections.size();
    }
    public synchronized boolean syncRemove (Connection connect) {
	return connections.remove(connect);
    }
    public synchronized int syncSize() {
	return connections.size();
    }
    public synchronized void syncNotify(){
	notify();
    }
    public synchronized void syncWait() throws java.lang.InterruptedException {
	wait();
    }

}

/**

  reconnect should _not_ be synchronized because it does some waiting on the
  server socket and may never return.
 *  Last modified by: $Author: rob $
 */
class SocketConnection implements Connection {
    Socket socket;
    int id;
    boolean disabled;
    SocketConnectionMgr manager;

    public SocketConnection (Socket socket, int id, SocketConnectionMgr manager){
	this.socket = socket;
	this.id = id;
	this.manager = manager;
	// always set disabled _last_, since we are not synchronizing the
	// methods which access these instance vars - if disbabled is false,
	// other methods will assume the rest of the instance vars are OK too.
	// Therefore don't set it until they are.
	this.disabled = false;
    }

    public void setSocket ( Socket socket) {
	this.socket = socket;
	this.disabled = false;
	LocalSystem.out.println("reconnected to socket :" + id); 
    }
    public synchronized String getSourceName() {
	if (!disabled) {
	    return socket.getInetAddress().toString();
	} else {
	    return null;
	}
    }
    public synchronized InputStream getIn() {
	if (!disabled) {
	    try {
		return socket.getInputStream();
	    } catch (Exception e) {
		LocalSystem.printException(e);
		throw new RuntimeException("ClientServerSocket: "+
					   "not a valid socket. No " +
					   "input stream.");
	    }
	} else {
	    return null;
	}
    }
    public synchronized OutputStream getOut() {
	if (!isDisabled()) {
	    try {
		return socket.getOutputStream();
	    } catch (Exception e) {
		LocalSystem.printException(e);
		throw new RuntimeException("ClientServerSocket: "+
					   "not a valid socket. No " +
					   "output stream.");
	    }
	} else {
	    return null;
	}
    }
    public int getId() {
	return id;
    }
    public synchronized void disconnect() throws java.io.IOException {
	if (!isDisabled()) {
	    // always set disabled _first_ - see comment in the constructor
	  disabled = true;
	  // BUGBUG - attempt to send a disconnect message to the client, just
	  // in case its still listening
	  manager.disableConnection(this);
	  socket.close();
	  socket = null; // close and throw away the socket
	}
    }
    public void reconnect(int timeout) throws Exception {
      manager.reconnectConnection(this, timeout);
    }
    public boolean isDisabled() {
	return disabled;
    }
    public ConnectionManager getConnectionManager() {
	return manager;
    }

}
