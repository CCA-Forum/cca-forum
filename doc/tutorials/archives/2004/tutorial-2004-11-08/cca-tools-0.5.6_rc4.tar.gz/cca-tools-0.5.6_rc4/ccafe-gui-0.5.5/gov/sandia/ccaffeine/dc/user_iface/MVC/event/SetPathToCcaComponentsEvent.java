package gov.sandia.ccaffeine.dc.user_iface.MVC.event;

/**
 * Used to notify listeners that the path to the cca components
 * is set.
 */

public class SetPathToCcaComponentsEvent extends java.util.EventObject {

    /*
     * The path to the CCA component.
     */
    String path = null;


    /**
     * Get the path to the cca componets.
     * @return The path to the cca components.
     */
    public String getPath() {
        return(this.path);
    }


    /**
     * Set the path to the cca componets.
     * @param path The path to the cca components.
     */
    public void getPath(String path) {
        this.path = path;
    }


    /**
     * Construct a SetPathToCcaComponentsEvent.
     * @param source the entity that originated this event.
     */
    public SetPathToCcaComponentsEvent(Object source) {
        super(source);
        this.path = null;
    }

    /**
     * Construct a SetPathToCcaComponentsEvent.
     * @param source the entity that originated this event.
     * @param path the path to the cca components.
     */
    public SetPathToCcaComponentsEvent(Object source, String path) {
        super(source);
        this.path = path;
    }


}