package gov.sandia.ccaffeine.dc.user_iface.MVC.event;
import java.util.EventObject;

public class FixSharedLibraryEvent extends EventObject {

    public FixSharedLibraryEvent(Object source) {
        super(source);
    }

}