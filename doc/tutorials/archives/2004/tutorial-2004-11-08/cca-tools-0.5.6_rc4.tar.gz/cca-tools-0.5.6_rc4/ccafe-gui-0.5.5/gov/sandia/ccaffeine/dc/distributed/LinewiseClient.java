package gov.sandia.ccaffeine.dc.distributed;

import java.net.*;
import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;


/** Client that muxes line-by-line, flushing on output */
class LinewiseClient implements Client {
  /** Socket seems to have been dropped on the far end or an end of
      file has been reached. */
  private static int SOCK_EOF_REACHED = 0;
  /** Socket is readable and functioning normally. */
  private static int SOCK_CONNECTED = 1;
  /** Socket is not connected. */
  private static int SOCK_UNCONNECTED = 2;
  /** Current state of the socket. */
  private int sockStatus = SOCK_UNCONNECTED;
  private int clientId = -7;
  private List output = new Vector();  // lines of output
  /** Number of lines to keep in scope for each client. */
  private static int OUTPUT_HIGH_WATER_MARK = 30;
  private static int OUTPUT_LOW_WATER_MARK = 15;
  private Vector lsnrs = new Vector();
  private long charCount = 0;
  public BufferedReader in;
  public PrintWriter out;
  private ClientOutputListener xLsnr;
  private boolean finished = false; // has shutdown been called?
  private boolean disconnected = false;
  private String name;
  private Connection connection;
  /** This is the message that the SocketException ahs when the peer
      has dropped its end of the socket.  Near as anyone can tell,
      there is no functional way to gracefully quit a socket in java
      without defining a one-off protocol. */
  private String[] peerDroppedMsgs = { "Connection reset by peer",
				       "Broken pipe" };

  /** Constructor: takes a generic connection which the linewise
      client will read from and write to using IO streams. */
  public LinewiseClient(Connection connect) {

    this.in = new BufferedReader( new InputStreamReader(connect.getIn()));
    this.out = new PrintWriter(connect.getOut(), true /* flush on println */);
    this.clientId = connect.getId();
    this.name = clientId + ":" + connect.getSourceName();
    this.connection = connect;
    sockStatus = SOCK_CONNECTED;
  }

  /** This method runs in a separate thread and handles reading
      strings from the in stream of the connection. Right now it
      also handles disconnecting and reconnecting the connection -
      once we move this code to C++ most of that logic should move
      to a separate, centralized connect thread. */
  public void run() {
    String str;
    try {
      while(true) {

        /* read a line from our client */
	try {
	  str = in.readLine();
	} catch(SocketException se) {
	  if(finished) {
	    return;
	  }//if finished
	  String msg = se.getMessage();
	  if(peerHasDropped(msg)) {
	    sockStatus = SOCK_EOF_REACHED;
	  } //if(peerHasDropped(msg)
          else {
	    LocalSystem.err.println("Client "+clientId+
				    " Connection dropped by "+
				    "controlling side, "+
				    "disconnected = "+disconnected+
				    " finished = "+finished);
	    LocalSystem.err.println("call stack follows:");
	    se.printStackTrace(LocalSystem.err);
	  } // else if(peerHasDropped(msg)
	  str = ""; // shut the compiler up.
	}//catch(SocketException se)


	// Sometimes and EOF condition is indicated by a null
	// string (who knows why).
	if(   (sockStatus != SOCK_EOF_REACHED)
	      && (sockStatus != SOCK_UNCONNECTED)
	      && (str == null)) {
	  sockStatus = SOCK_EOF_REACHED;
	}
	if(sockStatus == SOCK_EOF_REACHED) {
	  // The peer has dropped the connection.  This may
	  // not be a real error but just a closed socket on
	  // the other side that was not gracefully handled
	  // by java.  Check to see if we have been
	  // disconnected by the parent thread.
	  if(finished) {
	    // Yup, that's what it was.
	    return;
	  } //if finished
          else if(disconnected) {
	    // Yup, that's what it was.
	    // at this point we _know_ someone asked to
	    // disconnect this client and we should
	    // destroy the connection and wait for the
	    // client to come back again

	    LocalSystem.out.println("Disconnecting client: " +
				    clientId);
	    connection.disconnect();
	    LocalSystem.out.println("Waiting for reconnect "+
				    "on client: " + clientId);
	    connection.reconnect(0); // infinite timeout
	    disconnected = false;
	    sockStatus = SOCK_CONNECTED;
	    in = new BufferedReader(new InputStreamReader(connection.getIn()));
	    out = new PrintWriter(connection.getOut(), true);

	  } //if(disconnected)
          else {
	    if(finished) {
	      return;
	    }//if finished
	    //Nope.  There appears to be a real problem.
	    String msg = "Client "+clientId+
	      " Connection dropped by "+
	      "controlling side "+
	      "disconnected = "+disconnected+
	      " finished = "+finished;
            shutdown();
	    throw new RuntimeException(msg);
	  } //else if(disconnected)
	} //if(sockStatus == SOCK_EOF_REACHED)

        /*
        Copy the line (that we read from our client)
        to a buffer.
        Encapsulate the line in a ClientOutputEvent
        and then send the event to listeners.
        */
        else {
	  addOutput(str);
	  notifyOutput(str);
	}//else

      }//while
    } catch(Exception e) {
      // when the file is closed on the other side, if that results in
      // the socket beig torn down, then we will get an error.  Unless
      // we have some out-of-band protocol for determining a shutdown
      // condition, we will get an error here.  It would be nice if,
      // before the Socket is torn down, an end-of-file condition
      // would be passed through, this would be more consistent.
      if(!finished) {
	LocalSystem.err.println("Exception for Client: "+clientId+
				" message: "+e.getMessage());
	e.printStackTrace(LocalSystem.err);
	throw new RuntimeException(e.getMessage());
      }//if(!finished)
    }//catch(Exception e)
    LocalSystem.out.println("Shutting down Client # : " + clientId );
  }//method




  /** Mark the LinewiseClient disconnected - the run loop will realize
      that it is disconnected when it does its next read. */
  public synchronized void disconnect() {
    disconnected = true;
  }




  /** Marks this client shudown and closes the connection so that the
      read loop in run() ends. */
  public void shutdown() {
    LocalSystem.err.println("Shutting down linewiseClient");
    LocalSystem.err.flush();
    finished = true;
    try {
      connection.disconnect(); // closes the socket and drops us out of the
      // run loop
    } catch(IOException e) {
      LocalSystem.err.println("Exception in LinewiseClient");
      e.printStackTrace(LocalSystem.err);
    }finally {
       /* tell everyone this sever is dead */
       broadcastShutdown();
    }
  }




  /** Lets the listeners for this client know about data coming in from
      the connection */
  protected void notifyOutput(String s) {
    ClientOutputEvent evt = new ClientOutputEvent(this, s);
    for(Enumeration e =  lsnrs.elements(); e.hasMoreElements();) {
      ((ClientOutputListener)e.nextElement()).clientOutput(evt);
    }
  }




  /** Keeps a (limited) buffer of saved output lines */
  protected synchronized void addOutput(String s) {
    // keep the number of output lines saved between the
    // low water mark and the high water mark.
    if (output.size() > OUTPUT_HIGH_WATER_MARK) {
      output = output.subList(OUTPUT_HIGH_WATER_MARK - OUTPUT_LOW_WATER_MARK, OUTPUT_HIGH_WATER_MARK);
    }
    output.add(s);
  }





  public void addClientOutputListener(ClientOutputListener l) {
    lsnrs.addElement(l);
  }




  public List getOutput() {
    return output;
  }





  // BUGBUG - is this thread safe? can it throw when the connection
  // is disconnected?
  /** Writes to the output stream provided by the connection */
  public void write(String s) {
    out.println(s);
  }




  public void flush() {
    out.flush();
  }




  public int getId() {
    return clientId;
  }




  public String getSourceName() {
    return name;
  }




  private boolean peerHasDropped(String msg) {
    if(msg == null) {
      return false;
    }
    for(int i = 0;i < peerDroppedMsgs.length;i++) {
      if(msg.indexOf(peerDroppedMsgs[i]) != -1) {
	return true;
      }
    }
    return false;
  }






    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/

    Vector shutdownListeners = new Vector();

    /**
     * Register a Shutdown Listener.
     * Whenever this class shutdown this server
     * then notify this listener.
     * @param listener The Shutdown Listener
     * that wants to be notified whenever this class
     * shuts down this server.
     */
    synchronized public void addShutdownListener(ShutdownListener listener)
    {
         shutdownListeners.add(listener);
    }

    /**
     * Unregister a Shutdown Listener.
     * Whenever this class shutdown this server
     * then do NOT notify this listener.
     * @param listener The Shutdown Listener
     * that no longer wants to be notified
     * whenever this class shutsdown this server.
     */
    synchronized public void removeShutdownListener(ShutdownListener listener)
    {
         shutdownListeners.remove(listener);
    }


    /**
     * Tell all registered Shutdown listeners
     * that we are shutting down this server.
     */
    public void broadcastShutdown(){
        ShutdownEvent event = new ShutdownEvent(this);
        broadcastShutdown(event);
    }

    /**
     * Tell all registered Shutdown listeners
     * that we are shutting down this server.
     * @param event The event that is generated
     * whenever this class shuts down the server.
     */
    protected void broadcastShutdown(ShutdownEvent event)
    {
         // loop through each listener and pass on the event if needed
         Vector listeners;
            synchronized (this) {
                listeners = (Vector)shutdownListeners.clone();
         }
         int numberOfListeners = listeners.size();
         for (int i=0; i<numberOfListeners; i++){
             ShutdownListener x = (ShutdownListener)listeners.elementAt(i);
             x.serverShuttingDown(event);
         }
    }










    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/
    /*-------------------------------------------------------------------*/




}
