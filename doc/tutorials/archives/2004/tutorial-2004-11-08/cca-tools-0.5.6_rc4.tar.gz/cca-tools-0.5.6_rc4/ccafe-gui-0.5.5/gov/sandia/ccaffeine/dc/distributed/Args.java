package gov.sandia.ccaffeine.dc.distributed;
import gov.sandia.ccaffeine.util.LocalSystem;
import gnu.getopt.*;
import java.util.*;
import java.io.*;


/** Simple argument class for the Builders.  Not all arguments make
    sense in all contexts. */
public class Args {
  public static final String DEFAULTPROCFILEPATH = "processors";
  public static final int DEFAULTPORT = 2023;
  public static final int DEFAULTBUILDERPORT = 2024;
  /** Port to listen on. */
  public int portNumber = DEFAULTPORT;
  /** Port number for the builder to contact the MuxingProcess. */
  public static int builderPort = DEFAULTBUILDERPORT;
  /** Name of the type of run to be done, may not be used. */
  public static String type; 
  /** Path to the processor file. */
  public static String procFile;
  /** The name, found in the processor file, that refers to this process */
  public static String myProcName = null;
  /** The name, found in the processor file, that refers to this process */
  public static String myServerMachineName = null;
  /** Timeout that a server should wait for the client to
      connect. Zero means infinity. */
  public long timeout = -1;

  public static String logFile = null;
  public static int heartbeatTimeout = 0;

  public Args() {
  }
  /** Create an Args with the String array argument; parseArgs does
      not need to be called */
  public Args(String[] s) {
    parseArgs(s);
  }
  public void parseArgs(String[] args) {

    String usage = "<MuxingProcess> --name MyName "+
      "[--file procDefinitionFile]"+
      "[--timeout millisec]"+"[--builderPort port]"+
      "[--port port] [--nextServerName machineName]"+
      "[--logFile filename]" +
      "[--heartbeatTimeout millisec]" +
" \n"+
"  --file procDefinitionFile (required)\n"+
"         A processor definition file that associates names with machine \n"+
"        and processor locations of the layout for this parallel run.\n"+
"\n"+
"  --name MyName (required)\n"+
"         The name for this server appearing in the processor definition file.\n"+
"\n"+
"  --builderPort port\n"+
"         The port to listen on for a connection from the single process\n"+ 
"         expecting multiplexed IO.\n"+
"\n"+
"  --port port\n"+
"         The port to listen on for multiple connections from the parallel \n"+
"         processes.  \n"+       
"\n"+
"  --logFile filename\n" +
"         The name of the file that contains debug status info from the Muxer \n"+
"\n"+
"  --heartbeatTimeout\n"+
"         The number of milliseconds after which an idle builder client is assumed dead. \n" +
"\n"+
"  --timeout\n"+
"         The number of milliseconds we will wait for the clients to make their \n" +
"         initial connection to the Muxer." +
"\n";



    procFile = DEFAULTPROCFILEPATH;

    StringBuffer sb = new StringBuffer();
    LongOpt[] longopts = new LongOpt[8];
    longopts[0] = new LongOpt("name", LongOpt.REQUIRED_ARGUMENT, sb, 'n');
    longopts[1] = new LongOpt("file", LongOpt.REQUIRED_ARGUMENT, sb, 'f');
    longopts[2] = new LongOpt("builderPort", LongOpt.REQUIRED_ARGUMENT, sb, 
			      'u');
    longopts[3] = new LongOpt("port", LongOpt.REQUIRED_ARGUMENT, sb, 
			      'p');
    longopts[4] = new LongOpt("timeout", LongOpt.REQUIRED_ARGUMENT, sb, 
			      'i');
    longopts[5] = new LongOpt("nextServerName", LongOpt.REQUIRED_ARGUMENT, sb, 
			      's');
    longopts[6] = new LongOpt("logFile", LongOpt.REQUIRED_ARGUMENT, sb, 'l');
    longopts[7] = new LongOpt("heartbeatTimeout", LongOpt.REQUIRED_ARGUMENT, sb, 
			      'h');



    /* We want to remove --makeItStopId_xxxx from the args array */
    Vector v = new Vector();
    for (int i=0; i<args.length; i++) {
        if (args[i].startsWith("--makeItStopId_")) continue;
        v.add(args[i]);
    }
    args = new String[v.size()];
    for (int i=0; i<v.size(); i++)
        args[i] = (String)v.get(i);
   


    Getopt g = new Getopt("TestClientServer", args, "n:f:t:u:p:i:s:l:h", longopts);
    String theOption;
    type = "0";
    int c;
    String errorMessage = "";
    while((c = g.getopt()) != -1) {
      switch(c) {
      case 'n':
	//Name of processor I am on.
	theOption = "name";
	break;
      case 'f':
	//File to read
	theOption = "file";
	break;
      case 'u':
	theOption = "builderPort";
	break;
      case 'p':
	theOption = "port";
	break;
      case 'i':
	theOption = "timeout";
	break;
      case 's':
	theOption = "nextServerName";
	break;
      case 'l':
	theOption = "logFile";
        break;
      case 'h':
	theOption = "heartbeatTimeout";
        break;
      default:
      case '?':
	LocalSystem.err.println(usage);
	return;
      case 0:
	theOption = longopts[g.getLongind()].getName();
	break;
      }
      if(theOption == "name") {
	myProcName = g.getOptarg();
      } else if(theOption == "file") {
	procFile = g.getOptarg();
      } else if(theOption == "port") {
	portNumber = Integer.parseInt(g.getOptarg());
      } else if(theOption == "builderPort") {
	builderPort = Integer.parseInt(g.getOptarg());
      } else if(theOption == "timeout") {
	timeout = Long.parseLong(g.getOptarg());
      } else if(theOption == "nextServerName") {
	myServerMachineName = g.getOptarg();
      } else if (theOption == "logFile") {
        logFile = g.getOptarg();
      } else if(theOption == "heartbeatTimeout") {
	heartbeatTimeout = Integer.parseInt(g.getOptarg());
      } else {
    	    LocalSystem.err.println("Bad Option: "+theOption);
            if (errorMessage.equals(""))
	        errorMessage = usage;
      }
       
    }//while

    if ((!errorMessage.equals("")) || (myProcName == null)) {
      LocalSystem.err.println(usage);
      return;
    }//if

  }//method


}

