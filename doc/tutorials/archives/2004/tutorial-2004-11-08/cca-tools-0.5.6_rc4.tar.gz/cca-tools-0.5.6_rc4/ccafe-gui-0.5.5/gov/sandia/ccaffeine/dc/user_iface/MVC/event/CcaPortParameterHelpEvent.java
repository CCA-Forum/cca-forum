package gov.sandia.ccaffeine.dc.user_iface.MVC.event;


/**
 * Cca components contain ports.
 * Some of the ports contain data fields.
 * This event can be used to notify components
 * that the cca server is sending the text that
 * contains helpful information on the data field.
 * A client entity might respond by setting up a
 * help system inside of a dialog box.
 * <p>
 * Possible Scenario: <br>
 * An end-user clicks on a blue port inside of a component <br>
 * client sends "parameters" to server <br>
 * serer- sends "ParamDialog" to client <br>
 * client responds by creating an empty dialog box <br>
 * server sends "ParamTab" to client <br>
 * client responds by inserting a new tab in the dialog box <br>
 * server sends "ParamField" to client <br>
 * client responds by inserting a blank data line into the dialog box <br>
 * server sends "ParamCurrent" to client <br>
 * client responds by inserting the data's value into the dialog box <br>
 * server sends "ParamHelp" to client <br>
 * client responds by setting the text that is displayed if the help button is clicked <br>
 * server sends "ParamPrompt" to client <br>
 * client responds by displaying a prompt to the left of the data's value <br>
 * server sends "ParamDefault" to client <br>
 * client responds by setting the data's default value <br>
 * server sends "ParamStringChoice" to client <br>
 * client responds by setting an item in the value's choice box <br>
 * server sends "ParamNumberRange" to client <br>
 * client responds by setting the data value's range of allowed values <br>
 * server sends  "ParamEndDialog" to client <br>
 * client responds by displaying the dialog box on the screen <br>
 */

import gov.sandia.ccaffeine.dc.user_iface.MVC.CcaPortParameterHelp;

public class CcaPortParameterHelpEvent 
       extends java.util.EventObject {

    CcaPortParameterHelp ccaPortParameterHelp = null;

    public CcaPortParameterHelp
           getCcaPortParameterHelp() {
              return(this.ccaPortParameterHelp);
    }

    public void setCcaPortParameterHelp
        (CcaPortParameterHelp ccaPortParameterHelp) {
        this.ccaPortParameterHelp = ccaPortParameterHelp;
    }

    public CcaPortParameterHelpEvent(Object source) {
        super(source);
        this.ccaPortParameterHelp = null;
    }

    public CcaPortParameterHelpEvent
           (Object source,
            CcaPortParameterHelp ccaPortParameterHelp) {
        super(source);
        this.ccaPortParameterHelp = ccaPortParameterHelp;
    }
}