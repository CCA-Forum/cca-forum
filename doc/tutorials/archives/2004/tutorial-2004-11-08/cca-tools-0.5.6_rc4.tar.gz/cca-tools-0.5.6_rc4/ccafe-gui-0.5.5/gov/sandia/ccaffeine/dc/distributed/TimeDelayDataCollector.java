package gov.sandia.ccaffeine.dc.distributed;

import java.util.*;
import java.io.*;
import gov.sandia.ccaffeine.util.*;

class TimeDelayDataCollector implements ClientOutputCollector
{
    public static final String TIME_DELAY_MSG = "TIME_DELAY=";
    private TDMessageTable messages;
    private Thread tTable;
    private ClientOutputRelay cRelay;
    public TimeDelayDataCollector ()
    {
	LocalSystem.err.println("Started time delay data collector...");
    }
    public TimeDelayDataCollector (ClientOutputRelay cRelay)
    {
	LocalSystem.out.println("Started time delay data collector...");
	this.cRelay = cRelay;
	messages = new TDMessageTable(cRelay);
	tTable = new Thread (messages);
	tTable.start();
    }

    public void setClientOutputRelay( ClientOutputRelay cR) 
    {
	this.cRelay = cR;
	messages = new TDMessageTable(cRelay);
	tTable = new Thread (messages);
	tTable.start();
    }

    public void controllerClientOutput(ClientOutputEvent evt)
    {
	String s = evt.getString();
	cRelay.relayMessageFromController(s);
    }
    /******************************************************************
     Notes: method is always called from ServerMux.clientOutput which
     is synchronized. It should, therefore, already be thread safe, but 
     just in case...
     
     The events coming in here should be from the "muxee" clients - ie,
     we should get a whole series of messages which need to be 
     combined into one and sent to the muxor.

     This particular data collector has the following interesting qualities:
     1) each message is held for at least a set time delay - if any other 
     message which match the message text exactly come along during this
     delay, they are combined and sent on as one message.

     message format:

     combination of messages:

     setting the time delay:
     *****************************************************************/
    public void computeClientOutput(ClientOutputEvent evt)
    {
	Client src = (Client) evt.getSource();
	String s = evt.getString();
	messages.addClientOutput( src, s );
    }


    public void processOutOfBand(OutOfBandEvent evt)
    {
	String str = evt.getOutOfBandCommand();
	if (str.startsWith(TIME_DELAY_MSG)) {
	    // from after the = to just before the >>
	    String setting = str.substring(TIME_DELAY_MSG.length(), str.length());
	    LocalSystem.out.println("Setting time delay and interrupting thread");
	    messages.setTimeDelay(Long.parseLong(setting));
	    tTable.interrupt();
	}
	else
	    return;
    }

}


class TDMessageTable implements Runnable {
    // so that we can find matching messages quickly
    private HashMap waitingLines; 
    // so that we remember what order the messages came in (send in same order)
    private LinkedList lineQueue;
    private ClientOutputRelay cRelay;
    private long timeDelay = 0; // in millisecs

    public TDMessageTable (ClientOutputRelay cRelay)
    {
	this.cRelay = cRelay;
	waitingLines = new HashMap();
	lineQueue = new LinkedList();
    }

    public void run() {
	while (true) {
	    try {
		Thread.currentThread().sleep(timeDelay); // a time delay
		// of 0 will cause this thread to sleep until interrupted
		checkSendMessages();
	    } catch (InterruptedException e) {
		LocalSystem.out.println("interrupting thread");
		checkSendMessages();
		continue;
	    }
	}
    }
    void setTimeDelay(long timeDelay) { this.timeDelay = timeDelay; }

    public void addClientOutput(Client client, String s)
    {
	if (cRelay == null) {
	    // BUGBUG - log an exception (but there is no relay to send 
	    // it to!)
	    return;
	}

	// all messages should start with identifying information, in
	// one of the following formats: 
	//       <<idlist>>, !<<idlist>> or #<<idlist>>
	addMessage(s, client);
	

	// print out a list of all unique messages, with the ids of the 
	// computers which generated them
	checkSendMessages();
    }

    public synchronized void checkSendMessages() {
	// format the message
	String dataString = "";
	ListIterator respIter = lineQueue.listIterator();
	while (respIter.hasNext()) {
	    
	    TDMessage msgData = (TDMessage) respIter.next();
	    if(( System.currentTimeMillis() - msgData.getLastModifiedTime()) >= timeDelay) {
		dataString = msgData.getFormattedMessageString();
		cRelay.relayMessageFromDataProducers(dataString);
		waitingLines.remove(msgData);
		respIter.remove();
		dataString = "";
	    } else {
		// if we've found any messages that we aren't going to send
		// definitely don't send the rest of the (later) messages in
		// the queue
		break;
	    }
	}
    }

    public synchronized void addMessage(String message, Client client)
    {
	TDMessage msgData = new TDMessage (message, client);
	TDMessage foundData = (TDMessage) waitingLines.get(msgData);
	
	if ((foundData != null) && (!foundData.hasClientData(client)))
	    {
		foundData.appendIds(msgData.getIdList(), client);
	    }
	else
	    {
		waitingLines.put(msgData, msgData ); // insert the message data
		//with the message as the key
		lineQueue.addLast(msgData);
	    }
	
    }
    
}

class TDMessage extends MessageData{
    long lastModified = System.currentTimeMillis();

    public TDMessage (String fullMessage, Client client)
    {
	super(fullMessage, client);
    }
    public long getLastModifiedTime() { return lastModified; }

    public void appendIds(String idList, Client client) { 
	super.appendIds(idList, client);
	lastModified = System.currentTimeMillis(); // reset the time
    }


}
