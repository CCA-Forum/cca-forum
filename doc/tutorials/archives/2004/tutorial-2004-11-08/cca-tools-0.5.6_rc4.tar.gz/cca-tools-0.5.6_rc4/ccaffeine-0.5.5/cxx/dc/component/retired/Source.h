#ifndef __DC_COMPONENT_SOURCE__
#define __DC_COMPONENT_SOURCE__

/** Boundary condition. */
class Source {
public:
  double temperature;
  double duration;
};

#endif // __DC_COMPONENT_SOURCE__
