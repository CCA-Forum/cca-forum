#include "jc++/jc++.h"
#include "jc++/lang/Object.h"
#include "jc++/util/JCPN(StringEnumeration).h"
#include "jc++/util/JCPN(StringVector).h"
#include "parameters/parametersStar.h"
#include <cca.h>
//#include "util/IO.h"
#include "esi/ESI-cca.h"
#include "port/portInterfaces.h"
#include "dc/port/portStar.h"
#include "dc/component/DiagonalModel.h"
#include "esi/esi_Map_cca.h"
#include "esi/esi_JCPN(Vector)_cca.h"

DiagonalModel::DiagonalModel() { 

  nx = new IntParameter("nx",
    "The number of matrix rows",
    "matrix order",10,1,100000
  );

  pp = new DefaultParameterPort();
  pp->setBatchTitle("Diagonal configuration");
  pp->setGroupName("Matrix");
  pp->addRequest(nx);

  pfp = 0;
  myCore = 0;
}

DiagonalModel::~DiagonalModel() { 
  delete nx;
  delete pp;
  pfp = 0;
  nx = 0;
  pp = 0;
  myCore = 0;
}

void DiagonalModel::setServices(Services *cc) {
  myCore = cc;

  // Contact the PrintfService
  PortInfo* pinfo = cc->createPortInfo("pSvc", "gov.cca.PrintfService", 0);
  cc->registerUsesPort(pinfo);
  pfp = dynamic_cast<PrintfPort*>(cc->getPort("pSvc"));
  CHECKDC(pfp);
  if(pfp == 0) {
    cc->addProvidesPort(this, cc->createPortInfo("DEAD=NoPrintf", "GoPort", 0));
    printf("!!! No PrintfService available from framework.");
    return;
  }

  myCore->registerUsesPort(myCore->createPortInfo("LINALG", "ESI_EquationSolver", 0));
  myCore->addProvidesPort(this, 
      myCore->createPortInfo("GO", "GoDirectPort", 0));
  myCore->addProvidesPort(pp,
      myCore->createPortInfo("CONFIG","ParameterPort", 0));
}

void DiagonalModel::go(){

  struct MPI_wrapper *mw=0;
  esi_JCPN(Vector)_cca *x=0, *b=0, *r=0;
  RowEquationSolver *slv=0;

  slv = dynamic_cast <RowEquationSolver*> (myCore->getPort("LINALG"));
  if (slv == 0) {
    pfp->en("DiagonalModel::go(): uses port slv not set!");
    return;
  }

  mw = new struct MPI_wrapper;

#ifdef MPI_wrapper_HAS_COMM
  mw->comm = MPI_COMM_WORLD;
#endif //MPI_wrapper_HAS_COMM

  esi_Map_cca *xmap = new esi_Map_cca(mw);

  int  localSize, localOffset, rank;
#ifndef MPI_wrapper_HAS_COMM

  xmap->setGlobalSize(nx->value);
  xmap->setLocalInfo(nx->value, 0);
  localSize = nx->value;
  localOffset = 0;
  rank = 0;

#else

  int size, avg, rem;
  MPI_Comm_rank(mw->comm,&rank);
  MPI_Comm_size(mw->comm,&size);
  if (nx->value < rank) {
    pfp->en("Matrix needs at least as many equations as processors");
    delete xmap; xmap = 0;
    return;
  }
  avg = nx->value / size;
  rem = nx->value % size;
  if (rem == 0) {
    localSize = avg;
    localOffset = avg * rank;
  } else {
    localSize = avg;
    localOffset = localSize * rank;
    if (rank == (size - 1) ) {
      // last processor gets extra
      localSize = nx->value - localOffset;
    }
  }
#endif // MPI_wrapper_HAS_COMM

  xmap->setGlobalSize(nx->value);
  xmap->setLocalInfo(localSize, localOffset);
  x = new esi_JCPN(Vector)_cca(xmap);
  b = new esi_JCPN(Vector)_cca(xmap);
  r = new esi_JCPN(Vector)_cca(xmap);

  if (slv->setJCPN(Vector)s(x,b,r)) {
    pfp->en("setJCPN(Vector)s returned an error");
    assert(0);
  };
  
  b->put(1); // solution is reciprocals 
  x->put(0.0); 
  r->put(-1.0); 
  int row; double oned; 
  for (int i = 0; i < localSize; i++) {
    row = i+1+localOffset;
    oned=1.0*row;
    if ( slv->setEquation(row,1,&row,&oned) ) { // col == row
      pfp->en("setEquation returned an error");
      assert(0);
    }
  }
  slv->equationsDone(); // tell system the equations are done.

  slv->solve();

  int status = slv->getJCPN(Vector)s();
  pfp->en("RowEquationSolver returned %d",status);
  pfp->en("RHS=");
  b->saveState(0,&rank);
  pfp->en("X=");
  x->saveState(0,&rank);
  pfp->en("ERRS=");
  r->saveState(0,&rank);
  myCore->releasePort("LINALG");

  delete x; x = 0;
  delete b; b = 0;
  delete r; r = 0;
  delete xmap; xmap = 0;

}
