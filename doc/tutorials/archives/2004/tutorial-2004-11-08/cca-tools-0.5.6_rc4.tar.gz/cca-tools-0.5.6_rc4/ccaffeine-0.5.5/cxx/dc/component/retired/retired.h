#ifndef componentStar_h_seen
#define componentStar_h_seen

#include "StarterComponent.h"
#include "TimeStamper.h"
#include "Timer.h"
#include "PrinterComponent.h"

//#include "Integrator2.h"
#ifdef STV_ROOT
#include "Eyes2.h"
#include "Eyes.h"
#endif
//#include "LinearSystemIsis.h"
//#include "DiagonalModel.h"

#ifdef ESICCA_h_seen
// requires esi
#include "Plate1.h"
#include "Plate2.h"
#endif // ESICCA_h_seen

#include "Source.h"
#include "Shape.h"
#ifdef _ISIS
#include "Integrator2.h"
#include "DataHolder.h"
#endif // _ISIS
#include "Diffusion.h"
#include "RevalidateTest.h"

#ifdef _ISIS
#include "Diffusion2.h"
#endif //_ISIS


#endif // componentStar_h_seen
