#ifndef Integrator2_h_seen
#define Integrator2_h_seen

/** That does a custom integration. */
class Integrator2 : public virtual classic::gov::cca::Component, public virtual classic::gov::cca::GoPort, public virtual ClockPort {

private:

  classic::gov::cca::Services *core;
  classic::gov::cca::PrintfPort *pfp;

  ConfigurableParameterPort *pp;
  /** Euler time step */
  DoubleParameter *step;
  /** integration time limit */
  DoubleParameter *horizon;
  /** number of 'noises' over the time span */
  IntParameter *nJumps;
  /** number of adjacent states to tweak in a jump */
  IntParameter *nJumpVars;
  /** fractional size of change in a jumped var */
  DoubleParameter *jumpMagnitude;

  /** current time point in simulation */
  double time;
  /** next noise point in simulation */
  double next_time;

  void setupParameters(ConfigurableParameterFactory *);

public:

  Integrator2();
  ~Integrator2();

  virtual void setServices(classic::gov::cca::Services *cc);

  /** Implements ClockPort */
  virtual double getClock();

  /**Run the integrator according to the parameter values
     obtained. Implements GoPort */
  virtual int go();
};
#endif //Integrator2_h_seen
