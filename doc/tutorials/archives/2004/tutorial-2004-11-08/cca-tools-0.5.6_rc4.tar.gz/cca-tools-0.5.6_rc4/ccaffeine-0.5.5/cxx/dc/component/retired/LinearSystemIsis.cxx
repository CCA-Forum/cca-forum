#ifdef _CCAISIS
//package ccax.demo.directConnect.component;

//import java.util.Random;
//import cca.*;
//import esi.*;
//import parameters.*;
//import ccax.demo.directConnect.port.*;
//import ccax.demo.directConnect.user_iface.*;

#include <unistd.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#ifndef _CCAMPI
#include <isis-ser.h>
#else
#include <isis-mpi.h>
#endif
#include "jc++/jc++.h"
#include "esi/ESI-cca.h"
#include "esi/esi_Map_cca.h"
#include "esi/esi_JCPN(Vector)_cca.h"
#include <cca.h>
#include "parameters/parametersStar.h"
#include "port/portInterfaces.h"
#include "dc/port/portStar.h"
#include "dc/port/DefaultParameterPort.h"

#include "dc/component/LinearSystemIsis.h"

#include "util/freefree.h" //make free go away

#ifdef USING_MPIUNI
static char id[]=
"$Id: LinearSystemIsis.cxx,v 1.1 2003/05/02 00:20:38 baallan Exp $ Using FAKE MPI for ISIS";
#else
static char id[]=
"$Id: LinearSystemIsis.cxx,v 1.1 2003/05/02 00:20:38 baallan Exp $ Using MPI with ISIS";
#endif // USING_MPIUNI

#define MaxStringLength 256

LinearSystemIsis::LinearSystemIsis() {

  pcside = new StringParameter("pcside",
    "Side of A preconditioner is applied on",
    "preconditioner side","left"
  );
  pcside->addChoice("left");
  pcside->addChoice("right");
  pcside->addChoice("two-sided");

  rowScale = new BoolParameter("rowScale",
    "Row scaling of matrix data by largest row element value",
    "scale matrix rows",
    0
  );

  colScale = new BoolParameter("colScale",
    "Column scaling of matrix data by largest column element value",
    "scale matrix columns",
    0
  );

  pcname = new StringParameter("pcname",
    "Explanations of preconditioners are in ISIS++ Reference Guide."
    " See http//z.ca.sandia.gov/isis",
    "Preconditioner",
    "identity"
  );
  pcname->addChoice("identity");
  pcname->addChoice("diagonal");
  pcname->addChoice("polynomial");
  pcname->addChoice("polyspai");
  pcname->addChoice("polybj");
  pcname->addChoice("spai");
  pcname->addChoice("bj");
  pcname->addChoice("cgne_bj");
  pcname->addChoice("cgne_diag");
  pcname->addChoice("cgne_poly");
  pcname->addChoice("cgnr_poly");

  solvername = new StringParameter("solvername",
    "Explanations of solvers are in ISIS++ Reference Guide."
    " See http//z.ca.sandia.gov/isis",
    "Solver",
    "qmr"
  );
  solvername->addChoice("qmr");
  solvername->addChoice("qmr2");
  solvername->addChoice("gmres");
  solvername->addChoice("fgmres");
  solvername->addChoice("cg");
  solvername->addChoice("defgmres");
  solvername->addChoice("bicgstab");
  solvername->addChoice("cgs");
  solvername->addChoice("cgne");
  solvername->addChoice("cgnr");

  // general parameters
  gpp = new DefaultParameterPort();
  // gpp->setUpdater(this);
  gpp->setBatchTitle("ISIS++ Configuration");
  gpp->setGroupName("Options");
  gpp->addRequest(solvername);
  gpp->addRequest(pcside);
  gpp->addRequest(pcname);
  gpp->addRequest(rowScale);
  gpp->addRequest(colScale);

  // solver parameters
  spp = new DefaultParameterPort();
  // spp->setUpdater(this);
  solveTol = new DoubleParameter("solveTol",
    "max absolute residual allowed",
    "tolerance",
    1e-4,5e-40, 1000
  );
  solveItLim = new IntParameter("solveItLim",
    "max number of iterations",
    "iteration limit",
    1000, 2, 100000
  );
  solveRestart = new IntParameter("solveRestart",
    "number of gmres iterations before restart",
    "restart (gmres)",
    50, 2, 100000
  );
  spp->setBatchTitle("Solver Configuration");
  spp->setGroupName("Options");
  spp->addRequest(solveTol);
  spp->addRequest(solveItLim);
  spp->addRequest(solveRestart);

  

  // preconditioner parameters
  pcpp = new DefaultParameterPort();
  pcpp->setUpdater(this);
  // pcpp is not configured until the getConfiguration call, but
  // we do make all its potential items here.
  blockSize = new IntParameter("blockSize",
    "The size of blocks in block Jacobi algorithms",
    "Jacobi block size",
    32,2,10000
  );
  blockType = new StringParameter("blockType",
    "Controls blocking strategy and has implications on memory management",
    "blocking strategy",
    "overlapping"
  );
  blockType->addChoice("overlapping");
  blockType->addChoice("non-overlapping");
  polyOrder = new IntParameter("polyOrder",
    "The order of the preconditioning polynomials",
    "polynomial order",
    2,1,10
  );
  polyType = new StringParameter("polyType",
    "see Alan Williams (william at ca.sandia.gov) for further explanation ",
    "polynomial type",
    "least squares"
  );
  polyType->addChoice("least squares");
  polyType->addChoice("Neumann");
  spaiEpsilon = new DoubleParameter("spaiEpsilon",
    "tolerance when computing approximate inverse",
    "epsilon",
    0.4,5e-100,100000
  );
  spaiNBSteps = new IntParameter("spaiNBSteps",
    "max number of \"improvement\" steps per column",
    "nbsteps",
    20, 1, 1000
  );
  spaiMaxapi = new IntParameter("spaiMaxapi",
    "upper limit on nonzeros in row or column of M",
    "maxapi",
    100,2,1000
  );
  spaiMax = new IntParameter("spaiMax",
    "max dimensions of ja2, q, etc.",
    "max",
    2000,10,100000
  );
  spaiMaxNew = new IntParameter("spaiMaxNew",
    "max number of new entries per step",
    "maxnew",
    5, 1, 1000
  );
  spaiVerbose = new BoolParameter("spaiVerbose",
    "status report output",
    "info",
    0
  );
  spaiCacheSize = new IntParameter("spaiCacheSize",
    "see Alan Williams",
    "cache size",
    3, 1, 5
  );

  mw=0;
  my_rank=-1;
  num_procs=0;
  master_rank=-1;
  n=-1; 
  startRow= endRow= numParams=-1;
  paramStrings=0;
  pPC1=0;
  pPC2=0;
  commInfo=0;
  A=0;
  ix= ib=ir=0;
  map=0;
  lsize=-1; // localSize of vectors, number of local rows.

  solveStarted=0;
  solveStatus=-5;
  pprecond=0;
  psolver=0;
  lse=0;

  ux= urhs= uresid=0;


  mw = new struct MPI_wrapper;
  // note debugger may show the serial definition of
  // mw (pid,hostname), but it is wrong except in the serial build.

#ifdef MPI_wrapper_HAS_COMM
  char tmp[60];
  int err = 0;
  err += MPI_Comm_dup(MPI_COMM_WORLD,&(mw->comm));
  err += MPI_Comm_rank(mw->comm,&my_rank);
  err += MPI_Comm_size(mw->comm,&num_procs);
  sprintf(tmp,"LSI: mpi->rank %d, size%d",my_rank,num_procs);
  pfp->en(tmp);
  assert(err==0);
#else
  my_rank = 0;
  num_procs = 1;
#endif // MPI_wrapper_HAS_COMM
  master_rank = 0;
  numParams = 19; // should match parports total.
  paramStrings = (char **)malloc(sizeof(char *)*(numParams+1));
  for (int i = 0; i < numParams; i++) {
    paramStrings[i] = (char *)malloc(sizeof(char)*MaxStringLength);
  }
  paramStrings[numParams] = 0;
  pPC1 = pPC2 = 0;

  solveStarted = 0;
  lse = 0;

  startRow = endRow = lsize = -1;

}

/// rebuild argv being passed to isis objects for configuration.
void LinearSystemIsis::updateParamStrings() {
  assert(solvername != 0);
  assert(pcname != 0);
  assert(pcside != 0);
  assert(rowScale != 0);
  assert(colScale != 0);
  assert(solveTol != 0);
  assert(solveItLim != 0);
  assert(solveRestart != 0);
  assert(blockSize != 0);
  assert(blockType != 0);
  assert(polyOrder != 0);
  assert(polyType != 0);
  assert(spaiEpsilon != 0);
  assert(spaiNBSteps != 0);
  assert(spaiMaxapi != 0);
  assert(spaiMax != 0);
  assert(spaiMaxNew != 0);
  assert(spaiVerbose != 0);
  assert(spaiCacheSize != 0);

  sprintf(paramStrings[ 0], "solver %s", solvername->value);
  sprintf(paramStrings[ 1], "pc %s", pcname ->value);
  sprintf(paramStrings[ 2], "side %s", pcside->value);
  sprintf(paramStrings[ 3], "rowScale %s", rowScale->value?"true":"false");
  sprintf(paramStrings[ 4], "colScale %s", colScale->value?"true":"false");
  sprintf(paramStrings[ 5], "tolerance %g", solveTol->value);
  sprintf(paramStrings[ 6], "maxIterations %d", solveItLim->value);
  sprintf(paramStrings[ 7], "restart %d", solveRestart->value);
  sprintf(paramStrings[ 8], "blockSize %d", blockSize->value);
  sprintf(paramStrings[ 9], "blockType %d", blockType->value[0]=='o'?1:2);
  sprintf(paramStrings[10], "polyOrder %d", polyOrder->value);
  sprintf(paramStrings[11], "polyType %d", polyType->value[0]=='N'?1:2);
  sprintf(paramStrings[12], "spai_epsilon %g", spaiEpsilon->value);
  sprintf(paramStrings[13], "spai_nbsteps %d", spaiNBSteps->value);
  sprintf(paramStrings[14], "spai_maxapi %d", spaiMaxapi->value);
  sprintf(paramStrings[15], "spai_max %d", spaiMax->value);
  sprintf(paramStrings[16], "spai_maxnew %d", spaiMaxNew->value);
  sprintf(paramStrings[17], "spai_info %d",  spaiVerbose->value);
  sprintf(paramStrings[18], "spai_cache_size %d", spaiCacheSize->value);
}

LinearSystemIsis::~LinearSystemIsis(){

  if (lse != 0) {
    delete lse; lse = 0;
  }
  if (psolver != 0) {
    delete psolver; psolver = 0;
  }
  if (pprecond != 0) {
    delete pprecond; pprecond = 0;
  }
  if (pPC1 != 0) {
    delete pPC1;
  }
  if (pPC2 != 0) {
    delete pPC2;
  }
  if ( ix != 0) {
    delete ix; ix = 0;
  }
  if ( ib != 0) {
    delete ib; ib = 0;
  }
  if ( ir != 0) {
    delete ir; ir = 0;
  }
  if ( A != 0) {
    delete A; A = 0;
  }
  if ( map != 0) {
    delete map; map = 0;
  }
  if ( commInfo != 0) {
    delete commInfo; commInfo = 0;
  }

#ifdef MPI_wrapper_HAS_COMM
  assert(mw->comm != MPI_COMM_NULL);
  MPI_Comm_free(&(mw->comm));
#endif // MPI_wrapper_HAS_COMM

  delete mw; mw = 0;
  
  for (int i = 0; i < numParams; i++) {
    free(paramStrings[i]);
    paramStrings[i] = 0;
  }
  free(paramStrings);
  paramStrings = 0;

  delete solvername;
  delete pcname;
  delete rowScale;
  delete colScale;
  delete pcside;
  delete solveTol;
  delete solveItLim ;
  delete solveRestart ;
  delete blockSize ;
  delete blockType ;
  delete polyOrder ;
  delete polyType ;
  delete spaiEpsilon ;
  delete spaiNBSteps ;
  delete spaiMaxapi ;
  delete spaiMax ;
  delete spaiMaxNew;
  delete spaiVerbose ;
  delete spaiCacheSize ;

  solvername =0;
  pcname =0;
  rowScale =0;
  colScale =0;
  pcside =0;
  solveTol =0;
  solveItLim  =0;
  solveRestart  =0;
  blockSize  =0;
  blockType  =0;
  polyOrder  =0;
  polyType  =0;
  spaiEpsilon  =0;
  spaiNBSteps  =0;
  spaiMaxapi  =0;
  spaiMax  =0;
  spaiMaxNew =0;
  spaiVerbose  =0;
  spaiCacheSize  =0;

  delete gpp; gpp = null;
  delete spp; spp = null;
  delete pcpp; pcpp = null;
}


void LinearSystemIsis::setServices(Services *cc){
  assert(cc != 0);
  core = cc;

  assert(gpp !=0);
  assert(spp !=0);
  assert(pcpp !=0);
  try {

    core->addProvidesPort(gpp, 
      core->createPortInfo("CONFIG", "ParameterPort", 0));
    core->addProvidesPort(spp, 
      core->createPortInfo("SOLVER", "ParameterPort", 0));
    core->addProvidesPort(pcpp, 
      core->createPortInfo("PC", "ParameterPort", 0));

    core->addProvidesPort(this,
      core->createPortInfo("ESI", "ESI_EquationSolver", 0 ));

  } catch (ExceptionJC *e) {

    pfp->e("LinearSystemIsis set failure:");
    pfp->en(e->why());

  }

}

boolean LinearSystemIsis::updateParameterPort(DefaultParameterPort *dpp) {
  if (dpp == 0) { return  0; }
  if (dpp == gpp) { return 0; }
  if (dpp == spp) { return 0; }
  if (dpp == pcpp) {
    pcpp->clearRequests();
    char *pc;
    pc = pcname->value;
    pcpp->setBatchTitle(pcname->value);
    if ( strcmp(pc,"identity") == 0 || 
         strcmp(pc,"diagonal") == 0 ) {
      pcpp->setGroupName("No tunable parameters");
      return 0; // no values need updating.
    }
    if ( strncmp(pc,"poly",4) == 0 ||
         strcmp(pc,"cgne_poly") == 0 || 
         strcmp(pc,"cgne_poly") == 0 ) {
      pcpp->setGroupName("Polynomial");
      pcpp->addRequest(polyType);
      pcpp->addRequest(polyOrder);
    }
    if ( strcmp(pc,"spai") == 0 || 
         strcmp(pc,"polyspai") == 0 ) {
      pcpp->setGroupName("SPAI");
      pcpp->addRequest(spaiEpsilon);
      pcpp->addRequest(spaiNBSteps);
      pcpp->addRequest(spaiMaxapi);
      pcpp->addRequest(spaiMax);
      pcpp->addRequest(spaiMaxNew);
      pcpp->addRequest(spaiCacheSize);
      pcpp->addRequest(spaiVerbose);
    }
    if ( strcmp(pc,"bj") == 0 || 
         strcmp(pc,"polybj") == 0 || 
         strcmp(pc,"cgne_bj") == 0) {
      pcpp->setGroupName("Block Jacobi");
      pcpp->addRequest(blockType);
      pcpp->addRequest(blockSize);
    }
    return 1;
  }
  return 0;
}

void LinearSystemIsis::solve() {


  if (solveStarted == 0) {
    // setup everything the first time.

    solveStarted = 1;
    assert(A != 0);
    assert(ix != 0);
    assert(ib != 0);

    assert(ux!=0);
    assert(urhs!=0);
    eJCPN(Vector)2iJCPN(Vector)(ux,ix); // just in case there's an init
    eJCPN(Vector)2iJCPN(Vector)(urhs,ib);

    //ix->writeToFile("/tmp/ix-before");
    //ib->writeToFile("/tmp/ib-before");
    lse = new LinearEquations(*A,*ix,*ib);
    assert(lse != 0);


    if (!strcmp(solvername->value, "qmr")) {
        psolver = new QMR_SolverIsis();
        pfp->en("QMR solver selected.");
    }
    else if (!strcmp(solvername->value, "qmr2")) {
        psolver = new QMR2_SolverIsis();
        pfp->en("QMR2 solver selected.");
    }
    else if (!strcmp(solvername->value, "gmres")) {
        psolver = new GMRES_SolverIsis();
        pfp->en("GMRES solver selected.");
    }
    else if (!strcmp(solvername->value, "fgmres")) {
        psolver = new FGMRES_SolverIsis();
        pfp->en("FGMRES solver selected.");
    }
    else if (!strcmp(solvername->value, "cg")) {
        psolver = new CG_SolverIsis();
        pfp->en("CG solver selected.");
    }
    else if (!strcmp(solvername->value, "defgmres")) {
        psolver = new DefGMRES_SolverIsis();
        pfp->en("DefGMRES solver selected.");
    }
    else if (!strcmp(solvername->value, "bicgstab")) {
        psolver = new BiCGStab_SolverIsis();
        pfp->en("BiCGStab solver selected.");
    }
    else if (!strcmp(solvername->value, "cgs")) {
        psolver = new CGS_SolverIsis();
        pfp->en("CGS solver selected.");
    }
    else if (!strcmp(solvername->value, "cgne")) {
        psolver = new CGNE_SolverIsis();
        pfp->en("CGNE solver selected.");
    } 
    else if (!strcmp(solvername->value, "cgnr")) {
        psolver = new CGNR_SolverIsis();
        pfp->en("CGNR solver selected.");
    } 
    else {
        psolver = new QMR_SolverIsis();
        pfp->en("Defaulting to QMR solver.");
    }

    if (!strcmp(pcname->value, "identity")) {
        pprecond = new Identity_PC(*A);
        pfp->en("Identity pc selected.");
    }
    else if (!strcmp(pcname->value, "diagonal")) {
        pprecond = new Diagonal_PC(*A, *ix);
        pfp->en("Diagonal pc selected.");
    }
    else if (!strcmp(pcname->value, "polynomial")) {
        pprecond = new Poly_PC(*A, *ix);
        pfp->en("Polynomial pc selected.");
    }
    else if (!strcmp(pcname->value, "polyspai")) {
        pPC1 = new SPAI_PC(*A);

        // Construct composed polynomial pc.
        pPC2 = new Poly_PC(*A, *ix, *pPC1);

        pprecond = new Composed_PC(*A,*ix,*pPC1,*pPC2);
        pfp->en("Composed PC, Poly and SPAI.");
    } 
    else if (!strcmp(pcname->value, "polybj")) {
        pPC1 = new BlockJacobi_PC(*A);

        // Construct composed polynomial pc.
        pPC2 = new Poly_PC(*A, *ix, *pPC1);

        pprecond = new Composed_PC(*A,*ix,*pPC1,*pPC2);
        pfp->en("Composed pc selected, Polynomial and BJ.");
    }
    else if (!strcmp(pcname->value, "spai")) {
        pprecond = new SPAI_PC(*A);
        pfp->en("SPAI pc selected.");
    }
    else if (!strcmp(pcname->value, "bj")) {
        pprecond = new BlockJacobi_PC(*A);
        pfp->en("BlockJacobi pc selected.");
    }
    else if (!strcmp(pcname->value, "cgne_bj")) {
        pprecond = new CGNE_BlockJacobi_PC(*A);
        pfp->en("CGNE Block Jacobi pc selected.");
    }
    else if (!strcmp(pcname->value, "cgne_diag")) {
        pprecond = new CGNE_Diagonal_PC(*A, *ix);
        pfp->en("CGNE Diagonal pc selected.");
    }
    else if (!strcmp(pcname->value, "cgne_poly")) {
        pprecond = new CGNE_Poly_PC(*A, *ix);
        pfp->en("CGNE Polynomial pc selected.");
    }
    else if (!strcmp(pcname->value, "cgnr_poly")) {
        pprecond = new CGNR_Poly_PC(*A, *ix);
        pfp->en("CGNR Polynomial pc selected.");
    }
    else {
        pprecond = new Identity_PC(*A);
        pfp->en("Defaulting to Identity pc.");
    }

    assert(psolver != 0);
    assert(pprecond != 0);

    if (colScale->value) {
      if (!lse->colScale()) {
        pfp->en("Warning - column scaling failed.");
      } else {
        pfp->en("...column scaling completed.");
      }
    } else {
      pfp->en("...column turned off.");
    }
    if (rowScale->value) {
      if (!lse->rowScale()) {
        pfp->en("Warning - row scaling failed.");
      } else {
        pfp->en("...row scaling completed.");
      }
    } else {
      pfp->en("Row scaling turned off.");
    }
    if (!strcmp(solvername->value, "fgmres")) {
      pprecond->setRight();
    }
    lse->setSolverIsis(*psolver);
    lse->setPreconditionerIsis(*pprecond);
    pfp->en("*****************************");

    psolver->outputLevel(1,my_rank,master_rank);
    updateParamStrings();
    psolver->parameters(numParams, paramStrings);
    pprecond->parameters(numParams, paramStrings);

    pfp->en("Computing the preconditioner...");
    pprecond->calculate();
    MPI_Barrier(MPI_COMM_WORLD);
    pfp->en("Starting solve... ");
  }
  if (solveStatus != 0) {
    return;
  }

  solveStatus = lse->solve();
  //ix->writeToFile("/tmp/ix-after");
  //ib->writeToFile("/tmp/ib-after");
  if (solveStatus == 1) {
    pfp->en("...solve complete.");
  }
  if (solveStatus == -1) {
    pfp->en("...solve stalled.");
  }

} 

int LinearSystemIsis::setJCPN(Vector)s(ESI_JCPN(Vector) *x, ESI_JCPN(Vector) *rightside, ESI_JCPN(Vector) *residual) {

  // need to do some sanity checks here to require 0 between new values.
  if ((x !=0 || rightside != 0 || residual != 0) &&
      (ux != 0 || urhs != 0 || uresid != 0)) {
    return 1; // setJCPN(Vector)s called while already configured.
  }

  ux = x;
  urhs = rightside;
  uresid = residual;
  solveStatus = solveStarted = 0;

  if ( ix != 0) {
    delete ix; ix = 0;
  }
  if ( ib != 0) {
    delete ib; ib = 0;
  }
  if ( ir != 0) {
    delete ir; ir = 0;
  }
  if ( A != 0) {
    delete A; A = 0;
  }
  if ( map != 0) {
    delete map; map = 0;
  }
  if ( commInfo != 0) {
    delete commInfo; commInfo = 0;
  }

  if (ux != 0) {
    pfp->en("LSI building A,x,b");
    // reconfigure A, x, b isis structures
    // compute buffersize for int *rowLengths.
  
    n = x->getGlobalSize();
    startRow = x->getLocalOffset();
    lsize = x->getLocalSize();
    endRow = startRow + lsize - 1;

#ifdef MPI_wrapper_HAS_COMM
    commInfo = new CommInfo(master_rank, mw->comm);
#else
    commInfo = new CommInfo(master_rank, MPI_COMM_WORLD); // fake comm
#endif //MPI_wrapper_HAS_COMM
    map = new MapIsis(n, startRow+1, endRow+1, *commInfo);
    assert(map != 0);
    A = new RsDCRS_MatrixIsis(*map);
    ix = new Dist_JCPN(Vector)Isis(*map);
    ib = new Dist_JCPN(Vector)Isis(*map);
    ir = new Dist_JCPN(Vector)Isis(*map);
    assert(A !=0);
    assert(ix !=0);
    assert(ib !=0);
    assert(ir !=0);

  } else {
    pfp->en("LSI NOT building A,x,b");
  }

  
  return 0;
}

int LinearSystemIsis::setEquation(int row, int rowLen, 
                                  int *colIndices, double *coef) {
  if (A != 0) {
    pfp->en("Equation %d, len %d, 1st element col %d = %g",
           row,rowLen,*colIndices, *coef);
    A->setRowLength(rowLen,row);
    A->putRow(row,rowLen, coef, colIndices);
    return 0;
  }

  return 1;
}

void LinearSystemIsis::equationsDone() {
  assert(A != 0);
  A->fillComplete();
}

int LinearSystemIsis::getJCPN(Vector)s() {
  // map isis vectors back to esiland
  // return solver status
  if (solveStarted == 0) {
    return -2;
  }

  iJCPN(Vector)2eJCPN(Vector)(ix,ux);
  iJCPN(Vector)2eJCPN(Vector)(ib,urhs);

  A->vectorMultiply(*ir, *ix);
  ir->linComb(*ib, -1.0, *ir);
  iJCPN(Vector)2eJCPN(Vector)(ir,uresid);

  return solveStatus;
}

// not exportable, as assumes vectors have our layout
void LinearSystemIsis::eJCPN(Vector)2iJCPN(Vector)(ESI_JCPN(Vector) *ev, Dist_JCPN(Vector)Isis *iv) {
  assert(iv != 0 && ev != 0);
  double *edata;
  ev->accessArrayRead(&edata);
  for (int i = 0 ; i < lsize ; i++) {
   (*iv)[i+1+startRow] = edata[i];
  }
  ev->restoreArray(&edata);
}

void LinearSystemIsis::iJCPN(Vector)2eJCPN(Vector)(Dist_JCPN(Vector)Isis *iv, ESI_JCPN(Vector) *ev) {
  assert(iv != 0 && ev != 0);
  double *edata;
  ev->accessArrayRead(&edata);
  for (int i = 0 ; i < lsize ; i++) {
   edata[i] = (*iv)[i+1+startRow];
  }
  ev->restoreArray(&edata);
}

#endif //_CCAISIS
