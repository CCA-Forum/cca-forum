#ifndef _F90CCAPORT_H_
#define _F90CCAPORT_H_

#include <cca.h>
#include <map>

namespace CCA {

  typedef struct CCAPORT_ {
    classic::gov::cca::Port* instance;
  } CCAPORT;

}

extern std::map<void*, classic::gov::cca::Services*> servicesMap;

extern "C" {

void GETPORT(CCA::CCAPORT* requesting_port,
             CCA::CCAPORT* port, const char* name, int length);

void RELEASEPORT(CCA::CCAPORT* requesting_port, const char* name, int length);

}

#endif // _F90CCAPORT_H_
