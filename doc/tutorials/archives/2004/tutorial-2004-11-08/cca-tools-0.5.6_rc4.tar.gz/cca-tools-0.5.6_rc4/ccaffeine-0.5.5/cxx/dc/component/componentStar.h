#ifndef componentStar_h_seen
#define componentStar_h_seen

#include "StarterComponent.h"
#include "TimeStamper.h"
#include "Timer.h"
#include "PrinterComponent.h"
#include "RevalidateTest.h"

#endif // componentStar_h_seen
