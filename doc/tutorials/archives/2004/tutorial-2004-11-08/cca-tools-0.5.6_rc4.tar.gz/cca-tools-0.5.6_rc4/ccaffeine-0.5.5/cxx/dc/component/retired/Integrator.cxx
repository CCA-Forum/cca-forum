//package ccax.demo.directConnect.component;

//import java.util.Random;
//import cca.*;
//import esi.*;
//import parameters.*;
//import ccax.demo.directConnect.port.*;
//import ccax.demo.directConnect.user_iface.*;

#include <unistd.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include "jc++/jc++.h"
#include "jc++/util/jc++util.h"
#include <cca.h>
#include "parameters/parametersStar.h"
#include "port/portInterfaces.h"
#include "dc/port/portStar.h"
#include "dc/port/DefaultParameterPort.h"

#include "dc/component/Integrator.h"
//#include "util/IO.h"

#include "util/freefree.h" //make free go away

static char id[]=
"$Id: Integrator.cxx,v 1.1 2003/05/02 00:20:38 baallan Exp $";


Integrator::Integrator(){

  step = new DoubleParameter("step",
    "The time step is used for explicit euler integration",
    "time step",0.001,1e-20,1e+20
  );
  horizon = new DoubleParameter("horizon",
    "The length of the integration",
    "time horizon",1.0,1e-20,1e+20
  );
  nJumps = new IntParameter("nJumps",
    "The number of noise events in the simulation",
    "number of noises",0,0,100000
  );
  jumpMagnitude = new DoubleParameter("jumpMagnitude",
    "fractional size of noise in a perturbed state variable",
    "noise volume",2.0,1e-5,1000.0
  );
  nJumpVars = new IntParameter("nJumpVars",
    "The number of simulation state variables in each noise event",
    "number of adjacent nodes perturbed",1,1,100000
  );

  pp = new DefaultParameterPort();
  pp->setBatchTitle("Simulation Configuration");
  pp->setGroupName("Integration parameters");
  pp->addRequest(step);
  pp->addRequest(horizon);
  pp->setGroupName("Noise Generation parameters");
  pp->addRequest(nJumps);
  pp->addRequest(jumpMagnitude);
  pp->addRequest(nJumpVars);
}

Integrator::~Integrator(){

  delete step; step = null;
  delete horizon; horizon = null;
  delete nJumps; nJumps = null;
  delete nJumpVars; nJumpVars = null;
  delete jumpMagnitude; jumpMagnitude = null;
  delete pp; pp = null;
}


void Integrator::setServices(Services *cc){
  core = cc;

  try {

    core->addProvidesPort(this, core->createPortInfo("GO", "GoDirectPort", 0 ));
    /// We supply a sink for framework "go" events

    core->addProvidesPort(pp,
        core->createPortInfo("CONFIG","ParameterPort", 0));
    /// We supply a parameter page pair which can look awful sexy if the
    /// GUI so chooses.

    core->registerUsesPort(core->createPortInfo("STATE", "JCPN(Vector)Port", 0));
    /// We get the initial value of states for ode during our init.
    /// We get the states vector for ode at first iteration.
    /// We call to announce a new value of states for ode at each iteration

    core->registerUsesPort(core->createPortInfo("DERIV", "JCPN(Vector)Port", 0));
    /// We get the derivative vector from the plate during our init.
    /// We request a computation of the derivatives for the ode at 
    /// each iteration

    core->addProvidesPort(this,core->createPortInfo("CLOCK", "ClockPort", 0));
    /// We set the clock on the physics if it wants it.

  } catch (ExceptionJC *e) {

    pfp->e("Integrator set failure:");
    pfp->en(e->why());

  }

}

double Integrator::getClock() {
  return time;
}

void Integrator::go() {
  double *ydata; 
  double *ypdata;

  double jumpstep;

  if (!pp->isFullyConfigured()) {
    pfp->en("Integrator parameters must be configured!");
  }
  pfp->en("Integrator appears to be configured.");

  // random number nasty hacks
  // Random random = new Random(23423523);
#define random_nextInt() ((int)(random()&INT_MAX))
  srandom(23423523); // We want random to be the same on
                     // all processors, which is unlikely
                     // if other components use random.
                     // We don't have to communicate the
                     // change zone if we do this successfully.

  JCPN(Vector)Port *state;
  JCPN(Vector)Port *derivative;
  ESI_JCPN(Vector) *y, *yprime;
  Port *pgot1. *pgot2;

  pgot1 = core->getPort("STATE");
  pgot2 = core->getPort("DERIV");
  if (pgot1 == 0 || pgot2 == 0) {
    pfp->en("Integrator not fully wired");
    return;
  }
  state=	dynamic_cast<JCPN(Vector)Port*>(pgot1);
  derivative=	dynamic_cast<JCPN(Vector)Port*>(pgot2);
  if (state == 0 || derivative == 0) {
    pfp->en("Integrator wired incorrectly");
    return;
  }

  time = 0.0; // clock always starts at 0
  jumpstep = horizon->value/(1.0*nJumps->value);
  next_time = jumpstep;

  pfp->en("Integrator vector ports ok.");

  state->compute(); // get physics to compute consistent initial state

  pfp->en("Integrator initialized physics.");

  y = state->getJCPN(Vector)();
  yprime = derivative->getJCPN(Vector)();
  int size = y->getGlobalSize();
  int lsize = y->getLocalSize();
  int lo = y->getLocalOffset();
  int hi = lo + lsize;
  char checkpoint[200];
  double normi, norm2;

  pfp->en("Integrator looping:");

  try {

    // explicit euler no error control, fixed step length.
    while (time < horizon->value) {

#ifdef _DBG_ILOOP
      pfp->e("Integrator derivative->compute()...");
#endif //_DBG_ILOOP

      derivative->compute(); // get y' from physics

#ifdef _DBG_ILOOP
      pfp->en("Integrator derivative computed.");
#endif //_DBG_ILOOP

      y->axpy(*yprime,step->value); // y += y'dt
#ifdef _DBG_ILOOP
      pfp->en("Integrator state projected.");
#endif //_DBG_ILOOP

      // every jumpstep delta time, we rescale some states to
      // introduce noise.
      if (time > next_time) {

        (void)y->accessArrayReadWrite(&ydata); // lock vectors
        (void)yprime->accessArrayRead(&ypdata);
#ifdef _DBG_ILOOP
        pfp->en("Integrator data access starts");
#endif //_DBG_ILOOP

        int change, lastchange;
        change = random_nextInt() % size;
        lastchange = change + nJumpVars->value;

        for (int i = change; i < lastchange; i++) {
          // i is in the global index space
          if (i >= lo && i <= hi) {
#ifdef _DBG_ILOOP
            pfp->en("Integrator Applying noise at %d",i);
#endif //_DBG_ILOOP
            ydata[i-lo] *= jumpMagnitude->value;
          }
        }
#ifdef _DBG_ILOOP
        pfp->en("Integrator Applying noise done");
#endif //_DBG_ILOOP

        (void)y->restoreArray(&ydata);
        (void)yprime->restoreArray(&ypdata);
#ifdef _DBG_ILOOP
        pfp->en("Integrator data access done");
#endif //_DBG_ILOOP

        next_time += jumpstep;
      }

      state->update();
#ifdef _DBG_ILOOP
      pfp->en("Integrator calling physics state->update()");
#endif //_DBG_ILOOP
      time += step->value;

#ifdef _DBG_ILOOP
      pfp->en("Integrator calling y->norm2()");
#endif //_DBG_ILOOP

      yprime->norm2(norm2);
      y->normInfinity(normi);
      sprintf(checkpoint,"t= %g, |Q|_2 = %g Tmax = %g",time,norm2,normi);
      pfp->en(checkpoint);
      
    }

  } catch (ExceptionJC *e) {
    pfp->e("Integrator execution error:");
    pfp->en(e->why());
    return;
  }
}
