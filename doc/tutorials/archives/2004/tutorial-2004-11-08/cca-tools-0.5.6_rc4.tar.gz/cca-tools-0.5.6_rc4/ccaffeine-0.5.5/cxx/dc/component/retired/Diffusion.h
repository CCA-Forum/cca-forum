#ifndef __DIFFUSION_H__
#define __DIFFUSION_H__
/** A 2d diffusion differential equation solution by stencil. */
class Diffusion : public virtual classic::gov::cca::Component, public virtual classic::gov::cca::GoPort {
 private:
  
  classic::gov::cca::Services* svc;
  classic::gov::cca::PrintfPort *pfp;
  boolean isInitialized;
  boolean vizInitialized;
  CCA_Block* block;
  double* data;
  int debug;

  int beginCol;
  int endCol;
  int beginRow;
  int endRow;
  int offset;
  int colLen;
  int numRows;
  int numCols;

  DefaultParameterPort* pp;
  DoubleParameter* timeParam;
  DoubleParameter* tEndParam;
  DoubleParameter* tBeginParam;
  DoubleParameter* dtParam;
  DoubleParameter* dxParam;
  DoubleParameter* dyParam;
  BoolParameter* isRandom;
  DoubleParameter* randDuration;
  DoubleParameter* randMaxTemp;
  DoubleParameter* randMinTemp;
  DoubleParameter* randProbability;

  double t;
  double tEnd;
  double dt;
  double dx;
  double dy;
  double alpha;
  
  int numProcs;
  int myProc;
  int overlap;

  Source* lbcSrc;
  Source* rbcSrc;
  Source* tbcSrc;
  Source* bbcSrc;


  boolean computeRandBC(double* Uptr, Source** srcPtr, int i, int begin);
  void init();
  void initViz();
  CDELETE Source* randomSource();
 public:
  
  Diffusion();
  virtual ~Diffusion();
  /** Implements GoPort interface. */
  virtual int go();
  void setServices(classic::gov::cca::Services* svc);
  /** This means create the first state, i.e. initialize. */
  void stateCompute();
  void stateUpdate();

  void derivCompute();
  void derivUpdate();
  void printGrid();
};



#endif // __DIFFUSION_H__
