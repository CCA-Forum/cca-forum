// 
// File:          test_script_babel_BabelMain_Impl.hh
// Symbol:        test_script_babel.BabelMain-v0.0
// Symbol Type:   class
// Babel Version: 0.9.6
// Description:   Server-side implementation for test_script_babel.BabelMain
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.9.6
// 

#ifndef included_test_script_babel_BabelMain_Impl_hh
#define included_test_script_babel_BabelMain_Impl_hh

#ifndef included_sidl_cxx_hh
#include "sidl_cxx.hh"
#endif
#ifndef included_test_script_babel_BabelMain_IOR_h
#include "test_script_babel_BabelMain_IOR.h"
#endif
// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_AbstractFramework_hh
#include "gov_cca_AbstractFramework.hh"
#endif
#ifndef included_gov_cca_Component_hh
#include "gov_cca_Component.hh"
#endif
#ifndef included_gov_cca_ComponentID_hh
#include "gov_cca_ComponentID.hh"
#endif
#ifndef included_gov_cca_Services_hh
#include "gov_cca_Services.hh"
#endif
#ifndef included_gov_cca_ports_BuilderService_hh
#include "gov_cca_ports_BuilderService.hh"
#endif
#ifndef included_sidl_BaseInterface_hh
#include "sidl_BaseInterface.hh"
#endif
#ifndef included_sidl_ClassInfo_hh
#include "sidl_ClassInfo.hh"
#endif
#ifndef included_test_script_babel_BabelMain_hh
#include "test_script_babel_BabelMain.hh"
#endif
#ifndef included_test_script_babel_StringMap_hh
#include "test_script_babel_StringMap.hh"
#endif


// DO-NOT-DELETE splicer.begin(test_script_babel.BabelMain._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(test_script_babel.BabelMain._includes)

namespace test_script_babel { 

  /**
   * Symbol "test_script_babel.BabelMain" (version 0.0)
   */
  class BabelMain_impl
  // DO-NOT-DELETE splicer.begin(test_script_babel.BabelMain._inherits)
  // Put additional inheritance here...
  // DO-NOT-DELETE splicer.end(test_script_babel.BabelMain._inherits)
  {

  private:
    // Pointer back to IOR.
    // Use this to dispatch back through IOR vtable.
    BabelMain self;

    // DO-NOT-DELETE splicer.begin(test_script_babel.BabelMain._implementation)
    // Put additional implementation details here...
    // DO-NOT-DELETE splicer.end(test_script_babel.BabelMain._implementation)

  private:
    // private default constructor (required)
    BabelMain_impl() {} 

  public:
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    BabelMain_impl( struct test_script_babel_BabelMain__object * s ) : self(s,
      true) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~BabelMain_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

  public:

    /**
     * user defined non-static method.
     */
    void
    invokeGo (
      /*in*/ const ::std::string& component,
      /*in*/ const ::std::string& port,
      /*in*/ ::gov::cca::ComponentID c,
      /*in*/ ::gov::cca::Services services,
      /*in*/ ::gov::cca::ports::BuilderService bs
    )
    throw () 
    ;

    /**
     * user defined non-static method.
     */
    void
    setParameters (
      /*in*/ const ::std::string& component,
      /*in*/ const ::std::string& port,
      /*in*/ ::gov::cca::Component c,
      /*in*/ ::gov::cca::ports::BuilderService bs,
      /*in*/ ::gov::cca::Services services,
      /*in*/ ::test_script_babel::StringMap sm
    )
    throw () 
    ;

    /**
     * user defined non-static method.
     */
    void
    driverBody (
      /*inout*/ ::gov::cca::AbstractFramework& af
    )
    throw () 
    ;

  };  // end class BabelMain_impl

} // end namespace test_script_babel

// DO-NOT-DELETE splicer.begin(test_script_babel.BabelMain._misc)
// Put miscellaneous things here...
// DO-NOT-DELETE splicer.end(test_script_babel.BabelMain._misc)

#endif
