#ifndef Plate2_h_seen
#define Plate2_h_seen

class P2TPort;
class P2QPort;

class Plate2 : public virtual classic::gov::cca::Component {

private:

  classic::gov::cca::PrintfPort *pfp;
  classic::gov::cca::Services *core;
  P2TPort *temperature;
  P2QPort *tempGradient;

  DefaultParameterPort *pp;
  DoubleParameter *tmax;
  DoubleParameter *tedge;
  DoubleParameter *tinf;
  DoubleParameter *period;
  StringParameter *profile;
  DoubleParameter *k;
  IntParameter *nx;
  IntParameter *ny;

  ESI_Vector *T;
  ESI_Vector *Q;

public:

  Plate2();
  ~Plate2();

  void setServices(classic::gov::cca::Services *cc);

  void setT(ESI_Vector *newt) ;

  void setQ(ESI_Vector *newq) ;

  ESI_Vector *getT() ;

  ESI_Vector *getQ() ;

};
#endif //Plate2_h_seen
