// 
// File:          test_script_babel_BabelMain_Impl.cc
// Symbol:        test_script_babel.BabelMain-v0.0
// Symbol Type:   class
// Babel Version: 0.9.6
// Description:   Server-side implementation for test_script_babel.BabelMain
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.9.6
// 
#include "test_script_babel_BabelMain_Impl.hh"

// DO-NOT-DELETE splicer.begin(test_script_babel.BabelMain._includes)
// Put additional includes or other arbitrary code here...
#define WHINE(s) \
gov::cca::CCAException gex; \
 test_script_babel::Exception ex = test_script_babel::Exception::_create(); \
 ex.setNote(s); \
 gex = ex; \
 throw gex

#define WHINE2(t,s) \
gov::cca::CCAException gex; \
 test_script_babel::Exception ex = test_script_babel::Exception::_create(); \
 ex.setNote(s); \
 ex.setType(t); \
 gex = ex; \
 throw gex

#include "gov_cca.hh"
#include "gov_cca_ports.hh"
#include "test_script_babel.hh"
#include <iostream>

// DO-NOT-DELETE splicer.end(test_script_babel.BabelMain._includes)

// user defined constructor
void test_script_babel::BabelMain_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(test_script_babel.BabelMain._ctor)
  // add construction details here
  // DO-NOT-DELETE splicer.end(test_script_babel.BabelMain._ctor)
}

// user defined destructor
void test_script_babel::BabelMain_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(test_script_babel.BabelMain._dtor)
  // add destruction details here
  // DO-NOT-DELETE splicer.end(test_script_babel.BabelMain._dtor)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  invokeGo[]
 */
void
test_script_babel::BabelMain_impl::invokeGo (
  /*in*/ const ::std::string& component,
  /*in*/ const ::std::string& port,
  /*in*/ ::gov::cca::ComponentID c,
  /*in*/ ::gov::cca::Services services,
  /*in*/ ::gov::cca::ports::BuilderService bs ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(test_script_babel.BabelMain.invokeGo)
  std::cerr << "test_script_babel.BabelMain.invokeGo fixme" << std::endl;
  // DO-NOT-DELETE splicer.end(test_script_babel.BabelMain.invokeGo)
}

/**
 * Method:  setParameters[]
 */
void
test_script_babel::BabelMain_impl::setParameters (
  /*in*/ const ::std::string& component,
  /*in*/ const ::std::string& port,
  /*in*/ ::gov::cca::Component c,
  /*in*/ ::gov::cca::ports::BuilderService bs,
  /*in*/ ::gov::cca::Services services,
  /*in*/ ::test_script_babel::StringMap sm ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(test_script_babel.BabelMain.setParameters)
  // insert implementation here
  std::cerr << "test_script_babel.BabelMain.setParameters fixme" << std::endl;
  // DO-NOT-DELETE splicer.end(test_script_babel.BabelMain.setParameters)
}

/**
 * Method:  driverBody[]
 */
void
test_script_babel::BabelMain_impl::driverBody (
  /*inout*/ ::gov::cca::AbstractFramework& af ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(test_script_babel.BabelMain.driverBody)
	gov::cca::TypeMap dummy;
	dummy = af.createTypeMap();

	gov::cca::ports::BuilderService bs, dummybs;
	test_script_babel::PrivateRepository pr;
	pr = test_script_babel::PrivateRepository::_create();

	gov::cca::Services services;
	// set the script up as a component in the frame it receives.
	services = af.getServices("test_script_babel_BabelMain", "test_script_babel_BabelMain", dummy);
	// and find its id tag in the frame.
	gov::cca::ComponentID myself = services.getComponentID();

	// tell the framework about the components that come with the driver.
	// the components from PrivateRepository will now be available from
	// the BuilderService port.
	
	services.addProvidesPort(pr, "test_script_babel_PrivateRepository", "ccaffeine.ports.ComponentFactory", dummy);

	services.registerUsesPort("bs", "gov.cca.ports.BuilderService", dummy);

	gov::cca::Port dummyp;
	gov::cca::Port p;
	p = services.getPort("bs");
	if ( p._is_nil() ) {
		WHINE("Service port bs is missing!");
	}
	bs = p; // CAST
	if ( bs._is_nil() ) {
		WHINE2(gov::cca::CCAExceptionType_BadPortType, "Service port bs is not of expected type neo::cca::ports::BuilderService");
	}
	// scripted source here

#include "test_script_babel.BabelMain.driverBody.guts.hh"

	// end script source
	bs = dummybs;
	p = dummyp;
	services.releasePort("bs");
	services.unregisterUsesPort("bs");
	services.removeProvidesPort("test_script_babel_PrivateRepository");
	// remove ourselves from the frame.
	af.releaseServices(services);


  // DO-NOT-DELETE splicer.end(test_script_babel.BabelMain.driverBody)
}


// DO-NOT-DELETE splicer.begin(test_script_babel.BabelMain._misc)
// Put miscellaneous code here
// DO-NOT-DELETE splicer.end(test_script_babel.BabelMain._misc)

