#ifndef __BUILDERSERVICEPT_HH__
#define __BUILDERSERVICEPT_HH__

#include <unistd.h>
#include <cca.h>
#include <stdPorts.h>
#include "dc/framework/dc_fwkStar.h"
#include "dc/user_iface/BuilderModel.h"
#include "dc/user_iface/BuilderView.h"
#include "dc/user_iface/DefaultBuilderModel.h"
#include "dc/user_iface/CmdLineBuilderView.h"
#include "dc/user_iface/CmdLineBuilderViewMux.h"
#include "dc/framework/dc_fwkStar.h"

#include "dc/export/ccafeopq.hh"
#include "dc/framework/KernelPort.h"
#include "dc/framework/OpqBuilderService.h"


class BuilderServicePC : public virtual PortConverter {
private:
public:
  virtual ~BuilderServicePC(){}

  virtual gov::cca::Port convert(::ccafeopq::Port * op) {
    ::ccafeopq::BuilderService * bsp =
	dynamic_cast< ::ccafeopq::BuilderService * > (op);
    if(!bsp) {
      IO_en1("BuilderServicePT: fails to cast ::ccafeopq::Port * "
	     "to a ::ccafeopq::BuilderService *, returning NULL");
      return  gov::cca::Port();
    }
    ccaffeine::ports::BuilderService bsPort = 
      ccaffeine::ports::BuilderService::_create();
    bsPort.initialize(bsp);
    gov::cca::Port p = bsPort; // cast
    return p;
  }
};

#endif // __BUILDERSERVICEPT_HH__
