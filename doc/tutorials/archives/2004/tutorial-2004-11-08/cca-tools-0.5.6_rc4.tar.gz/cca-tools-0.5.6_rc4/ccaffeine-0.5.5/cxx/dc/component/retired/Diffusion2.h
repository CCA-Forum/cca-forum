#ifndef __DIFFUSION2_H__
#define __DIFFUSION2_H__

//#include <stdlib.h>
//#include "jc++/jc++.h"
//#include "jc++/util/jc++util.h"
//#include <cca.h>
//#include  "parameters/parametersStar.h"
//#include "port/portInterfaces.h"
//#include "port/supportInterfaces.h"
//#include "dc/port/portStar.h"


/** 2D diffusion by equation solver. */
class Diffusion2 : public virtual classic::gov::cca::Component, public virtual classic::gov::cca::GoPort {
 private:
  
  classic::gov::cca::Services* svc;
  classic::gov::cca::PrintfPort *pfp;
  boolean isInitialized;
  boolean vizInitialized;
  CCA_Block* block;
  double* data;
  boolean debug;

  int beginCol;
  int endCol;
  int beginRow;
  int endRow;
  int offset;
  int colLen;
  int numRows;
  int numCols;

  ConfigurableParameterPort* pp;
  DoubleParameter* timeParam;
  DoubleParameter* tEndParam;
  DoubleParameter* tBeginParam;
  DoubleParameter* dtParam;
  DoubleParameter* dxParam;
  DoubleParameter* dyParam;
  BoolParameter* isRandom;
  DoubleParameter* randDuration;
  DoubleParameter* randMaxTemp;
  DoubleParameter* randMinTemp;
  DoubleParameter* randProbability;

  double t;
  double tEnd;
  double dt;
  double dx;
  double dy;
  double alpha;
  
  int numProcs;
  int myProc;
  int overlap;

  Source* lbcSrc;
  Source* rbcSrc;
  Source* tbcSrc;
  Source* bbcSrc;

  void setupParameters(ConfigurableParameterFactory *cpf);
  boolean computeRandBC(double* Uptr, Source** srcPtr, int i, int begin);
  void init1();
  void init2();
  void initViz();
  CDELETE Source* randomSource();
  int goSetup();
  int goSolve();
  int matConfigured;

 public:
  
  Diffusion2();
  virtual ~Diffusion2();
  /** Implements GoPort interfaces. */
  virtual int go();
  void setServices(classic::gov::cca::Services* svc);
  /** This means create the first state, i.e. initialize. */
  void stateCompute();
  void stateUpdate();

  void derivCompute();
  void derivUpdate();
  /** dump data in ASCII form to printfport. */
  void printGrid();
};



#endif // __DIFFUSION2_H__
