// 
// File:          ccaffeine_ports_ParameterDialogServiceWrap_Impl.hh
// Symbol:        ccaffeine.ports.ParameterDialogServiceWrap-v0.3
// Symbol Type:   class
// Description:   Server-side implementation for ccaffeine.ports.ParameterDialogServiceWrap
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_ccaffeine_ports_ParameterDialogServiceWrap_Impl_hh
#define included_ccaffeine_ports_ParameterDialogServiceWrap_Impl_hh

#ifndef included_SIDL_cxx_hh
#include "SIDL_cxx.hh"
#endif
#ifndef included_ccaffeine_ports_ParameterDialogServiceWrap_IOR_h
#include "ccaffeine_ports_ParameterDialogServiceWrap_IOR.h"
#endif
// 
// Includes for all method dependencies.
// 
#ifndef included_SIDL_BaseInterface_hh
#include "SIDL_BaseInterface.hh"
#endif
#ifndef included_SIDL_ClassInfo_hh
#include "SIDL_ClassInfo.hh"
#endif
#ifndef included_ccaffeine_ports_ParameterDialogServiceWrap_hh
#include "ccaffeine_ports_ParameterDialogServiceWrap.hh"
#endif
#ifndef included_gov_cca_Services_hh
#include "gov_cca_Services.hh"
#endif
#ifndef included_gov_cca_TypeMap_hh
#include "gov_cca_TypeMap.hh"
#endif
#ifndef included_gov_cca_ports_ParameterGetListener_hh
#include "gov_cca_ports_ParameterGetListener.hh"
#endif
#ifndef included_gov_cca_ports_ParameterSetListener_hh
#include "gov_cca_ports_ParameterSetListener.hh"
#endif


// DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap._includes)
// Put additional includes or other arbitrary code here...
#include "dc/export/AllExport.hh"
//#include "dc/export/oldPorts.hh"
// DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap._includes)

namespace ccaffeine { 
  namespace ports { 

    /**
     * Symbol "ccaffeine.ports.ParameterDialogServiceWrap" (version 0.3)
     * 
     * The implementation of the babel ParameterDialogService
     * is a wrapper. The component writer cannot create an instance
     * of this independently and succeed. The component writer
     * must use the port ParameterDialogService, not this class.
     */
    class ParameterDialogServiceWrap_impl
    // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap._inherits)
    // Put additional inheritance here...
    // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap._inherits)
    {

    private:
      // Pointer back to IOR.
      // Use this to dispatch back through IOR vtable.
      ParameterDialogServiceWrap self;

      // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap._implementation)
      // Put additional implementation details here...
#if ENABLE_DEPRECATED_NAMESPACE
	::ccafeopq::ports::ParameterDialogService *opds;
#else
        void * opds;
#endif
      // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap._implementation)

    private:
      // private default constructor (required)
      ParameterDialogServiceWrap_impl() {} 

    public:
      // SIDL constructor (required)
      // Note: alternate Skel constructor doesn't call addref()
      // (fixes bug #275)
      ParameterDialogServiceWrap_impl( struct 
        ccaffeine_ports_ParameterDialogServiceWrap__object * s ) : self(s,
        true) { _ctor(); }

      // user defined construction
      void _ctor();

      // virtual destructor (required)
      virtual ~ParameterDialogServiceWrap_impl() { _dtor(); }

      // user defined destruction
      void _dtor();

    public:


      /**
       * passed in is a void * cast pointer of
       *  ccafeopq::ParameterDialogService.
       */
      void
      initialize (
        /*in*/ void* ccafeopq_ParameterDialogService_port_ptr
      )
      throw () 
      ;


      /**
       * fetch up a pointer for static casting. if the name
       * supplied is not exactly right, returns null.
       */
      void*
      getWrapped (
        /*in*/ const ::std::string& className
      )
      throw () 
      ;


      /**
       * Initialize the portData for use as a parameter dialog port
       *  with name portName.
       *  More than one such port can be defined. Each must
       *  be published before the next can be created.
       *  The given string portName will appear in the TypeMap
       *  as the result of this function and must not be changed
       *  by the component henceforth. It will appear under the key
       *  "ParameterDialogService.portName",
       *  @param portData the typemap associated with the port;
       *       It is shared between the ParameterDialogService
       *       and the component. The ParameterDialogService will
       *       not read or change values in portData except those
       *       requested via the addRequest functions.
       *  @param portName The name of a ParameterPort to appear in
       *       user interface one way or another.
       *  
       * 
       */
      void
      createParameterPort (
        /*inout*/ ::gov::cca::TypeMap& portData,
        /*in*/ const ::std::string& portName
      )
      throw () 
      ;


      /**
       * Define the window title for the parameter dialog.
       * 
       */
      void
      setBatchTitle (
        /*in*/ ::gov::cca::TypeMap portData,
        /*in*/ const ::std::string& title
      )
      throw () 
      ;


      /**
       * Define the next tab/group title to use. All
       * addRequest subsequent calls will add to this group.
       * Multiple dialog tabs/groups can be defined in this way.
       */
      void
      setGroupName (
        /*in*/ ::gov::cca::TypeMap portData,
        /*in*/ const ::std::string& newGroupName
      )
      throw () 
      ;


      /**
       * Define a boolean parameter and its default state.
       * The configured value is always available by
       * portData->getBool(name, ...);
       */
      void
      addRequestBoolean (
        /*in*/ ::gov::cca::TypeMap portData,
        /*in*/ const ::std::string& name,
        /*in*/ const ::std::string& help,
        /*in*/ const ::std::string& prompt,
        /*in*/ bool deflt
      )
      throw () 
      ;


      /**
       * Define a int parameter and its default state.
       * The configured value is always available by
       * portData->getInt(name, ...) and it will be
       * in the range [low, high].
       */
      void
      addRequestInt (
        /*in*/ ::gov::cca::TypeMap portData,
        /*in*/ const ::std::string& name,
        /*in*/ const ::std::string& help,
        /*in*/ const ::std::string& prompt,
        /*in*/ int32_t deflt,
        /*in*/ int32_t low,
        /*in*/ int32_t high
      )
      throw () 
      ;


      /**
       * Define a long parameter and its default state.
       * The configured value is always available by
       * portData->getLong(name, ...) and it will be
       * in the range [low, high].
       */
      void
      addRequestLong (
        /*in*/ ::gov::cca::TypeMap portData,
        /*in*/ const ::std::string& name,
        /*in*/ const ::std::string& help,
        /*in*/ const ::std::string& prompt,
        /*in*/ int64_t deflt,
        /*in*/ int64_t low,
        /*in*/ int64_t high
      )
      throw () 
      ;


      /**
       * Define a float parameter and its default state.
       * The configured value is always available by
       * portData->getFloat(name, ...) and it will be
       * in the range [low, high].
       */
      void
      addRequestFloat (
        /*in*/ ::gov::cca::TypeMap portData,
        /*in*/ const ::std::string& name,
        /*in*/ const ::std::string& help,
        /*in*/ const ::std::string& prompt,
        /*in*/ float deflt,
        /*in*/ float low,
        /*in*/ float high
      )
      throw () 
      ;


      /**
       * Define a double parameter and its default state.
       * The configured value is always available by
       * portData->getDouble(name, ...) and it will be
       * in the range [low, high].
       */
      void
      addRequestDouble (
        /*in*/ ::gov::cca::TypeMap portData,
        /*in*/ const ::std::string& name,
        /*in*/ const ::std::string& help,
        /*in*/ const ::std::string& prompt,
        /*in*/ double deflt,
        /*in*/ double low,
        /*in*/ double high
      )
      throw () 
      ;


      /**
       * Define a string parameter and its default state.
       * The configured value is always available by
       * portData->getString(name, ...).
       * If no addRequestStringChoice calls are made, the
       * user input may be any string. If addRequestStringChoice
       * is used, the value will be one among the choices.
       * If addRequestStringChoice is used, deflt must
       * be among the choices defined.
       */
      void
      addRequestString (
        /*in*/ ::gov::cca::TypeMap portData,
        /*in*/ const ::std::string& name,
        /*in*/ const ::std::string& help,
        /*in*/ const ::std::string& prompt,
        /*in*/ const ::std::string& deflt
      )
      throw () 
      ;


      /**
       * define a new choice for a string parameter.
       * If no calls to this function are made for a given
       * name, then any form of string will be acceptable input. 
       */
      void
      addRequestStringChoice (
        /*in*/ ::gov::cca::TypeMap portData,
        /*in*/ const ::std::string& name,
        /*in*/ const ::std::string& choice
      )
      throw () 
      ;


      /**
       * Clear all previously added requests, titles, groups. After
       *  this call, it is as if the ParameterPort has
       *  been created but never configured. The values of
       *  previously defined parameters will, nonethesless,
       *  remain in the typemap.
       *  Typically, this is used only by someone implementing
       *  the updateParameterPort function from
       *  interface ParameterGetListener.
       */
      void
      clearRequests (
        /*in*/ ::gov::cca::TypeMap portData
      )
      throw () 
      ;


      /**
       * Register listener (the component) that wishes to have
       * a chance to change the contents of its ParameterPort
       * just before the parameters typemap is used to
       * render the parameter dialog.
       * @param powner a pointer to the listener that will be
       * forgotten when it is no longer needed. 
       */
      void
      setUpdater (
        /*in*/ ::gov::cca::TypeMap portData,
        /*in*/ ::gov::cca::ports::ParameterGetListener powner
      )
      throw () 
      ;


      /**
       * Register listener (the component) if it wishes to be
       * informed when an parameter is set.
       * Listeners are called after values are set.
       */
      void
      setUpdatedListener (
        /*in*/ ::gov::cca::TypeMap portData,
        /*in*/ ::gov::cca::ports::ParameterSetListener powner
      )
      throw () 
      ;


      /**
       * Signal that the ParameterPort is fully defined and should
       * now pop out on the component. The Services passed here
       * must be the component's own Services handle.
       * The ParameterDialogService takes care of addProvidesPort
       * and task delegation.
       */
      void
      publishParameterPort (
        /*in*/ ::gov::cca::TypeMap portData,
        /*in*/ ::gov::cca::Services svc
      )
      throw () 
      ;


      /**
       * Cause a previously defined parameter port to go away.
       * This function should be called at component shutdown
       * (setService(0)) time for any parameter ports that have
       * been published but not yet unpublished.
       * The ParameterDialogService takes care of removeProvidesPort.
       */
      void
      unpublishParameterPort (
        /*in*/ ::gov::cca::TypeMap portData,
        /*in*/ ::gov::cca::Services svc
      )
      throw () 
      ;

    };  // end class ParameterDialogServiceWrap_impl

  } // end namespace ports
} // end namespace ccaffeine

// DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap._misc)
// Put miscellaneous things here...
// DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap._misc)

#endif
