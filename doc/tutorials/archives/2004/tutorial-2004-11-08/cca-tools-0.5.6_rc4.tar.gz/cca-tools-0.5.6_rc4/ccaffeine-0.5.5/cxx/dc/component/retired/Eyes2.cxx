#include <stdio.h>
#include "esi/MPI_wrapper.h"
//#include "util/IO.h"

#ifndef _CCAMPI
// This is two completely different implementations, if 
// do not have mpi,pvm,cumulus.
// Here is Eyes2-lite:
#include <unistd.h>
#include <assert.h>
#include <ESI.h>
#include "jc++/jc++.h"
#include "jc++/util/jc++util.h"
#include "parameters/parametersStar.h"
#include <cca.h>
#include "port/portInterfaces.h"
#include "dc/port/portStar.h"
#include "dc/port/DefaultParameterPort.h"

#include "dc/component/Eyes2.h"

#include "util/freefree.h" //make free go away

static char *EYES_VERSION="$Id: Eyes2.cxx,v 1.1 2003/05/02 00:20:38 baallan Exp $ build without MPI, PVM, or CUMULVS";

#ifdef MPI_wrapper_HAS_COMM
#define(`fatal_error', `errprint(`m4: '__file__: __line__`: fatal error: $*')m4exit(1)')
#fatal_error('There aint no stinkin mpi around, idiot!')
#endif

Eyes2::Eyes2() {
  verbose = false;
  debug = false;
  gub=0;
  glb=0;
  axisinfo =0;
  axisinfo2 = 0;
  axistype = 0;
  arraydecl = 0;
  mw = new struct MPI_wrapper;
  char hname[1024];
  (void)gethostname(hname,1023);
  mw->hostname = STRDUP(hname);
  mw->pid = getpid();
  int err = 0;
  fname[0] = fname[1] = 0;
  configured = (err==0)?0:-3; // there are 3 set calls mandatory
  rank = 0;
  size = 1;
}

Eyes2::~Eyes2() {
  esi_msg msg;
  x = 0;
  y = 0;
  free(fname[0]);
  free(fname[1]);
  fname[0] = fname[1] = 0;
  for (int k=0;k<2;k++) {
    if (dataptr[k]!=0) {
      (void) field[k]->releaseArray(&(dataptr[k]),msg);
      assert(dataptr[k] == 0);
    }
  }
  free(mw->hostname);
  delete mw; mw = 0;
  configured = -1;
  rank = size = -2;
}

void Eyes2::setServices(Services *cc){
  core = cc;
  // We supply a sink for JCPN(Vector)s (they call us)
  core->addProvidesPort(this,
    core->createPortInfo("VIZ","Cartesian2Port",0));
}

int Eyes2::visualize() {

  if (configured < 3) {
    return 1;
  }

  int i,j,k,ilim,jlim,dlim;
  double *tmpd;
  for (k=0; k<2; k++) {
    ilim = y->getLocalSize(); 
    jlim = x->getLocalSize();
    dlim = ilim*jlim;
    assert(dlim == field[k]->getLocalSize());
    pfp->pn("\n%d ----------- Values for %s--------------------------",mw->pid,fname[k]);
    tmpd = dataptr[k];
    for (j=0; j < jlim; j++) {
      for (i=0; i <ilim; i++) {
        pfp->pn("%3d: (%5d, %5d) %21.18g",mw->pid,i,j,tmpd[i+j*ilim]);
      }
    }
  }

  return 0;
}

void Eyes2::setXAxis(ESI_JCPN(Vector) *x_) {
  if (x_ != 0) {
    x = x_;
    configured++;
    // add coordinates later...  :-)
  }
}

void Eyes2::setYAxis(ESI_JCPN(Vector) *y_) {
  if (y_ != 0) {
    y = y_;
    configured++;
    // add coordinates later...  :-)
  }
}

void Eyes2::setField(ESI_JCPN(Vector) *data, char *name, int field_number) {
  if (data != 0 && field_number >= 0 && field_number <= 1) {
    configured++;
         /// field is the 1d equivalent of a 2d f77 array
         /// with global dimension data.length=x.localsize*y.localsize
         /// data(ix, iy).

    int err = data->accessArrayRead(&dataptr[field_number]);
    assert(err==0);
    field[field_number] = data;
    fname[field_number] = STRDUP((name != 0)?name:((field_number)?"Field 1":"Field 0"));
  }
}

void Eyes2::setTime(double * theta, char *name, int field_number)  {
  // do this at a later time...  :-)
}

//end Eyes2-lite
#else // _CCAMPI
// Eyes2-heavy

#include <ESI.h>
#include <cca.h>
#include "jc++/jc++.h"
#include "jc++/util/jc++util.h"
#include "parameters/parametersStar.h"
#include "dc/port/portStar.h"
#include "dc/port/DefaultParameterPort.h"

#ifdef _CCAVIS
#include "stv.h" //cumulus
#endif // _CCAVIS
#include "dc/component/Eyes2.h"

#include "util/freefree.h" //make free go away

#ifndef _CCAVIS
static char *EYES_VERSION="$Id: Eyes2.cxx,v 1.1 2003/05/02 00:20:38 baallan Exp $ build with MPI and without PVM or CUMULVS";
#else
static char *EYES_VERSION="$Id: Eyes2.cxx,v 1.1 2003/05/02 00:20:38 baallan Exp $ build with MPI, PVM, and CUMULVS";
#endif

Eyes2::Eyes2() {
  verbose = FALSE;
  debug = FALSE;
  mw = new struct MPI_wrapper;
    // note debugger may show the serial definition of
    // mw (pid,hostname), but it is wrong.
  char tmp[60];
  int err = 0;
  err += MPI_Comm_dup(MPI_COMM_WORLD,&(mw->comm));
  err += MPI_Comm_rank(mw->comm,&rank);
  err += MPI_Comm_size(mw->comm,&size);
  sprintf(tmp,"mpi->rank %d, size %d",rank,size);
  pfp->en(tmp);
  configured = (err==0)?0:-3; // there are 3 set calls mandatory
#ifdef _CCAVIS
  gub = new int[STV_MAX_DIM];
  glb = new int[STV_MAX_DIM];
  axisinfo = new int[STV_MAX_DIM];
  axisinfo2 = new int[STV_MAX_DIM];
  axistype = new int[STV_MAX_DIM];
  arraydecl = new int[STV_MAX_DIM];
  stv_init( "physics", 1000, size, rank );
#endif // _CCAVIS
}

Eyes2::~Eyes2() {
  esi_msg msg;
  free(fname[0]);
  free(fname[1]);
  fname[0] = fname[1] = 0;
  for (int k=0;k<2;k++) {
    if (dataptr[k]!=0) {
      (void) field[k]->releaseArray(&(dataptr[k]),msg);
      assert(dataptr[k] == 0);
    }
  }
#ifdef _CCAVIS
  delete gub; gub = 0;
  delete glb; glb =0;
  delete axisinfo; axisinfo = 0;
  delete axisinfo2; axisinfo2 =0;
  delete axistype; axistype = 0;
  delete arraydecl; arraydecl = 0;
#endif
  MPI_Comm_free(&(mw->comm));
  delete mw; mw = 0;
  configured = -1;
}

void Eyes2::setServices(Services *cc){
  core = cc;
  // We supply a sink for JCPN(Vector)s (they call us)
  core->addProvidesPort(this,
			core->createPortInfo("VIZ","Cartesian2Port",0));
}

int Eyes2::visualize() {
  pfp->pn("entry visualize: configured=%d\n", configured);
  if (configured < 3) {
    return 1;
  }
  esi_msg msg;

#ifdef _CCAVIS
  int params_changed;
  params_changed = stv_sendReadyData( stvSendDefault );
#endif
  if(verbose || debug) {
    // mpi w/out vis
    int i,j,k,ilim,jlim,dlim, xo;
    double *tmpd;
    // Number of fields hardwired in, Oh Ben, Ben, Ben ...
    // Jim needs to provide a proper cumulus object/port set.
    ESI_Map *ymap, *xmap, *fmap;
    ESI_MapAlgebraic *aymap, *axmap, *afmap;
    (void) y->getMap(ymap,msg);
    (void) x->getMap(xmap,msg);
    ymap->getInterface("ESI_MapAlgebraic",((void **)(&aymap)),msg);
    xmap->getInterface("ESI_MapAlgebraic",((void **)(&axmap)),msg);
    assert(axmap != 0);
    assert(aymap != 0);

    for (k=0; k<1; k++) {
      aymap->getLocalSize(&ilim,msg); 
      axmap->getLocalSize(&jlim,msg);
      axmap->getLocalOffset(&xo,msg);
      dlim = ilim*jlim;

      int checksize;
      (void) field[k]->getMap(fmap,msg);
      fmap->getInterface("ESI_MapAlgebraic",((void **)(&afmap)),msg);
      afmap->getLocalSize(&checksize,msg);
      assert(dlim == checksize);

      pfp->pn("\n%d ----------- Values for %s--------------------------",rank,fname[k]);
      tmpd = dataptr[k];
      for (j=0; j < jlim; j++) {
	for (i=0; i <ilim; i++) {
	  pfp->pn("%3d: (%5d, %5d) %21.18g",rank,i,j+xo,tmpd[i+j*ilim]);
	}
      }
    }
  }

  // steering updates later...
  return 0;
}

void Eyes2::setXAxis(ESI_JCPN(Vector) *x_) {
  if (x_ != 0) {
    x = x_;
    configured++;
#ifdef _CCAVIS
    axistype[0] = stvExplicit;
    axisinfo[0] = x->getLocalOffset();
    axisinfo2[0] = axisinfo[0] + x->getLocalSize() - 1;
    glb[0] = 0;
    gub[0] = x->getGlobalSize() - 1;

    arraydecl[0] = x->getLocalSize();

	pfp->pn("setXAxis(): axisinfo(%d,%d) gb(%d,%d) arraydecl=%d\n",
		axisinfo[0], axisinfo2[0], glb[0], gub[0], arraydecl[0] );

#endif // _CCAVIS

  }
  // add coordinates later...  :-)
}

void Eyes2::setYAxis(ESI_JCPN(Vector) *y_) {
  if (y_ != 0) {
    y = y_;
    configured++;
#ifdef _CCAVIS
    axistype[1] = stvCollapse;
    axisinfo[1] = y->getLocalOffset();
    axisinfo2[1] = axisinfo[1] + y->getLocalSize() - 1;
    glb[1] = 0;
    gub[1] = y->getGlobalSize() - 1;

    arraydecl[1] = y->getLocalSize();

	pfp->pn("setYAxis(): axisinfo(%d,%d) gb(%d,%d) arraydecl=%d\n",
		axisinfo[1], axisinfo2[1], glb[1], gub[1], arraydecl[1] );

#endif // _CCAVIS

  }
  // add coordinates later...  :-)
}

void Eyes2::setField(ESI_JCPN(Vector) *data, char *name, int field_number) {
  esi_msg msg;
  if (data != 0 && field_number >= 0 && field_number <= 1) {
    field[field_number] = data;
    fname[field_number] = STRDUP((name != 0)?name:((field_number)?"Field 1":"Field 0"));
    configured++;
         /// field is the 1d equivalent of a 2d f77 array
         /// with global DIMENSION data.length=x.length*y.length
         /// data(ix, iy).

    int err = data->getArrayRead(&dataptr[field_number],msg);
    assert(err==0);

#ifdef _CCAVIS
    int decompId;

    decompId = stv_decompDefine( 2, axistype, axisinfo, axisinfo2,
        glb, gub, 1, stvLocalArray );

    stv_fieldDefine( (STV_VALUE) dataptr[field_number], name, decompId,
        stvNoFieldOffsets, arraydecl, stvDouble,
        stvLocalArray, stvVisOnly );
#endif // _CCAVIS
  }
}

void Eyes2::setTime(double * theta, char *name, int field_number)  {
  // do this at a later time...  :-)
}

#endif //_CCAMPI Eyes2-heavy
