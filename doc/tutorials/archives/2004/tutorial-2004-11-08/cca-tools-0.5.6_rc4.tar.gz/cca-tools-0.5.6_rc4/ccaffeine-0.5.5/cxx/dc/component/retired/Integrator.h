#ifndef Integrator_h_seen
#define Integrator_h_seen

/** That does a custom integration. */
class Integrator : public virtual classic::gov::cca::Component, public virtual classic::gov::cca::GoPort, public virtual ClockPort {

private:

  classic::gov::cca::Services *core;

  DefaultParameterPort *pp;
  // first page
  DoubleParameter *step; // Euler time step
  DoubleParameter *horizon; // integration time limit
  // next page
  IntParameter *nJumps; // number of 'noises' over the time span
  IntParameter *nJumpVars; // number of adjacent states to tweak in a jump
  DoubleParameter *jumpMagnitude; // fractional size of change in a jumped var

  // don't know how many of these we need.
  double time; // current time point in simulation
  double next_time;  // next noise point in simulation


public:

  Integrator();
  ~Integrator();

  virtual void setServices(classic::gov::cca::Services *cc);

  virtual double getClock();

  /**Run the integrator according to the parameter values
     obtained. Implements GoPort */
  virtual int go();
};
#endif //Integrator_h_seen
