#if 0 // this really needs to go away.
// if no one notices for a while in python land, it's a goner
//
// never use this header except when panicked.
//
#include "ccaffeine_CCAException.hh"
#include "ccaffeine_ComponentClassDescription.hh"
#include "ccaffeine_ComponentID.hh"
#include "ccaffeine_ConnectionEventService.hh"
#include "ccaffeine_ConnectionID.hh"
#include "ccaffeine_Framework.hh"
#include "ccaffeine_ports_ComponentRepository.hh"
#include "ccaffeine_ports_ConnectionEvent.hh"
#include "ccaffeine_Services.hh"
#include "ccaffeine_TypeMap.hh"
#include "ccaffeine_TypeMismatchException.hh"


#include "ccaffeine_CCAException_Impl.hh"
#include "ccaffeine_ComponentClassDescription_Impl.hh"
#include "ccaffeine_ComponentID_Impl.hh"
#include "ccaffeine_ConnectionEventService_Impl.hh"
#include "ccaffeine_ConnectionID_Impl.hh"
#include "ccaffeine_Framework_Impl.hh"
#include "ccaffeine_ports_ComponentRepository_Impl.hh"
#include "ccaffeine_ports_ConnectionEvent_Impl.hh"
#include "ccaffeine_Services_Impl.hh"
#include "ccaffeine_TypeMap_Impl.hh"
#include "ccaffeine_TypeMismatchException_Impl.hh"
#endif // go away
