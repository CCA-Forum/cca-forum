/**
For testing purposes only. Do NOT copy the code
used to implement this class -- it depends on internal
framework interfaces that are highly subject to change
and will NOT be supported in future versions.

REPEAT:
Don't do anything like this component when writing
your own. This service (PDS) is not yet ported to 
classic space.
*/
//
// ABANDON ALL HOPE, YE WHO ENTER HERE
//
#include <cca.h>
#include <stdPorts.h>
#include <ports/StringConsumerPort.h>
#include "dc/framework/Check.h"
#include "dc/export/ccafeopq.hh"
#include "dc/classic/ccafe-bind/AllCcafeBind.hh"
#include "dc/component/PDSTest.h"

#ifndef lint
namespace {
char id[] =
"$Id: PDSTest.cxx,v 1.1 2004/03/25 02:47:56 baallan Exp $";
} ENDSEMI
#endif

using std::string;

PDSTest::PDSTest(){ myCore = 0; numtests = 0;}
PDSTest::~PDSTest(){ myCore = 0; }

void PDSTest::setServices(classic::gov::cca::Services *cc) {
	if (myCore != 0 && cc == 0) {
		::classic::gov::cca::Port * port;
		port = myCore->getPort("pds");
		if (port != 0) {
			pds = dynamic_cast< ::ccafeopq::ParameterDialogService *>(port);
			if (!pds == 0) {
				ClassicServices * cs = dynamic_cast<ClassicServices *>(myCore);
				::ccafeopq::Services * os = 0;
				os = cs->unwrapServices();
				for (size_t i = 0; i < pplist.size(); i++)
				{
					::ccafeopq::TypeMap_shared tm = pplist[i];
					pds->unpublishParameterPort(tm, os);
				}
			}
			myCore->releasePort("pds");
		}
		myCore->unregisterUsesPort("pds");
		myCore->removeProvidesPort("go");
		myCore = 0;
		return;
	}
	if (myCore != 0 && cc != 0)
	{
		return; // fwk is hosed. ignore it.
	}

  myCore = cc;

  // Contact the PrintfService
  classic::gov::cca::PortInfo* pinfo = cc->createPortInfo("pSvc", "gov.cca.JPrintfService", 0);
  cc->registerUsesPort(pinfo);
  pinfo = 0;
  pfp = dynamic_cast<classic::gov::cca::JPrintfPort*>(cc->getPort("pSvc"));
  CHECKDC(pfp);
  if(pfp == 0) {
    cc->addProvidesPort(this, cc->createPortInfo("DEAD=NoJPrintf", "classic::gov::cca::GoPort", 0));
    ::printf("!!! No JPrintfService available from framework.");
    return;
  }

  pinfo = myCore->createPortInfo("pds", "::ccafeopq::ParameterDialogService",0);
  myCore->registerUsesPort(pinfo);
  pinfo = 0;
  pinfo = myCore->createPortInfo("go", "classic::gov::cca::GoPort",0);
  myCore->addProvidesPort(this, pinfo);
  pinfo = 0;
}

int PDSTest::go()
{
  char buf[40];
  numtests++;
  sprintf(buf,"%d",numtests);
  classic::gov::cca::Port * port= 0;

  ClassicServices * cs = dynamic_cast<ClassicServices *>(myCore);
  ::ccafeopq::Services * os = 0;
  os = cs->unwrapServices();

  ::ccafeopq::TypeMap_shared tm = os->createTypeMap();

  pplist.push_back(tm);
  std::string pname = "PP_";
  pname += buf;


  port = myCore->getPort("pds");
  if (port == 0) {
	   return -1;
  }
  pds = dynamic_cast< ::ccafeopq::ParameterDialogService *>(port);
  pds->createParameterPort(tm, pname);

  ::std::string title = "Test PDS for port ";
  title += pname;
  pds->setBatchTitle(tm, title);
  pds->addRequestBoolean(tm,"noName","var to test if default group gets used","anon group",true);
  pds->setGroupName(tm,"Named Set1");
  pds->addRequestInt(tm,"iVar","a ranged test integer","int test", 5, 0 ,10);
  pds->addRequestLong(tm,"jVar","a deranged test long","long test", -50, 0 , -100);
  pds->setGroupName(tm,"Named Set2");
  pds->addRequestDouble(tm,"dVar","a ranged test double","double test", -50, 0 , -100);
  pds->addRequestFloat(tm,"fVar","a ranged test float","float test", 50, -1000 , 1000);
  pds->setGroupName(tm,"Named Set3");
  pds->addRequestString(tm,"sVar","a free test string","string any test", "some value");
  pds->addRequestString(tm,"sList","a choice test string","string list test", "some value");
  pds->addRequestStringChoice(tm,"sList","choice 1");
  pds->addRequestStringChoice(tm,"sList","choice 3");
  pds->addRequestStringChoice(tm,"sList","choice 2");
  
  pds->publishParameterPort(tm, os);
  pds = 0;

  myCore->releasePort("pds");
  return 0;
}


