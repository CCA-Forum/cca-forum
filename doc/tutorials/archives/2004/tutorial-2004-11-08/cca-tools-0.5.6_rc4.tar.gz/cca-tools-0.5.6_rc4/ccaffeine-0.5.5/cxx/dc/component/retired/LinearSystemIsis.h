#ifdef _CCAISIS
#ifndef LinearSystemIsis_h_seen
#define LinearSystemIsis_h_seen

//
#ifdef _CCAMPI
#include "isis-mpi.h"
#else
#include "isis-ser.h"
#endif

/** obsoleted component. do not use. */
class LinearSystemIsis : public virtual classic::gov::cca::Component, public virtual ParameterOwner, public virtual RowEquationSolver, public virtual GoDirectPort {

private:

  classic::gov::cca::Services *core;

  DefaultParameterPort *gpp;
  DefaultParameterPort *spp;
  DefaultParameterPort *pcpp;

  // if you add/delete parameters here, fix up IsisWrapper code.
  StringParameter *solvername ;
  StringParameter *pcname ;
  BoolParameter *rowScale;
  BoolParameter *colScale;
  StringParameter *pcside ;
  DoubleParameter *solveTol ;
  IntParameter *solveItLim ;
  IntParameter *solveRestart ;
  IntParameter *blockSize ;
  StringParameter *blockType ;
  IntParameter *polyOrder ;
  StringParameter *polyType ;
  DoubleParameter *spaiEpsilon ;
  IntParameter *spaiNBSteps ;
  IntParameter *spaiMaxapi ;
  IntParameter *spaiMax;
  IntParameter *spaiMaxNew;
  BoolParameter *spaiVerbose;
  IntParameter *spaiCacheSize;

  ESI_Vector *ux;
  ESI_Vector *urhs;
  ESI_Vector *uresid;

  struct MPI_wrapper *mw;
  int my_rank;
  int num_procs;
  int master_rank;
  int n; // global row count
  int startRow, endRow, numParams;
  char **paramStrings;
  PreconditionerIsis *pPC1;
  PreconditionerIsis *pPC2;
  CommInfo *commInfo;
  RsDCRS_MatrixIsis *A;
  Dist_VectorIsis *ix, *ib, *ir;
  MapIsis *map;
  int lsize; // localSize of vectors, number of local rows.
  void updateParamStrings();

  int solveStarted;
  int solveStatus;
  PreconditionerIsis *pprecond;
  IterativeSolverIsis *psolver;
  LinearEquations *lse;


public:

  LinearSystemIsis();
  virtual ~LinearSystemIsis();

  // Component interface
  virtual void setServices(classic::gov::cca::Services *cc);


  // ParameterOwner interface
  virtual boolean updateParameterPort(class DefaultParameterPort *dpp);


  // Go interface
  virtual int go() { solve(); }

/**
  stripped down from the isis distDriver.cc by Alan Williams.
 */

  // RowEquationSolver interface

  virtual void solve();
    /// run the solver, after setRHS and the setEquation loop are done.

  virtual int setVectors(ESI_Vector *x, ESI_Vector *rightside, ESI_Vector *residual);
    /// This is a caching interface, it keeps the pointers given.
    /// To replace the rhs, first setVectors(0,0).
    /// This must be called before any setEquation calls.
    /// The system gets its distributed row geometry from the
    /// distribution of the rightside vector.

  virtual int setEquation(int row, int rowLen, int *colIndices, double *coef);
    /// This is a *copy* interface, it doesn't keep the pointers given.
    /// The row number and colIndices are indexed from 0, not 1.
    /// Equations can only be set after the vectors are set.
    /// If the system already has an equation for this row, the colindices
    /// must be the same but the coefficient values may be changed.
    /// If the equation given is off-processor or there is another error,
    /// we return 1 instead of 0.
    /// The RHS value for this equation should be stored in the
    /// previously set RHS vector before calling solve.

  virtual void equationsDone();
    /// tell us all the equations that will be set have been.

  virtual int getVectors();
    /// Updates the content of the x and residual vectors after solve.
    /// The caller is assumed to have the pointers -- this function
    /// accesses and updates the cached vector pointers.
    /// Return has values:
    /// -2: system never solved.
    /// -1: permanent failure of solution algorithm.
    /// 0: possible to continue iterating.
    /// 1: solution within tolerance reached.

private:
  // functions to firewall isis data structures from esi.
  void iVector2eVector(Dist_VectorIsis *isisV, ESI_Vector *esiV);
  void eVector2iVector(ESI_Vector *esiV, Dist_VectorIsis *isisV);
};
#endif //LinearSystemIsis_h_seen
#endif //_CCAISIS
