/*
 * File:          functions_LinearFunction_Impl.c
 * Symbol:        functions.LinearFunction-v1.0
 * Symbol Type:   class
 * Babel Version: 0.9.8
 * Description:   Server-side implementation for functions.LinearFunction
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 * babel-version = 0.9.8
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "functions.LinearFunction" (version 1.0)
 */

#include "functions_LinearFunction_Impl.h"

/* DO-NOT-DELETE splicer.begin(functions.LinearFunction._includes) */
/* Put additional includes or other arbitrary code here... */

#include <stdio.h>
#include "sidl_Exception.h"

#if (!defined NULL)
#define NULL 0
#endif
/* DO-NOT-DELETE splicer.end(functions.LinearFunction._includes) */

/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__ctor"

void
impl_functions_LinearFunction__ctor(
  /*in*/ functions_LinearFunction self)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._ctor) */
  /* Insert the implementation of the constructor method here... */

  /* Allocate memory for the private data of this component */
  struct functions_LinearFunction__data *pdptr = (struct functions_LinearFunction__data*) 
    malloc(sizeof(struct functions_LinearFunction__data));
  if (pdptr) {
    /* Initialize the framework Services handle */
    pdptr->frameworkServices = NULL;
  }
  functions_LinearFunction__set_data(self, pdptr);
  
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction._ctor) */
}

/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__dtor"

void
impl_functions_LinearFunction__dtor(
  /*in*/ functions_LinearFunction self)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._dtor) */
  /* Insert the implementation of the destructor method here... */
  
  struct functions_LinearFunction__data *pdptr;
  
  /* Access private data structure */
  pdptr = functions_LinearFunction__get_data(self);
  if (pdptr) {
    if (pdptr->frameworkServices) {
      gov_cca_Services_deleteRef(pdptr->frameworkServices);
    }
    pdptr->frameworkServices = NULL;
    free(pdptr); 
    functions_LinearFunction__set_data(self, NULL);
  }
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction._dtor) */
}

/*
 * Method:  init[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_init"

void
impl_functions_LinearFunction_init(
  /*in*/ functions_LinearFunction self,
    /*in*/ struct sidl_double__array* params)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.init) */
  /* Insert the implementation of the init method here... */
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction.init) */
}

/*
 * Method:  evaluate[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_evaluate"

double
impl_functions_LinearFunction_evaluate(
  /*in*/ functions_LinearFunction self, /*in*/ double x)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.evaluate) */
  /* Insert the implementation of the evaluate method here... */

  return 12.0 * x + 3.2;

  /* DO-NOT-DELETE splicer.end(functions.LinearFunction.evaluate) */
}

/*
 * Method:  setServices[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_setServices"

void
impl_functions_LinearFunction_setServices(
  /*in*/ functions_LinearFunction self, /*in*/ gov_cca_Services servicesHandle,
    /*out*/ sidl_BaseInterface* _ex)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.setServices) */
  /* Insert the implementation of the setServices method here... */

  sidl_BaseInterface exception = NULL;

  struct functions_LinearFunction__data *pd;
  
  /* Access private data structure */
  pd = functions_LinearFunction__get_data(self);
  if (pd->frameworkServices) {
    /* remove reference to previous services object */
    gov_cca_Services_deleteRef(pd->frameworkServices);
  }
  pd->frameworkServices = servicesHandle;
  if (!servicesHandle) return;

  gov_cca_Services_addRef(servicesHandle);
  
  /* Create a typemap for the FunctionPort */
  gov_cca_TypeMap tm = gov_cca_Services_createTypeMap(pd->frameworkServices, &exception);
  if (SIDL_CATCH(exception, "gov.cca.CCAException")) {
    fprintf(stderr, "Exception:: %s:%d: gov::cca::TypeMap was not created\n",
	    __FILE__, __LINE__);
    SIDL_CLEAR(exception);
    exit(1);
  }
  if (tm == NULL) {
    fprintf(stderr, "Error:: %s:%d: gov::cca::TypeMap is nil\n",
	    __FILE__, __LINE__);
    exit(1);  
  } 
  
  /* Provide a FunctionPort */
  gov_cca_Port port = gov_cca_Port__cast(self);
  if (port == NULL) {
    fprintf(stderr, "Error:: %s:%d: Error casting self to gov::cca::Port \n",
	    __FILE__, __LINE__);
    exit(1);
  } 
  
  gov_cca_Services_addProvidesPort(pd->frameworkServices,   
				   port,
				   "FunctionPort",
				   "function.FunctionPort",
				   tm,
				   &exception);
  if (SIDL_CATCH(exception, "gov.cca.CCAException")) {
    fprintf(stderr, "Exception:: %s:%d: Could not register function.FunctionPort provides port\n",
	    __FILE__, __LINE__);
    SIDL_CLEAR(exception);
    exit(1);
  }
  
  /* Register with framework for component release */
  gov_cca_ComponentRelease cr = gov_cca_ComponentRelease__cast(self);
  if (cr != NULL) {
    gov_cca_Services_registerForRelease(pd->frameworkServices, cr, &exception);
  }
  
  return;
  
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction.setServices) */
}
