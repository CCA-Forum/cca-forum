#
# File:          PYDriver_Impl.py
# Symbol:        drivers.PYDriver-v1.0
# Symbol Type:   class
# Babel Version: 0.9.8
# Description:   Implementation of sidl class drivers.PYDriver in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
# babel-version = 0.9.8
#


# DO-NOT-DELETE splicer.begin(_initial)
# Put your code here...
import sys
# DO-NOT-DELETE splicer.end(_initial)

import sidl.BaseClass
import gov.cca.CCAException
import sidl.BaseInterface
import gov.cca.ports.GoPort
import gov.cca.Services
import gov.cca.Port
import gov.cca.Component
import sidl.ClassInfo
import drivers.PYDriver

# DO-NOT-DELETE splicer.begin(_before_type)
# Put your code here...
import gov.cca.ports.BuilderService        # Builder Services interface
import integrator.IntegratorPort           # Access to Integrator port
# DO-NOT-DELETE splicer.end(_before_type)

class PYDriver:

  # All calls to sidl methods should use __IORself

  def __init__(self, IORself):
    self.__IORself = IORself
    # DO-NOT-DELETE splicer.begin(__init__)
    # Put your code here...
    self.myservices = None 
    # DO-NOT-DELETE splicer.end(__init__)

  def go(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # int _return
    #

    # DO-NOT-DELETE splicer.begin(go)
    # Put your code here...
      
    try:
      intport = self.myservices.getPort('IntegratorPort')
      myintport = integrator.IntegratorPort.IntegratorPort(intport);   # Casting !!!!
    except:
      print 'Caught an exception in call to getPort()'
      print sys.exc_type, sys.exc_info()
    
    result = myintport.integrate(0.0, 1.0, 10000)  
    print 'Result = ', result
    
    self.myservices.releasePort('IntegratorPort')
    
    return 0
    # DO-NOT-DELETE splicer.end(go)

  def setServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # # None
    #

    # DO-NOT-DELETE splicer.begin(setServices)
    # Put your code here...
    self.myservices = services 
    
    mymap = services.createTypeMap()
    try:
      me = gov.cca.Component.Component(self.__IORself)  # Casting !!!!
    except:
      print 'Caught an exception in cast to gov.cca.Component'
      print sys.exc_type, sys.exc_info()
      
    try:
      services.addProvidesPort(me, 
                              'GoPort', 
                              'gov.cca.ports.GoPort', 
                              mymap);
    except:
      print 'Caught an exception in call to addProvidesPort()'
      print sys.exc_type, sys.exc_info()
    
    try:
      services.registerUsesPort('IntegratorPort', 
                                'integrator.IntegratorPort', 
                                mymap);
    except:
      print sys.exc_type, sys.exc_info()
      print 'Caught an exception in call to registerUsesPort()'
       
    print 'Python drivers.PYDriver done with setServices()'
    # DO-NOT-DELETE splicer.end(setServices)

# DO-NOT-DELETE splicer.begin(_final)
# Put your code here...
# DO-NOT-DELETE splicer.end(_final)
