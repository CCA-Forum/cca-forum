#!/bin/sh

function usage () {
	echo -e "\nUsage:\n\tsh $0 <rcfile> <lib_dir> <ccaffeine_executable>\n\n"\
		"This script adds a small Ccaffeine resource control (rc) script fragment\n"\
		"that set the dynamic  library search path to <lib_dir>\n"\
		" Arguments (all are required): \n"\
		"            rcfile is the full path name of the target Ccaffeine RC file\n"\
		"	     lib_dir is the full path location of the dynamic libraries\n"\
		"            ccaffeine_executable is the full path to the ccaffeine executable\n" > /dev/stderr
}

if [ $# -lt 2 ];  then
	usage
	exit 1;
fi

rcfilearg=$1
rcfiledir=`dirname $1`
lib=$2
ccafe=$3
instantiate_only="0"

if [ ! -f "$rcfilearg" ] ; then 
    echo -e "\n****\n**** Could not run tests, didn't find $rcfilearg file.\n****"; 
    exit 0;
fi 
if [ "x`echo $rcfilearg | grep \.incl`" == "x" ]; then 
    instantiate_only="1";
    rcfile=$rcfilearg
else 
    rcfile="`echo $rcfilearg | sed -e 's|\.incl||'`";
    sed -e "/@CCA_COMPONENT_PATH@/ s|@CCA_COMPONENT_PATH@|${lib}|" $rcfilearg > $rcfile;
fi

if [ "x`grep quit $rcfile`" == "x" ]; then echo "quit" >> $rcfile; fi; 
$ccafe --ccafe-rc $rcfile > $rcfile.log 2>&1 ; 
if [ "$instantiate_only" != "1" ] ; then
	echo -e "\n#### Testing component connection and execution."; 
	successful=`grep "specific go command successful" $rcfile.log | wc -l`
	expected=`egrep "^go " $rcfile | wc -l`
	if [  "$successful" != "0" -a "x$successful" == "x$expected" ]; then 
	    echo -e "\n====\n==== All simple run tests passed, go command executed successfully.\n===="; 
	else 
	    echo -e "\n****\n**** Some run tests dit NOT succeed, go command failed (see $rcfile.log).\n****"; 
	fi 
else # Instantiation test only
	echo -e "\n#### Testing component instantiation."; 
	successful=`grep "instantiate" $rcfile | wc -l`;
	expected=`grep "successfully instantiated" $rcfile.log | wc -l`;
	if [ "$successful" != "0" -a "x$successful" == "x$expected" ]; then 
	    echo -e "\n====\n==== Simple tests passed, all built components were successfully instantiated.\n===="; 
	else 
	    echo -e "\n****\n**** Simple tests did NOT succeed, some built components were not instantiated (see $rcfile.log).\n****"; 
	    grep "instantiation failed" $rcfile.log; 
	fi 
fi
