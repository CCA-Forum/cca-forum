// this file disappears if there is no mpi.
#ifdef _CCAMPI
#include <mpi.h>
#include <cca.h>
#include <ports/MPIService.h>
#include "dc/export/config.hh"
#ifdef HAVE_NEO
#include <neocca.hh>
#include <neoports.hh>
#endif
#include "dc/port/DefaultMPIService.h"

const int DefaultMPIService::cap; // small enough for debugging demos. must match header

DefaultMPIService::DefaultMPIService() {
	int i;
  for (i = 0; i < cap; i++) {
    comm[i] = MPI_COMM_NULL;
    inuse[i] = false;
  }
}

DefaultMPIService::~DefaultMPIService() {
	int i;
  for (i = 0; i < cap; i++) {
    // maybe should use commcompare...
    if (comm[i] != MPI_COMM_NULL) {
      MPI_Comm_free(&(comm[i]));
      comm[i] = MPI_COMM_NULL;
      if (inuse[i]) {
        // oh well, too bad.
        inuse[i] = false;
      }
    }
  }
}

MPI_Comm DefaultMPIService::getComm() {
	int i;
  // check for one recyclable
  for (i = 0; i < cap; i++) {
    // maybe should use commcompare...
    if (comm[i] != MPI_COMM_NULL) {
      if (!inuse[i]) {
        inuse[i] = true;
        return comm[i];
      }
    }
  }
  // find someplace to put a new duplicate.
  for (i = 0; i < cap; i++) {
    // maybe should use commcompare...
    if (comm[i] == MPI_COMM_NULL) {
      MPI_Comm_dup(MPI_COMM_WORLD, &(comm[i]));
      inuse[i] = true;
      return comm[i];
    }
  }
  // too bad, we're toast. hate those hardcoded cap limits.
  return MPI_COMM_NULL;
}

void DefaultMPIService::releaseComm(MPI_Comm m) {
  
  if (m == MPI_COMM_NULL) {
    return;
  }
  // if we don't find it, ignore it quietly.
	int i;
  for (i = 0; i < cap; i++) {
    int result;
    MPI_Comm_compare(m,comm[i],&result);
    if (result == MPI_IDENT && inuse[i] == true) {
      inuse[i] = false;
      break;
    }
  }
}

#endif // _CCAMPI
