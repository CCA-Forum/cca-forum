#include <cca.h>
#include <map>
#include <string>
#include "dc/framework/dc_fwkStar.h"
#include "dc/framework/bbl_fwkStar.h"
#include "dc/framework/TypeMapPortInfo.h"

///////
// UGH!!!!
//
using ::std::string;
//

TypeMapPortInfo::TypeMapPortInfo() {
  portname = porttype = 0; 
  tm = ccaffeine::TypeMap::_create();
}

/** Properties are terminated by a null entry for key and value */
TypeMapPortInfo::TypeMapPortInfo(CONST char* name, 
				 CONST char* type, 
				 gov::cca::TypeMap tm_) {
  if(tm_._is_nil()) {
    fprintf(stderr, "%s:%d:  tm_ is nil\n", __FILE__, __LINE__);
    this->tm = ccaffeine::TypeMap::_create();
    if(this->tm._is_nil()) {
      IO_dn1(":-( what the ... Call Gary Kumfert tm is still nil\n");
    } else {
      IO_dn1(":-) tm is *not* nil");
    }
  } else {
    fprintf(stderr, "%s:%d:  tm is not nil\n", __FILE__, __LINE__);
    this->tm  = tm_;
  }
  IO_dn2("name = %s", name);
  setName(name);
  IO_dn2("type = %s", type);
  setType(type);
}

/** A useful copy constructor from PortInfo. */
TypeMapPortInfo::TypeMapPortInfo(classic::gov::cca::PortInfo& pi) {
  setName(pi.getName());
  setType(pi.getType());
  DefaultPortInfo* dpi = dynamic_cast<DefaultPortInfo*>(&pi);
  if (dpi) {
    ::std::vector< ::std::string > keys = dpi->getKeys();
    for (unsigned int i = 0 ; i < keys.size(); i++) {
      ::std::string k = keys[i];
      char* p = pi.getProperty(const_cast<char *>(k.c_str()));
      if (p != 0) {
	try
       	{
      	  tm.putString(k , string(p));
	}
       	catch ( ::std::exception & e)
	{
	  // well, the damn babel exception ought to inherit std anyway...
  	  IO_dn2("type = %s", e.what() );
	}
      }
    }
  }
}

TypeMapPortInfo::~TypeMapPortInfo(){
  free(porttype);
  free(portname);
  // probably missing a tm destroy here.
}

CONST char* 
TypeMapPortInfo::getType() {
  return porttype;
}
CONST char* 
TypeMapPortInfo::getName() {
  return portname;
}
CONST char* 
TypeMapPortInfo::getProperty(CONST char* key) {
  string s = tm.getString(string(key), NULL);
  return (char*)s.c_str();
}

void 
TypeMapPortInfo::setType(const char* type) {
  porttype = STRDUP(type);
  tm.putString("cca.type", string(porttype));
}
void 
TypeMapPortInfo::setName(const char* name) {
  portname = STRDUP(name);
  IO_dn1(" About to do tm.putString");
  try {
    string s = portname;
    if(tm._not_nil()) {
      IO_dn1("tm is not nil");
    }else{
      IO_dn1("tm is nil");
    }
    tm.putString("cca.instanceName", s);
  } catch(SIDL::BaseException& e) {
    IO_dn2("SIDL::BaseException: %s", e.getMessage().c_str());
  }catch(std::exception& e) {
    IO_dn2("library exception: %s", e.what());
  } catch(...) {
    IO_dn1("whooo! unexpected exception");
  }
}

const gov::cca::TypeMap 
TypeMapPortInfo::getTypeMap() {
  return tm;
}

gov::cca::TypeMap 
TypeMapPortInfo::cloneTypeMap() {
  return tm.cloneTypeMap();
}

/** method unapproved and unproposed for standard. do not use except
    to debug.  @see ServicesHelper toStringPortInfo. */
CFREE char* 
TypeMapPortInfo::toString() {
  string s = string(portname);
  string t = string(porttype);
  const char* str = (string("Port name = ")+s+"Port type = "+t).c_str();
  return STRDUP(str);
}
