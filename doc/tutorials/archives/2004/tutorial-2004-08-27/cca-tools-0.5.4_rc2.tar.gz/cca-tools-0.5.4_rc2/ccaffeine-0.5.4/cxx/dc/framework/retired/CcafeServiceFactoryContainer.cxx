// #include <stdio.h>
#include <string>
#include <map>
#include "dc/export/AllExport.hh"
#include "ServiceFactory.h"
#include "ServicePortFactory.h"
#include "ServiceFactoryContainer.h"
#include "CcafeServiceFactoryContainer.h"

namespace {
char id[]=
"$Id: CcafeServiceFactoryContainer.cxx,v 1.1 2004/03/29 08:03:11 baallan Exp $";
} ENDSEMI

CcafeServiceFactoryContainer::CcafeServiceFactoryContainer() {
  
}

CcafeServiceFactoryContainer::~CcafeServiceFactoryContainer() {
  ::std::map< ::std::string, ServicePortFactory* >::iterator pos;
  for (pos = holder.begin(); pos != holder.end(); pos++) {
	  ServicePortFactory *spf = pos->second;
	  if (spf != 0) {
		  delete spf;
		  holder[pos->first] = 0;
	  } 
  }
}

/** Add a service to the table. */
ServicePortFactory* 
CcafeServiceFactoryContainer::addServicePortFactory(ServicePortFactory* factory) {
  if (factory == 0) {
    return 0; //should whine
  }
  ::std::map< ::std::string, ServicePortFactory* >::iterator pos;
  ::std::string key = factory->getType();
  pos = holder.find(key);
  if (pos != holder.end()) { 
    return 0; //should whine about duplicate.
  }
  holder[key] = factory;
  return factory;
}
/** Remove a service from the table. someone removing still owns the pointer,
 * so we don't delete. ugh what a mess. 
 */
ServicePortFactory* 
CcafeServiceFactoryContainer::removeServicePortFactory(ServicePortFactory* factory) {
  if (factory == 0) {
    return 0; //should whine
  }
  ::std::map< ::std::string, ServicePortFactory* >::iterator pos;
  ::std::string key = factory->getType();
  pos = holder.find(key);
  if (pos == holder.end()) { 
    return 0; //should whine about duplicate missing
  }
  holder.erase(key);
  return factory;
}

/** Create a service by type. 
 * If the service does not exist, NULL is returned. 
 */
ccafeopq::Port* 
CcafeServiceFactoryContainer::createService(const char* serviceType) {
  ::std::map< ::std::string, ServicePortFactory* >::iterator pos;
  ::std::string key = serviceType;
  pos = holder.find(key);
  if ( pos == holder.end()) {
    return 0;
  }
  ServicePortFactory* sf = pos->second;
  ccafeopq::Port* op = 0;
  op = sf->create();
  return op;
}

/** Get the underlying factory that has this type. */
ServicePortFactory* 
CcafeServiceFactoryContainer::getServicePortFactory(const char* SvcPortType){
  ::std::map< ::std::string, ServicePortFactory* >::iterator pos;
  ::std::string key = SvcPortType;
  pos = holder.find(key);
  if ( pos == holder.end()) {
    return 0;
  }
  return pos->second;
}

::std::vector< ::std::string > CcafeServiceFactoryContainer::getTypes() {
  ::std::map< ::std::string, ServicePortFactory* >::const_iterator pos;
  ::std::vector< ::std::string > v;
  for (pos = holder.begin(); pos != holder.end(); pos++) {
    v.push_back(pos->first);
  }
  return v;

}

  /** Copy the ServiceFactoryContainer argument into this Container. 
   * ignore duplicates.
   * All hell is gonna break loose at delete time with this implementation.
   */
void
CcafeServiceFactoryContainer::incorporate( ServiceFactoryContainer* container) {

  ::std::vector< ::std::string > v = container->getTypes();
  for (int i = v.size() -1; i >= 0; i--) {
      ServicePortFactory* f = container->getServicePortFactory(v[i].c_str());
      if(f != 0) {
	addServicePortFactory(f);
      }
  }
}

