#ifndef RowEquationSolver_h_seen
#define RowEquationSolver_h_seen

/** Simplistic interface to equation solvers. */
class RowEquationSolver : public virtual classic::gov::cca::Port {

public:

  virtual ~RowEquationSolver() {}

  /** Run the solver, after setRHS and the setEquation loop are done. */
  virtual void solve()=0;

    /** This is a caching interface, it keeps the pointers given.
     To replace the rhs, first setVectors(0,0).
     This must be called before any setEquation calls.
     The system gets its distributed row geometry from the
     distribution of the rightside vector. */
  virtual int setVectors(ESI_Vector *x, ESI_Vector *rightside, ESI_Vector *residual)=0;

    /** This is a *copy* interface, it doesn't keep the pointers given.
     The row number and colIndices are indexed from 0, not 1.
     Equations can only be set after the vectors are set.
     If the system already has an equation for this row, the colindices
     must be the same but the coefficient values may be changed.
     If the equation given is off-processor or there is another error,
     we return 1 instead of 0.
     The RHS value for this equation should be stored in the
     previously set RHS vector before calling solve. */
  virtual int setEquation(int row, int rowLen, int *colIndices, double *coef)=0;
 
    /** Tells system there are no more equations coming. */
  virtual void equationsDone()=0;

    /** Updates the content of the x and residual vectors after solve.
     The caller is assumed to have the pointers -- this function
     accesses and updates the cached vector pointers.
    /// Return has values:
    /// -2: system never solved.
    /// -1: permanent failure of solution algorithm.
    /// 0: possible to continue iterating.
    /// 1: solution within tolerance reached. */
  virtual int getVectors()=0;

};
#endif //RowEquationSolver_h_seen
