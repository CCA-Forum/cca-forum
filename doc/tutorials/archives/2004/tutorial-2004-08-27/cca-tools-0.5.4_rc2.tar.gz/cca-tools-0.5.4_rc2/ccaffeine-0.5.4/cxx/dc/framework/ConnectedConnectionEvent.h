#ifndef __ConnectedConnectionEvent_h_seen__
#define __ConnectedConnectionEvent_h_seen__
/** Event delivered after a new connection has been made. */
class ConnectedConnectionEvent : public virtual classic::gov::cca::ConnectionEvent {

private:
  ::ccafeopq::PortInfo *pi;
  bool killpi;
  classic::gov::cca::PortInfo *cpi;
  ::ccafeopq::TypeMap_shared ctm;

public:
  ConnectedConnectionEvent( UserPortData & upd);
  ConnectedConnectionEvent( ProviderPortData & ppd);
  virtual ~ConnectedConnectionEvent();
  
  /** True if the event informs a connection. (always) */
  virtual int connected();
  
  /** True if the event informs a disconnection (never) */
  virtual int disconnected();
  
  /** Get the PortInfo of the affected Port. */
  virtual classic::gov::cca::PortInfo *getPortInfo();

  virtual void * getOpqTypeMapSharedPtrAddress();
  
};
#endif // __ConnectedConnectionEvent_h_seen__

