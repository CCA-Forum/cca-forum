#ifndef __SERVICEFACTORYCONTAINER_H__
#define __SERVICEFACTORYCONTAINER_H__

/** nonstandard interface for running a hashmap of ServiceFactory's,
 * which are nonstandard interface for constructors. DEPRECATED.
 */
class ServiceFactoryContainer : public virtual ServiceFactory {
 public:

  virtual ~ServiceFactoryContainer(){}

  /** Add a service to the table. 
   * @param factory will be deleted with container, unless removed 
   * first. */
  virtual ServicePortFactory * 
    addServicePortFactory(ServicePortFactory* factory) = 0;

  /** Remove a service from the table. This class
   * just forgets it, doesn't delete it. */
  virtual ServicePortFactory * removeServicePortFactory( ServicePortFactory * factory) = 0;

  /** Get the underlying factory that has this type. */
  virtual ServicePortFactory* getServicePortFactory(const char * SvcPortType) = 0;

  /** Get all of the ServicePortTypes belonging to this factory. */
  virtual ::std::vector< ::std::string > getTypes() = 0;

  /** Copy the ServiceFactoryContainer argument into this Container. 
   * both containers end up holding pointers and those in
   * container should be removed, not left for delete when container
   * is deleted.
   */
  virtual void incorporate( ServiceFactoryContainer * container) = 0;

  /** Create a service by name. If the service does not exist, NULL is
      returned. */
  virtual ccafeopq::Port* createService(const char* serviceType) = 0;

};

#endif // __SERVICEFACTORYCONTAINER_H__
