#if 0
class GUIServiceAction : public virtual CmdAction {
 private:

  char* namelist[1];

 public:

  GUIServiceAction();

  virtual ~GUIServiceAction();

  /** Does the action, called with the CmdContext of the interpreter
   and with a vector that matches the signature given by argtype().
   The exit command returns 1; others return 0. */
  virtual int doIt(CmdContext *cc, JCPN(Vector) *args);

  /** Returns a string containing the description of this command. */
  virtual char *help();

  /** Describes the args Vector wanted by this Command.
   * <pre>
   * This is our hack to get around stupid varargs-lessness in java.
   * Each character indicates a separate user argument and its type.
   * Type checked user input:
   *   C --> class named by user.
   *   c --> optional class named by user.
   *   I --> instance named by user.
   *   i --> optional instance named by user.
   *   S --> string token from user.
   *   s --> optional string token from user.
   *   K --> long token from user.
   *   k --> optional long token from user.
   *   D --> int token from user.
   *   d --> optional int token from user.
   *   B --> bool token from user.
   *   b --> optional bool token from user.
   *   G --> double token from user.
   *   g --> optional double token from user.
   *   * --> repeat previous character ad infinitum. can only appear last. 
   * Special (cannot be followed directly by *):
   *   A --> all of the line after the command name token as a single string.
   *   a --> all of the line after the command name token as optional string.
   *   L --> the list of known CmdActions.
   *   P --> the command parser itself. 
   * </pre>
  */
  virtual char *argtype();

  /** name(s) of the function. Do not free them. on exit len is number
      of names. */
  virtual char ** names(int& len); 
};

/** Use scenario:
    registerUsesPort("GUIService",...);
    GUIService* GUIPort = dynamic_cast<GUIService*>(getPort("GUIService"));
    GUIPort->load("gov.sandia.sophia.PlottingBean http://x.sandia.gov/plotData.txt");
    // Put in code that deals with the plotting here
    // ...
*/

/** Component's eye view of the GUI world. */
class GUIService : 
#ifdef HAVE_NEO
public virtual neo::cca::Port,
#endif // HAVE_NEO
public virtual classic::gov::cca::Port
{
 private:
  CmdLineBuilderView* bv;
  char* strJoin(const char* str1, const char* str2);

 public:

  GUIService(BuilderController* bc, CmdLineBuilderView* bv);

  CONST Char* getGUIInfo();

  bool loadWidget(const char* widgetName);

};

#endif // 0
