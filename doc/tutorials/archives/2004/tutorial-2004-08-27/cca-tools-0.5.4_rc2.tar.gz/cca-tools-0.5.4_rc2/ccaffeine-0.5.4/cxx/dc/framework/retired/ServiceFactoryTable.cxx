#include <stdio.h>
#include <cca.h> // only for "cca/PortInfo.h" currently
#include <stdPorts.h>
#include "jc++/jc++.h"
#include "jc++/lang/jc++lang.h"
#include "jc++/util/jc++util.h"
#include "ServiceFactory.h"
#include "ServicePortFactory.h"
#include "CcafeServiceFactoryContainer.h"


CcafeServiceFactoryContainer::CcafeServiceFactoryContainer() {
  holder = new jcpp::StringHash();
}

CcafeServiceFactoryContainer::~CcafeServiceFactoryContainer() {
  jcpp::StringEnumeration* e = holder->keys();
  while(e->hasMoreElements()) {
    char* key = e->nextElement();
    jcpp::Object* o = holder->get(key);
    if(o != NULL) {
      delete o;
    }
  }
  delete e;
}

/** Add a service to the table. */
ServicePortFactory* 
CcafeServiceFactoryContainer::addServicePortFactory(CDELETE ServicePortFactory* factory) {
  jcpp::Object* o = holder->put(factory->getType(), factory);
  return dynamic_cast<ServicePortFactory*>(o);
}
/** Remove a service from the table.*/
ServicePortFactory* 
CcafeServiceFactoryContainer::removeServicePortFactory(ServicePortFactory* factory) {
  jcpp::Object* o = holder->remove(factory->getType());
  return dynamic_cast<ServicePortFactory*>(o);
}
/** Create a service by type. If the service does not exist, NULL is
    returned. */
OpaquePort* 
CcafeServiceFactoryContainer::createService(char* serviceType) {
  jcpp::Object* o = holder->get(serviceType);
  if(o == NULL) {
    return NULL;
  }
  ServicePortFactory* sf = dynamic_cast<ServicePortFactory*>(o);CHECKDC(sf);
  return sf->create();
}
