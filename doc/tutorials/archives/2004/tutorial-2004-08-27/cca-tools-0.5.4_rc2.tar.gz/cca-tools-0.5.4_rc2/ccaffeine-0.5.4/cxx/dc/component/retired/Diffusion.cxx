#include <stdlib.h>
#include "jc++/jc++.h"
#include "jc++/util/jc++util.h"
#include <cca.h>
#include "parameters/parametersStar.h"
#include "port/portInterfaces.h"
#include "port/supportInterfaces.h"
#include "dc/port/portStar.h"
#include "dc/component/Shape.h"

#include <mpi.h>
#include <ESI.h>
#include <snl-cpp.h>
#include <isis.h>

#include "Source.h"
#include "Diffusion.h"

// for debugging the dataholder ONLY. 
#include "dc/component/DataHolder.h"

// bit masks for debugging various code sections.
#define DBG_LAYOUT 1 // map layout info
#define DBG_DATA 2 // dataholder
#define DBG_GHOST 4 // overlap communications
#define DBG_BC 8 // random boundary condition

Diffusion::Diffusion() {
  numProcs = -1;
  myProc = -1;
  srandom(2718281);
  overlap = 1;
  isInitialized = FALSE;
  vizInitialized = FALSE;
  dxParam = new DoubleParameter("dxParam", "X Spacing", "Delta X", .00001, 
				.1, 100.);
  dyParam = new DoubleParameter("dyParam", "Y Spacing", "Delta Y", .00001, 
				.1, 100.);
  dtParam = new DoubleParameter("dtParam", "Time Step", "Delta T", .00001, 
				.1, 100.);
  timeParam = new DoubleParameter("timeParam", "Reciprocol Time Scale", 
				  "Admittance", 
				  .00001, .1, 1.);
  tEndParam = new DoubleParameter("tEndParam", "End Time", "End Time", 
				  .1, 50, 100000.);
  tBeginParam = new DoubleParameter("tBeginParam", "Begin Time", "Begin Time", 
				    .1, 1, 100000.);
  isRandom = new BoolParameter("isRandom", 
			       "Random Temperature Boundary Condition", 
			       "Random B.C.", 1);
  randDuration = new DoubleParameter("randDuration", 
				     "Random B.C. Max Duration in Time Steps", 
				     "Max. Duration", 1., 30., 5000.);
  randProbability = new DoubleParameter("randProbability", 
					"Random B.C. Prob. of Occurance", 
					"Occurance Prob.", .0, .008, 1.);
  randMaxTemp = new DoubleParameter("randMaxTemp", 
				    "Randomly Choosen Max. Temperature",
				    "Max. Temperature", 0., 1.e5, 1.e8);
  randMinTemp = new DoubleParameter("randMinTemp", 
				    "Randomly Choosen Min. Temperature",
				    "Min. Temperature", 0., 1., 1.e8);

  pp = new DefaultParameterPort();
  pp->setBatchTitle("Stencil Diffusion Configuration");
  pp->setGroupName("Physical Properties");
  pp->addRequest(timeParam);
  pp->addRequest(dxParam);
  pp->addRequest(dyParam);
  pp->setGroupName("Numerical Settings");
  pp->addRequest(dtParam);
  pp->addRequest(tEndParam);
  pp->addRequest(tBeginParam);
  pp->setGroupName("Random Boundary Cond. Settings");
  pp->addRequest(isRandom);
  pp->addRequest(randDuration);
  pp->addRequest(randProbability);
  pp->addRequest(randMaxTemp);
  pp->addRequest(randMinTemp);

  debug = DBG_LAYOUT; // this is the or (|) of what you want spew for.
  lbcSrc = 0;
  rbcSrc = 0;
  tbcSrc = 0;
  bbcSrc = 0;

  pfp = 0;
  svc = 0;
}

Diffusion::~Diffusion(){
//fixme
  pfp = 0;
  svc = 0;
}

void Diffusion::init() {
  // Initialize the state and deriv. for the diffusion.
  BlockPort* port = dynamic_cast<BlockPort*>(svc->getPort("DATA"));
  CHECKDC(port);
  port->getBlock(&block);
  if(debug & DBG_DATA) {
    DataHolder* dh = dynamic_cast<DataHolder*>(port);
    if(dh != 0) dh->setDebug(TRUE);
  }
  CCA_BlockDescription* d = block->getDescription();
  data = block->getData();
  int nDim = 0, bId;
  bId = d->getBlockId(); myProc = bId;
  CCA_dimenMap *dim = (CCA_dimenMap *)d->getDimensions(nDim);
  if(nDim != 2) {
    char* str = (char*)malloc(1024*sizeof(char));
    sprintf(str, ":-( Dimension of the problem = %d, we can only do 2", 
	    nDim);
    pfp->en(str);
    free(str);
    svc->releasePort("DATA");
    return;
  }
  beginCol = dim[1].gLow;
  endCol = dim[1].gHigh;
  beginRow = dim[0].gLow;
  endRow = dim[0].gHigh;
  offset = dim[0].beginPad*(endCol - beginCol);
  numCols = dim[1].gSize;
  numRows = dim[0].gSize;
  colLen = endCol - beginCol;
  if(debug & DBG_LAYOUT) {
    pfp->en("offset = %d", offset);
    pfp->en("beginRow = %d", beginRow);
    pfp->en("endRow = %d", endRow);
    pfp->en("beginCol = %d", beginCol);
    pfp->en("endCol = %d", endCol);
    pfp->en("data = 0x%x", data);
    pfp->en("blockId = %d", bId);
    for(int r = beginRow;r < endRow;r++) {
      for(int c = beginCol;c < endCol;c++) {
        if (debug & DBG_DATA) {
	  pfp->en("loading (%d, %d) total offset = %d", r, c, 
	         offset + (c - beginCol) + colLen*(r - beginRow));
        }
	*(data + offset + (c - beginCol) + colLen*(r - beginRow)) = 
	  (double)10000.*(double)bId + (double)100.*(double)r + (double)c;
      }
    }
    if (debug & DBG_DATA) {
      for(int r = beginRow - overlap;r < endRow + overlap;r++) {
        for(int c = beginCol;c < endCol;c++) {
          pfp->en("data(%d,%d) = %g", r, c,  
	           *(data + offset + (c - beginCol) + colLen*(r - beginRow)));
        }
      }
    }
  }
  port->update();
  if(debug & DBG_DATA) {
    pfp->en("\n\nAfter Update:\n\n");
    for(int r = beginRow - overlap;r < endRow + overlap;r++) {
      for(int c = beginCol;c < endCol;c++) {
	pfp->en("data(%d,%d) = %g", r, c,  
	       *(data + offset + (c - beginCol) + colLen*(r - beginRow)));
      }
    }
  }
  svc->releasePort("DATA");
    
  dx = dxParam->value;
  dy = dyParam->value;
  dt = dtParam->value;
  alpha = (0.25*(dx*dx + 2*dx*dy + dy*dy))/timeParam->value;
  tEnd = tEndParam->value;
  isInitialized = TRUE;
  initViz();
  Port* prt = svc->getPort("VIZ");
  if(prt != 0) {
    Cartesian2Port* c2;
    c2 = dynamic_cast<Cartesian2Port *>(prt); CHECKDC(c2);
    c2->visualize();
    svc->releasePort("VIZ");
  }
}

/** Implements GoPort interface. */
int Diffusion::go() {
  stateCompute(); // Sets up the overlap radius.
  init();
  for(t = 0.;t < tEnd;t += dt) {
    BlockPort* port = dynamic_cast<BlockPort*>(svc->getPort("DATA"));
    CHECKDC(port);
    if(debug) {
      printGrid();
    }
    port->update();
    if(debug) {
      printGrid();
    }
    derivCompute();
    svc->releasePort("DATA");
    Port* prt = svc->getPort("VIZ");
    if(prt != 0) {
      Cartesian2Port* c2;
      c2 = dynamic_cast<Cartesian2Port *>(prt); CHECKDC(c2);
      c2->visualize();
      svc->releasePort("VIZ");
    }
  }
  if(debug) {
    printGrid();
  }
  return 0;
}

void Diffusion::setServices(Services* svc) {
  this->svc = svc;

  // Contact the PrintfService
  PortInfo* pinfo = svc->createPortInfo("pSvc", "gov.cca.PrintfService", 0);
  svc->registerUsesPort(pinfo);
  pfp = dynamic_cast<PrintfPort*>(svc->getPort("pSvc"));
  CHECKDC(pfp);
  if(pfp == 0) {
    svc->addProvidesPort(this, svc->createPortInfo("DEAD=NoPrintf", "GoPort", 0));
    printf("!!! No PrintfService available from framework.");
    return;
  }

  svc->registerUsesPort( svc->createPortInfo("DATA", "BlockPort", 0));
  svc->addProvidesPort(this, svc->createPortInfo("GO", "GoPort", 0));
  svc->addProvidesPort(pp, svc->createPortInfo("CONFIG", "ParameterPort", 0));
  svc->registerUsesPort(svc->createPortInfo("VIZ", "Cartesian2Port", 0));
}

/** This means create the first state, i.e. initialize. */
void Diffusion::stateCompute() {
  if(isInitialized) return;
  BlockPort* port = dynamic_cast<BlockPort*>(svc->getPort("DATA"));
  CHECKDC(port);

  port->setOverlapUniform(overlap, &block);
    
  svc->releasePort("DATA");
}

void Diffusion::stateUpdate() {
//do nothing
}

void Diffusion::initViz() {
  esi_msg msg; esi_int err;
  int blocksize;
  pfp->en(" Diffusion::initViz() entry ...");
  if (!vizInitialized) { // first call
    SNL_Map *xmap = new SNL_Map();
    SNL_Map *ymap = new SNL_Map();
    SNL_Map *fmap = new SNL_Map();
    ESI_MapAlgebraic *ema;
    err = 0;
#ifdef ONE_PROC_ONLY
    assert(myProc == 0);
    if(debug&DBG_LAYOUT) {
      pfp->en("Setting serial maps:");
      pfp->en("numCols: %d, numRows: %d, beginCol: %d, endCol: %d, beginRow: %d endRow: %d", numCols, numRows, beginCol, endCol, beginRow, endRow);
    }
    //xmap->setGlobalSize(numCols, msg);
    //ymap->setGlobalSize(numRows, msg);
    //fmap->setGlobalSize(numRows*numCols, msg);
    err += xmap->setLocalInfo(numCols, 0, msg);
    err += ymap->setLocalInfo(numRows, 0, msg);
    blocksize = numCols*numRows;
    err += fmap->setLocalInfo(blocksize, 0, msg);
#else
    if(debug&DBG_LAYOUT) {
      pfp->en("Setting parallel maps:");
      pfp->en("numCols: %d, numRows: %d, beginCol: %d, endCol: %d, beginRow: %d endRow: %d", numCols, numRows, beginCol, endCol, beginRow, endRow);
    }
    // cant set both global and local
    //xmap->setGlobalSize(numCols, msg);
    //ymap->setGlobalSize(numRows, msg);
    //fmap->setGlobalSize(numRows*numCols, msg);
    err += xmap->setLocalInfo(endCol - beginCol, beginCol, msg); // calc'd in init()
    err += ymap->setLocalInfo(endRow - beginRow, beginRow, msg); // calc'd in init()
    blocksize = (endCol - beginCol)*(endRow - beginRow);
    err += fmap->setLocalInfo(blocksize, numCols*beginRow, msg); // size;offset
#endif // ONE_PROC_ONLY

    if (err != 0) {
        pfp->en(" Diffusion::initViz() map bogosity ...");
	delete xmap;
	delete ymap;
	delete fmap;
	fmap = xmap = ymap = 0;
        return;
    }

    esi_int eerr;
    xmap->getInterface("ESI_MapAlgebraic",((void **)(&ema)),msg);
    if (!ema) {
        pfp->en(" Diffusion::initViz() x mapAlgebraic bogosity ...{%s}",msg);
    }
    ISIS_JCPN(Vector)* Xaxis = new ISIS_JCPN(Vector)(*ema,eerr,msg);
    if (eerr < 0 || Xaxis == 0) {
        pfp->en(" Diffusion::initViz() Xaxis create bogosity {%s}",msg);
    }
    ymap->getInterface("ESI_MapAlgebraic",((void **)(&ema)),msg);
    if (!ema) {
        pfp->en(" Diffusion::initViz() y mapAlgebraic bogosity ...{%s}",msg);
    }
    ISIS_JCPN(Vector)* Yaxis = new ISIS_JCPN(Vector)(*ema,eerr,msg);
    if (eerr < 0 || Yaxis == 0) {
        pfp->en(" Diffusion::initViz() Yaxis create bogosity {%s}",msg);
    }


    //esi_JCPN(Vector)_cca* T = new esi_JCPN(Vector)_cca(fmap, data + offset, (endCol - beginCol)*(endRow - beginRow)); 
    fmap->getInterface("ESI_MapAlgebraic",((void **)(&ema)),msg);
    if (!ema) {
        pfp->en(" Diffusion::initViz() f mapAlgebraic bogosity ...{%s}",msg);
    }
    ISIS_JCPN(Vector)* T = new ISIS_JCPN(Vector)(*ema,eerr,msg);
    if (eerr < 0 || Yaxis == 0) {
        pfp->en(" Diffusion::initViz() T create bogosity {%s}",msg);
    }

    ESI_JCPN(Vector)ReplaceAccess *Tra;
    T->getInterface("ESI_JCPN(Vector)ReplaceAccess",((void **)(&Tra)),msg);
    assert(Tra != 0);
    Tra->setArrayPointer(data+offset,&blocksize,msg);

    //      Q = new esi_JCPN(Vector)_cca(fmap); 

    // call cartesian2port to set up viz.
    Port* prt = svc->getPort("VIZ");
    if(prt != 0) {
      Cartesian2Port *c2;
      c2 = dynamic_cast<Cartesian2Port*>(prt); CHECKDC(c2);

      c2->setXAxis(Yaxis); // flip the rendering axes
      c2->setYAxis(Xaxis); // flip the rendering axes
      c2->setField(T,"temperature",0);
      //      c2->setField(Q,"heat flux",1);
      if(debug) {
        pfp->en("Diffusion cartesian2port filled.");
      }
      svc->releasePort("VIZ");
      if(debug) {
        pfp->en("Diffusion cartesian2port released.");
      }
      vizInitialized = TRUE;
      return;
    }
  }
}
  

CDELETE Source* Diffusion::randomSource() {
  double prob = .008; // probability of event.
  double max = 100.;
  
  double rx = (random() % 1000) * 0.1;
  double rndm = rx/max;
  double maxDuration = 30.*dt;
  // duration <= 0 means no event.
  double duration = (prob - rndm)*maxDuration/prob;
  if(debug&DBG_BC) {
    pfp->en("duration: %g rndm: %g max: %g rx %g", duration, rndm, max, rx);
  }
  double maxTemperatureSrc = 100000.;
  double minTemperatureSrc = 0.;
      
  rx = (random() % 10000) * 0.01;
  rndm = rx/max;
  double temperature = (maxTemperatureSrc - minTemperatureSrc)*rndm + 
    minTemperatureSrc;
  Source* src = new Source();
  src->temperature = temperature;
  src->duration = duration;
  return src;
}

boolean Diffusion::computeRandBC(double* Uptr, Source** srcPtr, int i, int begin) {
  Source* rs = randomSource();
  double U = 0;
  Source* lbcSrc = *srcPtr;
    
  if((rs->duration > 0) && (lbcSrc == 0)) {
    lbcSrc = rs;
  } else {
    delete rs;
  }
  if(lbcSrc != 0) {
    U = lbcSrc->temperature;
    if(i == begin) {
      lbcSrc->duration -= dt;
    }
    if(debug&DBG_BC) {
      pfp->en("Event for LBC: U = %g, lbcSrc = 0x%x, duration = %g, r = %d", 
	     U, lbcSrc, lbcSrc->duration, i);
    }
    if(lbcSrc->duration < 0) {
      delete lbcSrc;
      lbcSrc = 0;
    } 
    *Uptr = U;
    *srcPtr = lbcSrc;
    return TRUE;
  } else {
    *srcPtr = lbcSrc;
    return FALSE;
  }
}

// Correct for the fact that the Y direction in viz space is backwards.
#define Y_DIRECTION_CORRECTION 1.0
#define DATA(r,c) data[offset + ((c) - beginCol) + colLen*((r) - beginRow)]

void Diffusion::derivCompute() {
  BlockPort* port = dynamic_cast<BlockPort*>(svc->getPort("DATA"));
  port->getBlock(&block);
  data = block->getData();
    
  if(!isInitialized) {
    init();
  }
    
  double U;
  double Uym1;
  double Uyp1;
  double Uxm1;
  double Uxp1;
  double Utp1;

  boolean noCompute = FALSE;
  if(noCompute){}
  else {
    for(int r = beginRow;r < endRow;r++) {
      for(int c = beginCol;c < endCol;c++) {
	if(c == 0) { //Left BC
	  boolean isEvent = computeRandBC(&U, &lbcSrc, r, beginRow);
	  if(!isEvent) {
	    // Insulate
	    U = DATA(r,c);
	    Uxp1 = DATA(r, c + 1);
	    U = Uxp1;
	  }
	  DATA(r, c) = U;
	} else if(c == (numCols - 1)) { //Right BC
	  if(FALSE) {
	    ;
	  } else {
	    //Insulate
	    U = DATA(r, c);
	    Uxm1 = DATA(r, c - 1);
	    U = Uxm1;
	  }
	  DATA(r, c) = U;
	} else if(r == 0) {//Top BC
	  boolean isEvent = computeRandBC(&U, &tbcSrc, c, beginCol + 1);
	  if(!isEvent) {
	    U = DATA(r, c);
	    Uyp1 = DATA(r + 1, c);
	    U = Uyp1;
	  }
	  DATA(r, c) = U;
	}else if(r == (numRows - 1)) { // Bottom BC
	  if(FALSE) {
	    ;
	  } else {
	    U = DATA(r, c);
	    Uym1 = DATA(r - 1, c);
	    U = Uym1;
	  }
	  DATA(r, c) = U;
	} else { // Middle somewhere
	  U = DATA(r, c);
	  Uym1 = DATA(r - 1, c);
	  Uyp1 = DATA(r + 1, c);
	  Uxm1 = DATA(r, c - 1);
	  Uxp1 = DATA(r, c + 1);
	  // 	Utp1 = alpha*dt*(
	  // 			 ((Uxp1 - U)/dx - (U - Uxm1)/dx)/dx +
	  // 			 Y_DIRECTION_CORRECTION*
	  // 			 (((Uyp1 - U)/dy - (U - Uym1))/dy)/dy
	  // 			 ) + U;
	  double eps = timeParam->value;
	  if(debug&DBG_BC) {
	    pfp->en("eps %g,Uxm1 %g,Uxp1 %g,U %g", eps, Uxm1, Uxp1, U);
	  }
	  //Utp1 = (eps*(Uxm1+Uxp1) + (2.0 - 2*eps)*U)/2.0;
	  Utp1 = (eps*(Uxm1 + Uxp1 + Uym1 + Uyp1) + (4.0 - 4*eps)*U)/4.0;
	  DATA(r, c) = Utp1;
	}
      }
    }
  }
  svc->releasePort("DATA");
}

void Diffusion::printGrid() {
  BlockPort* port = dynamic_cast<BlockPort*>(svc->getPort("DATA"));
  port->getBlock(&block);
  data = block->getData();
  pfp->en("Printing the grid from row = %d to %d", beginRow, endRow);
  for(int r = beginRow;r < endRow;r++) {
    for(int c = beginCol;c < endCol;c++) {
      pfp->e("%g\t", DATA(r, c));
    }
    pfp->en("");
  }
  svc->releasePort("DATA");
}

void Diffusion::derivUpdate() {
//do nothing
}
