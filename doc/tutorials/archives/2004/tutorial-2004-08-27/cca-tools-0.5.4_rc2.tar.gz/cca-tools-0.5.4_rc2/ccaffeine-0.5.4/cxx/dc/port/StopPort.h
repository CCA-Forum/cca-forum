/** StopPort for use in interrupting loops gracefully.
    @author Ben Allan, 9/30/1999, Sandia National Laboratories.
    @version $Id: StopPort.h,v 1.6 2002/12/19 20:20:51 baallan Exp $
 */
class StopPort : public virtual classic::gov::cca::Port {
public:
  /** Returns 0 if no interrupt is set, OTHERWISE returns interrupt value. */
  virtual int get() =0;
  /** Set 0 to clear interrupt. */
  virtual void setInterrupt(int interrupt) =0;
};

