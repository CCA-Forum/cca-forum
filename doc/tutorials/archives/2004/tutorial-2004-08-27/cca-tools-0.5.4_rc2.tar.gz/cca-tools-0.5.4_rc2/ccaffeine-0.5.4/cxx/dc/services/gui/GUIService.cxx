#ifndef lint
static char id[]=
"$Id: GUIService.cxx,v 1.4 2004/02/17 18:53:37 baallan Exp $";
#endif


#include <unistd.h>
#include <stdio.h>
// For open():
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <cca.h> 
#include <stdPorts.h>

// this is just <getopt.h> under linux but we aren't linux always
// so include our own which is from the gnu distribution.
#include "gnu/getopt/getCCAFEopt.h" 

#include "jc++/jc++.h"
#include "jc++/util/jc++util.h"
#include "cmd/CmdContext.h"
#include "cmd/CmdAction.h"
#include "cmd/CmdParse.h"
#include "dc/user_iface/BuilderController.h"


#include "dc/framework/dc_fwkStar.h"
#include "dc/user_iface/BuilderView.h"
#include "dc/user_iface/BuilderModel.h"

#include "util/IO.h"

#include "dc/user_iface/CmdLineBuilderView.h"
#include "dc/user_iface/CmdLineBuilderViewForHuman.h"
#include "dc/user_iface/CmdLineBuilderViewForGUI.h"
#include "dc/user_iface/CmdLineBuilderViewMux.h"

#include "dc/user_iface/DefaultBuilderModel.h"
#include "dc/user_iface/ccacmd/CmdContextCCA.h"
#include "dc/user_iface/ccacmd/CmdActionCCA.h"


#include "dc/user_iface/CmdLineBuilderController2.h"
#include "dc/distributed/ProcessorInfo.h"
#include "dc/distributed/ClientServerSocket.h"

#include "dc/user_iface/CmdLineClient.h"

#include "util/freefree.h"

#include "stovepipe/stp.h"

#ifdef HAVE_NEO
#include <neocca.hh>
#endif // HAVE_NEO

#include "GUIService.h"


GUIServiceAction::GUIServiceAction() {
  namelist[0] = strdup("load");
}

GUIServiceAction::~GUIServiceAction(){
  free(namelist[0]);
}


/** Does the action, called with the CmdContext of the interpreter
    and with a vector that matches the signature given by argtype().
    The exit command returns 1; others return 0. */
int 
GUIServiceAction::doIt(CmdContext *cc, JCPN(Vector) *args) {
  IO::pn("GUIServiceAction::doIt: does nothing");
  return 0;
}

/** Returns a string containing the description of this command. */
char *
GUIServiceAction::help() {
  return "loaded <Java Class Name> \n this is only an acknowledgement\n";
}

/** Describes the args Vector wanted by this Command.
 * <pre>
 * This is our hack to get around stupid varargs-lessness in java.
 * Each character indicates a separate user argument and its type.
 * Type checked user input:
 *   C --> class named by user.
 *   c --> optional class named by user.
 *   I --> instance named by user.
 *   i --> optional instance named by user.
 *   S --> string token from user.
 *   s --> optional string token from user.
 *   K --> long token from user.
 *   k --> optional long token from user.
 *   D --> int token from user.
 *   d --> optional int token from user.
 *   B --> bool token from user.
 *   b --> optional bool token from user.
 *   G --> double token from user.
 *   g --> optional double token from user.
 *   * --> repeat previous character ad infinitum. can only appear last. 
 * Special (cannot be followed directly by *):
 *   A --> all of the line after the command name token as a single string.
 *   a --> all of the line after the command name token as optional string.
 *   L --> the list of known CmdActions.
 *   P --> the command parser itself. 
 * </pre>
 */
char *GUIServiceAction::argtype() {
  return "S";
}

/** name(s) of the function. Do not free them. on exit len is number of names. */
char ** 
GUIServiceAction::names(int& len) {
  len = 1;
  return namelist;
}


GUIService::GUIService(BuilderController* bc, CmdLineBuilderView* bv) {
  bc->addAction(new GUIServiceAction());
  this->bv = bv;
}

const char* 
GUIService::getGUIInfo() {
  return "Ccaffeine Java GUI";
}

bool 
GUIService::loadWidget(const char* widgetName) {
  char* cmd = strJoin("load ", widgetName);
  bv->pn(cmd);
  free(cmd);
  return true;
}

CFREE char* 
GUIService::strJoin(const char* str1, const char* str2) {
  int siz = strlen(str1) + strlen(str2) + 1;
  char* ret = (char*)malloc(siz*sizeof(char));
  strcpy(ret, str1);
  strcat(ret, str2);
  return ret;
}


