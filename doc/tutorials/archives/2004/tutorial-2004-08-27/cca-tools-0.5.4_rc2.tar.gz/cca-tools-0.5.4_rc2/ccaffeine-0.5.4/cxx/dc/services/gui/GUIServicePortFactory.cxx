#ifndef lint
static char id[]=
"$Id: GUIServicePortFactory.cxx,v 1.4 2004/02/17 18:53:37 baallan Exp $";
#endif


#include <unistd.h>
#include <stdio.h>
// For open():
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <cca.h> 
#include <stdPorts.h>

// this is just <getopt.h> under linux but we aren't linux always
// so include our own which is from the gnu distribution.
#include "gnu/getopt/getCCAFEopt.h" 

#include "jc++/jc++.h"
#include "jc++/util/jc++util.h"
#include "cmd/CmdContext.h"
#include "cmd/CmdAction.h"
#include "cmd/CmdParse.h"
#include "dc/user_iface/BuilderController.h"


#include "dc/framework/dc_fwkStar.h"
#include "dc/user_iface/BuilderView.h"
#include "dc/user_iface/BuilderModel.h"

#include "util/IO.h"

#include "dc/user_iface/CmdLineBuilderView.h"
#include "dc/user_iface/CmdLineBuilderViewForHuman.h"
#include "dc/user_iface/CmdLineBuilderViewForGUI.h"
#include "dc/user_iface/CmdLineBuilderViewMux.h"

#include "dc/user_iface/DefaultBuilderModel.h"
#include "dc/user_iface/ccacmd/CmdContextCCA.h"
#include "dc/user_iface/ccacmd/CmdActionCCA.h"


#include "dc/user_iface/CmdLineBuilderController2.h"
#include "dc/distributed/ProcessorInfo.h"
#include "dc/distributed/ClientServerSocket.h"

#include "dc/user_iface/CmdLineClient.h"

#include "util/freefree.h"

#include "stovepipe/stp.h"

#include "GUIService.h"
#include "GUIServicePortFactory.h"

GUIServicePortFactory::GUIServicePortFactory(BuilderController* bc, 
					     CmdLineBuilderView* bv) {
  this->name = strdup("GUIService");
  this->bc = bc;
  this->bv = bv;
}

/** Return the name of the Service that this factory creates. */
const char* 
GUIServicePortFactory::getName() {
  return name;
}
/** Create the service. */
::ccafeopq::Port* GUIServicePortFactory::create() {
  GUIService * gs = new GUIService(bc, bv);
  ::ccafeopq::Port *op = new ccafeopq::Port(gs);
  return op;
}

