#ifndef __SERVICEFACTORY_H__
#define __SERVICEFACTORY_H__

class ServiceFactory {
 public:
  virtual ccafeopq::Port* createService(const char* serviceName) = 0;

};

#endif // __SERVICEFACTORY_H__
