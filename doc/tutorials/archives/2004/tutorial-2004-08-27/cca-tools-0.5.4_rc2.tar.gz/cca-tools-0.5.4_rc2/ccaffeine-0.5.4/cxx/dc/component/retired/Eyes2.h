#ifndef Eyes2_h_seen
#define Eyes2_h_seen

// requires
//#include "jc++/jc++.h"
//#include <ESI.h>
//#include <cca.h>
//#include "parameters/parametersStar.h"
//#include "port/portInterfaces.h"
//#include "dc/port/portStar.h"


class Eyes2 : public virtual classic::gov::cca::Component, public virtual Cartesian2Port {
             

private:
  ESI_Vector *x, *y;
  int *gub;
  int *glb;
  int *axisinfo;
  int *axisinfo2;
  int *axistype;
  int *arraydecl;
  char *fname[2];
  double *dataptr[2]; // hard wired # of fields. cart22port, maybe.
  ESI_Vector *field[2];
  int configured;
  boolean verbose;
  boolean debug;

  struct MPI_wrapper *mw;
  int rank,size;

  classic::gov::cca::Services *core;


public:

  Eyes2();
  ~Eyes2();

  virtual void setServices(classic::gov::cca::Services *cc);

  virtual int visualize();

  virtual void setXAxis(ESI_Vector *x);

  virtual void setYAxis(ESI_Vector *y);

  virtual void setField(ESI_Vector *data, char *name, int field_number);

  virtual void setTime(double * theta, char *name, int field_number); // not implemented
  void setDebug(boolean tf) {
    debug = tf;
  }
  void setVerbose(boolean tf) {
    verbose = tf;
  }

};
#endif //Eyes2_h_seen
