#include "dc/export/ccafeopq.hh"
#include "dc/framework/PropertiesHelper.h"

namespace {
char id[]=
"$Id: PropertiesHelper.cxx,v 1.3 2003/07/07 19:08:39 baallan Exp $";
} ENDSEMI

bool PropertiesHelper::inited = false;
