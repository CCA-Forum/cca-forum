#if 0
#ifndef __TYPEMAPPORTINFO_H__
#define __TYPEMAPPORTINFO_H__

/** Implements in the ccaffeine way the PortInfo interface. */
class TypeMapPortInfo : public classic::gov::cca::PortInfo {
  private:
  /** our names */
  CONST char* portname;
  CONST char* porttype;
  gov::cca::TypeMap tm;

  public:

  TypeMapPortInfo();

  /** Properties are terminated by a null entry for key and value */
  TypeMapPortInfo(CONST char* name, CONST char* type, gov::cca::TypeMap tm);

  /** A useful copy constructor from PortInfo. */
  TypeMapPortInfo(classic::gov::cca::PortInfo& pi);

  virtual ~TypeMapPortInfo();

  CONST char* getType();
  CONST char* getName();
  CONST char* getProperty(CONST char* key);

  void setType(const char* type);
  void setName(const char* name);

  const gov::cca::TypeMap getTypeMap();

  gov::cca::TypeMap cloneTypeMap();

  /** method unapproved and unproposed for standard. do not use except
      to debug.  @see ServicesHelper toStringPortInfo. */
  virtual CFREE char* toString();
};

#endif // __TYPEMAPPORTINFO_H__
#endif // 0
