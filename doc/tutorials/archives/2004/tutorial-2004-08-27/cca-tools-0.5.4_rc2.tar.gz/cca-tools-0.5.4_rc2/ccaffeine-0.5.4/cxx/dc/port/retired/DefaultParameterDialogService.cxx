#include <cca.h>
#include "dc/export/AllExport.hh"
#include "dc/framework/KernelPort.h"
#include "dc/port/DefaultParameterDialogService.h"
#include "dc/port/StringableParameterPort.h"
#include "util/TypeMap.h"

using ::std::vector;
using ::std::string;

// private impl stuff
namespace {

////////////////////////////////////////////////////////////
// misc typedefs 


typedef ::std::vector< string > StringVector;
typedef ::std::map< string, string > StringMap;
typedef ::std::map< string, void * > VoidPtrMap;
typedef StringVector::const_iterator SVCI;
// an empty vector for any typemap calls that need one
StringVector defaultVector; 

////////////////////////////////////////////////////////////
/*
 * The structure of the typemap data is as follows:
 * (where the stuff in all caps is actually larger
 *  strings defined below.)
 *
 * PORTNAME: The name of the parameter port that goes with this map.
 * TITLE: The name of the dialog, for UI purposes.
 * GROUPS: The names of the tabs w/in the dialog; if the
 * 	empty array, then there is just the main tab.
 * GROUPKEYS.{$group}: The sequence of the keys w/in the group.
 * {$key}: The default value per the user, until set.
 * {$key}.DEFAULT: The default value per the user.
 * {$key}.BOUNDS: For bounded values, 2 elem vector of bounds [lo,hi];
 *                For list values, n elem vector of choices.
 * {$key}.HELP: The long help string.
 * {$key}.PROMPT: The short prompt string.
 *
 * 
 */

string PORTNAME = "DPDS.Dialog.PortName";
string PUBPORTNAME = "ParameterDialogService.portName";
string TITLE = "DPDS.Dialog.Title";
string ALLKEYS = "DPDS.Dialog.AllKeys";
string GROUPS = "DPDS.Dialog.Group.List";
string CURGROUP = "DPDS.Dialog.Group.Current";
string GROUPKEYS = "DPDS.Dialog.Group.Keys.";
string DEFAULT = ".DPDS.Default";
string BOUNDS = ".DPDS.Bounds";
string HELP = ".DPDS.Help";
string PROMPT = ".DPDS.Prompt";

////////////////////////////////////////////////////////////
// private port implementation

class ParameterPort_Impl : public virtual classic::gov::cca::Port,
			public virtual ccafeopq::ParameterPort,
			public virtual StringableParameterPort,
			public virtual KernelPort
{
private:

	vector< ::ccafeopq::ParameterGetListener *> glv;
	vector< ::ccafeopq::ParameterSetListener *> slv;
	ccafeopq::TypeMap_shared portData;
	bool published;

public:
	ParameterPort_Impl( ccafeopq::TypeMap_shared data);
	~ParameterPort_Impl();

	virtual StringVector getMapNames();

	virtual ccafeopq::TypeMap_shared getConfiguration(const string & mapName );
	
	virtual void setConfiguration( const string & mapName, ::ccafeopq::TypeMap_shared tm);

	virtual std::string getConfigurationString( const std::string & prefix);
	virtual std::string getConfigurationString( const std::string & prefix, const std::string & key);
	virtual int setConfigurationString( const std::string & key, const std::string & value);

	void addSetListener( ::ccafeopq::ParameterSetListener * sl);
	void addGetListener( ::ccafeopq::ParameterGetListener * gl);
	void clearListeners();
	bool getPublished();
	void setPublished(bool tf);
	std::string toString( const std::string & prefix, ::ccafeopq::TypeMap_shared d, const std::string &key);

}; // end implementation ParameterPort_Impl

#define GSU ::gov::sandia::util::TypeMap

int ParameterPort_Impl::setConfigurationString( const std::string & key, const std::string & value)
{
	// fixme setConfigurationString
	if (!portData) { return -1; }
	std::string kts = GSU::stringType(portData, key);
	int err;
        err = 
	GSU::putValueByStrings(portData, key, kts, value);
        return err;
}

void ParameterPort_Impl::setConfiguration(const string & mapName, ::ccafeopq::TypeMap_shared tm )
{
	if (!portData || !tm ) {
		return;
	}
	string n = portData->getString(PORTNAME,"");
	if (!( n == mapName)) {
		return;
	}
	StringVector targets = portData->getStringArray(ALLKEYS,defaultVector);
	StringVector changedKeys = 
		GSU::copyInKeysTell(tm, portData, targets);
	for (size_t j = slv.size(); j > 0; j--)
	{
		::ccafeopq::ParameterSetListener * sl;
		sl = slv[j-1];
		for (size_t i = 0; i < changedKeys.size(); i++)
		{
			sl->updatedParameterValue(mapName, changedKeys[i]);
		}
	}
	
}

ccafeopq::TypeMap_shared ParameterPort_Impl::getConfiguration(const string & mapName )
{
	ccafeopq::TypeMap_shared res;
	if (! portData) {
		return res;
	}
	string n = portData->getString(PORTNAME,"");
	if (!( n == mapName)) {
		return res;
	}
	for (size_t j = glv.size(); j > 0; j--)
	{
		::ccafeopq::ParameterGetListener * gl;
		gl = glv[j-1];
		gl->updateParameterPort(mapName);
	}
	return portData->cloneTypeMap();
	
}

std::string ParameterPort_Impl::getConfigurationString( const std::string & prefix, const std::string & key)
{
	if (! portData) {
		std::string sb = "!DEAD ParameterPort_Impl";
		return sb;
	}
	string n = portData->getString(PORTNAME,"");
	for (size_t j = glv.size(); j > 0; j--)
	{
		::ccafeopq::ParameterGetListener * gl;
		gl = glv[j-1];
		gl->updateParameterPort(n);
	}

	string sb;
	if ( portData->hasKey(key) ) {
		enum ccafeopq::Type kt = portData->typeOf(key);
		switch (kt)
		{
		case ccafeopq::Bool:
		case ccafeopq::Long:
		case ccafeopq::Int:
		case ccafeopq::Double:
		case ccafeopq::Float:
		case ccafeopq::String:
			sb += toString(prefix,portData,key);
			break;
		default:
			break;
		}
	}
	return sb;
}

std::string ParameterPort_Impl::getConfigurationString(const string & prefix)
{
	if (! portData) {
		std::string sb = "!DEAD ParameterPort_Impl";
		return sb;
	}
	string n = portData->getString(PORTNAME,"");
	for (size_t j = glv.size(); j > 0; j--)
	{
		::ccafeopq::ParameterGetListener * gl;
		gl = glv[j-1];
		gl->updateParameterPort(n);
	}
	std::string sb = "newParamDialog ";
	sb += prefix;
       	sb += " "; 
	string title = portData->getString(TITLE, "");
	sb += title;
       	sb += "\n";
	vector< string  > groups = portData->getStringArray(GROUPS, defaultVector);

	// for all tabs
	for (size_t i = 0; i < groups.size(); i++)
	{
		string gkey = GROUPKEYS;
		gkey += groups[i];
		vector< string  > keys = portData->getStringArray(gkey, defaultVector);
		sb += "newParamTab ";
		sb += prefix;
		sb += " ";
		sb += groups[i];
		sb += "\n";
		for (size_t j = 0; j < keys.size(); j++)
		{
			sb += toString(prefix,portData,keys[j]);
		}
	}
	sb += "paramEndDialog ";
	sb += prefix;
	sb += "\n";
	return sb;
}

string typeToString(enum ::ccafeopq::Type t)
{
	switch(t) {
		case ::ccafeopq::Bool: return "BOOL";
		case ::ccafeopq::String: return "STRING";
		case ::ccafeopq::Long: return "LONG";
		case ::ccafeopq::Int: return "INT";
		case ::ccafeopq::Float: return "FLOAT";
		case ::ccafeopq::Double: return "DOUBLE";
		default:
		return "ERROR";
	}
}

std::string ParameterPort_Impl::toString( const std::string & prefix, ::ccafeopq::TypeMap_shared d, const std::string &key)
{
	string kp = prefix;
	kp += " ";
	kp += key;
	kp += " ";

	string helpkey = key;
	helpkey += HELP;
	string promptkey = key;
	promptkey += PROMPT;
	string defkey = key;
	defkey += DEFAULT;
	string boundkey = key;
	boundkey += BOUNDS;
	enum ccafeopq::Type kt;
	kt = d->typeOf(key);

	string s = "newParamField ";
	s += prefix;
	s += " ";
	s += typeToString(kt);
	s += " ";
	s += key;
	s += "\nparamCurrent ";
	s += kp;
	s += GSU::stringValue(d, key);
	s += "\nparamHelp ";
	s += kp;
	s += d->getString(helpkey,"");
	s += "\nparamPrompt ";
	s += kp;
	s += d->getString(promptkey,"");
	s += "\nparamDefault ";
	s += kp;
	s += GSU::stringValue(d, defkey);
	if (kt != ccafeopq::String && kt != ccafeopq::Bool)
	{
		s += "\nparamNumberRange ";
		s += kp;
		s += GSU::stringValue(d, boundkey);
	}
	if ( kt == ccafeopq::String )
	{
		vector< string > choices = d->getStringArray(boundkey, defaultVector);
		for (size_t i = 0 ;i < choices.size(); i++)
		{
 			s += "\nparamStringChoice ";
			s += kp;
			s += choices[i];
		}
	}
	s += "\n";
	return s;
}

void ParameterPort_Impl::clearListeners()
{
	for (size_t i = slv.size(); i > 0; i--)
	{
		vector< ::ccafeopq::ParameterSetListener * > snew;
		slv = snew;
	}
	for (size_t j = glv.size(); j > 0; j--)
	{
		vector< ::ccafeopq::ParameterGetListener * > gnew;
		glv = gnew;
	}
}

void ParameterPort_Impl::addSetListener( ::ccafeopq::ParameterSetListener * sl)
{
	for (size_t i = 0; i < slv.size(); i++)
	{
		if (slv[i] == sl) {
			return;
		}
	}
	slv.push_back(sl);
}

void ParameterPort_Impl::addGetListener( ::ccafeopq::ParameterGetListener * gl)
{
	for (size_t i = 0; i < glv.size(); i++)
	{
		if (glv[i] == gl) {
			return;
		}
	}
	glv.push_back(gl);
}

ParameterPort_Impl::ParameterPort_Impl( ::ccafeopq::TypeMap_shared d)
{
	portData = d;
	published = false;
}

ParameterPort_Impl::~ParameterPort_Impl()
{
}

StringVector ParameterPort_Impl::getMapNames()
{
	StringVector res;
	if (!portData) { return res; }
	string n = portData->getString(PORTNAME,"");
	if (n.size() != 0) {
		res.push_back(n);
	}
	return res;
}

bool ParameterPort_Impl::getPublished()
{
	return published;
}

void  ParameterPort_Impl::setPublished(bool tf)
{
	published = tf;
}

////////////////////////////////////////////////////////////

} // end namespace anonymous

////////////////////////////////////////////////////////////
// implementation macros that never leave this file.
////////////////////////////////////////////////////////////
/** insist that we have a port name */
#define VALID if (! portData->hasKey(PORTNAME) )  return

/** insist that we have a group name for all parameters.
* if there are none yet, add one with the title. */
#define VALIDGROUP \
	string G = portData->getString(CURGROUP,""); \
	string T = portData->getString(TITLE,""); \
	if (G.size() == 0) setGroupName(portData,T)

// check type against map data possibly already there.
#define VALIDTYPE(X) \
	if (	portData->typeOf(name) != ::ccafeopq::X && \
		portData->typeOf(name) != ::ccafeopq::None) return

// add to total list, if not there, or punt
// fixme whine redefinition
#define UNIQUEKEY \
	StringVector alist = portData->getStringArray(ALLKEYS, defaultVector); \
	if ( std::find(alist.begin(), alist.end(), name) != alist.end() ) \
	{ \
		return; \
	} \
	alist.push_back(name); \
	portData->putStringArray(ALLKEYS,alist)

#define SETKEY(X) \
	if ( !portData->hasKey(name) ) portData->put##X(name, deflt)

// add key to list for group
#define ADDTOGROUP \
	string gname = GROUPKEYS; \
	gname += portData->getString(CURGROUP,""); \
	StringVector glist = portData->getStringArray(gname, defaultVector); \
	glist.push_back(name); \
	portData->putStringArray(gname,glist)

// take care of default, help, prompt
#define SETATTR(X) \
	string tmp = name; \
	tmp += DEFAULT; \
	portData->put##X(tmp,deflt); \
	tmp = name; \
	tmp += HELP; \
	portData->putString(tmp,help); \
	tmp = name; \
	tmp += PROMPT; \
	portData->putString(tmp,prompt)

// take care of bounds on bounded types
// whine fixme deflt outside of bounds case,
// current out of bounds case.
#define SETBOUNDS(X, Y) \
	vector< X > bounds(2); \
	if (low > high) { \
		X sw = low; \
		low = high; \
		high = sw; \
	} \
	bounds[0] = low; \
	bounds[1] = high; \
	tmp = name; \
	tmp += BOUNDS; \
	portData->put##Y##Array(tmp,bounds)

#define PPI_DECL \
	string portName = portData->getString(PORTNAME,""); \
	void *vppi = delegates[portName]; \
	if (!vppi) { \
		return; \
	} \
	ParameterPort_Impl * ppi = static_cast<ParameterPort_Impl *>(vppi)

////////////////////////////////////////////////////////////
// begin interface DefaultParameterDialogService

/** Due to the scoping issue involved in creating
* delegated ports with specific names, it is easier
* to organize this code as one service instance
* per using component instance. It could also
* be organized as a global service running a table
* of typemaps with keys which are componentname+keyname.
* Memory management is also easier for the PDS
* if we associate 1:1; once the component is
* dead, we know we can blow away any stateful service
* such as this that it may have left behind.
*/
DefaultParameterDialogService::DefaultParameterDialogService()
{
}

DefaultParameterDialogService::~DefaultParameterDialogService()
{
	VoidPtrMap::iterator vi;
	for (vi = delegates.begin(); vi != delegates.end(); ++vi)
	{
		void * vppi = vi->second;
		ParameterPort_Impl * ppi = static_cast<ParameterPort_Impl *>(vppi);
		if (ppi->getPublished()) {
		// whine. fixme
		// something is now gonna be leaked, because
		// remove wasn't done before the component
		// was destroyed.
		// This leak is better than having someone
		// call on a dead pointer, which potentially
		// is the alternative.
		} else {
	  		delete ppi;
		}
		delegates[vi->first] = 0;
	}
}


/** Initialize the portData for use as a parameter dialog port
*  with name portName.
*  More than one such port can be defined.
*  The given string portName will appear in the  ::ccafeopq::TypeMap_shared
*  as the result of this function and must not be changed
*  by the component henceforth. It will appear under the key
*  "ParameterDialogService.portName",
*  @param portData the typemap associated with the port;
*       It is shared between the ParameterDialogService
*       and the component. The ParameterDialogService will
*       not read or change values in portData except those
*       requested via the addRequest functions.
*  @param portName The name of a ParameterPort to appear in
*       user interface one way or another.
*  
**/
void DefaultParameterDialogService::createParameterPort(
			::ccafeopq::TypeMap_shared portData, 
			const string & portName)
{
	if (!portData) { return; }

	if ( delegates.find(portName) != delegates.end() )
	{
		return; // really whine fixme
	}

	ParameterPort_Impl * ppi = new ParameterPort_Impl(portData);
	void * vppi = 0;
	vppi = static_cast< void *>(ppi);
	delegates[portName] = vppi;

	if (portData->hasKey(PORTNAME) )
	{
		return; // should whine fixme
	}
	portData->putString(PORTNAME, portName);
	portData->putString(PUBPORTNAME, portName);
	portData->putString(TITLE, portName);
}


/** Define the window title for the parameter dialog.
**/
void DefaultParameterDialogService::setBatchTitle(
	       			::ccafeopq::TypeMap_shared portData, 
				const string & title)
{
	if (!portData) { return; }
	VALID;
	if (portData->hasKey(TITLE) )
	{
		portData->remove(TITLE);
	}
	portData->putString(TITLE, title);
}


/** Define the next tab/group title to use. All
 * addRequest subsequent calls will add to this group.
 * Multiple dialog tabs/groups can be defined in this way.
 */
void DefaultParameterDialogService::setGroupName( 
				::ccafeopq::TypeMap_shared portData, 
				const string & newGroupName)
{

	if (!portData) { return; }
	VALID;
	StringVector sv = portData->getStringArray(GROUPS,defaultVector);
	if ( std::find(sv.begin(), sv.end(), newGroupName) != sv.end() )
	{
		return;
	}
	sv.push_back(newGroupName);
	portData->putStringArray(GROUPS,sv);
	portData->putString(CURGROUP, newGroupName);

}


/** Define a boolean parameter and its default state.
 * The configured value is always available by
 * portData->getBool(name, ...)
 */
void DefaultParameterDialogService::addRequestBoolean( 
				::ccafeopq::TypeMap_shared portData,
				const string & name, 
				const string & help,
				const string & prompt,
				bool deflt)
{

	if (!portData) { return; }

	VALID;
	VALIDGROUP;
	VALIDTYPE(Bool); // fixme whine mismatch
	UNIQUEKEY;
	SETKEY(Bool);
	ADDTOGROUP;
	SETATTR(Bool);

}

/** Define a int parameter and its default state.
 * The configured value is always available by
 * portData->getInt(name, ...) and it will be
 * in the range [low, high].
 */
void DefaultParameterDialogService::addRequestInt( 
				::ccafeopq::TypeMap_shared portData,
				const string & name, 
				const string & help,
				const string & prompt,
				int deflt,
				int low,
				int high)
{
	if (!portData) { return; }
	VALID;
	VALIDGROUP;
	VALIDTYPE(Int); // fixme whine mismatch
	UNIQUEKEY;
	SETKEY(Int);
	ADDTOGROUP;
	SETATTR(Int);
	SETBOUNDS(int32_t, Int);
}

/** Define a long parameter and its default state.
 * The configured value is always available by
 * portData->getLong(name, ...) and it will be
 * in the range [low, high].
 */
void DefaultParameterDialogService::addRequestLong(
	       			::ccafeopq::TypeMap_shared portData,
				const string & name, 
				const string & help,
				const string & prompt,
				int64_t deflt,
				int64_t low,
				int64_t high)
{
	if (!portData) { return; }
	VALID;
	VALIDGROUP;
	VALIDTYPE(Long); // fixme whine mismatch
	UNIQUEKEY;
	SETKEY(Long);
	ADDTOGROUP;
	SETATTR(Long);
	SETBOUNDS(int64_t, Long);
}

/** Define a float parameter and its default state.
 * The configured value is always available by
 * portData->getFloat(name, ...) and it will be
 * in the range [low, high].
 */
void DefaultParameterDialogService::addRequestFloat(
	       			::ccafeopq::TypeMap_shared portData,
				const string & name, 
				const string & help,
				const string & prompt,
				float deflt,
				float low,
				float high)
{
	if (!portData) { return; }
	VALID;
	VALIDGROUP;
	VALIDTYPE(Float); // fixme whine mismatch
	UNIQUEKEY;
	SETKEY(Float);
	ADDTOGROUP;
	SETATTR(Float);
	SETBOUNDS(float, Float);
}

/** Define a double parameter and its default state.
 * The configured value is always available by
 * portData->getDouble(name, ...) and it will be
 * in the range [low, high].
 */
void DefaultParameterDialogService::addRequestDouble(
	       			::ccafeopq::TypeMap_shared portData,
				const string & name, 
				const string & help,
				const string & prompt,
				double deflt,
				double low,
				double high)
{
	if (!portData) { return; }
	VALID;
	VALIDGROUP;
	VALIDTYPE(Double); // fixme whine mismatch
	UNIQUEKEY;
	SETKEY(Double);
	ADDTOGROUP;
	SETATTR(Double);
	SETBOUNDS(double, Double);
}

/** Define a string parameter and its default state.
 * The configured value is always available by
 * portData->getString(name, ...).
 * If no addRequestStringChoice calls are made, the
 * user input may be any string. If addRequestStringChoice
 * is used, the value will be one among the choices.
 * If addRequestStringChoice is used, deflt must
 * be among the choices defined.
 */
void DefaultParameterDialogService::addRequestString(
	       			::ccafeopq::TypeMap_shared portData,
				const string & name, 
				const string & help,
				const string & prompt,
				const string & deflt)
{
	if (!portData) { return; }
	VALID;
	VALIDGROUP;
	VALIDTYPE(String); // fixme whine mismatch
	UNIQUEKEY;
	SETKEY(String);
	ADDTOGROUP;
	SETATTR(String);

	// init to empty
	StringVector bounds;
	tmp = name; 
	tmp += BOUNDS;
	portData->putStringArray(tmp,bounds);
}

/** define a new choice for a string parameter. */
void DefaultParameterDialogService::addRequestStringChoice(
	       		::ccafeopq::TypeMap_shared portData,
			const string & name,
		       	const string &choice)
{
	if (!portData) { return; }
	VALID;
	if (portData->typeOf(name) != ::ccafeopq::String) 
	{
		// fixme whine
		return;
	}
	string tmp = name; 
	tmp += BOUNDS;
	StringVector bounds =  portData->getStringArray(tmp,defaultVector); \
	if ( std::find(bounds.begin(), bounds.end(), choice) == bounds.end())
	{
		bounds.push_back(choice);
		portData->putStringArray(tmp,bounds);
	}
}

 /** Clear all previously added requests, titles, groups. After
  *  this call, it is as if the ParameterPort has
  *  been created but never configured. The values of
  *  previously defined parameters will, nonethesless,
  *  remain in the typemap.
  *  Typically, this is used only by someone implementing
  *  the updateParameterPort function from
   *  class ::ccafeopq::ParameterGetListener {
  */
void DefaultParameterDialogService::clearRequests(
	       		::ccafeopq::TypeMap_shared portData)
{
	if (!portData) { return; }
	VALID;
	portData->remove(TITLE);
	StringVector groups = portData->getStringArray(GROUPS,defaultVector);
	portData->remove(CURGROUP);
	portData->remove(GROUPS);
	size_t i;
	for ( i = 0; i < groups.size(); i++)
	{
		string gkey = GROUPKEYS;
		gkey += groups[i];
		portData->remove(gkey);
	}
	StringVector names =  portData->getStringArray(ALLKEYS,defaultVector);
	portData->remove(ALLKEYS);
	for (i = names.size() ; i > 0 ; i--)
	{
		string name = names[i-1];
		string tmp = name;
		tmp += DEFAULT;
		portData->remove(tmp);
		tmp = name;
		tmp += BOUNDS;
		portData->remove(tmp);
		tmp = name;
		tmp += HELP;
		portData->remove(tmp);
		tmp = name;
		tmp += PROMPT;
		portData->remove(tmp);
	}
	// fixme remove listeners
	PPI_DECL;
	ppi->clearListeners();
}

/** 
 * Register listener (the component) that wishes to have
 * a chance to change the contents of its ParameterPort
 * just before the parameters typemap is used to
 * render the parameter dialog.
 * @param powner a pointer to the listener that will be
 * forgotten when it is no longer needed. 
 */
void DefaultParameterDialogService::setUpdater(
			::ccafeopq::TypeMap_shared portData, 
			::ccafeopq::ParameterGetListener *powner)
{
	if (!portData) { return; }
	VALID;
	PPI_DECL;
	ppi->addGetListener(powner);
}

/** Register listener (the component) if it wishes to be
 * informed when an parameter is set.
 * Listeners are called after values are set.
 */
void DefaultParameterDialogService::setUpdatedListener( 
			::ccafeopq::TypeMap_shared portData,
			::ccafeopq::ParameterSetListener *powner)
{
	if (!portData) { return; }
	VALID;
	PPI_DECL;
	ppi->addSetListener(powner);
}

/** Signal that the ParameterPort is fully defined and should
 * now pop out on the component. The  ::ccafeopq::Services passed here
 * must be the component's own  ::ccafeopq::Services handle.
 */
void DefaultParameterDialogService::publishParameterPort(
	       		::ccafeopq::TypeMap_shared portData,
		      	::ccafeopq::Services * svc)
{
	if (!portData) { return; }
	VALID;
	PPI_DECL;
	if ( ppi->getPublished() ) {
		return; // whine fixme
	}
	string ptype = "::ccafeopq::ParameterPort";
	string pname = portData->getString(PORTNAME,"");
	ccafeopq::Port * op = ppi;
	ccafeopq::TypeMap_shared nullprops;
	svc->addProvidesPort(op, pname, ptype, nullprops);
	ppi->setPublished(true);
}

/** Cause a previously defined parameter port to go away. */
void DefaultParameterDialogService::unpublishParameterPort(
	       		::ccafeopq::TypeMap_shared portData,
			::ccafeopq::Services * svc)
{
	if (!portData) { return; }
	VALID;
	PPI_DECL;
	if (!ppi->getPublished() ) {
		return; // whine fixme
	}
	string pname = portData->getString(PORTNAME,"");
	svc->removeProvidesPort(pname);
	ppi->setPublished(false);
}

// end interface DefaultParameterDialogService

/////////////////// test stuff ///////////////////////
#ifdef DefaultParameterDialogService_MAIN
#include "util/TypeMap.h"
typedef ::gov::sandia::util::TypeMap SMap;
#define GS ::gov::sandia::util::TypeMap
typedef ::ccafeopq::TypeMap_shared CMap;
using namespace std;
int main() {
	GS *s = new GS();
	CMap c(s);
	DefaultParameterDialogService d;
	d.createParameterPort(c, "CONFIG");
	d.createParameterPort(c, "CONFIG");
	d.setBatchTitle(c, "CONFIG title");
	d.setGroupName(c, "G1" );
	d.addRequestBoolean(c,"b1","Long b1 hlep", "short b1", true);
	d.addRequestBoolean(c,"b1","Long b1 hlep", "short b1b", true);
	d.addRequestInt(c,"i1","Long i1 hlep", "short i1", 3, 0, 10);
	d.setGroupName(c, "G2" );
	d.addRequestDouble(c,"d1","silly d1 help", "short d1", 4, 0, 10);
	d.setGroupName(c, "G3" );
	d.addRequestString(c,"s1","silly s1 help", "short s1", "default s1 value");
	d.addRequestString(c,"s2","silly s2 help", "short s2", "default s2 value");
	d.addRequestStringChoice(c, "s2", "banana");
	d.addRequestStringChoice(c, "s2", "pear");
	d.addRequestStringChoice(c, "s2", "banana");
	GS::dump(c);
	d.clearRequests(c);
	cout << "   all cleared" << endl;
	GS::dump(c);

}
#endif // DefaultParameterDialogService_MAIN
