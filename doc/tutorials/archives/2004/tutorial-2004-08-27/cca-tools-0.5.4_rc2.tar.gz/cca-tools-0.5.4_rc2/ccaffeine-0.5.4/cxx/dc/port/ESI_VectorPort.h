#ifndef _esi_VectorPort_h_
#define _esi_VectorPort_h_

/** Near OBSOLETE. DO NOT USE anew.
     Partial interface of ESI_Vector.
 */
class ESI_VectorPort  : {
  public:

  
    ~ESI_VectorPort();

      /** Returns length of the local data array returned from acces functions,
       and returns the offset from the beginning of the global array at
       which the local array starts. */
    void getLocalInfo(int& localLength, int& localOffset);

    /** scaling:
     y <- y*scalar */
    intErrorCode scale(double scalar);

    /** norm(y) of various types */
    double norm1();
    double norm2();
    double norm2squared();
    double normInfinity();
    /** useful non-norms. !norm(y) */
    double minAbsCoef();

    /** single external reference data management. */
    double *accessArrayRead();
    double *accessArrayWrite();
    double *accessArrayReadWrite();
    void restoreArray(double *ary);

};

#endif /* _esi_VectorPort_h_ */
