#ifdef _CCAMPI
#ifndef DefaultMPIBorrow_h_seen
#define DefaultMPIBorrow_h_seen
#include <mpi.h>
#include "dc/export/config.hh"
class DefaultMPIBorrow : 
public virtual classic::gov::cca::MPIBorrow
#ifdef HAVE_NEO
  /// this is a hack. do the opq adapter and make it go away. ouch.
, public virtual neo::cca::Port
, public virtual neo::cca::ports::MPIBorrow
#endif // HAVE_NEO

{

private:

	/** next available tag. */
	int maxTag;

	/** last issued key */
	int maxKey;
	
public:

  DefaultMPIBorrow();

  virtual ~DefaultMPIBorrow();

	/** Get a communicator and a set of available tags on it.
	 * FIXME need to keep a key:tag lookup array to be fully safe.
	 * FIXME need to keep a key comm lookup, if we manage more than one comm...
	 */
  virtual MPI_Comm borrowComm(int, int*, int&);

	/** Return a communicator and release the tags on it. */
  virtual void returnComm(MPI_Comm, int, int*, int);

};
#endif //DefaultMPIBorrow_h_seen
#endif // _CCAMPI
