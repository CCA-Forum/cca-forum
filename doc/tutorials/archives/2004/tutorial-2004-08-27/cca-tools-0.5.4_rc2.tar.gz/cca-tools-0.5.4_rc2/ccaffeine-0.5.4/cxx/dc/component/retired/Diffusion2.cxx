#include <stdlib.h>
#include "jc++/jc++.h"
#include "jc++/util/jc++util.h"
#include <cca.h>
#include "parameters/parametersStar.h"
#include "port/portInterfaces.h"
#include "port/supportInterfaces.h"
#include "dc/port/portStar.h"
#include <ESI.h>
#include <ESICCA.h>
#include "dc/component/Shape.h"

#include "Source.h"

#include <mpi.h>
#include <ESI.h>
#include <snl-cpp.h>
#include <isis.h>

#include "Diffusion2.h"

// for debugging DataHolder ONLY
#include "DataHolder.h"

// bit masks for debugging various code sections.
#define DBG_LAYOUT 1 // map layout info
#define DBG_DATA 2 // dataholder
#define DBG_GHOST 4 // overlap communications
#define DBG_BC 8 // random boundary condition
#define DBG_ESI 16 // esi data calls
#define DBG_UINFO 32 // interior nodes


void Diffusion2::setupParameters(ConfigurableParameterFactory *cpf){
  pp = cpf->createConfigurableParameterPort();
  pp->setBatchTitle("Stencil Diffusion2 Configuration");
  pp->setGroupName("Physical Properties");
  pp->addRequest(timeParam);
  pp->addRequest(dxParam);
  pp->addRequest(dyParam);
  pp->setGroupName("Numerical Settings");
  pp->addRequest(dtParam);
  pp->addRequest(tEndParam);
  pp->addRequest(tBeginParam);
  pp->setGroupName("Random Boundary Cond. Settings");
  pp->addRequest(isRandom);
  pp->addRequest(randDuration);
  pp->addRequest(randProbability);
  pp->addRequest(randMaxTemp);
  pp->addRequest(randMinTemp);
}

Diffusion2::Diffusion2() {
  matConfigured = 0;
  numProcs = -1;
  myProc = -1;
  isInitialized = 0;
  overlap = 1;
  vizInitialized = FALSE;
  dxParam = new DoubleParameter("dxParam", "X Spacing", "Delta X", .00001, 
                                .1, 100.);
  dyParam = new DoubleParameter("dyParam", "Y Spacing", "Delta Y", .00001, 
                                .1, 100.);
  dtParam = new DoubleParameter("dtParam", "Time Step", "Delta T", .00001, 
                                .1, 100.);
  timeParam = new DoubleParameter("timeParam", "Reciprocol Time Scale", 
                                  "Admittance", 
                                  .00001, .1, 1.);
  tEndParam = new DoubleParameter("tEndParam", "End Time", "End Time", 
                                  .1, 50, 100000.);
  tBeginParam = new DoubleParameter("tBeginParam", "Begin Time", "Begin Time", 
                                    .1, 1, 100000.);
  isRandom = new BoolParameter("isRandom", 
                               "Random Temperature Boundary Condition", 
                               "Random B.C.", 1);
  randDuration = new DoubleParameter("randDuration", 
                                     "Random B.C. Max Duration in Time Steps", 
                                     "Max. Duration", 1., 30., 5000.);
  randProbability = new DoubleParameter("randProbability", 
                                        "Random B.C. Prob. of Occurance", 
                                        "Occurance Prob.", .0, .008, 1.);
  randMaxTemp = new DoubleParameter("randMaxTemp", 
                                    "Randomly Choosen Max. Temperature",
                                    "Max. Temperature", 0., 1.e5, 1.e8);
  randMinTemp = new DoubleParameter("randMinTemp", 
                                    "Randomly Choosen Min. Temperature",
                                    "Min. Temperature", 0., 1., 1.e8);

  debug = (DBG_LAYOUT | DBG_ESI);
  lbcSrc = 0;
  rbcSrc = 0;
  tbcSrc = 0;
  bbcSrc = 0;
}

Diffusion2::~Diffusion2(){
//fixme
  svc = 0;
  pfp = 0;
}

void Diffusion2::init1() {
  // Initialize the state and deriv. for the diffusion.
  Port *tmpPort = svc->getPort("DATA");
  if (tmpPort == 0) {
    pfp->en("! Diffusion2::init: port DATA not connected.");
    return;
  }
  BlockPort* port = dynamic_cast<BlockPort*>(tmpPort);
  CHECKDCM(port,"Port DATA wired to incorrect type of provider (not BlockPort)");

  port->getBlock(&block);
  if(debug & DBG_DATA) {
    DataHolder* dh = dynamic_cast<DataHolder*>(port);
    if(dh != 0) dh->setDebug(TRUE);
  }
  CCA_BlockDescription* d = block->getDescription();
  data = block->getData();
  int nDim = 0, bId;
  myProc = bId = d->getBlockId();
  CCA_dimenMap *dim = (CCA_dimenMap *)d->getDimensions(nDim);
  if (nDim != 2) {
    char* str = (char*)malloc(1024*sizeof(char));
    sprintf(str, ":-( Dimension of the problem = %d, we can only do 2", 
            nDim);
    pfp->en(str);
    free(str);
    svc->releasePort("DATA");
    return;
  }
  beginCol = dim[1].gLow;
  endCol = dim[1].gHigh;
  beginRow = dim[0].gLow;
  endRow = dim[0].gHigh;
  offset = dim[0].beginPad*(endCol - beginCol);
  numCols = dim[1].gSize;
  numRows = dim[0].gSize;
  colLen = endCol - beginCol;
  if(debug  & DBG_LAYOUT) {
    pfp->en("offset = %d", offset);
    pfp->en("beginRow = %d", beginRow);
    pfp->en("endRow = %d", endRow);
    pfp->en("beginCol = %d", beginCol);
    pfp->en("endCol = %d", endCol);
    pfp->en("data = 0x%x", data);
    pfp->en("blockId = %d", bId);
    for(int r = beginRow;r < endRow;r++) {
      for(int c = beginCol;c < endCol;c++) {
        if (debug & DBG_DATA) {
          pfp->en("loading (%d, %d) total offset = %d", r, c, 
                 offset + (c - beginCol) + colLen*(r - beginRow));
        }
        *(data + offset + (c - beginCol) + colLen*(r - beginRow)) = 
          (double)10000.*(double)bId + (double)100.*(double)r + (double)c;
      }
    }
    if (debug & DBG_DATA) {
      for(int r = beginRow - overlap;r < endRow + overlap;r++) {
        for(int c = beginCol;c < endCol;c++) {
          pfp->en("data(%d,%d) = %g", r, c,  
                 *(data + offset + (c - beginCol) + colLen*(r - beginRow)));
        }
      }
    }
  }
  port->update();
  if(debug & DBG_DATA) {
    pfp->en("\n\nAfter Update:\n\n");
    for(int r = beginRow - overlap;r < endRow + overlap;r++) {
      for(int c = beginCol;c < endCol;c++) {
        pfp->en("data(%d,%d) = %g", r, c,  
               *(data + offset + (c - beginCol) + colLen*(r - beginRow)));
      }
    }
  }
  svc->releasePort("DATA");
    
}

void Diffusion2::init2() {
  dx = dxParam->value;
  dy = dyParam->value;
  dt = dtParam->value;
  alpha = (0.25*(dx*dx + 2*dx*dy + dy*dy))/timeParam->value;
  tEnd = tEndParam->value;
  isInitialized = TRUE;
  initViz();
  Port* prt = svc->getPort("Viz");
  if(prt != 0) {
    Cartesian2Port* c2;
    c2 = dynamic_cast<Cartesian2Port *>(prt); CHECKDC(c2);
    c2->visualize();
    svc->releasePort("Viz");
  }
}

/** Implements GoPort interface. */
int Diffusion2::go() {
  if (matConfigured) {
    return goSolve();
  }
  return goSetup();
}

// Correct for the fact that the Y direction in viz space is backwards.
#define Y_DIRECTION_CORRECTION 1.0
#define DATA(r,c) data[offset + ((c) - beginCol) + colLen*((r) - beginRow)]
//Global index for the eqn solver, see explanation below
#define GINDEX(r,c) ((c) + (r)*(numCols)) 
//Local index for the eqn solver.
#define LINDEX(r,c) ((c) - beginCol + colLen*((r) - beginRow))
int Diffusion2::goSetup() {
  if (matConfigured) { return -1; }
  init1();
  // get builder
  Port *tmpPort=0;
  ESI_MatrixRowBuilder *mb=0;

  tmpPort = svc->getPort("matrixRowBuilder");
  if (!tmpPort) { return 0; } //user not done wiring. not error.

  mb = dynamic_cast<ESI_MatrixRowBuilder *>(tmpPort);
  if (!mb) {
    pfp->en("!!! Diffusion2::setupMatrix: matrixRowBuilder port not wired correctly!!");
    // maybe unregister and reregister port to dump misconnection here.
    return 0;
  }
  
  // use builder (setrows,allocate)
  // calc rows, call mb->setRowLengths, mb->allocateRows()
  // whine about errors.

  esi_int retCode;
  esi_msg msg;
  sprintf(msg,"goSetup entered");

  esi_int4 localSize = (endRow-beginRow)*(endCol-beginCol); // wild guess
  esi_int4 *rowCounts = new esi_int4[localSize];
  for (int i = 0 ; i < localSize ; i++) {rowCounts[i] = -1;}

  tmpPort=0;
  // note: if the rowcounts are wrong below, then the calculation is also.
  // in particular, oughtn't we to get some 2's, 3's, and 4's near the corners?
  if (1) {
    esi_int4 numColsInRow;
    char *plocation;
    for(int r = beginRow;r < endRow;r++) {
      for(int c = beginCol;c < endCol;c++) {
        plocation = (char *)"!! NOWHERE !!";
        if(c == 0) {                   //Left BC
	  numColsInRow = 1;
          plocation = (char *)"Left";
        } else if(c == (numCols - 1)) { //Right BC
	  numColsInRow = 1;
          plocation = (char *)"Right";
        } else if(r == 0) {             //Top BC
	  numColsInRow = 1;
          plocation = (char *)"Top";
        } else if(r == (numRows - 1)) {  // Bottom BC
	  numColsInRow = 1;
          plocation = (char *)"Bottom";
        } else { // Middle somewhere, this is all that matters to the solver.
	  numColsInRow = 5;
          plocation = (char *)"Interior";
        }
	rowCounts[LINDEX(r, c)] = numColsInRow;
        // if (debug & DBG_ESI) {
          pfp->en("# D2 rowCounts[%d] = %d (%s)",
                 LINDEX(r, c),numColsInRow,plocation);
        // }
      }
    }
  }

  retCode = mb->setRowLengths(rowCounts, localSize, msg);
  if (retCode < 0) {
    pfp->en("!!! Diffusion2::goSetup setRowLengths bogus {%s}",msg);
    return 0;
  }

  retCode = mb->allocateRows(msg);
  if (retCode < 0) {
    pfp->en("!!! Diffusion2::goSetup allocateRows bogus {%s}",msg);
    delete [] rowCounts;
    return 0;
  }
  delete [] rowCounts;

// the isis implementation is consistent with the incomplete esi headers and
// imagines rows/cols are indexed 1 based.
// esi will be clarifying this.
#define ROW(roW) ((roW)+1)
#define COL(coL) ((coL)+1) 

  if(1) {
    for(int r = beginRow;r < endRow;r++) {
      for(int c = beginCol;c < endCol;c++) {
        if(c == 0) { //Left BC
          int row = ROW(GINDEX(r, c));
          esi_int4 numColsInRow = 1;
          esi_int4 colIndex = COL(GINDEX(r, c));
if (debug & DBG_ESI) {
pfp->en("mb->setColIndices(%d, %d, %d, msg)",row,numColsInRow,colIndex);
}
          esi_int retCode = mb->setColIndices(row, numColsInRow, 
                                           &colIndex, 
                                           msg);
          if(retCode < 0) {
            pfp->en("mb->setColIndices failed(%d) for row: %d", 
                   retCode, row);
            pfp->en("Mb returned:{%s}. Bye!",msg);
            assert(0);
          }
        } else if(c == (numCols - 1)) { //Right BC
          int row = ROW(GINDEX(r, c));
          esi_int4 numColsInRow = 1;
          esi_int4 colIndex = COL(GINDEX(r, c));
if (debug & DBG_ESI) {
pfp->en("mb->setColIndices(%d, %d, %d, msg)",row,numColsInRow,colIndex);
}
          esi_int retCode = mb->setColIndices(row, 
                                           numColsInRow, 
                                           &colIndex, 
                                           msg);
          if(retCode < 0) {
            pfp->en("mb->setColIndices failed(%d) for row: %d", retCode,row);
            assert(0);
          }
        } else if(r == 0) {//Top BC
          int row = ROW(GINDEX(r, c));
          esi_int4 numColsInRow = 1;
          esi_int4 colIndex = COL(GINDEX(r, c));
          
if (debug & DBG_ESI) {
pfp->en("mb->setColIndices(%d, %d, %d, msg)",row,numColsInRow,colIndex);
}
          esi_int retCode = mb->setColIndices(row, 
                                           numColsInRow, 
                                           &colIndex, 
                                           msg);
          if(retCode < 0) {
            pfp->en("mb->setColIndices failed(%d) for row: %d", retCode, row);
            assert(0);
          }
        }else if(r == (numRows - 1)) { // Bottom BC
          int row = ROW(GINDEX(r, c));
          esi_int4 numColsInRow = 1;
          esi_int4 colIndex = COL(GINDEX(r, c));
if (debug & DBG_ESI) {
pfp->en("mb->setColIndices(%d, %d, %d, msg)",row, numColsInRow, colIndex);
}
          esi_int retCode = mb->setColIndices(row, 
                                           numColsInRow, 
                                           &colIndex, 
                                           msg);
          if(retCode < 0) {
            pfp->en("mb->setColIndices failed(%d) for row: %d", retCode,row);
            assert(0);
          }
        } else { // Middle somewhere, this is all that matters to the solver.
          int row = ROW(GINDEX(r, c));
          esi_int4 numColsInRow = 5;
          esi_int4* colIndex = new esi_int4[numColsInRow];

          colIndex[0] = COL(GINDEX(r, c));
          colIndex[1] = COL(GINDEX(r, c - 1));
          colIndex[2] = COL(GINDEX(r, c + 1));
          colIndex[3] = COL(GINDEX(r - 1, c)); // fixme, rob?
          colIndex[4] = COL(GINDEX(r + 1, c)); // fixme, rob?
          
if (debug & DBG_ESI) {
pfp->en("mb->setColIndices(%d, %d, (%d,%d,%d,%d,%d), msg)",row, numColsInRow,
       colIndex[0], colIndex[1], colIndex[2], colIndex[3], colIndex[4]);
}
          esi_int retCode = mb->setColIndices(/*esi_int4 row */ row, 
          /*esi_int4 length*/ numColsInRow, 
          /*esi_int4* colIndices*/ colIndex, 
          msg);
          delete [] colIndex;
          if(retCode < 0) {
            pfp->en("mb->setColIndices failed(%d) for row: %d", retCode, row);
            assert(0);
          }
        }
      }
    }
  }
  retCode = mb->allocateBuffers(msg);
  if(retCode < 0) {
    pfp->en("mb->allocateBuffers failed(%d) {%s}. bye!", retCode, msg);
    assert(0);
  }


  svc->releasePort("matrixRowBuilder");
  svc->unregisterUsesPort("matrixRowBuilder");
  svc->registerUsesPort(svc->createPortInfo("Viz", "Cartesian2Port", 0));
  svc->registerUsesPort(svc->createPortInfo("matrixPutRow", "ESI_MatrixRowWriteAccess", 0));
  svc->removeProvidesPort("setupMatrix");
  svc->addProvidesPort(this, svc->createPortInfo("Go", "GoPort", 0));
  matConfigured = 1;
  return 0;
}

int Diffusion2::goSolve() {
  stateCompute(); // Sets up the overlap radius.
  init2();
  for(t = 0.;t < tEnd;t += dt) {
    BlockPort* port = dynamic_cast<BlockPort*>(svc->getPort("DATA"));
    CHECKDC(port);
    if(debug) {
      printGrid();
    }
    port->update();
    if(debug) {
      printGrid();
    }
    derivCompute();
    svc->releasePort("DATA");
    Port* prt = svc->getPort("Viz");
    if(prt != 0) {
      Cartesian2Port* c2;
      c2 = dynamic_cast<Cartesian2Port *>(prt); CHECKDC(c2);
      c2->visualize();
      svc->releasePort("Viz");
    }
  }
  if(debug) {
    printGrid();
  }
  return 0;
}

void Diffusion2::setServices(Services* svc) {
  this->svc = svc;

  // Contact the PrintfService
  PortInfo* pinfo = svc->createPortInfo("pSvc", "gov.cca.PrintfService", 0);
  svc->registerUsesPort(pinfo);
  pfp = dynamic_cast<PrintfPort*>(svc->getPort("pSvc"));
  CHECKDC(pfp);
  if(pfp == 0) {
    svc->addProvidesPort(this, svc->createPortInfo("DEAD=NoPrintf", "GoPort", 0));
    printf("!!! No PrintfService available from framework.");
    return;
  }

  // Contact the ParameterPortFactoryService
  pinfo = svc->createPortInfo("cSvc", "gov.cca.ParameterPortFactoryService", 0);
  svc->registerUsesPort(pinfo);
  ConfigurableParameterFactory *cpf =
    dynamic_cast<ConfigurableParameterFactory*>(svc->getPort("cSvc"));
  CHECKDC(cpf);
  if(cpf == 0) {
    svc->addProvidesPort(this, svc->createPortInfo("DEAD=NoParamService", "Port", 0));
    return;
  }
  setupParameters(cpf);
  svc->releasePort("cSvc");
  svc->unregisterUsesPort("cSvc");


  svc->registerUsesPort( svc->createPortInfo("DATA", "BlockPort", 0));
  svc->addProvidesPort(this, svc->createPortInfo("setupMatrix", "GoPort", 0));
  svc->addProvidesPort(pp, svc->createPortInfo("Config", "ParameterPort", 0));
  svc->registerUsesPort(svc->createPortInfo("matrixRowBuilder", 
                                            "ESI_MatrixRowBuilder", 0));
  svc->registerUsesPort(svc->createPortInfo("BJCPN(Vector)", 
                                            "ESI_JCPN(Vector)", 0));
  svc->registerUsesPort(svc->createPortInfo("ESI_Solver", 
                                            "ESI_Solver", 0));
}
/** This means create the first state, i.e. initialize. */
void Diffusion2::stateCompute() {
  if(isInitialized) return;
  Port *tmpPort = svc->getPort("DATA");
  if (tmpPort == 0) {
    pfp->en("! Diffusion2::stateCompute: port DATA not connected.");
    return;
  }
  BlockPort* port = dynamic_cast<BlockPort*>(tmpPort);
  CHECKDCM(port,"Port DATA wired to incorrect type of provider (not BlockPort)");

  port->setOverlapUniform(overlap, &block);
    
  svc->releasePort("DATA");
}
void Diffusion2::stateUpdate() {
//do nothing
}

void Diffusion2::initViz() {
  esi_msg msg; esi_int err;
  int blocksize;
  pfp->en(" Diffusion2::initViz() entry ...");
  if (!vizInitialized) { // first call
    SNL_Map *xmap = new SNL_Map();
    SNL_Map *ymap = new SNL_Map();
    SNL_Map *fmap = new SNL_Map();
    ESI_MapAlgebraic *ema;
    err = 0;
#ifdef ONE_PROC_ONLY
    assert(myProc == 0);
    if(debug & DBG_LAYOUT) {
      pfp->en("Setting serial maps:");
      pfp->en("numCols: %d, numRows: %d, beginCol: %d, endCol: %d, beginRow: %d endRow: %d", numCols, numRows, beginCol, endCol, beginRow, endRow);
    }
    // xmap->setGlobalSize(numCols,msg);
    // ymap->setGlobalSize(numRows,msg);
    // fmap->setGlobalSize(numRows*numCols,msg);
    err += xmap->setLocalInfo(numCols, 0,msg);
    err += ymap->setLocalInfo(numRows, 0,msg);
    blocksize = numCols*numRows;
    err += fmap->setLocalInfo(blocksize, 0,msg); //size, no offset
#else
    if(debug&DBG_LAYOUT) {
      pfp->en("Setting parallel maps:");
      pfp->en("numCols: %d, numRows: %d, beginCol: %d, endCol: %d, beginRow: %d endRow: %d", numCols, numRows, beginCol, endCol, beginRow, endRow);
    }
    // cant set both global and local
    // xmap->setGlobalSize(numCols,msg);
    // ymap->setGlobalSize(numRows,msg);
    // fmap->setGlobalSize(numRows*numCols,msg);
    err += xmap->setLocalInfo(endCol - beginCol, beginCol, msg); // calc'd in init1()
    err += ymap->setLocalInfo(endRow - beginRow, beginRow, msg); // calc'd in init1()
    blocksize = (endCol - beginCol)*(endRow - beginRow);
    err += fmap->setLocalInfo(blocksize, numCols*beginRow, msg); // size, offset
#endif //ONE_PROC_ONLY

    if (err != 0) {
        pfp->en(" Diffusion::initViz() map bogosity ...");
        delete xmap;
        delete ymap;
        delete fmap;
        fmap = xmap = ymap = 0;
        return;
    }

    esi_int eerr;
    xmap->getInterface("ESI_MapAlgebraic",((void **)(&ema)),msg);
    if (!ema) {
        pfp->en(" Diffusion::initViz() x mapAlgebraic bogosity ...{%s}",msg);
    }
    ISIS_JCPN(Vector)* Xaxis = new ISIS_JCPN(Vector)(*ema,eerr,msg);
    if (eerr < 0 || Xaxis == 0) {
        pfp->en(" Diffusion::initViz() Xaxis create bogosity {%s}",msg);
    }
    ymap->getInterface("ESI_MapAlgebraic",((void **)(&ema)),msg);
    if (!ema) {
        pfp->en(" Diffusion::initViz() y mapAlgebraic bogosity ...{%s}",msg);
    }
    ISIS_JCPN(Vector)* Yaxis = new ISIS_JCPN(Vector)(*ema,eerr,msg);
    if (eerr < 0 || Yaxis == 0) {
        pfp->en(" Diffusion::initViz() Yaxis create bogosity {%s}",msg);
    }

    // ISIS_JCPN(Vector)* T = new ISIS_JCPN(Vector)(fmap, data + offset, (endCol - beginCol)*(endRow - beginRow)); 
    fmap->getInterface("ESI_MapAlgebraic",((void **)(&ema)),msg);
    if (!ema) {
        pfp->en(" Diffusion::initViz() f mapAlgebraic bogosity ...{%s}",msg);
    }
    ISIS_JCPN(Vector)* T = new ISIS_JCPN(Vector)(*ema,eerr,msg);
    if (eerr < 0 || T == 0) {
        pfp->en(" Diffusion::initViz() T create bogosity {%s}",msg);
    }

    ESI_JCPN(Vector)ReplaceAccess *Tra;
    T->getInterface("ESI_JCPN(Vector)ReplaceAccess",((void **)(&Tra)),msg);
    assert(Tra != 0);
    Tra->setArrayPointer(data+offset,&blocksize,msg);

    //      Q = new ISIS_JCPN(Vector)(fmap); 

    // call cartesian2port to set up viz.
    Port* prt = svc->getPort("Viz");
    if(prt != 0) {
      Cartesian2Port *c2;
      c2 = dynamic_cast<Cartesian2Port*>(prt); CHECKDC(c2);

      c2->setXAxis(Yaxis); // flip the rendering axes
      c2->setYAxis(Xaxis); // flip the rendering axes
      c2->setField(T,"temperature",0);
      //      c2->setField(Q,"heat flux",1);
      if(debug) {
        pfp->en("Diffusion2 cartesian2port filled.");
      }
      svc->releasePort("Viz");
      if(debug) {
        pfp->en("Diffusion2 cartesian2port released.");
      }
      vizInitialized = TRUE;
      return;
    }
  }
}
  

CDELETE Source* Diffusion2::randomSource() {
  double prob = .008; // probability of event.
  double max = 100.;
  
  double rx = (random() % 1000) * 0.1;
  double rndm = rx/max;
  double maxDuration = 30.*dt;
  // duration <= 0 means no event.
  double duration = (prob - rndm)*maxDuration/prob;
  if(debug & DBG_BC) {
    pfp->en("duration: %g rndm: %g max: %g rx %g", duration, rndm, max, rx);
  }
  double maxTemperatureSrc = 100000.;
  double minTemperatureSrc = 0.;
      
  rx = (random() % 10000) * 0.01;
  rndm = rx/max;
  double temperature = (maxTemperatureSrc - minTemperatureSrc)*rndm + 
    minTemperatureSrc;
  Source* src = new Source();
  src->temperature = temperature;
  src->duration = duration;
  return src;
}

boolean Diffusion2::computeRandBC(double* Uptr, Source** srcPtr, int i, int begin) {
  Source* rs = randomSource();
  double U = 0;
  Source* lbcSrc = *srcPtr;
    
  if((rs->duration > 0) && (lbcSrc == 0)) {
    lbcSrc = rs;
  } else {
    delete rs;
  }
  if(lbcSrc != 0) {
    U = lbcSrc->temperature;
    if(i == begin) {
      lbcSrc->duration -= dt;
    }
    if(debug & DBG_BC) {
      pfp->en("Event for LBC: U = %g, lbcSrc = 0x%x, duration = %g, r = %d", 
             U, lbcSrc, lbcSrc->duration, i);
    }
    if(lbcSrc->duration < 0) {
      delete lbcSrc;
      lbcSrc = 0;
    } 
    *Uptr = U;
    *srcPtr = lbcSrc;
    return TRUE;
  } else {
    *srcPtr = lbcSrc;
    return FALSE;
  }
}

void Diffusion2::derivCompute() {
  Port *tmpPort = 0;
  tmpPort = svc->getPort("DATA");
  if (tmpPort == 0) {
    pfp->en("! Diffusion2::derivCompute: port DATA not connected.");
    return;
  }
  BlockPort* port = dynamic_cast<BlockPort*>(tmpPort);
  CHECKDCM(port,"Port DATA wired to incorrect type of provider (not BlockPort)");

  port->getBlock(&block);
  data = block->getData();
    
  if(!isInitialized) {
    init2();
  }

  // Begin ESI preparatory stuff
  // Pop out an array to be filled with the b values.
  esi_int retCode;
  esi_msg msg;
  sprintf(msg,"derivCompute ok");

  tmpPort=0;
  tmpPort = svc->getPort("BJCPN(Vector)");
  if (tmpPort == 0) {
    pfp->en("!!! Diffusion2::derivCompute svc->getPort(\"BJCPN(Vector)\") failed");
    assert(0);
  }
  ESI_JCPN(Vector) *bvec =  dynamic_cast<ESI_JCPN(Vector)*>(tmpPort);
  if (bvec == 0) {
    pfp->en("!!! Diffusion2::derivCompute BJCPN(Vector) port misconnected");
    assert(0);
  }
  esi_real8* bPtr;
  retCode = bvec->getArrayRead(&bPtr, msg);
  if(retCode < 0 || bPtr ==0) {
    pfp->en("ESIJCPN(Vector)::getArrayRead failed");
    assert(0);
  }
  ESI_JCPN(Vector)* xvec;
  // Clone the solution vector.
  retCode = bvec->clone(xvec, msg);
  if(retCode < 0) {
    pfp->en("ESIJCPN(Vector)::clone failed");
    assert(0);
  }
  ESI_MatrixRowWriteAccess* mat = 
    dynamic_cast<ESI_MatrixRowWriteAccess*>(svc->getPort("matrixPutRow"));
  CHECKDC(mat);

  //End ESI preparatory stuff

  double U;
  double Uym1;
  double Uyp1;
  double Uxm1;
  double Uxp1;
  double Utp1;

// the isis implementation is consistent with the incomplete esi headers and
// imagines rows/cols are indexed 1 based.
// esi will be clarifying this.
// defined earlier ROW(roW) ((roW)+1)
// defined earlier COL(coL) ((coL)+1) 

  boolean noCompute = FALSE;
  if(noCompute){}
  else {
    for(int r = beginRow;r < endRow;r++) {
      for(int c = beginCol;c < endCol;c++) {
        if(c == 0) { //Left BC
          boolean isEvent = computeRandBC(&U, &lbcSrc, r, beginRow);
          if(!isEvent) {
            // Insulate
            U = DATA(r,c);
            Uxp1 = DATA(r, c + 1);
            U = Uxp1;
          }
          // DATA(r, c) = U;
          // Row number for this equation.
          int row = ROW(GINDEX(r, c));
          // Number of nonzero columns in our row
          esi_int4 numColsInRow = 1;
          // coefficients for the matrix
          esi_real8 coeff = 1.;
          // indices for the coefficients
          esi_int4 colIndex = COL(GINDEX(r, c));
          // rhs (b value) for the row
          
          pfp->en("# bPtr[%d] = %g",LINDEX(r, c),U);
          bPtr[LINDEX(r, c)] = U;
if (debug & DBG_ESI) {
pfp->en("mat->copyInRow(%d, %g, %d, %d, msg)",row,coeff,colIndex,numColsInRow);
}
          esi_int retCode = mat->copyInRow(row, 
                                           &coeff, 
                                           &colIndex, 
                                           numColsInRow, 
                                           msg);
          if(retCode < 0) {
            pfp->en("ESI_MatrixRowWriteAccess:copyInRow: failed(%d) for row: %d", 
                   retCode, row);
            pfp->en("Mat returned:{%s}. Bye!",msg);
            assert(0);
          }
        } else if(c == (numCols - 1)) { //Right BC
          if(FALSE) {
            ;
          } else {
            //Insulate
            U = DATA(r, c);
            Uxm1 = DATA(r, c - 1);
            U = Uxm1;
          }
          // DATA(r, c) = U;
          // Row number for this equation.
          int row = ROW(GINDEX(r, c));
          // Number of nonzero columns in our row
          esi_int4 numColsInRow = 1;
          // coefficients for the matrix
          esi_real8 coeff = 1.;
          // indices for the coefficients
          esi_int4 colIndex = COL(GINDEX(r, c));
          // rhs (b value) for the row
          
          pfp->en("# bPtr[%d] = %g",LINDEX(r, c),U);
          bPtr[LINDEX(r, c)] = U;
if (debug & DBG_ESI) {
pfp->en("mat->copyInRow(%d, %g, %d, %d, msg)",row,coeff,colIndex,numColsInRow);
}
          esi_int retCode = mat->copyInRow(row, 
                                           &coeff, 
                                           &colIndex, 
                                           numColsInRow, 
                                           msg);
          if(retCode < 0) {
            pfp->en("ESI_MatrixRowWriteAccess:copyInRow: failed for row: %d", 
                   row);
            assert(0);
          }
        } else if(r == 0) {//Top BC
          boolean isEvent = computeRandBC(&U, &tbcSrc, c, beginCol + 1);
          if(!isEvent) {
            U = DATA(r, c);
            Uyp1 = DATA(r + 1, c);
            U = Uyp1;
          }
          // DATA(r, c) = U;
          // Row number for this equation.
          int row = ROW(GINDEX(r, c));
          // Number of nonzero columns in our row
          esi_int4 numColsInRow = 1;
          // coefficients for the matrix
          esi_real8 coeff = 1.;
          // indices for the coefficients
          esi_int4 colIndex = COL(GINDEX(r, c));
          // rhs (b value) for the row
          
          pfp->en("# bPtr[%d] = %g",LINDEX(r, c),U);
          bPtr[LINDEX(r, c)] = U;
if (debug & DBG_ESI) {
pfp->en("mat->copyInRow(%d, %g, %d, %d, msg)",row,coeff,colIndex,numColsInRow);
}
          esi_int retCode = mat->copyInRow(row, 
                                           &coeff, 
                                           &colIndex, 
                                           numColsInRow, 
                                           msg);
          if(retCode < 0) {
            pfp->en("ESI_MatrixRowWriteAccess:copyInRow: failed for row: %d", 
                   row);
            assert(0);
          }
        }else if(r == (numRows - 1)) { // Bottom BC
          if(FALSE) {
            ;
          } else {
            U = DATA(r, c);
            Uym1 = DATA(r - 1, c);
            U = Uym1;
          }
          //          DATA(r, c) = U;
          // Row number for this equation.
          int row = ROW(GINDEX(r, c));
          // Number of nonzero columns in our row
          esi_int4 numColsInRow = 1;
          // coefficients for the matrix
          esi_real8 coeff = 1.;
          // indices for the coefficients
          esi_int4 colIndex = COL(GINDEX(r, c));
          // rhs (b value) for the row
          
          pfp->en("# bPtr[%d] = %g",LINDEX(r, c),U);
          bPtr[LINDEX(r, c)] = U;
if (debug & DBG_ESI) {
pfp->en("mat->copyInRow(%d, %g, %d, %d, msg)",row,coeff,colIndex,numColsInRow);
}
          esi_int retCode = mat->copyInRow(row, 
                                           &coeff, 
                                           &colIndex, 
                                           numColsInRow, 
                                           msg);
          if(retCode < 0) {
            pfp->en("ESI_MatrixRowWriteAccess:copyInRow: failed for row: %d", 
                   row);
            assert(0);
          }
        } else { // Middle somewhere, this is all that matters to the solver.
          U = DATA(r, c);
          Uym1 = DATA(r - 1, c);
          Uyp1 = DATA(r + 1, c);
          Uxm1 = DATA(r, c - 1);
          Uxp1 = DATA(r, c + 1);

          // The number of rows in the global matrix is
          // numRows*numCols, the global size of the problem.  The
          // boundary conditions effectively "skin" the problem, and
          // reduce the problem size by (numCols - 1)*(numRows - 1)
          // Values for the B.C.'s are just known (see above) that
          // means there are N - 2 rows in the global matrix, where N
          // is the size of the grid.

          // Row number for this equation.
          int row = ROW(GINDEX(r, c));
          // Number of nonzero columns in our row
          esi_int4 numColsInRow = 5;
          // coefficients for the matrix
          esi_real8* coeff = new esi_real8[numColsInRow];
          // indices for the coefficients
          esi_int4* colIndex = new esi_int4[numColsInRow];
          // rhs (b value) for the row
          esi_real8 b;

          colIndex[0] = COL(GINDEX(r, c));
          colIndex[1] = COL(GINDEX(r, c - 1));
          colIndex[2] = COL(GINDEX(r, c + 1));
          colIndex[3] = COL(GINDEX(r - 1, c)); // fixme, rob?
          colIndex[4] = COL(GINDEX(r + 1, c)); // fixme, rob?
          
          double eps = timeParam->value;
          coeff[0] = 4.0*(1.0 + eps);
          coeff[1] = -eps;
          coeff[2] = -eps;
          coeff[3] = -eps;
          coeff[4] = -eps;

           b = eps*(Uym1 +  Uyp1 + Uxm1 + Uxp1) + 4.0*(1.0 - eps)*U;
          // load b's into vector that will be exported to the solver.
          pfp->en("# bPtr[%d] = %g",LINDEX(r, c),U);
          bPtr[LINDEX(r, c)] = b;
          
if (debug & DBG_ESI) {
pfp->en("mat->copyInRow(%d, (%g,%g,%g,%g,%g) (%d,%d,%d,%d,%d) %d, msg)",row,
       coeff[0], coeff[1], coeff[2], coeff[3], coeff[4],
       colIndex[0], colIndex[1], colIndex[2], colIndex[3], colIndex[4],
       numColsInRow);
}
          esi_int retCode = mat->copyInRow(/*esi_int4 row */ row, 
          /*esi_real8* coefs*/ coeff, 
          /*esi_int4* colIndices*/ colIndex, 
          /*esi_int4 length*/ numColsInRow, 
          msg);
          if(retCode < 0) {
            pfp->en("ESI_MatrixRowWriteAccess failed for row: %d", row);
            assert(0);
          }


          //         Utp1 = alpha*dt*(
          //                          ((Uxp1 - U)/dx - (U - Uxm1)/dx)/dx +
          //                          Y_DIRECTION_CORRECTION*
          //                          (((Uyp1 - U)/dy - (U - Uym1))/dy)/dy
          //                          ) + U;
          if(debug & DBG_UINFO) {
            pfp->en("eps %g,Uxm1 %g,Uxp1 %g,U %g", eps, Uxm1, Uxp1, U);
          }
          //Utp1 = (eps*(Uxm1+Uxp1) + (2.0 - 2*eps)*U)/2.0;
          Utp1 = (eps*(Uxm1 + Uxp1 + Uym1 + Uyp1) + (4.0 - 4*eps)*U)/4.0;
          DATA(r, c) = Utp1;
        }
      }
    }
  }
  // ESI preparatory to solve
  retCode = bvec->releaseArray(&bPtr, msg);
  tmpPort = svc->getPort("ESI_Solver");
  if (tmpPort == 0) {
    pfp->en("! Diffusion2::derivCompute: port ESI_Solver not connected.");
    return;
  }
  ESI_Solver* solver = dynamic_cast<ESI_Solver*>(tmpPort);
  CHECKDCM(port,"Port ESI_Solver wired to incorrect type of provider (not ESI_Solver)");

  retCode = solver->solve(*bvec, *xvec, msg);
  if(retCode < 0) {
    pfp->en("ESI_Solver::solve failed");
  }
  svc->releasePort("ESI_Solver");
  // End ESI preparatory to solve
  

  // Load the answers back into the block of data
  esi_real8* ans;
  retCode = xvec->getArrayRead(&ans, msg);
  if(retCode < 0) {
    pfp->en("ESI_JCPN(Vector)::getArrayRead failed -- no answer available.");
  } else {
    for(int r = beginRow;r < endRow;r++) {
      for(int c = beginCol;c < endCol;c++) {
        DATA(r, c) = ans[LINDEX(r, c)];
      }
    }
    xvec->releaseArray(&ans, msg);
  }

  svc->releasePort("BJCPN(Vector)");
  svc->releasePort("matrixPutRow");
  svc->releasePort("DATA");
}

void Diffusion2::printGrid() {
  Port *tmpPort = svc->getPort("DATA");
  if (tmpPort == 0) {
    pfp->en("! Diffusion2::printGrid: port DATA not connected.");
    return;
  }
  BlockPort* port = dynamic_cast<BlockPort*>(tmpPort);
  CHECKDCM(port,"Port DATA wired to incorrect type of provider (not BlockPort)");

  port->getBlock(&block);
  data = block->getData();
  pfp->en("Printing the grid from row = %d to %d", beginRow, endRow);
  for(int r = beginRow;r < endRow;r++) {
    for(int c = beginCol;c < endCol;c++) {
      pfp->e("%g\t", DATA(r, c));
    }
    pfp->en("");
  }
  svc->releasePort("DATA");
}

void Diffusion2::derivUpdate() {
//do nothing
}
