Make sure to check environment variables, for example:
capt-january$ echo $SIDL_DLL_PATH 
/home/rob/cca/ccafe/cxx/lib;/usr/local/babel/lib;/home/rob/cca/cca-spec-babel/server
capt-january$ echo $LD_LIBRARY_PATH 
/usr/local/babel/lib:/home/rob/cca/cca-spec-babel/server:/usr/local/mpich/lib/shared
capt-january$ echo $PYTHONPATH 
/home/rob/cca/ccafe/cxx/dc/babel/babel-cca/py-client:/usr/local/babel/lib/python2.1/site-packages/babel:/usr/local/babel/lib/python2.1:/usr/local/babel/lib/python2.1/site-packages:/home/rob/cca/ccafe/cxx/dc/babel/component/PrinterComponent/py-client
