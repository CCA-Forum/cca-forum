// if this is defined a variety of spew occurs via IO_dn*
// and all users of this header have access to IO_dn automatically.
#define CCAFE_AUDIT CCAFE_SPEW

#include "dc/export/ccafeopq.hh"
//#define _OPAQUE_TYPEDEFS 0
#ifdef _OPAQUE_TYPEDEFS // compile -D_OPAQUE_TYPEDEFS iff legacy developer
/* these typedefs will be going away and should
 * not be used in new code.
 */
typedef ccafeopq::Port OpaquePort;
typedef ccafeopq::Component OpaqueComponent;
typedef ccafeopq::GoPort OpaqueGoPort;
typedef ccafeopq::Services OpaqueServices;
typedef ccafeopq::FactoryService OpaqueFactoryService;
typedef ccafeopq::PortInfo OpaquePortInfo;
#endif // all gone now

/* the next header belongs elsewhere, but we
 * don't have time to move it at the moment.
 */
#include "dc/export/OpqPortInfo.hh"
#include "dc/export/oldPorts.hh"
#include "dc/export/paramPorts.hh"
#include "dc/export/ccafeopq_support.hh"
// the next file should live in ccafeopq_support somehow
#include "dc/framework/KernelPort.h"

#ifdef CCAFE_AUDIT
#if CCAFE_AUDIT == 1
#include "util/IO.h"
#else
#undef CCAFE_AUDIT
#endif
#endif
