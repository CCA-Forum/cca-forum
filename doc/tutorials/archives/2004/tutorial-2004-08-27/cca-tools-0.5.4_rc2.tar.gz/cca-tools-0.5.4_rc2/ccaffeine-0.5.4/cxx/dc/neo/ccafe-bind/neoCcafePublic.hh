#ifndef neo_ccafe_public_hh
#define neo_ccafe_public_hh
#include "dc/neo/ccafe-bind/NeoAbstractFramework.hh"
#endif // neo_ccafe_public_hh
