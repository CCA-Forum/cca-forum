
#include <map>
#include <string>

#include <cca.h>
#include "util/IO.h"


#ifdef CCAFE_NO_DL

#include "port/portInterfaces.h"
#include "port/supportInterfaces.h"
#include "dc/port/portStar.h"
#include "dc/component/componentStar.h"

#endif // CCAFE_NO_DL


#include <string.h>
#include <glob.h>
#include <ctype.h>

#ifdef HAVE_BABEL
#include <AllCCA.hh>
#include "dc/babel/babel-cca/AllBabelCCA.hh"
#include "sidl_Loader.hh"
#endif // HAVE_BABEL

#include "util/ascDynaLoad.h"
#include "util/freefree.h"
#include "dc/export/AllExport.hh"
#include "dc/framework/KernelPort.h"
#include "dc/export/ccafeopq_support.hh"
#include "dc/services/dotcca/dccore/DotCCAComponentCore.hpp"
#include "dc/classic/ccafe-bind/AllCcafeBind.hh"
#ifdef HAVE_BABEL
#include "dc/babel/ccafe-bind/AllCcafeBind.hh"
#endif // HAVE_BABEL

#ifdef HAVE_NEO
#include <neocca.hh>
#include "dc/neo/ccafe-bind/AllNeoBind.hh"
#endif // HAVE_NEO

#include "ComponentRecord_Impl.h"
#include "KernelPort.h"
#include "ComponentFactory.h"

// for stat call
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#ifndef DSTRING
#define DSTRING "undated"
#endif

namespace {
  char id[]=
    "$Id: ComponentFactory.cxx,v 1.62 2004/08/12 18:28:41 baallan Exp $";
  char date[]=DSTRING;
} ENDSEMI

  // Must match component type in the ".cca" file
#define BABEL_TYPE "babel"
#define OPAQUE_TYPE "opaque"
#define CLASSIC_TYPE "classic"
#define NEO_TYPE "neo"


  // Stuff we don't want to put in the header if we can help it.
  // we need to split the ccafe_factory_list uses into 
  // per container and global so that the functions per container
  // are correct. We want to avoid having multiple copies of
  // dynamically loaded constructor function pointers around so
  // we have a chance at unloading.

  /** Print out debug info. */
#ifdef CCAFE_SPEW
#if CCAFE_SPEW
bool ComponentFactory::debug = true;
#else
bool ComponentFactory::debug = false;
#endif
#else
bool ComponentFactory::debug = false;
#endif

namespace {
  static bool cfl_init_done = false;

} ENDSEMI


  // A dummy function that should never be called, if it is anyway, it
  // whines.

classic::gov::cca::Component * babelDummyLoader() {
  IO_en1(":-( The dummy loader for a babel component has been called.  "
	 "This cannot happen.  "
	 "Please  report this ccafe-help@z.ca.sandia.gov.");
  return 0;
}

#define eatspace(s) for (; s[0] != '\0' && isspace(s[0]); s = &(s[1]))
#define initspace(s,n) { int ns; for (ns = 0; ns < n; ns++ ) { s[ns] = '\0'; } }

#define PATHSEP '/'

#define CCAFE_LINESIZE 1024

ComponentFactory::ComponentFactory()
{
  initPalette();
  initKernel();
}

ComponentFactory::~ComponentFactory()
{
}

bool ComponentFactory::checkAlreadyLoaded(const char *fname) {
  std::vector< ComponentRecord_shared > & rep = repository;
  ComponentRecord_shared rec;
  for (size_t i = 0; i < rep.size(); i++) {
    rec = rep[i];
    if ( strcmp(fname, rec->getIndexFile().c_str()) == 0) { return true; }
  }
  return false;
}

int ComponentFactory::countUnloadedClasses( ) {
  std::vector< ComponentRecord_shared > & rep = repository;
  ComponentRecord_shared rec;
  int result=0;
  for (size_t i = 0; i < rep.size(); i++) {
    rec = rep[i];
    if (rec->getInFactory() == 0) { result++; }
  }
  return result;
}

/** lookup by palette alias. */
ComponentRecord_shared ComponentFactory::getRecordByPaletteClassName( const char *cname) {
  std::vector< ComponentRecord_shared > & rep = repository;
  ComponentRecord_shared rec;
  for (size_t i = 0; i < rep.size(); i++) {
    rec = rep[i];
    if ( rec->getDeploymentClassAlias().compare(cname) == 0) { return rec; }
  }
  ComponentRecord_shared dummy;
  return dummy;
}

/** lookup by real class name  and library */
ComponentRecord_shared ComponentFactory::getRecordByLibraryClassName( char *lib, char *lcname) {
  std::vector< ComponentRecord_shared > & rep = repository;
  ComponentRecord_shared rec;
  for (size_t i = 0; i < rep.size(); i++) {
    rec = rep[i];
    if (rec->getComponentClassName().compare(lcname) == 0 &&
	rec->getLibraryLocation().compare(lib) == 0)
      { return rec; }
  }
  ComponentRecord_shared dummy;
  return dummy;
}

/*CDELETE*/ ccafeopq::Component * ComponentFactory::createComponentInstance(const std::string & className)
{
  return instantiate(className.c_str());
}

/*CDELETE*/ ccafeopq::Component * ComponentFactory::createComponentInstance(const std::string & className, ccafeopq::TypeMap_shared &tm)
{
  (void)tm; // fixme-feature tm not used in createComponentInstance
  return instantiate(className.c_str());
}

void ComponentFactory::destroyComponentInstance(const std::string & s, ccafeopq::Component *c)
{
  // fixme-feature not used yet.
}
/*
  
*/

//==============================================================
/*CDELETE*/ ccafeopq::Component * ComponentFactory::instantiate(const char *className) {
  IO_dn1("entry");
  if (!cfl_init_done) {
    IO::en("ComponentFactory function called before ComponentFactory::initPalette");
    return (ccafeopq::Component*)0;
  }

  classic::gov::cca::Component * (*create)();
  create = 0;
#ifdef HAVE_NEO
  neo::cca::Component * (*creatNeo)();
  creatNeo = 0;
#endif

  ComponentRecord_shared r = getRecordByPaletteClassName((char*)className);
  if (r == 0) {
    IO::en("ComponentFactory::instantiate called with unknown className %s\n",className);
    return static_cast< ccafeopq::Component* >(0);
  }
  std::string libraryClassName = r->getComponentClassName();
  std::string ct = r->getCCASpecBinding();
  if(ComponentFactory::debug && (ct != "")) {
    fprintf(stderr, "%s: componentType = %s for className = %s\n", 
            __FILE__, r->getCCASpecBinding().c_str(), className);
  }
  IO_dn2("paletteClassAlias = %s", className);
  IO_dn2("libraryClassName = %s", libraryClassName.c_str());
  IO_dn2("r->cFuncName = %s", r->getConstructorName().c_str());
  IO_dn2("r->buildLocation = %s", r->getLibraryLocation().c_str());
  IO_dn2("r->componentType = %s", ct.c_str());

  IO_dn2("componentType = %s", ct.c_str());
  if(ct != "") {
    IO_dn2("strncmp(ct.c_str(), BABEL_TYPE, strlen(BABEL_TYPE)) = %d", 
           strncmp(ct.c_str(), BABEL_TYPE, strlen(BABEL_TYPE)));
  }
  if((ct != "") && 
     (strncmp(ct.c_str(), BABEL_TYPE, strlen(BABEL_TYPE)) == 0)) {
    // each choice inside this if must return.
    
#ifndef HAVE_BABEL
    IO_en2("dccafe was configured and built without cca-spec-babel:%s",
	   "\nTry reconfiguring and rebuilding --with-cca-babel. See ./configure --help.");
    return static_cast< ccafeopq::Component* >(0);
#else // HAVE_BABEL defined
    IO_dn2("Babel Component: %s to be instantiated", libraryClassName.c_str());
    // the metadata xml format now allows babel classes to be palette
    // aliased. so we have to look up the real babel class name.
    // normally this is identical to the babel class name.
    gov::cca::Component babelCmpt;
#if 0 // replacing for 092
      babelCmpt = sidl::Loader::createClass( libraryClassName );
#else
    sidl::DLL dll = sidl::Loader::findLibrary(libraryClassName, "ior/impl", sidl::Scope_SCLSCOPE, sidl::Resolve_SCLRESOLVE);
    if (dll._not_nil()) {
	    babelCmpt = dll.createClass(libraryClassName);
    }

#endif // replacing for 092 end
    if ( babelCmpt._not_nil() ) {
      BabelComponentWrapper * bc = new BabelComponentWrapper(babelCmpt);
      return bc;
    } else {
      IO_en2(":-( You're having a bad day: Could not create Babel component"
             " classname: %s", className);
      std::string bpath = sidl::Loader::getSearchPath();
      IO_en2("sidl::Loader::getSearchPath=%s",bpath.c_str());
      const char *sdbg = getenv("SIDL_DEBUG_DLOPEN");
      if (sdbg != 0) { IO_en2("SIDL_DEBUG_DLOPEN=%s",sdbg); }
      else { IO_en2("SIDL_DEBUG_DLOPEN %s","not set."); }
      const char *sdbg2 = getenv("sidl_DEBUG_DLOPEN");
      if (sdbg2 != 0) { IO_en2("sidl_DEBUG_DLOPEN=%s",sdbg2); }
      else { IO_en2("sidl_DEBUG_DLOPEN %s","not set."); }
      const char *spath = getenv("SIDL_DLL_PATH");
      if (spath != 0) { IO_en2("SIDL_DLL_PATH=%s",spath); }
      const char *lpath = getenv("LD_LIBRARY_PATH");
      if (lpath != 0) { IO_en2("LD_LIBRARY_PATH=%s",lpath); }
      
      if (ComponentFactory::debug) {
      	dumpFactory();
      }
      return static_cast< ccafeopq::Component* >(0);
    }
#endif // HAVE_BABEL defined

  }
  // This applies to classic since we are in charge of loading the
  // component.  In fact it is a bad idea to load Babel code, better
  // to leave that to Babel.
  if ( ! r->getInFactory() ) {
    IO::en("ComponentFactory::instantiate called name of class not loaded %s\n",className);
    IO::en("ComponentFactory::instantiate try repository get-global %s first\n",className);
    IO::en("ComponentFactory::instantiate or repository get %s first\n",className);
    return static_cast< ccafeopq::Component* >(0);
  }
  if( (ct != "") && 
      (strncmp(ct.c_str(), OPAQUE_TYPE, strlen(OPAQUE_TYPE)) == 0)) {
    // each choice inside this if must return.
    // Component of pure type opaque
    ccafeopq::Component * (*creat)();
    creat = (ccafeopq::Component * (*)())(r->getConstructorFunc());
    if(creat != 0) {
      return creat();
    } else {
      IO_en1("ccafeopq::Component creation wrapper is null.");
      return static_cast< ccafeopq::Component* >(0);
    }
  }
  if( (ct != "") && 
      (strncmp(ct.c_str(), NEO_TYPE, strlen(NEO_TYPE)) == 0)) {
#ifdef HAVE_NEO
    // each choice inside this if must return.
    // Component of type neo
    neo::cca::Component * (*creatNeo)();
    creatNeo = (neo::cca::Component * (*)())(r->getConstructorFunc());
    if(creatNeo != 0) {
      ::neo::cca::Component *nc = creatNeo();
      ::ccafeopq::Component * oc = new NeoComponentWrapper(nc);
      return oc;
    } else {
      IO_en1("ccafeopq::Component creation wrapper is null for neo component.");
      return static_cast< ccafeopq::Component* >(0);
    }
#else
    IO_en1("neo component support not configured into framework. Can't do neo components.");
    return static_cast< ccafeopq::Component* >(0);
#endif // HAVE_NEO
  }
  // always default to classic
  create = (classic::gov::cca::Component * (*)())(r->getConstructorFunc());
  if (create != 0) {
    ::classic::gov::cca::Component *cc = create();
    ::ccafeopq::Component * oc = new ClassicComponentWrapper(cc);
    return oc;
  }
  if (create == 0) {
    fprintf(stderr, ":-( Attempt to call a null ptr in %s:%d\n", 
	    __FILE__, 
	    __LINE__);
  }
  
  return static_cast< ccafeopq::Component* >(0);
}

std::vector<std::string> ComponentFactory::getComponentClassAliases() {
  return getPalette();
}

//==============================================================
std::vector<std::string> ComponentFactory::getPalette() {

  // a curious function, because we know on the back side
  // of most getpalette calls the first thing people do
  // is get the JCPN(StringEnumeration) from the vector...

  std::vector< std::string > v;
  if (!cfl_init_done) { 
    IO::en("ComponentFactory::getPalette called before ComponentFactory::initPalette");
    return v;
  }

  ComponentRecord_shared rec;

  for (size_t i = 0; i < repository.size(); i++ )
    {
      rec = repository[i];
      if (rec->getInFactory()) {
	v.push_back(rec->getDeploymentClassAlias());
      }
    }
#if 0 // debug io
  for (size_t j = 0; j < v.size(); j++) 
  {
	  IO_en2("# getPalette: %s",v[j].c_str() );
  }
#endif
  return v;
}

//==============================================================
// register a classic component constructor.
// returns -1 if duplicate class, -2 if factory is still closed.
// return 0 if ok.
int ComponentFactory::addClass(const char *className, 
                               classic::gov::cca::Component * (*create)()) {

  ComponentRecord_shared rec;
  if (cfl_init_done) {
    if (create == 0) {
      IO::en("ComponentFactory::addClass(%s,0) called with null constructor pointer",
             className);
      return -1;
    }
    for (size_t i = 0; i < repository.size(); i++)
      {
	rec = repository[i];
	if ( rec->getDeploymentClassAlias() == className ) {
	  break;
	}
      }
    if (rec == 0) {
      IO::en("ComponentFactory::addClass called with palette name %s not recorded in metadata", className);
      return -1;
    }
    if ( rec->getInFactory() ) {
      IO::en("ComponentFactory::addClass called with duplicate className %s", className);
      return -1;
    }
    rec->setConstructorFunc((void*)create);
  } else {
    IO::en("ComponentFactory::addClass called before ComponentFactory::initPalette");
    return -2;
  }
  return 0;
}
 
//==============================================================
#define CREATEDEF(cxxName)						\
  static classic::gov::cca::Component *create_##cxxName() { return new cxxName(); }

#define MAPNAME(cname,cxxName)						\
  addClass(cname, create_##cxxName); fprintf(stderr,"# factory added %s\n",cname)

//==============================================================
// define the simple constructor function pointers.

#ifdef CCAFE_NO_DL

CREATEDEF(TimeStamper);
// CREATEDEF(RevalidateTest); fixme events
CREATEDEF(Timer);
CREATEDEF(StarterComponent);
CREATEDEF(PrinterComponent);

#endif // CCAFE_NO_DL

//==============================================================
// Define the mapping of string names to C++ classes by adding
// hard-coded types to the palette or check the env(CCA_COMPONENT_PATH) for
// loadable components.
void ComponentFactory::initPalette() {
  if (cfl_init_done) {
    IO::en("ComponentFactory::initPalette called twice!");
    return;
  }

#ifdef CCAFE_NO_DL // defined in a config header if dl not available

  MAPNAME("TimeStamper",        TimeStamper);
  //   MAPNAME("RevalidateTest",     RevalidateTest); fixme events
  MAPNAME("Timer",              Timer);
  MAPNAME("StarterComponent",   StarterComponent);
  MAPNAME("PrinterComponent",   PrinterComponent);

#endif // CCAFE_NO_DL

  cfl_init_done = true;
}

void 
ComponentFactory::setComponentPath(const std::vector< std::string > & p) {
  componentPathEntries.clear();
#ifdef HAVE_BABEL
  // save the old sidl path
  std::string bpath = sidl::Loader::getSearchPath();
  IO_dn2("was sidl::Loader::getSearchPath=%s",bpath.c_str());
  sidl::Loader::setSearchPath("");
#endif
  for (size_t i = 0; i < p.size();  i++) {
    componentPathEntries.push_back(p[i]);
    IO_dn2("Path = %s", p[i].c_str());
#ifdef HAVE_BABEL
    // sidl::Loader::addSearchPath(p[i]); to support arbitrary file suffix,
    // we must add this call.
#endif
  }
#ifdef HAVE_BABEL
  // append old sidl path last so that new path
  // has effect in event of conflict.
  sidl::Loader::addSearchPath(bpath);
  bpath = sidl::Loader::getSearchPath();
  IO_dn2("now sidl::Loader::getSearchPath=%s",bpath.c_str());
#endif
}

/** Set the component path. The array given is null terminated. 
    The path will be searched for dynamically loadable libraries.
    The memory you hand us in this call is not kept.

    The argv given may be empty and may contain unreal paths.
    It is anticipated that the array elements may include a url
    in the future. The framework makes no immediate commitment to
    loading from urls, we simply note that this is the hook, in
    the absence of a more complicated repository interface.

    This call is not required if you want to use only statically
    linked components hardwired into ComponentFactory.cxx.

    For those elements which are file system names:
    A component library is detectable if a file with a name ending
    in .cca is found. Each line of such a file is assumed to contain
    either an un-path-qualified library name or a comment. Comments
    start with # or !. Additional details of the file format
    will be found in the documentation.

    The advisability of loading and executing a component constructor
    (which may entail unresolved symbols if it requires other 
    components/libraries to be loaded first) is not addressed in 
    this interface. It is expected that the dependency issue will
    be addressed at a higher level where more pre-load introspection
    is possible, before a load is required here.

    For those elements which are URLs, the semantics are still
    under-defined. A decent web trusted repository protocol is expected.

*/
void 
ComponentFactory::setComponentPath(const char **pathDirArgv)
{
  if (!cfl_init_done) {
    IO::en("ComponentFactory function called before ComponentFactory::initPalette");
    return;
  }
  std::vector< std::string > vals;
  if (pathDirArgv == 0) { return; }
  for (int i = 0; pathDirArgv[i] != 0;  i++) {
    vals.push_back(pathDirArgv[i]);
  }
  setComponentPath(vals);
}

std::vector< std::string> ComponentFactory::getComponentPath() {
  if (!cfl_init_done) {
    IO::en("ComponentFactory function called before ComponentFactory::initPalette");
  }
  return componentPathEntries;
}


std::vector< std::string> ComponentFactory::getParsedFiles()
{
  if (!cfl_init_done) {
    IO::en("ComponentFactory function called before ComponentFactory::initPalette");
  }
  
  IO_en2("ComponentFactory::getParsedFiles: %d files",(int)parsedFiles.size());
  return parsedFiles;
}


extern "C" {
  static int ComponentFactory_glob_whine(const char *epath, int eerrno)
  {
    IO::en("ComponentFactory::searchComponentPath: open failed for %s -- %s.",
	   epath, strerror(eerrno));
    return 0;
  }
} // end C

// cast to get around incomplete ibm prototype for glob errfunc
// under aix /usr/include has a broken glob header, in the protoized part,
// omits the args to glob errfunc argument.
#ifndef OS_AIX
#define FIX_BROKEN_IBM(f) f
#else
#define FIX_BROKEN_IBM(f) ( (int (*)())(f) )
#endif

void ComponentFactory::indexComponentPath()
{
  searchComponentPath();
}

int ComponentFactory::searchComponentPath()
{

  if (!cfl_init_done) {
    IO::en("ComponentFactory function called before ComponentFactory::initPalette");
    return 0;
  }

  if (componentPathEntries.size() < 1) {
    return 0;
  }

#define INDEX_PAT "/*.cca"
  glob_t globbuf;
  globbuf.gl_offs = 0;

  std::string entry;
  size_t i;
  for (i = 0; i < componentPathEntries.size() ; i++) {
    entry = componentPathEntries[i];
    entry += INDEX_PAT;
    const char *pat;
    pat = entry.c_str();
    int err = glob(pat, ((!i)?GLOB_MARK:(GLOB_MARK|GLOB_APPEND)),
                   FIX_BROKEN_IBM(ComponentFactory_glob_whine) , &globbuf);

    switch (err) {
    case GLOB_NOSPACE:
      IO::en("ComponentFactory::searchComponentPath: malloc fail in glob.");
      break;
#ifndef MACOSX
    case GLOB_ABORTED:
      IO::en("ComponentFactory::searchComponentPath: glob aborted unexpectedly.");
      break;
    case GLOB_NOMATCH:
      IO::en("ComponentFactory::searchComponentPath: Empty list -- %s.", pat);
      break;
#else
    case GLOB_ERR:
      IO::en("ComponentFactory::searchComponentPath: unexpected error from glob.");
      break;
#endif // MACOSX
    default:
      break;
    }
  }

  for (i = 0 ; i < globbuf.gl_pathc ; i++) {
    char *p = globbuf.gl_pathv[i];
    // here's our policy not to reread an index file once read or read dirs.
    if (p[strlen(p)-1] != PATHSEP && !checkAlreadyLoaded( p)) {
      ccafe::DotCCAComponentCore dccc;
      std::string fpath = p;
      std::vector< ::ccafeopq::ComponentClassDescription_shared > ccdv = dccc.parseDescriptions( fpath );
      parsedFiles.push_back(fpath);
#ifdef HAVE_BABEL
      sidl::Loader::addSearchPath( fpath );
#endif // HAVE_BABEL
      // ccafe_repository
      for (size_t j = 0 ; j < ccdv.size(); j++)
	{
	  // bounce duplicates
	  ComponentRecord_shared oldrec;
	  std::vector< ComponentRecord_shared > & rep = repository;
	  bool duplicate = false;
	  for (size_t i = 0; i < rep.size(); i++) {
	    oldrec = rep[i];
	    if (oldrec->getDeploymentClassAlias() == ccdv[j]->getDeploymentClassAlias() ||
		oldrec->getComponentClassName() == ccdv[j]->getComponentClassName() )
	      {
		duplicate = true;
		break;
	      }
	  }
	  if (duplicate)
	    {
	      IO::en("ComponentFactory::searchComponentPath: class name or alias (%s alias %s) duplicates one already found. It is ignored.",
		     ccdv[j]->getComponentClassName().c_str(),
		     ccdv[j]->getDeploymentClassAlias().c_str());
	      continue;
	    }

	  ccafe::ComponentRecord_Impl *cri = new ccafe::ComponentRecord_Impl();
	  assert(cri != 0);
	  ComponentRecord_shared rec(cri);
	  rec->setFoundInPath(true);
	  rec->setCCD(ccdv[j]);
	  repository.push_back(rec);
	  rec.reset();
	}
    }
  }

  globfree(&globbuf);

  int result = countUnloadedClasses();
  return result; 
}

std::vector< std::string > ComponentFactory::getLoadedLibraries() {
  if (!cfl_init_done) {
    IO::en("ComponentFactory function called before ComponentFactory::initPalette");
  }
  ::std::map< ::std::string, void * >::iterator pos;
  std::vector< std::string > result;
  pos = loadedLibraries.begin();
  while (pos != loadedLibraries.end())
    {
      result.push_back(pos->first);
    }
  return result; // iterate over map loadedLibraries?
}


/** Returns the list of tuples, library:component pairs, describing
    what is currently dynamically loaded. The list is hence of an
    even length since each pair is kept as successive elements, in
    {library, component} order. Due to possible syntax of urls
    and class names in namespaces, we do not try to combine these
    into a single string per component loaded, though this is
    surely doable by the thoughtful.

    This method, unfortunately, must be global in scope since
    we don't want to be redundantly loading libraries.
    This is probably a function useful only to the outermost
    framework/container. GetPalette is what users want to see.
*/
std::vector< std::string > ComponentFactory::getLoadedComponents() {
  std::vector< std::string > dummy;
  if (!cfl_init_done) {
    IO::en("ComponentFactory function called before ComponentFactory::initPalette");
    return dummy;
  }

  ComponentRecord_shared rec;
  std::vector< ComponentRecord_shared > & rep = repository;
  for (size_t i = 0; i < rep.size(); i++) {
    rec = rep[i];
    if (rec->getInFactory()) {
      dummy.push_back(rec->getLibraryName());
      dummy.push_back(rec->getComponentClassName());
    }
  }
  return dummy;
}

std::vector< std::string > ComponentFactory::getUnloadedComponents() {
  std::vector< std::string > dummy;
  if (!cfl_init_done) {
    IO::en("ComponentFactory function called before ComponentFactory::initPalette");
    return dummy;
  }

  ComponentRecord_shared rec;
  std::vector< ComponentRecord_shared > & rep = repository;
  for (size_t i = 0; i < rep.size(); i++) {
    rec = rep[i];
    if ( ! rec->getInFactory()) {
      dummy.push_back(rec->getLibraryName());
      dummy.push_back(rec->getComponentClassName());
    }
  }
  return dummy;
}

std::vector< ccafeopq::ComponentClassDescription_shared > ComponentFactory::getComponentClasses() {
  std::vector< ccafeopq::ComponentClassDescription_shared > dummy;
  if (!cfl_init_done) {
    IO::en("ComponentFactory function called before ComponentFactory::initPalette");
    return dummy;
  }

  ComponentRecord_shared rec;
  std::vector< ComponentRecord_shared > & rep = repository;
  for (size_t i = 0; i < rep.size(); i++) {
    rec = rep[i];
    dummy.push_back(rec);
  }
  return dummy;
}

//
int ComponentFactory::loadPorts(const std::string & libPathName) {

  if (! cfl_init_done) {
    IO::en("ComponentFactory function called before ComponentFactory::initPalette");
    return 0;
  }
  int err = CCA_LoadPorts(const_cast<char *>(libPathName.c_str()),1);
  return err;
}

// do dl stuff, privately.
int ComponentFactory::loadPalette(const char *soName, const char *mapName, const char *cFuncName, bool global, bool lazy, const char * cmptType, const char * soDir) {

  if (! cfl_init_done) {
    IO::en("ComponentFactory function called before ComponentFactory::initPalette");
    return 0;
  }
  std::string sfilename = soDir;
  sfilename += "/";
  sfilename += soName;
  IO_dn3("mapName = %s, cmptType = %s", mapName, cmptType);

  // If we want to leave the babel components alone.
  // for the pure-virtual based components (opq,neo,classic,
  // we cheat and c-cast all types for purposes of addClass
  // to classic.
  // probably would have been better off keeping void* explicitly.
  if((cmptType == 0) || 
     (strncmp(cmptType, OPAQUE_TYPE, strlen(OPAQUE_TYPE)) == 0) ||
#ifdef HAVE_NEO
     (strncmp(cmptType, NEO_TYPE, strlen(NEO_TYPE)) == 0) ||
#endif // HAVE_NEO
     (strncmp(cmptType, CLASSIC_TYPE, strlen(CLASSIC_TYPE)) == 0))
    {

      // update classname, assuming coherence of cfuncname
      classic::gov::cca::Component * (*create)();
      create = 
	(classic::gov::cca::Component * (*)())CCA_IntrospectLibrary(
								    (char *) sfilename.c_str(), (char *)cFuncName,
								    (global ? 0 : 1), 
								    (global ? 1 : 0), 
								    (lazy ? 1 : 0), 
								    (lazy ? 0 : 1), 
								    1);
      int err;
      err = addClass(mapName, create);
      if (err) {
	IO::en("# factory bounced(%d) {%s}:{%s} as %s\n",
	       err,(sfilename.c_str()), cFuncName, mapName);
	return err;
      }
      loadedLibraries[sfilename] = (void*)8; // dummy entry
      IO::en("# factory added {%s}:{%s} as %s\n",
	     (sfilename.c_str()), cFuncName, mapName);
      return 0;

    } else {

    if(strncmp(cmptType, BABEL_TYPE, strlen(BABEL_TYPE)) == 0) 
      {
#ifndef HAVE_BABEL
	fprintf(stderr,"CCAFFEINE configured WITHOUT babel and babel components.\n"
		"I hope you're not trying to load a babel component.\n"
		"Reconfigure with --with-cca-babel=/something and remake if you need babel.\n");
	return -1;
#else

	// It is a babel component
	int err = 0;
	IO_dn2("mapName = %s", mapName);

	// Dummy function for Babel components
	classic::gov::cca::Component * (*babel_dummy_loader)();
	babel_dummy_loader = &babelDummyLoader;
	err = addClass(mapName, babel_dummy_loader);

	IO_dn2("err = %d", err);
	return err;
#endif
      }
    IO_en1("Unrecognized componentType option in \".cca\" file");
    return -1;
  }
}

void ComponentFactory::dumpFactory()
{
  std::cout << "------- repository dump  ------" << std::endl;
  for (size_t i = 0; i < repository.size(); i++)
    {
      std::cout << "--------" << repository[i]->getDeploymentClassAlias() << "----------" << std::endl;
      std::cout << repository[i]->toString() << std::endl;
    }
  std::cout << "------- done ------" << std::endl;
}
void ComponentFactory::loadComponentDescription(const std::string & uri)
{
  readComponentDescription(uri);
}

void ComponentFactory::readComponentDescription(const std::string & uri)
{
  // FIXME -- needs to be refactored so search and read have
  // mostly common implementation.
  // parse uri file, // add description, // set 'notglobd' flag in description
  if (uri == std::string("")) {
    return;
  }
  const char *p = uri.c_str();
  // here's our policy not to reread an index file once read or read dirs.
  if (p[strlen(p)-1] != PATHSEP && !checkAlreadyLoaded( p)) {
    ccafe::DotCCAComponentCore dccc;
    std::string fpath = p;
    std::vector< ::ccafeopq::ComponentClassDescription_shared > ccdv = dccc.parseDescriptions( fpath );
    parsedFiles.push_back(fpath);
    for (size_t j = 0 ; j < ccdv.size(); j++)
      {
	// bounce duplicates
	ComponentRecord_shared oldrec;
	std::vector< ComponentRecord_shared > & rep = repository;
	bool duplicate = false;
	for (size_t i = 0; i < rep.size(); i++) {
	  oldrec = rep[i];
	  if (oldrec->getDeploymentClassAlias() == ccdv[j]->getDeploymentClassAlias() ||
	      oldrec->getComponentClassName() == ccdv[j]->getComponentClassName() )
	    {
	      duplicate = true;
	      break;
	    }
	}
	if (duplicate)
	  {
	    IO::en("ComponentFactory::readComponentDescription: class name or alias (%s alias %s) duplicates one already found. It is ignored.",
		   ccdv[j]->getComponentClassName().c_str(),
		   ccdv[j]->getDeploymentClassAlias().c_str());
	    continue;
	  }

	ccafe::ComponentRecord_Impl *cri = new ccafe::ComponentRecord_Impl();
	assert(cri != 0);
	ComponentRecord_shared rec(cri);
	rec->setFoundInPath(false);
	rec->setCCD(ccdv[j]);
	repository.push_back(rec);
	rec.reset();
      }
  }
}

void 
ComponentFactory::loadClass(const std::string className, bool global, bool lazy) {
  loadPalette(className,global,lazy);
}

int 
ComponentFactory::loadPalette(const std::string& className, 
			      bool global, 
			      bool lazy) { 
  return loadPalette(className.c_str(), global, lazy);
}

// by unique class name
int ComponentFactory::loadPalette(const char *className, bool global, bool lazy) { 
  if (!cfl_init_done) {
    IO::en("ComponentFactory function called before ComponentFactory::initPalette");
    return 0;
  }

  ComponentRecord_shared rec;
  rec = getRecordByPaletteClassName(className);
  if (rec == 0) {
    IO::en("ComponentFactory::loadPalette(%s) failed (unknown component).",
           className);
    return -1;
  }
  if (!rec->getInFactory()) {
    return loadPalette(rec->getLibraryName().c_str(), className, 
		       rec->getConstructorName().c_str(), 
		       global, 
		       lazy,
		       rec->getCCASpecBinding().c_str(), rec->getLibraryLocation().c_str());
  }
  IO::en("ComponentFactory::loadPalette(%s) failed (already loaded).",
         className);
  return -1;
}

//==============================================================================
#if 0 // argv

void ComponentFactory::destroyArgv(char **&argv) {
  if (argv == 0) { return; }
  for (int i = 0; argv[i] != 0; i++) {
    free(argv[i]);
    argv[i] = 0;
  }
  free(argv);
  argv = 0;
}

int ComponentFactory::sizeofArgv(char **argv) {
  if (argv==0) { return -1; }
  int i = 0;
  while (argv[i] !=0) {
    i++;
  }
  return i;
}

/* CFREE */ char ** ComponentFactory::copyArgv(char **argv) {
  int argc;
  char **newArgv;

  argc = sizeofArgv(argv);
  newArgv = (char **)malloc(sizeof(char *)*(argc+1));

  for (int i = 0; i <= argc; i++) { 
    newArgv[i] = argv[i]; 
  }

  return newArgv;
 
}

char **ComponentFactory::appendArgv(char **&argv, char *string) {

  char **newArgv;
  // new case
  if (argv==0) {
    // malloc argv and add string
    newArgv = (char **)malloc(sizeof(char *)*(2));
    newArgv[0] = newArgv[1] = 0;
    if (string !=0) {
      newArgv[0] = string;
    }
    return newArgv;
  }
  // noop case
  if (string == 0) { 
    return argv;
  }
  // expand/replace case
  int argc;
  argc = sizeofArgv(argv);
  newArgv = (char **)malloc(sizeof(char *)*(argc+2));
  for (int i = 0; i < argc; i++) { 
    newArgv[i] = argv[i]; 
    argv[i] = 0; 
  }
  newArgv[argc] = string;
  newArgv[argc+1] = 0;
  free(argv);
  return newArgv;
}

#endif // 0 dump argv
