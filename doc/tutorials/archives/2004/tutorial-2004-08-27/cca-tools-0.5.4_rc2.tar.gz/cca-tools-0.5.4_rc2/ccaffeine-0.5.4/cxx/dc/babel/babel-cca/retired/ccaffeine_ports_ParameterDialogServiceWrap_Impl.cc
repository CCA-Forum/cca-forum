// 
// File:          ccaffeine_ports_ParameterDialogServiceWrap_Impl.cc
// Symbol:        ccaffeine.ports.ParameterDialogServiceWrap-v0.3
// Symbol Type:   class
// Description:   Server-side implementation for ccaffeine.ports.ParameterDialogServiceWrap
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "ccaffeine_ports_ParameterDialogServiceWrap_Impl.hh"

// DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap._includes)

// user defined constructor
void ccaffeine::ports::ParameterDialogServiceWrap_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap._ctor)
  // add construction details here
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap._ctor)
}

// user defined destructor
void ccaffeine::ports::ParameterDialogServiceWrap_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap._dtor)
  // add destruction details here
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap._dtor)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * passed in is a void * cast pointer of
 *  ccafeopq::ParameterDialogService.
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::initialize (
  /*in*/ void* ccafeopq_ParameterDialogService_port_ptr ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.initialize)
#if ENABLE_DEPRECATED_NAMESPACE
	opds = static_cast< ::ccafeopq::ParameterDialogService *>(ccafeopq_ParameterDialogService_port_ptr);
#endif
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.initialize)
}

/**
 * fetch up a pointer for static casting. if the name
 * supplied is not exactly right, returns null.
 */
void*
ccaffeine::ports::ParameterDialogServiceWrap_impl::getWrapped (
  /*in*/ const ::std::string& className ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.getWrapped)
  // insert implementation here
#if ENABLE_DEPRECATED_NAMESPACE
	return static_cast<void *>(opds);
#else
	return 0;
#endif
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.getWrapped)
}

/**
 * Initialize the portData for use as a parameter dialog port
 *  with name portName.
 *  More than one such port can be defined. Each must
 *  be published before the next can be created.
 *  The given string portName will appear in the TypeMap
 *  as the result of this function and must not be changed
 *  by the component henceforth. It will appear under the key
 *  "ParameterDialogService.portName",
 *  @param portData the typemap associated with the port;
 *       It is shared between the ParameterDialogService
 *       and the component. The ParameterDialogService will
 *       not read or change values in portData except those
 *       requested via the addRequest functions.
 *  @param portName The name of a ParameterPort to appear in
 *       user interface one way or another.
 *  
 * 
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::createParameterPort (
  /*inout*/ ::gov::cca::TypeMap& portData,
  /*in*/ const ::std::string& portName ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.createParameterPort)
  // insert implementation here
	// FIXME createParameterPort
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.createParameterPort)
}

/**
 * Define the window title for the parameter dialog.
 * 
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::setBatchTitle (
  /*in*/ ::gov::cca::TypeMap portData,
  /*in*/ const ::std::string& title ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.setBatchTitle)
  // insert implementation here
	// FIXME setBatchTitle
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.setBatchTitle)
}

/**
 * Define the next tab/group title to use. All
 * addRequest subsequent calls will add to this group.
 * Multiple dialog tabs/groups can be defined in this way.
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::setGroupName (
  /*in*/ ::gov::cca::TypeMap portData,
  /*in*/ const ::std::string& newGroupName ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.setGroupName)
  // insert implementation here
	// FIXME setGroupName
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.setGroupName)
}

/**
 * Define a boolean parameter and its default state.
 * The configured value is always available by
 * portData->getBool(name, ...);
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::addRequestBoolean (
  /*in*/ ::gov::cca::TypeMap portData,
  /*in*/ const ::std::string& name,
  /*in*/ const ::std::string& help,
  /*in*/ const ::std::string& prompt,
  /*in*/ bool deflt ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.addRequestBoolean)
  // insert implementation here
	// FIXME addRequestBoolean
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.addRequestBoolean)
}

/**
 * Define a int parameter and its default state.
 * The configured value is always available by
 * portData->getInt(name, ...) and it will be
 * in the range [low, high].
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::addRequestInt (
  /*in*/ ::gov::cca::TypeMap portData,
  /*in*/ const ::std::string& name,
  /*in*/ const ::std::string& help,
  /*in*/ const ::std::string& prompt,
  /*in*/ int32_t deflt,
  /*in*/ int32_t low,
  /*in*/ int32_t high ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.addRequestInt)
  // insert implementation here
	// FIXME addRequestInt
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.addRequestInt)
}

/**
 * Define a long parameter and its default state.
 * The configured value is always available by
 * portData->getLong(name, ...) and it will be
 * in the range [low, high].
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::addRequestLong (
  /*in*/ ::gov::cca::TypeMap portData,
  /*in*/ const ::std::string& name,
  /*in*/ const ::std::string& help,
  /*in*/ const ::std::string& prompt,
  /*in*/ int64_t deflt,
  /*in*/ int64_t low,
  /*in*/ int64_t high ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.addRequestLong)
  // insert implementation here
	// FIXME addRequestLong
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.addRequestLong)
}

/**
 * Define a float parameter and its default state.
 * The configured value is always available by
 * portData->getFloat(name, ...) and it will be
 * in the range [low, high].
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::addRequestFloat (
  /*in*/ ::gov::cca::TypeMap portData,
  /*in*/ const ::std::string& name,
  /*in*/ const ::std::string& help,
  /*in*/ const ::std::string& prompt,
  /*in*/ float deflt,
  /*in*/ float low,
  /*in*/ float high ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.addRequestFloat)
  // insert implementation here
	// FIXME addRequestFloat
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.addRequestFloat)
}

/**
 * Define a double parameter and its default state.
 * The configured value is always available by
 * portData->getDouble(name, ...) and it will be
 * in the range [low, high].
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::addRequestDouble (
  /*in*/ ::gov::cca::TypeMap portData,
  /*in*/ const ::std::string& name,
  /*in*/ const ::std::string& help,
  /*in*/ const ::std::string& prompt,
  /*in*/ double deflt,
  /*in*/ double low,
  /*in*/ double high ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.addRequestDouble)
  // insert implementation here
	// FIXME addRequestDouble
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.addRequestDouble)
}

/**
 * Define a string parameter and its default state.
 * The configured value is always available by
 * portData->getString(name, ...).
 * If no addRequestStringChoice calls are made, the
 * user input may be any string. If addRequestStringChoice
 * is used, the value will be one among the choices.
 * If addRequestStringChoice is used, deflt must
 * be among the choices defined.
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::addRequestString (
  /*in*/ ::gov::cca::TypeMap portData,
  /*in*/ const ::std::string& name,
  /*in*/ const ::std::string& help,
  /*in*/ const ::std::string& prompt,
  /*in*/ const ::std::string& deflt ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.addRequestString)
  // insert implementation here
	// FIXME addRequestString
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.addRequestString)
}

/**
 * define a new choice for a string parameter.
 * If no calls to this function are made for a given
 * name, then any form of string will be acceptable input. 
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::addRequestStringChoice (
  /*in*/ ::gov::cca::TypeMap portData,
  /*in*/ const ::std::string& name,
  /*in*/ const ::std::string& choice ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.addRequestStringChoice)
  // insert implementation here
	// FIXME addRequestStringChoice
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.addRequestStringChoice)
}

/**
 * Clear all previously added requests, titles, groups. After
 *  this call, it is as if the ParameterPort has
 *  been created but never configured. The values of
 *  previously defined parameters will, nonethesless,
 *  remain in the typemap.
 *  Typically, this is used only by someone implementing
 *  the updateParameterPort function from
 *  interface ParameterGetListener.
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::clearRequests (
  /*in*/ ::gov::cca::TypeMap portData ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.clearRequests)
  // insert implementation here
	// FIXME clearRequests
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.clearRequests)
}

/**
 * Register listener (the component) that wishes to have
 * a chance to change the contents of its ParameterPort
 * just before the parameters typemap is used to
 * render the parameter dialog.
 * @param powner a pointer to the listener that will be
 * forgotten when it is no longer needed. 
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::setUpdater (
  /*in*/ ::gov::cca::TypeMap portData,
  /*in*/ ::gov::cca::ports::ParameterGetListener powner ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.setUpdater)
  // insert implementation here
	// FIXME setUpdater
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.setUpdater)
}

/**
 * Register listener (the component) if it wishes to be
 * informed when an parameter is set.
 * Listeners are called after values are set.
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::setUpdatedListener (
  /*in*/ ::gov::cca::TypeMap portData,
  /*in*/ ::gov::cca::ports::ParameterSetListener powner ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.setUpdatedListener)
  // insert implementation here
	// FIXME setUpdatedListener
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.setUpdatedListener)
}

/**
 * Signal that the ParameterPort is fully defined and should
 * now pop out on the component. The Services passed here
 * must be the component's own Services handle.
 * The ParameterDialogService takes care of addProvidesPort
 * and task delegation.
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::publishParameterPort (
  /*in*/ ::gov::cca::TypeMap portData,
  /*in*/ ::gov::cca::Services svc ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.publishParameterPort)
  // insert implementation here
	// FIXME publishParameterPort
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.publishParameterPort)
}

/**
 * Cause a previously defined parameter port to go away.
 * This function should be called at component shutdown
 * (setService(0)) time for any parameter ports that have
 * been published but not yet unpublished.
 * The ParameterDialogService takes care of removeProvidesPort.
 */
void
ccaffeine::ports::ParameterDialogServiceWrap_impl::unpublishParameterPort (
  /*in*/ ::gov::cca::TypeMap portData,
  /*in*/ ::gov::cca::Services svc ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap.unpublishParameterPort)
  // insert implementation here
	// FIXME unpublishParameterPort
  // DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap.unpublishParameterPort)
}


// DO-NOT-DELETE splicer.begin(ccaffeine.ports.ParameterDialogServiceWrap._misc)
// Put miscellaneous code here
// DO-NOT-DELETE splicer.end(ccaffeine.ports.ParameterDialogServiceWrap._misc)

