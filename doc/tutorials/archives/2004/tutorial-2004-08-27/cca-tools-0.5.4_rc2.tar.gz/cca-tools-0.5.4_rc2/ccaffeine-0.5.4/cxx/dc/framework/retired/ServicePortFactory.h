#ifndef __SERVICEPORTFACTORY_H_
#define __SERVICEPORTFACTORY_H_

class ServicePortFactory {
 public:
  virtual ~ServicePortFactory(){}
  /** Return the name of the Service that this factory creates. */
  virtual const char* getType() = 0;
  /** Create the service. */
  virtual ccafeopq::Port* create() = 0;
};

#endif // __SERVICEPORTFACTORY_H_
