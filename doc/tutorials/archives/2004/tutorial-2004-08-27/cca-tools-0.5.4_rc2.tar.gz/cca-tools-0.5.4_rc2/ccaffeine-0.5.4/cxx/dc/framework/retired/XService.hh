#if 0 // deprecated. gone soon
#ifndef __XSERVICE_HH__
#define __XSERVICE_HH__

/** An external Service provided by a component.*/
class Gizzard;

class XService {
private:
  Gizzard * giz;
  ::std::string portInstanceName;
public:
  XService(Gizzard * giz, ::std::string & portInstanceName);
  virtual ~XService(){}
  ccafeopq::Port * getPort();
};

typedef boost::shared_ptr< XService > XService_ptr;

#endif // __XSERVICE_HH__
#endif
