#ifndef Signaler_h_seen
#define Signaler_h_seen

class PipeFitter; 
// don't want to expose a FILE * in the
// component public header.

/**
This component implements watching in one thread for
a signal string on a pipe while answering calls in the
main thread to check the status of the pipe.
When properly configured, any fixed number of components
can use this one. This one will happily live without
being used.

Since it's a pipe connected to an outside source,
we use strings rather than some system defined
integer values. Think of the pipe as the OS.
The outside source, however, can only raise
(not lower) a signal.

As it turns out, the clients can also raise
signals to each other, though this may be
a bad idea. The parallel model for this is
that all processes call raise, and then
a global gather takes place. If anyone
raised anything other than SIGOK, the
other raised signals get queued to all
processes. The natural thing to do after
a call to raise() is a call to check()
or to getAll().

Since it's just strings, the clients in the main
thread are free to IGNORE signals from the pipe,
thus calling it signals at all is stretching
the point a bit.

SIGOK      Do nothing. (CCA)
SIGHUP     Hangup (POSIX).  
SIGINT     Interrupt (ANSI).  
SIGQUIT    Quit (POSIX).  
SIGILL     Illegal instruction (ANSI).  
SIGTRAP    Trace trap (POSIX).  
SIGABRT    Abort (ANSI).  
SIGIOT     IOT trap (4.2 BSD).  
SIGBUS     BUS error (4.2 BSD).  
SIGFPE     Floating-point exception (ANSI).  
SIGKILL    Kill, unblockable (POSIX).  
SIGUSR1    User-defined signal 1 (POSIX).  
SIGSEGV    Segmentation violation (ANSI).  
SIGUSR2    User-defined signal 2 (POSIX).  
SIGPIPE    Broken pipe (POSIX).  
SIGALRM    Alarm clock (POSIX).  
SIGTERM    Termination (ANSI).  
SIGSTKFLT  Stack fault.  
SIGCLD     Same as SIGCHLD (System V).  
SIGCHLD    Child status has changed (POSIX).  
SIGCONT    Continue (POSIX).  
SIGSTOP    Stop, unblockable (POSIX).  
SIGTSTP    Keyboard stop (POSIX).  
SIGTTIN    Background read from tty (POSIX).  
SIGTTOU    Background write to tty (POSIX).  
SIGURG     Urgent condition on socket (4.2 BSD).  
SIGXCPU    CPU limit exceeded (4.2 BSD).  
SIGXFSZ    File size limit exceeded (4.2 BSD).  
SIGVTALRM  Virtual alarm clock (4.2 BSD).  
SIGPROF    Profiling alarm clock (4.2 BSD).  
SIGWINCH   Window size change (4.3 BSD, Sun).  
SIGPOLL    Pollable event occurred (System V).  
SIGIO      I/O now possible (4.2 BSD).  
SIGPWR     Power failure restart (System V).  
*/

class Signaler : public virtual Component {

private:

  Services *core;

  DefaultParameterPort *pp; 
   // n-conns, queue values

public:

  PipeFitter *pf;
  int setPipeFitter(PipeFitter *pf_);

  Signaler();
  ~Signaler();

  void setServices(Services *cc);

  /** Causes the configured pipes to be
     opened and the train of stupidity
     to leave the station. In particular,
     calling go causes the component to
     addProvides nconns-1 SignalPorts on the
     Services object. You get 1 by default.
     Go also starts the secondary thread.
     Go does not block once communication
     on the back-channel is established.
  */
  int go();

  // SignalPort.h:

    /** returns 1 if the local processor
    // has the name given in its
    // queue. returns 0 otherwise. */
  int check(char *signame);

    /** Returns a NULL terminated list
    // of the currently raised signals.
    // SIGOK never appears. The array
    // returned should be freed when
    // the caller is done. The pointers
    // (strings) in the array are NOT
    // to be freed.
    // Because of the threading, the
    // contents of getCurrent may be
    // less than complete if you keep
    // it around very long. */
  CFREE char **getCurrent();

    /** Add one of the known signals to the
    // list currently raised.
    // In parallel implementation, this
    // involves a Barrier. Collective.
    // Unrecognized signals are mapped
    // to SIGKILL, with vituperation.
    // Source given may be NULL.
    // When SIGKILL is raised, the nanoseconds
    // that remain in the life of the
    // secondary thread become numbered. */
  void raise(char *signame, char *source);

  /* clear and clearAll cause the signals
     cleared to go on the out pipe to the
     outside signal source, while clearing.
   */
    /** Removes the signal given from the
    // queue on the local processor. */
  void clear(char *signame);

    /** Empty the signal queue on the
    // local processor. */
  void clearAll();

};
#endif //Signaler_h_seen
