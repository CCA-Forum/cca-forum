class Caffeine_Port_DynamicLink {
private:
  CCA_BlockDescription* bd;
  CCA_DoubleBlock* db;
  int iSave;
public:
  Caffeine_Port_DynamicLink(int i);
  virtual ~Caffeine_Port_DynamicLink();
};
