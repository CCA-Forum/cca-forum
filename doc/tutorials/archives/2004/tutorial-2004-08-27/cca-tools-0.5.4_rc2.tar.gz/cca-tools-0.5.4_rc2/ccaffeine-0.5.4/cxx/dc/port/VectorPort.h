#ifndef VectorPort_seen
#define VectorPort_seen

/** VectorPort for use in applications exchanging data via
    ESI_Vectors.
    @author Ben Allan, 9/30/1999, Sandia National Laboratories.
    @version $Id: VectorPort.h,v 1.7 2002/12/19 20:20:51 baallan Exp $
 */
//class ESI_Vector;
/** the user of this port should also
/ -I$(ESI_ROOT)
/#include "esi/ESI_Vector.h"
/ the implementer of this port will probably need to
/ -I$(ESI_SNL)
/#include "esi_Vector_snl.h"
*/

/* interface */
class VectorPort : public virtual classic::gov::cca::Port {

  public:

    virtual ~VectorPort(){}

      /** Request that the owner of the vector do whatever it does
       to recompute the vector associated with this port.
       (This may be a NOP). */
    virtual int compute() =0;

      /** Tell the owner of the vector that you have done something
       to the data in the vector associated with this port.
       (This may be a NOP). */
    virtual int update() =0;

      /** Extract the data object from this port. The component
       implementation will reference count based on this.
      
       The component implementation *shall* persist based on
       this, meaning that while a getVector is outstanding the
       component cannot respond to another getVector() on the
       same port without sending back the same object and that
       while a getVector is outstanding, the component will not
       under the table destroy the object that is outstanding.
      
       The component implementation *may* lock on this,
       meaning it chooses not to perform any functions that 
       require changing the data values in the object. */
    virtual ESI_Vector<esi_real8,esi_int4> *getVector() =0;

      /** Opposite of getVector. After a release call,
       the vector pointer previously obtained becomes
       undefined. */
    virtual void releaseVector(ESI_Vector<esi_real8,esi_int4> *v) =0;
};
#endif //VectorPort_seen
