#ifndef __STRINGListenerDIRECTPORT_H__
#define __STRINGListenerDIRECTPORT_H__

/** OBSOLETE. DO NOT USE. */
class StringListenerDirectPort : public virtual classic::gov::cca::Port {
  public:
  virtual ~StringListenerDirectPort(){}
    /** When fire is called, the component which implements
    /// this interface generates some event which causes
    /// a string response from  */
  virtual CFREE char *fire() = 0;
};
#endif //__STRINGListenerDIRECTPORT_H__
