#ifndef ClockPort_seen
#define ClockPort_seen

/** ClockPort for use in applications exchanging data about
    mathematical time, such as in simulation.
    @author Ben Allan, 11/12/1999, Sandia National Laboratories.
    @version $Id: ClockPort.h,v 1.6 2002/12/19 20:20:50 baallan Exp $
 */
class ClockPort : public virtual classic::gov::cca::Port {

  public:

    virtual ~ClockPort(){}
    virtual double getClock() =0;
};
#endif //ClockPort_seen
