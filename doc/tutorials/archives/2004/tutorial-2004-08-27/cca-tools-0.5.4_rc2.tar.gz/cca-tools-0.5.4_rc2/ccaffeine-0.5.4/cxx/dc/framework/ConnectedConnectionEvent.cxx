#include "dc/export/AllExport.hh"
#include <cca.h>
#include <ports/AllEvents.h>
#include "dc/framework/ConnectionID.h"
#include "dc/framework/UserPortData.h"
#include "dc/framework/ProviderPortData.h"


#include "dc/framework/ConnectedConnectionEvent.h"
#include "util/TypeMap.h"
#include "dc/classic/ccafe-bind/AllCcafeBind.hh"

namespace {
char id[]=
"$Id: ConnectedConnectionEvent.cxx,v 1.5 2004/01/21 06:21:55 baallan Exp $";
} ENDSEMI

ConnectedConnectionEvent::~ConnectedConnectionEvent( )
{ 
  if (killpi) {
    delete cpi;
  }
  cpi = 0;
  pi = 0;
}

ConnectedConnectionEvent::ConnectedConnectionEvent( UserPortData & upd) 
// : ctm(upd.getUserPortProperties()) 
{ 
  ctm = upd.getUserPortProperties();
  ::std::string tpn = upd.getPortName();
  ::std::string tpt = upd.getPortType();
  pi = new OpqPortInfo(tpn, tpt, ctm);
  cpi = new ClassicPortInfo(pi);
  killpi = true;
}

ConnectedConnectionEvent::ConnectedConnectionEvent( ProviderPortData & ppd) 
//  : ctm(ppd.getProviderPortProperties()) 
{ 
  ctm =  ppd.getProviderPortProperties();
  ::std::string tpn = ppd.getPortName();
  ::std::string tpt = ppd.getPortType();
  pi = new OpqPortInfo(tpn, tpt, ctm);
  cpi = new ClassicPortInfo(pi);
  killpi = true;
}

/** True if the event informs a connection. (always) */
int ConnectedConnectionEvent::connected() {
  return true;
}

/** True if the event informs a disconnection (never) */
int ConnectedConnectionEvent::disconnected() {
  return false;
}

/** Get the PortInfo of the affected Port. */
classic::gov::cca::PortInfo *ConnectedConnectionEvent::getPortInfo() {
  return cpi; 
}

void * ConnectedConnectionEvent::getOpqTypeMapSharedPtrAddress()
{
	::ccafeopq::TypeMap_shared * ctm_addr = 0;
	ctm_addr = &(ctm);
	void * vpctm = static_cast<void *>(ctm_addr);
	return vpctm;
}
