//package ccax.demo.directConnect.component;

//import cca.*;
//import ccax.demo.directConnect.port.*;

#include <unistd.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include "jc++/jc++.h"
#include "jc++/util/jc++util.h"
#include "esi/ESI-cca.h"
#include "esi/esi_Map_cca.h"
#include "esi/esi_JCPN(Vector)_cca.h"
#include <cca.h>
#include "parameters/parametersStar.h"
#include "port/portInterfaces.h"
#include "dc/port/portStar.h"
#include "dc/port/DefaultParameterPort.h"

#include "dc/component/Plate1.h"

//#include "util/IO.h" 
#include "util/freefree.h" //make free go away

static char *id="$Id: Plate1.cxx,v 1.1 2003/05/02 00:20:38 baallan Exp $";

/** world's least robust physics component, logically */
// There's really just 3 functions in this file;
// Grid/Field initialization (TPort.compute)
// Gradient calculation (QPort.compute)
// Parameter management (Plate1)
// Memory management, except for parameters, is in the hands of TPort.
//////////////////////////////////////////////////////////////
// we have two private objects to supply our external vectorports.
/** The first internal object  */
class TPort : public virtual JCPN(Vector)Port {

public:
  DefaultParameterPort *pp;
  DoubleParameter *tmax;
  DoubleParameter *tedge;
  DoubleParameter *tinf;
  StringParameter *profile;
  DoubleParameter *k;
  IntParameter *nx;
  IntParameter *ny;

  int Tout, Qout;
  esi_JCPN(Vector)_cca *Xaxis;
  esi_JCPN(Vector)_cca *Yaxis;
  esi_JCPN(Vector)_cca *T;
  esi_JCPN(Vector)_cca *Q;
  Plate1 *plate;
  Services *gizzard;
  PrintfPort *pfp;

  TPort (DefaultParameterPort *ppf, IntParameter *nxf, IntParameter *nyf,
         DoubleParameter *tmaxf, DoubleParameter *tedgef,
         DoubleParameter *tinff, StringParameter *profilef, DoubleParameter *kf,
         Plate1 *platef) {
    gizzard = 0;
    plate = platef;
    pp = ppf;
    tmax = tmaxf;
    tedge = tedgef;
    tinf = tinff;
    profile = profilef;
    k = kf;
    nx = nxf;
    ny = nyf;
    Tout = 0;
    Qout = 0;
  }

  ~TPort () {
    if (Tout||Qout) {
      pfp->en("Temperature vectorport destroyed incorrectly");
    }
    delete T; T=0;
    delete Q; Q=0;
    delete Xaxis; Xaxis = 0;
    delete Yaxis; Yaxis = 0;
  }


  void compute() throws(ExceptionJC){

#ifdef _DBG_PLATE1
    pfp->en("TPort::compute() entered");
#endif // _DBG_PLATE1

    if (pp == null || !pp->isFullyConfigured()) {
      pfp->en("Plate1 parameters must be configured!");
    }
#ifdef _DBG_PLATE1
    pfp->en("Plate1 appears configured ok.");
#endif // _DBG_PLATE1

    if (T == null) { // first call
#ifdef _DBG_PLATE1
      pfp->en("Initializing TPort");
#endif // _DBG_PLATE1
      struct MPI_wrapper *mw;
      mw = new struct MPI_wrapper;
#ifdef MPI_wrapper_HAS_COMM
      mw->comm = MPI_COMM_WORLD;
#endif //MPI_wrapper_HAS_COMM
      esi_Map_cca *xmap = new esi_Map_cca(mw);
      esi_Map_cca *ymap = new esi_Map_cca(mw);
      esi_Map_cca *fmap = new esi_Map_cca(mw);
#ifndef MPI_wrapper_HAS_COMM
#ifdef _DBG_PLATE1
      pfp->en("Plate1 serial mapped.");
#endif // _DBG_PLATE1
      xmap->setGlobalSize(nx->value);
      ymap->setGlobalSize(ny->value);
      fmap->setGlobalSize(nx->value * ny->value);
      xmap->setLocalInfo(nx->value, 0);
      ymap->setLocalInfo(ny->value, 0);
      fmap->setLocalInfo(nx->value * ny->value, 0);
#else
      int rank,size, avg, rem, localSize, localOffset;
      MPI_Comm_rank(mw->comm,&rank);
      MPI_Comm_size(mw->comm,&size);
      if (nx->value < rank) {
        throw new ExceptionJC(
            "Plate1 mesh needs at least as many nodes in X direction as processors");
      }
      avg = nx->value / size;
      rem = nx->value % size;
      if (rem == 0) {
        localSize = avg;
        localOffset = avg * rank;
      } else {
        localSize = avg;
        localOffset = localSize * rank;
        if (rank == (size - 1) ) {
          // last processor gets extra
          localSize = nx->value - localOffset;
        }
      }
#ifdef _DBG_PLATE1
      pfp->e("Plate1 parallel mapping...");
#endif //_DBG_PLATE1
      xmap->setGlobalSize(nx->value);
      ymap->setGlobalSize(ny->value);
      fmap->setGlobalSize(nx->value * ny->value);
#ifdef _DBG_PLATE1
      pfp->en(" sized...");
#endif //_DBG_PLATE1
      xmap->setLocalInfo(localSize, localOffset); // from geometry
      ymap->setLocalInfo(ny->value, 0); // vertically striped distribution
      fmap->setLocalInfo(localSize*ny->value, localOffset*ny->value);
#ifdef _DBG_PLATE1
      pfp->en("done.");
#endif //_DBG_PLATE1
#endif //MPI_wrapper_HAS_COMM
      Xaxis = new esi_JCPN(Vector)_cca(xmap);
      Yaxis = new esi_JCPN(Vector)_cca(ymap);
      T = new esi_JCPN(Vector)_cca(fmap); 
      Q = new esi_JCPN(Vector)_cca(fmap); 

#ifdef _DBG_PLATE1
      pfp->en("Plate1 vectors created.");
#endif //_DBG_PLATE1
      double *t;
      (void)T->accessArrayReadWrite(&t);
      assert(t != 0);
      // init Xaxis = 1..nx
      // init Yaxis = 1..ny
      // init T = decaying centered field
      if (strcmp(profile->value,"pyramidal")==0) {
        double *tx, *ty, dt;
  
        int i,j, offset;
  
        dt = tmax->value - tedge->value;
        tx = (double*)malloc(sizeof(double)*nx->value);
        assert(tx!=0);
        ty = (double*)malloc(sizeof(double)*ny->value);
        assert(ty!=0);
  
        double h,k;
        h = (1.0*(nx->value-1))/2.0;
        k = (1.0*(ny->value-1))/2.0;
  
        // x contributions
        for (j = 0; j <  nx->value; j++) {
          tx[j] = fabs(j-h)/nx->value;
        }
  
        // y contributions
        for (i = 0; i < ny->value; i++) {
          ty[i] = fabs(i-k)/ny->value;
        }
  
  
#ifndef MPI_wrapper_HAS_COMM
        // calc weird initial profile
        for (j = 0; j < nx->value ; j++) { //iterate over columns
          offset = ny->value *j;
          for (i = 0; i < ny->value ; i++) { // iterate over rows
            t[i+offset] = tedge->value + dt *(1 - tx[j] - ty[i]);
          }
        }
#else // MPI_wrapper_HAS_COMM
        int tlim = localSize*ny->value;
        for (j = 0; j < localSize; j++) { //iterate over columns
          offset = ny->value *(j);
          for (i = 0; i < ny->value ; i++) { // iterate over rows
            assert((i+offset) < tlim);
            t[i+offset] = tedge->value + dt *(1 - tx[j+localOffset] - ty[i]);
          }
        }
#endif //MPI_wrapper_HAS_COMM
  
        free(tx); tx = 0;
        free(ty); ty = 0;

      } else {

        double dt;
        double h;
        double k;
        int offset;
        h = (1.0*(nx->value-1))/2.0;
        k = (1.0*(ny->value-1))/2.0;
        dt = tmax->value - tedge->value;

#ifndef MPI_wrapper_HAS_COMM
        // calc paraboloid initial profile
        for (int j = 0; j < nx->value ; j++) { //iterate over columns
          offset = ny->value *j;
          for (int i = 0; i < ny->value ; i++) { // iterate over rows
            t[i+offset] = tedge->value + dt *(1 - (i-h)*(i-h)/(h*h) - (j-k)*(j-k)/(k*k));
          }
        }
#else // MPI_wrapper_HAS_COMM
        int tlim = localSize*ny->value;
        for (int j = 0; j < localSize; j++) { //iterate over columns
          offset = ny->value * (j);
          for (int i = 0; i < ny->value ; i++) { // iterate over rows
            assert((i+offset) < tlim);
            t[i+offset] = tedge->value + 
               dt *(1 - (i-k)*(i-k)/(k*k) - (j+localOffset-h)*(j+localOffset-h)/(h*h));
          }
        }
#endif //MPI_wrapper_HAS_COMM
      }

      (void)T->restoreArray(&t);

      // call cartesian2port to set up viz.
      Cartesian2Port *c2;
      c2 = dynamic_cast<Cartesian2Port*>(gizzard->getPort("VIZ")); CHECKDC(c2);
#ifdef _DBG_PLATE1
      pfp->en("c2 port ok.");
#endif //_DBG_PLATE1
      c2->setXAxis(Xaxis);
      c2->setYAxis(Yaxis);
      c2->setField(T,"TEMP",0);
      c2->setField(Q,"heat flux",1);
      pfp->en("Plate1 cartesian2port filled.");
      gizzard->releasePort("VIZ");
      pfp->en("Plate1 cartesian2port released.");

      plate->setT(T);
      plate->setQ(Q);
      return;
    } else {
      // else, just do nothing, as we only compute the init point.
      pfp->en("TPort::compute() already called");
    }
  }

  void update() {
    /// do nothing, unless forced to copy;
  }

  ESI_JCPN(Vector) *getJCPN(Vector)() {
    Tout = 1;
    return T;
  }

  void releaseJCPN(Vector)(ESI_JCPN(Vector) *v) {
    if (T != v || !Tout) {
      pfp->en("temperature vector released incorrectly!");
    }
  }

  void setGizzard(Services *cc) {
    gizzard = cc;
  }
};

//////////////////////////////////////////////////////////////
class QPort: public virtual JCPN(Vector)Port {
private:
  Plate1 *plate;
  TPort *tport;
 
public:
  /** cannot be called until after TPort is created */
  QPort (TPort *tportf) {
    tport = tportf;
  }

  ~QPort () {
  }

  //// Qij = (Tinf - Tij)*k;
  void compute() {
    Cartesian2Port *c2;
    assert(tport != 0);
    if (tport->pp ==null || !tport->pp->isFullyConfigured()) {
      pfp->en("Plate1 parameters must be configured!");
    }

#ifdef _DBG_PLATE1
    pfp->en("QPort Q->put");
    assert(tport->Q != 0);
    pfp->en("QPort Q->put");
#endif //_DBG_PLATE1

    tport->Q->put(tport->k->value * tport->tinf->value);

#ifdef _DBG_PLATE1
    pfp->en("QPort Q->axpy");
#endif //_DBG_PLATE1

    tport->Q->axpy(*(tport->T),-(tport->k->value));

#ifdef _DBG_PLATE1
    pfp->en("QPort get cartesian2port");
#endif //_DBG_PLATE1

    c2 = dynamic_cast<Cartesian2Port *>(
           tport->gizzard->getPort("VIZ")); CHECKDC(c2);
    c2->visualize();
    tport->gizzard->releasePort("VIZ");

#ifdef _DBG_PLATE1
    pfp->en("QPort released cartesian2port");
#endif //_DBG_PLATE1

  }

  void update(){}
    /// we don't care if you change Q while we're looking.
    /// if we were a real model we might.

  ESI_JCPN(Vector) *getJCPN(Vector)() {
    tport->Qout = 1;
    return tport->Q;
  }

  void releaseJCPN(Vector)(ESI_JCPN(Vector) *v) {
    if (tport->Q != dynamic_cast<esi_JCPN(Vector)_cca *>(v) || tport->Qout == 0) {
      pfp->en("tempGradient vector released incorrectly!");
    }
  }

};

//////////////////////////////////////////////////////////////
/** Plate is a wrapper for the control parameters and ccaness
 of our physics. We have some physic model functionality that
 must be exported through separate ports.
*/

Plate1::Plate1() {

  tmax = new DoubleParameter("tmax",
    "Slab center temperature at beginning of simulation",
    "T max",100.0,1.0,1000000.0
  );
  tedge = new DoubleParameter("tedge",
    "Slab edge temperature at beginning of simulation",
    "T edge",20.0,1.0,1000000.0
  );
  tinf = new DoubleParameter("tinf",
    "Temperature of the infinite heat sink under the slab",
    "T infinity",2.0,0.0,1000000.0
  );
  profile = new StringParameter("profile",
    "Initial shape for distribution of temperatures in the slab",
    "initial profile shape","parabolic"
  );
  profile->addChoice("parabolic");
  profile->addChoice("pyramidal");
  k = new DoubleParameter("k",
    "Heat transfer coefficient between the slab and the heat sink",
    "k",0.1,1e-5,1000000.0
  );
  nx = new IntParameter("nx",
    "The number of nodes in the x direction",
    "x nodes",3,2,1000000
  );
  ny = new IntParameter("ny",
    "The number of nodes in the y direction",
    "y nodes",3,2,1000000
  );

  pp = new DefaultParameterPort();
  pp->setBatchTitle("Rectangular Plate Configuration");
  pp->setGroupName("Temperature Profile");
  pp->addRequest(tmax);
  pp->addRequest(tedge);
  pp->addRequest(tinf);
  pp->addRequest(k);
  pp->addRequest(profile);
  pp->setGroupName("Grid Geometry");
  pp->addRequest(nx);
  pp->addRequest(ny);

  temperature = new TPort(pp, nx, ny, tmax, tedge, tinf, profile, k, this);
  tempGradient = new QPort(temperature);

  pfp = 0;
}

Plate1::~Plate1() {

  delete tmax; tmax =0;
  delete tedge; tedge=0;
  delete tinf; tinf=0;
  delete profile; profile=0;
  delete k; k=0;
  delete nx; nx=0;
  delete ny; ny=0;
  delete pp; pp = 0;
  delete tempGradient;
  delete temperature;

  pfp = 0;
}

void Plate1::setServices(Services *cc) {
  core = cc;

  // Contact the PrintfService
  PortInfo* pinfo = cc->createPortInfo("pSvc", "gov.cca.PrintfService", 0);
  cc->registerUsesPort(pinfo);
  pfp = dynamic_cast<PrintfPort*>(cc->getPort("pSvc"));
  CHECKDC(pfp);
  if(pfp == 0) {
    cc->addProvidesPort(this, cc->createPortInfo("DEAD=NoPrintf", "Port", 0));
    printf("!!! No PrintfService available from framework.");
    return;
  }

  temperature->setGizzard(cc);
  try {
    core->addProvidesPort(pp,
        core->createPortInfo("CONFIG","ParameterPort", 0));

    core->addProvidesPort(temperature,
       core->createPortInfo("TEMP","JCPN(Vector)Port", 0));
    core->addProvidesPort(tempGradient,
       core->createPortInfo("FLUX","JCPN(Vector)Port", 0));

    // We send our geometry to some rendering front end.
    core->registerUsesPort(core->createPortInfo("VIZ", "Cartesian2Port", 0));
    
  } catch (ExceptionJC* e) {

    pfp->e("Plate set failure:");
    pfp->en(e->why());

  }
}

void Plate1::setT(ESI_JCPN(Vector) *newt) {
  T = newt;
}

void Plate1::setQ(ESI_JCPN(Vector) *newq) {
  Q = newq;
}

ESI_JCPN(Vector) *Plate1::getT() {
  return T;
}

ESI_JCPN(Vector) *Plate1::getQ() {
  return Q;
}

