#include <cca.h>
#ifdef HAVE_NEO
#include <neocca.hh>
#endif // HAVE_NEO
#include "dc/export/ccafeopq.hh"
#include "dc/export/AllExport.hh"
#include "dc/export/ccafeopq_support.hh"
#include <ports/AllEvents.h>
#include "dc/framework/ServiceFactory.h"
#include "dc/framework/ServicePortFactory.h"
#include "dc/framework/ServiceFactoryContainer.h"
#include "dc/framework/ComponentChangedEvent.h"
#include "dc/framework/ComponentChangedListener.h"
#include "dc/framework/ComponentID.h"
#include "dc/framework/ConnectionID.h"
#include "dc/framework/UserPortData.h"
#include "dc/framework/ProviderPortData.h"
#include "dc/framework/KernelPort.h"
#include "dc/framework/Gizzard.h"
#include "util/TypeMap.h"

#include "dc/framework/XService.hh"

namespace {
char id[]=
"$Id: XService.cc,v 1.1 2004/03/29 08:03:11 baallan Exp $";
} ENDSEMI
using std::string;

XService::XService(Gizzard * giz_, string & portInstanceName_)
{
  giz = giz_;
  portInstanceName = portInstanceName_;
}

ccafeopq::Port * 
XService::getPort() {
  if(!giz) {
    return 0;
  }
  return giz->getPort(portInstanceName.c_str());
}
