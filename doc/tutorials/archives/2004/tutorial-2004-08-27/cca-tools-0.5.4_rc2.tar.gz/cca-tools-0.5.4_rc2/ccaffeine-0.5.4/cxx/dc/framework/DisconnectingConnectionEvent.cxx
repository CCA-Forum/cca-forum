#include "dc/export/AllExport.hh"
#include <cca.h>
#include <ports/AllEvents.h>
#include "dc/framework/ConnectionID.h"
#include "dc/framework/UserPortData.h"
#include "dc/framework/ProviderPortData.h"
#include "dc/framework/DisconnectingConnectionEvent.h"
#include "util/TypeMap.h"
#include "dc/classic/ccafe-bind/AllCcafeBind.hh"

namespace {
char id[]=
"$Id: DisconnectingConnectionEvent.cxx,v 1.5 2004/01/21 06:21:55 baallan Exp $";
} ENDSEMI

DisconnectingConnectionEvent::DisconnectingConnectionEvent( UserPortData & upd)
{
  ::ccafeopq::TypeMap_shared tm1 = upd.getUserPortProperties();
  pi = new OpqPortInfo(upd.getPortName(), upd.getPortType(), tm1);
  cpi = new ClassicPortInfo(pi);
  killpi = true;
}

DisconnectingConnectionEvent::DisconnectingConnectionEvent( ProviderPortData & ppd)
{
  ::ccafeopq::TypeMap_shared tm1 = ppd.getProviderPortProperties();
  pi = new OpqPortInfo(ppd.getPortName(), ppd.getPortType(), tm1);
  cpi = new ClassicPortInfo(pi);
  killpi = true;
}

DisconnectingConnectionEvent::~DisconnectingConnectionEvent() 
{ 
  if (killpi) {
    delete cpi;
  }
  cpi = 0;
  pi = 0;
}

/** True if the event informs a connection. (never) */
int DisconnectingConnectionEvent::connected()
{
  return false;
}

/** True if the event informs a disconnection (always) */
int DisconnectingConnectionEvent::disconnected()
{
  return true;
}

/** Get the classic::gov::cca::PortInfo of the affected Port. */
classic::gov::cca::PortInfo *DisconnectingConnectionEvent::getPortInfo() 
{
  return cpi; 
}

void * DisconnectingConnectionEvent::getOpqTypeMapSharedPtrAddress()
{
	::ccafeopq::TypeMap_shared * ctm_addr = 0;
	ctm_addr = &(ctm);
	void * vpctm = static_cast<void *>(ctm_addr);
	return vpctm;
}

