#ifndef __DisconnectingConnectionEvent_h_seen__
#define __DisconnectingConnectionEvent_h_seen__

/** Event delivered to a connection listener before a connection is broken. */
class DisconnectingConnectionEvent : public virtual classic::gov::cca::ConnectionEvent {

private:
  ccafeopq::PortInfo *pi;
  bool killpi;
  classic::gov::cca::PortInfo *cpi;
  ::ccafeopq::TypeMap_shared ctm;

public:
  DisconnectingConnectionEvent( UserPortData & upd);
  DisconnectingConnectionEvent( ProviderPortData & ppd);
  virtual ~DisconnectingConnectionEvent();
  
  /** True if the event informs a connection. (never) */
  virtual int connected();
  
  /** True if the event informs a disconnection (always) */
  virtual int disconnected();
   
  /** Get the classic::gov::cca::PortInfo of the affected Port. */
  virtual classic::gov::cca::PortInfo *getPortInfo();

  virtual void * getOpqTypeMapSharedPtrAddress();
  
};

#endif // __DisconnectingConnectionEvent_h_seen__
