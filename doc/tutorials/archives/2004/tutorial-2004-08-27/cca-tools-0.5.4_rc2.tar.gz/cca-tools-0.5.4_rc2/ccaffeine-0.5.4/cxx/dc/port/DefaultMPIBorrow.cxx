// this file disappears if there is no mpi.
#ifdef _CCAMPI
#include <mpi.h>
#include <cca.h>
#include <ports/MPIBorrow.h>
#include "dc/export/config.hh"
#ifdef HAVE_NEO
#include <neocca.hh>
#include <neoports.hh>
#endif
#include "dc/port/DefaultMPIBorrow.h"

DefaultMPIBorrow::DefaultMPIBorrow() {
  maxTag = 0;
  maxKey = 0;
}

DefaultMPIBorrow::~DefaultMPIBorrow() {
	maxTag = -1;
	maxKey = -1;
}

MPI_Comm DefaultMPIBorrow::borrowComm(int tcount, int *tags, int &key) {
	if (this == 0 || maxTag == -1) { return MPI_COMM_NULL; }
	maxKey++;
  key = maxKey;
	for (int i = 0; i < tcount; i++) {
		tags[i] = i+ maxTag;
	}
	maxTag = tags[tcount-1] + 1;
  return MPI_COMM_WORLD;
}

void DefaultMPIBorrow::returnComm(MPI_Comm comm, int tcount, int *tags, int key) {
	if (this == 0 || maxTag == -1) { return; }
  if (key == maxKey-1) {
		maxKey--;
	} else {
		if (key < 0 || key > maxKey) { return; }
	}
	if (tcount < 0 || tcount > maxTag) { return; }
	for (int i = 0; i < tcount; i++) {
		tags[i] = -1;
	}
}

#endif // _CCAMPI
