#ifndef Cartesian2Port_h_seen
#define Cartesian2Port_h_seen

// requires <ESI.h>
template <>
class ESI_Vector<esi_real8,esi_int4>;


/** Interface called by physics at start to setup cumulvs. */
class Cartesian2Port : public virtual classic::gov::cca::Port { 

public:

	virtual ~Cartesian2Port(){}

	/** Set up array of x coordinates */
        virtual void setXAxis(ESI_Vector<esi_real8,esi_int4> *x) =0;

	/** Set array of y coordinates */
        virtual void setYAxis(ESI_Vector<esi_real8,esi_int4> *y) =0;

	/** field is the 1d equivalent of a 2d f77 array
	 with global DIMENSION data.length=x.length*y.length
	 data(ix, iy). */
        virtual void setField(ESI_Vector<esi_real8,esi_int4> *data, char *name, int field_number) =0;

	/** Give the location of the time variable theta. */
        virtual void setTime(double * theta, char *name, int field_number) =0;

	/** Start the visualization routine going again. */
	virtual int visualize()=0; 
};
#endif //Cartesian2Port_h_seen
