#ifndef __BABELCOMPONENTWRAPPER_H__
#define __BABELCOMPONENTWRAPPER_H__


class BabelComponentWrapper : public virtual ccafeopq::Component {
private:

  ::gov::cca::Component wrapped;
  ccaffeine::Services bblSvc;
  ClassicServicesHelper csh;

  void createException(const char * msg);

public:

  BabelComponentWrapper(gov::cca::Component c);

  virtual ~BabelComponentWrapper(){}

  virtual void setServices(ccafeopq::Services * svc) throw (ccafeopq::Exception);

};

#endif // __BABELCOMPONENTWRAPPER_H__
