#include "F90CCAPort.h"

#include <string.h>

const int MAX_LEN = 512;
char c_str[MAX_LEN];

std::map<void*, classic::gov::cca::Services*> servicesMap;

extern "C" {

void GETPORT(CCA::CCAPORT* requesting_port,
             CCA::CCAPORT* port, const char* name, int length)
{
  if (length >= MAX_LEN) {
    port->instance = 0;
    return;
  }

  strncpy(c_str, name, length);
  c_str[length] = '\0';

  port->instance = servicesMap[requesting_port->instance]->getPort(c_str);
}

void RELEASEPORT(CCA::CCAPORT* requesting_port, const char* name, int length)
{
  if (length >= MAX_LEN) return;

  strncpy(c_str, name, length);
  c_str[length] = '\0';

  servicesMap[requesting_port->instance]->releasePort(c_str);
}

} // extern "C"
