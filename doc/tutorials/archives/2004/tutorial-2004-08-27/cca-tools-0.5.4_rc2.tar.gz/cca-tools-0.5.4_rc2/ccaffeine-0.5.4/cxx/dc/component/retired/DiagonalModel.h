#ifndef __DIAGONALMODEL_H__
#define __DIAGONALMODEL_H__


/** Computes a diagonal matrix and solves it using a RowEquationSolver port
when the go port is prodded.
*/
class DiagonalModel : public classic::gov::cca::Component, public classic::gov::cca::GoPort {

private:

  IntParameter *nx;
  ParameterPort *pp;
  classic::gov::cca::Services *myCore;
  classic::gov::cca::PrintfPort *pfp;

public:

  DiagonalModel();

  ~DiagonalModel(); 

  void setServices(classic::gov::cca::Services *cc);

  virtual int go();

};


#endif //__DIAGONALMODEL_H__
