#if 0
class GUIServicePortFactory : public virtual ServicePortFactory {
 private:
  BuilderController* bc;
  CmdLineBuilderView* bv;
  char* name;

 public:

  GUIServicePortFactory(BuilderController* bc, 
			CmdLineBuilderView* bv);

  virtual ~GUIServicePortFactory(){
    free(name);
  }

  /** Return the name of the Service that this factory creates. */
  const char* getName();

  /** Create the service. */
  ::ccafeopq::Port* create();
};

#endif // 0
