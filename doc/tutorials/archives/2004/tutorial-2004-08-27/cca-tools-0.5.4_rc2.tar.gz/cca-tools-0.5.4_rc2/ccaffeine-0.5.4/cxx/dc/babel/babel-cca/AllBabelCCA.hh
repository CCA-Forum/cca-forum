//
// When adding stuff to this file, the client interface needs
// to come first.
// In fact, the impls shouldn't be exported at all,
// because none of the client interfaces refer to the
// impl classes.
//
#include "dc/babel/babel-cca/server/ccaffeine_CCAException.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ComponentClassDescription.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ComponentID.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ConnectionEventService.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ConnectionID.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ports_PortTranslator.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ports_ComponentRepository.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ports_ConnectionEvent.hh"
#include "dc/babel/babel-cca/server/ccaffeine_Services.hh"
#include "dc/babel/babel-cca/server/ccaffeine_TypeMap.hh"
#include "dc/babel/babel-cca/server/ccaffeine_TypeMismatchException.hh"
#include "dc/babel/babel-cca/server/ccaffeine_AbstractFramework.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ports_BuilderService.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ports_BasicParameterPortWrap.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ports_ParameterPortWrap.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ports_ParameterPortFactoryWrap.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ports_ServiceRegistryWrap.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ports_GoPortWrap.hh"

//------------ impls next.
#if 0
// these should not be included.
#include "dc/babel/babel-cca/server/ccaffeine_AbstractFramework_Impl.hh"
#include "dc/babel/babel-cca/server/ccaffeine_CCAException_Impl.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ComponentClassDescription_Impl.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ComponentID_Impl.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ConnectionEventService_Impl.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ConnectionID_Impl.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ports_ComponentRepository_Impl.hh"
#include "dc/babel/babel-cca/server/ccaffeine_ports_ConnectionEvent_Impl.hh"
#include "dc/babel/babel-cca/server/ccaffeine_Services_Impl.hh"
#include "dc/babel/babel-cca/server/ccaffeine_TypeMap_Impl.hh"
#include "dc/babel/babel-cca/server/ccaffeine_TypeMismatchException_Impl.hh"
#endif
