#ifndef Plate1_h_seen
#define Plate1_h_seen

class TPort;
class QPort;

class Plate1 : public virtual classic::gov::cca::Component {

private:

  classic::gov::cca::PrintfPort *pfp;
  classic::gov::cca::Services *core;
  TPort *temperature;
  QPort *tempGradient;

  DefaultParameterPort *pp;
  DoubleParameter *tmax;
  DoubleParameter *tedge;
  DoubleParameter *tinf;
  StringParameter *profile;
  DoubleParameter *k;
  IntParameter *nx;
  IntParameter *ny;

  ESI_Vector *T;
  ESI_Vector *Q;

public:

  Plate1();
  ~Plate1();

  void setServices(classic::gov::cca::Services *cc);

  void setT(ESI_Vector *newt) ;

  void setQ(ESI_Vector *newq) ;

  ESI_Vector *getT() ;

  ESI_Vector *getQ() ;

};
#endif //Plate1_h_seen
