#ifndef __SERVICEFACTORYTABLE_H__
#define __SERVICEFACTORYTABLE_H__

class CcafeServiceFactoryContainer : public virtual ServiceFactoryContainer {
 private:
  ::std::map< ::std::string, ServicePortFactory * > holder;
  
 public:

  CcafeServiceFactoryContainer();

  virtual ~CcafeServiceFactoryContainer();

  /** Add a service to the table. */
  virtual ServicePortFactory* addServicePortFactory(ServicePortFactory* factory);

  /** Remove a service from the table.*/
  virtual ServicePortFactory* removeServicePortFactory(ServicePortFactory* factory);

  /** Get the underlying factory that has this type. */
  virtual ServicePortFactory* getServicePortFactory(const char* SvcPortType);

  /** Get all of the ServicePortTypes belonging to this factory. */
  ::std::vector< ::std::string > getTypes();

  /** Copy the ServiceFactoryContainer argument into this Container. */
  virtual void incorporate(ServiceFactoryContainer* container);

  /** Create a service by name. If the service does not exist, NULL is
      returned. */
  virtual ccafeopq::Port* createService(const char* serviceType);

};

#endif // __SERVICEFACTORYTABLE_H__
