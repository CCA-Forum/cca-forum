#include <cca.h>
#include "ports/TimeProducerPort.h"
#include "port/portInterfaces.h"
#include "Timer.h"

#ifndef lint
namespace {
char idFile[]= 
"$Id: Timer.cxx,v 1.15 2003/10/07 08:04:17 baallan Exp $";
} ENDSEMI
#endif

#include <time.h>

void Timer::setServices(classic::gov::cca::Services *svc){
  if(!svc) {
    return;
  }
  myCore = svc;
  myCore->addProvidesPort(dynamic_cast<classic::gov::cca::TimeProducerPort*>(this),
    myCore->createPortInfo("time_port", "TimeProducerPort", 0));
}

/*CFREE*/ char* Timer::getTime() {
  time_t t = ::time(&t);
  char* tmp = ::ctime(&t);
  char* d = strdup(tmp);
  return d;
}
