#include <cca.h>

#include "dc/framework/ComponentChangedEvent.h"

#include "dc/export/config.hh"
namespace {
char id[]=
"$Id: ComponentChangedEvent.cxx,v 1.5 2003/07/07 19:08:39 baallan Exp $";
} ENDSEMI

int ComponentChangedEvent::PORT_ERROR      = 0;
int ComponentChangedEvent::PORT_REMOVED      = 1;
int ComponentChangedEvent::PORT_ADDED        = 2;
int ComponentChangedEvent::PORT_REGISTERED   = 3;
int ComponentChangedEvent::PORT_UNREGISTERED = 4;
