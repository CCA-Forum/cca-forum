/*
 * File:          functions_LinearFunction_Impl.c
 * Symbol:        functions.LinearFunction-v1.0
 * Symbol Type:   class
 * Babel Version: 0.9.4
 * Description:   Server-side implementation for functions.LinearFunction
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 * babel-version = 0.9.4
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "functions.LinearFunction" (version 1.0)
 */

#include "functions_LinearFunction_Impl.h"

/* DO-NOT-DELETE splicer.begin(functions.LinearFunction._includes) */
/* Put additional includes or other arbitrary code here... */
/* DO-NOT-DELETE splicer.end(functions.LinearFunction._includes) */

/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__ctor"

void
impl_functions_LinearFunction__ctor(
  /*in*/ functions_LinearFunction self)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._ctor) */
  /* Insert the implementation of the constructor method here... */
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction._ctor) */
}

/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__dtor"

void
impl_functions_LinearFunction__dtor(
  /*in*/ functions_LinearFunction self)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._dtor) */
  /* Insert the implementation of the destructor method here... */
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction._dtor) */
}

/*
 * Method:  init[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_init"

void
impl_functions_LinearFunction_init(
  /*in*/ functions_LinearFunction self,
    /*in*/ struct sidl_double__array* params)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.init) */
  /* Insert the implementation of the init method here... */
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction.init) */
}

/*
 * Method:  evaluate[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_evaluate"

double
impl_functions_LinearFunction_evaluate(
  /*in*/ functions_LinearFunction self, /*in*/ double x)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.evaluate) */
  /* Insert the implementation of the evaluate method here... */
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction.evaluate) */
}

/*
 * Method:  setServices[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_setServices"

void
impl_functions_LinearFunction_setServices(
  /*in*/ functions_LinearFunction self, /*in*/ gov_cca_Services servicesHandle,
    /*out*/ sidl_BaseInterface* _ex)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.setServices) */
  /* Insert the implementation of the setServices method here... */
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction.setServices) */
}
