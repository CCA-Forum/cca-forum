#!/bin/sh
		
# This script combines babel.make files (that use component-specific prefixes, 
# see documentation for the -m option to babel) into one file, babel.make.all.
# The script should be invoked in the directory where the impls reside.
# Currently C, C++, and Fortran client and server are supported.

BABEL_MAKE_ALL=babel.make.all

rm -f ${BABEL_MAKE_ALL}

srcKinds=(IORSRCS STUBSRCS SKELSRCS IMPLSRCS IMPLMODULESRCS TYPEMODULESRCS STUBMODULESRCS ARRAYMODULESRCS)

babelMakeFiles=`ls *babel.make`
touch ${BABEL_MAKE_ALL}

#for element in "${srcKinds[@]}" ; do
#	echo "$element = " >> $BABEL_MAKE_ALL
#done

for babelMake in $babelMakeFiles ; do
	if [ -e $babelMake ] ; then 
		for element in "${srcKinds[@]}" ; 
			do
				# Clumsy, but easy
				srcs=`grep $element $babelMake | sed -e 's/^.* = //g'`;
				if [ "x$srcs" != "x" ] ; then
					echo "$element:=\$($element) $srcs  " >> $BABEL_MAKE_ALL
				fi
			done
	fi
done

# Now do glue code, if any
if [ -d glue ]; then
	babelMakeFiles="`ls glue/*babel.make`"
fi
for babelMake in $babelMakeFiles ; do
	if [ -e $babelMake ] ; then 
		for element in "${srcKinds[@]}" ; 
			do
				# Clumsy, but easy
				srcs=`grep $element $babelMake | sed -e 's/^.* = //g'`;
				if [ "x$srcs" != "x" ] ; then
					echo "$element:=\$($element) glue/$srcs  " >> $BABEL_MAKE_ALL
				fi
			done
	fi
done



echo $BABEL_MAKE_ALL


#   for i in "${colors[@]}"
#   do
#     echo "$i"
#   done
