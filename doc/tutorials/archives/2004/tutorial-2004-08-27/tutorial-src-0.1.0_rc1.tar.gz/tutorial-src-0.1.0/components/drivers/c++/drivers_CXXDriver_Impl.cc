// 
// File:          drivers_CXXDriver_Impl.cc
// Symbol:        drivers.CXXDriver-v1.0
// Symbol Type:   class
// Babel Version: 0.9.4
// Description:   Server-side implementation for drivers.CXXDriver
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.9.4
// 
#include "drivers_CXXDriver_Impl.hh"

// DO-NOT-DELETE splicer.begin(drivers.CXXDriver._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(drivers.CXXDriver._includes)

// user defined constructor
void drivers::CXXDriver_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(drivers.CXXDriver._ctor)
  // add construction details here
  // DO-NOT-DELETE splicer.end(drivers.CXXDriver._ctor)
}

// user defined destructor
void drivers::CXXDriver_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(drivers.CXXDriver._dtor)
  // add destruction details here
  // DO-NOT-DELETE splicer.end(drivers.CXXDriver._dtor)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  go[]
 */
int32_t
drivers::CXXDriver_impl::go () 
throw () 

{
  // DO-NOT-DELETE splicer.begin(drivers.CXXDriver.go)
  // insert implementation here

  double value;
  int count = 100000;
  double lowerBound = 0.0, upperBound = 1.0;

  ::integrator::IntegratorPort integrator;

  // get the port ...
  integrator = frameworkServices.getPort("IntegratorPort");

  if(integrator._is_nil()) {
    fprintf(stdout, "drivers.CXXDriver not connected\n");
    frameworkServices.releasePort("IntegratorPort");
    return -1;    
  }
    // operate on the port
    value = integrator.integrate (lowerBound, upperBound, count);

    fprintf(stdout,"Value = %lf\n", value);
    fflush(stdout);
  
  // release the port.
  frameworkServices.releasePort("IntegratorPort");
  return 0;

  // DO-NOT-DELETE splicer.end(drivers.CXXDriver.go)
}

/**
 * Method:  setServices[]
 */
void
drivers::CXXDriver_impl::setServices (
  /*in*/ ::gov::cca::Services services ) 
throw ( 
  ::gov::cca::CCAException
){
  // DO-NOT-DELETE splicer.begin(drivers.CXXDriver.setServices)
  // insert implementation here

  frameworkServices = services;
  
  // Provide a Go port
   gov::cca::ports::GoPort gp = self;
        
  frameworkServices.addProvidesPort(gp, 
				        "GoPort", 
				        "gov.cca.ports.GoPort",
				        frameworkServices.createTypeMap());
              
  // Use an IntegratorPort port
  frameworkServices.registerUsesPort ("IntegratorPort", 
				            "integrator.IntegratorPort", 
				            frameworkServices.createTypeMap());

// DO-NOT-DELETE splicer.end(drivers.CXXDriver.setServices)
}


// DO-NOT-DELETE splicer.begin(drivers.CXXDriver._misc)
// Put miscellaneous code here
// DO-NOT-DELETE splicer.end(drivers.CXXDriver._misc)

