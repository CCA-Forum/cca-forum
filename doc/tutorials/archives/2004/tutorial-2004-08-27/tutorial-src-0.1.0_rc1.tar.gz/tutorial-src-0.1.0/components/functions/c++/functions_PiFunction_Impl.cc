// 
// File:          functions_PiFunction_Impl.cc
// Symbol:        functions.PiFunction-v1.0
// Symbol Type:   class
// Babel Version: 0.9.4
// Description:   Server-side implementation for functions.PiFunction
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.9.4
// 
#include "functions_PiFunction_Impl.hh"

// DO-NOT-DELETE splicer.begin(functions.PiFunction._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(functions.PiFunction._includes)

// user defined constructor
void functions::PiFunction_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(functions.PiFunction._ctor)
  // add construction details here
  // DO-NOT-DELETE splicer.end(functions.PiFunction._ctor)
}

// user defined destructor
void functions::PiFunction_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(functions.PiFunction._dtor)
  // add destruction details here
  // DO-NOT-DELETE splicer.end(functions.PiFunction._dtor)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Starts up a component presence in the calling framework.
 * @param Svc the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument Svc will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
functions::PiFunction_impl::setServices (
  /*in*/ ::gov::cca::Services services ) 
throw ( 
  ::gov::cca::CCAException
){
  // DO-NOT-DELETE splicer.begin(functions.PiFunction.setServices)

  // Provide a Function port
  if(services._not_nil()) {
    gov::cca::TypeMap tm = services.createTypeMap();
    if(tm._is_nil()) {
      fprintf(stderr, "%s:%d: gov::cca::TypeMap is nil\n",
          __FILE__, __LINE__);
    } 
    
    gov::cca::Port p = self;      //  Babel required casting
    
    if(p._is_nil()) {
      fprintf(stderr, "p is nil");
    } 
    
    services.addProvidesPort(p,
                             "FunctionPort",
                             "function.FunctionPort", tm);
  }

  // insert implementation here
  // DO-NOT-DELETE splicer.end(functions.PiFunction.setServices)
}

/**
 * Method:  init[]
 */
void
functions::PiFunction_impl::init (
  /*in*/ ::sidl::array<double> params ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(functions.PiFunction.init)
  // insert implementation here
  // DO-NOT-DELETE splicer.end(functions.PiFunction.init)
}

/**
 * Method:  evaluate[]
 */
double
functions::PiFunction_impl::evaluate (
  /*in*/ double x ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(functions.PiFunction.evaluate)
  // insert implementation here

  return 4.0 / (1.0 + x * x);

  // DO-NOT-DELETE splicer.end(functions.PiFunction.evaluate)
}


// DO-NOT-DELETE splicer.begin(functions.PiFunction._misc)
// Put miscellaneous code here
// DO-NOT-DELETE splicer.end(functions.PiFunction._misc)

