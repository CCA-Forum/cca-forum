#!/bin/sh	
packages="";
until [ -z "$1" ]; do packages="${1%%.*} $packages"; shift; done
echo "$packages"
