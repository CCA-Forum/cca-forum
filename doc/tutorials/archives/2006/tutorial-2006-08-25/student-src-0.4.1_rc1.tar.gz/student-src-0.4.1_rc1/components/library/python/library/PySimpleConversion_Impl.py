#
# File:          PySimpleConversion_Impl.py
# Symbol:        library.PySimpleConversion-v1.0
# Symbol Type:   class
# Babel Version: 0.10.8
# Description:   Implementation of sidl class library.PySimpleConversion in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
# babel-version = 0.10.8
# xml-url       = /home/epperly/current/tutorial/src/components/../xml_repository/library.PySimpleConversion-v1.0.xml
#


# DO-NOT-DELETE splicer.begin(_initial)
# DO-NOT-DELETE splicer.end(_initial)

import sidl.ClassInfo
import library.PySimpleConversion
import units.Unit
import units.Conversion
import sidl.BaseInterface
import sidl.BaseClass

# DO-NOT-DELETE splicer.begin(_before_static)
# DO-NOT-DELETE splicer.end(_before_static)

def build(fromUnit, toUnit):
  #
  # sidl EXPECTED INCOMING TYPES
  # ============================
  # units.Unit fromUnit
  # units.Unit toUnit
  #

  #
  # sidl EXPECTED RETURN VALUE(s)
  # =============================
  # library.PySimpleConversion _return
  #

  # DO-NOT-DELETE splicer.begin(build)
  result = library.PySimpleConversion.PySimpleConversion()
  result.init(fromUnit, toUnit)
  return result
  # DO-NOT-DELETE splicer.end(build)

# DO-NOT-DELETE splicer.begin(_before_type)
# Insert-Code-Here {_before_type} ()
# DO-NOT-DELETE splicer.end(_before_type)

class PySimpleConversion:

  # All calls to sidl methods should use __IORself

  def __init__(self, IORself):
    self.__IORself = IORself
    # DO-NOT-DELETE splicer.begin(__init__)
    self.d_fromUnit = None
    self.d_toUnit = None
    # DO-NOT-DELETE splicer.end(__init__)

  def init(self, fromUnit, toUnit):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # units.Unit fromUnit
    # units.Unit toUnit
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # # None
    #

    # DO-NOT-DELETE splicer.begin(init)
    self.d_fromUnit = fromUnit
    self.d_toUnit = toUnit
    # DO-NOT-DELETE splicer.end(init)

  def reverse(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # # None
    #

    """\
Reverse the direction of the conversion.
"""
    # DO-NOT-DELETE splicer.begin(reverse)
    self.d_fromUnit, self.d_toUnit = (self.d_toUnit, self.d_fromUnit)
    # DO-NOT-DELETE splicer.end(reverse)

  def convertFrom(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # units.Unit _return
    #

    """\
Return the unit that this Conversion interface will convert
from.
"""
    # DO-NOT-DELETE splicer.begin(convertFrom)
    return self.d_fromUnit
    # DO-NOT-DELETE splicer.end(convertFrom)

  def convertTo(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # units.Unit _return
    #

    """\
Return the unit that this interface will convert to.
"""
    # DO-NOT-DELETE splicer.begin(convertTo)
    return self.d_toUnit
    # DO-NOT-DELETE splicer.end(convertTo)

  def convert(self, orig):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # double orig
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # double _return
    #

    """\
Convert a physical quantity from old set of units to another.
"""
    # DO-NOT-DELETE splicer.begin(convert)
    slope, offset = self.d_fromUnit.conversionFactors()
    siValue = slope*orig + offset + 0.0
    slope, offset = self.d_toUnit.conversionFactors()
    return (siValue - offset)/slope
    # DO-NOT-DELETE splicer.end(convert)

# DO-NOT-DELETE splicer.begin(_final)
# DO-NOT-DELETE splicer.end(_final)
