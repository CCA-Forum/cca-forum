#
# File:          PySimpleUnit_Impl.py
# Symbol:        library.PySimpleUnit-v1.0
# Symbol Type:   class
# Babel Version: 0.10.8
# Description:   Implementation of sidl class library.PySimpleUnit in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
# babel-version = 0.10.8
# xml-url       = /home/epperly/current/tutorial/src/components/../xml_repository/library.PySimpleUnit-v1.0.xml
#


# DO-NOT-DELETE splicer.begin(_initial)
# DO-NOT-DELETE splicer.end(_initial)

import sidl.ClassInfo
import units.Unit
import library.PySimpleUnit
import sidl.BaseInterface
import sidl.BaseClass

# DO-NOT-DELETE splicer.begin(_before_static)
# DO-NOT-DELETE splicer.end(_before_static)

def build(name, slope, offset):
  #
  # sidl EXPECTED INCOMING TYPES
  # ============================
  # string name
  # double slope
  # double offset
  #

  #
  # sidl EXPECTED RETURN VALUE(s)
  # =============================
  # library.PySimpleUnit _return
  #

  # DO-NOT-DELETE splicer.begin(build)
  result = library.PySimpleUnit.PySimpleUnit()
  result.init(name, slope, offset)
  return result
  # DO-NOT-DELETE splicer.end(build)

# DO-NOT-DELETE splicer.begin(_before_type)
# DO-NOT-DELETE splicer.end(_before_type)

class PySimpleUnit:

  # All calls to sidl methods should use __IORself

  def __init__(self, IORself):
    self.__IORself = IORself
    # DO-NOT-DELETE splicer.begin(__init__)
    self.d_name = None
    self.d_slope = 1
    self.d_offset = 0
    # DO-NOT-DELETE splicer.end(__init__)

  def init(self, name, slope, offset):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # string name
    # double slope
    # double offset
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # # None
    #

    # DO-NOT-DELETE splicer.begin(init)
    self.d_name = name
    self.d_slope = slope
    self.d_offset = offset
    # DO-NOT-DELETE splicer.end(init)

  def name(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # string _return
    #

    """\
Return the name of the unit 
"""
    # DO-NOT-DELETE splicer.begin(name)
    return self.d_name
    # DO-NOT-DELETE splicer.end(name)

  def conversionFactors(self):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # (slope, offset)
    # double slope
    # double offset
    #

    """\
Return the conversion factor to SI units. The return values
should satisfy the relation <value in SI units> = <value in
Unit units> * slope + offset.
"""
    # DO-NOT-DELETE splicer.begin(conversionFactors)
    return (self.d_slope, self.d_offset)
    # DO-NOT-DELETE splicer.end(conversionFactors)

# DO-NOT-DELETE splicer.begin(_final)
# DO-NOT-DELETE splicer.end(_final)
