/*
 * File:          arrayOps_CArrayOp_Impl.c
 * Symbol:        arrayOps.CArrayOp-v1.0
 * Symbol Type:   class
 * Babel Version: 0.99.3
 * Description:   Server-side implementation for arrayOps.CArrayOp
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "arrayOps.CArrayOp" (version 1.0)
 */

#include "arrayOps_CArrayOp_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"

/* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp._includes) */
/* Insert-Code-Here {arrayOps.CArrayOp._includes} (includes and arbitrary code) */
#include <stdio.h>
#include <stdlib.h>
#include "sidl_Exception.h"

#if (!defined NULL)
#define NULL 0
#endif
/* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp._includes) */

#define SIDL_IOR_MAJOR_VERSION 0
#define SIDL_IOR_MINOR_VERSION 10
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayOps_CArrayOp__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_arrayOps_CArrayOp__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp._load) */
  /* Insert-Code-Here {arrayOps.CArrayOp._load} (static class initializer method) */
  /* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayOps_CArrayOp__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_arrayOps_CArrayOp__ctor(
  /* in */ arrayOps_CArrayOp self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp._ctor) */
  sidl_BaseInterface throwaway_excpt = NULL;
  struct arrayOps_CArrayOp__data *pd = (struct arrayOps_CArrayOp__data*) 
             calloc(1, sizeof(struct arrayOps_CArrayOp__data));
  arrayOps_CArrayOp__set_data(self, pd);
  arrayOps_CArrayOp_init(self, &throwaway_excpt);
  return;
  
  /* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayOps_CArrayOp__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_arrayOps_CArrayOp__ctor2(
  /* in */ arrayOps_CArrayOp self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp._ctor2) */
    /* Insert-Code-Here {arrayOps.CArrayOp._ctor2} (special constructor method) */
    /*
     * This method has not been implemented
     */

    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayOps_CArrayOp__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_arrayOps_CArrayOp__dtor(
  /* in */ arrayOps_CArrayOp self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp._dtor) */
  /* Insert-Code-Here {arrayOps.CArrayOp._dtor} (destructor method) */
  
  struct arrayOps_CArrayOp__data *pd;
  sidl_BaseInterface throwaway_excpt = NULL;

  /* Access private data structure */
  pd = arrayOps_CArrayOp__get_data(self);
  arrayOps_CArrayOp_init(self, &throwaway_excpt);
  free(pd);
  arrayOps_CArrayOp__set_data(self, NULL);
  /* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp._dtor) */
  }
}

/*
 *  Initialize (or Re-Initialize) internal state in preparation
 * for accumulation.
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayOps_CArrayOp_init"

#ifdef __cplusplus
extern "C"
#endif
void
impl_arrayOps_CArrayOp_init(
  /* in */ arrayOps_CArrayOp self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp.init) */
  /* Insert-Code-Here {arrayOps.CArrayOp.init} (init method) */
  struct arrayOps_CArrayOp__data *pd;
  
  /* Access private data structure */
  pd = arrayOps_CArrayOp__get_data(self);
  if (pd) {
    if (pd->myVector)
       free(pd->myVector);
    pd->myVector = NULL;
    pd->myVecLen = 0;
  }
  return;
  /* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp.init) */
  }
}

/*
 *  Evaluate Acc = Acc + alpha A x,  where
 * Acc     The internal accumulator maintained by implementors 
 * of this interafce
 * return the result  in vector y (of size m)
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayOps_CArrayOp_mulMatVec"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_arrayOps_CArrayOp_mulMatVec(
  /* in */ arrayOps_CArrayOp self,
  /* in */ double alpha,
  /* in rarray[m,n] */ double* A,
  /* in rarray[n] */ double* x,
  /* inout rarray[m] */ double* y,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp.mulMatVec) */
  /* Insert-Code-Here {arrayOps.CArrayOp.mulMatVec} (mulMatVec method) */
  int32_t i, j;
  struct arrayOps_CArrayOp__data  *pd;
   
  pd = arrayOps_CArrayOp__get_data(self);
  if (!pd){
     fprintf(stderr, "FATAL EEROR:: %s:%d: Call to a method in an unintialized component.\n",
	     __FILE__, __LINE__);
     return -1;
  }
  if (!pd->myVector){  /* First time */
     pd->myVector = (double *) malloc (m * sizeof(double));
     for (i =0; i < m; i++)
        pd->myVector[i] = 0;
     pd->myVecLen = m;
  }
  else if (pd->myVecLen != m){  /* Size mismatch with previous calls */
     fprintf(stderr, "EEROR:: %s:%d: Size mismatch in linear operator.\n",
 	     __FILE__, __LINE__);
     return -1;
  }
     
  for (i= 0; i < m; i++){
     y[i] = 0.0;
     for (j = 0 ; j < n; j++){
        y[i] += alpha * A[j*m + i] * x[j];  /* Raw array A is column major */
/*        printf("%d  %d  %d  %.2f  %.2f  %.2f\n", 
					i, j, j*m + i, A[j*m + i], x[j], y[i]); */
     }
     pd->myVector[i] += y[i];
     y[i] = pd->myVector[i];
  }
  return 0;
  /* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp.mulMatVec) */
  }
}

/*
 *  Evaluate Acc = Acc + beta v,  where
 * Acc     The internal accumulator maintained by implementors 
 * of this interafce
 * return the result  in vector y (of size m)
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayOps_CArrayOp_addVec"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_arrayOps_CArrayOp_addVec(
  /* in */ arrayOps_CArrayOp self,
  /* in */ double beta,
  /* in array<double> */ struct sidl_double__array* v,
  /* out array<double> */ struct sidl_double__array** r,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp.addVec) */
  /* Insert-Code-Here {arrayOps.CArrayOp.addVec} (addVec method) */
  int32_t i, j;
  struct arrayOps_CArrayOp__data  *pd;
  double *rdata, *vdata;
  int32_t n, vstride;
   
  pd = arrayOps_CArrayOp__get_data(self);
  if (!pd){
     fprintf(stderr, "FATAL EEROR:: %s:%d: Call to a method in an unintialized component.\n",
	     __FILE__, __LINE__);
     return -1;
  }
  n = sidl_double__array_length(v,0);
  if (!pd->myVector){  /* First time */
     pd->myVector = (double *) malloc (n * sizeof(double));
     for (i =0; i < n; i++)
        pd->myVector[i] = 0;
     pd->myVecLen = n;
  }
  else if (pd->myVecLen != n){		/* Size mismatch with previous calls */
     fprintf(stderr, "EEROR:: %s:%d: Size mismatch in linear operator.\n",
 	     __FILE__, __LINE__);
     return -1;
  }
  *r = sidl_double__array_create1d(n);
  if (!*r){
     fprintf(stderr, "EEROR:: %s:%d: Unable to create return array.\n",
 	     __FILE__, __LINE__);
     return -1;
  }
  rdata = sidlArrayAddr1(*r, 0);  /* Access underlying array pointers */
  vdata = sidlArrayAddr1(v, 0);
  vstride = sidlStride(v, 0);
  for ( i = 0; i < n; i++){
     rdata[i] = pd->myVector[i] += beta * vdata[i*vstride];
  }
  return 0;
     
  /* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp.addVec) */
  }
}

/*
 *  Get result of linear operators              
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayOps_CArrayOp_getResult"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_arrayOps_CArrayOp_getResult(
  /* in */ arrayOps_CArrayOp self,
  /* inout rarray[m] */ double* r,
  /* in */ int32_t m,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp.getResult) */
  /* Insert-Code-Here {arrayOps.CArrayOp.getResult} (getResult method) */
  int32_t i;
  struct arrayOps_CArrayOp__data  *pd;
   ;
  pd = arrayOps_CArrayOp__get_data(self);
  if (!pd){
     fprintf(stderr, "FATAL EEROR:: %s:%d: Call to a method in an unintialized component.\n",
	     __FILE__, __LINE__);
     return -1;
  }
  else if (!pd->myVector){  /* First time */
     fprintf(stderr, "FATAL EEROR:: %s:%d: No linear operators previously applied.\n",
	     __FILE__, __LINE__);
     return -1;
  }
  else if (pd->myVecLen != m){		/* Size mismatch with previous calls */
     fprintf(stderr, "EEROR:: %s:%d: Size mismatch in linear operator.\n",
 	     __FILE__, __LINE__);
     return -1;
  }
  
  for ( i = 0; i < m; i++){
     r[i] = pd->myVector[i];
  }
  return 0;
  /* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp.getResult) */
  }
}

/*
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument Svc will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayOps_CArrayOp_setServices"

#ifdef __cplusplus
extern "C"
#endif
void
impl_arrayOps_CArrayOp_setServices(
  /* in */ arrayOps_CArrayOp self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp.setServices) */
  /* Insert-Code-Here {arrayOps.CArrayOp.setServices} (setServices method) */
   
  sidl_BaseInterface exception = NULL, throwaway_excpt = NULL;

  struct arrayOps_CArrayOp__data *pd;
  
  /* Access private data structure */
  pd = arrayOps_CArrayOp__get_data(self);
  if (pd->frameworkServices) {
    /* remove reference to previous services object */
    gov_cca_Services_deleteRef(pd->frameworkServices, &throwaway_excpt);
  }
  pd->frameworkServices = services;
  gov_cca_Services_addRef(services, &throwaway_excpt);
  
  /* Create a typemap for the LinearOp port */
  gov_cca_TypeMap tm = gov_cca_Services_createTypeMap(pd->frameworkServices, &exception);
  if (SIDL_CATCH(exception, "gov.cca.CCAException")) {
    fprintf(stderr, "Exception:: %s:%d: gov::cca::TypeMap was not created\n",
	    __FILE__, __LINE__);
    SIDL_CLEAR(exception);
    exit(1);
  }
  if (tm == NULL) {
    fprintf(stderr, "Error:: %s:%d: gov::cca::TypeMap is nil\n",
	    __FILE__, __LINE__);
    exit(1);  
  } 
  
  /* Provide an arrayop.LinearOp port */
  gov_cca_Port port = gov_cca_Port__cast(self, &throwaway_excpt);
  if (port == NULL) {
    fprintf(stderr, "Error:: %s:%d: Error casting self to gov::cca::Port \n",
	    __FILE__, __LINE__);
    exit(1);
  } 
  
  gov_cca_Services_addProvidesPort(pd->frameworkServices,   
				   port,
				   "LinearOpPort",
				   "arrayop.LinearOp",
				   tm,
				   &exception);
  if (SIDL_CATCH(exception, "gov.cca.CCAException")) {
    fprintf(stderr, "Exception:: %s:%d: Could not register arrayop.LinearOp provides port\n",
	    __FILE__, __LINE__);
    SIDL_CLEAR(exception);
    exit(1);
  }
  
  /* Register with framework for component release */
  gov_cca_ComponentRelease cr = gov_cca_ComponentRelease__cast(self, &throwaway_excpt);
  if (cr != NULL) {
    gov_cca_Services_registerForRelease(pd->frameworkServices, cr, &exception);
  }
  
  return;
  
  /* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp.setServices) */
  }
}

/*
 * Shuts down a component presence in the calling framework.
 * @param Svc the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument Svc will never be nil/null.
 * The argument Svc will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to Svc.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayOps_CArrayOp_releaseServices"

#ifdef __cplusplus
extern "C"
#endif
void
impl_arrayOps_CArrayOp_releaseServices(
  /* in */ arrayOps_CArrayOp self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp.releaseServices) */
  /* Insert-Code-Here {arrayOps.CArrayOp.releaseServices} (releaseServices method) */
  struct arrayOps_CArrayOp__data *pd;
  sidl_BaseInterface throwaway_excpt = NULL;
  
  /* Access private data structure */
  pd = arrayOps_CArrayOp__get_data(self);
  if (pd->frameworkServices) {
    /* remove reference to previous services object */
    gov_cca_Services_deleteRef(pd->frameworkServices, &throwaway_excpt);
  }
  pd->frameworkServices = NULL;
  return;
  /* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp.releaseServices) */
  }
}
/* Babel internal methods, Users should not edit below this line. */
struct arrayOps_CArrayOp__object* 
  impl_arrayOps_CArrayOp_fconnect_arrayOps_CArrayOp(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return arrayOps_CArrayOp__connectI(url, ar, _ex);
}
struct arrayOps_CArrayOp__object* 
  impl_arrayOps_CArrayOp_fcast_arrayOps_CArrayOp(void* bi,
  sidl_BaseInterface* _ex) {
  return arrayOps_CArrayOp__cast(bi, _ex);
}
struct arrayop_LinearOp__object* 
  impl_arrayOps_CArrayOp_fconnect_arrayop_LinearOp(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return arrayop_LinearOp__connectI(url, ar, _ex);
}
struct arrayop_LinearOp__object* 
  impl_arrayOps_CArrayOp_fcast_arrayop_LinearOp(void* bi,
  sidl_BaseInterface* _ex) {
  return arrayop_LinearOp__cast(bi, _ex);
}
struct gov_cca_CCAException__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_CCAException(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return gov_cca_CCAException__connectI(url, ar, _ex);
}
struct gov_cca_CCAException__object* 
  impl_arrayOps_CArrayOp_fcast_gov_cca_CCAException(void* bi,
  sidl_BaseInterface* _ex) {
  return gov_cca_CCAException__cast(bi, _ex);
}
struct gov_cca_Component__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_Component(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return gov_cca_Component__connectI(url, ar, _ex);
}
struct gov_cca_Component__object* 
  impl_arrayOps_CArrayOp_fcast_gov_cca_Component(void* bi,
  sidl_BaseInterface* _ex) {
  return gov_cca_Component__cast(bi, _ex);
}
struct gov_cca_ComponentRelease__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_ComponentRelease(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return gov_cca_ComponentRelease__connectI(url, ar, _ex);
}
struct gov_cca_ComponentRelease__object* 
  impl_arrayOps_CArrayOp_fcast_gov_cca_ComponentRelease(void* bi,
  sidl_BaseInterface* _ex) {
  return gov_cca_ComponentRelease__cast(bi, _ex);
}
struct gov_cca_Port__object* impl_arrayOps_CArrayOp_fconnect_gov_cca_Port(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return gov_cca_Port__connectI(url, ar, _ex);
}
struct gov_cca_Port__object* impl_arrayOps_CArrayOp_fcast_gov_cca_Port(void* bi,
  sidl_BaseInterface* _ex) {
  return gov_cca_Port__cast(bi, _ex);
}
struct gov_cca_Services__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_Services(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return gov_cca_Services__connectI(url, ar, _ex);
}
struct gov_cca_Services__object* 
  impl_arrayOps_CArrayOp_fcast_gov_cca_Services(void* bi,
  sidl_BaseInterface* _ex) {
  return gov_cca_Services__cast(bi, _ex);
}
struct sidl_BaseClass__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_BaseClass(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connectI(url, ar, _ex);
}
struct sidl_BaseClass__object* 
  impl_arrayOps_CArrayOp_fcast_sidl_BaseClass(void* bi,
  sidl_BaseInterface* _ex) {
  return sidl_BaseClass__cast(bi, _ex);
}
struct sidl_BaseInterface__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_BaseInterface(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connectI(url, ar, _ex);
}
struct sidl_BaseInterface__object* 
  impl_arrayOps_CArrayOp_fcast_sidl_BaseInterface(void* bi,
  sidl_BaseInterface* _ex) {
  return sidl_BaseInterface__cast(bi, _ex);
}
struct sidl_ClassInfo__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_ClassInfo(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connectI(url, ar, _ex);
}
struct sidl_ClassInfo__object* 
  impl_arrayOps_CArrayOp_fcast_sidl_ClassInfo(void* bi,
  sidl_BaseInterface* _ex) {
  return sidl_ClassInfo__cast(bi, _ex);
}
struct sidl_RuntimeException__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_RuntimeException(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_RuntimeException__connectI(url, ar, _ex);
}
struct sidl_RuntimeException__object* 
  impl_arrayOps_CArrayOp_fcast_sidl_RuntimeException(void* bi,
  sidl_BaseInterface* _ex) {
  return sidl_RuntimeException__cast(bi, _ex);
}
