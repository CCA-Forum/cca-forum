/*
 * File:          QuadFunction_Impl.java
 * Symbol:        functions.QuadFunction-v1.0
 * Symbol Type:   class
 * Babel Version: 0.99.3
 * Description:   Server-side implementation for functions.QuadFunction
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package functions;

import function.FunctionPort;
import gov.cca.CCAException;
import gov.cca.Component;
import gov.cca.Port;
import gov.cca.Services;
import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;

// DO-NOT-DELETE splicer.begin(functions.QuadFunction._imports)
// Insert-Code-Here {functions.QuadFunction._imports} (additional imports)
// DO-NOT-DELETE splicer.end(functions.QuadFunction._imports)

/**
 * Symbol "functions.QuadFunction" (version 1.0)
 */
public class QuadFunction_Impl extends QuadFunction
{

  // DO-NOT-DELETE splicer.begin(functions.QuadFunction._data)
  // Insert-Code-Here {functions.QuadFunction._data} (private data)
  
  gov.cca.Services frameworkServices;
  // DO-NOT-DELETE splicer.end(functions.QuadFunction._data)

  static { 
  // DO-NOT-DELETE splicer.begin(functions.QuadFunction._load)
  // Insert-Code-Here {functions.QuadFunction._load} (class initialization)
  // DO-NOT-DELETE splicer.end(functions.QuadFunction._load)
  }

  /**
   * User defined constructor
   */
  public QuadFunction_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(functions.QuadFunction.QuadFunction)
    // Insert-Code-Here {functions.QuadFunction.QuadFunction} (constructor)
    // DO-NOT-DELETE splicer.end(functions.QuadFunction.QuadFunction)
  }

  /**
   * Back door constructor
   */
  public QuadFunction_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(functions.QuadFunction._wrap)
    // Insert-Code-Here {functions.QuadFunction._wrap} (_wrap)
    // DO-NOT-DELETE splicer.end(functions.QuadFunction._wrap)
  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(functions.QuadFunction._dtor)
    // Insert-Code-Here {functions.QuadFunction._dtor} (destructor)
    // DO-NOT-DELETE splicer.end(functions.QuadFunction._dtor)
  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(functions.QuadFunction.finalize)
    // Insert-Code-Here {functions.QuadFunction.finalize} (finalize)
    // DO-NOT-DELETE splicer.end(functions.QuadFunction.finalize)
  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  init[]
   */
  public void init_Impl (
    /*in*/ sidl.Double.Array1 params ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(functions.QuadFunction.init)
    // Insert-Code-Here {functions.QuadFunction.init} (init)
    /*
     * This method has not been implemented
     */

    sidl.NotImplementedException noImpl = new sidl.NotImplementedException();
    noImpl.setNote("This method has not been implmented.");
    sidl.RuntimeException.Wrapper rex = (sidl.RuntimeException.Wrapper) sidl.RuntimeException.Wrapper._cast(noImpl);
    throw rex;
    // DO-NOT-DELETE splicer.end(functions.QuadFunction.init)
  }

  /**
   * Method:  evaluate[]
   */
  public double evaluate_Impl (
    /*in*/ double x ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(functions.QuadFunction.evaluate)
    // Insert-Code-Here {functions.QuadFunction.evaluate} (evaluate)

    return x * x;

    // DO-NOT-DELETE splicer.end(functions.QuadFunction.evaluate)
  }

  /**
   *  Starts up a component presence in the calling framework.
   * @param services the component instance's handle on the framework world.
   * Contracts concerning Svc and setServices:
   * 
   * The component interaction with the CCA framework
   * and Ports begins on the call to setServices by the framework.
   * 
   * This function is called exactly once for each instance created
   * by the framework.
   * 
   * The argument Svc will never be nil/null.
   * 
   * Those uses ports which are automatically connected by the framework
   * (so-called service-ports) may be obtained via getPort during
   * setServices.
   */
  public void setServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(functions.QuadFunction.setServices)
    // Insert-Code-Here {functions.QuadFunction.setServices} (setServices)

    frameworkServices = services;
    gov.cca.TypeMap tm = services.createTypeMap();
    services.addProvidesPort((gov.cca.Port)this, 
                             "FunctionPort",
                             "function.FunctionPort", tm);
    return;
    // DO-NOT-DELETE splicer.end(functions.QuadFunction.setServices)
  }


  // DO-NOT-DELETE splicer.begin(functions.QuadFunction._misc)
  // Insert-Code-Here {functions.QuadFunction._misc} (miscellaneous)
  // DO-NOT-DELETE splicer.end(functions.QuadFunction._misc)

} // end class QuadFunction

