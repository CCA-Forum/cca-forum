// 
// File:          library_CxxUnitsLibraryComp_Impl.hxx
// Symbol:        library.CxxUnitsLibraryComp-v1.0
// Symbol Type:   class
// Babel Version: 0.99.3
// Description:   Server-side implementation for library.CxxUnitsLibraryComp
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_library_CxxUnitsLibraryComp_Impl_hxx
#define included_library_CxxUnitsLibraryComp_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_library_CxxUnitsLibraryComp_IOR_h
#include "library_CxxUnitsLibraryComp_IOR.h"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Component_hxx
#include "gov_cca_Component.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_library_CxxUnitsLibraryComp_hxx
#include "library_CxxUnitsLibraryComp.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_units_Conversion_hxx
#include "units_Conversion.hxx"
#endif
#ifndef included_units_Unit_hxx
#include "units_Unit.hxx"
#endif
#ifndef included_units_UnitsLibrary_hxx
#include "units_UnitsLibrary.hxx"
#endif
#ifndef included_units_UnknownUnitException_hxx
#include "units_UnknownUnitException.hxx"
#endif


// DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp._includes)
#include <map>
// DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp._includes)

namespace library { 

  /**
   * Symbol "library.CxxUnitsLibraryComp" (version 1.0)
   */
  class CxxUnitsLibraryComp_impl : public virtual 
    ::library::CxxUnitsLibraryComp 
  // DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp._inherits)
  // DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    // DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp._implementation)
    ::std::map<const ::std::string,::units::Unit> d_library;
    // DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp._implementation)

    bool _wrapped;
  public:
    // default constructor, used for data wrapping(required)
    CxxUnitsLibraryComp_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    CxxUnitsLibraryComp_impl( struct library_CxxUnitsLibraryComp__object * s ) 
      : StubBase(s,true), _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~CxxUnitsLibraryComp_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:


    /**
     *  Starts up a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning Svc and setServices:
     * 
     * The component interaction with the CCA framework
     * and Ports begins on the call to setServices by the framework.
     * 
     * This function is called exactly once for each instance created
     * by the framework.
     * 
     * The argument Svc will never be nil/null.
     * 
     * Those uses ports which are automatically connected by the framework
     * (so-called service-ports) may be obtained via getPort during
     * setServices.
     */
    void
    setServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;


    /**
     * Generate conversion factors for a pair of units.
     */
    ::units::Conversion
    lookupConversion_impl (
      /* in */::units::Unit src,
      /* in */::units::Unit dest
    )
    ;


    /**
     * Define a new unit. Units defined are automatically
     * registered in the library. slope and offset should
     * be defined so that <value in knownUnit> = slope 
     * <value in newUnit> + offset.
     */
    void
    defineUnit_impl (
      /* in */const ::std::string& name,
      /* in */double slope,
      /* in */double offset,
      /* in */::units::Unit knownUnit,
      /* out */::units::Unit& newUnit
    )
    ;


    /**
     * Transform a Conversion interface to convert values in the 
     * opposite direction. Note this can modify or replace the 
     * incoming parameter.
     */
    void
    invertConversion_impl (
      /* inout */::units::Conversion& convert
    )
    ;


    /**
     * Lookup a unit definition. If no matching unit is found,
     * the UnknownUnitException is thrown.
     */
    ::units::Unit
    lookupUnit_impl (
      /* in */const ::std::string& name
    )
    // throws:
    //     ::sidl::RuntimeException
    //     ::units::UnknownUnitException
    ;

  };  // end class CxxUnitsLibraryComp_impl

} // end namespace library

// DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp._misc)
// Insert-Code-Here {library.CxxUnitsLibraryComp._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp._misc)

#endif
