// 
// File:          library_CxxSimpleUnit_Impl.cc
// Symbol:        library.CxxSimpleUnit-v1.0
// Symbol Type:   class
// Babel Version: 0.10.8
// Description:   Server-side implementation for library.CxxSimpleUnit
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.10.8
// xml-url       = /home/epperly/current/tutorial/src/components/../xml_repository/library.CxxSimpleUnit-v1.0.xml
// 
#include "library_CxxSimpleUnit_Impl.hh"

// DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._includes)
// Insert-Code-Here {library.CxxSimpleUnit._includes} (additional includes or code)
// DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._includes)

// user-defined constructor.
void library::CxxSimpleUnit_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._ctor)
  d_slope = 1.0;
  d_offset = 0;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._ctor)
}

// user-defined destructor.
void library::CxxSimpleUnit_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._dtor)
  // Insert-Code-Here {library.CxxSimpleUnit._dtor} (destructor)
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._dtor)
}

// static class initializer.
void library::CxxSimpleUnit_impl::_load() {
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._load)
  // Insert-Code-Here {library.CxxSimpleUnit._load} (class initialization)
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._load)
}

// user-defined static methods:
/**
 * Method:  build[]
 */
::library::CxxSimpleUnit
library::CxxSimpleUnit_impl::build (
  /* in */ const ::std::string& name,
  /* in */ double slope,
  /* in */ double offset ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit.build)
  ::library::CxxSimpleUnit unit = ::library::CxxSimpleUnit::_create();
  unit.init(name, slope, offset);
  return unit;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit.build)
}


// user-defined non-static methods:
/**
 * Method:  init[]
 */
void
library::CxxSimpleUnit_impl::init (
  /* in */ const ::std::string& name,
  /* in */ double slope,
  /* in */ double offset ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit.init)
  d_name = name;
  d_slope = slope;
  d_offset = offset;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit.init)
}

/**
 * Return the name of the unit 
 */
::std::string
library::CxxSimpleUnit_impl::name ()
throw () 

{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit.name)
  return d_name;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit.name)
}

/**
 * Return the conversion factor to SI units. The return values
 * should satisfy the relation <value in SI units> = <value in
 * Unit units> * slope + offset.
 */
void
library::CxxSimpleUnit_impl::conversionFactors (
  /* out */ double& slope,
  /* out */ double& offset ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit.conversionFactors)
  slope = d_slope;
  offset = d_offset;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit.conversionFactors)
}


// DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._misc)
// Insert-Code-Here {library.CxxSimpleUnit._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._misc)

