// 
// File:          library_CxxUnknownException_Impl.hh
// Symbol:        library.CxxUnknownException-v1.0
// Symbol Type:   class
// Babel Version: 0.10.8
// Description:   Server-side implementation for library.CxxUnknownException
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.10.8
// xml-url       = /home/epperly/current/tutorial/src/components/../xml_repository/library.CxxUnknownException-v1.0.xml
// 

#ifndef included_library_CxxUnknownException_Impl_hh
#define included_library_CxxUnknownException_Impl_hh

#ifndef included_sidl_cxx_hh
#include "sidl_cxx.hh"
#endif
#ifndef included_library_CxxUnknownException_IOR_h
#include "library_CxxUnknownException_IOR.h"
#endif
// 
// Includes for all method dependencies.
// 
#ifndef included_library_CxxUnknownException_hh
#include "library_CxxUnknownException.hh"
#endif
#ifndef included_sidl_BaseInterface_hh
#include "sidl_BaseInterface.hh"
#endif
#ifndef included_sidl_ClassInfo_hh
#include "sidl_ClassInfo.hh"
#endif


// DO-NOT-DELETE splicer.begin(library.CxxUnknownException._includes)
// DO-NOT-DELETE splicer.end(library.CxxUnknownException._includes)

namespace library { 

  /**
   * Symbol "library.CxxUnknownException" (version 1.0)
   */
  class CxxUnknownException_impl
  // DO-NOT-DELETE splicer.begin(library.CxxUnknownException._inherits)
  // DO-NOT-DELETE splicer.end(library.CxxUnknownException._inherits)
  {

  private:
    // Pointer back to IOR.
    // Use this to dispatch back through IOR vtable.
    CxxUnknownException self;

    // DO-NOT-DELETE splicer.begin(library.CxxUnknownException._implementation)
    // DO-NOT-DELETE splicer.end(library.CxxUnknownException._implementation)

  private:
    // private default constructor (required)
    CxxUnknownException_impl() 
    {} 

  public:
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    CxxUnknownException_impl( struct library_CxxUnknownException__object * s ) 
      : self(s,true) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~CxxUnknownException_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // static class initializer
    static void _load();

  public:

  };  // end class CxxUnknownException_impl

} // end namespace library

// DO-NOT-DELETE splicer.begin(library.CxxUnknownException._misc)
// DO-NOT-DELETE splicer.end(library.CxxUnknownException._misc)

#endif
