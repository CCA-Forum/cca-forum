// 
// File:          library_CxxSimpleUnit_Impl.cxx
// Symbol:        library.CxxSimpleUnit-v1.0
// Symbol Type:   class
// Babel Version: 0.99.3
// Description:   Server-side implementation for library.CxxSimpleUnit
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "library_CxxSimpleUnit_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_library_CxxSimpleUnit_hxx
#include "library_CxxSimpleUnit.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._includes)
// Insert-Code-Here {library.CxxSimpleUnit._includes} (additional includes or code)
// DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
library::CxxSimpleUnit_impl::CxxSimpleUnit_impl() : StubBase(reinterpret_cast< 
  void*>(::library::CxxSimpleUnit::_wrapObj(this)),false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._ctor2)
  // Insert-Code-Here {library.CxxSimpleUnit._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._ctor2)
}

// user defined constructor
void library::CxxSimpleUnit_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._ctor)
  d_slope = 1.0;
  d_offset = 0;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._ctor)
}

// user defined destructor
void library::CxxSimpleUnit_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._dtor)
  // Insert-Code-Here {library.CxxSimpleUnit._dtor} (destructor)
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._dtor)
}

// static class initializer
void library::CxxSimpleUnit_impl::_load() {
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._load)
  // Insert-Code-Here {library.CxxSimpleUnit._load} (class initialization)
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._load)
}

// user defined static methods:
/**
 * Method:  build[]
 */
::library::CxxSimpleUnit
library::CxxSimpleUnit_impl::build_impl (
  /* in */const ::std::string& name,
  /* in */double slope,
  /* in */double offset ) 
{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit.build)
  ::library::CxxSimpleUnit unit = ::library::CxxSimpleUnit::_create();
  unit.init(name, slope, offset);
  return unit;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit.build)
}


// user defined non-static methods:
/**
 * Method:  init[]
 */
void
library::CxxSimpleUnit_impl::init_impl (
  /* in */const ::std::string& name,
  /* in */double slope,
  /* in */double offset ) 
{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit.init)
  d_name = name;
  d_slope = slope;
  d_offset = offset;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit.init)
}

/**
 *  Return the name of the unit 
 */
::std::string
library::CxxSimpleUnit_impl::name_impl () 

{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit.name)
  return d_name;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit.name)
}

/**
 *  
 * Return the conversion factor to SI units. The return values
 * should satisfy the relation <value in SI units> = <value in
 * Unit units>  slope + offset.
 */
void
library::CxxSimpleUnit_impl::conversionFactors_impl (
  /* out */double& slope,
  /* out */double& offset ) 
{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit.conversionFactors)
  slope = d_slope;
  offset = d_offset;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit.conversionFactors)
}


// DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._misc)
// Insert-Code-Here {library.CxxSimpleUnit._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._misc)

