// 
// File:          library_CxxSimpleUnit_Impl.hxx
// Symbol:        library.CxxSimpleUnit-v1.0
// Symbol Type:   class
// Babel Version: 0.99.3
// Description:   Server-side implementation for library.CxxSimpleUnit
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_library_CxxSimpleUnit_Impl_hxx
#define included_library_CxxSimpleUnit_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_library_CxxSimpleUnit_IOR_h
#include "library_CxxSimpleUnit_IOR.h"
#endif
#ifndef included_library_CxxSimpleUnit_hxx
#include "library_CxxSimpleUnit.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_units_Unit_hxx
#include "units_Unit.hxx"
#endif


// DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._includes)
#include <string>
// DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._includes)

namespace library { 

  /**
   * Symbol "library.CxxSimpleUnit" (version 1.0)
   */
  class CxxSimpleUnit_impl : public virtual ::library::CxxSimpleUnit 
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._inherits)
  // Insert-Code-Here {library.CxxSimpleUnit._inherits} (optional inheritance here)
  // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    // DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._implementation)
    std::string d_name;
    double      d_slope;
    double      d_offset;
    // DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._implementation)

    bool _wrapped;
  public:
    // default constructor, used for data wrapping(required)
    CxxSimpleUnit_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    CxxSimpleUnit_impl( struct library_CxxSimpleUnit__object * s ) : StubBase(s,
      true), _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~CxxSimpleUnit_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:
    /**
     * user defined static method
     */
    static ::library::CxxSimpleUnit
    build_impl (
      /* in */const ::std::string& name,
      /* in */double slope,
      /* in */double offset
    )
    ;


    /**
     * user defined non-static method.
     */
    void
    init_impl (
      /* in */const ::std::string& name,
      /* in */double slope,
      /* in */double offset
    )
    ;


    /**
     *  Return the name of the unit 
     */
    ::std::string
    name_impl() ;

    /**
     *  
     * Return the conversion factor to SI units. The return values
     * should satisfy the relation <value in SI units> = <value in
     * Unit units>  slope + offset.
     */
    void
    conversionFactors_impl (
      /* out */double& slope,
      /* out */double& offset
    )
    ;

  };  // end class CxxSimpleUnit_impl

} // end namespace library

// DO-NOT-DELETE splicer.begin(library.CxxSimpleUnit._misc)
// Insert-Code-Here {library.CxxSimpleUnit._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(library.CxxSimpleUnit._misc)

#endif
