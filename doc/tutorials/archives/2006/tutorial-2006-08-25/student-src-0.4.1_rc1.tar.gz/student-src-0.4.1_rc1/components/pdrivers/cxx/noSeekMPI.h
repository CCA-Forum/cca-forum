#ifndef tut_noSeekMPI_h_seen
#define tut_noSeekMPI_h_seen
/* a workaround to allow mpi.h c++ and stdio/iostream in the same file.
 * in the presence of mpi 2 SEEK binding.
 *
 * If including iostream or stdio before mpi.h,
 * include this file and then mpi.h.
 * If including iostream or stdio after mpi.h,
 * include mpi.h, this file , and then the io header.
 */
#undef SEEK_SET
#undef SEEK_CUR
#undef SEEK_END
#endif /* tut_noSeekMPI_h_seen */
