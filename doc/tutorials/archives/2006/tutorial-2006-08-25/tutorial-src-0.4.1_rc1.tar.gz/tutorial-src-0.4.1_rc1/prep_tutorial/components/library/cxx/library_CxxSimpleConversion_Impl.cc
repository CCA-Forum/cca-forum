// 
// File:          library_CxxSimpleConversion_Impl.cc
// Symbol:        library.CxxSimpleConversion-v1.0
// Symbol Type:   class
// Babel Version: 0.10.8
// Description:   Server-side implementation for library.CxxSimpleConversion
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.10.8
// xml-url       = /home/epperly/current/tutorial/src/components/../xml_repository/library.CxxSimpleConversion-v1.0.xml
// 
#include "library_CxxSimpleConversion_Impl.hh"

// DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._includes)
// Insert-Code-Here {library.CxxSimpleConversion._includes} (additional includes or code)
// DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._includes)

// user-defined constructor.
void library::CxxSimpleConversion_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._ctor)
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._ctor)
}

// user-defined destructor.
void library::CxxSimpleConversion_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._dtor)
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._dtor)
}

// static class initializer.
void library::CxxSimpleConversion_impl::_load() {
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._load)
  // Insert-Code-Here {library.CxxSimpleConversion._load} (class initialization)
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._load)
}

// user-defined static methods:
/**
 * Method:  build[]
 */
::library::CxxSimpleConversion
library::CxxSimpleConversion_impl::build (
  /* in */ ::units::Unit fromUnit,
  /* in */ ::units::Unit toUnit ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion.build)
  ::library::CxxSimpleConversion sc = ::library::CxxSimpleConversion::_create();
  sc.init(fromUnit, toUnit);
  return sc;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion.build)
}


// user-defined non-static methods:
/**
 * Method:  init[]
 */
void
library::CxxSimpleConversion_impl::init (
  /* in */ ::units::Unit fromUnit,
  /* in */ ::units::Unit toUnit ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion.init)
  d_fromUnit = fromUnit;
  d_toUnit = toUnit;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion.init)
}

/**
 * Reverse the direction of the conversion.
 */
void
library::CxxSimpleConversion_impl::reverse ()
throw () 

{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion.reverse)
  ::units::Unit tmp;
  tmp = d_fromUnit;
  d_fromUnit = d_toUnit;
  d_toUnit = tmp;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion.reverse)
}

/**
 * Return the unit that this Conversion interface will convert
 * from.
 */
::units::Unit
library::CxxSimpleConversion_impl::convertFrom ()
throw () 

{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion.convertFrom)
  return d_fromUnit;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion.convertFrom)
}

/**
 * Return the unit that this interface will convert to.
 */
::units::Unit
library::CxxSimpleConversion_impl::convertTo ()
throw () 

{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion.convertTo)
  return d_toUnit;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion.convertTo)
}

/**
 * Convert a physical quantity from old set of units to another.
 */
double
library::CxxSimpleConversion_impl::convert (
  /* in */ double orig ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion.convert)
  double slope, offset;
  double siValue;
  d_fromUnit.conversionFactors(slope, offset);
  siValue = slope*orig + offset;
  d_toUnit.conversionFactors(slope, offset);
  return (siValue - offset)/slope;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion.convert)
}


// DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._misc)
// DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._misc)

