#!/bin/sh

# Try to determine the number of CPUs or cores for various systems; this is incomplete, 
# so the default is 1

system=`uname`
cputype=`uname -m`
ncores=1

if [ "$cputype" == "i386" -o "$cputype" == "i586" -o "$cputype" == "i686" \
   -o "$cputype" == "x86_64" ] ; then 
  if [ "$system" == "Linux" ] ; then 
    if [ -e "/proc/cpuinfo" ] ; then
      ncores=`grep "^processor" /proc/cpuinfo | wc -l`
    fi
  elif [ "$system" == "Darwin" ] ; then
    ncores=`system_profiler  -detailLevel mini | grep "Number Of Cores" | sed -e 's/Number Of Cores: //'`
  fi
fi  

echo $ncores
