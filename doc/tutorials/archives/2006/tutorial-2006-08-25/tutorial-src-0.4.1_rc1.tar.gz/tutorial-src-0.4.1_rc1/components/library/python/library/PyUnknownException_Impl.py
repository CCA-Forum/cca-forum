#
# File:          PyUnknownException_Impl.py
# Symbol:        library.PyUnknownException-v1.0
# Symbol Type:   class
# Babel Version: 0.99.3
# Description:   Implementation of sidl class library.PyUnknownException in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
#


# DO-NOT-DELETE splicer.begin(_initial)
# Insert-Code-Here {_initial} ()
# DO-NOT-DELETE splicer.end(_initial)

import library.PyUnknownException
import sidl.BaseClass
import sidl.BaseException
import sidl.BaseInterface
import sidl.ClassInfo
import sidl.RuntimeException
import sidl.SIDLException
import sidl.io.Deserializer
import sidl.io.Serializable
import sidl.io.Serializer
import units.UnknownUnitException
import sidl.NotImplementedException

# DO-NOT-DELETE splicer.begin(_before_type)
# DO-NOT-DELETE splicer.end(_before_type)

class PyUnknownException:

  # All calls to sidl methods should use __IORself

  # Normal Babel creation pases in an IORself. If IORself == None
  # that means this Impl class is being constructed for native delegation
  def __init__(self, IORself = None):
    if (IORself == None):
      self.__IORself = library.PyUnknownException.PyUnknownException(impl =   \
        self)
    else:
      self.__IORself = IORself
    # DO-NOT-DELETE splicer.begin(__init__)
    # DO-NOT-DELETE splicer.end(__init__)

  # Returns the IORself (client stub) of the Impl, mainly for use
  # with native delegation
  def _getStub(self):
    return self.__IORself

# DO-NOT-DELETE splicer.begin(_final)
# DO-NOT-DELETE splicer.end(_final)
