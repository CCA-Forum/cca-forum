// 
// File:          library_CxxUnknownException_Impl.hxx
// Symbol:        library.CxxUnknownException-v1.0
// Symbol Type:   class
// Babel Version: 0.99.3
// Description:   Server-side implementation for library.CxxUnknownException
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_library_CxxUnknownException_Impl_hxx
#define included_library_CxxUnknownException_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_library_CxxUnknownException_IOR_h
#include "library_CxxUnknownException_IOR.h"
#endif
#ifndef included_library_CxxUnknownException_hxx
#include "library_CxxUnknownException.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_SIDLException_hxx
#include "sidl_SIDLException.hxx"
#endif
#ifndef included_sidl_io_Deserializer_hxx
#include "sidl_io_Deserializer.hxx"
#endif
#ifndef included_sidl_io_Serializer_hxx
#include "sidl_io_Serializer.hxx"
#endif
#ifndef included_units_UnknownUnitException_hxx
#include "units_UnknownUnitException.hxx"
#endif


// DO-NOT-DELETE splicer.begin(library.CxxUnknownException._includes)
// DO-NOT-DELETE splicer.end(library.CxxUnknownException._includes)

namespace library { 

  /**
   * Symbol "library.CxxUnknownException" (version 1.0)
   */
  class CxxUnknownException_impl : public virtual 
    ::library::CxxUnknownException 
  // DO-NOT-DELETE splicer.begin(library.CxxUnknownException._inherits)
  // DO-NOT-DELETE splicer.end(library.CxxUnknownException._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    // DO-NOT-DELETE splicer.begin(library.CxxUnknownException._implementation)
    // DO-NOT-DELETE splicer.end(library.CxxUnknownException._implementation)

    bool _wrapped;
  public:
    // default constructor, used for data wrapping(required)
    CxxUnknownException_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    CxxUnknownException_impl( struct library_CxxUnknownException__object * s ) 
      : StubBase(s,true), _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~CxxUnknownException_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

  };  // end class CxxUnknownException_impl

} // end namespace library

// DO-NOT-DELETE splicer.begin(library.CxxUnknownException._misc)
// DO-NOT-DELETE splicer.end(library.CxxUnknownException._misc)

#endif
