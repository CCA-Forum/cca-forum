// 
// File:          library_CxxSimpleConversion_Impl.cxx
// Symbol:        library.CxxSimpleConversion-v1.0
// Symbol Type:   class
// Babel Version: 0.99.3
// Description:   Server-side implementation for library.CxxSimpleConversion
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "library_CxxSimpleConversion_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_library_CxxSimpleConversion_hxx
#include "library_CxxSimpleConversion.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_units_Unit_hxx
#include "units_Unit.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._includes)
// Insert-Code-Here {library.CxxSimpleConversion._includes} (additional includes or code)
// DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
library::CxxSimpleConversion_impl::CxxSimpleConversion_impl() : 
  StubBase(reinterpret_cast< 
  void*>(::library::CxxSimpleConversion::_wrapObj(this)),false) ,
  _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._ctor2)
  // Insert-Code-Here {library.CxxSimpleConversion._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._ctor2)
}

// user defined constructor
void library::CxxSimpleConversion_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._ctor)
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._ctor)
}

// user defined destructor
void library::CxxSimpleConversion_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._dtor)
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._dtor)
}

// static class initializer
void library::CxxSimpleConversion_impl::_load() {
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._load)
  // Insert-Code-Here {library.CxxSimpleConversion._load} (class initialization)
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._load)
}

// user defined static methods:
/**
 * Method:  build[]
 */
::library::CxxSimpleConversion
library::CxxSimpleConversion_impl::build_impl (
  /* in */::units::Unit fromUnit,
  /* in */::units::Unit toUnit ) 
{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion.build)
  ::library::CxxSimpleConversion sc = ::library::CxxSimpleConversion::_create();
  sc.init(fromUnit, toUnit);
  return sc;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion.build)
}


// user defined non-static methods:
/**
 * Method:  init[]
 */
void
library::CxxSimpleConversion_impl::init_impl (
  /* in */::units::Unit fromUnit,
  /* in */::units::Unit toUnit ) 
{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion.init)
  d_fromUnit = fromUnit;
  d_toUnit = toUnit;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion.init)
}

/**
 * Reverse the direction of the conversion.
 */
void
library::CxxSimpleConversion_impl::reverse_impl () 

{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion.reverse)
  ::units::Unit tmp;
  tmp = d_fromUnit;
  d_fromUnit = d_toUnit;
  d_toUnit = tmp;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion.reverse)
}

/**
 * Return the unit that this Conversion interface will convert
 * from.
 */
::units::Unit
library::CxxSimpleConversion_impl::convertFrom_impl () 

{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion.convertFrom)
  return d_fromUnit;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion.convertFrom)
}

/**
 * Return the unit that this interface will convert to.
 */
::units::Unit
library::CxxSimpleConversion_impl::convertTo_impl () 

{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion.convertTo)
  return d_toUnit;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion.convertTo)
}

/**
 * Convert a physical quantity from old set of units to another.
 */
double
library::CxxSimpleConversion_impl::convert_impl (
  /* in */double orig ) 
{
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion.convert)
  double slope, offset;
  double siValue;
  d_fromUnit.conversionFactors(slope, offset);
  siValue = slope*orig + offset;
  d_toUnit.conversionFactors(slope, offset);
  return (siValue - offset)/slope;
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion.convert)
}


// DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._misc)
// DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._misc)

