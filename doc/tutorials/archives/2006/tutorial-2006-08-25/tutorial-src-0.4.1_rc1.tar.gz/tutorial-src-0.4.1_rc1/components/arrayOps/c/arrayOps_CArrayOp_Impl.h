/*
 * File:          arrayOps_CArrayOp_Impl.h
 * Symbol:        arrayOps.CArrayOp-v1.0
 * Symbol Type:   class
 * Babel Version: 0.99.3
 * Description:   Server-side implementation for arrayOps.CArrayOp
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_arrayOps_CArrayOp_Impl_h
#define included_arrayOps_CArrayOp_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_arrayOps_CArrayOp_h
#include "arrayOps_CArrayOp.h"
#endif
#ifndef included_arrayop_LinearOp_h
#include "arrayop_LinearOp.h"
#endif
#ifndef included_gov_cca_CCAException_h
#include "gov_cca_CCAException.h"
#endif
#ifndef included_gov_cca_Component_h
#include "gov_cca_Component.h"
#endif
#ifndef included_gov_cca_ComponentRelease_h
#include "gov_cca_ComponentRelease.h"
#endif
#ifndef included_gov_cca_Port_h
#include "gov_cca_Port.h"
#endif
#ifndef included_gov_cca_Services_h
#include "gov_cca_Services.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif

/* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp._includes) */
/* Insert-Code-Here {arrayOps.CArrayOp._includes} (include files) */
/* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp._includes) */

/*
 * Private data for class arrayOps.CArrayOp
 */

struct arrayOps_CArrayOp__data {
  /* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp._data) */
  gov_cca_Services  frameworkServices;
  double 			  *myVector;
  int    			  myVecLen;
  /* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct arrayOps_CArrayOp__data*
arrayOps_CArrayOp__get_data(
  arrayOps_CArrayOp);

extern void
arrayOps_CArrayOp__set_data(
  arrayOps_CArrayOp,
  struct arrayOps_CArrayOp__data*);

extern
void
impl_arrayOps_CArrayOp__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_arrayOps_CArrayOp__ctor(
  /* in */ arrayOps_CArrayOp self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_arrayOps_CArrayOp__ctor2(
  /* in */ arrayOps_CArrayOp self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_arrayOps_CArrayOp__dtor(
  /* in */ arrayOps_CArrayOp self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct arrayOps_CArrayOp__object* 
  impl_arrayOps_CArrayOp_fconnect_arrayOps_CArrayOp(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct arrayOps_CArrayOp__object* 
  impl_arrayOps_CArrayOp_fcast_arrayOps_CArrayOp(void* bi,
  sidl_BaseInterface* _ex);
extern struct arrayop_LinearOp__object* 
  impl_arrayOps_CArrayOp_fconnect_arrayop_LinearOp(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct arrayop_LinearOp__object* 
  impl_arrayOps_CArrayOp_fcast_arrayop_LinearOp(void* bi,
  sidl_BaseInterface* _ex);
extern struct gov_cca_CCAException__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_CCAException(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_CCAException__object* 
  impl_arrayOps_CArrayOp_fcast_gov_cca_CCAException(void* bi,
  sidl_BaseInterface* _ex);
extern struct gov_cca_Component__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_Component(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_Component__object* 
  impl_arrayOps_CArrayOp_fcast_gov_cca_Component(void* bi,
  sidl_BaseInterface* _ex);
extern struct gov_cca_ComponentRelease__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_ComponentRelease(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_ComponentRelease__object* 
  impl_arrayOps_CArrayOp_fcast_gov_cca_ComponentRelease(void* bi,
  sidl_BaseInterface* _ex);
extern struct gov_cca_Port__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_Port(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct gov_cca_Port__object* 
  impl_arrayOps_CArrayOp_fcast_gov_cca_Port(void* bi, sidl_BaseInterface* _ex);
extern struct gov_cca_Services__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_Services(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_Services__object* 
  impl_arrayOps_CArrayOp_fcast_gov_cca_Services(void* bi,
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_BaseClass(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* 
  impl_arrayOps_CArrayOp_fcast_sidl_BaseClass(void* bi,
  sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_BaseInterface(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_arrayOps_CArrayOp_fcast_sidl_BaseInterface(void* bi,
  sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_ClassInfo(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* 
  impl_arrayOps_CArrayOp_fcast_sidl_ClassInfo(void* bi,
  sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_RuntimeException(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_arrayOps_CArrayOp_fcast_sidl_RuntimeException(void* bi,
  sidl_BaseInterface* _ex);
extern
void
impl_arrayOps_CArrayOp_init(
  /* in */ arrayOps_CArrayOp self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_arrayOps_CArrayOp_mulMatVec(
  /* in */ arrayOps_CArrayOp self,
  /* in */ double alpha,
  /* in rarray[m,n] */ double* A,
  /* in rarray[n] */ double* x,
  /* inout rarray[m] */ double* y,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_arrayOps_CArrayOp_addVec(
  /* in */ arrayOps_CArrayOp self,
  /* in */ double beta,
  /* in array<double> */ struct sidl_double__array* v,
  /* out array<double> */ struct sidl_double__array** r,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_arrayOps_CArrayOp_getResult(
  /* in */ arrayOps_CArrayOp self,
  /* inout rarray[m] */ double* r,
  /* in */ int32_t m,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_arrayOps_CArrayOp_setServices(
  /* in */ arrayOps_CArrayOp self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_arrayOps_CArrayOp_releaseServices(
  /* in */ arrayOps_CArrayOp self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

extern struct arrayOps_CArrayOp__object* 
  impl_arrayOps_CArrayOp_fconnect_arrayOps_CArrayOp(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct arrayOps_CArrayOp__object* 
  impl_arrayOps_CArrayOp_fcast_arrayOps_CArrayOp(void* bi,
  sidl_BaseInterface* _ex);
extern struct arrayop_LinearOp__object* 
  impl_arrayOps_CArrayOp_fconnect_arrayop_LinearOp(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct arrayop_LinearOp__object* 
  impl_arrayOps_CArrayOp_fcast_arrayop_LinearOp(void* bi,
  sidl_BaseInterface* _ex);
extern struct gov_cca_CCAException__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_CCAException(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_CCAException__object* 
  impl_arrayOps_CArrayOp_fcast_gov_cca_CCAException(void* bi,
  sidl_BaseInterface* _ex);
extern struct gov_cca_Component__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_Component(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_Component__object* 
  impl_arrayOps_CArrayOp_fcast_gov_cca_Component(void* bi,
  sidl_BaseInterface* _ex);
extern struct gov_cca_ComponentRelease__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_ComponentRelease(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_ComponentRelease__object* 
  impl_arrayOps_CArrayOp_fcast_gov_cca_ComponentRelease(void* bi,
  sidl_BaseInterface* _ex);
extern struct gov_cca_Port__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_Port(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct gov_cca_Port__object* 
  impl_arrayOps_CArrayOp_fcast_gov_cca_Port(void* bi, sidl_BaseInterface* _ex);
extern struct gov_cca_Services__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_Services(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_Services__object* 
  impl_arrayOps_CArrayOp_fcast_gov_cca_Services(void* bi,
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_BaseClass(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* 
  impl_arrayOps_CArrayOp_fcast_sidl_BaseClass(void* bi,
  sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_BaseInterface(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_arrayOps_CArrayOp_fcast_sidl_BaseInterface(void* bi,
  sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_ClassInfo(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* 
  impl_arrayOps_CArrayOp_fcast_sidl_ClassInfo(void* bi,
  sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_RuntimeException(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_arrayOps_CArrayOp_fcast_sidl_RuntimeException(void* bi,
  sidl_BaseInterface* _ex);
#ifdef __cplusplus
}
#endif
#endif
