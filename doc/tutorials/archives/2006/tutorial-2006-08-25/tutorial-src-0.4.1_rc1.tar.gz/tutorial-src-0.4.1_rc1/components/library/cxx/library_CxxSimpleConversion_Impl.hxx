// 
// File:          library_CxxSimpleConversion_Impl.hxx
// Symbol:        library.CxxSimpleConversion-v1.0
// Symbol Type:   class
// Babel Version: 0.99.3
// Description:   Server-side implementation for library.CxxSimpleConversion
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_library_CxxSimpleConversion_Impl_hxx
#define included_library_CxxSimpleConversion_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_library_CxxSimpleConversion_IOR_h
#include "library_CxxSimpleConversion_IOR.h"
#endif
#ifndef included_library_CxxSimpleConversion_hxx
#include "library_CxxSimpleConversion.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_units_Conversion_hxx
#include "units_Conversion.hxx"
#endif
#ifndef included_units_Unit_hxx
#include "units_Unit.hxx"
#endif


// DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._includes)
// Insert-Code-Here {library.CxxSimpleConversion._includes} (includes or arbitrary code)
// DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._includes)

namespace library { 

  /**
   * Symbol "library.CxxSimpleConversion" (version 1.0)
   */
  class CxxSimpleConversion_impl : public virtual 
    ::library::CxxSimpleConversion 
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._inherits)
  // none needed
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._implementation)
    ::units::Unit d_fromUnit;
    ::units::Unit d_toUnit;
    // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._implementation)

    bool _wrapped;
  public:
    // default constructor, used for data wrapping(required)
    CxxSimpleConversion_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    CxxSimpleConversion_impl( struct library_CxxSimpleConversion__object * s ) 
      : StubBase(s,true), _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~CxxSimpleConversion_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:
    /**
     * user defined static method
     */
    static ::library::CxxSimpleConversion
    build_impl (
      /* in */::units::Unit fromUnit,
      /* in */::units::Unit toUnit
    )
    ;


    /**
     * user defined non-static method.
     */
    void
    init_impl (
      /* in */::units::Unit fromUnit,
      /* in */::units::Unit toUnit
    )
    ;


    /**
     * Reverse the direction of the conversion.
     */
    void
    reverse_impl() ;

    /**
     * Return the unit that this Conversion interface will convert
     * from.
     */
    ::units::Unit
    convertFrom_impl() ;

    /**
     * Return the unit that this interface will convert to.
     */
    ::units::Unit
    convertTo_impl() ;

    /**
     * Convert a physical quantity from old set of units to another.
     */
    double
    convert_impl (
      /* in */double orig
    )
    ;

  };  // end class CxxSimpleConversion_impl

} // end namespace library

// DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._misc)
// Insert-Code-Here {library.CxxSimpleConversion._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._misc)

#endif
