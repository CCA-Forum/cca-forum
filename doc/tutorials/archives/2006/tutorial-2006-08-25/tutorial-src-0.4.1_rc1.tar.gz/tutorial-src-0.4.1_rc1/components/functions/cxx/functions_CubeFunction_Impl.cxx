// 
// File:          functions_CubeFunction_Impl.cxx
// Symbol:        functions.CubeFunction-v1.0
// Symbol Type:   class
// Babel Version: 0.99.3
// Description:   Server-side implementation for functions.CubeFunction
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "functions_CubeFunction_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(functions.CubeFunction._includes)
// Insert-Code-Here {functions.CubeFunction._includes} (additional includes or code)
// DO-NOT-DELETE splicer.end(functions.CubeFunction._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
functions::CubeFunction_impl::CubeFunction_impl() : StubBase(reinterpret_cast< 
  void*>(::functions::CubeFunction::_wrapObj(this)),false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(functions.CubeFunction._ctor2)
  // Insert-Code-Here {functions.CubeFunction._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(functions.CubeFunction._ctor2)
}

// user defined constructor
void functions::CubeFunction_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(functions.CubeFunction._ctor)
  // Insert-Code-Here {functions.CubeFunction._ctor} (constructor)
  // DO-NOT-DELETE splicer.end(functions.CubeFunction._ctor)
}

// user defined destructor
void functions::CubeFunction_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(functions.CubeFunction._dtor)
  // Insert-Code-Here {functions.CubeFunction._dtor} (destructor)
  // DO-NOT-DELETE splicer.end(functions.CubeFunction._dtor)
}

// static class initializer
void functions::CubeFunction_impl::_load() {
  // DO-NOT-DELETE splicer.begin(functions.CubeFunction._load)
  // Insert-Code-Here {functions.CubeFunction._load} (class initialization)
  // DO-NOT-DELETE splicer.end(functions.CubeFunction._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  init[]
 */
void
functions::CubeFunction_impl::init_impl (
  /* in array<double> */::sidl::array<double> params ) 
{
  // DO-NOT-DELETE splicer.begin(functions.CubeFunction.init)
  // Insert-Code-Here {functions.CubeFunction.init} (init method)
  // DO-NOT-DELETE splicer.end(functions.CubeFunction.init)
}

/**
 * Method:  evaluate[]
 */
double
functions::CubeFunction_impl::evaluate_impl (
  /* in */double x ) 
{
  // DO-NOT-DELETE splicer.begin(functions.CubeFunction.evaluate)
  // Insert-Code-Here {functions.CubeFunction.evaluate} (evaluate method)
   return x*x*x;
  // DO-NOT-DELETE splicer.end(functions.CubeFunction.evaluate)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument Svc will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
functions::CubeFunction_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(functions.CubeFunction.setServices)
  // Insert-Code-Here {functions.CubeFunction.setServices} (setServices method)
  
    frameworkServices = services;
    gov::cca::TypeMap tm = services.createTypeMap();
    if(tm._is_nil()) {
       fprintf(stderr, "Error:: %s:%d: gov::cca::TypeMap is nil\n",
          __FILE__, __LINE__);
       exit(1);  
    } 
    gov::cca::Port p = (*this);      //  Babel required casting
    if(p._is_nil()) {
       fprintf(stderr, "Error:: %s:%d: Error casting (*this) to gov::cca::Port \n",
          __FILE__, __LINE__);
       exit(1);
    } 
    
    services.addProvidesPort(p,
                             "FunctionPort",
                             "function.FunctionPort", tm);
    
    gov::cca::ComponentRelease cr = ::babel_cast< gov::cca::ComponentRelease >(*this);  //  Babel required casting
    services.registerForRelease(cr);
    return;

  // DO-NOT-DELETE splicer.end(functions.CubeFunction.setServices)
}


// DO-NOT-DELETE splicer.begin(functions.CubeFunction._misc)
// Insert-Code-Here {functions.CubeFunction._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(functions.CubeFunction._misc)

