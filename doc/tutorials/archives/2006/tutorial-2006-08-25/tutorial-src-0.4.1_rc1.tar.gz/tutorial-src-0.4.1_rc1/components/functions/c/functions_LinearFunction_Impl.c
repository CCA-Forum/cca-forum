/*
 * File:          functions_LinearFunction_Impl.c
 * Symbol:        functions.LinearFunction-v1.0
 * Symbol Type:   class
 * Babel Version: 0.99.3
 * Description:   Server-side implementation for functions.LinearFunction
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "functions.LinearFunction" (version 1.0)
 */

#include "functions_LinearFunction_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"

/* DO-NOT-DELETE splicer.begin(functions.LinearFunction._includes) */
/* Put additional includes or other arbitrary code here... */

#include <stdio.h>
#include <stdlib.h>
#include "sidl_Exception.h"

#if (!defined NULL)
#define NULL 0
#endif
/* DO-NOT-DELETE splicer.end(functions.LinearFunction._includes) */

#define SIDL_IOR_MAJOR_VERSION 0
#define SIDL_IOR_MINOR_VERSION 10
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._load) */
  /* Insert-Code-Here {functions.LinearFunction._load} (static class initializer method) */
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction__ctor(
  /* in */ functions_LinearFunction self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._ctor) */
  /* Insert the implementation of the constructor method here... */

  /* Allocate memory for the private data of this component */
  struct functions_LinearFunction__data *pdptr = (struct functions_LinearFunction__data*) 
    malloc(sizeof(struct functions_LinearFunction__data));
  if (pdptr) {
    /* Initialize the framework Services handle */
    pdptr->frameworkServices = NULL;
  }
  functions_LinearFunction__set_data(self, pdptr);
  
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction__ctor2(
  /* in */ functions_LinearFunction self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._ctor2) */
    /* Insert-Code-Here {functions.LinearFunction._ctor2} (special constructor method) */
    /*
     * This method has not been implemented
     */

    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-NOT-DELETE splicer.end(functions.LinearFunction._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction__dtor(
  /* in */ functions_LinearFunction self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._dtor) */
  /* Insert the implementation of the destructor method here... */
  
  struct functions_LinearFunction__data *pdptr;
  sidl_BaseInterface throwaway_excpt;

  /* Access private data structure */
  pdptr = functions_LinearFunction__get_data(self);
  if (pdptr) {
    if (pdptr->frameworkServices) {
      gov_cca_Services_deleteRef(pdptr->frameworkServices, &throwaway_excpt);
    }
    pdptr->frameworkServices = NULL;
    free(pdptr); 
    functions_LinearFunction__set_data(self, NULL);
  }
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction._dtor) */
  }
}

/*
 * Method:  init[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_init"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction_init(
  /* in */ functions_LinearFunction self,
  /* in array<double> */ struct sidl_double__array* params,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.init) */
  /* Insert the implementation of the init method here... */
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction.init) */
  }
}

/*
 * Method:  evaluate[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_evaluate"

#ifdef __cplusplus
extern "C"
#endif
double
impl_functions_LinearFunction_evaluate(
  /* in */ functions_LinearFunction self,
  /* in */ double x,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.evaluate) */
  /* Insert the implementation of the evaluate method here... */

  return 12.0 * x + 3.2;

  /* DO-NOT-DELETE splicer.end(functions.LinearFunction.evaluate) */
  }
}

/*
 * Method:  setServices[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_setServices"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction_setServices(
  /* in */ functions_LinearFunction self,
  /* in */ gov_cca_Services servicesHandle,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.setServices) */
  /* Insert the implementation of the setServices method here... */

  sidl_BaseInterface exception = NULL, throwaway_excpt = NULL;

  struct functions_LinearFunction__data *pd;
  
  /* Access private data structure */
  pd = functions_LinearFunction__get_data(self);
  if (pd->frameworkServices) {
    /* remove reference to previous services object */
    gov_cca_Services_deleteRef(pd->frameworkServices, &throwaway_excpt);
  }
  pd->frameworkServices = servicesHandle;
  if (!servicesHandle) return;

  gov_cca_Services_addRef(servicesHandle, &throwaway_excpt);
  
  /* Create a typemap for the FunctionPort */
  gov_cca_TypeMap tm = gov_cca_Services_createTypeMap(pd->frameworkServices, &exception);
  if (SIDL_CATCH(exception, "gov.cca.CCAException")) {
    fprintf(stderr, "Exception:: %s:%d: gov::cca::TypeMap was not created\n",
	    __FILE__, __LINE__);
    SIDL_CLEAR(exception);
    exit(1);
  }
  if (tm == NULL) {
    fprintf(stderr, "Error:: %s:%d: gov::cca::TypeMap is nil\n",
	    __FILE__, __LINE__);
    exit(1);  
  } 
  
  /* Provide a FunctionPort */
  gov_cca_Port port = gov_cca_Port__cast(self, &throwaway_excpt);
  if (port == NULL) {
    fprintf(stderr, "Error:: %s:%d: Error casting self to gov::cca::Port \n",
	    __FILE__, __LINE__);
    exit(1);
  } 
  
  gov_cca_Services_addProvidesPort(pd->frameworkServices,   
				   port,
				   "FunctionPort",
				   "function.FunctionPort",
				   tm,
				   &exception);
  if (SIDL_CATCH(exception, "gov.cca.CCAException")) {
    fprintf(stderr, "Exception:: %s:%d: Could not register function.FunctionPort provides port\n",
	    __FILE__, __LINE__);
    SIDL_CLEAR(exception);
    exit(1);
  }
  
  /* Register with framework for component release */
  gov_cca_ComponentRelease cr = gov_cca_ComponentRelease__cast(self, &throwaway_excpt);
  if (cr != NULL) {
    gov_cca_Services_registerForRelease(pd->frameworkServices, cr, &exception);
  }
  
  return;
  
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction.setServices) */
  }
}
/* Babel internal methods, Users should not edit below this line. */
struct function_FunctionPort__object* 
  impl_functions_LinearFunction_fconnect_function_FunctionPort(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return function_FunctionPort__connectI(url, ar, _ex);
}
struct function_FunctionPort__object* 
  impl_functions_LinearFunction_fcast_function_FunctionPort(void* bi,
  sidl_BaseInterface* _ex) {
  return function_FunctionPort__cast(bi, _ex);
}
struct functions_LinearFunction__object* 
  impl_functions_LinearFunction_fconnect_functions_LinearFunction(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return functions_LinearFunction__connectI(url, ar, _ex);
}
struct functions_LinearFunction__object* 
  impl_functions_LinearFunction_fcast_functions_LinearFunction(void* bi,
  sidl_BaseInterface* _ex) {
  return functions_LinearFunction__cast(bi, _ex);
}
struct gov_cca_CCAException__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_CCAException(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return gov_cca_CCAException__connectI(url, ar, _ex);
}
struct gov_cca_CCAException__object* 
  impl_functions_LinearFunction_fcast_gov_cca_CCAException(void* bi,
  sidl_BaseInterface* _ex) {
  return gov_cca_CCAException__cast(bi, _ex);
}
struct gov_cca_Component__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Component(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return gov_cca_Component__connectI(url, ar, _ex);
}
struct gov_cca_Component__object* 
  impl_functions_LinearFunction_fcast_gov_cca_Component(void* bi,
  sidl_BaseInterface* _ex) {
  return gov_cca_Component__cast(bi, _ex);
}
struct gov_cca_Port__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Port(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return gov_cca_Port__connectI(url, ar, _ex);
}
struct gov_cca_Port__object* 
  impl_functions_LinearFunction_fcast_gov_cca_Port(void* bi,
  sidl_BaseInterface* _ex) {
  return gov_cca_Port__cast(bi, _ex);
}
struct gov_cca_Services__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Services(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return gov_cca_Services__connectI(url, ar, _ex);
}
struct gov_cca_Services__object* 
  impl_functions_LinearFunction_fcast_gov_cca_Services(void* bi,
  sidl_BaseInterface* _ex) {
  return gov_cca_Services__cast(bi, _ex);
}
struct sidl_BaseClass__object* 
  impl_functions_LinearFunction_fconnect_sidl_BaseClass(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connectI(url, ar, _ex);
}
struct sidl_BaseClass__object* 
  impl_functions_LinearFunction_fcast_sidl_BaseClass(void* bi,
  sidl_BaseInterface* _ex) {
  return sidl_BaseClass__cast(bi, _ex);
}
struct sidl_BaseInterface__object* 
  impl_functions_LinearFunction_fconnect_sidl_BaseInterface(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connectI(url, ar, _ex);
}
struct sidl_BaseInterface__object* 
  impl_functions_LinearFunction_fcast_sidl_BaseInterface(void* bi,
  sidl_BaseInterface* _ex) {
  return sidl_BaseInterface__cast(bi, _ex);
}
struct sidl_ClassInfo__object* 
  impl_functions_LinearFunction_fconnect_sidl_ClassInfo(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connectI(url, ar, _ex);
}
struct sidl_ClassInfo__object* 
  impl_functions_LinearFunction_fcast_sidl_ClassInfo(void* bi,
  sidl_BaseInterface* _ex) {
  return sidl_ClassInfo__cast(bi, _ex);
}
struct sidl_RuntimeException__object* 
  impl_functions_LinearFunction_fconnect_sidl_RuntimeException(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_RuntimeException__connectI(url, ar, _ex);
}
struct sidl_RuntimeException__object* 
  impl_functions_LinearFunction_fcast_sidl_RuntimeException(void* bi,
  sidl_BaseInterface* _ex) {
  return sidl_RuntimeException__cast(bi, _ex);
}
