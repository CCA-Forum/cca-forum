// 
// File:          pdrivers_CXXDriverMPI_Impl.hxx
// Symbol:        pdrivers.CXXDriverMPI-v1.0
// Symbol Type:   class
// Babel Version: 0.99.3
// Description:   Server-side implementation for pdrivers.CXXDriverMPI
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_pdrivers_CXXDriverMPI_Impl_hxx
#define included_pdrivers_CXXDriverMPI_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_pdrivers_CXXDriverMPI_IOR_h
#include "pdrivers_CXXDriverMPI_IOR.h"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Component_hxx
#include "gov_cca_Component.hxx"
#endif
#ifndef included_gov_cca_ComponentRelease_hxx
#include "gov_cca_ComponentRelease.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_GoPort_hxx
#include "gov_cca_ports_GoPort.hxx"
#endif
#ifndef included_pdrivers_CXXDriverMPI_hxx
#include "pdrivers_CXXDriverMPI.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif


// DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI._includes)
// Insert-Code-Here {pdrivers.CXXDriverMPI._includes} (includes or arbitrary code)
#include "noSeekMPI.h"
#include <mpi.h> // or use the c++ header for your mpi if available.
#include "parallel_MPICommUser.hxx"
#include "gov_cca_ports_GoPort.hxx"
#include "ccaffeine_ports_MPIService.hxx"
// DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI._includes)

namespace pdrivers { 

  /**
   * Symbol "pdrivers.CXXDriverMPI" (version 1.0)
   */
  class CXXDriverMPI_impl : public virtual ::pdrivers::CXXDriverMPI 
  // DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI._inherits)
  // Insert-Code-Here {pdrivers.CXXDriverMPI._inherits} (optional inheritance here)
  // DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    // DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI._implementation)
    // Insert-Code-Here {pdrivers.CXXDriverMPI._implementation} (additional details)
    ::gov::cca::Services frameworkServices;
    ::ccaffeine::ports::MPIService mpiService;
    int64_t commSIDL; 
    MPI_Comm commC; 


    // DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI._implementation)

    bool _wrapped;
  public:
    // default constructor, used for data wrapping(required)
    CXXDriverMPI_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    CXXDriverMPI_impl( struct pdrivers_CXXDriverMPI__object * s ) : StubBase(s,
      true), _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~CXXDriverMPI_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    int32_t
    go_impl() ;
    /**
     * user defined non-static method.
     */
    void
    setServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;

    /**
     * user defined non-static method.
     */
    void
    releaseServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;

  };  // end class CXXDriverMPI_impl

} // end namespace pdrivers

// DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI._misc)
// Insert-Code-Here {pdrivers.CXXDriverMPI._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI._misc)

#endif
