#!/usr/bin/env python

import sys,os

# By default, Python deprecation warnings are disabled, define the CCA_TOOLS_DEBUG env. variable to enable
try:
    import warnings
    if not ('CCA_TOOLS_DEBUG' in os.environ.keys() and os.environ['CCA_TOOLS_DEBUG'] == '1'): 
        warnings.filterwarnings("ignore", category=DeprecationWarning)
except:
    pass
        
# Clean initial environment
if os.getenv('LD_LIBRARY_PATH'): del os.environ['LD_LIBRARY_PATH']
if os.getenv('PYTHONPATH'): del os.environ['PYTHONPATH']

from contractor import *
from packages import *

if packages_name and packages_version:
    info(packages_name + ' version ' + packages_version + packages_copyright)
    
try:
	main(sys.argv)
except KeyboardInterrupt:
	info("Exiting...")
