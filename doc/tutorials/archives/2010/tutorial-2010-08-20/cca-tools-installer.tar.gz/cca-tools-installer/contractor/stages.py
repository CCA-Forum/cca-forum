# This file is part of Contractor
# Original author: James Amundson, amundson@fnal.gov
# (c) 2007-2010 Fermi Research Alliance, LLC
# For copying information, see the file LICENSE

#!/usr/bin/env python

from utils import *
from cores import get_num_cores
import urllib, urlparse

build_msg_pre = "\x1B[07m" 
build_msg_post = "\x1B[00m"
green_pre = '\033[1;32m'
green_post = '\033[1;m'

class Stage:
    def __init__(self, stage_name = 'generic_stage', parallel = True):
        self.package = None
        self.stage_name = stage_name
        self.parallel = parallel
        self.hidden_parallel = 1    # number of processes for custom control of parallelism
        self.processes = 1

    def get_name(self):
        return self.stage_name
        
    def set_package(self, package):
        self.package = package

    def aux_stage(self):
        return None
        
    def _var(self, name):
        return self.package.get_var(name)

    def _vars(self):
        return self.package.get_vars()

    def _log(self):
        return os.path.join(self._var('log_dir'),self.stage_name)
    
    def build_method(self):
        info("%s/%s" % \
              (self.package.name,self.stage_name), pre=build_msg_pre, 
              post='%s %s[%d]%s' % (build_msg_post,green_pre,self.processes,green_post))

class Unpack(Stage):
    def __init__(self, archive_name=None, pattern=None, url=None, md5file=None):
        # We assume that md5file resides in the same directory in the given url
        self.pattern = listify(pattern)
        if archive_name:
            self.archive_name = listify(archive_name)
        else:
            self.archive_name = [None]
            for i in range(1,len(self.pattern)):
                self.archive_name.append(None)
        self.url = listify(url)
        self.need_url = 0
        self.md5file = md5file
        self.fetchcount = 0
        Stage.__init__(self,'unpack')

    def _fetch_url(self):
        self.archive_name = []
        for url in self.url:
            scheme,host,pathname = urlparse.urlparse(url)[0:3]
            filename = os.path.basename(pathname)
            output_file = os.path.join(self._var("root.urlcache_dir"), filename)
            download_failed = False
            md5check_failed = False
            if not os.path.exists(output_file):
                if False and len(self.pattern) != 1 or self.pattern[0] != None: 
                    # This still work-in-progress and is thus disabled with the False condition above
                    import re
                    filename = ''
                    dirname = os.path.dirname(pathname)
                    fobj = urllib.urlopen(scheme + '://' + host + dirname)
                    lines = fobj.readlines()
                    fobj.close()
                    for line in lines:
                        for p in self.pattern:
                            m=re.search(p+'">',line)
                            if m: 
                                filename = line[m.start():m.end()]
                                break
                        if filename: break
                    url = scheme + '://' + host + dirname + '/' + filename

                self.fetchcount += 1
                command_message("fetching " + url)
                try:
                    urllib.urlretrieve(url,output_file)
                except:
                    download_failed = True

                if not download_failed and self.md5file:
                    command_message('checking md5sum')
                    urlpath = url[0:url.rfind('/')+1]
                    md5url = urlpath + self.md5file
                    md5checkfile = self.md5file + '.remote'
                    try:
                        urllib.urlretrieve(md5url,md5checkfile)
                    except:
                        info('Warning: could not validate md5sum for %s (md5sum file %s)' % (url,md5url))
                        md5check_failed = True
                    if not md5check_failed:
                        f=open(md5checkfile)
                        checksum = f.read().strip()
                        if checksum.count('=') > 0: checksum = checksum.split('=')[1].strip()
                        md5sum = get_md5sum_file(output_file)
                        if checksum != md5sum:
                            md5check_failed = True
                        else:
                            os.unlink(md5checkfile)

                if download_failed or md5check_failed:
                # Retry up to 3 times
                    if self.fetchcount < 4:
                        if os.path.exists(output_file): os.unlink(output_file) 
                        self._fetch_url()
                    else:
                        if md5check_failed: msg = ' (md5sum check failed)'
                        else: msg = ''
                        raise RuntimeError, \
                            '*** Unable to download archive for '+ self.package.get_name() + msg + ': ' + url + \
                            ' (check the URLs in the package description and/or your network connection).'
                    
            self.archive_name.append(output_file)
                      
    def set_package(self, package):
        Stage.set_package(self, package)
        for i in range(0,len(self.archive_name)):
            if not self.archive_name[i]:
                if self.pattern[i]:
                    pattern = self.pattern[i]
                else:
                    pattern = self.package.get_name() + "*"
                search_result = glob.glob(abs_rel_dir(\
                    self._var("root.archive_dir"), pattern))
                if len(search_result) == 1:
                    self.archive_name[i] = search_result[0]
                else:
                    if self.url != [None]:
                        self.need_url = 1
                    else:
                        raise RuntimeError, \
                              'Unable to find archive for ' + \
                              self.package.get_name() + \
                              '/unpack.\nglob(' + pattern + ') returned ' + \
                              str(search_result)
        
    def build_method(self):
        info("%s/%s" % \
              (self.package.name,self.stage_name), pre=build_msg_pre, post=build_msg_post)
        if os.path.isdir(self._var('src_dir')):
            if self.package.is_precious():
                return
            system_or_die('/bin/rm -rf %s' % self._var('src_dir'))
        if self.need_url:
            self._fetch_url()
        info("Switching to build dir...")
        debug(self._var('root.build_dir'))
        os.chdir(self._var('root.build_dir'))
        if os.path.isdir('tmp'):
            system_or_die('/bin/rm -rf tmp')
        #info("Switching to tmp dir...")
        os.makedirs('tmp')
        os.chdir('tmp')
        if len(self.archive_name) > 1:
            command = "("
        else:
            command = ""
        count = 0
        for archive_name in self.archive_name:
            count += 1
            basic_cmd = 'tar xf'
            suffix = os.path.splitext(archive_name)[1]
            if suffix == '.zip':
                basic_cmd = 'unzip'
            if (suffix == '.tgz') or (suffix == '.gz'):
                basic_cmd = 'tar zxf'
            elif suffix == '.bz2':
                basic_cmd = 'tar jxf'
            if count > 1:
                command += " && "
            command += '%s %s' % \
                       (basic_cmd,
                        abs_rel_dir(self._var('root.archive_dir'),
                                    archive_name))
        if len(self.archive_name) > 1:
            command += ")"
        # info("Running cmd...")
        retval = system_cmd(command, self._log())

        # If failure, try again (just once):
        if retval != 0:
            if os.path.isdir(self._var('src_dir')):
                if self.package.is_precious():
                    return
                system_cmd('/bin/rm -rf %s' % self._var('src_dir'))
            if self.need_url:
                for url in self.url:
                   scheme,host,pathname = urlparse.urlparse(url)[0:3]
                   filename = os.path.basename(pathname)
                   output_file = os.path.join(self._var("root.urlcache_dir"), filename)
                   if os.path.exists(output_file): os.unlink(output_file) 
                self._fetch_url()
            info("Switching to build dir...")
            os.chdir(self._var('root.build_dir'))
            retval = system_or_die(command, self._log())
        
        #info("cmd finished...")
        output = glob.glob("*")
        if len(output) == 0:
            raise RuntimeError, 'No output found from tar'
        elif len(output) > 1:
            os.makedirs(self._var('src_dir'))
        #info("Moving source...")
		# Clean up old build directory if it exists
        if os.path.exists(self._var('src_dir')):
            system_or_die('/bin/rm -rf %s/*' % self._var('src_dir'))
        system_or_die('/bin/mv * %s' % self._var('src_dir'))
        os.chdir('..')
        debug(os.getcwd())
        #info("Removing tmp...")
        system_or_die('/bin/rm -rf tmp')
        os.chdir(self._var("root.base_dir"))
        
class Cvs_checkout(Stage):
    def __init__(self, repository=None, module=None, branch=None):
        self.repository = repository
        self.module = module
        self.branch = branch
        self.create_sc_tarball = Create_sc_tarball(self)
        Stage.__init__(self,'cvs_checkout')

    def set_package(self,package):
        Stage.set_package(self, package)
        if not self.module:
            self.module = self.package.get_name()
            
    def aux_stage(self):
        return self.create_sc_tarball
    
    def build_method(self):
        info("%s/%s" % \
              (self.package.name,self.stage_name), pre=build_msg_pre, post=build_msg_post)

        if os.path.isdir(self._var('src_dir')):
            if self.package.is_precious():
                return
            system_or_die('/bin/rm -rf %s' % self._var('src_dir'))
        os.chdir(self._var('root.build_dir'))
        self.checkout()
        os.chdir(self._var("root.base_dir"))

    def checkout(self):
        branch_arg = ''
        if self.repository:
            repository_arg = '-d %s' % self.repository
        else:
            repository_arg = ''
        if self.branch:
            branch_arg = '-r %s' % self.branch
        else:
            branch_arg = ''
        system_or_die('cvs %s checkout -d %s %s %s' % (repository_arg,
                                                       self.package.get_name(),
                                                       branch_arg,
                                                       self.module),
                      self._log())

class Svn_checkout(Stage):
    def __init__(self, url, module=None):
        self.url = url
        self.module = module
        self.create_sc_tarball = Create_sc_tarball(self)
        Stage.__init__(self,'svn_checkout')

    def set_package(self,package):
        Stage.set_package(self, package)
        if not self.module:
            self.module = self.package.get_name()
            
    def aux_stage(self):
        return self.create_sc_tarball
    
    def build_method(self):
        info("%s/%s" % \
              (self.package.name,self.stage_name), pre=build_msg_pre, post=build_msg_post)
        if os.path.isdir(self._var('src_dir')):
            if self.package.is_precious():
                return
            system_or_die('/bin/rm -rf %s' % self._var('src_dir'))
        os.chdir(self._var('root.build_dir'))
        self.checkout()
        os.chdir(self._var("root.base_dir"))

    def checkout(self):
        system_or_die('svn checkout %s %s' % (self.url,
                                              self.module),
                      self._log())
        if self.module != self.package.get_name():
            system_or_die("/bin/mv %s %s" % (self.module, self.package.get_name()))

class Create_sc_tarball(Stage):
    def __init__(self, checkout):
        self.checkout = checkout 
        Stage.__init__(self,'create_sc_tarball')

    def build_method(self):
        info("%s/%s" % \
              (self.checkout.package.name,self.stage_name), pre=build_msg_pre, post=build_msg_post)
        tmpdir = self.checkout._var('src_dir') + '-tarballtmp'
        if os.path.isdir(tmpdir):
            system_or_die('/bin/rm -rf %s' % tmpdir)
        os.makedirs(tmpdir)
        os.chdir(tmpdir)
        self.checkout.checkout()
        system_or_die('tar zcf %s.tar.gz %s' % \
                      (self.checkout.package.get_name(),
                       self.checkout.package.get_name()))
        system_or_die('mv %s.tar.gz %s' % \
                      (self.checkout.package.get_name(),
                       self.checkout._var("root.archive_dir")))
        system_or_die('/bin/rm -rf %s' % tmpdir)
        os.chdir(self.checkout._var("root.base_dir"))


class Bootstrap(Stage):
    def __init__(self, command=None):
        if command:
            self.command = command
        else:
            self.command = "./bootstrap"
        Stage.__init__(self,'bootstrap')
        
    def build_method(self):
        info("%s/%s" % \
              (self.package.name,self.stage_name), pre=build_msg_pre, post=build_msg_post)

        os.chdir(self._var("build_dir"))
        system_or_die('%s' % self.command, self._log())
        os.chdir(self._var("root.base_dir"))

class Configure(Stage):
    def __init__(self, extra_args=None, all_args=None):
        self.extra_args = extra_args
        self.all_args = all_args
        Stage.__init__(self,'configure')

    def add_arg(self, extra_args=None):
        if extra_args:
            self.extra_args += ' ' + extra_args
        return
            
    def build_method(self):
        info("%s/%s" % \
              (self.package.name,self.stage_name), pre=build_msg_pre, post=build_msg_post)
        if not os.path.isdir(self._var("build_dir")):
            os.makedirs(self._var("build_dir"))
        os.chdir(self._var("build_dir"))
        if self.package.prefix is not None:
              self.prefix = self.package.prefix
        else:
              self.prefix = "%(root.install_dir)s"

        for libpathvar in ['LD_LIBRARY_PATH','DYLD_LIBRARY_PATH']:
            libpath = os.path.join(self.prefix,'lib64') + ':' + os.path.join(self.prefix,'lib') 
            if os.environ.has_key(libpathvar):
                os.environ[libpathvar] = libpath + ':' + os.environ[libpathvar]
            else:
                os.environ[libpathvar] = libpath

        if self.all_args:
            args = self.all_args
        else:
            args = "--prefix=" + self.prefix
            if self.extra_args:
                args += " " + self.extra_args
        system_or_die(('%(src_dir)s/configure' + ' ' + args) % self._vars(),
                      self._log())
        os.chdir(self._var("root.base_dir"))

class Make(Stage):
    def __init__(self, parallel=True):
        Stage.__init__(self,stage_name='make',parallel=parallel)
        
    def build_method(self):
        if self.parallel:
            self.processes = get_num_cores()
            opts = " -j" + str(self.processes)
        else:
            opts = ""
            self.processes = self.hidden_parallel
        Stage.build_method(self)
        os.chdir(self._var("build_dir"))
        system_or_die('make' + opts, self._log())
        os.chdir(self._var("root.base_dir"))
        self.hidden_parallel = 1

class Qmake(Stage):
    def __init__(self, pro_file="*.pro"):
        self.pro_file = pro_file
        Stage.__init__(self,'qmake')
        
    def build_method(self):
        info("%s/%s" % \
              (self.package.name,self.stage_name), pre=build_msg_pre, post=build_msg_post)
        os.chdir(self._var("build_dir"))
        system_or_die('qmake %s' % self.pro_file, self._log())
        os.chdir(self._var("root.base_dir"))

class Install(Stage):
    def __init__(self, parallel=True):
        Stage.__init__(self,'install')
        self.extra_args = ''
        
    def add_arg(self, extra_args=None):
        if extra_args:
            self.extra_args += ' ' + extra_args
        return

    def build_method(self):
        info("%s/%s" % \
              (self.package.name,self.stage_name), pre=build_msg_pre, post=build_msg_post)
        os.chdir(self._var("build_dir"))
        changed_files = Changed_files(self._var("root.install_dir"))
        system_or_die('make ' + self.extra_args  + ' install',self._log())
        changed_files.end()
        changed_files.dump_all(self._log()+".changed_files")
        os.chdir(self._var("root.base_dir"))

class Py_install(Stage):
    def __init__(self, extra_args=None):
        if extra_args:
            self.extra_args = extra_args
        else:
            self.extra_args = ''
        Stage.__init__(self,'py_install')
            
    def build_method(self):
        info("%s/%s" % \
              (self.package.name,self.stage_name), pre=build_msg_pre, post=build_msg_post)
        os.chdir(self._var("build_dir"))
        if self.extra_args:
            extra_args = self.extra_args
        else:
            extra_args = ''
        extra_args += " --prefix=%(root.install_dir)s" % self._vars()
        changed_files = Changed_files(self._var("root.install_dir"))
        system_or_die(('python setup.py install ' + \
                       extra_args) % self.package.get_vars(),
                      self._log())
        changed_files.end()
        changed_files.dump_all(self._log()+".changed_files")
        os.chdir(self._var("root.base_dir"))

class Build_command(Stage):
    def __init__(self, stage_name, command, record_install=0):
        self.command = command
        self.record_install = record_install
        Stage.__init__(self,stage_name)
        
    def build_method(self):
        info("%s/%s" % \
              (self.package.name,self.stage_name), pre=build_msg_pre, post=build_msg_post)
        if not os.path.isdir(self._var("build_dir")):
            os.makedirs(self._var("build_dir"))
        os.chdir(self._var("build_dir"))
        if self.record_install:
            changed_files = Changed_files(self._var("root.install_dir"))
        system_or_die(self.command % self.package.get_vars(),
                      self._log())
        if self.record_install:
            changed_files.end()
            changed_files.dump_all(self._log()+".changed_files")
        os.chdir(self._var("root.base_dir"))

