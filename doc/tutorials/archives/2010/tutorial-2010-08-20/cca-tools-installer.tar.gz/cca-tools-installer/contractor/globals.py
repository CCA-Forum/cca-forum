# This file is part of Contractor
# Original author: Boyana Norris, norris@mcs.anl.gov
# (c) 2010 UChicago Argonne, LLC
# For copying information, see the file LICENSE

import logging, os

# Global singleton class for various runtime options that control Contractor's behavior
# TODO: add various globals floating arround to the Globals_Singleton class
def Globals():
    '''Helper function to ensure exactly one instance of the Globals_singleton class exists'''
    myglobals = None
    try:
        myglobals = Globals_Singleton()
    except Globals_Singleton, s:
        myglobals = s
    return myglobals

class Globals_Singleton:
    '''A singleton class in which to stash various useful global variables for bocca.
    Do not instantiate this class directly, rather use the Globals helper function,
    e.g., myglobals = Globals().
    '''
    __single = None  # Used for ensuring singleton instance
    def __init__(self):
        if Globals_Singleton.__single:
            raise Globals_Singleton.__single 
        Globals_Singleton.__single = self

        self.dry_run = False     # When True, don't execute anything, just print commands
        
        self.shell = '/bin/sh'   # Shell used by contractor 
        
        # Configure logging
        self.logger = logging.getLogger("CCA Tools")
        self.logfile = 'cca-tools-install.log'
        self.logger.addHandler(logging.FileHandler(filename=self.logfile))
        # Because commands are output with extra formatting, for now do not use the logger for stderr output
        #streamhandler = logging.StreamHandler()
        #streamhandler.setLevel(logging.INFO)
        #self.logger.addHandler(streamhandler)
        
        # Project representation graph
        self.nodes = {}
        self.targets = []
        self.default = None
        
        # Formatting (e.g., color) settings
        self.error_pre = "\x1B[00;31m"
        self.error_post = "\x1B[00m"

        # Enable debugging
        if 'CCA_TOOLS_DEBUG' in os.environ.keys() and os.environ['CCA_TOOLS_DEBUG'] == '1': 
            self.debug = True
            self.logger.setLevel(logging.DEBUG)
        else: 
            self.debug = False
            self.logger.setLevel(logging.INFO)
        pass
