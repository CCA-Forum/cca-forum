#!/usr/bin/env python

import os

from contractor import *
from babel import *
from libxml2 import *
from common import *


spec_babel_internal = Option(local_root, "spec_babel_internal", True, \
                        bool, "Install internal version of SIDL/Babel CCA spec")

if nightly.get():
    spec_babel_version = "nightly"
    spec_babel_url = nightlyurl + "cca-spec-babel.tar.gz"
    spec_babel_md5 = 'cca-spec-babel.md5sum'
else:
    spec_babel_version = "0.8.6"
    spec_babel_url = toolsurl + 'cca-spec-babel-' + spec_babel_version + '.tar.gz'
    spec_babel_md5 = 'cca-spec-babel-' + spec_babel_version + '.md5sum'
            
class SpecBabelConfigure(Configure):
    def __init__(self):
        babel_version, babel_ver_from_config = validateBabelVersion()
        args = "--disable-contrib --with-babel-config=%s/bin/babel-config" % \
            babel.get_var("root.install_dir")
        Configure.__init__(self, extra_args = args)
    
    def build_method(self):
        babel_ver, babel_ver_from_config = validateBabelVersion()
        if babel_ver != babel_ver_from_config:
            self.add_arg(" --with-babel-branch=%s" % babel_ver)
            os.environ["CCA_BABEL_FORCE"] = babel_ver
            
        if self.package.prefix is not None: self.prefix = self.package.prefix
        else: self.prefix = "%(root.install_dir)s"

        if libxml2_prefix.get():
            if os.path.exists(libxml2_prefix.get()):
                self.add_arg(" --with-libxml2=%s" % libxml2_prefix.get())
            elif libxml2_prefix.get() == "internal":
                self.add_arg(" --with-libxml2=%s" % self.prefix)
            else:
                err("libxml2 installation not found, please reconfigure with the option libxml2_prefix=/installation/dir")

        Configure.build_method(self)
        if babel_version != babel_ver_from_config:
            if os.environ.has_key("CCA_BABEL_FORCE"):
                del os.environ["CCA_BABEL_FORCE"]

class SpecBabelMake(Make):
    def __init__(self):
        Make.__init__(self, parallel = False)
    
    def build_method(self):
        nprocs = get_num_cores()
        os.environ["CCA_PMAKE"] = "-j " + str(nprocs)
        self.hidden_parallel = nprocs
        Make.build_method(self)
        del os.environ["CCA_PMAKE"]

class SpecBabelInstall(Install):
    def __init__(self):
        Install.__init__(self, parallel = False)

    def build_method(self):
        nprocs = get_num_cores()
        os.environ["CCA_PMAKE"] = "-j " + str(nprocs)
        self.hidden_parallel = nprocs
        Install.build_method(self)
        del os.environ["CCA_PMAKE"]

if spec_babel_internal.get():
    spec_babel = Package(local_root, "spec_babel", \
            [Unpack(url=spec_babel_url, md5file=spec_babel_md5), \
            SpecBabelConfigure(), SpecBabelMake(), \
            SpecBabelInstall()], [libxml2,babel], optiondeps=[libxml2_prefix])
else:
    spec_babel = External_package("spec_bable")
