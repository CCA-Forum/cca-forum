#!/usr/bin/env python

import os

from contractor import *
from boost import *
from babel import *
from mpi import *
from common import *

spec_neo_internal = Option(local_root, "spec_neo_internal", False, \
                        bool, "Install internal version of neo (C++-only) CCA spec")

# Nightly version
if nightly.get():
    spec_neo_version = "nightly"
    spec_neo_url = "http://www.cca-forum.org/download/cca-tools/nightly/cca-spec-neo.tar.gz"
    spec_neo_md5 = "cca-spec-neo.md5sum"
else:
    spec_neo_version = "0.2.8"
    spec_neo_url = toolsurl + 'cca-spec-neo-' + spec_neo_version + '.tar.gz'
    spec_neo_md5 = 'cca-spec-neo-' + spec_neo_version + '.md5sum'
    
    
# TODO: Remove this when we move to a new release that has it fixed
bash_fix = "find . -type f | grep make.install | xargs sed -e 's/\/bin\/sh/\/bin\/bash/'"

class SpecNeoConfigure(Configure):
    def __init__(self):
        if boost_prefix.get() == "":
            args = "--with-boost=" + boost.get_var("src_dir")
        else:
            args = "--with-boost=" + boost_prefix.get()
        
        if mpi.get():
            args += " --with-mpi=" + mpi.get()
        else:
            args += " --without-mpi"

        Configure.__init__(self, extra_args = args + \
            " --with-babel-libtool=%s/bin/babel-libtool " % \
            babel.get_var("root.install_dir"))
    
    def build_method(self):
        babel_version = os.popen("%s/bin/babel-config --version" % babel.get_var("root.install_dir")).read().strip()
        os.environ["CCA_BABEL_FORCE"] = babel_version
        Configure.build_method(self)
        del os.environ["CCA_BABEL_FORCE"]

class SpecNeoMake(Stage):
    def __init__(self):
        Stage.__init__(self, "make")
    
    def build_method(self):
        os.chdir(self._var("build_dir"))
        #Parallel build doesn't seem to work right now, so disabling
        system_or_die("make", self._log())
        os.chdir(self._var("root.base_dir"))

#-------------------------------------------------------------

if spec_neo_internal.get():
    spec_neo = Package(local_root, "spec_neo", \
            [Unpack(url = spec_neo_url, md5file=spec_neo_md5), \
            SpecNeoConfigure(), \
            Build_command("bash-fix", bash_fix), SpecNeoMake(), Install()], \
            [babel])
else:
    spec_neo = External_package("spect_neo")
