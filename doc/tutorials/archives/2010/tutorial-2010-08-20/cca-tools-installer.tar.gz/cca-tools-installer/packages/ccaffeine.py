#!/usr/bin/env python

import sys, os, time
from contractor import *
from boost import *
from cca_spec_classic import *
from cca_spec_neo import *
from cca_spec_babel import *
from babel import *
from mpi import *
from common import *
from libxml2 import *

ccaffeine_internal = Option(local_root, "ccaffeine_internal", True, \
                        bool, "Install internal version of Ccaffeine")

if nightly.get():
    # Nightly version
    ccaffeine_version = "nightly"
    ccaffeine_url = nightlyurl + 'ccaffeine.tar.gz'
    ccaffeine_md5 = 'ccaffeine.md5sum'
else:
    ccaffeine_version = '0.8.8'
    ccaffeine_url = toolsurl + 'ccaffeine-' + ccaffeine_version + '.tar.gz'
    ccaffeine_md5 = 'ccaffeine-' + ccaffeine_version + '.md5sum'

class CcaffeConfig(Configure):
    def __init__(self):
        if boost_prefix.get() == "":
            args = "--with-boost=" + boost.get_var("src_dir")
        else:
            args = "--with-boost=" + boost_prefix.get()
                
        if mpi.get():
            args += " --with-mpi=" + mpi.get()
        else:
            args += " --without-mpi"
        
        Configure.__init__(self, extra_args = args)
        pass

    def build_method(self):
        babel_version, babel_ver_from_conf = validateBabelVersion()
        babel_version_arg = ''
        if babel_version == '':
            babel_version = time.strftime('%Y%m%d') # Yucky, but nonfatal
        if babel_version != babel_ver_from_conf:
            self.add_arg(' --with-babel-experimental=%s' % babel_version)

        somespec = False
        if spec_classic.get_prefix():
            if os.path.exists(os.path.join(spec_classic.get_prefix(),'bin','cca-spec-classic-config')):
                self.add_arg(' --with-cca-classic=%s' % spec_classic.get_prefix())
                somespec = True

        if spec_neo.get_prefix():
            if os.path.exists(os.path.join(spec_neo.get_prefix(),'bin','cca-spec-neo-config')):
                self.add_arg(' --with-cca-neo=%s' % spec_classic.get_prefix())
                somespec = True

        if spec_babel.get_prefix():
            if os.path.exists(os.path.join(spec_babel.get_prefix(),'bin','cca-spec-babel-config')):
                self.add_arg(' --with-cca-babel=%s' % spec_babel.get_prefix())
                somespec = True

        if not somespec:
            err('No suitable CCA spec found. Ccaffeine requires that you configure contractor with at least one CCA spec enabled (classic, neo, or babel). Giving up.')


        Configure.build_method(self)
        pass


class CcaffeMake(Make):
    def __init__(self):
        Make.__init__(self, parallel = False)
    
    def build_method(self):
        nprocs = get_num_cores()
        os.environ["CCA_PMAKE"] = "-j " + str(nprocs)
        self.hidden_parallel = nprocs 
        Make.build_method(self)
        del os.environ["CCA_PMAKE"]

if ccaffeine_internal.get():
    dependencies = [babel, boost]
    if spec_neo_internal.get():
        dependencies.append(spec_neo)
        #info('adding neo', spec_neo_internal.get())
    if spec_classic_internal.get():
        dependencies.append(spec_classic)
        #info('adding classic', spec_classic_internal.get())
    if spec_babel_internal.get():
        dependencies.append(spec_babel)
    ccaffeine = Package(local_root, "ccaffeine", \
                        [Unpack(url = ccaffeine_url, md5file=ccaffeine_md5),  \
                        CcaffeConfig(), CcaffeMake(), \
                        Install()], dependencies)
else:
    ccaffeine = External_package("ccaffeine")
