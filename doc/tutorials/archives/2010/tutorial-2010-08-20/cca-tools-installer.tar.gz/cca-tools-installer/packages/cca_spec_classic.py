#!/usr/bin/env python

import os

from contractor import *
from babel import *
from common import *

spec_classic_internal = Option(local_root, "spec_classic_internal", False, \
                        bool, "Install internal version of classic (C++-only) CCA spec")

# Nightly version
if nightly.get():
    spec_classic_version = "nightly"
    spec_classic_url = "http://www.cca-forum.org/download/cca-tools/nightly/cca-spec-classic.tar.gz"
    spec_classic_md5 = "cca-spec-classic.md5sum"
else:
    spec_classic_version = "0.5.7"
    spec_classic_url = toolsurl + 'cca-spec-classic-' + spec_classic_version + '.tar.gz'
    spec_classic_md5 = 'cca-spec-classic-' + spec_classic_version + '.md5sum'
    
# TODO: Remove this when we move to a new release that has it fixed
bash_fix = "find . -type f | grep make.install | xargs sed -e 's/\/bin\/sh/\/bin\/bash/'"

if spec_classic_internal.get():
    spec_classic = Package(local_root, "spec_classic", \
            [Unpack(url = spec_classic_url, md5file = spec_classic_md5), \
            Configure(extra_args = "--with-babel-libtool=%s/bin/babel-libtool" % babel.get_var("root.install_dir")), \
            Build_command("bash-fix", bash_fix), Make(), Install()], \
            [babel])
else:
    spec_classic = External_package("spect_classic")
