#!/usr/bin/env python

import os

from contractor import *
from ccaffeine import *

bocca_internal = Option(local_root, "bocca_internal", True, \
						bool, "Install internal version of Bocca")

if nightly.get():
    bocca_version = 'nightly'
    bocca_url = nightlyurl + 'bocca.tar.gz'
    bocca_md5 = 'bocca.md5sum'
else:
    bocca_version = "0.5.5"
    bocca_url = toolsurl + 'bocca-' + bocca_version + '.tar.gz'
    bocca_md5 = 'bocca-' + bocca_version + '.md5sum'
    
# TODO: Remove this when we move to a new release that has it fixed
bash_fix = "find . -type f | grep make.install | xargs sed -e 's/\/bin\/sh/\/bin\/bash/'"
            
class BoccaMake(Make):
    def __init__(self):
        Make.__init__(self, parallel = False)
    
    def build_method(self):
        os.environ["CCA_PMAKE"] = "-j " + str(get_num_cores())
        Make.build_method(self)
        del os.environ["CCA_PMAKE"]
        
if bocca_internal.get():
	bocca = Package(local_root, "bocca", \
			[Unpack(url = bocca_url, md5file = bocca_md5), \
			Configure(extra_args = "--with-ccafe-config=%s/bin/ccafe-config" % ccaffeine.get_var("root.install_dir")), \
			Build_command("bash-fix", bash_fix), BoccaMake(), Install()], \
			[ccaffeine])
else:
	bocca = External_package("bocca")
