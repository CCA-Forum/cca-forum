#!/usr/bin/env python

from contractor import *
from distutils import sysconfig


prefix = Option(local_root, "prefix", "%(base_dir)s/install", str, \
                "Install all tools in the specified directory")

# For the ACTS tutorial, make nightly true by default, but change the link to point to the acts10 tool snapshot
nightly = Option(local_root, 'nightly', True, bool, 'Install nightly snapshots of Babel and CCA tools')

nightlyurl = 'http://www.cca-forum.org/download/cca-tools/cca-tools-acts10/'
toolsurl = 'http://www.cca-forum.org/download/cca-tools/cca-tools-acts10/'

python_libdir=sysconfig.get_config_var('LIBDIR')
python_platform=sysconfig.get_config_var('PLATDIR')
