#!/usr/bin/env python

"""
	CCA Tools Installer - GTK+ Interface
	====================================
	A GTK+ based graphical interface for the CCA Tools installer. This GUI is
	meant to simplify installation and provide a graphical way to configure the
	new contractor-based CCA Tools build system.
	
	Usage
	-----
	Run the installer and follow the directions presented. Options are
	displayed in a list and can be edited by clicking the option values. Any
	changes made are reflected immediately in the contractor configuration
	system.
	
	Authors
	-------
	Daniel G. Taylor <dan@programmer-art.org>
	
	License
	-------
	Awaiting contractor licensing information.
"""

import sys, os, threading, re, imp
import gobject, gtk, gtk.glade, gtk.gdk

# Get lists of known verbs and subjects
gui_self = os.path.realpath(sys.argv[0])
gui_dir = os.path.dirname(gui_self)
modulePath = os.path.abspath(os.path.join(gui_dir,'..'))

try:
    (file,filename,description) = imp.find_module('contractor',[modulePath])
    contractor = imp.load_module('contractor', file, filename, description)
    (file,filename,description) = imp.find_module('packages',[modulePath])
    packages = imp.load_module('packages', file, filename, description)
except:
    print "Please run from the same place you would run contract.py!"
    print "(probably just go back out to the main directory)"
    sys.exit(1)

TAB_START = 0
TAB_END = 3

output_buffer = ""
output_buffer_lock = threading.Lock()

class OutputRedirection:
	"""
	Redirect output sent to a particular stream
	"""
	def __init__(self, stream):
		self.stream = stream
	
	def write(self, data):
		global output_buffer
		
		output_buffer_lock.acquire()
		output_buffer += data
		self.stream.write(data)
		output_buffer_lock.release()

# Catch everything sent to standard out
sys.stdout = OutputRedirection(sys.__stdout__)
sys.stderr = OutputRedirection(sys.__stderr__)

class OptionObject:
	"""
	An object representing a contractor option. This object holds a reference
	to the actual option as well as a list of known possibilities, and whether
	or not the option may be disabled or set to a custom value.
	"""
	def __init__(self, name, option = None, options = [], default = 0):
		"""
		Create a new option object.
		
		@param name: The name of the option
		@type name: str
		@param option: The actual contractor option
		@type option: contractor.Option
		@param options: A list of possible values for the option
		@type options: list
		@param default: The index in the list of possible values to use as the
						default.
		@type default: int
		"""
		self.name = name
		self.option = option
		self.options = options
		self.default = default
		self.disable = True
		self.custom = True
	
	def set_value(self, value):
		"""
		Set the value of the option object.
		
		@param value: The value to set
		"""
		self.option.configure({self.option.name: value})
	
	def get_custom(self):
		"""
		Get a custom value for this option from the user. This displays a popup
		dialog with an input box to allow the user to enter a custom option
		value.
		
		@return: The entered value or None
		"""
		dialog = gtk.Dialog("Custom...", buttons = (gtk.STOCK_CANCEL, \
							gtk.RESPONSE_REJECT, gtk.STOCK_OK, \
							gtk.RESPONSE_ACCEPT))
		label = gtk.Label("Enter custom option for " + self.name)
		
		entry = gtk.Entry()	
		entry.connect("activate", lambda widget: \
										dialog.response(gtk.RESPONSE_ACCEPT))
		
		dialog.vbox.pack_start(label)
		dialog.vbox.pack_start(entry)
		dialog.vbox.set_border_width(10)
		dialog.vbox.set_spacing(5)
		dialog.vbox.show_all()
		
		response = dialog.run()
		if response == gtk.RESPONSE_ACCEPT:
			data = entry.get_text()
		else:
			data = None
		
		dialog.destroy()
		
		return data

class OptionTreeView:
	"""
	An object that attaches itself to an existing treeview and turns it into
	a view of editable options, setting up a model, columns, and other info,
	then allowing a developer to easily add options and populate the view.
	
	This object handles when the cursor is changed and when options are changed
	automagically.
	"""
	def __init__(self, treeview):
		"""
		Create a new OptionTreeView.
		
		@param treeview: The treeview to attach to
		@type treeview: gtk.TreeView
		"""
		self.options = {}
		self.view = treeview
		self.view.connect("cursor-changed", self.cursor_changed)
		self.model = gtk.ListStore(gobject.TYPE_PYOBJECT, \
								   gobject.TYPE_STRING, \
								   gobject.TYPE_STRING)
		self.view.set_model(self.model)
		
	def setup_columns(self, col1_name, col2_name):
		"""
		Setup the option view's columns. The left is a string and the right
		is the combo box where options are listed.
		
		@param col1_name: The name of the left column
		@type col1_name: str
		@param col2_name: The name of the right column
		@type col2_name: str
		"""
		renderer = gtk.CellRendererText()
		column = gtk.TreeViewColumn(col1_name, renderer, text = 1)
		self.view.append_column(column)
		
		renderer = gtk.CellRendererCombo()
		self.combo = gtk.ListStore(gobject.TYPE_STRING)
		renderer.set_property("model", self.combo)
		renderer.set_property("text-column", 0)
		renderer.set_property("editable", True)
		renderer.set_property("has-entry", False)
		renderer.connect("edited", self.combo_edit)
		column = gtk.TreeViewColumn(col2_name, renderer, text = 2)
		self.view.append_column(column)
	
	def option_check(self, possible, current_value):
		"""
		Check the validity of a possible option given the current value of the 
		actual option.
		
		@param possible: The possible option value to test
		@param current_value: The current real value of the option
		@return: True and the option value (which can be modified) or False
				 and None
		"""
		if possible != current_value:
			return True, possible
		
		return False, None
	
	def add_option(self, name, opt, possible, disable = True, custom = True,\
					option_object = OptionObject):
		"""
		Add an option with possible values to the view. Note that this does
		NOT add the option to the view's model. Make sure to call populate()
		after all options have been added!
		
		@param name: The name of the option
		@type name: str
		@param opt: The actual contractor option
		@type opt: contractor.Option
		@param possible: A list of possible option values
		@type possible: list
		@param disable: Allow the option value to be None?
		@type disable: bool
		@param custom: Allow custom input to the option?
		@type custom: bool
		@param option_object: The OptionObject-based class to create the object
							  with and add to the model.
		@type option_object: OptionObject-based class
		"""
		if not opt._have_value():
			opt.configure()
			
		value = opt.get()
		if value and value != True:
			options = [value]
		else:
			options = []
		
		for possibility in possible:
			okay, newval = self.option_check(possibility, value)
			if okay:
				options.append(newval)
		
		if value:
			default = 0
		else:
			default = len(options)
		
		obj = option_object(name, opt, options, default)
		obj.disable = disable
		obj.custom = custom
		self.options[obj.name] = obj
	
	def populate(self):
		"""
		Populate the view with all options defined using add_option(). Items are
		listed in alphabetical order for convenience.
		
		You SHOULD call add_option before populate. You SHOULD call populate
		after having called add_option any number of times and SHOULD only call
		populate to actually fill the tree view model once.
		"""
		keys = self.options.keys()
		keys.sort()
		for key in keys:
			option = self.options[key]
			iter = self.model.insert_before(None, None)
			self.model.set_value(iter, 0, option)
			self.model.set_value(iter, 1, option.name)
			if option.options:
				self.model.set_value(iter, 2, option.options[0])
			elif option.disable:
				self.model.set_value(iter, 2, "Disabled")
			elif option.custom:
				self.model.set_value(iter, 2, "Click to select custom...")
			else:
				print "No available options for " + option.name
	
	def cursor_changed(self, widget):
		"""
		Update the option combo box when the cursor is changed to a new item.
		"""
		model, iter = self.view.get_selection().get_selected()
		name = model.get_value(iter, 1)
		options = self.options[name].options
		self.combo.clear()
		for option in options:
			iter = self.combo.append()
			self.combo.set_value(iter, 0, option)
		if self.options[name].disable:
			iter = self.combo.append()
			self.combo.set_value(iter, 0, "Disabled")
		if self.options[name].custom:
			iter = self.combo.append()
			self.combo.set_value(iter, 0, "Custom...")
		iter = self.combo.append()
		self.combo.set_value(iter, 0, "Reset")
	
	def set_disabled(self, option):
		"""
		Set an option as disabled. Override this to do special things for
		specific options.
		
		@param option: The option to disable
		@type option: OptionObject
		"""
		if option.option.type == bool:
			option.set_value(False)
		elif option.option.type == str:
			option.set_value("")
	
	def set_custom(self, option):
		"""
		Get a custom value from the user for an option. Override this to do
		special things for specific options.
		
		@param option: The option to get the custom value for
		@type option: OptionObject
		@return: The custom value or None
		"""
		item = option.get_custom()
		if item:
			return item
		
		return None
	
	def combo_edit(self, renderer, index, item):
		"""
		Set a new value for the selected option.
		"""
		if item:
			model, iter = self.view.get_selection().get_selected()
			option = model.get_value(iter, 0)
			
			if item == "Custom...":
				item = self.set_custom(option)
				if item:
					model.set_value(iter, 2, item)
				else:
					return
			elif item == "Reset":
				option.option.reset()
				option.option.configure()
				model.set_value(iter, 2, option.option.get())
				return
			elif item[:8] == "Internal":
				option.set_value("")
				model.set_value(iter, 2, item)
				return
			else:
				model.set_value(iter, 2, item)
			
			if item == "Disabled":
				self.set_disabled(option)
			else:
				option.set_value(item)

class LangOptionView(OptionTreeView):
	"""
	Option tree view for the language options that babel and ccaffe support.
	"""
	def option_check(self, option, current_value):
		"""
		Check for valid binaries in the path if a custom option is set and only
		return true if the option is valid.
		"""
		if option != current_value and contractor.check_bin(option):
			return True, option
		
		return False, None

class PackageOptionView(OptionTreeView):
	"""
	Option tree view for the package options in the CCA Tools build.
	"""
	def combo_edit(self, renderer, index, item):
		if item:
			model, iter = self.view.get_selection().get_selected()
			option = model.get_value(iter, 0)
			
			if item == "Disabled" and option.name == "Chasm":
				packages.f90.configure({"f90": None})
				packages.f90_vendor.configure()
				option.set_value("")
				model.set_value(iter, 2, item)
			elif item[:8] == "Internal" and option.name == "Chasm":
				if packages.f90.get() == None:
					packages.f90.configure()
					packages.f90_vendor.configure()
				option.set_value("")
				model.set_value(iter, 2, item)
			elif item[:8] == "Internal" and option.name in ["Numpy", \
					"Spec Classic", "Spec Babel", "Ccaffeine"]:
				option.set_value(True)
				model.set_value(iter, 2, item)
			else:
				OptionTreeView.combo_edit(self, renderer, index, item)

class InstallerGUI:
	"""
	The CCA Tools Installer GTK+ GUI
	"""
	def __init__(self):
		"""
		Load the GUI from its GLADE file, attach signals, and create shortcut
		references to most used widgets in the tree, then setup the option views
		and show the window.
		"""
		gtk.gdk.threads_init()
		
		self.wtree = gtk.glade.XML(os.path.join(gui_dir,"cca-install.glade"), "main")

		signals = { "on_main_destroy": gtk.main_quit,
					"page_forward": self.page_forward,
					"page_back": self.page_back,
					"install": self.install,
					"cancel": self.cancel }
		self.wtree.signal_autoconnect(signals)

		self.window = self.wtree.get_widget("main")
		self.image = self.wtree.get_widget("image")
		self.notebook = self.wtree.get_widget("notebook")
		self.tree_lang = self.wtree.get_widget("treeview_lang")
		self.tree_package = self.wtree.get_widget("treeview_package")
		self.progress = self.wtree.get_widget("progressbar")
		self.progress_text = self.wtree.get_widget("progress_text")
		self.button_cancel = self.wtree.get_widget("button_cancel")
		self.button_back = self.wtree.get_widget("button_back")
		self.button_forward = self.wtree.get_widget("button_forward")
		self.button_install = self.wtree.get_widget("button_install")
		self.detail_text_view = self.wtree.get_widget("detail_text_view")
		self.detail_text = self.detail_text_view.get_buffer()
		self.detail_text.set_text("")
		
		self.lang_setup()
		self.package_setup()
		
		self.window.show()
	
	def lang_setup(self):
		"""
		Setup the language view with all the possible language options.
		"""
		self.lang_view = LangOptionView(self.tree_lang)
		view = self.lang_view
		view.setup_columns("Language", "Install Options")
		
		view.add_option("Fortran 90 compiler", packages.f90, packages.F90)
		view.add_option("Fortran 77 compiler", packages.f77, packages.F77)
		view.add_option("C compiler", packages.cc, packages.CC, disable = False)
		view.add_option("C++ compiler", packages.cxx, packages.CXX, \
						disable = False)
		view.add_option("Java runtime", packages.java, packages.JAVA)
		view.add_option("Python interpreter", packages.python.python_prefix, packages.python.PYTHON)
		view.add_option("MPI Prefix", packages.mpi,[])
		
		view.populate()

	def package_setup(self):
		"""
		Setup the package view with options for all the packages, such as which
		packages to build internally and which to use that are already present
		on the system.
		"""
		self.package_view = PackageOptionView(self.tree_package)
		view = self.package_view
		view.setup_columns("Package", "Install Options")
		
		view.add_option("Boost", packages.boost_prefix, ["Internal (" + \
						packages.boost_version + ")"], disable = False)
		view.add_option("LibXML2", packages.libxml2_prefix, ["Internal (" + \
						packages.libxml2_version + ")"], disable = False)
		view.add_option("Chasm", packages.chasm_prefix, ["Internal (" + \
						packages.chasm_version + ")"])
		view.add_option("Python", packages.python.python_prefix, ["Internal (" + \
						packages.python.python_version.get() + ")"])
		view.add_option("Numpy", packages.python.numpy_internal, ["External", \
						"Internal (" + packages.python.numpy_version + ")"], \
						disable = False, custom = False)
		view.add_option("Spec Classic", packages.spec_classic_internal, \
						["Internal (Nightly)"], custom = False)
		view.add_option("Spec Babel", packages.spec_babel_internal, \
						["Internal (Nightly)"], custom = False)
		view.add_option("Ccaffeine", packages.ccaffeine_internal, \
						["Internal (Nightly)"], custom = False)
		
		view.populate()

	def page_forward(self, widget):
		"""
		Move a page forward in the dialog (which is really just a notebook).
		"""
		tab = self.notebook.get_current_page()
		self.notebook.set_current_page(tab + 1)
		if tab + 1 == TAB_END - 1:
			self.button_forward.set_sensitive(False)
			self.button_install.set_sensitive(True)
		self.button_back.set_sensitive(True)
		self.image.set_from_file(os.path.join(gui_dir,"cca-install-config.png"))
	
	def page_back(self, widget):
		"""
		Move a page backward in the dialog (which is really just a notebook).
		"""
		tab = self.notebook.get_current_page()
		self.notebook.set_current_page(tab - 1)
		if tab - 1 == TAB_START:
			self.button_back.set_sensitive(False)
			self.image.set_from_file(os.path.join(gui_dir,"cca-install-welcome.png"))
		else:
			self.button_forward.set_sensitive(True)
			self.button_install.set_sensitive(False)
	
	def install(self, widget):
		"""
		Move a page forward in the dialog and begin the install process!
		"""
		self.notebook.set_current_page(TAB_END)
		self.button_back.set_sensitive(False)
		self.button_forward.set_sensitive(False)
		self.button_install.set_sensitive(False)
		self.image.set_from_file(os.path.join(gui_dir,"cca-install-installing.png"))
		
		installer = InstallerThread(self)
		installer.start()
	
	def cancel(self, widget):
		"""
		Cancel the install.
		TODO: Show a dialog here?
		"""
		gtk.main_quit()

class InstallerThread(threading.Thread):
	"""
	A thread to run the actual installation process and handle events, such as
	when packages are completed so that the main thread can respond to user and
	other actions.
	"""
	def __init__(self, gui):
		"""
		Initialize this thread and link it to the user interface so that it can
		update (e.g. the progress bar).
		
		@param gui: The user interface
		@type gui: InstallerGUI
		"""
		threading.Thread.__init__(self)
		self.setDaemon(True)
		self.gui = gui
		self.nodes = []
		self.total_nodes = 0
		self.nodes_finished = 0
		self.packages = []
		self.packages_finished = 0
		self.current_package = ""
		contractor.events.connect("node-started", self.node_started)
		contractor.events.connect("node-finished", self.node_finished)
		contractor.events.connect("error", self.handle_error)
		self.get_package_nodes()
	
	def get_package_nodes(self):
		"""
		Sort through all the nodes in the contractor tree and pull out the ones
		we care about to monitor the build.
		"""
		nodes = contractor.get_nodes()
		keys = nodes.keys()
		
		for pos, key in enumerate(keys):
			parts = key.split("/")
			if len(parts) > 1:
				package, stage = parts
				
				# Filter out special stages
				if stage in ["all", "clean", "create_sc_tarball"]:
					continue
					
				if package not in self.packages:
					self.packages.append(package)
				if key not in self.nodes:
					self.nodes.append(key)
					
		self.total_nodes = len(self.nodes)
		self.packages.sort()
		self.nodes.sort()
		
		#print self.packages
		#print self.nodes
	
	def update_detail_view(self):
		"""
		Update the detail view with output sent to standard out by commands.
		"""
		global output_buffer
		
		output_buffer_lock.acquire()
		gtk.gdk.threads_enter()	
			
		buffer = self.gui.detail_text
		# Massage away the stupid color codes
		match = re.match("([^\x1B]*)(?:\x1B[^m]*m([^\x1B]*)\x1B[^m]*m)*(.*)", \
						 output_buffer)
		text = "".join(group for group in match.groups() if group)
		
		if len(output_buffer) > 1 and output_buffer[-1] == "\n":
			text += "\n"
		
		#print >>sys.__stdout__, output_buffer
		#print >>sys.__stdout__, text
		
		buffer.insert(buffer.get_end_iter(), text)
		output_buffer = ""
		
		gtk.gdk.threads_leave()
		output_buffer_lock.release()
		
		return True
	
	def run(self):
		"""
		The threads execution method. Do not invoke this directly - instead use
		Installer.start() which will create a new thread and call this function.
		
		This method initializes the progress bar and text, then begins the build
		process through contractor.
		"""
		gtk.gdk.threads_enter()
		self.gui.progress.set_fraction(0)
		self.gui.progress_text.set_text("Packages installed: %i of %i" % \
				(0, len(self.packages)))
		gtk.gdk.threads_leave()
		gobject.timeout_add(250, self.update_detail_view)
		contractor.build_node()
	
	def node_started(self, node):
		"""
		Called when a node has started building. Update the GUI, etc.
		
		@param node: The node's name
		@type node: str
		"""
		if node and node.name in self.nodes:
			#print node.name + " started"
			package, stage = node.name.split("/")
			
			if not self.current_package:
				self.current_package = package
			
			gtk.gdk.threads_enter()
			
			if self.current_package != package:
				self.packages_finished += 1
				self.current_package = package
				self.gui.progress_text.set_text("Packages installed: %i of %i" \
								% (self.packages_finished, len(self.packages)))
			
			self.gui.progress.set_text(node.name)
			
			gtk.gdk.threads_leave()
	
	def node_finished(self, node):
		"""
		Called when a node has finished building. Update the GUI, etc.
		
		@param node: The node's name
		@type node: str
		"""
		if node and node.name in self.nodes:
			#print node.name + " finished"
			package, stage = node.name.split("/")
			self.nodes_finished += 1
			
			gtk.gdk.threads_enter()
			
			if self.nodes_finished == self.total_nodes:
				self.gui.progress_text.set_text("Packages installed: %i of %i" \
					% (len(self.packages), len(self.packages)))
				self.gui.progress.set_fraction(1)
				self.gui.progress.set_text("Installation complete.")
				self.gui.button_cancel.set_sensitive(False)
				gtk.gdk.threads_leave()
				return
				
			#print float(self.nodes_finished) / self.total_nodes
			self.gui.progress.set_fraction(float(self.nodes_finished) / 
											self.total_nodes)
			gtk.gdk.threads_leave()
			
			self.nodes.remove(node.name)
			
	def handle_error(self, args):
		"""
		Called when an error occurs.
		
		@param args: The command that caused the error and the logfile
		@type args: tuple
		"""
		print "Error! trying to clean up..."
		command = args[0]
		logfile = args[1]
		archive = args[2]
		
		gtk.gdk.threads_enter()
		
		dialog = gtk.Dialog("Error!", self.gui.window, gtk.DIALOG_MODAL | \
					gtk.DIALOG_DESTROY_WITH_PARENT, (gtk.STOCK_OK, \
					gtk.RESPONSE_ACCEPT))
		label = gtk.Label("There was an error with the build.\n" + \
						  "An archive of logs has been saved to " + archive + \
						  ".\nPlease email this file to dtaylor@mcs.anl.gov " + \
						  "so that we can try and fix the problem.\nLog " + \
						  "output is displayed below if available.")
		textbuffer = gtk.TextBuffer()
		textview = gtk.TextView(buffer = textbuffer)
		textview.set_property("wrap-mode", gtk.WRAP_WORD)
		textview.set_size_request(640, 350)
		scrolls = gtk.ScrolledWindow()
		scrolls.set_property("hscrollbar-policy", gtk.POLICY_AUTOMATIC)
		scrolls.set_property("vscrollbar-policy", gtk.POLICY_AUTOMATIC)
		scrolls.set_property("shadow-type", gtk.SHADOW_IN)
		scrolls.add(textview)
		dialog.vbox.pack_start(label, expand=False)
		dialog.vbox.pack_start(scrolls)
		dialog.vbox.set_property("spacing", 5)
		dialog.set_property("border-width", 5)
		dialog.vbox.show_all()
		
		text = ""
		if logfile:
			text = open(logfile).read()
		
		if text:
			textbuffer.set_text(text)
		else:
			textbuffer.set_text("No log data found.")
		
		dialog.run()
		dialog.destroy()
		
		gtk.gdk.threads_leave()
		gtk.main_quit()

if __name__ == "__main__":
	InstallerGUI()
	gtk.main()

