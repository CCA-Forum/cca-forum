#!/usr/bin/env python

import os, os.path

from contractor import *

# List compilers to check for here!

F90 = ["gfortran", "g95", "ifort", "f90", "f95", "xlf90", "xlf95", "pgf90", \
        "ifc"]
F77 = F90 + ["f77", "pgf77"]
CC = ["cc", "gcc"]
CXX = ["c++", "cxx", "g++", "xlc++"]
JAVA = ["java", "gcj"]
JAVAC = ["javac", "gcj"]

def fortran_vendor_check():
    """
    Set the fortran vendor based on the selected compiler.
    """
    compiler = f90.get()
    if compiler:
        compiler = os.path.basename(compiler)
    vendor = None
    
    if compiler == "gfortran":
        vendor = "GNU"
    elif compiler == "g95":
        vendor = "G95"
    elif compiler == "ifort":
        vendor = "Intel"
    elif compiler == "ifc":
        vendor = "Intel_7"
    elif compiler == "f90":
        vendor = "Absoft"
    elif compiler in ["xlf90", "xlf95"]:
        vendor = "IBMXL"
    elif compiler == "f95":
        vendor = "NAG"
    elif compiler == "pgf90":
        vendor = "PGI"
    
    return vendor

def check_f77():
    f90compiler = f90.get()
    if f90compiler: return f90compiler
    else: return check_bin_list(F77)

def java_check():
    """
    Attempt to find and set the java and javac to use
    """
    javaexec = None
    javacexec = None
    # Check various environment variables
    for envvar in ["JAVA_HOME", "JAVAPREFIX", "JAVA_DIR"]:
        if os.environ.has_key(envvar):
            path = os.path.join(os.environ["JAVA_HOME"], "bin", "javac")
            if path and  os.access(path, os.F_OK):
                javacexec = path	

    # Check the default paths
    if not javacexec:
        path = check_bin_list(JAVAC)
        if path and os.access(path, os.F_OK):
                javacexec = path

    if javacexec:
        path = os.path.join(os.path.dirname(javacexec),"java")
        if path and os.access(path, os.F_OK):
            javaexec = path
        else:
            path = os.path.join(os.path.dirname(javacexec),"gcj")
            if path and os.access(path, os.F_OK):
                javaexec = path

    if not javacexec:
        err("Couldn't find javac (a Java compiler, preferably by Sun, is required for building Babel). Please make sure javac is in your path or run contract.py --configure java=/path/to/jdk/installation.")

    return javaexec

    
f90 = Option(local_root, "f90", "", str, "Fortran 90 compiler", \
                 function = lambda: check_bin_list(F90))

f90_vendor = Option(local_root, "f90_vendor", "", str,
                        "Fortran 90 compiler vendor", function = \
                        fortran_vendor_check, deps = [f90])

f77 = Option(local_root, "f77", "", str, "Fortran 77 compiler", \
                function = lambda: check_f77())

cc = Option(local_root, "cc", "", str, "C compiler", \
                function = lambda: check_bin_list(CC))

cxx = Option(local_root, "cxx", "", str, "C++ compiler", \
                function = lambda: check_bin_list(CXX))

java = Option(local_root, "java", "", str, "Java interpreter", \
                function = java_check)

