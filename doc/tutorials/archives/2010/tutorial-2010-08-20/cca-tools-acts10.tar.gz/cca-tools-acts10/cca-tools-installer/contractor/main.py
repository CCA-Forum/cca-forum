# This file is part of Contractor
# Original author: James Amundson, amundson@fnal.gov
# (c) 2007-2010 Fermi Research Alliance, LLC
# For copying information, see the file LICENSE 

#!/usr/bin/env python

import sys

from configuration import *
from nodes import *
from utils import check_shell
from messages import info,err
from cores import *

check_shell()

def usage(retval=0):
    info("usage: cont [options] [targets]\n" + \
         "options:\n" + \
         "        --help                    : this message\n" + \
         "        --configure [args]        : configure build options\n" + \
         "        --configure-help          : list all build options\n" + \
         "        --configure-show          : show values of build options\n" + \
         "        --configure-dump <file>   : dump build options to file\n" + \
         "        --configure-import <file> : import build options from file\n" + \
         "        --configure-reset         : reset configuration to default\n" + \
         "        --list-targets            : list designated targets\n" + \
         "        --list-nodes              : list all defined nodes\n" + \
         "        --default                 : list default targets\n" + \
         "        --deps <target>           : show dependencies for <target>\n" + \
         "        --viz                     : create postscript graphs (requires pydot)\n" + \
         "        --gee-viz                 : display live dependency graphs\n" + \
         "        --processes <num>         : number of processes to use for builds\n" + \
         "                                    (overrides the default automatically \n" + \
         "                                    determined number which is based on \n" + \
         "                                    the number of cores and current load)")
    sys.exit(retval)

def main(argv):
    argv.reverse()
    if len(argv) > 0:
        argv.pop()
    found_target = 0

    # Run configure the very first time if it has not been run before
    if len(argv) == 0 and not os.path.exists(os.path.join(os.getcwd(),'config','configure_cmd')):
        configure(argv,exit=False)

    while len(argv) > 0:
        arg = argv.pop()
        if arg == "--help":
            usage(0)
        elif arg == "--configure":
            configure(argv)
        elif arg == "--configure-help":
            configure_help()
        elif arg == "--configure-show":
            configure_show()
        elif arg == "--configure-dump":
            configure_dump(argv)
        elif arg == "--configure-import":
            configure_import(argv)
        elif arg == "--configure-reset":
            configure_reset()
        elif arg == "--list-targets":
            list_targets()
        elif arg == "--list-nodes":
            list_nodes()
        elif arg == "--default":
            list_default()
        elif arg == "--deps":
            if len(argv) > 0:
                dep_arg = argv.pop()
            else:
                usage(1)
            list_deps(dep_arg)
        elif arg == "--viz":
            viz()
        elif arg == "--gee-viz":
            gee_viz()
        elif arg == '--processes':
            cores = argv.pop()
            set_num_cores(cores,caching = True, dynamic = False)
        elif arg == '--cores':
            cores = argv.pop()
            set_num_cores(cores,caching = True, dynamic = False)
        elif arg[0] == "-":
            err('unknown option "%s"' % arg)
            usage(1)
        else:
            timer.reset_timer()
            build_node(arg)
            timer.show_timer()
            found_target = 1
    if not found_target:
        timer.reset_timer()
        build_node()
        timer.show_timer()


