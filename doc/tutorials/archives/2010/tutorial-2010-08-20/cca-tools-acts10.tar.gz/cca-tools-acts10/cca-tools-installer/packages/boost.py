#!/usr/bin/env python

from contractor import *

boost_prefix = Option(local_root, "boost_prefix", "", str,
						"Prefix to boost installation")

boost_version = "1.34.0"
boost_url = "http://www.cca-forum.org/download/cca-tools/dependencies/boost_" + \
			boost_version.replace(".", "_") + ".tar.bz2"

if boost_prefix.get() == "":
	boost = Package(local_root, "boost", [Unpack(url = boost_url)], optiondeps=[boost_prefix])
else:
	boost = External_package("boost")

