#!/usr/bin/env python

import os

from contractor import *
from ccaffeine import *

ccafe_gui_internal = Option(local_root, "ccafe_gui_internal", True, \
						bool, "Install internal version of Ccaffeine GUI")


if nightly.get():
    ccafe_gui_url = nightlyurl + "ccafe-gui.tar.gz"
    ccafe_gui_version = "nightly"
    ccafe_gui_md5 = 'ccafe-gui.md5sum'
else:
    ccafe_gui_version = "0.5.8"
    ccafe_gui_url = toolsurl + 'ccafe-gui-' + ccafe_gui_version + '.tar.gz'
    ccafe_gui_md5 = 'ccafe-gui-' + ccafe_gui_version + '.md5sum'

            
if ccafe_gui_internal.get():
	ccafe_gui = Package(local_root, "ccafe_gui", \
			[Unpack(url = ccafe_gui_url, md5file=ccafe_gui_md5), \
			Configure(extra_args = "--with-ccafe-config=%s/bin/ccafe-config" % ccaffeine.get_var("root.install_dir")), \
			Make(), Install()], \
			[ccaffeine])
else:
	ccafe_gui = External_package("ccafe_gui")
