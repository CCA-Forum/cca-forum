#!/usr/bin/env python

import os
from contractor import *

MPI = ["mpicc"]

def mpi_check():
    for compiler in MPI:
        if check_bin(os.path.join("usr", "bin", compiler)):
            return os.path.join("usr", "bin")
    
    return None
            
mpi_prefix = Option(local_root, "mpi", "", str, "MPI Prefix", \
                    function = mpi_check)

# For backward compatibility of option
mpi = mpi_prefix

