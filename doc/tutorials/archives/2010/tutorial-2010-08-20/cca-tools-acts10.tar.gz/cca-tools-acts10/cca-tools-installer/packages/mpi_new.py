#!/usr/bin/env python

import os
from contractor import *

# Determine the following values: 
# mpi prefix, mpi includes paths, mpi library paths, location of mpd, 
# binaries path, full paths for compiler wrappers for C and C++, and f77 and f90
# wrappers if those languages are enabled.

MPICC = ["mpicc", "mpixlc_r", "mpixlc"]
MPICXX = ["mpiCC", "mpic++", "mpicxx", "mpixlcxx_r", "mpixlcxx"]
mpi_prepaths = [self.prefix, 
                os.path.abspath(os.path.join(self.prefix,'..')),
                "/usr", "/usr/local", "/usr/lib", os.getenv("HOME")]
mpi_names = ['mpi', 'mpich', 'openmpi', 'ompi']

class MPIInfo:
    def __init__(self, prefix):
        self.prefix = prefix
        
        

def mpi_check():
        
    for mpipath in mpi_prepaths:
        for mpi
        if check_bin(os.path.join(mpipath,'mpicc')):
            return os.path.join(mpipath)
        for mpiname in mpinames:                
            if check_bin(os.path.join()
            if check_bin(os.path.join("usr", "bin", compiler)):
                return os.path.join("usr", "bin")
    
    return None

            
mpi_prefix = Option(local_root, "mpi", "", str, "MPI Prefix", \
                    function = mpi_check_prefix)

# For backward compatibility of option
mpi = mpi_prefix

