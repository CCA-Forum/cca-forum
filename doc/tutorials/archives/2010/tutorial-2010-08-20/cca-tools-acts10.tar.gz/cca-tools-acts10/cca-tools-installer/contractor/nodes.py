# This file is part of Contractor
# Original author: James Amundson, amundson@fnal.gov
# (c) 2007-2010 Fermi Research Alliance, LLC
# For copying information, see the file LICENSE 

#!/usr/bin/env python
import os,sys,glob,time

from utils import *
#from configuration import *
import timer
from viz import *

import events

_nodes = {}
_targets = []
_default = None

class Node:
    def __init__(self, name):
        self.name = name
        self.dependencies = []
        _nodes[self.name] = self

    def get_name(self):
        return self.name

    def is_modified(self, parent):
        return 1

    def modification_time(self):
        return None

    def reset(self):
        pass

    def exists(self):
        return 0

    def recursive_reset(self):
        for dependency in self.dependencies:
            dependency.recursive_reset()

    def depends(self,dependency):
        self.dependencies.append(dependency)
        self._check_circularity()

    def list_dependencies(self, prefix=""):
        info(prefix + " " + self.name)
        for dependency in self.dependencies:
            dependency.list_dependencies(prefix+"  ")
        
    def build(self):
        dependency_modified = 0
        built = 0
        for dependency in self.dependencies:
            dependency.build()
        for dependency in self.dependencies:
            if dependency.is_modified(self):
                dependency_modified = 1
        events.signal("node-started", self)
        if dependency_modified or (not self.exists()):
            update_graphs(self.name,"building")
            self.build_method()
            built = 1
        events.signal("node-finished", self)
        update_graphs(self.name,"done")
        return built

    def build_method(self):
        info("building node '%s'" % self.name)

    def _check_circularity(self, parents=[]):
        if parents.count(self)>0:
            raise RuntimeError, 'Circular dependency in %s' % self.name 
        new_parents = list(parents)
        new_parents.append(self)
        for dependency in self.dependencies:
            dependency._check_circularity(new_parents)

    def is_newer(self, other_node):
        my_time = self.modification_time()
        newer = 0
        if other_node == None:
            newer = 0
        else:
            other_time = other_node.modification_time()
            if my_time == None or other_time == None:
                newer = 1
            else:
                newer =  (my_time > other_time)
        return newer
    
class Dummy_node(Node):
    def build_method(self):
        pass
    def is_modified(self, parent):
        return 0
    
class Command(Node):
    def __init__(self, name, command):
        self.command = command
        Node.__init__(self, name)

    def build_method(self):
        self.command()

class Command_string(Command):
    def build_method(self):
        os.system(self.command)

class File(Node):
    def __init__(self, name, filename=None, create_command=None):
        if filename:
            self.filename = filename
        else:
            self.filename = name
        self.create_command = create_command
        Node.__init__(self,name)
        
    def modification_time(self):
        if os.path.exists(self.filename):
            return os.path.getmtime(self.filename)
        else:
            return None

    def is_modified(self, parent):
        if os.path.exists(self.filename):
            return self.is_newer(parent)
        else:
            return 1

    def exists(self):
        return os.path.exists(self.filename)

    def build_method(self):
        if self.create_command:
            self.create_command(self.filename)
        else:
            raise RuntimeError, 'No such file "%s"' % self.filename

class Directories(Node):
    def __init__(self, name, dirnames=None):
        if dirnames:
            self.dirnames = listify(dirnames)
        else:
            self.dirnames = listify(name)
        Node.__init__(self,name)
        
    def modification_time(self):
        return None

    def is_modified(self, parent):
        return 0

    def exists(self):
        retval = 1
        for dirname in self.dirnames:
            if not os.path.isdir(dirname):
                retval = 0
        return retval

    def build_method(self):
        for dirname in self.dirnames:
            if not os.path.isdir(dirname):
                os.makedirs(dirname)

class Tagged_node(File):
    def build_method(self):
        if not os.path.isdir(os.path.dirname(self.filename)):
            os.makedirs(os.path.dirname(self.filename))
        f = open(self.filename,"w")
        f.write("this is my tag!\n")
        f.close()

class Tagged_command(Tagged_node):
    def __init__(self, name, command, filename=None):
        self.command = command
        File.__init__(self, name, filename)

    def build_method(self):
        self.command()
        Tagged_node.build_method(self)

def target(node):
    _targets.append(node.get_name())

def default(node):
    global _default
    _default=node.get_name()

def list_targets(retval=0):
    if len(_targets) > 0:
        _targets.sort()
        last_package = None
        for target in _targets:
            package = target.split('/')[0]
            if last_package and (last_package <> package):
                info("")
            info(target, end=' ')
            last_package = package
    else:
        info("No targets defined.")
    sys.exit(retval)

def list_nodes(retval=0):
    if len(_nodes) > 0:
        node_names = _nodes.keys()
        last_package = None
        node_names.sort()
        for name in node_names:
            package = name.split('/')[0]
            if last_package and (last_package <> package):
                info("")
            info(name, end=' ')
            last_package = package
    else:
        info("No nodes defined.")
    sys.exit(retval)

def get_default():
    if _default:
        return _default
    elif len(_targets) > 0:
        return(list(_targets).pop())
    elif len(_nodes) > 0:
        return(list(_nodes.keys()).pop())
    else:
        return None

def list_default(retval=0):
    default = get_default()
    if default:
        exit(default,retval)
    else:
        list_nodes(1)
    sys.exit(retval)

def list_deps(node,retval=0):
    if not _nodes.has_key(node):
        warn("Unknown node '%s'. Defined nodes:" % node)
        list_nodes(1)
    _nodes[node].list_dependencies()
    sys.exit(retval)
    
def build_node(node=None):
    if not node:
        node = get_default()
    if not _nodes.has_key(node):
        warn("Unknown node '%s'. Defined nodes:" % node)
        list_nodes(1)
    if not _nodes[node].build():
        info("nothing to be done for " + str(node))

def get_nodes():
    return _nodes

try:
    import pydot

    def viz():
        viz_main(_nodes)
        sys.exit(0)
        
    def gee_viz():
        gee_viz_main(_nodes)
        
except:
    def viz():
        err("pydot must be installed in order to use the viz option")
        sys.exit(1)            

    def gee_viz():
        err("pydot must be installed in order to use the gee-viz option")
        sys.exit(1)            
        
