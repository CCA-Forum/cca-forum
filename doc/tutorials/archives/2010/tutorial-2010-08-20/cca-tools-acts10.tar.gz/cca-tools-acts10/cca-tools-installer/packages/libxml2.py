#!/usr/bin/env python

import os

from contractor import *

def libxml2_check():
    if check_bin("xml2-config"):
        prefix = os.popen("xml2-config --prefix").read().strip()

    elif check_lib("libxml2"):
        prefix = "External"
    else:
        prefix = "internal"
        
    if not os.path.exists(prefix) or (os.path.exists(prefix) and not os.path.exists(os.path.join(prefix,'include','libxml2','libxml','SAX.h'))):
        prefix = "internal"
    return prefix

    

libxml2_prefix = Option(local_root, "libxml2_prefix", "internal", str,
                          "Prefix to the libxml2 installation", \
                          function = libxml2_check)

libxml2_version = "2.6.28"
libxml2_url = "http://www.cca-forum.org/download/cca-tools/dependencies/libxml2-" + libxml2_version + ".tar.gz"

if libxml2_prefix.get() in [None,"","None","internal"]:
    libxml2 = Package(local_root, "libxml2", [Unpack(url = libxml2_url), \
                                              Configure(extra_args="--without-http"), Make(), Install()])
else:
    # Check libxml2 headers (especially missing libxml2-devel package)
    if not os.path.exists(os.path.join(libxml2_prefix.get(),'include','libxml2','libxml','SAX.h')):
        err('Could not find libxml2 headers in %s (e.g., SAX.h). ' % libxml2_prefix.get() + \
            'Please make sure you have libxml2-devel rpm installed or reconfigure this build with libxml2_prefix=internal')
    libxml2 = External_package("libxml2",prefix=libxml2_prefix.get())
