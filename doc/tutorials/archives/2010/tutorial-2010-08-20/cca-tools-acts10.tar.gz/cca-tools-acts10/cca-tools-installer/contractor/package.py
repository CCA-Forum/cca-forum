# This file is part of Contractor
# Original author: James Amundson, amundson@fnal.gov
# (c) 2007-2010 Fermi Research Alliance, LLC
# For copying information, see the file LICENSE 

#!/usr/bin/env python
import os,sys,glob,time

import events

from utils import *
from nodes import *
from configuration import get_prefix

class External_package:
    def __init__(self, name, prefix=None):
        self.name = name
        self.prefix = prefix
        p = get_prefix()
        if p is not None:
            self.prefix = p
        self.vars = {}
        self.node = Dummy_node(name)

    def first_tag(self):
        return self.node

    def last_tag(self):
        return self.node

    def get_name(self):
        return self.name

    def get_var(self,name):
        return self.vars[name]

    def get_vars(self):
        return self.vars

    def new_var(self,name,value):
        self.vars[name] = value % self.vars

    def get_prefix(self):
        return self.prefix

class Package:
    def __init__(self, root, name, stages, depends=[], non_depends=[],
                 src_dir=None, build_dir=None, precious=0, optiondeps=[]):
        self.name = name
        self.root = root
        self.precious = precious
        self.vars = {}
        self.optiondeps = optiondeps
        self.add_vars(self.root)
        p = get_prefix()
        if p is not None: self.prefix = p
        else: self.prefix=self.vars['root.install_dir']
        if src_dir:
            self.vars['src_dir'] = abs_rel_dir(self.vars['root.build_dir'],
                                                 src_dir)
        else:
            self.vars['src_dir'] = os.path.join(self.vars['root.build_dir'],
                                                self.name)
        if build_dir:
            self.vars['build_dir'] = abs_rel_dir(self.vars['root.build_dir'],
                                                 build_dir)
        else:
            self.vars['build_dir'] = self.vars['src_dir']
        self.vars['log_dir'] = os.path.join(self.vars['root.log_dir'],
                                            self.name)
        self.vars['tag_dir'] = os.path.join(self.vars['root.tag_dir'],
                                            self.name)
        self.stage_list = []
        self.stage_data = {}
        self.stage_objects = {}
        self.stage_tags = []
        for stage in stages:
            stage.set_package(self)
            self.stage_list.append(stage)
            stage_name = stage.get_name()
            tag_name = self._tag_name(stage_name)
            tag_file = self._tag_file(stage_name)
            self.stage_objects[stage_name] = Tagged_command(\
                tag_name,stage.build_method,tag_file)
            if stage.aux_stage():
                stage_name = stage.aux_stage().get_name()
                tag_name = self._tag_name(stage_name)
                self.stage_objects[stage_name] = Command(\
                    tag_name,stage.aux_stage().build_method)
                self.root.get_dist().depends(self.stage_objects[stage_name])
            if self.last_tag():
                self.stage_objects[stage_name].depends(self.last_tag())
            self.stage_tags.append(tag_name)
        self.first_tag().depends(self.root.dirs_node())
        self.clean_object = Command(self._tag_name("clean"), self.clean)
        target(self.clean_object)
        self.all_object = Tagged_node(self._tag_name("all"),
                                      self._tag_file("all"))
        self.all_object.depends(self.last_tag())
        target(self.all_object)
        for dependency in depends:
            package_depends(self,dependency)
            self.add_vars(dependency)
        for dependency in non_depends:
            self.add_vars(dependency)
            
    def _tag_name(self, stage_name):
        return "%s/%s" % (self.name,stage_name)
    
    def _tag_file(self, stage_name):
        return os.path.join(self.vars['tag_dir'],stage_name)
    
    def get_name(self):
        return self.name

    def get_prefix(self):
        return self.prefix
    
    def get_var(self,name):
        return self.vars[name]

    def get_vars(self):
        return self.vars

    def add_vars(self, package):
        prefix = package.get_name() + "."
        for key in package.get_vars():
            self.vars[prefix+key] = package.get_var(key)
            
    def first_tag(self):
        return self.stage_objects[self.stage_list[0].get_name()]

    def last_tag(self):
        last = len(self.stage_tags) - 1
        if last >= 0:
            tag = self.stage_objects[self.stage_list[last].get_name()]
        else:
            tag = None
        return tag

    def first_object(self):
        first = self.stage_list[0]
        return self.stage_objects[first]

    def last_object(self):
        last = self.stage_list[len(self.stage_list) - 1]
        return self.stage_objects[last]

    def stage_object(self,name):
        return self.stage_objects[name]

    def is_precious(self):
        return self.precious

    def clean(self):
        os.system("/bin/rm -rf %(build_dir)s %(src_dir)s %(tag_dir)s %(log_dir)s"%\
                  self.vars)
        
def package_depends(target, dependency):
    if type(dependency) == type(()) or type(dependency) == type([]):
        target.first_tag().depends([d.last_tag() for d in dependency])
    else:
        target.first_tag().depends(dependency.last_tag())

