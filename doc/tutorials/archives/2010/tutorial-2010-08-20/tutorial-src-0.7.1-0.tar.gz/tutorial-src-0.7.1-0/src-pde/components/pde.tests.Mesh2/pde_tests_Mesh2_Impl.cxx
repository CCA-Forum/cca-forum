// 
// File:          pde_tests_Mesh2_Impl.cxx
// Symbol:        pde.tests.Mesh2-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.tests.Mesh2
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_tests_Mesh2_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_ParameterPortFactory_hxx
#include "gov_cca_ports_ParameterPortFactory.hxx"
#endif
#ifndef included_pde_MeshSource_hxx
#include "pde_MeshSource.hxx"
#endif
#ifndef included_pde_RenderPort_hxx
#include "pde_RenderPort.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.tests.Mesh2._includes)

  // Insert-UserCode-Here {pde.tests.Mesh2._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(pde.tests.Mesh2._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.tests.Mesh2._includes)

  // Insert-UserCode-Here {pde.tests.Mesh2._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.tests.Mesh2._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::tests::Mesh2_impl::Mesh2_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::tests::Mesh2::_wrapObj(reinterpret_cast< void*>(this))),false) , 
  _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(pde.tests.Mesh2._ctor2)
  // Insert-Code-Here {pde.tests.Mesh2._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.tests.Mesh2._ctor2)
}

// user defined constructor
void pde::tests::Mesh2_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.tests.Mesh2._ctor)
    
  // Insert-UserCode-Here {pde.tests.Mesh2._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(pde.tests.Mesh2._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.tests.Mesh2: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.tests.Mesh2._ctor)

  // Insert-UserCode-Here {pde.tests.Mesh2._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(pde.tests.Mesh2._ctor)
}

// user defined destructor
void pde::tests::Mesh2_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.tests.Mesh2._dtor)
  // Insert-UserCode-Here {pde.tests.Mesh2._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.tests.Mesh2._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.tests.Mesh2: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.tests.Mesh2._dtor) 

  // DO-NOT-DELETE splicer.end(pde.tests.Mesh2._dtor)
}

// static class initializer
void pde::tests::Mesh2_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.tests.Mesh2._load)
  // Insert-Code-Here {pde.tests.Mesh2._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.tests.Mesh2._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
pde::tests::Mesh2_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.tests.Mesh2.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.tests.Mesh2.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "pde.tests.Mesh2: Error casting self to gov::cca::Port");
  } 


  // Provide a gov.cca.ports.GoPort port with port name GO 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "GO", // port instance name
                   "gov.cca.ports.GoPort",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "pde.tests.Mesh2: Error calling addProvidesPort(port,"
        "\"GO\", \"gov.cca.ports.GoPort\", typeMap) ", -2);
    throw;
  }    

  // Use a pde.MeshSource port with port name mesher 
  try{
    this->d_services.registerUsesPort(
                   "mesher", // port instance name
                   "pde.MeshSource",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.tests.Mesh2: Error calling registerUsesPort(\"mesher\", "
       "\"pde.MeshSource\", typeMap) ", -2);
    throw;
  }

  // Use a pde.RenderPort port with port name output 
  try{
    this->d_services.registerUsesPort(
                   "output", // port instance name
                   "pde.RenderPort",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.tests.Mesh2: Error calling registerUsesPort(\"output\", "
       "\"pde.RenderPort\", typeMap) ", -2);
    throw;
  }

  // Use a gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    this->d_services.registerUsesPort(
                   "ppf", // port instance name
                   "gov.cca.ports.ParameterPortFactory",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.tests.Mesh2: Error calling registerUsesPort(\"ppf\", "
       "\"gov.cca.ports.ParameterPortFactory\", typeMap) ", -2);
    throw;
  }


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(pde.tests.Mesh2.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(pde.tests.Mesh2.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
pde::tests::Mesh2_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.tests.Mesh2.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.tests.Mesh2.boccaReleaseServices)
  this->d_services=0;


  // Un-provide gov.cca.ports.GoPort port with port name GO 
  try{
    services.removeProvidesPort("GO");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.tests.Mesh2: Error calling removeProvidesPort("
              << "\"GO\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release pde.MeshSource port with port name mesher 
  try{
    services.unregisterUsesPort("mesher");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.tests.Mesh2: Error calling unregisterUsesPort("
              << "\"mesher\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release pde.RenderPort port with port name output 
  try{
    services.unregisterUsesPort("output");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.tests.Mesh2: Error calling unregisterUsesPort("
              << "\"output\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    services.unregisterUsesPort("ppf");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.tests.Mesh2: Error calling unregisterUsesPort("
              << "\"ppf\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(pde.tests.Mesh2.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.tests.Mesh2.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::tests::Mesh2_impl::boccaForceUsePortInclude_impl (
  /* in */::pde::MeshSource dummy0,
  /* in */::pde::RenderPort dummy1,
  /* in */::gov::cca::ports::ParameterPortFactory dummy2 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.tests.Mesh2.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.tests.Mesh2.boccaForceUsePortInclude)
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;

  // Bocca generated code. bocca.protected.end(pde.tests.Mesh2.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.tests.Mesh2.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
pde::tests::Mesh2_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.tests.Mesh2.setServices)

  // Insert-UserCode-Here{pde.tests.Mesh2.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(pde.tests.Mesh2.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(pde.tests.Mesh2.setServices)
  
  // Insert-UserCode-Here{pde.tests.Mesh2.setServices:epilog}

  // DO-NOT-DELETE splicer.end(pde.tests.Mesh2.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
pde::tests::Mesh2_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.tests.Mesh2.releaseServices)

  // Insert-UserCode-Here {pde.tests.Mesh2.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(pde.tests.Mesh2.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(pde.tests.Mesh2.releaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.tests.Mesh2.releaseServices)
}

/**
 *  
 * Execute some encapsulated functionality on the component. 
 * Return 0 if ok, -1 if internal error but component may be 
 * used further, and -2 if error so severe that component cannot
 * be further used safely.
 */
int32_t
pde::tests::Mesh2_impl::go_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.tests.Mesh2.go)
// User editable portion is in the middle at the next Insert-UserCode-Here line.


// Bocca generated code. bocca.protected.begin(pde.tests.Mesh2.go:boccaGoProlog)
  int bocca_status = 0;
  // The user's code should set bocca_status 0 if computation proceeded ok.
  // The user's code should set bocca_status -1 if computation failed but might
  // succeed on another call to go(), e.g. when a required port is not yet 
  // connected.
  // The user's code should set bocca_status -2 if the computation failed and 
  // can never succeed in a future call.
  // The user's code should NOT use return in this function.
  // Exceptions that are not caught in user code will be converted to 
  // status -2.

  gov::cca::Port port;

  // nil if not fetched and cast successfully:
  pde::MeshSource mesher; 
  // True when releasePort is needed (even if cast fails):
  bool mesher_fetched = false; 
  // nil if not fetched and cast successfully:
  gov::cca::ports::ParameterPortFactory ppf; 
  // True when releasePort is needed (even if cast fails):
  bool ppf_fetched = false; 
  // nil if not fetched and cast successfully:
  pde::RenderPort output; 
  // True when releasePort is needed (even if cast fails):
  bool output_fetched = false; 
  // Use a pde.MeshSource port with port name mesher 
  try{
    port = this->d_services.getPort("mesher");
  } catch ( ::gov::cca::CCAException ex )  {
    // we will continue with port nil (never successfully assigned) and 
    // set a flag.

#ifdef _BOCCA_STDERR
    std::cerr << "pde.tests.Mesh2: Error calling getPort(\"mesher\") "
              " at " << __FILE__ << ":" << __LINE__ -5 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }
  if ( port._not_nil() ) {
    // even if the next cast fails, must release.
    mesher_fetched = true; 
    mesher = ::babel_cast< pde::MeshSource >(port);
    if (mesher._is_nil()) {

#ifdef _BOCCA_STDERR
      std::cerr << "pde.tests.Mesh2: Error casting gov::cca::Port "
                << "mesher to type "
                << "pde::MeshSource" << std::endl;
#endif //_BOCCA_STDERR

      goto BOCCAEXIT; // we cannot correctly continue. clean up and leave.
    } 
  } 

  // Use a gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    port = this->d_services.getPort("ppf");
  } catch ( ::gov::cca::CCAException ex )  {
    // we will continue with port nil (never successfully assigned) and 
    // set a flag.

#ifdef _BOCCA_STDERR
    std::cerr << "pde.tests.Mesh2: Error calling getPort(\"ppf\") "
              " at " << __FILE__ << ":" << __LINE__ -5 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }
  if ( port._not_nil() ) {
    // even if the next cast fails, must release.
    ppf_fetched = true; 
    ppf = ::babel_cast< gov::cca::ports::ParameterPortFactory >(port);
    if (ppf._is_nil()) {

#ifdef _BOCCA_STDERR
      std::cerr << "pde.tests.Mesh2: Error casting gov::cca::Port "
                << "ppf to type "
                << "gov::cca::ports::ParameterPortFactory" << std::endl;
#endif //_BOCCA_STDERR

      goto BOCCAEXIT; // we cannot correctly continue. clean up and leave.
    } 
  } 

  // Use a pde.RenderPort port with port name output 
  try{
    port = this->d_services.getPort("output");
  } catch ( ::gov::cca::CCAException ex )  {
    // we will continue with port nil (never successfully assigned) and 
    // set a flag.

#ifdef _BOCCA_STDERR
    std::cerr << "pde.tests.Mesh2: Error calling getPort(\"output\") "
              " at " << __FILE__ << ":" << __LINE__ -5 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }
  if ( port._not_nil() ) {
    // even if the next cast fails, must release.
    output_fetched = true; 
    output = ::babel_cast< pde::RenderPort >(port);
    if (output._is_nil()) {

#ifdef _BOCCA_STDERR
      std::cerr << "pde.tests.Mesh2: Error casting gov::cca::Port "
                << "output to type "
                << "pde::RenderPort" << std::endl;
#endif //_BOCCA_STDERR

      goto BOCCAEXIT; // we cannot correctly continue. clean up and leave.
    } 
  } 


// Bocca generated code. bocca.protected.end(pde.tests.Mesh2.go:boccaGoProlog)



  // When this try/catch block is rewritten by the user, we will not change it.
  try {


        if (mesher._is_nil()) {
                BOCCA_THROW_CXX(sidl::SIDLException, "port mesher not connected");
        }
        if (output._is_nil()) {
                BOCCA_THROW_CXX(sidl::SIDLException, "port output not connected");
        }

        std::cout << "pde.tests.Mesh2 STARTING" << std::endl;
        pde::Mesh m = mesher.createMesh();
        sidl::array< int32_t > shape = sidl::array< int32_t >::create1d(2);
	sidl::array< double > distances = sidl::array< double >::create1d(2);
        shape.set(0,12);
	shape.set(1,12);
	distances.set(0,3);
	distances.set(1,3);
        std::cout << "pde.tests.Mesh2 configure" << std::endl;
        m.configure( 2, pde::MeshColl_CENTERS, 1, shape, distances, 1, 0, 0);
        std::cout << "pde.tests.Mesh2 compose" << std::endl;
        m.compose1(5);
        std::cout << "dest is pde.tests.Mesh2.out" << std::endl;
        output.setOutput("pde.tests.Mesh2.out");
        std::cout << "show" << std::endl;
        output.showMesh(m);
        std::cout << "dest is pde.tests.Mesh2.out" << std::endl;

	pde::BoundaryCondition nilBC; // uninitialized bc computation will be silently ignored.
        pde::FieldVar fv = m.createFieldVar("temperature", 1, pde::MeshColl_CENTERS, nilBC);
        sidl::array< double > data;
        int32_t top, patchcount;

        for (int32_t ip = 0; ip < fv.getRegionCount(); ip++) {
                data = fv.getData(0, ip);
                top = data.upper(0);
                for (int k = data.lower(0); k <= top; k++) {
                        data.set(k, 10000*ip + k);
                }
        }
        std::cout << "dest is pde.tests.Mesh2.fields.out" << std::endl;
        output.setOutput("pde.tests.Mesh2.fields.out");
        std::cout << "showfields" << std::endl;
        output.showField(m,fv);
        std::cout << "dest is pde.tests.Mesh2.fields.out" << std::endl;

        bocca_status = 0;

  } 
  // If unknown exceptions in the user code are tolerable and restart is ok, 
  // return -1 instead. -2 means the component is so confused that it and 
  // probably the application should be destroyed.
  catch (sidl::SIDLException ex) {
    bocca_status = -2;
    std::string enote = ex.getNote();

#ifdef _BOCCA_STDERR
    std::cerr << "SIDLException in user go code: " << enote << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;;
#endif

  }
  catch (sidl::BaseException ex) {
    bocca_status = -2;
    std::string enote = ex.getNote();

#ifdef _BOCCA_STDERR
    std::cerr << "Exception in user go code: " << enote << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;;
#endif

  }
  catch (std::exception ex) {
    bocca_status = -2;

#ifdef _BOCCA_STDERR
    std::cerr << "C++ exception in user go code: " << ex.what() << std::endl;
    std::cerr << "Returning -2 from go()"  << std::endl;
#endif

  }
  catch (...) {
    bocca_status = -2;

#ifdef _BOCCA_STDERR
    std::cerr << "Odd exception in user go code " << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;
#endif

  }


  BOCCAEXIT:; // target point for error and regular cleanup. do not delete.
// Bocca generated code. bocca.protected.begin(pde.tests.Mesh2.go:boccaGoEpilog)

  // release mesher 
  if (mesher_fetched) {
    mesher_fetched = false;
    try{
      this->d_services.releasePort("mesher");
    } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
      std::cerr << "pde.tests.Mesh2: Error calling releasePort("
                << "\"mesher\") at " 
                << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
                << std::endl;
#endif // _BOCCA_STDERR

    }
    // c++ port reference will be dropped when function exits, but we 
    // must tell framework.
  }

  // release ppf 
  if (ppf_fetched) {
    ppf_fetched = false;
    try{
      this->d_services.releasePort("ppf");
    } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
      std::cerr << "pde.tests.Mesh2: Error calling releasePort("
                << "\"ppf\") at " 
                << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
                << std::endl;
#endif // _BOCCA_STDERR

    }
    // c++ port reference will be dropped when function exits, but we 
    // must tell framework.
  }

  // release output 
  if (output_fetched) {
    output_fetched = false;
    try{
      this->d_services.releasePort("output");
    } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
      std::cerr << "pde.tests.Mesh2: Error calling releasePort("
                << "\"output\") at " 
                << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
                << std::endl;
#endif // _BOCCA_STDERR

    }
    // c++ port reference will be dropped when function exits, but we 
    // must tell framework.
  }


  return bocca_status;
// Bocca generated code. bocca.protected.end(pde.tests.Mesh2.go:boccaGoEpilog)

    
    
  // DO-NOT-DELETE splicer.end(pde.tests.Mesh2.go)
}


// DO-NOT-DELETE splicer.begin(pde.tests.Mesh2._misc)
// Insert-Code-Here {pde.tests.Mesh2._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(pde.tests.Mesh2._misc)

