// 
// File:          pde_Reaction_Impl.hxx
// Symbol:        pde.Reaction-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.Reaction
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_pde_Reaction_Impl_hxx
#define included_pde_Reaction_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_pde_Reaction_IOR_h
#include "pde_Reaction_IOR.h"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Component_hxx
#include "gov_cca_Component.hxx"
#endif
#ifndef included_gov_cca_ComponentRelease_hxx
#include "gov_cca_ComponentRelease.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_ParameterPortFactory_hxx
#include "gov_cca_ports_ParameterPortFactory.hxx"
#endif
#ifndef included_pde_MeshColl_hxx
#include "pde_MeshColl.hxx"
#endif
#ifndef included_pde_NamedPatchPort_hxx
#include "pde_NamedPatchPort.hxx"
#endif
#ifndef included_pde_Reaction_hxx
#include "pde_Reaction.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif


// DO-NOT-DELETE splicer.begin(pde.Reaction._includes)
// Insert-Code-Here {pde.Reaction._includes} (includes or arbitrary code)
// DO-NOT-DELETE splicer.end(pde.Reaction._includes)

namespace pde { 

  /**
   * Symbol "pde.Reaction" (version 0.0)
   */
  class Reaction_impl : public virtual ::pde::Reaction 
  // DO-NOT-DELETE splicer.begin(pde.Reaction._inherits)
  // Insert-Code-Here {pde.Reaction._inherits} (optional inheritance here)
  // DO-NOT-DELETE splicer.end(pde.Reaction._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

  // DO-NOT-DELETE splicer.begin(pde.Reaction._implementation)

  // Insert-UserCode-Here(pde.Reaction._implementation)

  // Bocca generated code. bocca.protected.begin(pde.Reaction._implementation)
  
   gov::cca::Services    d_services; // our cca handle.
 

  // Bocca generated code. bocca.protected.end(pde.Reaction._implementation)
      double qConstant_ ;
      double fConstant_ ;
      double epsilon_  ;
      int d_stencil_radius ;

  // DO-NOT-DELETE splicer.end(pde.Reaction._implementation)

  public:
    // default constructor, used for data wrapping(required)
    Reaction_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    Reaction_impl( struct pde_Reaction__object * s ) : StubBase(s,true), 
      _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~Reaction_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    void
    boccaSetServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;

    /**
     * user defined non-static method.
     */
    void
    boccaReleaseServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;


    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude_impl (
      /* in */::gov::cca::ports::ParameterPortFactory dummy0
    )
    ;


    /**
     *  Starts up a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning services and setServices:
     * 
     * The component interaction with the CCA framework
     * and Ports begins on the call to setServices by the framework.
     * 
     * This function is called exactly once for each instance created
     * by the framework.
     * 
     * The argument services will never be nil/null.
     * 
     * Those uses ports which are automatically connected by the framework
     * (so-called service-ports) may be obtained via getPort during
     * setServices.
     */
    void
    setServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;


    /**
     * Shuts down a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning services and setServices:
     * 
     * This function is called exactly once for each callback registered
     * through Services.
     * 
     * The argument services will never be nil/null.
     * The argument services will always be the same as that received in
     * setServices.
     * 
     * During this call the component should release any interfaces
     * acquired by getPort().
     * 
     * During this call the component should reset to nil any stored
     * reference to services.
     * 
     * After this call, the component instance will be removed from the
     * framework. If the component instance was created by the
     * framework, it will be destroyed, not recycled, The behavior of
     * any port references obtained from this component instance and
     * stored elsewhere becomes undefined.
     * 
     * Notes for the component implementor:
     * 1) The component writer may perform blocking activities
     * within releaseServices, such as waiting for remote computations
     * to shutdown.
     * 2) It is good practice during releaseServices for the component
     * writer to remove or unregister all the ports it defined.
     */
    void
    releaseServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;

    /**
     * user defined non-static method.
     */
    int32_t
    setData_impl (
      /* in */int32_t ndim,
      /* in array<double> */::sidl::array<double> dataNamed,
      /* in array<int> */::sidl::array<int32_t> lowerCorner,
      /* in array<int> */::sidl::array<int32_t> upperCorner,
      /* in array<int> */::sidl::array<int32_t> shape,
      /* in */int32_t nvars,
      /* in */::pde::MeshColl mc,
      /* in */const ::std::string& name
    )
    ;

    /**
     * user defined non-static method.
     */
    int32_t
    compute_impl (
      /* in */int32_t ndim,
      /* in array<double> */::sidl::array<double> data1,
      /* in array<int> */::sidl::array<int32_t> lowerCorner,
      /* in array<int> */::sidl::array<int32_t> upperCorner,
      /* in array<int> */::sidl::array<int32_t> shape,
      /* in */int32_t nvars,
      /* in */::pde::MeshColl mc,
      /* inout array<double> */::sidl::array<double>& data2
    )
    ;


    /**
     * Set extra data for processing several patches of the same sort.
     * @param boundaryWidth something
     * @param stencil_radius something else
     * @param meshShape mesh size in each dimension (excludes boundaries).
     * @param delta grid spacing in each dimension (uniform cell size assumed).
     */
    int32_t
    setComputeInfoUniform_impl (
      /* in */int32_t boundaryWidth,
      /* in */int32_t stencil_radius,
      /* in array<int> */::sidl::array<int32_t> meshShape,
      /* in array<double> */::sidl::array<double> delta
    )
    ;


    /**
     * A method to indicate that all state set by set can now be forgotten 
     */
    void
    clearData_impl() ;
  };  // end class Reaction_impl

} // end namespace pde

// DO-NOT-DELETE splicer.begin(pde.Reaction._misc)
// Insert-Code-Here {pde.Reaction._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(pde.Reaction._misc)

#endif
