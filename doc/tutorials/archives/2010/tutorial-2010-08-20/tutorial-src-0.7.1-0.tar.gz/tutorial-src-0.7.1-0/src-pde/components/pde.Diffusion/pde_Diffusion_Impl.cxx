// 
// File:          pde_Diffusion_Impl.cxx
// Symbol:        pde.Diffusion-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.Diffusion
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_Diffusion_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_bsl_arr_hxx
#include "bsl_arr.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_ParameterPortFactory_hxx
#include "gov_cca_ports_ParameterPortFactory.hxx"
#endif
#ifndef included_pde_MeshColl_hxx
#include "pde_MeshColl.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.Diffusion._includes)

#include "bsl_arr.hxx"

  // Bocca generated code. bocca.protected.begin(pde.Diffusion._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.Diffusion._includes)

  // Insert-UserCode-Here {pde.Diffusion._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.Diffusion._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::Diffusion_impl::Diffusion_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::Diffusion::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(pde.Diffusion._ctor2)
  // Insert-Code-Here {pde.Diffusion._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.Diffusion._ctor2)
}

// user defined constructor
void pde::Diffusion_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.Diffusion._ctor)
    
  // Insert-UserCode-Here {pde.Diffusion._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(pde.Diffusion._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.Diffusion: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.Diffusion._ctor)

        d_boundaryWidth = 0;
        d_stencil_radius = 0;
	diffusion_coefficient = 1.0e-2;
	dataset = false;

  // DO-NOT-DELETE splicer.end(pde.Diffusion._ctor)
}

// user defined destructor
void pde::Diffusion_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.Diffusion._dtor)
  // Insert-UserCode-Here {pde.Diffusion._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.Diffusion._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.Diffusion: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.Diffusion._dtor) 

  // DO-NOT-DELETE splicer.end(pde.Diffusion._dtor)
}

// static class initializer
void pde::Diffusion_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.Diffusion._load)
  // Insert-Code-Here {pde.Diffusion._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.Diffusion._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
pde::Diffusion_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.Diffusion.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.Diffusion.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "pde.Diffusion: Error casting self to gov::cca::Port");
  } 


  // Provide a pde.NamedPatchPort port with port name diffusion 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "diffusion", // port instance name
                   "pde.NamedPatchPort",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "pde.Diffusion: Error calling addProvidesPort(port,"
        "\"diffusion\", \"pde.NamedPatchPort\", typeMap) ", -2);
    throw;
  }    

  // Use a gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    this->d_services.registerUsesPort(
                   "ppf", // port instance name
                   "gov.cca.ports.ParameterPortFactory",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.Diffusion: Error calling registerUsesPort(\"ppf\", "
       "\"gov.cca.ports.ParameterPortFactory\", typeMap) ", -2);
    throw;
  }


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(pde.Diffusion.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(pde.Diffusion.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
pde::Diffusion_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.Diffusion.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.Diffusion.boccaReleaseServices)
  this->d_services=0;


  // Un-provide pde.NamedPatchPort port with port name diffusion 
  try{
    services.removeProvidesPort("diffusion");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.Diffusion: Error calling removeProvidesPort("
              << "\"diffusion\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    services.unregisterUsesPort("ppf");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.Diffusion: Error calling unregisterUsesPort("
              << "\"ppf\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(pde.Diffusion.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.Diffusion.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::Diffusion_impl::boccaForceUsePortInclude_impl (
  /* in */::gov::cca::ports::ParameterPortFactory dummy0,
  /* in */::bsl::arr dummy1 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.Diffusion.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.Diffusion.boccaForceUsePortInclude)
    (void)dummy0;
    (void)dummy1;

  // Bocca generated code. bocca.protected.end(pde.Diffusion.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.Diffusion.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
pde::Diffusion_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.Diffusion.setServices)

  // Insert-UserCode-Here{pde.Diffusion.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(pde.Diffusion.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(pde.Diffusion.setServices)
  
  // Insert-UserCode-Here{pde.Diffusion.setServices:epilog}

  // DO-NOT-DELETE splicer.end(pde.Diffusion.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
pde::Diffusion_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.Diffusion.releaseServices)

  // Insert-UserCode-Here {pde.Diffusion.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(pde.Diffusion.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(pde.Diffusion.releaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.Diffusion.releaseServices)
}

/**
 * Method:  setData[]
 */
int32_t
pde::Diffusion_impl::setData_impl (
  /* in */int32_t ndim,
  /* in array<double> */::sidl::array<double> dataNamed,
  /* in array<int> */::sidl::array<int32_t> lowerCorner,
  /* in array<int> */::sidl::array<int32_t> upperCorner,
  /* in array<int> */::sidl::array<int32_t> shape,
  /* in */int32_t nvars,
  /* in */::pde::MeshColl mc,
  /* in */const ::std::string& name ) 
{
  // DO-NOT-DELETE splicer.begin(pde.Diffusion.setData)
	// nothing to do;
	return 0;
  // DO-NOT-DELETE splicer.end(pde.Diffusion.setData)
}

/**
 * Method:  compute[]
 */
int32_t
pde::Diffusion_impl::compute_impl (
  /* in */int32_t ndim,
  /* in array<double> */::sidl::array<double> data1,
  /* in array<int> */::sidl::array<int32_t> lowerCorner,
  /* in array<int> */::sidl::array<int32_t> upperCorner,
  /* in array<int> */::sidl::array<int32_t> shape,
  /* in */int32_t nvars,
  /* in */::pde::MeshColl mc,
  /* inout array<double> */::sidl::array<double>& data2 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.Diffusion.compute)

    int32_t nx = 1, ny = 1, nz = 1;
    int32_t starti = 0, endi = 1, startj = 0, endj = 1, startk = 0, endk = 1;
    double dx = 1, dy = 1, dz = 1;
    
    starti = d_stencil_radius; endi = shape[0] - d_stencil_radius; dx = d_delta[0] ; nx = shape[0] ;

    if ( ndim > 1) 
    { 
	startj = d_stencil_radius ; endj = shape[1] - d_stencil_radius ; dy = d_delta[1] ; 
	ny = shape[1]; 
    }

    if ( ndim > 2) 
    { 
	startk = d_stencil_radius ; endk = shape[2] - d_stencil_radius ; dz = d_delta[2] ; 
	nz = shape[2]; 
    }

    // Now loop over all variables and diffuse
    int32_t line = nx ;
    int32_t slab = nx*ny ;
    int32_t vol  = nx*ny*nz ;

    for(int ivar = 0; ivar < nvars; ivar++)
    {
	for (int k = startk; k < endk; k++)
	{
	    for (int j = startj; j < endj ; j++)
	    {
		for (int i = starti; i < endi; i++)
		{
		    int index = i + nx*j + slab*k + vol*ivar ;
		    
		    int ip1 = (i+1) + nx*j + slab*k + vol*ivar ;
		    int im1 = (i-1) + nx*j + slab*k + vol*ivar ;

		    int jp1 = 0, jm1 = 0;
		    if (ndim > 1)
		    {
			jp1 = i + nx*(j+1) + slab*k + vol*ivar ;
		        jm1 = i + nx*(j-1) + slab*k + vol*ivar ;
		    }

		    int kp1 = 0, km1 = 0;
		    if (ndim > 2)
		    {
			kp1 = i + nx*j + slab*(k+1) + vol*ivar ;
		        km1 = i + nx*j + slab*(k-1) + vol*ivar ;
		    }

		    double termx = diffusion_coefficient * (data1[ip1] - 2*data1[index] + data1[im1]) / (dx*dx) ;
		    double termy = diffusion_coefficient * (data1[jp1] - 2*data1[index] + data1[jm1]) / (dy*dy) ;
		    double termz = diffusion_coefficient * (data1[kp1] - 2*data1[index] + data1[km1]) / (dz*dz) ;

		    data2.set(index, (termx + termy + termz) ) ;
		} // end of loop over i
	    } // end of loop over j
	} // end of loop over k
    } // end of loop over ivars ;


  // DO-NOT-DELETE splicer.end(pde.Diffusion.compute)
}

/**
 * Set extra data for processing several patches of the same sort.
 * @param boundaryWidth something
 * @param stencil_radius something else
 * @param meshShape mesh size in each dimension (excludes boundaries).
 * @param delta grid spacing in each dimension (uniform cell size assumed).
 */
int32_t
pde::Diffusion_impl::setComputeInfoUniform_impl (
  /* in */int32_t boundaryWidth,
  /* in */int32_t stencil_radius,
  /* in array<int> */::sidl::array<int32_t> meshShape,
  /* in array<double> */::sidl::array<double> delta ) 
{
  // DO-NOT-DELETE splicer.begin(pde.Diffusion.setComputeInfoUniform)
        d_boundaryWidth = boundaryWidth;
        d_stencil_radius = stencil_radius;
        d_meshShape = bsl::arr::cloneInt1(meshShape);
        d_delta = bsl::arr::cloneDouble1(delta);
	dataset = true;
  // DO-NOT-DELETE splicer.end(pde.Diffusion.setComputeInfoUniform)
}

/**
 * A method to indicate that all state set by set can now be forgotten 
 */
void
pde::Diffusion_impl::clearData_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.Diffusion.clearData)
	dataset = false;
  // DO-NOT-DELETE splicer.end(pde.Diffusion.clearData)
}


// DO-NOT-DELETE splicer.begin(pde.Diffusion._misc)
// Insert-Code-Here {pde.Diffusion._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(pde.Diffusion._misc)

