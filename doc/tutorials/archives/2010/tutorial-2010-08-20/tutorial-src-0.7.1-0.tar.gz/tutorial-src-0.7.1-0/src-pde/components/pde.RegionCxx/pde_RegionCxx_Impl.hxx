// 
// File:          pde_RegionCxx_Impl.hxx
// Symbol:        pde.RegionCxx-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.RegionCxx
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_pde_RegionCxx_Impl_hxx
#define included_pde_RegionCxx_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_pde_RegionCxx_IOR_h
#include "pde_RegionCxx_IOR.h"
#endif
#ifndef included_bsl_arr_hxx
#include "bsl_arr.hxx"
#endif
#ifndef included_pde_BoundPos_hxx
#include "pde_BoundPos.hxx"
#endif
#ifndef included_pde_MeshColl_hxx
#include "pde_MeshColl.hxx"
#endif
#ifndef included_pde_Patch_hxx
#include "pde_Patch.hxx"
#endif
#ifndef included_pde_Region_hxx
#include "pde_Region.hxx"
#endif
#ifndef included_pde_RegionCxx_hxx
#include "pde_RegionCxx.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(pde.RegionCxx._includes)
// Insert-Code-Here {pde.RegionCxx._includes} (includes or arbitrary code)
// DO-NOT-DELETE splicer.end(pde.RegionCxx._includes)

namespace pde { 

  /**
   * Symbol "pde.RegionCxx" (version 0.0)
   */
  class RegionCxx_impl : public virtual ::pde::RegionCxx 
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx._inherits)
  // Insert-Code-Here {pde.RegionCxx._inherits} (optional inheritance here)
  // DO-NOT-DELETE splicer.end(pde.RegionCxx._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(pde.RegionCxx._implementation)
    pde::Patch patch;
    std::vector< sidl::array<double> > timeslices;
    sidl::array< int32_t > firstAll;
    sidl::array< int32_t > lastAll;
    sidl::array< int32_t > shapeAll;
    int32_t volume;
    int32_t tl, th, tcur;

    int32_t timeZeroed(int32_t t) {
	t = t - tcur; // shift to tcur centered axis
        if (t < tl || t > th) {
            return -1; // should cause a later error
        }
	return t - tl;  // shift to axis with 0 at tl
    }
               
    // DO-NOT-DELETE splicer.end(pde.RegionCxx._implementation)

  public:
    // default constructor, used for data wrapping(required)
    RegionCxx_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    RegionCxx_impl( struct pde_RegionCxx__object * s ) : StubBase(s,true), 
      _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~RegionCxx_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    void
    init_impl (
      /* in */::pde::Patch p,
      /* in */int32_t sstencil,
      /* in */int32_t bwidth,
      /* in */int32_t nvars,
      /* in */::pde::MeshColl T,
      /* in */int32_t tlo,
      /* in */int32_t thi
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    finalize_impl() ;
    /**
     * user defined non-static method.
     */
    int32_t
    computeDataSize_impl (
      /* in */::pde::Patch p,
      /* in */int32_t sstencil,
      /* in */int32_t bwidth,
      /* in */int32_t nvars,
      /* in */::pde::MeshColl T
    )
    ;


    /**
     *  return the range within the source patch that overlaps this region and its ghost cells.
     * @return false if no overlap, true if overlap.
     */
    bool
    computeOverlap_impl (
      /* in */::pde::Patch source,
      /* inout rarray[d] */int32_t* windowLowerCorner,
      /* inout rarray[d] */int32_t* windowUpperCorner,
      /* in */int32_t d
    )
    ;


    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude_impl (
      /* in */::pde::MeshColl dummy0,
      /* in */::pde::Patch dummy1,
      /* in */::pde::BoundPos dummy2,
      /* in */::bsl::arr dummy3
    )
    ;

    /**
     * user defined non-static method.
     */
    ::sidl::array<int32_t>
    getLowerCorner_impl() ;

    /**
     *  
     * @return upper bounding box corner of the regionId given.
     * result array will be getDimension() long.
     */
    ::sidl::array<int32_t>
    getUpperCorner_impl() ;

    /**
     *  @return  array 'dimension' long with sizes in X,Y,Z directions. 
     */
    ::sidl::array<int32_t>
    getShape_impl() ;

    /**
     *  
     * @return 1d array with size the product of getShape()[i] for all i=[0.dim-1].
     */
    ::sidl::array<double>
    getData_impl (
      /* in */int32_t time
    )
    ;


    /**
     *  return the underlying mesh geometry section. 
     */
    ::pde::Patch
    getPatch_impl() ;

    /**
     *  left rotate the array. yea verily, the first shall become last. 
     */
    void
    cycletimes_impl() ;
    /**
     * user defined non-static method.
     */
    void
    setCurrentTime_impl (
      /* in */int32_t time
    )
    ;

  };  // end class RegionCxx_impl

} // end namespace pde

// DO-NOT-DELETE splicer.begin(pde.RegionCxx._misc)
// Insert-Code-Here {pde.RegionCxx._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(pde.RegionCxx._misc)

#endif
