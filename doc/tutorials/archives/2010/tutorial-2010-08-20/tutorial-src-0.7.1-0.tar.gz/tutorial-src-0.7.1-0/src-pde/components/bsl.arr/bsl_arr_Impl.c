/*
 * File:          bsl_arr_Impl.c
 * Symbol:        bsl.arr-v0.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for bsl.arr
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "bsl.arr" (version 0.0)
 */

#include "bsl_arr_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"

/* DO-NOT-DELETE splicer.begin(bsl.arr._includes) */


/** The arrays are passed in by reference here, this function increased
 *  the indicies, until it goes over the end of the array, it then returns
 *   false.
 */

static int
next(const int dimen, int32_t ind[],
     const int32_t lower[], const int32_t upper[])
{
  int i = 0;
  while ((i < dimen) && (++(ind[i]) > upper[i])) {
    ind[i] = lower[i];
    ++i;
  }
  return i < dimen;

}

#define sidl_int int32_t
#define sidl_long int64_t
#define sidl_float float
#define sidl_double double
#define sidl_opaque void *

/* Bocca generated code. bocca.protected.begin(bsl.arr._includes) */
#include <stdlib.h>
#include <string.h>
#include "sidl_SIDLException.h"

#define _BOCCA_CTOR_MESSAGES 0

#ifdef _BOCCA_STDERR

#define BOCCA_FPRINTF fprintf
#include <stdio.h>
#include "sidl_String.h"
#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif /* _BOCCA_CTOR_PRINT */

#else /* _BOCCA_STDERR */
#define BOCCA_FPRINTF boccaPrintNothing
#endif /* _BOCCA_STDERR */

static int
boccaPrintNothing(void *v, const char * s, ...)
{
  (void)v; (void)s;
  return 0;
}
/* Bocca generated code. bocca.protected.end(bsl.arr._includes) */

/* Insert-UserCode-Here {bsl.arr._includes} (includes and arbitrary code) */

/* DO-NOT-DELETE splicer.end(bsl.arr._includes) */

#define SIDL_IOR_MAJOR_VERSION 1
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr._load) */
	(void)_ex;
    /* DO-NOT-DELETE splicer.end(bsl.arr._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr__ctor(
  /* in */ bsl_arr self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(bsl.arr._ctor) */

  /* Insert-UserDecl-Here {bsl.arr._ctor} (constructor method) */
    
  /* bocca-default-code. User may edit or delete.begin(bsl.arr._ctor) */
   struct bsl_arr__data *dptr = 
                (struct bsl_arr__data*)malloc(sizeof(struct bsl_arr__data));
   if (dptr) {
      memset(dptr, 0, sizeof(struct bsl_arr__data));
   }
   bsl_arr__set_data(self, dptr);
   #if _BOCCA_CTOR_MESSAGES
     BOCCA_FPRINTF(stderr, "CTOR bsl.arr: %s constructed data %p in self %p\n", __FUNC__, dptr, self);
   #endif /* _BOCCA_CTOR_MESSAGES */
  /* bocca-default-code. User may edit or delete.end(bsl.arr._ctor) */

  /* initialize user elements of dptr here */
  /* Insert-UserCode-Here {bsl.arr._ctor} (constructor method) */

  /* DO-NOT-DELETE splicer.end(bsl.arr._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr__ctor2(
  /* in */ bsl_arr self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr._ctor2) */
    /* Insert-Code-Here {bsl.arr._ctor2} (special constructor method) */
    
    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin() */
    /* 
     * This method has not been implemented.
     */
    SIDL_THROW(*_ex, sidl_SIDLException,     "This method is not expected to be implemented.");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end() */
    
    /* DO-NOT-DELETE splicer.end(bsl.arr._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr__dtor(
  /* in */ bsl_arr self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(bsl.arr._dtor) */

  /* deinitialize user elements of dptr here */
  /* Insert-UserCode-Here {bsl.arr._dtor} (destructor method) */
    
  /* bocca-default-code. User may edit or delete.begin(bsl.arr._dtor) */
   struct bsl_arr__data *dptr = 
                bsl_arr__get_data(self);
   if (dptr) {
      free(dptr);
      bsl_arr__set_data(self, NULL);
   }
   #if _BOCCA_CTOR_MESSAGES
     BOCCA_FPRINTF(stderr, "DTOR bsl.arr: %s freed data %p in self %p\n", __FUNC__, dptr, self);
   #endif /* _BOCCA_CTOR_MESSAGES */
  /* bocca-default-code. User may edit or delete.end(bsl.arr._dtor) */

  /* DO-NOT-DELETE splicer.end(bsl.arr._dtor) */
  }
}

/*
 * Method:  str[]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_str"

#ifdef __cplusplus
extern "C"
#endif
char*
impl_bsl_arr_str(
  /* in array<> */ struct sidl__array* a,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.str) */
	int32_t atype, i, k, dim, slen;

	if (a == NULL ) { 
		return sidl_String_strdup("null"); 
	} 
	atype = sidl__array_type(a);
	char * result = NULL;
/*
  sidl_char_array      = 2,
  sidl_dcomplex_array  = 3,
  sidl_double_array    = 4,
  sidl_fcomplex_array  = 5,
  sidl_float_array     = 6,
  sidl_int_array       = 7,
  sidl_long_array      = 8,
  sidl_opaque_array    = 9,
*/
#define STR_CASE(scalartype) \
case sidl_## scalartype ##_array: \
	{ \
		struct sidl_ ## scalartype ## __array *p ## scalartype; \
		p ## scalartype = (struct sidl_ ## scalartype ## __array *)(a); \
		result = bsl_arrx_sfrom##scalartype( p ## scalartype, _ex ); \
	} \
	break

	switch (atype) {
	/* STR_CASE(opaque); */
	STR_CASE(bool);
	STR_CASE(int);
	STR_CASE(long);
	STR_CASE(float);
	STR_CASE(double);
	STR_CASE(fcomplex);
	STR_CASE(dcomplex);
	default:
		SIDL_THROW(*_ex, sidl_SIDLException, "Unsupported array type in bsl.arr.str");
		break;
	}
#undef STR_CASE
EXIT:
	return result;
	
    /* DO-NOT-DELETE splicer.end(bsl.arr.str) */
  }
}

/*
 * Method:  toString[]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_toString"

#ifdef __cplusplus
extern "C"
#endif
char*
impl_bsl_arr_toString(
  /* in array<> */ struct sidl__array* a,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.toString) */
	return  impl_bsl_arr_str(a, _ex);
    /* DO-NOT-DELETE splicer.end(bsl.arr.toString) */
  }
}

/*
 * Method:  toStringC[]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_toStringC"

#ifdef __cplusplus
extern "C"
#endif
char*
impl_bsl_arr_toStringC(
  /* in */ void* dataPointer,
  /* in */ int32_t dataLen,
  /* in */ enum bsl_datatype__enum dt,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.toStringC) */
	char * result = sidl_String_strdup("(" __FUNC__ ": not implemented yet.)");
	return result; /*FIXME bsl.arr.toStringC*/
    /* DO-NOT-DELETE splicer.end(bsl.arr.toStringC) */
  }
}

/*
 * Method:  fill[Bool]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_fillBool"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_fillBool(
  /* inout array<> */ struct sidl__array** a,
  /* in */ sidl_bool value,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.fillBool) */
/* use this with, e.g. bool as argument. */
#define FILL_GENERIC(scalartype) \
	int32_t atype, i, dim; \
	int32_t lower[7] = { 0, 0, 0, 0, 0, 0, 0 }; \
	int32_t upper[7] = { 0, 0, 0, 0, 0, 0, 0 }; \
	int32_t indices[7] = { 0, 0, 0, 0, 0, 0, 0 }; \
	struct sidl_ ## scalartype ## __array * b; \
 \
	if (a == NULL || *a == NULL) { \
		return; \
	} \
	printf("fill" #scalartype ",*> entered."); \
	atype = sidl__array_type(*a); \
	if (atype != sidl_ ## scalartype ## _array) { \
		printf("Argument mismatch: array<" #scalartype ",*> expected."); \
		SIDL_THROW(*_ex, sidl_SIDLException, \
			 "Argument mismatch: array<" #scalartype ",*> expected."); \
	} \
	b = (struct sidl_ ## scalartype ## __array *)(*a); \
	dim = sidl_ ## scalartype ## __array_dimen(b); \
	for (i=0; i < dim; i++) { \
		lower[i] = sidl_ ## scalartype ## __array_lower(b, i); \
		indices[i] = lower[i]; \
		upper[i] = sidl_ ## scalartype ## __array_upper(b, i); \
	} \
	do { \
		sidl_ ## scalartype ## __array_set(b, indices, value); \
	} while ( next(dim, indices, lower, upper) ); \
	 \
	return; \
  EXIT:

	FILL_GENERIC(bool);
    /* DO-NOT-DELETE splicer.end(bsl.arr.fillBool) */
  }
}

/*
 * Method:  fill[Int]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_fillInt"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_fillInt(
  /* inout array<> */ struct sidl__array** a,
  /* in */ int32_t value,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.fillInt) */
	/* bury the common c++ abuses by promoting the type. */
	switch (sidl__array_type(*a) ) {
	case sidl_double_array: {
			double dvalue = value;
			impl_bsl_arr_fillDouble(a, dvalue, _ex);
		}
        break;
	case sidl_float_array: {
			float fvalue = value;
			impl_bsl_arr_fillFloat(a, fvalue, _ex);
		}
        break;
	default: {
			FILL_GENERIC(int);
		}
	}

    /* DO-NOT-DELETE splicer.end(bsl.arr.fillInt) */
  }
}

/*
 * Method:  fill[Long]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_fillLong"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_fillLong(
  /* inout array<> */ struct sidl__array** a,
  /* in */ int64_t value,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.fillLong) */
	FILL_GENERIC(long);
    /* DO-NOT-DELETE splicer.end(bsl.arr.fillLong) */
  }
}

/*
 * Method:  fill[Float]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_fillFloat"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_fillFloat(
  /* inout array<> */ struct sidl__array** a,
  /* in */ float value,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.fillFloat) */
	FILL_GENERIC(float);
    /* DO-NOT-DELETE splicer.end(bsl.arr.fillFloat) */
  }
}

/*
 * Method:  fill[Double]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_fillDouble"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_fillDouble(
  /* inout array<> */ struct sidl__array** a,
  /* in */ double value,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.fillDouble) */
	FILL_GENERIC(double);
    /* DO-NOT-DELETE splicer.end(bsl.arr.fillDouble) */
  }
}

/*
 * Method:  fill[Fcomplex]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_fillFcomplex"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_fillFcomplex(
  /* inout array<> */ struct sidl__array** a,
  /* in */ struct sidl_fcomplex value,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.fillFcomplex) */
	FILL_GENERIC(fcomplex);
    /* DO-NOT-DELETE splicer.end(bsl.arr.fillFcomplex) */
  }
}

/*
 * Method:  fill[Dcomplex]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_fillDcomplex"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_fillDcomplex(
  /* inout array<> */ struct sidl__array** a,
  /* in */ struct sidl_dcomplex value,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.fillDcomplex) */
	FILL_GENERIC(dcomplex);
    /* DO-NOT-DELETE splicer.end(bsl.arr.fillDcomplex) */
  }
}

/*
 * Method:  clone[]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_clone"

#ifdef __cplusplus
extern "C"
#endif
struct sidl__array*
impl_bsl_arr_clone(
  /* in array<> */ struct sidl__array* a,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.clone) */
    /* Insert-Code-Here {bsl.arr.clone} (clone method)  FIXME */
	return NULL; 
    /* DO-NOT-DELETE splicer.end(bsl.arr.clone) */
  }
}

/*
 * Method:  cloneInt1[]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_cloneInt1"

#ifdef __cplusplus
extern "C"
#endif
struct sidl_int__array*
impl_bsl_arr_cloneInt1(
  /* in array<int> */ struct sidl_int__array* a,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.cloneInt1) */
	int32_t lower, upper;
	upper = sidl_int__array_upper(a, 0);
	lower = sidl_int__array_lower(a, 0);
	struct sidl_int__array *p = sidl_int__array_createCol(1, &lower, &upper);
        sidl_int__array_copy(a, p);
	return p;
    /* DO-NOT-DELETE splicer.end(bsl.arr.cloneInt1) */
  }
}

/*
 * Method:  cloneDouble1[]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_cloneDouble1"

#ifdef __cplusplus
extern "C"
#endif
struct sidl_double__array*
impl_bsl_arr_cloneDouble1(
  /* in array<double> */ struct sidl_double__array* a,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.cloneDouble1) */
	int32_t lower, upper;
	upper = sidl_double__array_upper(a, 0);
	lower = sidl_double__array_lower(a, 0);
	struct sidl_double__array *p = sidl_double__array_createCol(1, &lower, &upper);
        sidl_double__array_copy(a, p);
	return p;
    /* DO-NOT-DELETE splicer.end(bsl.arr.cloneDouble1) */
  }
}

/*
 * Method:  loadC[]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_loadC"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_loadC(
  /* inout array<> */ struct sidl__array** a,
  /* in */ void* dataPointer,
  /* in */ int32_t dataLen,
  /* in */ enum bsl_datatype__enum dt,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.loadC) */
	int32_t atype, i, k, dim, slen;
	int32_t lower[7] = { 0, 0, 0, 0, 0, 0, 0 };
	int32_t upper[7] = { 0, 0, 0, 0, 0, 0, 0 };
	int32_t indices[7] = { 0, 0, 0, 0, 0, 0, 0 };
	struct sidl_int__array *pint; sidl_int *dataint;
	struct sidl_long__array *plong; sidl_long *datalong;
	struct sidl_float__array *pfloat; sidl_float *datafloat;
	struct sidl_double__array *pdouble; sidl_double *datadouble;
	struct sidl_fcomplex__array *pfcomplex; struct sidl_fcomplex *datafcomplex;
	struct sidl_dcomplex__array *pdcomplex; struct sidl_dcomplex *datadcomplex;
	struct sidl_opaque__array *popaque; sidl_opaque *dataopaque;

	if (a == NULL || *a == NULL || dataLen < 1) { 
		return; 
	} 
	atype = sidl__array_type(*a);
	dim = sidlArrayDim(*a);
	slen = 1; /* product of all dimen lengths. */
	
	for (i=0; i < dim; i++) {
		lower[i] = sidlLower(*a, i);
		indices[i] = lower[i]; 
		upper[i] = sidlUpper(*a, i); 
		k = upper[i] - lower[i] +1;
		slen *= k;	
	}
	if (slen < 1) { return; }
	k = 0;
	
/*
  sidl_char_array      = 2,
  sidl_dcomplex_array  = 3,
  sidl_double_array    = 4,
  sidl_fcomplex_array  = 5,
  sidl_float_array     = 6,
  sidl_int_array       = 7,
  sidl_long_array      = 8,
  sidl_opaque_array    = 9,
*/
#define LOADC_CASE(scalartype) \
case sidl_## scalartype ##_array: \
	{ \
		struct sidl_ ## scalartype ## __array *p ## scalartype; \
		sidl_ ## scalartype *data ## scalartype; \
		data ## scalartype = (sidl_ ## scalartype *)(dataPointer); \
		p ## scalartype = (struct sidl_ ## scalartype ## __array *)(*a); \
		do { \
			sidl_ ## scalartype ## __array_set(p ## scalartype, indices, data ## scalartype[k]); \
			k++; \
		} while ( k < dataLen && next(dim, indices, lower, upper) );  \
	} \
	break

#define LOADC_CASE_COMPLEX(scalartype) \
case sidl_## scalartype ##_array: \
	{ \
		struct sidl_ ## scalartype ## __array *p ## scalartype; \
		struct sidl_ ## scalartype *data ## scalartypel; \
		data ## scalartype = (struct sidl_ ## scalartype *)(dataPointer); \
		p ## scalartype = (struct sidl_ ## scalartype ## __array *)(*a); \
		do { \
			sidl_ ## scalartype ## __array_set(p ## scalartype, indices, data ## scalartype[k]); \
			k++; \
		} while ( k < dataLen && next(dim, indices, lower, upper) );  \
	} \
	break

	switch (atype) {
	LOADC_CASE(opaque);
	LOADC_CASE(bool);
	LOADC_CASE(int);
	LOADC_CASE(long);
	LOADC_CASE(float);
	LOADC_CASE(double);
	LOADC_CASE_COMPLEX(fcomplex);
	LOADC_CASE_COMPLEX(dcomplex);
	default:
		SIDL_THROW(*_ex, sidl_SIDLException, "Unsupported array type in bsl.arr.loadC");
		break;
	}
	return; 
  EXIT: ;
    
    /* DO-NOT-DELETE splicer.end(bsl.arr.loadC) */
  }
}

/*
 * Method:  load1[Float]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_load1Float"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_load1Float(
  /* inout array<> */ struct sidl__array** a1,
  /* in rarray[m] */ float* values,
  /* in */ int32_t m,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.load1Float) */
#define LOADTYPEDRAW(stype, fname, dim, len, dt) \
	if (sidl__array_type(*a##dim) != stype ## _array) { \
    		SIDL_THROW(*_ex, sidl_SIDLException, fname ": array type mismatch."); \
	} \
	if (sidl__array_dimen(*a##dim) != dim) { \
    		SIDL_THROW(*_ex, sidl_SIDLException, fname ": shape mismatch"); \
	} \
	bsl_arr_loadC(a##dim, (void*)values, len, dt, _ex); \
EXIT:

	LOADTYPEDRAW(sidl_float, __FUNC__, 1, m, bsl_datatype_floatArray);
    
    /* DO-NOT-DELETE splicer.end(bsl.arr.load1Float) */
  }
}

/*
 * Method:  load2[Float]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_load2Float"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_load2Float(
  /* inout array<> */ struct sidl__array** a2,
  /* in rarray[m,n] */ float* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.load2Float) */
	LOADTYPEDRAW(sidl_float, __FUNC__, 2, m*n, bsl_datatype_floatArray);
    /* DO-NOT-DELETE splicer.end(bsl.arr.load2Float) */
  }
}

/*
 * Method:  load3[Float]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_load3Float"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_load3Float(
  /* inout array<> */ struct sidl__array** a3,
  /* in rarray[m,n,p] */ float* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* in */ int32_t p,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.load3Float) */
	LOADTYPEDRAW(sidl_float, __FUNC__, 3, m*n*p, bsl_datatype_floatArray);
    /* DO-NOT-DELETE splicer.end(bsl.arr.load3Float) */
  }
}

/*
 * Method:  load1[Double]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_load1Double"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_load1Double(
  /* inout array<> */ struct sidl__array** a1,
  /* in rarray[m] */ double* values,
  /* in */ int32_t m,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.load1Double) */
	LOADTYPEDRAW(sidl_double, __FUNC__, 1, m, bsl_datatype_doubleArray);
    /* DO-NOT-DELETE splicer.end(bsl.arr.load1Double) */
  }
}

/*
 * Method:  load2[Double]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_load2Double"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_load2Double(
  /* inout array<> */ struct sidl__array** a2,
  /* in rarray[m,n] */ double* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.load2Double) */
	LOADTYPEDRAW(sidl_double, __FUNC__, 2, m*n, bsl_datatype_doubleArray);
    /* DO-NOT-DELETE splicer.end(bsl.arr.load2Double) */
  }
}

/*
 * Method:  load3[Double]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_load3Double"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_load3Double(
  /* inout array<> */ struct sidl__array** a3,
  /* in rarray[m,n,p] */ double* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* in */ int32_t p,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.load3Double) */
	LOADTYPEDRAW(sidl_double, __FUNC__, 3, m*n*p, bsl_datatype_doubleArray);
    /* DO-NOT-DELETE splicer.end(bsl.arr.load3Double) */
  }
}

/*
 * Method:  load1[Int]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_load1Int"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_load1Int(
  /* inout array<> */ struct sidl__array** a1,
  /* in rarray[m] */ int32_t* values,
  /* in */ int32_t m,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.load1Int) */
	LOADTYPEDRAW(sidl_int, __FUNC__, 1, m, bsl_datatype_intArray);
    /* DO-NOT-DELETE splicer.end(bsl.arr.load1Int) */
  }
}

/*
 * Method:  load2[Int]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_load2Int"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_load2Int(
  /* inout array<> */ struct sidl__array** a2,
  /* in rarray[m,n] */ int32_t* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.load2Int) */
	LOADTYPEDRAW(sidl_int, __FUNC__, 2, m*n, bsl_datatype_intArray);
    /* DO-NOT-DELETE splicer.end(bsl.arr.load2Int) */
  }
}

/*
 * Method:  load3[Int]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_load3Int"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_load3Int(
  /* inout array<> */ struct sidl__array** a3,
  /* in rarray[m,n,p] */ int32_t* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* in */ int32_t p,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.load3Int) */
	LOADTYPEDRAW(sidl_int, __FUNC__, 3, m*n*p, bsl_datatype_intArray);
    /* DO-NOT-DELETE splicer.end(bsl.arr.load3Int) */
  }
}

/*
 * Method:  load1[Long]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_load1Long"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_load1Long(
  /* inout array<> */ struct sidl__array** a1,
  /* in rarray[m] */ int64_t* values,
  /* in */ int32_t m,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.load1Long) */
	LOADTYPEDRAW(sidl_long, __FUNC__, 1, m, bsl_datatype_longArray);
    /* DO-NOT-DELETE splicer.end(bsl.arr.load1Long) */
  }
}

/*
 * Method:  load2[Long]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_load2Long"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_load2Long(
  /* inout array<> */ struct sidl__array** a2,
  /* in rarray[m,n] */ int64_t* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.load2Long) */
	LOADTYPEDRAW(sidl_long, __FUNC__, 2, m*n, bsl_datatype_longArray);
    /* DO-NOT-DELETE splicer.end(bsl.arr.load2Long) */
  }
}

/*
 * Method:  load3[Long]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_load3Long"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_load3Long(
  /* inout array<> */ struct sidl__array** a3,
  /* in rarray[m,n,p] */ int64_t* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* in */ int32_t p,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.load3Long) */
	LOADTYPEDRAW(sidl_long, __FUNC__, 3, m*n*p, bsl_datatype_longArray);
#undef LOADTYPEDRAW
    /* DO-NOT-DELETE splicer.end(bsl.arr.load3Long) */
  }
}

/*
 * Method:  allocate1d[]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_allocate1d"

#ifdef __cplusplus
extern "C"
#endif
struct sidl__array*
impl_bsl_arr_allocate1d(
  /* in */ enum bsl_datatype__enum dt,
  /* in */ int32_t size,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.allocate1d) */
	struct sidl__array* result = NULL;
	if (size < 0) { goto EXIT; }
#define ALL1DCASE(scalartype) \
	case bsl_datatype_## scalartype ##Array: \
	{ \
		struct sidl_ ## scalartype ## __array *p = sidl_ ## scalartype ## __array_create1d(size); \
		result = (struct sidl__array*) p; \
	} \
	break
	switch (dt) {
	ALL1DCASE(bool);
	ALL1DCASE(int);
	ALL1DCASE(long);
	ALL1DCASE(float);
	ALL1DCASE(double);
	ALL1DCASE(fcomplex);
	ALL1DCASE(dcomplex);
	default:
		SIDL_THROW(*_ex, sidl_SIDLException, __FUNC__ ": unsupported array type.");
	}
EXIT:;
	return result;
#undef ALL1DCASE
    /* DO-NOT-DELETE splicer.end(bsl.arr.allocate1d) */
  }
}

/*
 * Method:  allocate2d[]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_allocate2d"

#ifdef __cplusplus
extern "C"
#endif
struct sidl__array*
impl_bsl_arr_allocate2d(
  /* in */ enum bsl_datatype__enum dt,
  /* in */ int32_t sizex,
  /* in */ int32_t sizey,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.allocate2d) */
	struct sidl__array* result = NULL;
	if (sizex < 0 || sizey < 0) { goto EXIT; }
#define ALL2DCASE(scalartype) \
	case bsl_datatype_## scalartype ##Array: \
	{ \
		struct sidl_ ## scalartype ## __array *p = sidl_ ## scalartype ## __array_create2dCol(sizex, sizey); \
		result = (struct sidl__array*) p; \
	} \
	break
	switch (dt) {
	ALL2DCASE(bool);
	ALL2DCASE(int);
	ALL2DCASE(long);
	ALL2DCASE(float);
	ALL2DCASE(double);
	ALL2DCASE(fcomplex);
	ALL2DCASE(dcomplex);
	default:
		SIDL_THROW(*_ex, sidl_SIDLException, __FUNC__ ": unsupported array type.");
	}
EXIT:;
	return result;
#undef ALL2DCASE
    /* DO-NOT-DELETE splicer.end(bsl.arr.allocate2d) */
  }
}

/*
 * Method:  allocate3d[]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_allocate3d"

#ifdef __cplusplus
extern "C"
#endif
struct sidl__array*
impl_bsl_arr_allocate3d(
  /* in */ enum bsl_datatype__enum dt,
  /* in */ int32_t sizex,
  /* in */ int32_t sizey,
  /* in */ int32_t sizez,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.allocate3d) */
	struct sidl__array* result = NULL;
	int32_t lower[3]= {0,0,0}, upper[3] = {sizex, sizey, sizez};
	if (sizex < 0 || sizey < 0 || sizez< 0) { goto EXIT; }
#define ALL3DCASE(scalartype) \
	case bsl_datatype_## scalartype ##Array: \
	{ \
		struct sidl_ ## scalartype ## __array *p  = sidl_ ## scalartype ## __array_createCol(3, lower, upper); \
		result = (struct sidl__array*) p; \
	} \
	break
	switch (dt) {
	ALL3DCASE(bool);
	ALL3DCASE(int);
	ALL3DCASE(long);
	ALL3DCASE(float);
	ALL3DCASE(double);
	ALL3DCASE(fcomplex);
	ALL3DCASE(dcomplex);
	default:
		SIDL_THROW(*_ex, sidl_SIDLException, __FUNC__ ": unsupported array type.");
	}
EXIT:;
	return result;
#undef ALL3DCASE
    /* DO-NOT-DELETE splicer.end(bsl.arr.allocate3d) */
  }
}

/*
 *  MPE_Decomp1d-alike for 0-based (C) numberings.
 * @param n the size of the 1d data to be decomposed.
 * @param size the number of patches to be decomposed into.
 * @param rank the number of this patch (in range 0..size-1)
 * @return two element array span, where span[0] is
 * the index of the first element of a Fortran (1:n) array 
 * size n assigned to the patch rank given and span[1] is the
 * last element of the array assigned to the patch rank given.
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_decompose1dC"

#ifdef __cplusplus
extern "C"
#endif
struct sidl_int__array*
impl_bsl_arr_decompose1dC(
  /* in */ int32_t n,
  /* in */ int32_t size,
  /* in */ int32_t rank,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.decompose1dC) */
	struct sidl_int__array* result = sidl_int__array_create1d(3);

	int s; int e; /* these are 1based and will be shifted to 0based at the last steps. */
	int nlocal, deficit;

	nlocal = n/size;
	s  = rank * nlocal + 1;
	deficit     = n % size;
	s  = s + ((rank < deficit) ? rank : deficit);
	if (rank < deficit) { nlocal++; }
	e = s + nlocal - 1;
	if (e > n || rank == size-1) { e = n; }

	/* convert to c notation and store */
	sidl_int__array_set1(result, 0, s-1);
	sidl_int__array_set1(result, 1, e-1);
	sidl_int__array_set1(result, 2, e-s+1);

	return result;
    /* DO-NOT-DELETE splicer.end(bsl.arr.decompose1dC) */
  }
}

/*
 * Method:  computeIntersection[]
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_computeIntersection"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_bsl_arr_computeIntersection(
  /* in array<int> */ struct sidl_int__array* low1,
  /* in array<int> */ struct sidl_int__array* high1,
  /* in array<int> */ struct sidl_int__array* low2,
  /* in array<int> */ struct sidl_int__array* high2,
  /* inout rarray[d] */ int32_t* low,
  /* inout rarray[d] */ int32_t* high,
  /* in */ int32_t d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.computeIntersection) */
	int32_t i;
        for (i = 0; i < d; i++) {
                /* each axis must have some overlap */
                int32_t l1, l2, h1, h2, b, e;
                l1 = sidlArrayElem1(low1,i);
                h1 = sidlArrayElem1(high1,i);
                l2 = sidlArrayElem1(low2,i);
                h2 = sidlArrayElem1(high2,i);
                b = (l1 > l2) ? l1 : l2; /* max of lows */
                e = (h1 > h2) ? h2 : h1; /* min of highs */
                if (b > e) return FALSE; /* non-overlapping */
                low[i] = b;
                high[i] = e;
        }
        return TRUE;
    /* DO-NOT-DELETE splicer.end(bsl.arr.computeIntersection) */
  }
}

/*
 *  Get equivalent N-d position indices from corners and position in 1d data array with first
 * element corresponding to lower corner and with column major ordering.
 * Outputs are undefined if first/last are outside dimensions [1..3].
 * @param index position in data 1d array, assuming 0-based indexing.
 * @param lowerCorner
 * @param upperCorner
 * @param i0 output index in dimension 0.
 * @param i1 output index in dimension 0 if 2 or 3d, else undefined.
 * @param i2 output index in dimension 0 if 2 or 3d, else undefined.
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_indexToCoord"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_indexToCoord(
  /* in */ int32_t index,
  /* in array<int> */ struct sidl_int__array* lowerCorner,
  /* in array<int> */ struct sidl_int__array* upperCorner,
  /* out */ int32_t* i0,
  /* out */ int32_t* i1,
  /* out */ int32_t* i2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.indexToCoord) */
        int32_t dim = sidlLength(lowerCorner,0);
        int32_t volume = 1;
        volume = impl_bsl_arr_boxVolume(lowerCorner, upperCorner,_ex);
        index = index % volume;
        if (dim == 1) { 
                *i0 = sidlArrayElem1(lowerCorner,0) + index;
                *i1 = *i2 = 0;
        }
        if (dim == 2) {
                int32_t len0 = 1 + sidlArrayElem1(upperCorner,0) - sidlArrayElem1(lowerCorner,0);
                *i1 = (index / len0) + sidlArrayElem1(lowerCorner,1);
                *i0 = (index % len0) + sidlArrayElem1(lowerCorner,0);
                *i2 = len0;
        }
        if (dim == 3) {
                int32_t r1;
                int32_t len1 = 1 + sidlArrayElem1(upperCorner,1) - sidlArrayElem1(lowerCorner,1);
                int32_t len0 = 1 + sidlArrayElem1(upperCorner,0) - sidlArrayElem1(lowerCorner,0);
                *i2 = index / (len0*len1);
                r1 = index % (len0*len1);
                *i1 = r1 / len0;
                *i0 = r1 % len0;
                *i2 += sidlArrayElem1(lowerCorner,2);
                *i1 += sidlArrayElem1(lowerCorner,1);
                *i0 += sidlArrayElem1(lowerCorner,0);
        }
    /* DO-NOT-DELETE splicer.end(bsl.arr.indexToCoord) */
  }
}

/*
 *  Get position in 1d data array from array position indices.
 * Output is undefined if first/last are outside dimensions [1..3].
 * @param varNumber a number from [0..getNVars-1]. result is offset by +volume(lowerCorner,upperCorner)varNumber.
 * @param lowerCorner
 * @param upperCorner
 * @param i0 output index in dimension 0.
 * @param i1 output index in dimension 0 if 2 or 3d, else undefined.
 * @param i2 output index in dimension 0 if 2 or 3d, else undefined.
 * @return index position in data 1d array, assuming 0-based indexing.
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_coordToIndex"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_bsl_arr_coordToIndex(
  /* in */ int32_t varNumber,
  /* in array<int> */ struct sidl_int__array* lowerCorner,
  /* in array<int> */ struct sidl_int__array* upperCorner,
  /* in */ int32_t i0,
  /* in */ int32_t i1,
  /* in */ int32_t i2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.coordToIndex) */
	int32_t dim = sidlLength(lowerCorner,0);
        int32_t volume = 1;
        volume = impl_bsl_arr_boxVolume(lowerCorner, upperCorner,_ex);
        if (dim == 1) {
                int index = i0 - sidlArrayElem1(lowerCorner,0);
                return index + varNumber*volume;
        }
        if (dim == 2) {
                int32_t len0 = 1 + sidlArrayElem1(upperCorner,0) - sidlArrayElem1(lowerCorner,0);
                int32_t index = (i0 - sidlArrayElem1(lowerCorner,0)) + len0*(i1 - sidlArrayElem1(lowerCorner,1));
                return index + varNumber*volume;
        }
        if (dim == 3) {
                int32_t len1 = 1 + sidlArrayElem1(upperCorner,1) - sidlArrayElem1(lowerCorner,1);
                int32_t len0 = 1 + sidlArrayElem1(upperCorner,0) - sidlArrayElem1(lowerCorner,0);
                int32_t index = (i0 - sidlArrayElem1(lowerCorner,0)) + 
			len0*( (i1 - sidlArrayElem1(lowerCorner,1)) + len1 * (i2 - sidlArrayElem1(lowerCorner,2)));
                return index + varNumber*volume;
        }
    /* DO-NOT-DELETE splicer.end(bsl.arr.coordToIndex) */
  }
}

/*
 *  Get volume of a box from 2 corners.
 * @param lowerCorner
 * @param upperCorner
 * @return PRODUCT(upperCorner[i] - lowerCorner[i] +1 for all i);
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_boxVolume"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_bsl_arr_boxVolume(
  /* in array<int> */ struct sidl_int__array* lowerCorner,
  /* in array<int> */ struct sidl_int__array* upperCorner,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(bsl.arr.boxVolume) */
        int64_t volume = 1;
        int32_t pdim = sidlLength(lowerCorner,0);
	int i;
        for (i=0; i < pdim; i++) {
                int32_t si = sidlArrayElem1(upperCorner,i)- sidlArrayElem1(lowerCorner,i) + 1;
                volume *= si;
        }
        return volume;
    /* DO-NOT-DELETE splicer.end(bsl.arr.boxVolume) */
  }
}

/*
 *  This function should never be called, but helps babel generate better code. 
 */

#undef __FUNC__
#define __FUNC__ "impl_bsl_arr_boccaForceUsePortInclude"

#ifdef __cplusplus
extern "C"
#endif
void
impl_bsl_arr_boccaForceUsePortInclude(
  /* in */ bsl_arr self,
  /* in */ bsl_arrx dummy0,
  /* in */ enum bsl_datatype__enum dummy1,
  /* in */ bsl_morph dummy2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(bsl.arr.boccaForceUsePortInclude) */
/* DO-NOT-EDIT-BOCCA */
  /* Bocca generated code. bocca.protected.begin(bsl.arr.boccaForceUsePortInclude) */
    (void)self;
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;

  /* Bocca generated code. bocca.protected.end(bsl.arr.boccaForceUsePortInclude) */
  /* DO-NOT-DELETE splicer.end(bsl.arr.boccaForceUsePortInclude) */
  }
}
/* Babel internal methods, Users should not edit below this line. */
struct bsl_arr__object* impl_bsl_arr_fconnect_bsl_arr(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return bsl_arr__connectI(url, ar, _ex);
}
struct bsl_arr__object* impl_bsl_arr_fcast_bsl_arr(void* bi, 
  sidl_BaseInterface* _ex) {
  return bsl_arr__cast(bi, _ex);
}
struct bsl_arrx__object* impl_bsl_arr_fconnect_bsl_arrx(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return bsl_arrx__connectI(url, ar, _ex);
}
struct bsl_arrx__object* impl_bsl_arr_fcast_bsl_arrx(void* bi, 
  sidl_BaseInterface* _ex) {
  return bsl_arrx__cast(bi, _ex);
}
struct bsl_morph__object* impl_bsl_arr_fconnect_bsl_morph(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return bsl_morph__connectI(url, ar, _ex);
}
struct bsl_morph__object* impl_bsl_arr_fcast_bsl_morph(void* bi, 
  sidl_BaseInterface* _ex) {
  return bsl_morph__cast(bi, _ex);
}
struct sidl_BaseClass__object* impl_bsl_arr_fconnect_sidl_BaseClass(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connectI(url, ar, _ex);
}
struct sidl_BaseClass__object* impl_bsl_arr_fcast_sidl_BaseClass(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_BaseClass__cast(bi, _ex);
}
struct sidl_BaseInterface__object* impl_bsl_arr_fconnect_sidl_BaseInterface(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connectI(url, ar, _ex);
}
struct sidl_BaseInterface__object* impl_bsl_arr_fcast_sidl_BaseInterface(void* 
  bi, sidl_BaseInterface* _ex) {
  return sidl_BaseInterface__cast(bi, _ex);
}
struct sidl_ClassInfo__object* impl_bsl_arr_fconnect_sidl_ClassInfo(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connectI(url, ar, _ex);
}
struct sidl_ClassInfo__object* impl_bsl_arr_fcast_sidl_ClassInfo(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_ClassInfo__cast(bi, _ex);
}
struct sidl_RuntimeException__object* 
  impl_bsl_arr_fconnect_sidl_RuntimeException(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex) {
  return sidl_RuntimeException__connectI(url, ar, _ex);
}
struct sidl_RuntimeException__object* impl_bsl_arr_fcast_sidl_RuntimeException(
  void* bi, sidl_BaseInterface* _ex) {
  return sidl_RuntimeException__cast(bi, _ex);
}
