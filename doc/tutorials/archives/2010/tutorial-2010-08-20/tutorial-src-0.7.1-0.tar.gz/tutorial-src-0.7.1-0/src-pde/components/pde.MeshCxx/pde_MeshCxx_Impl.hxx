// 
// File:          pde_MeshCxx_Impl.hxx
// Symbol:        pde.MeshCxx-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.MeshCxx
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_pde_MeshCxx_Impl_hxx
#define included_pde_MeshCxx_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_pde_MeshCxx_IOR_h
#include "pde_MeshCxx_IOR.h"
#endif
#ifndef included_bsl_arr_hxx
#include "bsl_arr.hxx"
#endif
#ifndef included_pde_BoundPos_hxx
#include "pde_BoundPos.hxx"
#endif
#ifndef included_pde_BoundaryCondition_hxx
#include "pde_BoundaryCondition.hxx"
#endif
#ifndef included_pde_FieldVar_hxx
#include "pde_FieldVar.hxx"
#endif
#ifndef included_pde_FieldVarCxx_hxx
#include "pde_FieldVarCxx.hxx"
#endif
#ifndef included_pde_Mesh_hxx
#include "pde_Mesh.hxx"
#endif
#ifndef included_pde_MeshColl_hxx
#include "pde_MeshColl.hxx"
#endif
#ifndef included_pde_MeshCxx_hxx
#include "pde_MeshCxx.hxx"
#endif
#ifndef included_pde_Patch_hxx
#include "pde_Patch.hxx"
#endif
#ifndef included_pde_PatchCxx_hxx
#include "pde_PatchCxx.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(pde.MeshCxx._hincludes)

#ifdef HAVE_MPI

// workaround openmpi whinage

#ifdef HAVE_LONG_LONG
#define BABEL_HAVE_LONG_LONG HAVE_LONG_LONG
#undef HAVE_LONG_LONG
#endif // HAVE_LONG_LONG

#include <mpi.h>

#ifdef BABEL_HAVE_LONG_LONG
#undef HAVE_LONG_LONG
#define HAVE_LONG_LONG BABEL_HAVE_LONG_LONG
#undef BABEL_HAVE_LONG_LONG
#endif // BABEL_HAVE_LONG_LONG

#endif // HAVE_MPI

#include <map>

// DO-NOT-DELETE splicer.end(pde.MeshCxx._hincludes)
// DO-NOT-DELETE splicer.begin(pde.MeshCxx._includes)

#ifdef HAVE_MPI

// workaround openmpi whinage

#ifdef HAVE_LONG_LONG
#define BABEL_HAVE_LONG_LONG HAVE_LONG_LONG
#undef HAVE_LONG_LONG
#endif // HAVE_LONG_LONG

#include <mpi.h>

#ifdef BABEL_HAVE_LONG_LONG
#undef HAVE_LONG_LONG
#define HAVE_LONG_LONG BABEL_HAVE_LONG_LONG
#undef BABEL_HAVE_LONG_LONG
#endif // BABEL_HAVE_LONG_LONG

#endif // HAVE_MPI

#include <map>

// DO-NOT-DELETE splicer.end(pde.MeshCxx._includes)

namespace pde { 

  /**
   * Symbol "pde.MeshCxx" (version 0.0)
   */
  class MeshCxx_impl : public virtual ::pde::MeshCxx 
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx._inherits)
  // Insert-Code-Here {pde.MeshCxx._inherits} (optional inheritance here)
  // DO-NOT-DELETE splicer.end(pde.MeshCxx._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(pde.MeshCxx._implementation)
    
	bool configured;
	int32_t dim;
	MeshColl coll;
	int32_t bwd;
	int32_t ishape[3];
	double lengths[3];
	int32_t strad;
	int32_t tlow, thigh;
	int32_t tcur;
	int32_t steps;
	bool commset; // true if we have a valid fcomm according to the user.
	bool composed; // true if composed, in which case other compose and setcomm not ok.
	int64_t fcomm;
	int d_procrank;
	int d_procsize;
	std::map< std::string, pde::FieldVar > vars;
	sidl::array< pde::PatchCxx > d_allpatches;
	sidl::array< pde::PatchCxx > d_localpatches;
#ifdef HAVE_MPI
	MPI_Comm ccomm;
#endif

    // DO-NOT-DELETE splicer.end(pde.MeshCxx._implementation)

  public:
    // default constructor, used for data wrapping(required)
    MeshCxx_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    MeshCxx_impl( struct pde_MeshCxx__object * s ) : StubBase(s,true), _wrapped(
      false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~MeshCxx_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:


    /**
     *  If mpi is to be supported, this must be called with.
     * If this is not called, the mesh will operate in serial mode.
     * @param fcomm a valid fortran-form communicator properly converted to a sidl long.
     */
    void
    setCommunicator_impl (
      /* in */int64_t fcomm
    )
    ;


    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude_impl (
      /* in */::bsl::arr dummy0,
      /* in */::pde::PatchCxx dummy1,
      /* in */::pde::FieldVarCxx dummy2,
      /* in */::pde::BoundPos dummy3
    )
    ;


    /**
     *  Set up the grid for all FieldVar defined on this Grid.
     * 
     * @param ndim an integer denoting the dimensionality. 1D, 2D or 3D.
     * @param mc the mesh collocation type.
     * @param boundaryWidthDefault halo of boundary cells.
     * @param shape a 1D array dim long containing the mesh resolution in each direction.
     * @param distances real space lengths of each axis.
     * @param stencil_radius maximum radius for space stencils.
     * @param time_high : how many intermediate stages of data to keep. in RK2, the values are 1, -1. 
     * @param time_low : how many intermediate stages of data to keep. in RK2, the values are 1, -1. 
     */
    void
    configure_impl (
      /* in */int32_t ndim,
      /* in */::pde::MeshColl mc,
      /* in */int32_t boundaryWidthDefault,
      /* in array<int> */::sidl::array<int32_t> shape,
      /* in array<double> */::sidl::array<double> distances,
      /* in */int32_t stencil_radius,
      /* in */int32_t time_low,
      /* in */int32_t time_high
    )
    ;


    /**
     *  @name QUERY METHODS. 
     * Needed by any component which needs to find the geometrical
     * location of a bounding box. Also needed by integrators.
     */
    int32_t
    getDimension_impl() ;
    /**
     * user defined non-static method.
     */
    ::sidl::array<int32_t>
    getShape_impl() ;
    /**
     * user defined non-static method.
     */
    ::sidl::array<double>
    getDistances_impl() ;

    /**
     *  Get the maximum boundary (halo) width for all FieldVar from this mesh.
     * @return Error : returns -1
     */
    int32_t
    getBoundaryWidth_impl() ;

    /**
     *  These will return the radius of the space stencil.  
     */
    int32_t
    getSpaceStencil_impl() ;

    /**
     *  return the range of labels for time steps. 
     */
    void
    getTimeRange_impl (
      /* out */int32_t& time_alias_low,
      /* out */int32_t& time_alias_high
    )
    ;


    /**
     *  Compose the data. This is called after configure.
     * Define the domain to be the global union of npatches slabs.
     * Decomposition algorithm will try to even the number of
     * mesh cells on each processor if parallelism is in use.
     * In parallel case, if npatches < nproc, empty patches result.
     * @return Error : return -1, else 0
     */
    int32_t
    compose1_impl (
      /* in */int32_t npatches
    )
    ;


    /**
     *  Compose the data. This is called after configure.
     * Define the domain to be the global union of patches
     * defined by tiling the domain in chunks with dimensions
     * tileSize (or larger at the domain upper edges).
     * A Decomposition algorithm will try to even the number of
     * mesh cells on each processor if parallelism is in use.
     * @param tileSize an array of size getDimension. e.g.
     * for a 2d domain, tileSize={3,3} will yield nominally 3x3 patches.
     * Note: tileSize elements smaller than stencil_radius and tBoundaryWidthDefault
     * are probably a bad idea.
     * @return Error : return -1, else 0
     */
    int32_t
    composeTile_impl (
      /* in array<int> */::sidl::array<int32_t> tileSize
    )
    ;


    /**
     *  @return list of all patch ids on this mesh. 
     */
    ::sidl::array<int64_t>
    getPatchIds_impl() ;

    /**
     *  @return patch with the given globalid. 
     */
    ::pde::Patch
    getPatch_impl (
      /* in */int64_t globalid
    )
    ;


    /**
     *  fetch the shape, corners of the boundary cell region along the side given. 
     * @param windowlb windowub, shape should all be dim long 1d arrays.
     */
    void
    getBoundaryWindow_impl (
      /* in */::pde::BoundPos side,
      /* inout array<int> */::sidl::array<int32_t>& windowlb,
      /* inout array<int> */::sidl::array<int32_t>& windowub,
      /* inout array<int> */::sidl::array<int32_t>& shape
    )
    ;


    /**
     *  Setup and return a FieldVar declared on this mesh.
     * Exactly One of the compose functions must be done before any
     * flavor fields are created.
     * @bug Only MeshColl_CENTERS is currently supported for coll.
     * @param name : Name of the FieldVar being formed
     * @param nvars : # of components making up a point in the field.
     * @param coll : Mesh collocation type.
     * @return Error : returns NULL
     */
    ::pde::FieldVar
    createFieldVar_impl (
      /* in */const ::std::string& name,
      /* in */int32_t nvars,
      /* in */::pde::MeshColl coll,
      /* in */::pde::BoundaryCondition bc
    )
    ;


    /**
     *  return an existing field var, or an exception if name is unknown. 
     */
    ::pde::FieldVar
    getFieldVar_impl (
      /* in */const ::std::string& name
    )
    ;


    /**
     *  return the names of all fieldvars.  
     */
    ::sidl::array< ::std::string>
    getFieldNames_impl() ;

    /**
     *  @name Time related methods
     */
    int32_t
    currentTime_impl() ;
    /**
     * user defined non-static method.
     */
    int32_t
    stepsCompleted_impl() ;
    /**
     * user defined non-static method.
     */
    int32_t
    incrementTime_impl() ;

    /**
     *  syncronise all FieldVars on this grid. i.e. ghost update.
     * @param timestep : an int showing which timestep to sync data at
     * @return Error returns -1 else 0
     */
    int32_t
    sync_impl (
      /* in */int32_t timestep
    )
    ;

    /**
     * user defined non-static method.
     */
    int32_t
    getProcCount_impl() ;
    /**
     * user defined non-static method.
     */
    int64_t
    getCommunicator_impl() ;
    /**
     * user defined non-static method.
     */
    int32_t
    getProcId_impl() ;
    /**
     * user defined non-static method.
     */
    bool
    boxContains_impl (
      /* in array<int> */::sidl::array<int32_t> lowerCorner,
      /* in array<int> */::sidl::array<int32_t> upperCorner,
      /* in array<int> */::sidl::array<int32_t> point
    )
    ;

    /**
     * user defined non-static method.
     */
    int64_t
    boxVolume_impl (
      /* in array<int> */::sidl::array<int32_t> lowerCorner,
      /* in array<int> */::sidl::array<int32_t> upperCorner
    )
    ;

    /**
     * user defined non-static method.
     */
    int64_t
    shapeVolume_impl (
      /* in array<int> */::sidl::array<int32_t> shape
    )
    ;

  };  // end class MeshCxx_impl

} // end namespace pde

// DO-NOT-DELETE splicer.begin(pde.MeshCxx._misc)
// Insert-Code-Here {pde.MeshCxx._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(pde.MeshCxx._misc)

#endif
