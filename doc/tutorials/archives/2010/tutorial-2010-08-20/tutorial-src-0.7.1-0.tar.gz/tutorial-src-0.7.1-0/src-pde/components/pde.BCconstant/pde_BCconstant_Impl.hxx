// 
// File:          pde_BCconstant_Impl.hxx
// Symbol:        pde.BCconstant-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.BCconstant
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_pde_BCconstant_Impl_hxx
#define included_pde_BCconstant_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_pde_BCconstant_IOR_h
#include "pde_BCconstant_IOR.h"
#endif
#ifndef included_bsl_arr_hxx
#include "bsl_arr.hxx"
#endif
#ifndef included_pde_BCconstant_hxx
#include "pde_BCconstant.hxx"
#endif
#ifndef included_pde_BoundPos_hxx
#include "pde_BoundPos.hxx"
#endif
#ifndef included_pde_BoundaryCondition_hxx
#include "pde_BoundaryCondition.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(pde.BCconstant._hincludes)
#include <map>
// DO-NOT-DELETE splicer.end(pde.BCconstant._hincludes)

namespace pde { 

  /**
   * Symbol "pde.BCconstant" (version 0.0)
   */
  class BCconstant_impl : public virtual ::pde::BCconstant 
  // DO-NOT-DELETE splicer.begin(pde.BCconstant._inherits)
  // Insert-Code-Here {pde.BCconstant._inherits} (optional inheritance here)
  // DO-NOT-DELETE splicer.end(pde.BCconstant._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

  // DO-NOT-DELETE splicer.begin(pde.BCconstant._implementation)

	std::map< std::string, int32_t > d_ints;
	std::map< std::string, double > d_doubles;  

	sidl::array< int32_t > d_win_shape;
	sidl::array< int32_t > d_win_hi;
	sidl::array< int32_t > d_win_lo;

  // DO-NOT-DELETE splicer.end(pde.BCconstant._implementation)

  public:
    // default constructor, used for data wrapping(required)
    BCconstant_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    BCconstant_impl( struct pde_BCconstant__object * s ) : StubBase(s,true), 
      _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~BCconstant_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:


    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude_impl (
      /* in */::bsl::arr dummy0
    )
    ;


    /**
     *  GetProperty Methods to set and get properties based on key-value pairs. Any 
     * component implementing this Boundary Conditions Port would have
     * its own keys.
     * @param key_name : a string identifying the property. Examples
     * include "InflowVelocity", "NumberOfBoundaryCells" etc.
     * @param value : an int/long/double that contains the value of the
     * property identified by the key_name. If the key is unknown in a get
     * operation, the value given is the value that comes back.
     */
    void
    getPropI_impl (
      /* in */const ::std::string& key_name,
      /* inout */int32_t& value
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    getPropD_impl (
      /* in */const ::std::string& key_name,
      /* inout */double& value
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    setPropI_impl (
      /* in */const ::std::string& key_name,
      /* in */int32_t value
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    setPropD_impl (
      /* in */const ::std::string& key_name,
      /* in */double value
    )
    ;


    /**
     *  mark start of processing a fieldvar 
     */
    void
    startApplication_impl (
      /* in */const ::std::string& fvName
    )
    ;

    /**
     * user defined non-static method.
     */
    int32_t
    setWindow_impl (
      /* in */::pde::BoundPos side,
      /* in array<int> */::sidl::array<int32_t> window_lower_bound,
      /* in array<int> */::sidl::array<int32_t> window_upper_bound,
      /* in array<int> */::sidl::array<int32_t> window_shape
    )
    ;

    /**
     * user defined non-static method.
     */
    int32_t
    setWindowRaw_impl (
      /* in */::pde::BoundPos side,
      /* in rarray[dim] */int32_t* window_lower_bound,
      /* in rarray[dim] */int32_t* window_upper_bound,
      /* in rarray[dim] */int32_t* window_shape,
      /* in */int32_t dim
    )
    ;

    /**
     * user defined non-static method.
     */
    int32_t
    compute_impl (
      /* inout array<double> */::sidl::array<double>& uc,
      /* in array<int> */::sidl::array<int32_t> lbc,
      /* in array<int> */::sidl::array<int32_t> ubc,
      /* in array<int> */::sidl::array<int32_t> shapec,
      /* in */int32_t nvars
    )
    ;


    /**
     *  mark end of processing of the region list within a single field var. 
     */
    void
    endApplication_impl (
      /* in */const ::std::string& fvName
    )
    ;

  };  // end class BCconstant_impl

} // end namespace pde

// DO-NOT-DELETE splicer.begin(pde.BCconstant._hmisc)
// Insert-Code-Here {pde.BCconstant._hmisc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(pde.BCconstant._hmisc)

#endif
