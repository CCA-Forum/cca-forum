/*
 * File:          funcwrap_SearchFuncC_Impl.h
 * Symbol:        funcwrap.SearchFuncC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for funcwrap.SearchFuncC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_funcwrap_SearchFuncC_Impl_h
#define included_funcwrap_SearchFuncC_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_funcwrap_SearchFuncC_h
#include "funcwrap_SearchFuncC.h"
#endif
#ifndef included_funcwrap_SearchFunction_h
#include "funcwrap_SearchFunction.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif

/* DO-NOT-DELETE splicer.begin(funcwrap.SearchFuncC._includes) */
#include "rootfind.h"
/* DO-NOT-DELETE splicer.end(funcwrap.SearchFuncC._includes) */

/*
 * Private data for class funcwrap.SearchFuncC
 */

struct funcwrap_SearchFuncC__data {
  /* DO-NOT-DELETE splicer.begin(funcwrap.SearchFuncC._data) */
  searchFunction f;
  /* DO-NOT-DELETE splicer.end(funcwrap.SearchFuncC._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct funcwrap_SearchFuncC__data*
funcwrap_SearchFuncC__get_data(
  funcwrap_SearchFuncC);

extern void
funcwrap_SearchFuncC__set_data(
  funcwrap_SearchFuncC,
  struct funcwrap_SearchFuncC__data*);

extern
void
impl_funcwrap_SearchFuncC__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_funcwrap_SearchFuncC__ctor(
  /* in */ funcwrap_SearchFuncC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_funcwrap_SearchFuncC__ctor2(
  /* in */ funcwrap_SearchFuncC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_funcwrap_SearchFuncC__dtor(
  /* in */ funcwrap_SearchFuncC self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct funcwrap_SearchFuncC__object* 
  impl_funcwrap_SearchFuncC_fconnect_funcwrap_SearchFuncC(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct funcwrap_SearchFuncC__object* 
  impl_funcwrap_SearchFuncC_fcast_funcwrap_SearchFuncC(void* bi, 
  sidl_BaseInterface* _ex);
extern struct funcwrap_SearchFunction__object* 
  impl_funcwrap_SearchFuncC_fconnect_funcwrap_SearchFunction(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct funcwrap_SearchFunction__object* 
  impl_funcwrap_SearchFuncC_fcast_funcwrap_SearchFunction(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_funcwrap_SearchFuncC_fconnect_sidl_BaseClass(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* 
  impl_funcwrap_SearchFuncC_fcast_sidl_BaseClass(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_BaseInterface__object* 
  impl_funcwrap_SearchFuncC_fconnect_sidl_BaseInterface(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_funcwrap_SearchFuncC_fcast_sidl_BaseInterface(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* 
  impl_funcwrap_SearchFuncC_fconnect_sidl_ClassInfo(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* 
  impl_funcwrap_SearchFuncC_fcast_sidl_ClassInfo(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_RuntimeException__object* 
  impl_funcwrap_SearchFuncC_fconnect_sidl_RuntimeException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_funcwrap_SearchFuncC_fcast_sidl_RuntimeException(void* bi, 
  sidl_BaseInterface* _ex);
extern
void
impl_funcwrap_SearchFuncC_setFPointer(
  /* in */ funcwrap_SearchFuncC self,
  /* in */ void* cfunc,
  /* out */ sidl_BaseInterface *_ex);

extern
void*
impl_funcwrap_SearchFuncC_getFPointer(
  /* in */ funcwrap_SearchFuncC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_funcwrap_SearchFuncC_eval(
  /* in */ funcwrap_SearchFuncC self,
  /* in */ double x,
  /* out */ double* value,
  /* out */ sidl_BaseInterface *_ex);

extern struct funcwrap_SearchFuncC__object* 
  impl_funcwrap_SearchFuncC_fconnect_funcwrap_SearchFuncC(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct funcwrap_SearchFuncC__object* 
  impl_funcwrap_SearchFuncC_fcast_funcwrap_SearchFuncC(void* bi, 
  sidl_BaseInterface* _ex);
extern struct funcwrap_SearchFunction__object* 
  impl_funcwrap_SearchFuncC_fconnect_funcwrap_SearchFunction(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct funcwrap_SearchFunction__object* 
  impl_funcwrap_SearchFuncC_fcast_funcwrap_SearchFunction(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_funcwrap_SearchFuncC_fconnect_sidl_BaseClass(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* 
  impl_funcwrap_SearchFuncC_fcast_sidl_BaseClass(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_BaseInterface__object* 
  impl_funcwrap_SearchFuncC_fconnect_sidl_BaseInterface(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_funcwrap_SearchFuncC_fcast_sidl_BaseInterface(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* 
  impl_funcwrap_SearchFuncC_fconnect_sidl_ClassInfo(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* 
  impl_funcwrap_SearchFuncC_fcast_sidl_ClassInfo(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_RuntimeException__object* 
  impl_funcwrap_SearchFuncC_fconnect_sidl_RuntimeException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_funcwrap_SearchFuncC_fcast_sidl_RuntimeException(void* bi, 
  sidl_BaseInterface* _ex);
#ifdef __cplusplus
}
#endif
#endif
