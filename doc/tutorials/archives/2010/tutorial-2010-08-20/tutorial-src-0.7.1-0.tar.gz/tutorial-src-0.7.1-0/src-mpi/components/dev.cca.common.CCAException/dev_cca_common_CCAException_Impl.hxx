// 
// File:          dev_cca_common_CCAException_Impl.hxx
// Symbol:        dev.cca.common.CCAException-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for dev.cca.common.CCAException
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_dev_cca_common_CCAException_Impl_hxx
#define included_dev_cca_common_CCAException_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_dev_cca_common_CCAException_IOR_h
#include "dev_cca_common_CCAException_IOR.h"
#endif
#ifndef included_dev_cca_common_CCAException_hxx
#include "dev_cca_common_CCAException.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_CCAExceptionType_hxx
#include "gov_cca_CCAExceptionType.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_SIDLException_hxx
#include "sidl_SIDLException.hxx"
#endif
#ifndef included_sidl_io_Deserializer_hxx
#include "sidl_io_Deserializer.hxx"
#endif
#ifndef included_sidl_io_Serializer_hxx
#include "sidl_io_Serializer.hxx"
#endif


// DO-NOT-DELETE splicer.begin(dev.cca.common.CCAException._hincludes)
// Insert-Code-Here {dev.cca.common.CCAException._hincludes} (includes or arbitrary code)
// DO-NOT-DELETE splicer.end(dev.cca.common.CCAException._hincludes)

namespace dev { 
  namespace cca { 
    namespace common { 

      /**
       * Symbol "dev.cca.common.CCAException" (version 0.0)
       */
      class CCAException_impl : public virtual ::dev::cca::common::CCAException 
      // DO-NOT-DELETE splicer.begin(dev.cca.common.CCAException._inherits)
      // Insert-Code-Here {dev.cca.common.CCAException._inherits} (optional inheritance here)
      // DO-NOT-DELETE splicer.end(dev.cca.common.CCAException._inherits)

      {

      // All data marked protected will be accessable by 
      // descendant Impl classes
      protected:

        bool _wrapped;

        // DO-NOT-DELETE splicer.begin(dev.cca.common.CCAException._implementation)
	gov::cca::CCAExceptionType e;
        // DO-NOT-DELETE splicer.end(dev.cca.common.CCAException._implementation)

      public:
        // default constructor, used for data wrapping(required)
        CCAException_impl();
        // sidl constructor (required)
        // Note: alternate Skel constructor doesn't call addref()
        // (fixes bug #275)
          CCAException_impl( struct dev_cca_common_CCAException__object * ior ) 
            : StubBase(ior,true), 
          ::sidl::io::Serializable((ior==NULL) ? NULL : &((
            *ior).d_sidl_sidlexception.d_sidl_io_serializable)),
          ::sidl::BaseException((ior==NULL) ? NULL : &((
            *ior).d_sidl_sidlexception.d_sidl_baseexception)),
        ::gov::cca::CCAException((ior==NULL) ? NULL : &((
          *ior).d_gov_cca_ccaexception)) , _wrapped(false) {_ctor();}


        // user defined construction
        void _ctor();

        // virtual destructor (required)
        virtual ~CCAException_impl() { _dtor(); }

        // user defined destruction
        void _dtor();

        // true if this object was created by a user newing the impl
        inline bool _isWrapped() {return _wrapped;}

        // static class initializer
        static void _load();

      public:

        /**
         * user defined non-static method.
         */
        void
        setCCAExceptionType_impl (
          /* in */::gov::cca::CCAExceptionType et
        )
        ;


        /**
         *  This function should never be called, but helps babel generate better code. 
         */
        void
        boccaForceUsePortInclude1_impl() ;
        /**
         * user defined non-static method.
         */
        ::gov::cca::CCAExceptionType
        getCCAExceptionType_impl() ;
      };  // end class CCAException_impl

    } // end namespace common
  } // end namespace cca
} // end namespace dev

// DO-NOT-DELETE splicer.begin(dev.cca.common.CCAException._hmisc)
// Insert-Code-Here {dev.cca.common.CCAException._hmisc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(dev.cca.common.CCAException._hmisc)

#endif
