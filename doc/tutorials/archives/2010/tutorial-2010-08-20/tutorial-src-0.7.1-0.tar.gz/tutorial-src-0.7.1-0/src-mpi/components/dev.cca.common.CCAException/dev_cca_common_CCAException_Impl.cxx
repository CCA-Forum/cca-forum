// 
// File:          dev_cca_common_CCAException_Impl.cxx
// Symbol:        dev.cca.common.CCAException-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for dev.cca.common.CCAException
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "dev_cca_common_CCAException_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAExceptionType_hxx
#include "gov_cca_CCAExceptionType.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_io_Deserializer_hxx
#include "sidl_io_Deserializer.hxx"
#endif
#ifndef included_sidl_io_Serializer_hxx
#include "sidl_io_Serializer.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(dev.cca.common.CCAException._includes)

  // Insert-UserCode-Here {dev.cca.common.CCAException._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(dev.cca.common.CCAException._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(dev.cca.common.CCAException._includes)

  // Insert-UserCode-Here {dev.cca.common.CCAException._includes:epilog} (additional includes or code)

// DO-NOT-DELETE splicer.end(dev.cca.common.CCAException._includes)

// special constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
dev::cca::common::CCAException_impl::CCAException_impl() : StubBase(
  reinterpret_cast< void*>(::dev::cca::common::CCAException::_wrapObj(
  reinterpret_cast< void*>(this))),false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(dev.cca.common.CCAException._ctor2)
  // Insert-Code-Here {dev.cca.common.CCAException._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(dev.cca.common.CCAException._ctor2)
}

// user defined constructor
void dev::cca::common::CCAException_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(dev.cca.common.CCAException._ctor)
    
  // Insert-UserCode-Here {dev.cca.common.CCAException._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(dev.cca.common.CCAException._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR dev.cca.common.CCAException: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(dev.cca.common.CCAException._ctor)

  // Insert-UserCode-Here {dev.cca.common.CCAException._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(dev.cca.common.CCAException._ctor)
}

// user defined destructor
void dev::cca::common::CCAException_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(dev.cca.common.CCAException._dtor)
  // Insert-UserCode-Here {dev.cca.common.CCAException._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(dev.cca.common.CCAException._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR dev.cca.common.CCAException: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(dev.cca.common.CCAException._dtor) 

  // DO-NOT-DELETE splicer.end(dev.cca.common.CCAException._dtor)
}

// static class initializer
void dev::cca::common::CCAException_impl::_load() {
  // DO-NOT-DELETE splicer.begin(dev.cca.common.CCAException._load)
  // Insert-Code-Here {dev.cca.common.CCAException._load} (class initialization)
  // DO-NOT-DELETE splicer.end(dev.cca.common.CCAException._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  setCCAExceptionType[]
 */
void
dev::cca::common::CCAException_impl::setCCAExceptionType_impl (
  /* in */::gov::cca::CCAExceptionType et ) 
{
  // DO-NOT-DELETE splicer.begin(dev.cca.common.CCAException.setCCAExceptionType)
	this->e = et;
  // DO-NOT-DELETE splicer.end(dev.cca.common.CCAException.setCCAExceptionType)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
dev::cca::common::CCAException_impl::boccaForceUsePortInclude1_impl () 

{
  // DO-NOT-DELETE splicer.begin(dev.cca.common.CCAException.boccaForceUsePortInclude1)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(dev.cca.common.CCAException.boccaForceUsePortInclude1)

  // Bocca generated code. bocca.protected.end(dev.cca.common.CCAException.boccaForceUsePortInclude1)
  // DO-NOT-DELETE splicer.end(dev.cca.common.CCAException.boccaForceUsePortInclude1)
}

/**
 * Method:  getCCAExceptionType[]
 */
::gov::cca::CCAExceptionType
dev::cca::common::CCAException_impl::getCCAExceptionType_impl () 

{
  // DO-NOT-DELETE splicer.begin(dev.cca.common.CCAException.getCCAExceptionType)
	return e;
  // DO-NOT-DELETE splicer.end(dev.cca.common.CCAException.getCCAExceptionType)
}


// DO-NOT-DELETE splicer.begin(dev.cca.common.CCAException._misc)
// Insert-Code-Here {dev.cca.common.CCAException._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(dev.cca.common.CCAException._misc)

