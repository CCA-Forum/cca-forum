// 
// File:          functions_CubeFunction_Impl.hxx
// Symbol:        functions.CubeFunction-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for functions.CubeFunction
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_functions_CubeFunction_Impl_hxx
#define included_functions_CubeFunction_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_functions_CubeFunction_IOR_h
#include "functions_CubeFunction_IOR.h"
#endif
#ifndef included_function_FunctionPort_hxx
#include "function_FunctionPort.hxx"
#endif
#ifndef included_functions_CubeFunction_hxx
#include "functions_CubeFunction.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Component_hxx
#include "gov_cca_Component.hxx"
#endif
#ifndef included_gov_cca_ComponentRelease_hxx
#include "gov_cca_ComponentRelease.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif


// DO-NOT-DELETE splicer.begin(functions.CubeFunction._hincludes)
// DO-NOT-DELETE splicer.end(functions.CubeFunction._hincludes)

namespace functions { 

  /**
   * Symbol "functions.CubeFunction" (version 0.0)
   */
  class CubeFunction_impl : public virtual ::functions::CubeFunction 
  // DO-NOT-DELETE splicer.begin(functions.CubeFunction._inherits)
  // DO-NOT-DELETE splicer.end(functions.CubeFunction._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

   // DO-NOT-DELETE splicer.begin(functions.CubeFunction._implementation)
   // Bocca generated code. bocca.protected.begin(functions.CubeFunction._implementation)
    gov::cca::Services    d_services;
   // Bocca generated code. bocca.protected.end(functions.CubeFunction._implementation)
 
    // DO-NOT-DELETE splicer.end(functions.CubeFunction._implementation)

  public:
    // default constructor, used for data wrapping(required)
    CubeFunction_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    CubeFunction_impl( struct functions_CubeFunction__object * s ) : StubBase(s,
      true), _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~CubeFunction_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    void
    boccaSetServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;

    /**
     * user defined non-static method.
     */
    void
    boccaReleaseServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;


    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude_impl() ;

    /**
     *  Starts up a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning Svc and setServices:
     * 
     * The component interaction with the CCA framework
     * and Ports begins on the call to setServices by the framework.
     * 
     * This function is called exactly once for each instance created
     * by the framework.
     * 
     * The argument Svc will never be nil/null.
     * 
     * Those uses ports which are automatically connected by the framework
     * (so-called service-ports) may be obtained via getPort during
     * setServices.
     */
    void
    setServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;


    /**
     * Shuts down a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning Svc and setServices:
     * 
     * This function is called exactly once for each callback registered
     * through Services.
     * 
     * The argument Svc will never be nil/null.
     * The argument Svc will always be the same as that received in
     * setServices.
     * 
     * During this call the component should release any interfaces
     * acquired by getPort().
     * 
     * During this call the component should reset to nil any stored
     * reference to Svc.
     * 
     * After this call, the component instance will be removed from the
     * framework. If the component instance was created by the
     * framework, it will be destroyed, not recycled, The behavior of
     * any port references obtained from this component instance and
     * stored elsewhere becomes undefined.
     * 
     * Notes for the component implementor:
     * 1) The component writer may perform blocking activities
     * within releaseServices, such as waiting for remote computations
     * to shutdown.
     * 2) It is good practice during releaseServices for the component
     * writer to remove or unregister all the ports it defined.
     */
    void
    releaseServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;

    /**
     * user defined non-static method.
     */
    void
    init_impl (
      /* in array<double> */::sidl::array<double> params
    )
    ;

    /**
     * user defined non-static method.
     */
    double
    evaluate_impl (
      /* in */double x
    )
    ;

  };  // end class CubeFunction_impl

} // end namespace functions

// DO-NOT-DELETE splicer.begin(functions.CubeFunction._hmisc)
// DO-NOT-DELETE splicer.end(functions.CubeFunction._hmisc)

#endif
