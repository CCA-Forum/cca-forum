#!/bin/sh
# script to set up the extra flags in a component using mpi/ccaffeine
# within a bocca project. MPISettings.sh must have run in the same shell.
# argument is the sidl name of the component, or none which applies
# flags to all components.
# args: language being supported (cxx, c, f90, f77, python, java) and
# sidl name of component (optional if entire project is in same language)
#

if test "x$1" = "x"; then
	echo "LANGUAGE must be specified to MPIFlags.sh"
	exit 1
fi
if test "x$2" = "x"; then
	:
else
	if ! test -d components/$2; then
		echo "MISSING component source dir components/$2"
		exit 1
	fi
fi

if test "x$HAVE_MPI" = "x1"; then

case $1 in
c|cxx)
cat  << MEOF > $TMPDIR/$1.$2.MPIvars.sh
INCLUDES=-I$CCAFEINCL -I$CCAFEINCL2 -DHAVE_MPI $MPIINC
LIBS=-R$MPILIB -L$MPILIB -l$MPILIBNAME -l$MPICXXLIB
MEOF
cat $TMPDIR/$1.$2.MPIvars.sh >> components/$2/make.vars.user
	;;
python)	:
	;;
java)	:
	;;
*)
	echo "#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
	echo "MPIFlags.sh doesn't yet support $1. Build or runtime will probably fail."
	echo "#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

esac

else
	echo "# mpi not configured in framework."
	echo "# mpi not configured in framework. HAVE_MPI will not be defined" >> $TMPDIR/$1.$2.MPIvars.sh

fi

