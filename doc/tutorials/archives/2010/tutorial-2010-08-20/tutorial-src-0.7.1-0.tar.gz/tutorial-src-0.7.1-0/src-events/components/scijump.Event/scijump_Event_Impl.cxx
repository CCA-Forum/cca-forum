
// 
// File:          scijump_Event_Impl.cxx
// Symbol:        scijump.Event-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for scijump.Event
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "scijump_Event_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_TypeMap_hxx
#include "gov_cca_TypeMap.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_io_Deserializer_hxx
#include "sidl_io_Deserializer.hxx"
#endif
#ifndef included_sidl_io_Serializer_hxx
#include "sidl_io_Serializer.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(scijump.Event._includes)

  // Insert-UserCode-Here {scijump.Event._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(scijump.Event._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(scijump.Event._includes)

  // Insert-UserCode-Here {scijump.Event._includes:epilog} (additional includes or code)
using namespace sidl;
using namespace gov::cca;

//framework dependent header for deserialization (see below)
#include <ccaffeine_TypeMap.hxx>

void serializeTypeMap(::gov::cca::TypeMap& tm, ::sidl::io::Serializer& ser);
void unserializeTypeMap(::gov::cca::TypeMap& tm, ::sidl::io::Deserializer& des);
// DO-NOT-DELETE splicer.end(scijump.Event._includes)

// special constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
scijump::Event_impl::Event_impl() : StubBase(reinterpret_cast< void*>(
  ::scijump::Event::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(scijump.Event._ctor2)
  // DO-NOT-DELETE splicer.end(scijump.Event._ctor2)
}

// user defined constructor
void scijump::Event_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(scijump.Event._ctor)
    
  // Insert-UserCode-Here {scijump.Event._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(scijump.Event._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR scijump.Event: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(scijump.Event._ctor)

  // Insert-UserCode-Here {scijump.Event._ctor:epilog} (constructor method)

  // Insert-Code-Here {scijump.Event._ctor} (constructor)
  // DO-NOT-DELETE splicer.end(scijump.Event._ctor)
}

// user defined destructor
void scijump::Event_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(scijump.Event._dtor)
  // Insert-UserCode-Here {scijump.Event._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(scijump.Event._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR scijump.Event: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(scijump.Event._dtor) 

  // Insert-Code-Here {scijump.Event._dtor} (destructor)
  // DO-NOT-DELETE splicer.end(scijump.Event._dtor)
}

// static class initializer
void scijump::Event_impl::_load() {
  // DO-NOT-DELETE splicer.begin(scijump.Event._load)
  // DO-NOT-DELETE splicer.end(scijump.Event._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  setHeader[]
 */
void
scijump::Event_impl::setHeader_impl (
  /* in */::gov::cca::TypeMap& h ) 
{
  // DO-NOT-DELETE splicer.begin(scijump.Event.setHeader)
  header = h;
  // DO-NOT-DELETE splicer.end(scijump.Event.setHeader)
}

/**
 * Method:  setBody[]
 */
void
scijump::Event_impl::setBody_impl (
  /* in */::gov::cca::TypeMap& b ) 
{
  // DO-NOT-DELETE splicer.begin(scijump.Event.setBody)
  body = b;
  // DO-NOT-DELETE splicer.end(scijump.Event.setBody)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
scijump::Event_impl::boccaForceUsePortInclude_impl () 

{
  // DO-NOT-DELETE splicer.begin(scijump.Event.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(scijump.Event.boccaForceUsePortInclude)

  // Bocca generated code. bocca.protected.end(scijump.Event.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(scijump.Event.boccaForceUsePortInclude)
}

/**
 *  Return the event's header. The header is usually generated
 * by the framework and holds bookkeeping information
 */
::gov::cca::TypeMap
scijump::Event_impl::getHeader_impl () 

{
  // DO-NOT-DELETE splicer.begin(scijump.Event.getHeader)
  return header;
  // DO-NOT-DELETE splicer.end(scijump.Event.getHeader)
}

/**
 *  Returs the event's body. The body is the information the 
 * publisher is sending to the subscribers
 */
::gov::cca::TypeMap
scijump::Event_impl::getBody_impl () 

{
  // DO-NOT-DELETE splicer.begin(scijump.Event.getBody)
  return body;
  // DO-NOT-DELETE splicer.end(scijump.Event.getBody)
}

/**
 * Method:  packObj[]
 */
void
scijump::Event_impl::packObj_impl (
  /* in */::sidl::io::Serializer& ser ) 
{
  // DO-NOT-DELETE splicer.begin(scijump.Event.packObj)
  serializeTypeMap(header, ser);
  serializeTypeMap(body, ser);
  // DO-NOT-DELETE splicer.end(scijump.Event.packObj)
}

/**
 * Method:  unpackObj[]
 */
void
scijump::Event_impl::unpackObj_impl (
  /* in */::sidl::io::Deserializer& des ) 
{
  // DO-NOT-DELETE splicer.begin(scijump.Event.unpackObj)
  unserializeTypeMap(header, des);
  unserializeTypeMap(body, des);
  // DO-NOT-DELETE splicer.end(scijump.Event.unpackObj)
}


// DO-NOT-DELETE splicer.begin(scijump.Event._misc)
void serializeTypeMap(::gov::cca::TypeMap& tm, ::sidl::io::Serializer& ser) {
  //temp variables
  ::sidl::array<std::string> arr_s;
  ::sidl::array<int32_t> arr_i;
  ::sidl::array<int64_t> arr_l;
  ::sidl::array<float> arr_f;
  ::sidl::array<bool> arr_b;
  ::sidl::array<double> arr_d;
  ::sidl::array<fcomplex> arr_fc;
  ::sidl::array<dcomplex> arr_dc;

  if(tm._is_nil()) {
    ser.packInt("keys.length",0);
    return;
  }
  
  //first store digest
  sidl::array<std::string> keys =  tm.getAllKeys(Type_NoType);
  ser.packInt("keys.length", keys.length());
  for(int i=0; i<keys.length(); i++) {
    std::stringstream serkey;
    serkey << "key" << i;
    ser.packString(serkey.str(), keys.get(i));
    serkey << ".type";
    ser.packInt(serkey.str(),tm.typeOf(keys.get(i)));
  }

  //then actual data
  for(int i=0; i<keys.length(); i++) {
    gov::cca::Type t = tm.typeOf(keys.get(i));
    switch(t) {
    case Type_Int:
      ser.packInt(keys.get(i), tm.getInt(keys.get(i), 0));
      break;
    case Type_Long:
      ser.packLong(keys.get(i), tm.getLong(keys.get(i), 0));
      break;
    case Type_Float:
      ser.packFloat(keys.get(i), tm.getFloat(keys.get(i), 0.0));
      break;
    case Type_Double:
      ser.packDouble(keys.get(i), tm.getDouble(keys.get(i), 0.0));
      break;
    case Type_Fcomplex:
      ser.packFcomplex(keys.get(i), tm.getFcomplex(keys.get(i), 0.0));
      break;
    case Type_Dcomplex:
      ser.packDcomplex(keys.get(i), tm.getDcomplex(keys.get(i), 0.0));
      break;
    case Type_String:
      ser.packString(keys.get(i), tm.getString(keys.get(i), " "));
      break;
    case Type_Bool:
      ser.packBool(keys.get(i), tm.getBool(keys.get(i), false));
      break;
    case Type_IntArray:
      arr_i = tm.getIntArray(keys.get(i), NULL);
      ser.packIntArray(keys.get(i), arr_i, 0, arr_i.dimen(), false);
      break;
    case Type_LongArray:
      arr_l = tm.getLongArray(keys.get(i), NULL);
      ser.packLongArray(keys.get(i), arr_l, 0, arr_l.dimen(), false);
      break;
    case Type_FloatArray:
      arr_f = tm.getFloatArray(keys.get(i), NULL);
      ser.packFloatArray(keys.get(i), arr_f, 0, arr_f.dimen(), false);
      break;
    case Type_DoubleArray:
      arr_d = tm.getDoubleArray(keys.get(i), NULL);
      ser.packDoubleArray(keys.get(i), arr_d, 0, arr_d.dimen(), false);
      break;
    case Type_FcomplexArray:
      arr_fc = tm.getFcomplexArray(keys.get(i), NULL);
      ser.packFcomplexArray(keys.get(i), arr_fc, 0, arr_fc.dimen(), false);
      break;
    case Type_DcomplexArray:
      arr_dc = tm.getDcomplexArray(keys.get(i), NULL);
      ser.packDcomplexArray(keys.get(i), arr_dc, 0, arr_dc.dimen(), false);
      break;
    case Type_StringArray:
      arr_s = tm.getStringArray(keys.get(i), NULL);
      ser.packStringArray(keys.get(i), arr_s, 0, arr_s.dimen(), false);
      break;
    case Type_BoolArray:
      arr_b = tm.getBoolArray(keys.get(i), NULL);
      ser.packBoolArray(keys.get(i), arr_b, 0, arr_b.dimen(), false);
      break;
    }
  }
}

//*********************

void unserializeTypeMap(::gov::cca::TypeMap& tm, ::sidl::io::Deserializer& des) {
  
  //temp variables
  int32_t valu_i;
  int64_t valu_l;
  float valu_f;
  double valu_d;
  bool valu_b;
  string valu_s;
  fcomplex valu_fc;
  dcomplex valu_dc;
  ::sidl::array<std::string> arr_s;
  ::sidl::array<int32_t> arr_i;
  ::sidl::array<int64_t> arr_l;
  ::sidl::array<float> arr_f;
  ::sidl::array<bool> arr_b;
  ::sidl::array<double> arr_d;
  ::sidl::array<fcomplex> arr_fc;
  ::sidl::array<dcomplex> arr_dc;

  //this is a framework-dependent piece but since 
  //deserialization and creation of this Event object 
  //is initiated from Babel, we have no easy way of 
  //getting a typemap
  tm = ccaffeine::TypeMap::_create();
 
  //get digest of data
  int keys_length;
  des.unpackInt("keys.length", keys_length);
  if(keys_length < 1) return;
  sidl::array<std::string> keys = sidl::array<std::string>::create1d(keys_length);
  sidl::array<int> keys_type = sidl::array<int>::create1d(keys_length);
  for(int i=0; i<keys_length; i++) {
    std::stringstream deskey;
    deskey << "key" << i;
    string payload;
    des.unpackString(deskey.str(), payload);
    keys.set(i,payload);
    deskey << ".type";
    int payload_type;
    des.unpackInt(deskey.str(), payload_type);
    keys_type.set(i,payload_type);
  }

  //and then the data payload
  for(int i=0; i<keys.length(); i++) {
    gov::cca::Type t = (gov::cca::Type)(keys_type.get(i));
    switch(t) {
    case Type_Int:
      des.unpackInt(keys.get(i), valu_i);
      tm.putInt(keys.get(i), valu_i);
      break;
    case Type_Long:
      des.unpackLong(keys.get(i), valu_l);
      tm.putLong(keys.get(i), valu_l);
      break;
    case Type_Float:
      des.unpackFloat(keys.get(i), valu_f);
      tm.putLong(keys.get(i), valu_f);
      break;
    case Type_Double:
      des.unpackDouble(keys.get(i), valu_d);
      tm.putLong(keys.get(i), valu_d);
      break;
    case Type_Fcomplex:
      des.unpackFcomplex(keys.get(i), valu_fc);
      tm.putFcomplex(keys.get(i), valu_fc);
      break;
    case Type_Dcomplex:
      des.unpackDcomplex(keys.get(i), valu_dc);
      tm.putDcomplex(keys.get(i), valu_dc);
      break;
    case Type_String:
      des.unpackString(keys.get(i), valu_s);
      tm.putString(keys.get(i), valu_s);
      break;
    case Type_Bool:
      des.unpackBool(keys.get(i), valu_b);
      tm.putBool(keys.get(i), valu_b);
      break;
    case Type_IntArray:
      des.unpackIntArray(keys.get(i), arr_i, 0, 0, false);
      tm.putIntArray(keys.get(i), arr_i);
      break;
    case Type_LongArray:
      des.unpackLongArray(keys.get(i), arr_l, 0, 0, false);
      tm.putLongArray(keys.get(i), arr_l);
      break;
    case Type_FloatArray:
      des.unpackFloatArray(keys.get(i), arr_f, 0, 0, false);
      tm.putFloatArray(keys.get(i), arr_f);
      break;
    case Type_DoubleArray:
      des.unpackDoubleArray(keys.get(i), arr_d, 0, 0, false);
      tm.putDoubleArray(keys.get(i), arr_d);
      break;
    case Type_FcomplexArray:
      des.unpackFcomplexArray(keys.get(i), arr_fc, 0, 0, false);
      tm.putFcomplexArray(keys.get(i), arr_fc);
      break;
    case Type_DcomplexArray:
      des.unpackDcomplexArray(keys.get(i), arr_dc, 0, 0, false);
      tm.putDcomplexArray(keys.get(i), arr_dc);
      break;
    case Type_StringArray:
      des.unpackStringArray(keys.get(i), arr_s, 0, 0, false);
      tm.putStringArray(keys.get(i), arr_s);
      break;
    case Type_BoolArray:
      des.unpackBoolArray(keys.get(i), arr_b, 0, 0, false);
      tm.putBoolArray(keys.get(i), arr_b);
      break;
    }
  }
}
// DO-NOT-DELETE splicer.end(scijump.Event._misc)

