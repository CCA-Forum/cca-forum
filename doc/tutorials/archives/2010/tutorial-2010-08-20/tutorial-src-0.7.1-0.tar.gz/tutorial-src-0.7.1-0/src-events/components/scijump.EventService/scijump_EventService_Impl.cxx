// 
// File:          scijump_EventService_Impl.cxx
// Symbol:        scijump.EventService-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for scijump.EventService
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "scijump_EventService_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_ServiceRegistry_hxx
#include "gov_cca_ports_ServiceRegistry.hxx"
#endif
#ifndef included_scijump_EventServiceException_hxx
#include "scijump_EventServiceException.hxx"
#endif
#ifndef included_scijump_Topic_hxx
#include "scijump_Topic.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_gob.ccb_EventServiceException_hxx
#include "gob.ccb_EventServiceException.hxx"
#endif
#ifndef included_gob.ccb_Subscription_hxx
#include "gob.ccb_Subscription.hxx"
#endif
#ifndef included_gob.ccb_Topic_hxx
#include "gob.ccb_Topic.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(scijump.EventService._includes)

  // Insert-UserCode-Here {scijump.EventService._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(scijump.EventService._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(scijump.EventService._includes)

  // Insert-UserCode-Here {scijump.EventService._includes:epilog} (additional includes or code)

#include <iostream>
#include <cctype>
// DO-NOT-DELETE splicer.end(scijump.EventService._includes)

// special constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
scijump::EventService_impl::EventService_impl() : StubBase(reinterpret_cast< 
  void*>(::scijump::EventService::_wrapObj(reinterpret_cast< void*>(this))),
  false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(scijump.EventService._ctor2)
  // Insert-Code-Here {scijump.EventService._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(scijump.EventService._ctor2)
}

// user defined constructor
void scijump::EventService_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(scijump.EventService._ctor)
    
  // Insert-UserCode-Here {scijump.EventService._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(scijump.EventService._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR scijump.EventService: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(scijump.EventService._ctor)

  // Insert-UserCode-Here {scijump.EventService._ctor:epilog} (constructor method)

  // Insert-Code-Here {scijump.EventService._ctor} (constructor)
  // DO-NOT-DELETE splicer.end(scijump.EventService._ctor)
}

// user defined destructor
void scijump::EventService_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(scijump.EventService._dtor)
  // Insert-UserCode-Here {scijump.EventService._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(scijump.EventService._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR scijump.EventService: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(scijump.EventService._dtor) 

  // Insert-Code-Here {scijump.EventService._dtor} (destructor)
  // DO-NOT-DELETE splicer.end(scijump.EventService._dtor)
}

// static class initializer
void scijump::EventService_impl::_load() {
  // DO-NOT-DELETE splicer.begin(scijump.EventService._load)
  // Insert-Code-Here {scijump.EventService._load} (class initialization)
  // DO-NOT-DELETE splicer.end(scijump.EventService._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
scijump::EventService_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(scijump.EventService.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(scijump.EventService.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "scijump.EventService: Error casting self to gov::cca::Port");
  } 


  // Provide a gob.ccb.ports.PublisherEventService port with port name publish 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "publish", // port instance name
                   "gob.ccb.ports.PublisherEventService",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "scijump.EventService: Error calling addProvidesPort(port,"
        "\"publish\", \"gob.ccb.ports.PublisherEventService\", typeMap) ", -2);
    throw;
  }    

  // Provide a gob.ccb.ports.SubscriberEventService port with port name subscribe 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "subscribe", // port instance name
                   "gob.ccb.ports.SubscriberEventService",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "scijump.EventService: Error calling addProvidesPort(port,"
        "\"subscribe\", \"gob.ccb.ports.SubscriberEventService\", typeMap) ", -2);
    throw;
  }    

  // Use a gov.cca.ports.ServiceRegistry port with port name sr 
  try{
    this->d_services.registerUsesPort(
                   "sr", // port instance name
                   "gov.cca.ports.ServiceRegistry",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "scijump.EventService: Error calling registerUsesPort(\"sr\", "
       "\"gov.cca.ports.ServiceRegistry\", typeMap) ", -2);
    throw;
  }


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(scijump.EventService.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(scijump.EventService.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
scijump::EventService_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(scijump.EventService.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(scijump.EventService.boccaReleaseServices)
  this->d_services=0;


  // Un-provide gob.ccb.ports.PublisherEventService port with port name publish 
  try{
    services.removeProvidesPort("publish");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "scijump.EventService: Error calling removeProvidesPort("
              << "\"publish\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Un-provide gob.ccb.ports.SubscriberEventService port with port name subscribe 
  try{
    services.removeProvidesPort("subscribe");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "scijump.EventService: Error calling removeProvidesPort("
              << "\"subscribe\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release gov.cca.ports.ServiceRegistry port with port name sr 
  try{
    services.unregisterUsesPort("sr");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "scijump.EventService: Error calling unregisterUsesPort("
              << "\"sr\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(scijump.EventService.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(scijump.EventService.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
scijump::EventService_impl::boccaForceUsePortInclude_impl (
  /* in */::gov::cca::ports::ServiceRegistry& dummy0,
  /* in */::scijump::EventServiceException& dummy1,
  /* in */::gob::ccb::Subscription& dummy2,
  /* in */::scijump::Topic& dummy3,
  /* in */::gob::ccb::Topic& dummy4 ) 
{
  // DO-NOT-DELETE splicer.begin(scijump.EventService.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(scijump.EventService.boccaForceUsePortInclude)
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;
    (void)dummy3;
    (void)dummy4;

  // Bocca generated code. bocca.protected.end(scijump.EventService.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(scijump.EventService.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
scijump::EventService_impl::setServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(scijump.EventService.setServices)

  // Insert-UserCode-Here{scijump.EventService.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(scijump.EventService.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(scijump.EventService.setServices)
  frameworktm = d_services.createTypeMap();
  gov::cca::Port p = d_services.getPort("sr");
  if(p._is_nil()) {
    std::cerr << "no ServiceRegistry connected in setServices\n";
    return;
  }
  gov::cca::ports::ServiceRegistry sr = ::babel_cast< gov::cca::ports::ServiceRegistry >(p); 
  if (sr._is_nil()) {
    std::cerr << "invalid ServiceRegistry connected in setServices.\n";
    return;
  }

  //adding myself as both publisher and subscriber event service
  sr.addSingletonService("gob.ccb.ports.PublisherEventService", *this);
  sr.addSingletonService("gob.ccb.ports.SubscriberEventService", *this);

  d_services.releasePort("sr");  

  // DO-NOT-DELETE splicer.end(scijump.EventService.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
scijump::EventService_impl::releaseServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(scijump.EventService.releaseServices)

  // Insert-UserCode-Here {scijump.EventService.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(scijump.EventService.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(scijump.EventService.releaseServices)
    
  // DO-NOT-DELETE splicer.end(scijump.EventService.releaseServices)
}

/**
 *  Get a Topic by passing a name that has the form X.Y.Z. The
 * method creates a topic of topicName it if it doesn't exist.
 * @topicName - A dot delimited, hierarchical name of the topic
 * on which to publish. Wildcard characters are not
 * allowed for a topicName.
 * see also: event service overview document for more information
 * on topic naming.
 */
::gob::ccb::Topic
scijump::EventService_impl::getTopic_impl (
  /* in */const ::std::string& topicName ) 
// throws:
//    ::sidl::RuntimeException
//    ::gob::ccb::EventServiceException
{
  // DO-NOT-DELETE splicer.begin(scijump.EventService.getTopic)
  if (topicName.empty()) {
    scijump::EventServiceException ex = scijump::EventServiceException::_create();
    ex.setNote("Topic name is empty");
    throw ex;
  }

  //Check if Topic Name has '*'
  for (unsigned int i = 0; i < topicName.size(); i++) {
    if (topicName.at(i) == '*') {
      scijump::EventServiceException ex = scijump::EventServiceException::_create();
      ex.setNote("Topic Name format not supported:'*' not allowed");
      throw ex;
    }
  }

  //Convert to lowercase
  std::string topicStr = topicName;
  for (unsigned int i = 0; i < topicStr.size(); i++)
  {
    topicStr[i]=tolower(topicStr[i]);
  }

  gob::ccb::Topic topicPtr;
  scijump::Topic stopicPtr;
  TopicMap::iterator iter = topicMap.find(topicStr);
  if (iter == topicMap.end()) { // new Topic
    stopicPtr = scijump::Topic::_create();
    topicPtr = stopicPtr;
    stopicPtr.initialize(topicStr, frameworktm);
    topicMap[topicStr] = topicPtr;
  } else { // Topic already present
    topicPtr = iter->second;
    return topicPtr;
  }

  // for all Subscriptions:
  // check for matching topic name and add to newly created Topic's Subscriptions map
  for (SubscriptionMap::iterator subscriptionIter = subscriptionMap.begin();
       subscriptionIter != subscriptionMap.end(); subscriptionIter++) {
    std::string subscriptionName = (subscriptionIter->second).getSubscriptionName();
    if ((topicStr == subscriptionName)||(isMatch(topicStr, subscriptionName))) {
      if (topicPtr._is_nil()) {
        scijump::EventServiceException ex = scijump::EventServiceException::_create();
        ex.setNote("Topic Name format not supported:'*' not allowed");
        throw ex;
      }
      stopicPtr = babel_cast< scijump::Topic >(topicPtr);
      stopicPtr.addSubscription(topicStr, subscriptionIter->second);
    }

  }

  return topicPtr;
  // DO-NOT-DELETE splicer.end(scijump.EventService.getTopic)
}

/**
 *  Returns true if topic already exists, false otherwise 
 */
bool
scijump::EventService_impl::existsTopic_impl (
  /* in */const ::std::string& topicName ) 
{
  // DO-NOT-DELETE splicer.begin(scijump.EventService.existsTopic)
  gob::ccb::Topic topicPtr;
  TopicMap::iterator iter = topicMap.find(topicName);
  if (iter == topicMap.end()) { 
    return false;
  } else { 
    return true;
  }
  // DO-NOT-DELETE splicer.end(scijump.EventService.existsTopic)
}

/**
 * Subscribe to one or more topics. 
 * 
 * @subscriptionName - A dot delimited hierarchical name selecting
 * the list of topics to get events from. Wildcard 
 * characters (,?)  are allowed for a subscriptionName 
 * to denote more than one topic.
 * 
 * see also: event service overview document for more information
 * on subscription naming and wildcard characters.
 */
::gob::ccb::Subscription
scijump::EventService_impl::getSubscription_impl (
  /* in */const ::std::string& subscriptionName ) 
// throws:
//    ::sidl::RuntimeException
//    ::gob::ccb::EventServiceException
{
  // DO-NOT-DELETE splicer.begin(scijump.EventService.getSubscription)
  if (subscriptionName.empty()) {
    scijump::EventServiceException ex = scijump::EventServiceException::_create();
    ex.setNote("Subscription name is empty");
    throw ex;
  }

  //Convert to lowercase
  std::string subscriptionStr = subscriptionName;
  for (unsigned int i = 0; i < subscriptionStr.size(); i++)
  {
    subscriptionStr[i]=toupper(subscriptionStr[i]);
  }

  scijump::Subscription ssubscriptionPtr;
  gob::ccb::Subscription subscriptionPtr;
  SubscriptionMap::iterator iter = subscriptionMap.find(subscriptionStr);
  if (iter == subscriptionMap.end()) { // new Subscription
    ssubscriptionPtr = scijump::Subscription::_create(); 
    ssubscriptionPtr.initialize(subscriptionStr, frameworktm);
    subscriptionPtr = ssubscriptionPtr;
    subscriptionMap[subscriptionStr] = subscriptionPtr;
  } else { // Subscription already present
    subscriptionPtr = iter->second;
  }

  // for all Topics:
  // add newly created Subscription to matching Topic's Subscriptions map
  for (TopicMap::iterator topicIter = topicMap.begin(); topicIter != topicMap.end(); topicIter++) {
    std::string topicName = (topicIter->second).getTopicName();
    if ((topicName == subscriptionStr)||(isMatch(topicName, subscriptionStr))) {
      gob::ccb::Topic t = topicIter->second;
      if (t._is_nil()) {
	scijump::EventServiceException ex = scijump::EventServiceException::_create();
	ex.setNote("Topic pointer is null");
	throw ex;
      }
      scijump::Topic st = babel_cast< scijump::Topic >(t);
      st.addSubscription(topicName, subscriptionPtr);
    }
  }

  return subscriptionPtr;
  // DO-NOT-DELETE splicer.end(scijump.EventService.getSubscription)
}

/**
 *  Process published events. When the subscriber calls this method,
 * this thread or some other one delivers each event by calling
 * processEvent(...) on each listener belonging to each specific
 * Subscription 
 */
void
scijump::EventService_impl::processEvents_impl () 
// throws:
//    ::sidl::RuntimeException
//    ::gob::ccb::EventServiceException

{
  // DO-NOT-DELETE splicer.begin(scijump.EventService.processEvents)
  if (topicMap.empty()) {
    return;
  }

  for (TopicMap::iterator iter = topicMap.begin(); iter != topicMap.end(); iter++) {
    // Call processEvents() on each Topic
    gob::ccb::Topic t = iter->second;
    if (t._is_nil()) {
      scijump::EventServiceException ex = scijump::EventServiceException::_create();
      ex.setNote("Topic pointer is null");
      throw ex;
    }
    scijump::Topic st = babel_cast< scijump::Topic >(t);
    st.processEvents();
  }
  // DO-NOT-DELETE splicer.end(scijump.EventService.processEvents)
}


// DO-NOT-DELETE splicer.begin(scijump.EventService._misc)
bool scijump::EventService_impl::isMatch(const std::string& topicName, 
					 const std::string& subscriptionName)
{
  if(topicName == subscriptionName) return true;

  std::string::size_type s_star = subscriptionName.find('*');
  if(s_star != std::string::npos) {
    std::string word = subscriptionName.substr(0, s_star);
    std::string::size_type t_start = topicName.find(word);
    std::string::size_type s_newstar = 0;
    std::string::size_type t_end = 0;

    if(t_start == 0) {
      while(t_start != std::string::npos) {
        if(subscriptionName.length() == s_star) return true;

        t_end = t_start + word.length();
        s_newstar = subscriptionName.find('*',s_star+1);
        if(s_newstar == std::string::npos) s_newstar = subscriptionName.length();
        word = subscriptionName.substr(s_star+1, s_newstar);
        s_star = s_newstar;

        t_start = topicName.find(word,t_end+1);
      }
    }
  }

  std::string::size_type s_percent = subscriptionName.find('?');
  if(s_percent != std::string::npos) {
    std::string word = subscriptionName.substr(0, s_percent);
    std::string::size_type t_start = topicName.find(word);
    std::string::size_type s_newpercent = 0;
    std::string::size_type t_end = 0;

    if(t_start == 0) {
      while(t_start != std::string::npos) {
        if(subscriptionName.length() == s_percent) return true;

        t_end = t_start + word.length();
        s_newpercent = subscriptionName.find('?',s_percent+1);
        if(s_newpercent == std::string::npos) s_newpercent = subscriptionName.length();
        word = subscriptionName.substr(s_percent+1, s_newpercent);
        s_percent = s_newpercent;

        t_start = topicName.find(word,t_end+1);
        if(t_start != t_end+1) break;
      }
    }

  }

  return false;
}
// DO-NOT-DELETE splicer.end(scijump.EventService._misc)

