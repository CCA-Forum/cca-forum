// 
// File:          scijump_EventServiceException_Impl.cxx
// Symbol:        scijump.EventServiceException-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for scijump.EventServiceException
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "scijump_EventServiceException_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAExceptionType_hxx
#include "gov_cca_CCAExceptionType.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_io_Deserializer_hxx
#include "sidl_io_Deserializer.hxx"
#endif
#ifndef included_sidl_io_Serializer_hxx
#include "sidl_io_Serializer.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(scijump.EventServiceException._includes)

  // Insert-UserCode-Here {scijump.EventServiceException._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(scijump.EventServiceException._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(scijump.EventServiceException._includes)

  // Insert-UserCode-Here {scijump.EventServiceException._includes:epilog} (additional includes or code)

// Insert-Code-Here {scijump.EventServiceException._includes} (additional includes or code)
// DO-NOT-DELETE splicer.end(scijump.EventServiceException._includes)

// special constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
scijump::EventServiceException_impl::EventServiceException_impl() : StubBase(
  reinterpret_cast< void*>(::scijump::EventServiceException::_wrapObj(
  reinterpret_cast< void*>(this))),false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(scijump.EventServiceException._ctor2)
  // DO-NOT-DELETE splicer.end(scijump.EventServiceException._ctor2)
}

// user defined constructor
void scijump::EventServiceException_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(scijump.EventServiceException._ctor)
    
  // Insert-UserCode-Here {scijump.EventServiceException._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(scijump.EventServiceException._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR scijump.EventServiceException: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(scijump.EventServiceException._ctor)

  // Insert-UserCode-Here {scijump.EventServiceException._ctor:epilog} (constructor method)

  type = ::gov::cca::CCAExceptionType_Unexpected;
  // DO-NOT-DELETE splicer.end(scijump.EventServiceException._ctor)
}

// user defined destructor
void scijump::EventServiceException_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(scijump.EventServiceException._dtor)
  // Insert-UserCode-Here {scijump.EventServiceException._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(scijump.EventServiceException._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR scijump.EventServiceException: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(scijump.EventServiceException._dtor) 

  // Insert-Code-Here {scijump.EventServiceException._dtor} (destructor)
  // DO-NOT-DELETE splicer.end(scijump.EventServiceException._dtor)
}

// static class initializer
void scijump::EventServiceException_impl::_load() {
  // DO-NOT-DELETE splicer.begin(scijump.EventServiceException._load)
  // DO-NOT-DELETE splicer.end(scijump.EventServiceException._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  initialize[]
 */
void
scijump::EventServiceException_impl::initialize_impl (
  /* in */::gov::cca::CCAExceptionType type ) 
{
  // DO-NOT-DELETE splicer.begin(scijump.EventServiceException.initialize)
  this->type = type;
  // DO-NOT-DELETE splicer.end(scijump.EventServiceException.initialize)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
scijump::EventServiceException_impl::boccaForceUsePortInclude1_impl () 

{
  // DO-NOT-DELETE splicer.begin(scijump.EventServiceException.boccaForceUsePortInclude1)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(scijump.EventServiceException.boccaForceUsePortInclude1)

  // Bocca generated code. bocca.protected.end(scijump.EventServiceException.boccaForceUsePortInclude1)
  // DO-NOT-DELETE splicer.end(scijump.EventServiceException.boccaForceUsePortInclude1)
}

/**
 * Method:  getCCAExceptionType[]
 */
::gov::cca::CCAExceptionType
scijump::EventServiceException_impl::getCCAExceptionType_impl () 

{
  // DO-NOT-DELETE splicer.begin(scijump.EventServiceException.getCCAExceptionType)
  return type;
  // DO-NOT-DELETE splicer.end(scijump.EventServiceException.getCCAExceptionType)
}


// DO-NOT-DELETE splicer.begin(scijump.EventServiceException._misc)
// DO-NOT-DELETE splicer.end(scijump.EventServiceException._misc)

