// 
// File:          scijump_EventService_Impl.hxx
// Symbol:        scijump.EventService-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for scijump.EventService
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_scijump_EventService_Impl_hxx
#define included_scijump_EventService_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_scijump_EventService_IOR_h
#include "scijump_EventService_IOR.h"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Component_hxx
#include "gov_cca_Component.hxx"
#endif
#ifndef included_gov_cca_ComponentRelease_hxx
#include "gov_cca_ComponentRelease.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_ServiceRegistry_hxx
#include "gov_cca_ports_ServiceRegistry.hxx"
#endif
#ifndef included_scijump_EventService_hxx
#include "scijump_EventService.hxx"
#endif
#ifndef included_scijump_EventServiceException_hxx
#include "scijump_EventServiceException.hxx"
#endif
#ifndef included_scijump_Topic_hxx
#include "scijump_Topic.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_gob.ccb_EventServiceException_hxx
#include "gob.ccb_EventServiceException.hxx"
#endif
#ifndef included_gob.ccb_Subscription_hxx
#include "gob.ccb_Subscription.hxx"
#endif
#ifndef included_gob.ccb_Topic_hxx
#include "gob.ccb_Topic.hxx"
#endif
#ifndef included_gob.ccb_ports_PublisherEventService_hxx
#include "gob.ccb_ports_PublisherEventService.hxx"
#endif
#ifndef included_gob.ccb_ports_SubscriberEventService_hxx
#include "gob.ccb_ports_SubscriberEventService.hxx"
#endif


// DO-NOT-DELETE splicer.begin(scijump.EventService._hincludes)

#include <map>


// DO-NOT-DELETE splicer.end(scijump.EventService._hincludes)

namespace scijump { 

  /**
   * Symbol "scijump.EventService" (version 0.0)
   */
  class EventService_impl : public virtual ::scijump::EventService 
  // DO-NOT-DELETE splicer.begin(scijump.EventService._inherits)
  // DO-NOT-DELETE splicer.end(scijump.EventService._inherits)

  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(scijump.EventService._implementation)

  // Insert-UserCode-Here(scijump.EventService._implementation)

  // Bocca generated code. bocca.protected.begin(scijump.EventService._implementation)
  
   gov::cca::Services    d_services; // our cca handle.
 

  // Bocca generated code. bocca.protected.end(scijump.EventService._implementation)

    typedef std::map<std::string, gob::ccb::Subscription> SubscriptionMap;
    typedef std::map<std::string, gob::ccb::Topic> TopicMap;

    TopicMap topicMap;
    SubscriptionMap subscriptionMap;
    ::gov::cca::TypeMap frameworktm;

    bool isMatch(const std::string& topicName, 
		 const std::string& subscriptionName);
    // DO-NOT-DELETE splicer.end(scijump.EventService._implementation)

  public:
    // default constructor, used for data wrapping(required)
    EventService_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
      EventService_impl( struct scijump_EventService__object * ior ) : StubBase(
        ior,true), 
      ::gov::cca::Component((ior==NULL) ? NULL : &((*ior).d_gov_cca_component)),
      ::gov::cca::ComponentRelease((ior==NULL) ? NULL : &((
        *ior).d_gov_cca_componentrelease)),
      ::gov::cca::Port((ior==NULL) ? NULL : &((*ior).d_gov_cca_port)),
      ::gob::ccb::ports::PublisherEventService((ior==NULL) ? NULL : &((
        *ior).d_gob.ccb_ports_publishereventservice)),
    ::gob::ccb::ports::SubscriberEventService((ior==NULL) ? NULL : &((
      *ior).d_gob.ccb_ports_subscribereventservice)) , _wrapped(false) {_ctor(
      );}


    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~EventService_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    void
    boccaSetServices_impl (
      /* in */::gov::cca::Services& services
    )
    // throws:
    //    ::gov::cca::CCAException
    //    ::sidl::RuntimeException
    ;

    /**
     * user defined non-static method.
     */
    void
    boccaReleaseServices_impl (
      /* in */::gov::cca::Services& services
    )
    // throws:
    //    ::gov::cca::CCAException
    //    ::sidl::RuntimeException
    ;


    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude_impl (
      /* in */::gov::cca::ports::ServiceRegistry& dummy0,
      /* in */::scijump::EventServiceException& dummy1,
      /* in */::gob::ccb::Subscription& dummy2,
      /* in */::scijump::Topic& dummy3,
      /* in */::gob::ccb::Topic& dummy4
    )
    ;


    /**
     *  Starts up a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning services and setServices:
     * 
     * The component interaction with the CCA framework
     * and Ports begins on the call to setServices by the framework.
     * 
     * This function is called exactly once for each instance created
     * by the framework.
     * 
     * The argument services will never be nil/null.
     * 
     * Those uses ports which are automatically connected by the framework
     * (so-called service-ports) may be obtained via getPort during
     * setServices.
     */
    void
    setServices_impl (
      /* in */::gov::cca::Services& services
    )
    // throws:
    //    ::gov::cca::CCAException
    //    ::sidl::RuntimeException
    ;


    /**
     * Shuts down a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning services and setServices:
     * 
     * This function is called exactly once for each callback registered
     * through Services.
     * 
     * The argument services will never be nil/null.
     * The argument services will always be the same as that received in
     * setServices.
     * 
     * During this call the component should release any interfaces
     * acquired by getPort().
     * 
     * During this call the component should reset to nil any stored
     * reference to services.
     * 
     * After this call, the component instance will be removed from the
     * framework. If the component instance was created by the
     * framework, it will be destroyed, not recycled, The behavior of
     * any port references obtained from this component instance and
     * stored elsewhere becomes undefined.
     * 
     * Notes for the component implementor:
     * 1) The component writer may perform blocking activities
     * within releaseServices, such as waiting for remote computations
     * to shutdown.
     * 2) It is good practice during releaseServices for the component
     * writer to remove or unregister all the ports it defined.
     */
    void
    releaseServices_impl (
      /* in */::gov::cca::Services& services
    )
    // throws:
    //    ::gov::cca::CCAException
    //    ::sidl::RuntimeException
    ;


    /**
     *  Get a Topic by passing a name that has the form X.Y.Z. The
     * method creates a topic of topicName it if it doesn't exist.
     * @topicName - A dot delimited, hierarchical name of the topic
     * on which to publish. Wildcard characters are not
     * allowed for a topicName.
     * see also: event service overview document for more information
     * on topic naming.
     */
    ::gob::ccb::Topic
    getTopic_impl (
      /* in */const ::std::string& topicName
    )
    // throws:
    //    ::sidl::RuntimeException
    //    ::gob::ccb::EventServiceException
    ;


    /**
     *  Returns true if topic already exists, false otherwise 
     */
    bool
    existsTopic_impl (
      /* in */const ::std::string& topicName
    )
    ;


    /**
     * Subscribe to one or more topics. 
     * 
     * @subscriptionName - A dot delimited hierarchical name selecting
     * the list of topics to get events from. Wildcard 
     * characters (,?)  are allowed for a subscriptionName 
     * to denote more than one topic.
     * 
     * see also: event service overview document for more information
     * on subscription naming and wildcard characters.
     */
    ::gob::ccb::Subscription
    getSubscription_impl (
      /* in */const ::std::string& subscriptionName
    )
    // throws:
    //    ::sidl::RuntimeException
    //    ::gob::ccb::EventServiceException
    ;


    /**
     *  Process published events. When the subscriber calls this method,
     * this thread or some other one delivers each event by calling
     * processEvent(...) on each listener belonging to each specific
     * Subscription 
     */
    void
    processEvents_impl() // throws:
    //    ::sidl::RuntimeException
    //    ::gob::ccb::EventServiceException
    ;
  };  // end class EventService_impl

} // end namespace scijump

// DO-NOT-DELETE splicer.begin(scijump.EventService._hmisc)
// DO-NOT-DELETE splicer.end(scijump.EventService._hmisc)

#endif
