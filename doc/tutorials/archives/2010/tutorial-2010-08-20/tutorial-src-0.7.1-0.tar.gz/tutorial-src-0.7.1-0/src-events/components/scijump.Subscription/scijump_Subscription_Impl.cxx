// 
// File:          scijump_Subscription_Impl.cxx
// Symbol:        scijump.Subscription-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for scijump.Subscription
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "scijump_Subscription_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_TypeMap_hxx
#include "gov_cca_TypeMap.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_gob.ccb_Event_hxx
#include "gob.ccb_Event.hxx"
#endif
#ifndef included_gob.ccb_EventListener_hxx
#include "gob.ccb_EventListener.hxx"
#endif
#ifndef included_gob.ccb_EventServiceException_hxx
#include "gob.ccb_EventServiceException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(scijump.Subscription._includes)

  // Insert-UserCode-Here {scijump.Subscription._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(scijump.Subscription._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(scijump.Subscription._includes)

  // Insert-UserCode-Here {scijump.Subscription._includes:epilog} (additional includes or code)

#include <scijump_EventServiceException.hxx>
#include <iostream>
// DO-NOT-DELETE splicer.end(scijump.Subscription._includes)

// special constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
scijump::Subscription_impl::Subscription_impl() : StubBase(reinterpret_cast< 
  void*>(::scijump::Subscription::_wrapObj(reinterpret_cast< void*>(this))),
  false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(scijump.Subscription._ctor2)
  // DO-NOT-DELETE splicer.end(scijump.Subscription._ctor2)
}

// user defined constructor
void scijump::Subscription_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(scijump.Subscription._ctor)
    
  // Insert-UserCode-Here {scijump.Subscription._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(scijump.Subscription._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR scijump.Subscription: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(scijump.Subscription._ctor)

  // Insert-UserCode-Here {scijump.Subscription._ctor:epilog} (constructor method)

  // Insert-Code-Here {scijump.Subscription._ctor} (constructor)
  // DO-NOT-DELETE splicer.end(scijump.Subscription._ctor)
}

// user defined destructor
void scijump::Subscription_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(scijump.Subscription._dtor)
  // Insert-UserCode-Here {scijump.Subscription._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(scijump.Subscription._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR scijump.Subscription: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(scijump.Subscription._dtor) 

  // Insert-Code-Here {scijump.Subscription._dtor} (destructor)
  // DO-NOT-DELETE splicer.end(scijump.Subscription._dtor)
}

// static class initializer
void scijump::Subscription_impl::_load() {
  // DO-NOT-DELETE splicer.begin(scijump.Subscription._load)
  // DO-NOT-DELETE splicer.end(scijump.Subscription._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  initialize[]
 */
void
scijump::Subscription_impl::initialize_impl (
  /* in */const ::std::string& subscriptionName,
  /* in */::gov::cca::TypeMap& tm ) 
{
  // DO-NOT-DELETE splicer.begin(scijump.Subscription.initialize)
  this->subscriptionName = subscriptionName;
  this->framework = tm;
  // DO-NOT-DELETE splicer.end(scijump.Subscription.initialize)
}

/**
 * Method:  processEvents[]
 */
void
scijump::Subscription_impl::processEvents_impl (
  /* in array<gob.ccb.Event> */::sidl::array< ::gob::ccb::Event>& eventList ) 
{
  // DO-NOT-DELETE splicer.begin(scijump.Subscription.processEvents)
  if (eventListenerMap.empty()) {
    return;
  }

  if (eventList.length() == 0) {
    return;
  }

  for (EventListenerMap::iterator eventListenerIter = eventListenerMap.begin();
       eventListenerIter != eventListenerMap.end(); eventListenerIter++) {

    // Call processEvent() on each Listener
    for (unsigned int i = 0; i < eventList.length(); i++) {
      // Call processEvent() on each event
      (eventListenerIter->second).processEvent(subscriptionName, eventList.get(i));
    }
  }
  // DO-NOT-DELETE splicer.end(scijump.Subscription.processEvents)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
scijump::Subscription_impl::boccaForceUsePortInclude_impl (
  /* in */::gob::ccb::Event& dummy0 ) 
{
  // DO-NOT-DELETE splicer.begin(scijump.Subscription.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(scijump.Subscription.boccaForceUsePortInclude)
    (void)dummy0;

  // Bocca generated code. bocca.protected.end(scijump.Subscription.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(scijump.Subscription.boccaForceUsePortInclude)
}

/**
 * Adds a listener to the collection of listeners for this Subscription.
 * 
 * @listenerKey - It is used as an index to a unique mapping
 * and the parameter \em theListener is a
 * reference to the /em Listener object.
 * @theListener - A pointer to the object that will listen for events.
 */
void
scijump::Subscription_impl::registerEventListener_impl (
  /* in */const ::std::string& listenerKey,
  /* in */::gob::ccb::EventListener& theListener ) 
// throws:
//    ::sidl::RuntimeException
//    ::gob::ccb::EventServiceException
{
  // DO-NOT-DELETE splicer.begin(scijump.Subscription.registerEventListener)
  if (listenerKey.empty()) {
    EventServiceException ex = EventServiceException::_create();
    ex.setNote("Listener key is empty");
    throw ex; 
  }

  if (theListener._is_nil()) {
    EventServiceException ex = EventServiceException::_create();
    ex.setNote("Listener pointer is nil");
    throw ex; 
  }
  EventListenerMap::iterator iter =  eventListenerMap.find(listenerKey);
  if (iter != eventListenerMap.end()) {
    EventServiceException ex = EventServiceException::_create();
    ex.setNote("Listener key already present");
    throw ex; 
  }

  eventListenerMap[listenerKey] = theListener;
  // DO-NOT-DELETE splicer.end(scijump.Subscription.registerEventListener)
}

/**
 * Removes a listener from the collection of listeners for this Topic.
 * @listenerKey - It is used as an index to remove this listener.
 */
void
scijump::Subscription_impl::unregisterEventListener_impl (
  /* in */const ::std::string& listenerKey ) 
{
  // DO-NOT-DELETE splicer.begin(scijump.Subscription.unregisterEventListener)
  if (listenerKey.empty()) {
    EventServiceException ex = EventServiceException::_create();
    ex.setNote("Listener key is empty");
    throw ex; 
  }

  EventListenerMap::iterator iter =  eventListenerMap.find(listenerKey);
  if (iter == eventListenerMap.end()) {
    EventServiceException ex = EventServiceException::_create();
    ex.setNote("Listener key is not registered");
    throw ex; 
  }

  eventListenerMap.erase(iter);
  // DO-NOT-DELETE splicer.end(scijump.Subscription.unregisterEventListener)
}

/**
 *  Returns the name for this Subscription object 
 */
::std::string
scijump::Subscription_impl::getSubscriptionName_impl () 

{
  // DO-NOT-DELETE splicer.begin(scijump.Subscription.getSubscriptionName)
  return subscriptionName;
  // DO-NOT-DELETE splicer.end(scijump.Subscription.getSubscriptionName)
}


// DO-NOT-DELETE splicer.begin(scijump.Subscription._misc)
// DO-NOT-DELETE splicer.end(scijump.Subscription._misc)

