# LaTeX2HTML 2008 (1.71)
# Associate images original text with physical files.


$key = q/displaystyleleft(vphantom{array{{c}0<row_mark>frac{1}{epsilon}left(phi_1(1-phi_1)(phi_1-phi_{th})right)<row_mark>(phi_1-phi_2)array{}right.;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="89" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img24.png"
 ALT="$\displaystyle \left(\vphantom{ \begin{array}{c} 0   \frac{1}{\epsilon} \left(...
...\phi_1) (\phi_1 - \phi_{th}) \right)   (\phi_1 - \phi_2) \end{array} }\right.$">|; 

$key = q/displaystyle{frac{{phi_{i,j+1}-2phi_{ij}+phi_{i,j-1}}}{{(Deltay)^2}}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="174" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img39.png"
 ALT="$\displaystyle {\frac{{ \phi_{i,j+1} - 2\phi_{ij} + \phi_{i,j-1} }}{{ (\Delta y)^2}}}$">|; 

$key = q/Phi;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img45.png"
 ALT="$ \Phi$">|; 

$key = q/displaystyle{frac{{Deltat}}{{2}}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="31" HEIGHT="62" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img48.png"
 ALT="$\displaystyle {\frac{{\Delta t}}{{2}}}$">|; 

$key = q/bgroupcolor{Green}phi_{2}^{}egroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img29.png"
 ALT="\bgroup\color{Green}$ \phi_{2}^{}$\egroup">|; 

$key = q/displaystyleleft(vphantom{exp(-a(mathbf{x}-mathbf{x}_1)^2)+exp(-a(mathbf{x}-mathbf{x}_2)^2)}right.;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="41" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img35.png"
 ALT="$\displaystyle \left(\vphantom{ \exp( - a(\mathbf{x}- \mathbf{x}_1)^2 ) + \exp( - a (\mathbf{x}- \mathbf{x}_2)^2) }\right.$">|; 

$key = q/approx;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="$ \approx$">|; 

$key = q/phi_{{2}}^{};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img53.png"
 ALT="$ \phi_{{2}}^{}$">|; 

$key = q/bgroupcolor{Green}Deltaegroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img42.png"
 ALT="\bgroup\color{Green}$ \Delta$\egroup">|; 

$key = q/bgroupcolor{Green}phi_{1}^{}egroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img33.png"
 ALT="\bgroup\color{Green}$ \phi_{1}^{}$\egroup">|; 

$key = q/bgroupcolor{black}phi_{{1}}^{}egroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img54.png"
 ALT="\bgroup\color{black}$ \phi_{{1}}^{}$\egroup">|; 

$key = q/Delta;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$ \Delta$">|; 

$key = q/{center}vbox{input{titlepage}}{center};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="612" HEIGHT="101" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\begin{center}\vbox{\input{titlepage}
}\end{center}">|; 

$key = q/displaystyle{frac{{dmathbf{Phi}}}{{dt}}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img46.png"
 ALT="$\displaystyle {\frac{{d \mathbf{\Phi}}}{{d t}}}$">|; 

$key = q/bgroupcolor{Green}piegroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="\bgroup\color{Green}$ \pi$\egroup">|; 

$key = q/displaystyleleft.vphantom{exp(-a(mathbf{x}-mathbf{x}_1)^2)+exp(-a(mathbf{x}-mathbf{x}_2)^2)}right);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="41" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img36.png"
 ALT="$\displaystyle \left.\vphantom{ \exp( - a(\mathbf{x}- \mathbf{x}_1)^2 ) + \exp( - a (\mathbf{x}- \mathbf{x}_2)^2) }\right)$">|; 

$key = q/displaystylembox{on{partial{mathcal{D}}{};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="55" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="$\displaystyle \mbox{on
$\partial {\mathcal{D}}$}$">|; 

$key = q/displaystyleDelta;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img47.png"
 ALT="$\displaystyle \Delta$">|; 

$key = q/displaystylePhi;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="$\displaystyle \Phi$">|; 

$key = q/displaystylephi_{1}^{};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img34.png"
 ALT="$\displaystyle \phi_{1}^{}$">|; 

$key = q/{frac{{4}}{{1+x^2}}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="40" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="$ {\frac{{4}}{{1+x^2}}}$">|; 

$key = q/pi;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="$ \pi$">|; 

$key = q/bgroupcolor{Green}mathcal{D}egroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="\bgroup\color{Green}$ \mathcal {D}$\egroup">|; 

$key = q/{frac{{1}}{{3}}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="40" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="$ {\frac{{1}}{{3}}}$">|; 

$key = q/displaystylenabla;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="$\displaystyle \nabla$">|; 

$key = q/displaystyleleft(vphantom{array{{c}epsilonnabla^2phi_0<row_mark>epsilonnabla^2phi_1<row_mark>epsilonnabla^2phi_2array{}right.;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="89" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="$\displaystyle \left(\vphantom{ \begin{array}{c} \epsilon \nabla^2 \phi_0   \epsilon \nabla^2 \phi_1   \epsilon \nabla^2 \phi_2 \end{array} }\right.$">|; 

$key = q/bgroupcolor{Green}nabla^{2}_{}egroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img30.png"
 ALT="\bgroup\color{Green}$ \nabla^{2}_{}$\egroup">|; 

$key = q/uparrow;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="$ \uparrow$">|; 

$key = q/phi_{{1}}^{};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img52.png"
 ALT="$ \phi_{{1}}^{}$">|; 

$key = q/bgroupcolor{Green}epsilonegroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img27.png"
 ALT="\bgroup\color{Green}$ \epsilon$\egroup">|; 

$key = q/displaystylephi;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img37.png"
 ALT="$\displaystyle \phi$">|; 

$key = q/bgroupcolor{Green}Rightarrowegroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img55.png"
 ALT="\bgroup\color{Green}$ \Rightarrow$\egroup">|; 

$key = q/bgroupcolor{Green}phi_{{2}}^{}egroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="\bgroup\color{Green}$ \phi_{{2}}^{}$\egroup">|; 

$key = q/Rightarrow;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="$ \Rightarrow$">|; 

$key = q/bgroupcolor{Green}Phiegroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img44.png"
 ALT="\bgroup\color{Green}$ \Phi$\egroup">|; 

$key = q/displaystyleleft.vphantom{array{{c}epsilonnabla^2phi_0<row_mark>epsilonnabla^2phi_1<row_mark>epsilonnabla^2phi_2array{}right);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="89" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img23.png"
 ALT="$\displaystyle \left.\vphantom{ \begin{array}{c} \epsilon \nabla^2 \phi_0   \epsilon \nabla^2 \phi_1   \epsilon \nabla^2 \phi_2 \end{array} }\right)$">|; 

$key = q/displaystylearray{{c}epsilonnabla^2phi_0<row_mark>epsilonnabla^2phi_1<row_mark>epsilonnabla^2phi_2array{;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="70" HEIGHT="89" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="$\displaystyle \begin{array}{c} \epsilon \nabla^2 \phi_0   \epsilon \nabla^2 \phi_1   \epsilon \nabla^2 \phi_2 \end{array}$">|; 

$key = q/displaystylearray{{c}0<row_mark>frac{1}{epsilon}left(phi_1(1-phi_1)(phi_1-phi_{th})right)<row_mark>(phi_1-phi_2)array{;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="214" HEIGHT="89" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img25.png"
 ALT="$\displaystyle \begin{array}{c} 0   \frac{1}{\epsilon} \left( \phi_1 ( 1 - \phi_1) (\phi_1 - \phi_{th}) \right)   (\phi_1 - \phi_2) \end{array}$">|; 

$key = q/{frac{{4}}{{5}}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="40" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="$ {\frac{{4}}{{5}}}$">|; 

$key = q/bgroupcolor{Green}phi_{0}^{}egroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img32.png"
 ALT="\bgroup\color{Green}$ \phi_{0}^{}$\egroup">|; 

$key = q/bgroupcolor{Green}phiegroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img41.png"
 ALT="\bgroup\color{Green}$ \phi$\egroup">|; 

$key = q/bgroupcolor{Green}phi_{{th}}^{}egroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img28.png"
 ALT="\bgroup\color{Green}$ \phi_{{th}}^{}$\egroup">|; 

$key = q/displaystyle{frac{{partialmathbf{Phi}}}{{partialt}}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="35" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="$\displaystyle {\frac{{\partial \mathbf{\Phi}}}{{\partial t}}}$">|; 

$key = q/phi_{{0}}^{};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img51.png"
 ALT="$ \phi_{{0}}^{}$">|; 

$key = q/bgroupcolor{Green}phi_{{1}}^{}egroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="\bgroup\color{Green}$ \phi_{{1}}^{}$\egroup">|; 

$key = q/displaystylenabla^{2}_{};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="41" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="$\displaystyle \nabla^{2}_{}$">|; 

$key = q/bgroupcolor{Green}phi_{{ij}}^{}egroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img40.png"
 ALT="\bgroup\color{Green}$ \phi_{{ij}}^{}$\egroup">|; 

$key = q/displaystyleleft(vphantom{F(mathbf{Phi}^n,nDeltat)+F(mathbf{Phi}^{(1)},(n+1)Deltat)}right.;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img49.png"
 ALT="$\displaystyle \left(\vphantom{ F(\mathbf{\Phi}^n, n
\Delta t) + F(\mathbf{\Phi}^{(1)}, (n+1) \Delta t) }\right.$">|; 

$key = q/displaystyleleft.vphantom{F(mathbf{Phi}^n,nDeltat)+F(mathbf{Phi}^{(1)},(n+1)Deltat)}right);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img50.png"
 ALT="$\displaystyle \left.\vphantom{ F(\mathbf{\Phi}^n, n
\Delta t) + F(\mathbf{\Phi}^{(1)}, (n+1) \Delta t) }\right)$">|; 

$key = q/bgroupcolor{Green}leqegroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img31.png"
 ALT="\bgroup\color{Green}$ \leq$\egroup">|; 

$key = q/bgroupcolor{Green}proptoegroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img43.png"
 ALT="\bgroup\color{Green}$ \propto$\egroup">|; 

$key = q/displaystyle{frac{{phi_{i+1,j}-2phi_{ij}+phi_{i-1,j}}}{{(Deltax)^2}}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="174" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img38.png"
 ALT="$\displaystyle {\frac{{ \phi_{i+1,j} - 2\phi_{ij} + \phi_{i-1,j} }}{{ (\Delta x)^2}}}$">|; 

$key = q/displaystyleleft.vphantom{array{{c}0<row_mark>frac{1}{epsilon}left(phi_1(1-phi_1)(phi_1-phi_{th})right)<row_mark>(phi_1-phi_2)array{}right);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="89" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="$\displaystyle \left.\vphantom{ \begin{array}{c} 0   \frac{1}{\epsilon} \left(...
...\phi_1) (\phi_1 - \phi_{th}) \right)   (\phi_1 - \phi_2) \end{array} }\right)$">|; 

$key = q/{frac{{1}}{{6}}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="40" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="$ {\frac{{1}}{{6}}}$">|; 

$key = q/bgroupcolor{Green}phi_{{0}}^{}egroup;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="\bgroup\color{Green}$ \phi_{{0}}^{}$\egroup">|; 

1;

