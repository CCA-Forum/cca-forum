/*
 * File:          functions_LinearFunction_Impl.c
 * Symbol:        functions.LinearFunction-v1.0
 * Symbol Type:   class
 * Babel Version: 0.10.12
 * Description:   Server-side implementation for functions.LinearFunction
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 * babel-version = 0.10.12
 * xml-url       = /san/cca/elwasifw/tutorial-src/components/../xml_repository/functions.LinearFunction-v1.0.xml
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "functions.LinearFunction" (version 1.0)
 */

#include "functions_LinearFunction_Impl.h"

/* DO-NOT-DELETE splicer.begin(functions.LinearFunction._includes) */
/* Put additional includes or other arbitrary code here... */

#include <stdio.h>
#include "sidl_Exception.h"

#if (!defined NULL)
#define NULL 0
#endif
/* DO-NOT-DELETE splicer.end(functions.LinearFunction._includes) */

/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction__load(
  void)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._load) */
  /* Insert-Code-Here {functions.LinearFunction._load} (static class initializer method) */
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction._load) */
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction__ctor(
  /* in */ functions_LinearFunction self)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._ctor) */
  /* Insert the implementation of the constructor method here... */

  /* Allocate memory for the private data of this component */
  struct functions_LinearFunction__data *pdptr = (struct functions_LinearFunction__data*) 
    malloc(sizeof(struct functions_LinearFunction__data));
  if (pdptr) {
    /* Initialize the framework Services handle */
    pdptr->frameworkServices = NULL;
  }
  functions_LinearFunction__set_data(self, pdptr);
  
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction._ctor) */
}

/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction__dtor(
  /* in */ functions_LinearFunction self)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._dtor) */
  /* Insert the implementation of the destructor method here... */
  
  struct functions_LinearFunction__data *pdptr;
  
  /* Access private data structure */
  pdptr = functions_LinearFunction__get_data(self);
  if (pdptr) {
    if (pdptr->frameworkServices) {
      gov_cca_Services_deleteRef(pdptr->frameworkServices);
    }
    pdptr->frameworkServices = NULL;
    free(pdptr); 
    functions_LinearFunction__set_data(self, NULL);
  }
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction._dtor) */
}

/*
 * Method:  init[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_init"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction_init(
  /* in */ functions_LinearFunction self,
  /* in array<double> */ struct sidl_double__array* params)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.init) */
  /* Insert the implementation of the init method here... */
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction.init) */
}

/*
 * Method:  evaluate[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_evaluate"

#ifdef __cplusplus
extern "C"
#endif
double
impl_functions_LinearFunction_evaluate(
  /* in */ functions_LinearFunction self,
  /* in */ double x)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.evaluate) */
  /* Insert the implementation of the evaluate method here... */

  return 12.0 * x + 3.2;

  /* DO-NOT-DELETE splicer.end(functions.LinearFunction.evaluate) */
}

/*
 * Method:  setServices[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_setServices"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction_setServices(
  /* in */ functions_LinearFunction self,
  /* in */ gov_cca_Services servicesHandle,
  /* out */ sidl_BaseInterface *_ex)
{
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.setServices) */
  /* Insert the implementation of the setServices method here... */

  sidl_BaseInterface exception = NULL;

  struct functions_LinearFunction__data *pd;
  
  /* Access private data structure */
  pd = functions_LinearFunction__get_data(self);
  if (pd->frameworkServices) {
    /* remove reference to previous services object */
    gov_cca_Services_deleteRef(pd->frameworkServices);
  }
  pd->frameworkServices = servicesHandle;
  if (!servicesHandle) return;

  gov_cca_Services_addRef(servicesHandle);
  
  /* Create a typemap for the FunctionPort */
  gov_cca_TypeMap tm = gov_cca_Services_createTypeMap(pd->frameworkServices, &exception);
  if (SIDL_CATCH(exception, "gov.cca.CCAException")) {
    fprintf(stderr, "Exception:: %s:%d: gov::cca::TypeMap was not created\n",
	    __FILE__, __LINE__);
    SIDL_CLEAR(exception);
    exit(1);
  }
  if (tm == NULL) {
    fprintf(stderr, "Error:: %s:%d: gov::cca::TypeMap is nil\n",
	    __FILE__, __LINE__);
    exit(1);  
  } 
  
  /* Provide a FunctionPort */
  gov_cca_Port port = gov_cca_Port__cast(self);
  if (port == NULL) {
    fprintf(stderr, "Error:: %s:%d: Error casting self to gov::cca::Port \n",
	    __FILE__, __LINE__);
    exit(1);
  } 
  
  gov_cca_Services_addProvidesPort(pd->frameworkServices,   
				   port,
				   "FunctionPort",
				   "function.FunctionPort",
				   tm,
				   &exception);
  if (SIDL_CATCH(exception, "gov.cca.CCAException")) {
    fprintf(stderr, "Exception:: %s:%d: Could not register function.FunctionPort provides port\n",
	    __FILE__, __LINE__);
    SIDL_CLEAR(exception);
    exit(1);
  }
  
  /* Register with framework for component release */
  gov_cca_ComponentRelease cr = gov_cca_ComponentRelease__cast(self);
  if (cr != NULL) {
    gov_cca_Services_registerForRelease(pd->frameworkServices, cr, &exception);
  }
  
  return;
  
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction.setServices) */
}
/* Babel internal methods, Users should not edit below this line. */
struct gov_cca_CCAException__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_CCAException(char* url,
  sidl_BaseInterface *_ex) {
  return gov_cca_CCAException__connect(url, _ex);
}
char * impl_functions_LinearFunction_fgetURL_gov_cca_CCAException(struct 
  gov_cca_CCAException__object* obj) {
  return gov_cca_CCAException__getURL(obj);
}
struct function_FunctionPort__object* 
  impl_functions_LinearFunction_fconnect_function_FunctionPort(char* url,
  sidl_BaseInterface *_ex) {
  return function_FunctionPort__connect(url, _ex);
}
char * impl_functions_LinearFunction_fgetURL_function_FunctionPort(struct 
  function_FunctionPort__object* obj) {
  return function_FunctionPort__getURL(obj);
}
struct gov_cca_Services__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Services(char* url,
  sidl_BaseInterface *_ex) {
  return gov_cca_Services__connect(url, _ex);
}
char * impl_functions_LinearFunction_fgetURL_gov_cca_Services(struct 
  gov_cca_Services__object* obj) {
  return gov_cca_Services__getURL(obj);
}
struct sidl_ClassInfo__object* 
  impl_functions_LinearFunction_fconnect_sidl_ClassInfo(char* url,
  sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connect(url, _ex);
}
char * impl_functions_LinearFunction_fgetURL_sidl_ClassInfo(struct 
  sidl_ClassInfo__object* obj) {
  return sidl_ClassInfo__getURL(obj);
}
struct functions_LinearFunction__object* 
  impl_functions_LinearFunction_fconnect_functions_LinearFunction(char* url,
  sidl_BaseInterface *_ex) {
  return functions_LinearFunction__connect(url, _ex);
}
char * impl_functions_LinearFunction_fgetURL_functions_LinearFunction(struct 
  functions_LinearFunction__object* obj) {
  return functions_LinearFunction__getURL(obj);
}
struct gov_cca_Port__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Port(char* url,
  sidl_BaseInterface *_ex) {
  return gov_cca_Port__connect(url, _ex);
}
char * impl_functions_LinearFunction_fgetURL_gov_cca_Port(struct 
  gov_cca_Port__object* obj) {
  return gov_cca_Port__getURL(obj);
}
struct gov_cca_Component__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Component(char* url,
  sidl_BaseInterface *_ex) {
  return gov_cca_Component__connect(url, _ex);
}
char * impl_functions_LinearFunction_fgetURL_gov_cca_Component(struct 
  gov_cca_Component__object* obj) {
  return gov_cca_Component__getURL(obj);
}
struct sidl_BaseInterface__object* 
  impl_functions_LinearFunction_fconnect_sidl_BaseInterface(char* url,
  sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connect(url, _ex);
}
char * impl_functions_LinearFunction_fgetURL_sidl_BaseInterface(struct 
  sidl_BaseInterface__object* obj) {
  return sidl_BaseInterface__getURL(obj);
}
struct sidl_BaseClass__object* 
  impl_functions_LinearFunction_fconnect_sidl_BaseClass(char* url,
  sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connect(url, _ex);
}
char * impl_functions_LinearFunction_fgetURL_sidl_BaseClass(struct 
  sidl_BaseClass__object* obj) {
  return sidl_BaseClass__getURL(obj);
}
