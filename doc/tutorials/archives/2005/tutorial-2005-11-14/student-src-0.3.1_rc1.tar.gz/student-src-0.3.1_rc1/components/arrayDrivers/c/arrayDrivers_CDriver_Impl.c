/*
 * File:          arrayDrivers_CDriver_Impl.c
 * Symbol:        arrayDrivers.CDriver-v1.0
 * Symbol Type:   class
 * Babel Version: 0.10.12
 * Description:   Server-side implementation for arrayDrivers.CDriver
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 * babel-version = 0.10.12
 * xml-url       = /san/cca/elwasifw/tutorial-src/components/../xml_repository/arrayDrivers.CDriver-v1.0.xml
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "arrayDrivers.CDriver" (version 1.0)
 */

#include "arrayDrivers_CDriver_Impl.h"

/* DO-NOT-DELETE splicer.begin(arrayDrivers.CDriver._includes) */
/* Insert-Code-Here {arrayDrivers.CDriver._includes} (includes and arbitrary code) */
#include "arrayop_LinearOp.h"   /* Port header file */
#include "sidl_header.h"
#include <stdio.h>
#include "sidl_Exception.h"
/* DO-NOT-DELETE splicer.end(arrayDrivers.CDriver._includes) */

/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayDrivers_CDriver__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_arrayDrivers_CDriver__load(
  void)
{
  /* DO-NOT-DELETE splicer.begin(arrayDrivers.CDriver._load) */
  /* Insert-Code-Here {arrayDrivers.CDriver._load} (static class initializer method) */
  /* DO-NOT-DELETE splicer.end(arrayDrivers.CDriver._load) */
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayDrivers_CDriver__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_arrayDrivers_CDriver__ctor(
  /* in */ arrayDrivers_CDriver self)
{
  /* DO-NOT-DELETE splicer.begin(arrayDrivers.CDriver._ctor) */
  /* Insert-Code-Here {arrayDrivers.CDriver._ctor} (constructor method) */
  struct arrayDrivers_CDriver__data *pd = (struct arrayDrivers_CDriver__data*) 
             malloc(sizeof(struct arrayDrivers_CDriver__data));
  if (pd) {
    /* Initialize the framework Services handle */
    pd->frameworkServices = NULL;
  }
  arrayDrivers_CDriver__set_data(self, pd);
  return;
  /* DO-NOT-DELETE splicer.end(arrayDrivers.CDriver._ctor) */
}

/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayDrivers_CDriver__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_arrayDrivers_CDriver__dtor(
  /* in */ arrayDrivers_CDriver self)
{
  /* DO-NOT-DELETE splicer.begin(arrayDrivers.CDriver._dtor) */
  /* Insert-Code-Here {arrayDrivers.CDriver._dtor} (destructor method) */
  struct arrayDrivers_CDriver__data *pd;
  pd = arrayDrivers_CDriver__get_data(self);
  if (pd) {
    free(pd); 
    arrayDrivers_CDriver__set_data(self, NULL);
  }
  /* DO-NOT-DELETE splicer.end(arrayDrivers.CDriver._dtor) */
}

/*
 * Execute some encapsulated functionality on the component. 
 * Return 0 if ok, -1 if internal error but component may be 
 * used further, and -2 if error so severe that component cannot
 * be further used safely.
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayDrivers_CDriver_go"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_arrayDrivers_CDriver_go(
  /* in */ arrayDrivers_CDriver self)
{
  /* DO-NOT-DELETE splicer.begin(arrayDrivers.CDriver.go) */
  /* Insert-Code-Here {arrayDrivers.CDriver.go} (go method) */
  int m = 3;			
  int n = 2;
  int i , j;
  double *A;
  double *v1;
  double *v2;
  double *y;
  double *r;
  double *sda1_data;
  double alpha = 1.0;
  double beta  = 2.0;
  double value;
  int    retval;
  struct sidl_double__array  *sda1, *sda2;
  
  arrayop_LinearOp  linopPort;
  gov_cca_Port      port;
  
  struct arrayDrivers_CDriver__data *pd;
  sidl_BaseInterface exception = NULL;
  
  /* Access private data structure */
  pd = arrayDrivers_CDriver__get_data(self);
    
  port = gov_cca_Services_getPort(pd->frameworkServices, "LinearOpPort", &exception);
  if (SIDL_CATCH(exception, "gov.cca.CCAException")) {
    fprintf(stderr, "Exception:: %s:%d: getPort(\"LinearOpPort\") failed.\n",
	    __FILE__, __LINE__);
    SIDL_CLEAR(exception);
    return(-1);
  }
  linopPort = arrayop_LinearOp__cast(port);
  if (linopPort == NULL) {
    fprintf(stderr, "Error:: %s:%d: Error casting port to arrayop.LinearOp \n",
	    __FILE__, __LINE__);
    exit(1);
  } 
  
  arrayop_LinearOp_init(linopPort);
  
  A = (double *) malloc (m * n * sizeof(double));
  v1 = (double *) malloc (n * sizeof(double));
  y = (double *) malloc (m * sizeof(double));
  r = (double *) malloc (m * sizeof(double));
  
  sda1 = sidl_double__array_create1d(m);
  if (!sda1){
    fprintf(stderr, "Error:: %s:%d: Error creating sda1.\n", 
	    __FILE__, __LINE__);
    return(-1);
  }
  
  if(!A || !v1  || !sda1 || !y || !r){
    fprintf(stderr, "Error:: %s:%d: Failed to allocate data for array/vector.\n",
	    __FILE__, __LINE__);
    return(-1);
  }
  
  /*      _         _          _    _          _    _ 
   *     | 1.0  4.0 |         | 1.0 |         | 3.0 |
   * A = | 2.0  5.0 |    v1 = | 2.0 |  sda1 = | 4.0 |
   *     | 3.0  6.0 |         -    -          | 5.0 | 
   *     -         -                          -    - 
   *
   * Note that A needs to be stored in column major order to make
   * the call using SIDL raw arrays
   */
  value = 0.0;
  for (i = 0; i < m; i++){
    for (j = 0; j < n; j++){
      A[i*n+j] = (value += 1.0);
    }
  }
  
  for (value =0.0, i = 0; i < n; i++){
    v1[i] = (value += 1.0);
  }
  
  sda1_data = sidlArrayAddr1(sda1, 0);
  for (value =0.0, i = 0; i < m; i++){
    sda1_data[i] = (double) i + 3.0 ; 
  }
  
  
  retval = arrayop_LinearOp_mulMatVec(linopPort, alpha, A, v1, y, m , n);
  if (retval != 0){
    fprintf(stderr, "Error:: %s:%d: Error in call to mulMatVec() \n",
	    __FILE__, __LINE__);
    return(-1);
  }
  
  printf("Result1 = ");
  for ( i = 0; i < m; i++){
    printf("%.2f  ", y[i]);
  } 
  printf("\n");
  gov_cca_Services_releasePort(pd->frameworkServices, "LinearOpPort", &exception);
  if (SIDL_CATCH(exception, "gov.cca.CCAException")) {
    fprintf(stderr, "Exception:: %s:%d: releasetPort(\"LinearOpPort\") failed.\n",
	    __FILE__, __LINE__);
    SIDL_CLEAR(exception);
    return(-1);
  }
  
  retval = arrayop_LinearOp_addVec(linopPort, beta, sda1, &sda2);
  if (retval != 0){
    fprintf(stderr, "Error:: %s:%d: Error in call to addVec() \n",
	    __FILE__, __LINE__);
    return(-1);
  }
  
  /* Print result obtained through sda2 */
  printf("Result2 = ");
  for ( i = sidlLower(sda2, 0); i <= sidlUpper(sda2, 0); i++){
    printf("%.2f  ", sidlArrayElem1(sda2, i));
  } 
  printf("\n");
  
  /*
   * Get results through  linopPort.getResult()
   */
  retval =  arrayop_LinearOp_getResult(linopPort, r, m);
  if (retval != 0){
    fprintf(stderr, "Error:: %s:%d: Error in call to getResult() \n",
	    __FILE__, __LINE__);
    return(-1);
  }
  printf("Result2 = ");
  for ( i = 0; i < m; i++){
    printf("%.2f  ", r[i]);
  } 
  printf("\n");
  gov_cca_Services_releasePort(pd->frameworkServices, "LinearOpPort", &exception);
  if (SIDL_CATCH(exception, "gov.cca.CCAException")) {
    fprintf(stderr, "Exception:: %s:%d: releasePort(\"LinearOpPort\") failed.\n",
       __FILE__, __LINE__);
    SIDL_CLEAR(exception);
    return(-1);
  }
  /* DO-NOT-DELETE splicer.end(arrayDrivers.CDriver.go) */
}

/*
 * Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument Svc will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayDrivers_CDriver_setServices"

#ifdef __cplusplus
extern "C"
#endif
void
impl_arrayDrivers_CDriver_setServices(
  /* in */ arrayDrivers_CDriver self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex)
{
  /* DO-NOT-DELETE splicer.begin(arrayDrivers.CDriver.setServices) */
  /* Insert-Code-Here {arrayDrivers.CDriver.setServices} (setServices method) */
  sidl_BaseInterface exception = NULL;

  struct arrayDrivers_CDriver__data *pd;
  
  /* Access private data structure */
  pd = arrayDrivers_CDriver__get_data(self);
  if (pd->frameworkServices) {
    /* remove reference to previous services object */
    gov_cca_Services_deleteRef(pd->frameworkServices);
  }
  pd->frameworkServices = services;
  gov_cca_Services_addRef(services);
  
  /* Create a typemap for the LinearOp port */
  gov_cca_TypeMap tm = gov_cca_Services_createTypeMap(pd->frameworkServices, 
        																&exception);
  if (SIDL_CATCH(exception, "gov.cca.CCAException")) {
    fprintf(stderr, "Exception:: %s:%d: gov::cca::TypeMap was not created\n",
	    __FILE__, __LINE__);
    SIDL_CLEAR(exception);
    exit(1);
  }
  if (tm == NULL) {
    fprintf(stderr, "Error:: %s:%d: gov::cca::TypeMap is nil\n",
	    __FILE__, __LINE__);
    exit(1);  
  } 
  
  /* Provide an arrayop.LinearOp port */
  gov_cca_Port port = gov_cca_Port__cast(self);
  if (port == NULL) {
    fprintf(stderr, "Error:: %s:%d: Error casting self to gov::cca::Port \n",
	    __FILE__, __LINE__);
    exit(1);
  } 
  
  gov_cca_Services_addProvidesPort(pd->frameworkServices,   
				   						  port,
				   						  "GoPort",
				                       "gov.cca.ports.GoPort",
				                       tm,
				                       &exception);
  if (SIDL_CATCH(exception, "gov.cca.CCAException")) {
    fprintf(stderr, "Exception:: %s:%d: Could not register gov.cca.ports.GoPort provides port\n",
	    __FILE__, __LINE__);
    SIDL_CLEAR(exception);
    exit(1);
  }
  
  gov_cca_Services_registerUsesPort(pd->frameworkServices,   
				   						  "LinearOpPort",
				                       "arrayop.LinearOp",
				                       tm,
				                       &exception);
  if (SIDL_CATCH(exception, "gov.cca.CCAException")) {
    fprintf(stderr, "Exception:: %s:%d: Could not add arrayop.LinearOp uses port\n",
	    __FILE__, __LINE__);
    SIDL_CLEAR(exception);
    exit(1);
  }
  
  /* Register with framework for component release */
  gov_cca_ComponentRelease cr = gov_cca_ComponentRelease__cast(self);
  if (cr != NULL) {
    gov_cca_Services_registerForRelease(pd->frameworkServices, cr, &exception);
  }
  
  return;
  /* DO-NOT-DELETE splicer.end(arrayDrivers.CDriver.setServices) */
}

/*
 * Shuts down a component presence in the calling framework.
 * @param Svc the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument Svc will never be nil/null.
 * The argument Svc will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to Svc.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */

#undef __FUNC__
#define __FUNC__ "impl_arrayDrivers_CDriver_releaseServices"

#ifdef __cplusplus
extern "C"
#endif
void
impl_arrayDrivers_CDriver_releaseServices(
  /* in */ arrayDrivers_CDriver self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex)
{
  /* DO-NOT-DELETE splicer.begin(arrayDrivers.CDriver.releaseServices) */
  /* Insert-Code-Here {arrayDrivers.CDriver.releaseServices} (releaseServices method) */
  struct arrayDrivers_CDriver__data *pd;
  
  pd = arrayDrivers_CDriver__get_data(self);
  if (pd->frameworkServices) {
    /* remove reference to previous services object */
    gov_cca_Services_deleteRef(pd->frameworkServices);
  }
  pd->frameworkServices = NULL;
  return;
  /* DO-NOT-DELETE splicer.end(arrayDrivers.CDriver.releaseServices) */
}
/* Babel internal methods, Users should not edit below this line. */
struct gov_cca_CCAException__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_CCAException(char* url,
  sidl_BaseInterface *_ex) {
  return gov_cca_CCAException__connect(url, _ex);
}
char * impl_arrayDrivers_CDriver_fgetURL_gov_cca_CCAException(struct 
  gov_cca_CCAException__object* obj) {
  return gov_cca_CCAException__getURL(obj);
}
struct gov_cca_ports_GoPort__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_ports_GoPort(char* url,
  sidl_BaseInterface *_ex) {
  return gov_cca_ports_GoPort__connect(url, _ex);
}
char * impl_arrayDrivers_CDriver_fgetURL_gov_cca_ports_GoPort(struct 
  gov_cca_ports_GoPort__object* obj) {
  return gov_cca_ports_GoPort__getURL(obj);
}
struct gov_cca_ComponentRelease__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_ComponentRelease(char* url,
  sidl_BaseInterface *_ex) {
  return gov_cca_ComponentRelease__connect(url, _ex);
}
char * impl_arrayDrivers_CDriver_fgetURL_gov_cca_ComponentRelease(struct 
  gov_cca_ComponentRelease__object* obj) {
  return gov_cca_ComponentRelease__getURL(obj);
}
struct gov_cca_Services__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_Services(char* url,
  sidl_BaseInterface *_ex) {
  return gov_cca_Services__connect(url, _ex);
}
char * impl_arrayDrivers_CDriver_fgetURL_gov_cca_Services(struct 
  gov_cca_Services__object* obj) {
  return gov_cca_Services__getURL(obj);
}
struct arrayDrivers_CDriver__object* 
  impl_arrayDrivers_CDriver_fconnect_arrayDrivers_CDriver(char* url,
  sidl_BaseInterface *_ex) {
  return arrayDrivers_CDriver__connect(url, _ex);
}
char * impl_arrayDrivers_CDriver_fgetURL_arrayDrivers_CDriver(struct 
  arrayDrivers_CDriver__object* obj) {
  return arrayDrivers_CDriver__getURL(obj);
}
struct sidl_ClassInfo__object* 
  impl_arrayDrivers_CDriver_fconnect_sidl_ClassInfo(char* url,
  sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connect(url, _ex);
}
char * impl_arrayDrivers_CDriver_fgetURL_sidl_ClassInfo(struct 
  sidl_ClassInfo__object* obj) {
  return sidl_ClassInfo__getURL(obj);
}
struct gov_cca_Port__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_Port(char* url,
  sidl_BaseInterface *_ex) {
  return gov_cca_Port__connect(url, _ex);
}
char * impl_arrayDrivers_CDriver_fgetURL_gov_cca_Port(struct 
  gov_cca_Port__object* obj) {
  return gov_cca_Port__getURL(obj);
}
struct gov_cca_Component__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_Component(char* url,
  sidl_BaseInterface *_ex) {
  return gov_cca_Component__connect(url, _ex);
}
char * impl_arrayDrivers_CDriver_fgetURL_gov_cca_Component(struct 
  gov_cca_Component__object* obj) {
  return gov_cca_Component__getURL(obj);
}
struct sidl_BaseInterface__object* 
  impl_arrayDrivers_CDriver_fconnect_sidl_BaseInterface(char* url,
  sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connect(url, _ex);
}
char * impl_arrayDrivers_CDriver_fgetURL_sidl_BaseInterface(struct 
  sidl_BaseInterface__object* obj) {
  return sidl_BaseInterface__getURL(obj);
}
struct sidl_BaseClass__object* 
  impl_arrayDrivers_CDriver_fconnect_sidl_BaseClass(char* url,
  sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connect(url, _ex);
}
char * impl_arrayDrivers_CDriver_fgetURL_sidl_BaseClass(struct 
  sidl_BaseClass__object* obj) {
  return sidl_BaseClass__getURL(obj);
}
