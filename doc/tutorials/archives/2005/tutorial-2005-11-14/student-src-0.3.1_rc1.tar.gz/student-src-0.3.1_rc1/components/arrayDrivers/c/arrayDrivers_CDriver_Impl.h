/*
 * File:          arrayDrivers_CDriver_Impl.h
 * Symbol:        arrayDrivers.CDriver-v1.0
 * Symbol Type:   class
 * Babel Version: 0.10.12
 * Description:   Server-side implementation for arrayDrivers.CDriver
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 * babel-version = 0.10.12
 * xml-url       = /san/cca/elwasifw/tutorial-src/components/../xml_repository/arrayDrivers.CDriver-v1.0.xml
 */

#ifndef included_arrayDrivers_CDriver_Impl_h
#define included_arrayDrivers_CDriver_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_gov_cca_CCAException_h
#include "gov_cca_CCAException.h"
#endif
#ifndef included_gov_cca_ports_GoPort_h
#include "gov_cca_ports_GoPort.h"
#endif
#ifndef included_gov_cca_ComponentRelease_h
#include "gov_cca_ComponentRelease.h"
#endif
#ifndef included_gov_cca_Services_h
#include "gov_cca_Services.h"
#endif
#ifndef included_arrayDrivers_CDriver_h
#include "arrayDrivers_CDriver.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_gov_cca_Port_h
#include "gov_cca_Port.h"
#endif
#ifndef included_gov_cca_Component_h
#include "gov_cca_Component.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif

/* DO-NOT-DELETE splicer.begin(arrayDrivers.CDriver._includes) */
/* Insert-Code-Here {arrayDrivers.CDriver._includes} (include files) */
/* DO-NOT-DELETE splicer.end(arrayDrivers.CDriver._includes) */

/*
 * Private data for class arrayDrivers.CDriver
 */

struct arrayDrivers_CDriver__data {
  /* DO-NOT-DELETE splicer.begin(arrayDrivers.CDriver._data) */
  /* Insert-Code-Here {arrayDrivers.CDriver._data} (private data members) */
  gov_cca_Services  frameworkServices;
  /* DO-NOT-DELETE splicer.end(arrayDrivers.CDriver._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct arrayDrivers_CDriver__data*
arrayDrivers_CDriver__get_data(
  arrayDrivers_CDriver);

extern void
arrayDrivers_CDriver__set_data(
  arrayDrivers_CDriver,
  struct arrayDrivers_CDriver__data*);

extern
void
impl_arrayDrivers_CDriver__load(
  void);

extern
void
impl_arrayDrivers_CDriver__ctor(
  /* in */ arrayDrivers_CDriver self);

extern
void
impl_arrayDrivers_CDriver__dtor(
  /* in */ arrayDrivers_CDriver self);

/*
 * User-defined object methods
 */

extern struct gov_cca_CCAException__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_CCAException(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_gov_cca_CCAException(struct 
  gov_cca_CCAException__object* obj);
extern struct gov_cca_ports_GoPort__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_ports_GoPort(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_gov_cca_ports_GoPort(struct 
  gov_cca_ports_GoPort__object* obj);
extern struct gov_cca_ComponentRelease__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_ComponentRelease(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_gov_cca_ComponentRelease(struct 
  gov_cca_ComponentRelease__object* obj);
extern struct gov_cca_Services__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_Services(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_gov_cca_Services(struct 
  gov_cca_Services__object* obj);
extern struct arrayDrivers_CDriver__object* 
  impl_arrayDrivers_CDriver_fconnect_arrayDrivers_CDriver(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_arrayDrivers_CDriver(struct 
  arrayDrivers_CDriver__object* obj);
extern struct sidl_ClassInfo__object* 
  impl_arrayDrivers_CDriver_fconnect_sidl_ClassInfo(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_sidl_ClassInfo(struct 
  sidl_ClassInfo__object* obj);
extern struct gov_cca_Port__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_Port(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_gov_cca_Port(struct 
  gov_cca_Port__object* obj);
extern struct gov_cca_Component__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_Component(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_gov_cca_Component(struct 
  gov_cca_Component__object* obj);
extern struct sidl_BaseInterface__object* 
  impl_arrayDrivers_CDriver_fconnect_sidl_BaseInterface(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_sidl_BaseInterface(struct 
  sidl_BaseInterface__object* obj);
extern struct sidl_BaseClass__object* 
  impl_arrayDrivers_CDriver_fconnect_sidl_BaseClass(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_sidl_BaseClass(struct 
  sidl_BaseClass__object* obj);
extern
int32_t
impl_arrayDrivers_CDriver_go(
  /* in */ arrayDrivers_CDriver self);

extern
void
impl_arrayDrivers_CDriver_setServices(
  /* in */ arrayDrivers_CDriver self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_arrayDrivers_CDriver_releaseServices(
  /* in */ arrayDrivers_CDriver self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

extern struct gov_cca_CCAException__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_CCAException(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_gov_cca_CCAException(struct 
  gov_cca_CCAException__object* obj);
extern struct gov_cca_ports_GoPort__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_ports_GoPort(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_gov_cca_ports_GoPort(struct 
  gov_cca_ports_GoPort__object* obj);
extern struct gov_cca_ComponentRelease__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_ComponentRelease(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_gov_cca_ComponentRelease(struct 
  gov_cca_ComponentRelease__object* obj);
extern struct gov_cca_Services__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_Services(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_gov_cca_Services(struct 
  gov_cca_Services__object* obj);
extern struct arrayDrivers_CDriver__object* 
  impl_arrayDrivers_CDriver_fconnect_arrayDrivers_CDriver(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_arrayDrivers_CDriver(struct 
  arrayDrivers_CDriver__object* obj);
extern struct sidl_ClassInfo__object* 
  impl_arrayDrivers_CDriver_fconnect_sidl_ClassInfo(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_sidl_ClassInfo(struct 
  sidl_ClassInfo__object* obj);
extern struct gov_cca_Port__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_Port(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_gov_cca_Port(struct 
  gov_cca_Port__object* obj);
extern struct gov_cca_Component__object* 
  impl_arrayDrivers_CDriver_fconnect_gov_cca_Component(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_gov_cca_Component(struct 
  gov_cca_Component__object* obj);
extern struct sidl_BaseInterface__object* 
  impl_arrayDrivers_CDriver_fconnect_sidl_BaseInterface(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_sidl_BaseInterface(struct 
  sidl_BaseInterface__object* obj);
extern struct sidl_BaseClass__object* 
  impl_arrayDrivers_CDriver_fconnect_sidl_BaseClass(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayDrivers_CDriver_fgetURL_sidl_BaseClass(struct 
  sidl_BaseClass__object* obj);
#ifdef __cplusplus
}
#endif
#endif
