// 
// File:          library_CxxUnitsLibraryComp_Impl.cc
// Symbol:        library.CxxUnitsLibraryComp-v1.0
// Symbol Type:   class
// Babel Version: 0.10.8
// Description:   Server-side implementation for library.CxxUnitsLibraryComp
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.10.8
// xml-url       = /home/epperly/current/tutorial/src/components/../xml_repository/library.CxxUnitsLibraryComp-v1.0.xml
// 
#include "library_CxxUnitsLibraryComp_Impl.hh"

// DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp._includes)
#include "library_CxxSimpleUnit.hh"
#include "library_CxxSimpleConversion.hh"
#include "library_CxxUnknownException.hh"
#include <stdio.h>

struct predefined_units {
  ::std::string d_name;
  double        d_slope;
  double        d_offset;
} s_predef[] = {
  { "kilogram", 1.0, 0.0 },
  { "kg", 1.0, 0.0 },
  { "pound", 0.45359237, 0.0 },
  { "gram", 0.001, 0.0 },
  { "meter", 1.0, 0 },
  { "inch", 0.0254, 0},
  { "feet", 0.3048, 0},
  { "kilometer", 1000.0, 0},
  { "cm", 0.01, 0},
  { "second", 1.0, 0},
  { "minute", 60.0, 0},
  { "hour", 3600.0, 0},
  { "ampere", 1.0, 0},
  { "Kelvin", 1.0, 0},
  { "Candela", 1.0, 0},
  { "mole", 1.0, 0}
};
// DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp._includes)

// user-defined constructor.
void library::CxxUnitsLibraryComp_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp._ctor)
  const int numDefined = sizeof(s_predef)/sizeof(struct predefined_units);
  for(int i = 0; i < numDefined; ++i) {
    ::units::Unit unit = 
	::library::CxxSimpleUnit::build(s_predef[i].d_name,
				     s_predef[i].d_slope,
				     s_predef[i].d_offset);
    d_library[s_predef[i].d_name] = unit;
  }
  // DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp._ctor)
}

// user-defined destructor.
void library::CxxUnitsLibraryComp_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp._dtor)
  // DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp._dtor)
}

// static class initializer.
void library::CxxUnitsLibraryComp_impl::_load() {
  // DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp._load)
  // Insert-Code-Here {library.CxxUnitsLibraryComp._load} (class initialization)
  // DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp._load)
}

// user-defined static methods: (none)

// user-defined non-static methods:
/**
 * Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument Svc will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
library::CxxUnitsLibraryComp_impl::setServices (
  /* in */ ::gov::cca::Services services ) 
throw ( 
  ::gov::cca::CCAException
){
  // DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp.setServices)
  if (services._not_nil()) {
    ::gov::cca::TypeMap tm = services.createTypeMap();
    ::gov::cca::Port port = self;
    if (port._is_nil()) {
      fprintf(stderr, "%s:%d: port is nil\n", __FILE__, __LINE__);
    }
    services.addProvidesPort(port,
			     "UnitLibraryPort",
			     "units.UnitsLibrary",
			     tm);
  }
  // DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp.setServices)
}

/**
 * Generate conversion factors for a pair of units.
 */
::units::Conversion
library::CxxUnitsLibraryComp_impl::lookupConversion (
  /* in */ ::units::Unit src,
  /* in */ ::units::Unit dest ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp.lookupConversion)
  ::units::Conversion conv = ::library::CxxSimpleConversion::build(src, dest);
  return conv;
  // DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp.lookupConversion)
}

/**
 * Define a new unit. Units defined are automatically
 * registered in the library. slope and offset should
 * be defined so that <value in knownUnit> = slope *
 * <value in newUnit> + offset.
 */
void
library::CxxUnitsLibraryComp_impl::defineUnit (
  /* in */ const ::std::string& name,
  /* in */ double slope,
  /* in */ double offset,
  /* in */ ::units::Unit knownUnit,
  /* out */ ::units::Unit& newUnit ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp.defineUnit)
  double knownSlope, knownOffset;
  knownUnit.conversionFactors(knownSlope, knownOffset);
  newUnit = ::library::CxxSimpleUnit::build(name, knownSlope * slope,
					 knownSlope * offset + knownOffset);
  // DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp.defineUnit)
}

/**
 * Transform a Conversion interface to convert values in the 
 * opposite direction. Note this can modify or replace the 
 * incoming parameter.
 */
void
library::CxxUnitsLibraryComp_impl::invertConversion (
  /* inout */ ::units::Conversion& convert ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp.invertConversion)
  ::library::CxxSimpleConversion sc = convert;
  sc.reverse();
  // DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp.invertConversion)
}

/**
 * Lookup a unit definition. If no matching unit is found,
 * the UnknownUnitException is thrown.
 */
::units::Unit
library::CxxUnitsLibraryComp_impl::lookupUnit (
  /* in */ const ::std::string& name ) 
throw ( 
  ::units::UnknownUnitException
){
  // DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp.lookupUnit)
  ::std::map<const ::std::string,::units::Unit>::iterator i = 
      d_library.find(name); 
  if (i != d_library.end()) {
    return i->second;
  }
  else {
    ::std::string msg = ::std::string("Unit \"") +
	name + ::std::string("\" is not known to the library.");
    ::units::UnknownUnitException uue =
	::library::CxxUnknownException::_create();
    uue.setNote(msg);
    throw uue;
  }
  // DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp.lookupUnit)
}


// DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp._misc)
// Insert-Code-Here {library.CxxUnitsLibraryComp._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp._misc)

