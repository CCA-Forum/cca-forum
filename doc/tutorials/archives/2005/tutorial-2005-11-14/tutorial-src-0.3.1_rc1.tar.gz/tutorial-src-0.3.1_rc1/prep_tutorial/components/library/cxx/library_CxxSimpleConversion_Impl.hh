// 
// File:          library_CxxSimpleConversion_Impl.hh
// Symbol:        library.CxxSimpleConversion-v1.0
// Symbol Type:   class
// Babel Version: 0.10.8
// Description:   Server-side implementation for library.CxxSimpleConversion
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.10.8
// xml-url       = /home/epperly/current/tutorial/src/components/../xml_repository/library.CxxSimpleConversion-v1.0.xml
// 

#ifndef included_library_CxxSimpleConversion_Impl_hh
#define included_library_CxxSimpleConversion_Impl_hh

#ifndef included_sidl_cxx_hh
#include "sidl_cxx.hh"
#endif
#ifndef included_library_CxxSimpleConversion_IOR_h
#include "library_CxxSimpleConversion_IOR.h"
#endif
// 
// Includes for all method dependencies.
// 
#ifndef included_library_CxxSimpleConversion_hh
#include "library_CxxSimpleConversion.hh"
#endif
#ifndef included_sidl_BaseInterface_hh
#include "sidl_BaseInterface.hh"
#endif
#ifndef included_sidl_ClassInfo_hh
#include "sidl_ClassInfo.hh"
#endif
#ifndef included_units_Unit_hh
#include "units_Unit.hh"
#endif


// DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._includes)
// Insert-Code-Here {library.CxxSimpleConversion._includes} (includes or arbitrary code)
// DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._includes)

namespace library { 

  /**
   * Symbol "library.CxxSimpleConversion" (version 1.0)
   */
  class CxxSimpleConversion_impl
  // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._inherits)
  // none needed
  // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._inherits)
  {

  private:
    // Pointer back to IOR.
    // Use this to dispatch back through IOR vtable.
    CxxSimpleConversion self;

    // DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._implementation)
    ::units::Unit d_fromUnit;
    ::units::Unit d_toUnit;
    // DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._implementation)

  private:
    // private default constructor (required)
    CxxSimpleConversion_impl() 
    {} 

  public:
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    CxxSimpleConversion_impl( struct library_CxxSimpleConversion__object * s ) 
      : self(s,true) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~CxxSimpleConversion_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // static class initializer
    static void _load();

  public:
    /**
     * user defined static method.
     */
    static ::library::CxxSimpleConversion
    build (
      /* in */ ::units::Unit fromUnit,
      /* in */ ::units::Unit toUnit
    )
    throw () 
    ;


    /**
     * user defined non-static method.
     */
    void
    init (
      /* in */ ::units::Unit fromUnit,
      /* in */ ::units::Unit toUnit
    )
    throw () 
    ;


    /**
     * Reverse the direction of the conversion.
     */
    void
    reverse() throw () 
    ;

    /**
     * Return the unit that this Conversion interface will convert
     * from.
     */
    ::units::Unit
    convertFrom() throw () 
    ;

    /**
     * Return the unit that this interface will convert to.
     */
    ::units::Unit
    convertTo() throw () 
    ;

    /**
     * Convert a physical quantity from old set of units to another.
     */
    double
    convert (
      /* in */ double orig
    )
    throw () 
    ;

  };  // end class CxxSimpleConversion_impl

} // end namespace library

// DO-NOT-DELETE splicer.begin(library.CxxSimpleConversion._misc)
// Insert-Code-Here {library.CxxSimpleConversion._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(library.CxxSimpleConversion._misc)

#endif
