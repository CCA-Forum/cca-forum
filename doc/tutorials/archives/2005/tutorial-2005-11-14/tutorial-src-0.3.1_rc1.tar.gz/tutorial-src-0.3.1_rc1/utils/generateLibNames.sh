#!/bin/sh
		
language=$1
shift;
libNameList=""
		
until [ -z "$1" ]            # Until uses up arguments passed...
	do
    sidlName=$1
		# First get rid of leading . if any
		sidlName="`echo $sidlName | sed 's|^\.||'`"
		#libPath="`echo $sidlName | sed 's|\.|\/|g'`"
		libName="lib`echo $sidlName | sed 's|\.||g'`-$language.so"
		libNameList="$libNameList $libName"
    shift
  done

echo $libNameList

