/*
 * File:          functions_LinearFunction_Impl.h
 * Symbol:        functions.LinearFunction-v1.0
 * Symbol Type:   class
 * Babel Version: 0.10.12
 * Description:   Server-side implementation for functions.LinearFunction
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 * babel-version = 0.10.12
 * xml-url       = /san/cca/elwasifw/tutorial-src/components/../xml_repository/functions.LinearFunction-v1.0.xml
 */

#ifndef included_functions_LinearFunction_Impl_h
#define included_functions_LinearFunction_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_gov_cca_CCAException_h
#include "gov_cca_CCAException.h"
#endif
#ifndef included_function_FunctionPort_h
#include "function_FunctionPort.h"
#endif
#ifndef included_gov_cca_Services_h
#include "gov_cca_Services.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_functions_LinearFunction_h
#include "functions_LinearFunction.h"
#endif
#ifndef included_gov_cca_Port_h
#include "gov_cca_Port.h"
#endif
#ifndef included_gov_cca_Component_h
#include "gov_cca_Component.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif

/* DO-NOT-DELETE splicer.begin(functions.LinearFunction._includes) */
/* Put additional include files here... */
/* DO-NOT-DELETE splicer.end(functions.LinearFunction._includes) */

/*
 * Private data for class functions.LinearFunction
 */

struct functions_LinearFunction__data {
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._data) */
  /* Put private data members here... */

  /* Handle to framework services object */
  gov_cca_Services frameworkServices;

  /* DO-NOT-DELETE splicer.end(functions.LinearFunction._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct functions_LinearFunction__data*
functions_LinearFunction__get_data(
  functions_LinearFunction);

extern void
functions_LinearFunction__set_data(
  functions_LinearFunction,
  struct functions_LinearFunction__data*);

extern
void
impl_functions_LinearFunction__load(
  void);

extern
void
impl_functions_LinearFunction__ctor(
  /* in */ functions_LinearFunction self);

extern
void
impl_functions_LinearFunction__dtor(
  /* in */ functions_LinearFunction self);

/*
 * User-defined object methods
 */

extern struct gov_cca_CCAException__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_CCAException(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_gov_cca_CCAException(struct 
  gov_cca_CCAException__object* obj);
extern struct function_FunctionPort__object* 
  impl_functions_LinearFunction_fconnect_function_FunctionPort(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_function_FunctionPort(struct 
  function_FunctionPort__object* obj);
extern struct gov_cca_Services__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Services(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_gov_cca_Services(struct 
  gov_cca_Services__object* obj);
extern struct sidl_ClassInfo__object* 
  impl_functions_LinearFunction_fconnect_sidl_ClassInfo(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_sidl_ClassInfo(struct 
  sidl_ClassInfo__object* obj);
extern struct functions_LinearFunction__object* 
  impl_functions_LinearFunction_fconnect_functions_LinearFunction(char* url,
  sidl_BaseInterface *_ex);
extern char* 
  impl_functions_LinearFunction_fgetURL_functions_LinearFunction(struct 
  functions_LinearFunction__object* obj);
extern struct gov_cca_Port__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Port(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_gov_cca_Port(struct 
  gov_cca_Port__object* obj);
extern struct gov_cca_Component__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Component(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_gov_cca_Component(struct 
  gov_cca_Component__object* obj);
extern struct sidl_BaseInterface__object* 
  impl_functions_LinearFunction_fconnect_sidl_BaseInterface(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_sidl_BaseInterface(struct 
  sidl_BaseInterface__object* obj);
extern struct sidl_BaseClass__object* 
  impl_functions_LinearFunction_fconnect_sidl_BaseClass(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_sidl_BaseClass(struct 
  sidl_BaseClass__object* obj);
extern
void
impl_functions_LinearFunction_init(
  /* in */ functions_LinearFunction self,
  /* in array<double> */ struct sidl_double__array* params);

extern
double
impl_functions_LinearFunction_evaluate(
  /* in */ functions_LinearFunction self,
  /* in */ double x);

extern
void
impl_functions_LinearFunction_setServices(
  /* in */ functions_LinearFunction self,
  /* in */ gov_cca_Services servicesHandle,
  /* out */ sidl_BaseInterface *_ex);

extern struct gov_cca_CCAException__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_CCAException(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_gov_cca_CCAException(struct 
  gov_cca_CCAException__object* obj);
extern struct function_FunctionPort__object* 
  impl_functions_LinearFunction_fconnect_function_FunctionPort(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_function_FunctionPort(struct 
  function_FunctionPort__object* obj);
extern struct gov_cca_Services__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Services(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_gov_cca_Services(struct 
  gov_cca_Services__object* obj);
extern struct sidl_ClassInfo__object* 
  impl_functions_LinearFunction_fconnect_sidl_ClassInfo(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_sidl_ClassInfo(struct 
  sidl_ClassInfo__object* obj);
extern struct functions_LinearFunction__object* 
  impl_functions_LinearFunction_fconnect_functions_LinearFunction(char* url,
  sidl_BaseInterface *_ex);
extern char* 
  impl_functions_LinearFunction_fgetURL_functions_LinearFunction(struct 
  functions_LinearFunction__object* obj);
extern struct gov_cca_Port__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Port(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_gov_cca_Port(struct 
  gov_cca_Port__object* obj);
extern struct gov_cca_Component__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Component(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_gov_cca_Component(struct 
  gov_cca_Component__object* obj);
extern struct sidl_BaseInterface__object* 
  impl_functions_LinearFunction_fconnect_sidl_BaseInterface(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_sidl_BaseInterface(struct 
  sidl_BaseInterface__object* obj);
extern struct sidl_BaseClass__object* 
  impl_functions_LinearFunction_fconnect_sidl_BaseClass(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_functions_LinearFunction_fgetURL_sidl_BaseClass(struct 
  sidl_BaseClass__object* obj);
#ifdef __cplusplus
}
#endif
#endif
