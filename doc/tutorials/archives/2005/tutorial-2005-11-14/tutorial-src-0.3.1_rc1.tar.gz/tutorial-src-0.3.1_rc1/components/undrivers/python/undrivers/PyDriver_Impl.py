#
# File:          PyDriver_Impl.py
# Symbol:        undrivers.PyDriver-v1.0
# Symbol Type:   class
# Babel Version: 0.10.12
# Description:   Implementation of sidl class undrivers.PyDriver in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
# babel-version = 0.10.12
# xml-url       = /san/cca/elwasifw/tutorial-src/components/../xml_repository/undrivers.PyDriver-v1.0.xml
#


# DO-NOT-DELETE splicer.begin(_initial)
# Insert-Code-Here {_initial} ()
# DO-NOT-DELETE splicer.end(_initial)

import gov.cca.CCAException
import gov.cca.ports.GoPort
import undrivers.PyDriver
import gov.cca.Services
import sidl.ClassInfo
import gov.cca.Port
import gov.cca.Component
import sidl.BaseInterface
import sidl.BaseClass

# DO-NOT-DELETE splicer.begin(_before_type)
import units.UnitsLibrary
# DO-NOT-DELETE splicer.end(_before_type)

class PyDriver:

  # All calls to sidl methods should use __IORself

  def __init__(self, IORself):
    self.__IORself = IORself
    # DO-NOT-DELETE splicer.begin(__init__)
    self.d_services = None
    # DO-NOT-DELETE splicer.end(__init__)

  def go(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # int _return
    #

    """\
Execute some encapsulated functionality on the component. 
Return 0 if ok, -1 if internal error but component may be 
used further, and -2 if error so severe that component cannot
be further used safely.
"""
    # DO-NOT-DELETE splicer.begin(go)
    genericPort = self.d_services.getPort("UnitLibrary")
    library = units.UnitsLibrary.UnitsLibrary(genericPort)
    meter = library.lookupUnit("meter")
    inch = library.lookupUnit("inch")
    converter = library.lookupConversion(meter,inch)
    reverseConverter = library.invertConversion(converter)
    inches = converter.convert(1)  # convert 1 meter to inches
    meters = reverseConverter.convert(1) # convert 1 inch to meters
    print "1 meter =  " + str(inches) + " inch"
    print "1 inch  =  " + str(meters) + " meter"
    self.d_services.releasePort("UnitLibrary")
    return 0
    # DO-NOT-DELETE splicer.end(go)

  def setServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # # None
    #

    """\
Starts up a component presence in the calling framework.
@param services the component instance's handle on the framework world.
Contracts concerning Svc and setServices:

The component interaction with the CCA framework
and Ports begins on the call to setServices by the framework.

This function is called exactly once for each instance created
by the framework.

The argument Svc will never be nil/null.

Those uses ports which are automatically connected by the framework
(so-called service-ports) may be obtained via getPort during
setServices.
"""
    # DO-NOT-DELETE splicer.begin(setServices)
    self.d_services = services
    mymap = self.d_services.createTypeMap()
    self.d_services.addProvidesPort(self.__IORself, 'GoPort',
                                    'gov.cca.ports.GoPort',
                                    mymap)
    self.d_services.registerUsesPort('UnitLibrary',
                                     'units.UnitsLibrary',
                                     mymap)
    # DO-NOT-DELETE splicer.end(setServices)

# DO-NOT-DELETE splicer.begin(_final)
# Insert-Code-Here {_final} ()
# DO-NOT-DELETE splicer.end(_final)
