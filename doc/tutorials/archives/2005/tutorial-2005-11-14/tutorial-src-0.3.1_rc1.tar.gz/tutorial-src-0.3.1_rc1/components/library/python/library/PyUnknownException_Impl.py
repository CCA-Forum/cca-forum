#
# File:          PyUnknownException_Impl.py
# Symbol:        library.PyUnknownException-v1.0
# Symbol Type:   class
# Babel Version: 0.10.12
# Description:   Implementation of sidl class library.PyUnknownException in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
# babel-version = 0.10.12
# xml-url       = /san/cca/elwasifw/tutorial-src/components/../xml_repository/library.PyUnknownException-v1.0.xml
#


# DO-NOT-DELETE splicer.begin(_initial)
# Insert-Code-Here {_initial} ()
# DO-NOT-DELETE splicer.end(_initial)

import units.UnknownUnitException
import sidl.SIDLException
import sidl.ClassInfo
import sidl.BaseInterface
import library.PyUnknownException
import sidl.BaseException
import sidl.BaseClass

# DO-NOT-DELETE splicer.begin(_before_type)
# DO-NOT-DELETE splicer.end(_before_type)

class PyUnknownException:

  # All calls to sidl methods should use __IORself

  def __init__(self, IORself):
    self.__IORself = IORself
    # DO-NOT-DELETE splicer.begin(__init__)
    # DO-NOT-DELETE splicer.end(__init__)

# DO-NOT-DELETE splicer.begin(_final)
# DO-NOT-DELETE splicer.end(_final)
