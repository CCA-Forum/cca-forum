// 
// File:          pdrivers_CXXDriverMPI_Impl.cc
// Symbol:        pdrivers.CXXDriverMPI-v1.0
// Symbol Type:   class
// Babel Version: 0.10.12
// Description:   Server-side implementation for pdrivers.CXXDriverMPI
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.10.12
// xml-url       = /san/cca/elwasifw/tutorial-src/components/../xml_repository/pdrivers.CXXDriverMPI-v1.0.xml
// 
#include "pdrivers_CXXDriverMPI_Impl.hh"

// DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI._includes)
// Insert-Code-Here {pdrivers.CXXDriverMPI._includes} (additional includes or code)

#include "noSeekMPI.h" // destroy the SEEK macros from mpi2
#include <iostream> // note: this is probably a dumb thing to do in a real mpi code

// DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI._includes)

// user-defined constructor.
void pdrivers::CXXDriverMPI_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI._ctor)
  // Insert-Code-Here {pdrivers.CXXDriverMPI._ctor} (constructor)
  // DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI._ctor)
}

// user-defined destructor.
void pdrivers::CXXDriverMPI_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI._dtor)
  // Insert-Code-Here {pdrivers.CXXDriverMPI._dtor} (destructor)
  // DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI._dtor)
}

// static class initializer.
void pdrivers::CXXDriverMPI_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI._load)
  // Insert-Code-Here {pdrivers.CXXDriverMPI._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI._load)
}

// user-defined static methods: (none)

// user-defined non-static methods:
/**
 * Method:  go[]
 */
int32_t
pdrivers::CXXDriverMPI_impl::go ()
throw () 

{
  // DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI.go)
  // Insert-Code-Here {pdrivers.CXXDriverMPI.go} (go method)
  int rank; 

  ::parallel::MPICommUser cu; 

  if (mpiService._not_nil()) {
    // get the port ...
    cu = frameworkServices.getPort("CommUser"); 
  
    if(cu._is_nil()) { 
      std::cerr << "pdrivers.CXXDriverMPI not connected to a MPICommUser" << std::endl;
    } else {
      // set the communicator on another component that needs it for real work.
      cu.setComm(commSIDL); 
      frameworkServices.releasePort("CommUser");  
    }

    int err = MPI_Comm_rank(commC,&rank);
    if (err != MPI_SUCCESS) {
      return -2; // we're really hosed if we can't get rank.
    }
 
    fprintf(stdout,"Comm rank = %d\n", rank);
    fflush(stdout);

    return 0; 
  } else {
    std::cerr << "pdrivers.CXXDriverMPI not connected to MPIService." << std::endl;
    return -1;
  }
  // DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI.go)
}

/**
 * Method:  setServices[]
 */
void
pdrivers::CXXDriverMPI_impl::setServices (
  /* in */ ::gov::cca::Services services ) 
throw ( 
  ::gov::cca::CCAException
){
  // DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI.setServices)
  // Insert-Code-Here {pdrivers.CXXDriverMPI.setServices} (setServices method)
  frameworkServices = services;

  // Provide a Go port
  gov::cca::ports::GoPort gp = self; 
  gov::cca::TypeMap tempMap = frameworkServices.createTypeMap(); 
        
  frameworkServices.addProvidesPort(gp,
                                    "GoPort",
                                    "gov.cca.ports.GoPort",
                                    tempMap);

  // Use an MPIService port 
  frameworkServices.registerUsesPort ("MPI", 
                                      "ccaffeine.ports.MPIService", 
                                      tempMap);

  // Use an MPICommUser port
  frameworkServices.registerUsesPort ("CommUser", 
                                      "parallel.MPICommUser", 
                                      tempMap);

  // Do not release the port or communicator here.  
  // Register to be notified at shutdown so we can release then.
  gov::cca::ComponentRelease cr = self; 
  frameworkServices.registerForRelease(cr);
  
  // Get the communicator 
  ::gov::cca::Port ms;
  ms = frameworkServices.getPort("MPI");
  if (ms._is_nil()) { 
    commSIDL = 0;
    commC = MPI_COMM_NULL;
    std::cerr << "pdrivers.CXXDriverMPI in a framework not providing MPIService." << std::endl;
  } else {
    mpiService = ms; // BABEL CAST operation.
    commSIDL = mpiService.getComm();
    MPI_Fint commF = (MPI_Fint)commSIDL;
    commC = MPI_Comm_f2c(commF);
  }
  
  // DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI.setServices)
}

/**
 * Method:  releaseServices[]
 */
void
pdrivers::CXXDriverMPI_impl::releaseServices (
  /* in */ ::gov::cca::Services services ) 
throw ( 
  ::gov::cca::CCAException
){
  // DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI.releaseServices)
  // Insert-Code-Here {pdrivers.CXXDriverMPI.releaseServices} (releaseServices method)
  mpiService.releaseComm(commSIDL);
  commC = MPI_COMM_NULL;
  commSIDL = 0;
  if (mpiService._not_nil()) {
    frameworkServices.releasePort("MPI");
  }
  mpiService = 0; // IS 0 THE RIGHT ARGUMENT THESE DAYS to nil a reference? Babel?
  frameworkServices.unregisterUsesPort("MPI");
  frameworkServices.unregisterUsesPort("CommUser");
  frameworkServices.removeProvidesPort("GoPort");
  frameworkServices = 0; // IS 0 THE RIGHT ARGUMENT THESE DAYS to nil a reference? Babel?
  // DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI.releaseServices)
}


// DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI._misc)
// Insert-Code-Here {pdrivers.CXXDriverMPI._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI._misc)

