/*
 * File:          arrayOps_CArrayOp_Impl.h
 * Symbol:        arrayOps.CArrayOp-v1.0
 * Symbol Type:   class
 * Babel Version: 0.10.12
 * Description:   Server-side implementation for arrayOps.CArrayOp
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 * babel-version = 0.10.12
 * xml-url       = /san/cca/elwasifw/tutorial-src/components/../xml_repository/arrayOps.CArrayOp-v1.0.xml
 */

#ifndef included_arrayOps_CArrayOp_Impl_h
#define included_arrayOps_CArrayOp_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_gov_cca_CCAException_h
#include "gov_cca_CCAException.h"
#endif
#ifndef included_gov_cca_ComponentRelease_h
#include "gov_cca_ComponentRelease.h"
#endif
#ifndef included_arrayop_LinearOp_h
#include "arrayop_LinearOp.h"
#endif
#ifndef included_gov_cca_Services_h
#include "gov_cca_Services.h"
#endif
#ifndef included_arrayOps_CArrayOp_h
#include "arrayOps_CArrayOp.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_gov_cca_Port_h
#include "gov_cca_Port.h"
#endif
#ifndef included_gov_cca_Component_h
#include "gov_cca_Component.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif

/* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp._includes) */
/* Insert-Code-Here {arrayOps.CArrayOp._includes} (include files) */
/* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp._includes) */

/*
 * Private data for class arrayOps.CArrayOp
 */

struct arrayOps_CArrayOp__data {
  /* DO-NOT-DELETE splicer.begin(arrayOps.CArrayOp._data) */
  gov_cca_Services  frameworkServices;
  double 			  *myVector;
  int    			  myVecLen;
  /* DO-NOT-DELETE splicer.end(arrayOps.CArrayOp._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct arrayOps_CArrayOp__data*
arrayOps_CArrayOp__get_data(
  arrayOps_CArrayOp);

extern void
arrayOps_CArrayOp__set_data(
  arrayOps_CArrayOp,
  struct arrayOps_CArrayOp__data*);

extern
void
impl_arrayOps_CArrayOp__load(
  void);

extern
void
impl_arrayOps_CArrayOp__ctor(
  /* in */ arrayOps_CArrayOp self);

extern
void
impl_arrayOps_CArrayOp__dtor(
  /* in */ arrayOps_CArrayOp self);

/*
 * User-defined object methods
 */

extern struct gov_cca_CCAException__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_CCAException(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_gov_cca_CCAException(struct 
  gov_cca_CCAException__object* obj);
extern struct gov_cca_ComponentRelease__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_ComponentRelease(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_gov_cca_ComponentRelease(struct 
  gov_cca_ComponentRelease__object* obj);
extern struct arrayop_LinearOp__object* 
  impl_arrayOps_CArrayOp_fconnect_arrayop_LinearOp(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_arrayop_LinearOp(struct 
  arrayop_LinearOp__object* obj);
extern struct gov_cca_Services__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_Services(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_gov_cca_Services(struct 
  gov_cca_Services__object* obj);
extern struct arrayOps_CArrayOp__object* 
  impl_arrayOps_CArrayOp_fconnect_arrayOps_CArrayOp(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_arrayOps_CArrayOp(struct 
  arrayOps_CArrayOp__object* obj);
extern struct sidl_ClassInfo__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_ClassInfo(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_sidl_ClassInfo(struct 
  sidl_ClassInfo__object* obj);
extern struct gov_cca_Port__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_Port(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_gov_cca_Port(struct 
  gov_cca_Port__object* obj);
extern struct gov_cca_Component__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_Component(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_gov_cca_Component(struct 
  gov_cca_Component__object* obj);
extern struct sidl_BaseInterface__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_BaseInterface(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_sidl_BaseInterface(struct 
  sidl_BaseInterface__object* obj);
extern struct sidl_BaseClass__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_BaseClass(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_sidl_BaseClass(struct 
  sidl_BaseClass__object* obj);
extern
void
impl_arrayOps_CArrayOp_init(
  /* in */ arrayOps_CArrayOp self);

extern
int32_t
impl_arrayOps_CArrayOp_mulMatVec(
  /* in */ arrayOps_CArrayOp self,
  /* in */ double alpha,
  /* in rarray[m,n] */ double* A,
  /* in rarray[n] */ double* x,
  /* inout rarray[m] */ double* y,
  /* in */ int32_t m,
  /* in */ int32_t n);

extern
int32_t
impl_arrayOps_CArrayOp_addVec(
  /* in */ arrayOps_CArrayOp self,
  /* in */ double beta,
  /* in array<double> */ struct sidl_double__array* v,
  /* out array<double> */ struct sidl_double__array** r);

extern
int32_t
impl_arrayOps_CArrayOp_getResult(
  /* in */ arrayOps_CArrayOp self,
  /* inout rarray[m] */ double* r,
  /* in */ int32_t m);

extern
void
impl_arrayOps_CArrayOp_setServices(
  /* in */ arrayOps_CArrayOp self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_arrayOps_CArrayOp_releaseServices(
  /* in */ arrayOps_CArrayOp self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

extern struct gov_cca_CCAException__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_CCAException(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_gov_cca_CCAException(struct 
  gov_cca_CCAException__object* obj);
extern struct gov_cca_ComponentRelease__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_ComponentRelease(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_gov_cca_ComponentRelease(struct 
  gov_cca_ComponentRelease__object* obj);
extern struct arrayop_LinearOp__object* 
  impl_arrayOps_CArrayOp_fconnect_arrayop_LinearOp(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_arrayop_LinearOp(struct 
  arrayop_LinearOp__object* obj);
extern struct gov_cca_Services__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_Services(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_gov_cca_Services(struct 
  gov_cca_Services__object* obj);
extern struct arrayOps_CArrayOp__object* 
  impl_arrayOps_CArrayOp_fconnect_arrayOps_CArrayOp(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_arrayOps_CArrayOp(struct 
  arrayOps_CArrayOp__object* obj);
extern struct sidl_ClassInfo__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_ClassInfo(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_sidl_ClassInfo(struct 
  sidl_ClassInfo__object* obj);
extern struct gov_cca_Port__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_Port(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_gov_cca_Port(struct 
  gov_cca_Port__object* obj);
extern struct gov_cca_Component__object* 
  impl_arrayOps_CArrayOp_fconnect_gov_cca_Component(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_gov_cca_Component(struct 
  gov_cca_Component__object* obj);
extern struct sidl_BaseInterface__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_BaseInterface(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_sidl_BaseInterface(struct 
  sidl_BaseInterface__object* obj);
extern struct sidl_BaseClass__object* 
  impl_arrayOps_CArrayOp_fconnect_sidl_BaseClass(char* url,
  sidl_BaseInterface *_ex);
extern char* impl_arrayOps_CArrayOp_fgetURL_sidl_BaseClass(struct 
  sidl_BaseClass__object* obj);
#ifdef __cplusplus
}
#endif
#endif
