// 
// File:          pdrivers_CXXDriverMPI_Impl.hh
// Symbol:        pdrivers.CXXDriverMPI-v1.0
// Symbol Type:   class
// Babel Version: 0.10.12
// Description:   Server-side implementation for pdrivers.CXXDriverMPI
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.10.12
// xml-url       = /san/cca/elwasifw/tutorial-src/components/../xml_repository/pdrivers.CXXDriverMPI-v1.0.xml
// 

#ifndef included_pdrivers_CXXDriverMPI_Impl_hh
#define included_pdrivers_CXXDriverMPI_Impl_hh

#ifndef included_sidl_cxx_hh
#include "sidl_cxx.hh"
#endif
#ifndef included_pdrivers_CXXDriverMPI_IOR_h
#include "pdrivers_CXXDriverMPI_IOR.h"
#endif
// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hh
#include "gov_cca_CCAException.hh"
#endif
#ifndef included_gov_cca_Services_hh
#include "gov_cca_Services.hh"
#endif
#ifndef included_pdrivers_CXXDriverMPI_hh
#include "pdrivers_CXXDriverMPI.hh"
#endif
#ifndef included_sidl_BaseInterface_hh
#include "sidl_BaseInterface.hh"
#endif
#ifndef included_sidl_ClassInfo_hh
#include "sidl_ClassInfo.hh"
#endif


// DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI._includes)
// Insert-Code-Here {pdrivers.CXXDriverMPI._includes} (includes or arbitrary code)
#include "noSeekMPI.h"
#include <mpi.h> // or use the c++ header for your mpi if available.
#include "parallel_MPICommUser.hh"
#include "gov_cca_ports_GoPort.hh"
#include "ccaffeine_ports_MPIService.hh"
// DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI._includes)

namespace pdrivers { 

  /**
   * Symbol "pdrivers.CXXDriverMPI" (version 1.0)
   */
  class CXXDriverMPI_impl
  // DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI._inherits)
  // Insert-Code-Here {pdrivers.CXXDriverMPI._inherits} (optional inheritance here)
  // DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI._inherits)
  {

  private:
    // Pointer back to IOR.
    // Use this to dispatch back through IOR vtable.
    CXXDriverMPI self;

    // DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI._implementation)
    // Insert-Code-Here {pdrivers.CXXDriverMPI._implementation} (additional details)
    ::gov::cca::Services frameworkServices;
    ::ccaffeine::ports::MPIService mpiService;
    int64_t commSIDL; 
    MPI_Comm commC; 


    // DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI._implementation)

  private:
    // private default constructor (required)
    CXXDriverMPI_impl() 
    {} 

  public:
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    CXXDriverMPI_impl( struct pdrivers_CXXDriverMPI__object * s ) : self(s,
      true) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~CXXDriverMPI_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    int32_t
    go() throw () 
    ;
    /**
     * user defined non-static method.
     */
    void
    setServices (
      /* in */ ::gov::cca::Services services
    )
    throw ( 
      ::gov::cca::CCAException
    );

    /**
     * user defined non-static method.
     */
    void
    releaseServices (
      /* in */ ::gov::cca::Services services
    )
    throw ( 
      ::gov::cca::CCAException
    );

  };  // end class CXXDriverMPI_impl

} // end namespace pdrivers

// DO-NOT-DELETE splicer.begin(pdrivers.CXXDriverMPI._misc)
// Insert-Code-Here {pdrivers.CXXDriverMPI._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(pdrivers.CXXDriverMPI._misc)

#endif
