// 
// File:          library_CxxUnitsLibraryComp_Impl.hh
// Symbol:        library.CxxUnitsLibraryComp-v1.0
// Symbol Type:   class
// Babel Version: 0.10.12
// Description:   Server-side implementation for library.CxxUnitsLibraryComp
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.10.12
// xml-url       = /san/cca/elwasifw/tutorial-src/components/../xml_repository/library.CxxUnitsLibraryComp-v1.0.xml
// 

#ifndef included_library_CxxUnitsLibraryComp_Impl_hh
#define included_library_CxxUnitsLibraryComp_Impl_hh

#ifndef included_sidl_cxx_hh
#include "sidl_cxx.hh"
#endif
#ifndef included_library_CxxUnitsLibraryComp_IOR_h
#include "library_CxxUnitsLibraryComp_IOR.h"
#endif
// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hh
#include "gov_cca_CCAException.hh"
#endif
#ifndef included_gov_cca_Services_hh
#include "gov_cca_Services.hh"
#endif
#ifndef included_library_CxxUnitsLibraryComp_hh
#include "library_CxxUnitsLibraryComp.hh"
#endif
#ifndef included_sidl_BaseInterface_hh
#include "sidl_BaseInterface.hh"
#endif
#ifndef included_sidl_ClassInfo_hh
#include "sidl_ClassInfo.hh"
#endif
#ifndef included_units_Conversion_hh
#include "units_Conversion.hh"
#endif
#ifndef included_units_Unit_hh
#include "units_Unit.hh"
#endif
#ifndef included_units_UnknownUnitException_hh
#include "units_UnknownUnitException.hh"
#endif


// DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp._includes)
#include <map>
// DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp._includes)

namespace library { 

  /**
   * Symbol "library.CxxUnitsLibraryComp" (version 1.0)
   */
  class CxxUnitsLibraryComp_impl
  // DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp._inherits)
  // DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp._inherits)
  {

  private:
    // Pointer back to IOR.
    // Use this to dispatch back through IOR vtable.
    CxxUnitsLibraryComp self;

    // DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp._implementation)
    ::std::map<const ::std::string,::units::Unit> d_library;
    // DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp._implementation)

  private:
    // private default constructor (required)
    CxxUnitsLibraryComp_impl() 
    {} 

  public:
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    CxxUnitsLibraryComp_impl( struct library_CxxUnitsLibraryComp__object * s ) 
      : self(s,true) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~CxxUnitsLibraryComp_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // static class initializer
    static void _load();

  public:


    /**
     * Starts up a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning Svc and setServices:
     * 
     * The component interaction with the CCA framework
     * and Ports begins on the call to setServices by the framework.
     * 
     * This function is called exactly once for each instance created
     * by the framework.
     * 
     * The argument Svc will never be nil/null.
     * 
     * Those uses ports which are automatically connected by the framework
     * (so-called service-ports) may be obtained via getPort during
     * setServices.
     */
    void
    setServices (
      /* in */ ::gov::cca::Services services
    )
    throw ( 
      ::gov::cca::CCAException
    );


    /**
     * Generate conversion factors for a pair of units.
     */
    ::units::Conversion
    lookupConversion (
      /* in */ ::units::Unit src,
      /* in */ ::units::Unit dest
    )
    throw () 
    ;


    /**
     * Define a new unit. Units defined are automatically
     * registered in the library. slope and offset should
     * be defined so that <value in knownUnit> = slope *
     * <value in newUnit> + offset.
     */
    void
    defineUnit (
      /* in */ const ::std::string& name,
      /* in */ double slope,
      /* in */ double offset,
      /* in */ ::units::Unit knownUnit,
      /* out */ ::units::Unit& newUnit
    )
    throw () 
    ;


    /**
     * Transform a Conversion interface to convert values in the 
     * opposite direction. Note this can modify or replace the 
     * incoming parameter.
     */
    void
    invertConversion (
      /* inout */ ::units::Conversion& convert
    )
    throw () 
    ;


    /**
     * Lookup a unit definition. If no matching unit is found,
     * the UnknownUnitException is thrown.
     */
    ::units::Unit
    lookupUnit (
      /* in */ const ::std::string& name
    )
    throw ( 
      ::units::UnknownUnitException
    );

  };  // end class CxxUnitsLibraryComp_impl

} // end namespace library

// DO-NOT-DELETE splicer.begin(library.CxxUnitsLibraryComp._misc)
// Insert-Code-Here {library.CxxUnitsLibraryComp._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(library.CxxUnitsLibraryComp._misc)

#endif
