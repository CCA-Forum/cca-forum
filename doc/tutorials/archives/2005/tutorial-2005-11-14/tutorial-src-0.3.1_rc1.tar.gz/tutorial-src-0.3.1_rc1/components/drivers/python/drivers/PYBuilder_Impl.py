#
# File:          PYBuilder_Impl.py
# Symbol:        drivers.PYBuilder-v1.0
# Symbol Type:   class
# Babel Version: 0.10.12
# Description:   Implementation of sidl class drivers.PYBuilder in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
# babel-version = 0.10.12
# xml-url       = /san/cca/elwasifw/tutorial-src/components/../xml_repository/drivers.PYBuilder-v1.0.xml
#


# DO-NOT-DELETE splicer.begin(_initial)
# Put your code here...
import sys
import time
# DO-NOT-DELETE splicer.end(_initial)

import gov.cca.CCAException
import gov.cca.ports.GoPort
import drivers.PYBuilder
import gov.cca.Services
import sidl.ClassInfo
import gov.cca.Port
import gov.cca.Component
import sidl.BaseInterface
import sidl.BaseClass

# DO-NOT-DELETE splicer.begin(_before_type)
# Put your code here...
import gov.cca.ports.BuilderService        # Builder Services interface
import integrator.IntegratorPort           # Access to Integrator port
import gov.cca.ConnectionID
import gov.cca.ComponentRelease
# DO-NOT-DELETE splicer.end(_before_type)

class PYBuilder:

  # All calls to sidl methods should use __IORself

  def __init__(self, IORself):
    self.__IORself = IORself
    # DO-NOT-DELETE splicer.begin(__init__)
    # Put your code here...
    self.myservices = None 
    # DO-NOT-DELETE splicer.end(__init__)

  def go(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # int _return
    #

    """\
Execute some encapsulated functionality on the component. 
Return 0 if ok, -1 if internal error but component may be 
used further, and -2 if error so severe that component cannot
be further used safely.
"""
    # DO-NOT-DELETE splicer.begin(go)
    # Put your code here...
    
    mymap = self.myservices.createTypeMap()
    availableIntegrators = [ ("Midpoint_Integrator", "integrators.Midpoint"), 
                             ("Trapezoid_Integrator", "integrators.Trapezoid"),
                             ("Simpson_Integrator", "integrators.Simpson") ]   
    
    try:
      self.myservices.registerUsesPort('IntegratorPort', 
                                 'integrator.IntegratorPort', 
                                 mymap);
    except:
      print sys.exc_type, sys.exc_info()
      print 'Caught an exception in call to registerUsesPort()'
       
    try:
      self.myservices.registerUsesPort('BuilderPort', 
                                'gov.cca.BuilderService', 
                                 mymap);
    except:
      print 'Caught an exception in call to registerUsesPort()'
      print sys.exc_type, sys.exc_info()
    
    try:
      bport = self.myservices.getPort('BuilderPort')
    except:
      print 'Caught an exception in call to getPort(\'BuilderPort\')'
      print sys.exc_type, sys.exc_info()
    
    try:
      bldport = gov.cca.ports.BuilderService.BuilderService(bport);
    except:
      print 'Caught an exception in call to BuilderService.BuilderService(bport)'
      print sys.exc_type, sys.exc_info()
      
    try:
      myid = self.myservices.getComponentID(); # this is my ComponentID
    except:
      print 'Caught an exception in call to getComponentID()'
      print sys.exc_type, sys.exc_info()
      
    integratorID = None
    for ai in availableIntegrators:
       try:
         integratorID = bldport.createInstance(ai[0], ai[1], mymap)
       except:
         print 'Unable to instantiate component class', ai[1]
       else:
         break   
      
    if (integratorID == None):
       print "Unable to instantiate any integrator component... Exiting"
       exit(1)
      
    try:
      functionID = bldport.createInstance("Pi_Function", \
                                          "functions.PiFunction", \
                                           mymap)
    except:
      print 'Caught an exception in call to createInstance()'
      print sys.exc_type, sys.exc_info()
        
    try:
      intConn = bldport.connect(myid, "IntegratorPort", integratorID, "IntegratorPort")
    except:
      print 'Caught an exception in call to connect()'
      print sys.exc_type, sys.exc_info()
    
    try:
      funConn = bldport.connect(integratorID, "FunctionPort", functionID, "FunctionPort")
    except:
      print 'Caught an exception in call to connect2()'
      print sys.exc_type, sys.exc_info()
      
    try:
      intport = self.myservices.getPort('IntegratorPort')
    except:
      print 'Caught an exception in call to getPort(''IntegratorPort'')'
      print sys.exc_type, sys.exc_info()
    
    try:
      myintport = integrator.IntegratorPort.IntegratorPort(intport)   # Casting !!!!
    except:
      print 'Caught an exception in call to cast(''IntegratorPort'')'
      print sys.exc_type, sys.exc_info()
      
    result = myintport.integrate(0.0, 1.0, 10000)  
    print 'Result = ', result
    
    try:
      self.myservices.releasePort('IntegratorPort');
    except:
      print 'Caught an exception in call to releasePort(\'IntegratorPort\')'
      print sys.exc_type, sys.exc_info()
      
    try:
      bldport.disconnect(intConn, 0)
    except:
      print 'Caught an exception in call to disconnect(intConn)'
      print intConn, sys.exc_type, sys.exc_info()
    
    try:
      self.myservices.unregisterUsesPort('IntegratorPort');
    except:
      print 'Caught an exception in call to unRegisterUsesPort(\'IntegratorPort\')'
      print sys.exc_type, sys.exc_info()
      
    try:
      bldport.disconnect(funConn, 0)
    except:
      print 'Caught an exception in call to disconnect(funConn)'
      print sys.exc_type, sys.exc_info()
      
    try:
      bldport.destroyInstance(functionID, 0)
    except:
      print 'Caught an exception in call to destroyInstance(functionID)'
      print sys.exc_type, sys.exc_info()
      
    try:
      bldport.destroyInstance(integratorID, 0)
    except:
      print 'Caught an exception in call to destroyInstance(integratorID)'
      print sys.exc_type, sys.exc_info()
    
    try:
      self.myservices.releasePort('BuilderPort');
    except:
      print 'Caught an exception in call to releasePort(\'BuilderPort\')'
      print sys.exc_type, sys.exc_info()
      
    try:
      self.myservices.unregisterUsesPort('BuilderPort');
    except:
      print 'Caught an exception in call to unRegisterUsesPort(\'BuilderPort\')'
      print sys.exc_type, sys.exc_info()
      
    return 0
       
    # DO-NOT-DELETE splicer.end(go)

  def setServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # # None
    #

    """\
Starts up a component presence in the calling framework.
@param services the component instance's handle on the framework world.
Contracts concerning Svc and setServices:

The component interaction with the CCA framework
and Ports begins on the call to setServices by the framework.

This function is called exactly once for each instance created
by the framework.

The argument Svc will never be nil/null.

Those uses ports which are automatically connected by the framework
(so-called service-ports) may be obtained via getPort during
setServices.
"""
    # DO-NOT-DELETE splicer.begin(setServices)
    # Put your code here...
    self.myservices = services 
    
    mymap = services.createTypeMap()
    try:
      me = gov.cca.Component.Component(self.__IORself)  # Casting !!!!
    except:
      print 'Caught an exception in cast to gov.cca.Component'
      print sys.exc_type, sys.exc_info()
      
    try:
      services.addProvidesPort(me, 
                              'GoPort', 
                              'gov.cca.ports.GoPort', 
                              mymap);
    except:
      print 'Caught an exception in call to addProvidesPort()'
      print sys.exc_type, sys.exc_info()
    
    print 'Python drivers.PYBuilder done with setServices()'
    # DO-NOT-DELETE splicer.end(setServices)

# DO-NOT-DELETE splicer.begin(_final)
# Put your code here...
# DO-NOT-DELETE splicer.end(_final)
