// 
// File:          integrators_Trapezoid_Impl.hh
// Symbol:        integrators.Trapezoid-v1.0
// Symbol Type:   class
// Babel Version: 0.10.12
// Description:   Server-side implementation for integrators.Trapezoid
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.10.12
// xml-url       = /san/cca/elwasifw/tutorial-src/components/../xml_repository/integrators.Trapezoid-v1.0.xml
// 

#ifndef included_integrators_Trapezoid_Impl_hh
#define included_integrators_Trapezoid_Impl_hh

#ifndef included_sidl_cxx_hh
#include "sidl_cxx.hh"
#endif
#ifndef included_integrators_Trapezoid_IOR_h
#include "integrators_Trapezoid_IOR.h"
#endif
// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hh
#include "gov_cca_CCAException.hh"
#endif
#ifndef included_gov_cca_Services_hh
#include "gov_cca_Services.hh"
#endif
#ifndef included_integrators_Trapezoid_hh
#include "integrators_Trapezoid.hh"
#endif
#ifndef included_sidl_BaseInterface_hh
#include "sidl_BaseInterface.hh"
#endif
#ifndef included_sidl_ClassInfo_hh
#include "sidl_ClassInfo.hh"
#endif


// DO-NOT-DELETE splicer.begin(integrators.Trapezoid._includes)
// Insert-Code-Here {integrators.Trapezoid._includes} (includes or arbitrary code)
// DO-NOT-DELETE splicer.end(integrators.Trapezoid._includes)

namespace integrators { 

  /**
   * Symbol "integrators.Trapezoid" (version 1.0)
   */
  class Trapezoid_impl
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid._inherits)
  // Insert-Code-Here {integrators.Trapezoid._inherits} (optional inheritance here)
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid._inherits)
  {

  private:
    // Pointer back to IOR.
    // Use this to dispatch back through IOR vtable.
    Trapezoid self;

    // DO-NOT-DELETE splicer.begin(integrators.Trapezoid._implementation)
    // Insert-Code-Here {integrators.Trapezoid._implementation} (additional details)
    gov::cca::Services  frameworkServices; 
    // DO-NOT-DELETE splicer.end(integrators.Trapezoid._implementation)

  private:
    // private default constructor (required)
    Trapezoid_impl() 
    {} 

  public:
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    Trapezoid_impl( struct integrators_Trapezoid__object * s ) : self(s,
      true) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~Trapezoid_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    double
    integrate (
      /* in */ double lowBound,
      /* in */ double upBound,
      /* in */ int32_t count
    )
    throw () 
    ;


    /**
     * Starts up a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning Svc and setServices:
     * 
     * The component interaction with the CCA framework
     * and Ports begins on the call to setServices by the framework.
     * 
     * This function is called exactly once for each instance created
     * by the framework.
     * 
     * The argument Svc will never be nil/null.
     * 
     * Those uses ports which are automatically connected by the framework
     * (so-called service-ports) may be obtained via getPort during
     * setServices.
     */
    void
    setServices (
      /* in */ ::gov::cca::Services services
    )
    throw ( 
      ::gov::cca::CCAException
    );


    /**
     * Shuts down a component presence in the calling framework.
     * @param Svc the component instance's handle on the framework world.
     * Contracts concerning Svc and setServices:
     * 
     * This function is called exactly once for each callback registered
     * through Services.
     * 
     * The argument Svc will never be nil/null.
     * The argument Svc will always be the same as that received in
     * setServices.
     * 
     * During this call the component should release any interfaces
     * acquired by getPort().
     * 
     * During this call the component should reset to nil any stored
     * reference to Svc.
     * 
     * After this call, the component instance will be removed from the
     * framework. If the component instance was created by the
     * framework, it will be destroyed, not recycled, The behavior of
     * any port references obtained from this component instance and
     * stored elsewhere becomes undefined.
     * 
     * Notes for the component implementor:
     * 1) The component writer may perform blocking activities
     * within releaseServices, such as waiting for remote computations
     * to shutdown.
     * 2) It is good practice during releaseServices for the component
     * writer to remove or unregister all the ports it defined.
     */
    void
    releaseServices (
      /* in */ ::gov::cca::Services services
    )
    throw ( 
      ::gov::cca::CCAException
    );

  };  // end class Trapezoid_impl

} // end namespace integrators

// DO-NOT-DELETE splicer.begin(integrators.Trapezoid._misc)
// Insert-Code-Here {integrators.Trapezoid._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(integrators.Trapezoid._misc)

#endif
