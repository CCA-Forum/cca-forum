// 
// File:          library_CxxUnknownException_Impl.cc
// Symbol:        library.CxxUnknownException-v1.0
// Symbol Type:   class
// Babel Version: 0.10.12
// Description:   Server-side implementation for library.CxxUnknownException
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.10.12
// xml-url       = /san/cca/elwasifw/tutorial-src/components/../xml_repository/library.CxxUnknownException-v1.0.xml
// 
#include "library_CxxUnknownException_Impl.hh"

// DO-NOT-DELETE splicer.begin(library.CxxUnknownException._includes)
// Insert-Code-Here {library.CxxUnknownException._includes} (additional includes or code)
// DO-NOT-DELETE splicer.end(library.CxxUnknownException._includes)

// user-defined constructor.
void library::CxxUnknownException_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(library.CxxUnknownException._ctor)
  // nothing needed here
  // DO-NOT-DELETE splicer.end(library.CxxUnknownException._ctor)
}

// user-defined destructor.
void library::CxxUnknownException_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(library.CxxUnknownException._dtor)
  // nothing needed here
  // DO-NOT-DELETE splicer.end(library.CxxUnknownException._dtor)
}

// static class initializer.
void library::CxxUnknownException_impl::_load() {
  // DO-NOT-DELETE splicer.begin(library.CxxUnknownException._load)
  // Insert-Code-Here {library.CxxUnknownException._load} (class initialization)
  // DO-NOT-DELETE splicer.end(library.CxxUnknownException._load)
}

// user-defined static methods: (none)

// user-defined non-static methods: (none)

// DO-NOT-DELETE splicer.begin(library.CxxUnknownException._misc)
// Insert-Code-Here {library.CxxUnknownException._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(library.CxxUnknownException._misc)

