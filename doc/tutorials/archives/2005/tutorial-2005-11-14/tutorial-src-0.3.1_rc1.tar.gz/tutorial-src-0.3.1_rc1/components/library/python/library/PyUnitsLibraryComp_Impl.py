#
# File:          PyUnitsLibraryComp_Impl.py
# Symbol:        library.PyUnitsLibraryComp-v1.0
# Symbol Type:   class
# Babel Version: 0.10.12
# Description:   Implementation of sidl class library.PyUnitsLibraryComp in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
# babel-version = 0.10.12
# xml-url       = /san/cca/elwasifw/tutorial-src/components/../xml_repository/library.PyUnitsLibraryComp-v1.0.xml
#


# DO-NOT-DELETE splicer.begin(_initial)
# DO-NOT-DELETE splicer.end(_initial)

import units.UnknownUnitException
import gov.cca.CCAException
import units.UnitsLibrary
import gov.cca.Services
import sidl.ClassInfo
import library.PyUnitsLibraryComp
import gov.cca.Port
import gov.cca.Component
import units.Unit
import units.Conversion
import sidl.BaseInterface
import sidl.BaseClass

# DO-NOT-DELETE splicer.begin(_before_type)
import library.PySimpleUnit
import library.PySimpleConversion
import library.PyUnknownException
_predefUnits = [
  [ "kilogram", 1.0, 0.0 ],
  [ "kg", 1.0, 0.0 ],
  [ "pound", 0.45359237, 0.0 ],
  [ "gram", 0.001, 0.0 ],
  [ "meter", 1.0, 0.0 ],
  [ "inch", 0.0254, 0.0],
  [ "feet", 0.3048, 0.0],
  [ "kilometer", 1000.0, 0.0],
  [ "cm", 0.01, 0.0],
  [ "second", 1.0, 0.0],
  [ "minute", 60.0, 0.0],
  [ "hour", 3600.0, 0.0],
  [ "ampere", 1.0, 0.0],
  [ "Kelvin", 1.0, 0.0],
  [ "Candela", 1.0, 0.0],
  [ "mole", 1.0, 0.0]
]
# DO-NOT-DELETE splicer.end(_before_type)

class PyUnitsLibraryComp:

  # All calls to sidl methods should use __IORself

  def __init__(self, IORself):
    self.__IORself = IORself
    # DO-NOT-DELETE splicer.begin(__init__)
    self.d_library = { }
    for i in _predefUnits:
      self.d_library[i[0]] = library.PySimpleUnit.build(i[0],i[1],i[2])
    # DO-NOT-DELETE splicer.end(__init__)

  def setServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # # None
    #

    """\
Starts up a component presence in the calling framework.
@param services the component instance's handle on the framework world.
Contracts concerning Svc and setServices:

The component interaction with the CCA framework
and Ports begins on the call to setServices by the framework.

This function is called exactly once for each instance created
by the framework.

The argument Svc will never be nil/null.

Those uses ports which are automatically connected by the framework
(so-called service-ports) may be obtained via getPort during
setServices.
"""
    # DO-NOT-DELETE splicer.begin(setServices)
    services.addProvidesPort(self.__IORself,
                             "UnitLibraryPort",
                             "units.UnitsLibrary",
                             services.createTypeMap())
    # DO-NOT-DELETE splicer.end(setServices)

  def lookupConversion(self, src, dest):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # units.Unit src
    # units.Unit dest
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # units.Conversion _return
    #

    """\
Generate conversion factors for a pair of units.
"""
    # DO-NOT-DELETE splicer.begin(lookupConversion)
    return library.PySimpleConversion.build(src, dest)
    # DO-NOT-DELETE splicer.end(lookupConversion)

  def defineUnit(self, name, slope, offset, knownUnit):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # string name
    # double slope
    # double offset
    # units.Unit knownUnit
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # units.Unit newUnit
    #

    """\
Define a new unit. Units defined are automatically
registered in the library. slope and offset should
be defined so that <value in knownUnit> = slope *
<value in newUnit> + offset.
"""
    # DO-NOT-DELETE splicer.begin(defineUnit)
    knownSlope, knownOffset = knownUnit.conversionFactors()
    return library.PySimpleUnit.build(name, knownSlope * slope,
                                      knownSlope*offset + knownOffset)
    # DO-NOT-DELETE splicer.end(defineUnit)

  def invertConversion(self, convert):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # units.Conversion convert
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # units.Conversion convert
    #

    """\
Transform a Conversion interface to convert values in the 
opposite direction. Note this can modify or replace the 
incoming parameter.
"""
    # DO-NOT-DELETE splicer.begin(invertConversion)
    sc = library.PySimpleConversion.PySimpleConversion(convert)
    sc.reverse()
    return sc
    # DO-NOT-DELETE splicer.end(invertConversion)

  def lookupUnit(self, name):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # string name
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # units.Unit _return
    #

    """\
Lookup a unit definition. If no matching unit is found,
the UnknownUnitException is thrown.
"""
    # DO-NOT-DELETE splicer.begin(lookupUnit)
    if self.d_library.has_key(name):
      return self.d_library[name]
    else:
      uue = library.PyUnknownException.PyUnknownException()
      uue.setNote("Unit \"" + name + "\" is not known to the library.")
      raise units.UnknownUnitException._Exception, uue
    # DO-NOT-DELETE splicer.end(lookupUnit)

# DO-NOT-DELETE splicer.begin(_final)
# DO-NOT-DELETE splicer.end(_final)
