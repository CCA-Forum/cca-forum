#!/bin/sh
function usage () {
 	echo "$0: usage: <mode> <libpath> <babelClassName> <palette-alias> <language> [dynamic <scope> <resolution>]" > /dev/stderr
	echo "This script generates to stdout .scl or .cca files which are installed next to the" > /dev/stderr
	echo "library in the same directory under some name xxxxxx.depl.cca. or libpath.scl." > /dev/stderr
	echo "The script creates scl and cca info in cca mode or just babel info in scl mode." > /dev/stderr
	echo " Arguments: mode is cca or scl." > /dev/stderr
	echo "            libpath is the full path of the .la, .o, .so, or .a file" > /dev/stderr
	echo "            babelClassName is the full dot-qualified babel.class.name of the component." > /dev/stderr
	echo "            palette-alias is the string name to be used in the user interface" > /dev/stderr
	echo "            language is the implementation language (c c++ f77 f90 python)" > /dev/stderr
	echo " Optional arguments (if library is dynamically loadable)" > /dev/stderr
	echo "            dynamic -- required literal. just put it there." > /dev/stderr
	echo "            scope is global or private" > /dev/stderr
	echo "            resolution is now or lazy" > /dev/stderr
	echo " If optional arguments are not given, static is assumed." > /dev/stderr
	echo "e.g.: $0 scl /somewhere/lib/libComponent3.a test3.Component1 Comp3" > /dev/stderr
	echo "e.g.: $0 cca /somewhere/lib/libComponent2.so test2.Component1 Comp2 dynamic global lazy" > /dev/stderr
	echo "e.g.: $0 scl /somewhere/lib/libComponent1.la test1.Component1 Comp1 dynamic private now" > /dev/stderr
	echo "e.g.: $0 cca /somewhere/lib/libComponent0.la test0.Component1 test0.Component1" > /dev/stderr
}
if test $# -lt 5; then
	usage
	exit 1;
fi
dstring=`date`
pstring=`pwd`/
mode=$1
libpath=$2
className=$3
palias="paletteClassAlias=\"$4\""
language=$5
scope=global
resolution=now
dynamic=static
if test $# -ge 7; then
	scope=$7
	dynamic=dynamic
fi
if test $# -ge 8; then
	resolution=$8
	dynamic=dynamic
fi
#echo $mode
#echo $libpath
#echo $className
#echo $palias
#echo $language
#echo $dynamic
#echo $scope
#echo $resolution
#exit 0
if [ "$language" == python ] ; then
  pythonImplLine="<class name=\"$className\" desc=\"python/impl\" />"
fi;  
if test "x$mode" = "xscl"; then
cat << __EOF1
<?xml version="1.0"?> 
<!-- # generated scl index. -->
<!-- date=$dstring -->
<!-- builder=$USER@$HOST -->
<!-- $0 $* -->
<scl>
  <library uri="$libpath" 
	scope="$scope" 
	resolution="$resolution" > 
    <class name="$className" desc="ior/impl" />
    $pythonImplLine
  </library>
</scl>
__EOF1
exit 0
fi

if test "x$mode" = "xcca"; then
cat << __EOF2
<?xml version="1.0"?> 
<libInfo>
<!-- # generated component index. -->
<!-- date=$dstring -->
<!-- builder=$USER@$HOST -->
<!-- $0 $* -->
<scl>
  <library uri="$libpath" 
	scope="$scope" 
	resolution="$resolution" > 
    <class name="$className" desc="ior/impl" />
    $pythonImplLine
  </library>
</scl>
<componentDeployment 
  name="$className"
  $palias
>
    <environment> 
        <ccaSpec binding="babel" /> 
        <library loading="$dynamic" />
    </environment>
</componentDeployment>
</libInfo>
__EOF2
exit 0
fi

echo "$0: Unrecognized mode" > /dev/stderr
usage
exit 1
