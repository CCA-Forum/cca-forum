#!/bin/sh
		
ulangs=$1
blangs=$2
langs="" 
for i in $ulangs; do 
	for j in $blangs; do 
		if [ "x$i" == "x$j" ]; then 
			langs="$langs $i"; 
		fi; 
	done; 
done; 
echo $langs
