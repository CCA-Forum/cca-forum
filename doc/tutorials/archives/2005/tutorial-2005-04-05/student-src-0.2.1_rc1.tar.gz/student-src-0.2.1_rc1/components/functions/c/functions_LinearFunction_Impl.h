/*
 * File:          functions_LinearFunction_Impl.h
 * Symbol:        functions.LinearFunction-v1.0
 * Symbol Type:   class
 * Babel Version: 0.10.2
 * Description:   Server-side implementation for functions.LinearFunction
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 * babel-version = 0.10.2
 */

#ifndef included_functions_LinearFunction_Impl_h
#define included_functions_LinearFunction_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_gov_cca_CCAException_h
#include "gov_cca_CCAException.h"
#endif
#ifndef included_gov_cca_Services_h
#include "gov_cca_Services.h"
#endif
#ifndef included_functions_LinearFunction_h
#include "functions_LinearFunction.h"
#endif
#ifndef included_sidl_BaseException_h
#include "sidl_BaseException.h"
#endif

/* DO-NOT-DELETE splicer.begin(functions.LinearFunction._includes) */
/* Put additional include files here... */
/* DO-NOT-DELETE splicer.end(functions.LinearFunction._includes) */

/*
 * Private data for class functions.LinearFunction
 */

struct functions_LinearFunction__data {
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._data) */
  /* Put private data members here... */

  /* Handle to framework services object */
  gov_cca_Services frameworkServices;

  /* DO-NOT-DELETE splicer.end(functions.LinearFunction._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct functions_LinearFunction__data*
functions_LinearFunction__get_data(
  functions_LinearFunction);

extern void
functions_LinearFunction__set_data(
  functions_LinearFunction,
  struct functions_LinearFunction__data*);

extern void
impl_functions_LinearFunction__load(
  void);

extern void
impl_functions_LinearFunction__ctor(
  /* in */ functions_LinearFunction self);

extern void
impl_functions_LinearFunction__dtor(
  /* in */ functions_LinearFunction self);

/*
 * User-defined object methods
 */

extern void
impl_functions_LinearFunction_init(
  /* in */ functions_LinearFunction self,
  /* in */ struct sidl_double__array* params);

extern double
impl_functions_LinearFunction_evaluate(
  /* in */ functions_LinearFunction self,
  /* in */ double x);

extern void
impl_functions_LinearFunction_setServices(
  /* in */ functions_LinearFunction self,
  /* in */ gov_cca_Services servicesHandle,
  /* out */ sidl_BaseInterface *_ex);

#ifdef __cplusplus
}
#endif
#endif
