// 
// File:          integrators_Trapezoid_Impl.cc
// Symbol:        integrators.Trapezoid-v1.0
// Symbol Type:   class
// Babel Version: 0.10.2
// Description:   Server-side implementation for integrators.Trapezoid
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.10.2
// 
#include "integrators_Trapezoid_Impl.hh"

// DO-NOT-DELETE splicer.begin(integrators.Trapezoid._includes)
// Put additional includes or other arbitrary code here...
#include "function_FunctionPort.hh"
// DO-NOT-DELETE splicer.end(integrators.Trapezoid._includes)

// user-defined constructor.
void integrators::Trapezoid_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid._ctor)
  // add construction details here
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid._ctor)
}

// user-defined destructor.
void integrators::Trapezoid_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid._dtor)
  // add destruction details here
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid._dtor)
}

// static class initializer.
void integrators::Trapezoid_impl::_load() {
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid._load)
  // Insert-Code-Here {integrators.Trapezoid._load} (class initialization)
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid._load)
}

// user-defined static methods: (none)

// user-defined non-static methods:
/**
 * Shuts down a component presence in the calling framework.
 * @param Svc the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument Svc will never be nil/null.
 * The argument Svc will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to Svc.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
integrators::Trapezoid_impl::releaseServices (
  /* in */ ::gov::cca::Services Svc ) 
throw ( 
  ::gov::cca::CCAException
){
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid.releaseServices)
  // insert implementation here
  myServices = 0;
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid.releaseServices)
}

/**
 * Starts up a component presence in the calling framework.
 * @param Svc the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument Svc will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
integrators::Trapezoid_impl::setServices (
  /* in */ ::gov::cca::Services services ) 
throw ( 
  ::gov::cca::CCAException
){
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid.setServices)
  // insert implementation here
  
    myServices = services;
    gov::cca::TypeMap tm = services.createTypeMap();
    if(tm._is_nil()) {
       fprintf(stderr, "Error:: %s:%d: gov::cca::TypeMap is nil\n",
          __FILE__, __LINE__);
       exit(1);  
    } 
    gov::cca::Port p = self;      //  Babel required casting
    if(p._is_nil()) {
       fprintf(stderr, "Error:: %s:%d: Error casting self to gov::cca::Port \n",
          __FILE__, __LINE__);
       exit(1);
    } 
    
    services.addProvidesPort(p,
                             "IntegratorPort",
                             "integrator.IntegratorPort", tm);
    
    services.registerUsesPort("FunctionPort",
          							"function.FunctionPort", tm);
    
    gov::cca::ComponentRelease cr = self;  //  Babel required casting
    services.registerForRelease(cr);
    return;
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid.setServices)
}

/**
 * Method:  integrate[]
 */
double
integrators::Trapezoid_impl::integrate (
  /* in */ double lowBound,
  /* in */ double upBound,
  /* in */ int32_t count ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid.integrate)
  // insert implementation here
   function::FunctionPort  myFunPort;
   gov::cca::Port          generalPort;
   
   generalPort = myServices.getPort("FunctionPort");
   if (generalPort._is_nil()){
       fprintf(stderr, "Error:: %s:%d: generalPort is nil - \
             maybe I'm not connected to any port!!\n",
             __FILE__, __LINE__);
       exit(1);  
    }
     
    myFunPort = generalPort;
    if (myFunPort._is_nil()){
       fprintf(stderr, "Error:: %s:%d: myFunPort is nil - \
             maybe I'm connected to the wrong \"Provides\" port!!\n",
             __FILE__, __LINE__);
       exit(1);  
    }
    
    double h = (upBound - lowBound) / count;
    double retval = 0.0;
    double sum = 0.0;
    for (int i = 1; i <= count; i++){
       sum += myFunPort.evaluate(lowBound + (i - 1) * h) +
              myFunPort.evaluate(lowBound + i * h);
    }
    retval = h/2.0 * sum;
    myServices.releasePort("FunctionPort");
    return retval;
      
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid.integrate)
}


// DO-NOT-DELETE splicer.begin(integrators.Trapezoid._misc)
// Put miscellaneous code here
// DO-NOT-DELETE splicer.end(integrators.Trapezoid._misc)

