// 
// File:          functions_CubeFunction_Impl.hh
// Symbol:        functions.CubeFunction-v1.0
// Symbol Type:   class
// Babel Version: 0.10.2
// Description:   Server-side implementation for functions.CubeFunction
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.10.2
// 

#ifndef included_functions_CubeFunction_Impl_hh
#define included_functions_CubeFunction_Impl_hh

#ifndef included_sidl_cxx_hh
#include "sidl_cxx.hh"
#endif
#ifndef included_functions_CubeFunction_IOR_h
#include "functions_CubeFunction_IOR.h"
#endif
// 
// Includes for all method dependencies.
// 
#ifndef included_functions_CubeFunction_hh
#include "functions_CubeFunction.hh"
#endif
#ifndef included_gov_cca_CCAException_hh
#include "gov_cca_CCAException.hh"
#endif
#ifndef included_gov_cca_Services_hh
#include "gov_cca_Services.hh"
#endif
#ifndef included_sidl_BaseInterface_hh
#include "sidl_BaseInterface.hh"
#endif
#ifndef included_sidl_ClassInfo_hh
#include "sidl_ClassInfo.hh"
#endif


// DO-NOT-DELETE splicer.begin(functions.CubeFunction._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(functions.CubeFunction._includes)

namespace functions { 

  /**
   * Symbol "functions.CubeFunction" (version 1.0)
   */
  class CubeFunction_impl
  // DO-NOT-DELETE splicer.begin(functions.CubeFunction._inherits)
  // Put additional inheritance here...
  // DO-NOT-DELETE splicer.end(functions.CubeFunction._inherits)
  {

  private:
    // Pointer back to IOR.
    // Use this to dispatch back through IOR vtable.
    CubeFunction self;

    // DO-NOT-DELETE splicer.begin(functions.CubeFunction._implementation)
    // Put additional implementation details here...
    gov::cca::Services    myServices;
    // DO-NOT-DELETE splicer.end(functions.CubeFunction._implementation)

  private:
    // private default constructor (required)
    CubeFunction_impl() 
    {} 

  public:
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    CubeFunction_impl( struct functions_CubeFunction__object * s ) : self(s,
      true) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~CubeFunction_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    void
    init (
      /* in */ ::sidl::array<double> params
    )
    throw () 
    ;

    /**
     * user defined non-static method.
     */
    double
    evaluate (
      /* in */ double x
    )
    throw () 
    ;


    /**
     * Starts up a component presence in the calling framework.
     * @param Svc the component instance's handle on the framework world.
     * Contracts concerning Svc and setServices:
     * 
     * The component interaction with the CCA framework
     * and Ports begins on the call to setServices by the framework.
     * 
     * This function is called exactly once for each instance created
     * by the framework.
     * 
     * The argument Svc will never be nil/null.
     * 
     * Those uses ports which are automatically connected by the framework
     * (so-called service-ports) may be obtained via getPort during
     * setServices.
     */
    void
    setServices (
      /* in */ ::gov::cca::Services services
    )
    throw ( 
      ::gov::cca::CCAException
    );

  };  // end class CubeFunction_impl

} // end namespace functions

// DO-NOT-DELETE splicer.begin(functions.CubeFunction._misc)
// Put miscellaneous things here...
// DO-NOT-DELETE splicer.end(functions.CubeFunction._misc)

#endif
