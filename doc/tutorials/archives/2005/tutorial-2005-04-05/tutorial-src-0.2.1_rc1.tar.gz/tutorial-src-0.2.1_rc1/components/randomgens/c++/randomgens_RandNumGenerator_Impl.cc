// 
// File:          randomgens_RandNumGenerator_Impl.cc
// Symbol:        randomgens.RandNumGenerator-v1.0
// Symbol Type:   class
// Babel Version: 0.10.2
// Description:   Server-side implementation for randomgens.RandNumGenerator
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.10.2
// 
#include "randomgens_RandNumGenerator_Impl.hh"

// DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator._includes)
// Put additional includes or other arbitrary code here...

#include <stdlib.h>
#include <time.h>
#include <stdio.h>

// DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator._includes)

// user-defined constructor.
void randomgens::RandNumGenerator_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator._ctor)
  // add construction details here

	// Set initial seed 
	srand( (unsigned)time( NULL ) );

  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator._ctor)
}

// user-defined destructor.
void randomgens::RandNumGenerator_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator._dtor)
  // add destruction details here
  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator._dtor)
}

// static class initializer.
void randomgens::RandNumGenerator_impl::_load() {
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator._load)
  // Insert-Code-Here {randomgens.RandNumGenerator._load} (class initialization)
  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator._load)
}

// user-defined static methods: (none)

// user-defined non-static methods:
/**
 * Method:  getRandomNumber[]
 */
double
randomgens::RandNumGenerator_impl::getRandomNumber ()
throw () 

{
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator.getRandomNumber)
  // insert implementation here

  double random_value = static_cast < double >(rand ());
  return random_value / RAND_MAX;

  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator.getRandomNumber)
}

/**
 * Starts up a component presence in the calling framework.
 * @param Svc the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument Svc will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
randomgens::RandNumGenerator_impl::setServices (
  /* in */ ::gov::cca::Services services ) 
throw ( 
  ::gov::cca::CCAException
){
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator.setServices)
  // insert implementation here

  frameworkServices = services;
  
  if(frameworkServices._not_nil()) {
    gov::cca::TypeMap tm = frameworkServices.createTypeMap();
    if(tm._is_nil()) {
      fprintf(stderr, "%s:%d: gov::cca::TypeMap is nil\n",
          __FILE__, __LINE__);
    }
    
    gov::cca::Port p = self;       // Babel-required cast
    
    if(p._is_nil()) {
      fprintf(stderr, "%s:%d: p is nil\n", __FILE__, __LINE__);
    } 
    
    frameworkServices.addProvidesPort(p,
                                      "RandomGeneratorPort",
                                      "randomgen.RandomGeneratorPort",
                                      tm);
  }
  
  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator.setServices)
}


// DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator._misc)
// Put miscellaneous code here
// DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator._misc)

