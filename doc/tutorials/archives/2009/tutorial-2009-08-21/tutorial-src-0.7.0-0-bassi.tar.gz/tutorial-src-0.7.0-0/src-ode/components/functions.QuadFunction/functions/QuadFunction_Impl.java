/*
 * File:          QuadFunction_Impl.java
 * Symbol:        functions.QuadFunction-v0.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for functions.QuadFunction
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package functions;

import function.FunctionPort;
import gov.cca.CCAException;
import gov.cca.Component;
import gov.cca.ComponentRelease;
import gov.cca.Port;
import gov.cca.Services;
import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;

// DO-NOT-DELETE splicer.begin(functions.QuadFunction._imports)
// DO-NOT-DELETE splicer.end(functions.QuadFunction._imports)

/**
 * Symbol "functions.QuadFunction" (version 0.0)
 */
public class QuadFunction_Impl extends QuadFunction
{

   // DO-NOT-DELETE splicer.begin(functions.QuadFunction._data)
   // Bocca generated code. bocca.protected.begin(functions.QuadFunction._data)
    gov.cca.Services    d_services;
    public boolean bocca_print_errs = true;
   // Bocca generated code. bocca.protected.end(functions.QuadFunction._data)
    // DO-NOT-DELETE splicer.end(functions.QuadFunction._data)

  static { 
  // DO-NOT-DELETE splicer.begin(functions.QuadFunction._load)
  // DO-NOT-DELETE splicer.end(functions.QuadFunction._load)
  }

  /**
   * User defined constructor
   */
  public QuadFunction_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(functions.QuadFunction.QuadFunction)
    // DO-NOT-DELETE splicer.end(functions.QuadFunction.QuadFunction)
  }

  /**
   * Back door constructor
   */
  public QuadFunction_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(functions.QuadFunction._wrap)
    // DO-NOT-DELETE splicer.end(functions.QuadFunction._wrap)
  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(functions.QuadFunction._dtor)
    // Insert-Code-Here {functions.QuadFunction._dtor} (destructor)
    // DO-NOT-DELETE splicer.end(functions.QuadFunction._dtor)
  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(functions.QuadFunction.finalize)
    // DO-NOT-DELETE splicer.end(functions.QuadFunction.finalize)
  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  boccaSetServices[]
   */
  public void boccaSetServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
// DO-NOT-DELETE splicer.begin(functions.QuadFunction.boccaSetServices)
// DO-NOT-EDIT-BOCCA
// Bocca generated code. bocca.protected.begin(functions.QuadFunction.boccaSetServices)
   gov.cca.TypeMap typeMap;
   gov.cca.Port    port;
   this.d_services = services;
   typeMap = this.d_services.createTypeMap();
   port = (gov.cca.Port)(this);
  // Provide a function.FunctionPort port with port name function 
   try{
      this.d_services.addProvidesPort(port, // the implementing object
                                      "function", // the name the user sees
                                      "function.FunctionPort", // the sidl name of the port type
                                      typeMap); // extra properties
   } catch ( gov.cca.CCAException.Wrapper ex )  {
      String msg = "Error calling addProvidesPort(port,\"function\", \"function.FunctionPort\", typeMap) ";
      ex.add(msg);
      throw ex;
   }    
   gov.cca.ComponentRelease cr = (gov.cca.ComponentRelease)this; // CAST
   this.d_services.registerForRelease(cr);
   return;
// Bocca generated code. bocca.protected.end(functions.QuadFunction.boccaSetServices)
// DO-NOT-DELETE splicer.end(functions.QuadFunction.boccaSetServices)
  }

  /**
   * Method:  boccaReleaseServices[]
   */
  public void boccaReleaseServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
  // DO-NOT-DELETE splicer.begin(functions.QuadFunction.boccaReleaseServices)
  // Bocca generated code. bocca.protected.begin(functions.QuadFunction.boccaReleaseServices)
   this.d_services=null;
  // Un-provide function.FunctionPort port with port name function 
  try{
    services.removeProvidesPort("function");
  } catch ( gov.cca.CCAException.Wrapper ex )  {
    if (bocca_print_errs) {
      System.err.print("functions.QuadFunction: Error calling removeProvidesPort(\"function\"): " +ex.getNote());
    }
  }
   return;
  // Bocca generated code. bocca.protected.end(functions.QuadFunction.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(functions.QuadFunction.boccaReleaseServices)
  }

  /**
   *  This function should never be called, but helps babel generate better code. 
   */
  public void boccaForceUsePortInclude_Impl () 
    throws sidl.RuntimeException.Wrapper
  {
  // DO-NOT-DELETE splicer.begin(functions.QuadFunction.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(functions.QuadFunction.boccaForceUsePortInclude)
  // Bocca generated code. bocca.protected.end(functions.QuadFunction.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(functions.QuadFunction.boccaForceUsePortInclude)
  }

  /**
   *  Starts up a component presence in the calling framework.
   * @param services the component instance's handle on the framework world.
   * Contracts concerning Svc and setServices:
   * 
   * The component interaction with the CCA framework
   * and Ports begins on the call to setServices by the framework.
   * 
   * This function is called exactly once for each instance created
   * by the framework.
   * 
   * The argument Svc will never be nil/null.
   * 
   * Those uses ports which are automatically connected by the framework
   * (so-called service-ports) may be obtained via getPort during
   * setServices.
   */
  public void setServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
  // DO-NOT-DELETE splicer.begin(functions.QuadFunction.setServices)
  // Insert-Code-Here {functions.QuadFunction.setServices} (setServices method prolog)
  // bocca-default-code. User may edit or delete.begin(functions.QuadFunction.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(functions.QuadFunction.setServices)
  // Insert-Code-Here {functions.QuadFunction.setServices} (setServices method epilog)
  // DO-NOT-DELETE splicer.end(functions.QuadFunction.setServices)
  }

  /**
   * Shuts down a component presence in the calling framework.
   * @param services the component instance's handle on the framework world.
   * Contracts concerning Svc and setServices:
   * 
   * This function is called exactly once for each callback registered
   * through Services.
   * 
   * The argument Svc will never be nil/null.
   * The argument Svc will always be the same as that received in
   * setServices.
   * 
   * During this call the component should release any interfaces
   * acquired by getPort().
   * 
   * During this call the component should reset to nil any stored
   * reference to Svc.
   * 
   * After this call, the component instance will be removed from the
   * framework. If the component instance was created by the
   * framework, it will be destroyed, not recycled, The behavior of
   * any port references obtained from this component instance and
   * stored elsewhere becomes undefined.
   * 
   * Notes for the component implementor:
   * 1) The component writer may perform blocking activities
   * within releaseServices, such as waiting for remote computations
   * to shutdown.
   * 2) It is good practice during releaseServices for the component
   * writer to remove or unregister all the ports it defined.
   */
  public void releaseServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
  // DO-NOT-DELETE splicer.begin(functions.QuadFunction.releaseServices)
  // Insert-Code-Here {functions.QuadFunction.releaseServices} (releaseServices method prolog)
  // bocca-default-code. User may edit or delete.end(functions.QuadFunction.releaseServices)
     boccaReleaseServices(services); 
  // bocca-default-code. User may edit or delete.end(functions.QuadFunction.releaseServices)
  // Insert-Code-Here {functions.QuadFunction.releaseServices} (releaseServices method epilog)
  // DO-NOT-DELETE splicer.end(functions.QuadFunction.releaseServices)
  }

  /**
   * Method:  init[]
   */
  public void init_Impl (
    /*in*/ sidl.Double.Array1 params ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(functions.QuadFunction.init)
 
 
 
    // DO-DELETE-WHEN-IMPLEMENTING exception.begin()
    /* 
     * This method has not been implemented.
     */
    sidl.NotImplementedException noImpl = new sidl.NotImplementedException();
    noImpl.setNote("This method has not been implemented.");
    sidl.RuntimeException.Wrapper rex = (sidl.RuntimeException.Wrapper) sidl.RuntimeException.Wrapper._cast(noImpl);
    throw rex;
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
 
    // DO-NOT-DELETE splicer.end(functions.QuadFunction.init)
  }

  /**
   * Method:  evaluate[]
   */
  public double evaluate_Impl (
    /*in*/ double x ) 
    throws sidl.RuntimeException.Wrapper
  {
  // DO-NOT-DELETE splicer.begin(functions.QuadFunction.evaluate)
  
	return x*x*x*x;
 
    // DO-NOT-DELETE splicer.end(functions.QuadFunction.evaluate)
  }


  // DO-NOT-DELETE splicer.begin(functions.QuadFunction._misc)
    
  // DO-NOT-DELETE splicer.end(functions.QuadFunction._misc)

} // end class QuadFunction

