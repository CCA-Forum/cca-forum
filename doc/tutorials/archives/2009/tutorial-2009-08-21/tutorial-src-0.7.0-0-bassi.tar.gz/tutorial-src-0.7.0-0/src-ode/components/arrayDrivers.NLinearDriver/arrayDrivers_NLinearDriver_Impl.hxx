// 
// File:          arrayDrivers_NLinearDriver_Impl.hxx
// Symbol:        arrayDrivers.NLinearDriver-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for arrayDrivers.NLinearDriver
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_arrayDrivers_NLinearDriver_Impl_hxx
#define included_arrayDrivers_NLinearDriver_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_arrayDrivers_NLinearDriver_IOR_h
#include "arrayDrivers_NLinearDriver_IOR.h"
#endif
#ifndef included_arrayDrivers_NLinearDriver_hxx
#include "arrayDrivers_NLinearDriver.hxx"
#endif
#ifndef included_arrayop_NonLinearOp_hxx
#include "arrayop_NonLinearOp.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Component_hxx
#include "gov_cca_Component.hxx"
#endif
#ifndef included_gov_cca_ComponentRelease_hxx
#include "gov_cca_ComponentRelease.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_GoPort_hxx
#include "gov_cca_ports_GoPort.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif


// DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver._includes)
// Insert-Code-Here {arrayDrivers.NLinearDriver._includes} (includes or arbitrary code)
// DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver._includes)

namespace arrayDrivers { 

  /**
   * Symbol "arrayDrivers.NLinearDriver" (version 0.0)
   */
  class NLinearDriver_impl : public virtual ::arrayDrivers::NLinearDriver 
  // DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver._inherits)
  // Insert-Code-Here {arrayDrivers.NLinearDriver._inherits} (optional inheritance here)
  // DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

  // DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver._implementation)
  // Insert-UserCode-Here(arrayDrivers.NLinearDriver._implementation)
  // Bocca generated code. bocca.protected.begin(arrayDrivers.NLinearDriver._implementation)
  
   gov::cca::Services    d_services; // our cca handle.
 
  // Bocca generated code. bocca.protected.end(arrayDrivers.NLinearDriver._implementation)
  // DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver._implementation)

  public:
    // default constructor, used for data wrapping(required)
    NLinearDriver_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    NLinearDriver_impl( struct arrayDrivers_NLinearDriver__object * s ) : 
      StubBase(s,true), _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~NLinearDriver_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    void
    boccaSetServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;

    /**
     * user defined non-static method.
     */
    void
    boccaReleaseServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;


    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude_impl (
      /* in */::arrayop::NonLinearOp dummy0
    )
    ;


    /**
     *  Starts up a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning Svc and setServices:
     * 
     * The component interaction with the CCA framework
     * and Ports begins on the call to setServices by the framework.
     * 
     * This function is called exactly once for each instance created
     * by the framework.
     * 
     * The argument Svc will never be nil/null.
     * 
     * Those uses ports which are automatically connected by the framework
     * (so-called service-ports) may be obtained via getPort during
     * setServices.
     */
    void
    setServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;


    /**
     * Shuts down a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning Svc and setServices:
     * 
     * This function is called exactly once for each callback registered
     * through Services.
     * 
     * The argument Svc will never be nil/null.
     * The argument Svc will always be the same as that received in
     * setServices.
     * 
     * During this call the component should release any interfaces
     * acquired by getPort().
     * 
     * During this call the component should reset to nil any stored
     * reference to Svc.
     * 
     * After this call, the component instance will be removed from the
     * framework. If the component instance was created by the
     * framework, it will be destroyed, not recycled, The behavior of
     * any port references obtained from this component instance and
     * stored elsewhere becomes undefined.
     * 
     * Notes for the component implementor:
     * 1) The component writer may perform blocking activities
     * within releaseServices, such as waiting for remote computations
     * to shutdown.
     * 2) It is good practice during releaseServices for the component
     * writer to remove or unregister all the ports it defined.
     */
    void
    releaseServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;


    /**
     *  
     * Execute some encapsulated functionality on the component. 
     * Return 0 if ok, -1 if internal error but component may be 
     * used further, and -2 if error so severe that component cannot
     * be further used safely.
     */
    int32_t
    go_impl() ;
  };  // end class NLinearDriver_impl

} // end namespace arrayDrivers

// DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver._misc)
// Insert-Code-Here {arrayDrivers.NLinearDriver._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver._misc)

#endif
