// 
// File:          scijump_EventListener_Impl.cxx
// Symbol:        scijump.EventListener-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for scijump.EventListener
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "scijump_EventListener_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_gob.ccb_Event_hxx
#include "gob.ccb_Event.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(scijump.EventListener._includes)

  // Insert-UserCode-Here {scijump.EventListener._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(scijump.EventListener._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(scijump.EventListener._includes)

  // Insert-UserCode-Here {scijump.EventListener._includes:epilog} (additional includes or code)

#include <iostream>
// DO-NOT-DELETE splicer.end(scijump.EventListener._includes)

// special constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
scijump::EventListener_impl::EventListener_impl() : StubBase(reinterpret_cast< 
  void*>(::scijump::EventListener::_wrapObj(reinterpret_cast< void*>(this))),
  false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(scijump.EventListener._ctor2)
  // DO-NOT-DELETE splicer.end(scijump.EventListener._ctor2)
}

// user defined constructor
void scijump::EventListener_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(scijump.EventListener._ctor)
    
  // Insert-UserCode-Here {scijump.EventListener._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(scijump.EventListener._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR scijump.EventListener: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(scijump.EventListener._ctor)

  // Insert-UserCode-Here {scijump.EventListener._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(scijump.EventListener._ctor)
}

// user defined destructor
void scijump::EventListener_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(scijump.EventListener._dtor)
  // Insert-UserCode-Here {scijump.EventListener._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(scijump.EventListener._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR scijump.EventListener: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(scijump.EventListener._dtor) 

  // insert code here (destructor)
  // DO-NOT-DELETE splicer.end(scijump.EventListener._dtor)
}

// static class initializer
void scijump::EventListener_impl::_load() {
  // DO-NOT-DELETE splicer.begin(scijump.EventListener._load)
  // DO-NOT-DELETE splicer.end(scijump.EventListener._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
scijump::EventListener_impl::boccaForceUsePortInclude_impl () 

{
  // DO-NOT-DELETE splicer.begin(scijump.EventListener.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(scijump.EventListener.boccaForceUsePortInclude)

  // Bocca generated code. bocca.protected.end(scijump.EventListener.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(scijump.EventListener.boccaForceUsePortInclude)
}

/**
 *  This is where event processing by a listener takes place. This
 * is a call-back method that a topic subscriber implements and 
 * gets called for each new event.
 * @topicName - The topic for which the Event was created and sent.
 * @theEvent - The payload.
 */
void
scijump::EventListener_impl::processEvent_impl (
  /* in */const ::std::string& topicName,
  /* in */::gob::ccb::Event& theEvent ) 
{
  // DO-NOT-DELETE splicer.begin(scijump.EventListener.processEvent)
  std::cerr << "TestEventListener -- I got an event on topic " << topicName << "\n";
  gov::cca::TypeMap map = theEvent.getBody();
  std::cout << "\tEvent Body: " << map.getString("payload","default") << std::endl;
  // DO-NOT-DELETE splicer.end(scijump.EventListener.processEvent)
}


// DO-NOT-DELETE splicer.begin(scijump.EventListener._misc)
// DO-NOT-DELETE splicer.end(scijump.EventListener._misc)

