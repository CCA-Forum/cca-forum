// 
// File:          scijump_Subscription_Impl.hxx
// Symbol:        scijump.Subscription-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for scijump.Subscription
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_scijump_Subscription_Impl_hxx
#define included_scijump_Subscription_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_scijump_Subscription_IOR_h
#include "scijump_Subscription_IOR.h"
#endif
#ifndef included_gov_cca_TypeMap_hxx
#include "gov_cca_TypeMap.hxx"
#endif
#ifndef included_scijump_Subscription_hxx
#include "scijump_Subscription.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_gob.ccb_Event_hxx
#include "gob.ccb_Event.hxx"
#endif
#ifndef included_gob.ccb_EventListener_hxx
#include "gob.ccb_EventListener.hxx"
#endif
#ifndef included_gob.ccb_EventServiceException_hxx
#include "gob.ccb_EventServiceException.hxx"
#endif
#ifndef included_gob.ccb_Subscription_hxx
#include "gob.ccb_Subscription.hxx"
#endif


// DO-NOT-DELETE splicer.begin(scijump.Subscription._hincludes)
#include <map>
// DO-NOT-DELETE splicer.end(scijump.Subscription._hincludes)

namespace scijump { 

  /**
   * Symbol "scijump.Subscription" (version 0.0)
   */
  class Subscription_impl : public virtual ::scijump::Subscription 
  // DO-NOT-DELETE splicer.begin(scijump.Subscription._inherits)
  // DO-NOT-DELETE splicer.end(scijump.Subscription._inherits)

  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(scijump.Subscription._implementation)
    std::string subscriptionName;
    ::gov::cca::TypeMap framework;

    typedef std::map<std::string, ::gob::ccb::EventListener> EventListenerMap;
    EventListenerMap eventListenerMap;
    // DO-NOT-DELETE splicer.end(scijump.Subscription._implementation)

  public:
    // default constructor, used for data wrapping(required)
    Subscription_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
      Subscription_impl( struct scijump_Subscription__object * ior ) : StubBase(
        ior,true), 
    ::gob::ccb::Subscription((ior==NULL) ? NULL : &((
      *ior).d_gob.ccb_subscription)) , _wrapped(false) {_ctor();}


    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~Subscription_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    void
    initialize_impl (
      /* in */const ::std::string& subscriptionName,
      /* in */::gov::cca::TypeMap& tm
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    processEvents_impl (
      /* in array<gob.ccb.Event> */::sidl::array< ::gob::ccb::Event>& 
        eventList
    )
    ;


    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude_impl (
      /* in */::gob::ccb::Event& dummy0
    )
    ;


    /**
     * Adds a listener to the collection of listeners for this Subscription.
     * 
     * @listenerKey - It is used as an index to a unique mapping
     * and the parameter \em theListener is a
     * reference to the /em Listener object.
     * @theListener - A pointer to the object that will listen for events.
     */
    void
    registerEventListener_impl (
      /* in */const ::std::string& listenerKey,
      /* in */::gob::ccb::EventListener& theListener
    )
    // throws:
    //    ::sidl::RuntimeException
    //    ::gob::ccb::EventServiceException
    ;


    /**
     * Removes a listener from the collection of listeners for this Topic.
     * @listenerKey - It is used as an index to remove this listener.
     */
    void
    unregisterEventListener_impl (
      /* in */const ::std::string& listenerKey
    )
    ;


    /**
     *  Returns the name for this Subscription object 
     */
    ::std::string
    getSubscriptionName_impl() ;
  };  // end class Subscription_impl

} // end namespace scijump

// DO-NOT-DELETE splicer.begin(scijump.Subscription._hmisc)
// DO-NOT-DELETE splicer.end(scijump.Subscription._hmisc)

#endif
