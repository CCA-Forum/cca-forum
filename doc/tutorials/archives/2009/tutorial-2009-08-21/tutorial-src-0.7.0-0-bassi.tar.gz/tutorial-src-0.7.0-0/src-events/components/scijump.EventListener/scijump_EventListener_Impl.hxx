// 
// File:          scijump_EventListener_Impl.hxx
// Symbol:        scijump.EventListener-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for scijump.EventListener
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_scijump_EventListener_Impl_hxx
#define included_scijump_EventListener_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_scijump_EventListener_IOR_h
#include "scijump_EventListener_IOR.h"
#endif
#ifndef included_scijump_EventListener_hxx
#include "scijump_EventListener.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_gob.ccb_Event_hxx
#include "gob.ccb_Event.hxx"
#endif
#ifndef included_gob.ccb_EventListener_hxx
#include "gob.ccb_EventListener.hxx"
#endif


// DO-NOT-DELETE splicer.begin(scijump.EventListener._hincludes)
// DO-NOT-DELETE splicer.end(scijump.EventListener._hincludes)

namespace scijump { 

  /**
   * Symbol "scijump.EventListener" (version 0.0)
   */
  class EventListener_impl : public virtual ::scijump::EventListener 
  // DO-NOT-DELETE splicer.begin(scijump.EventListener._inherits)
  // DO-NOT-DELETE splicer.end(scijump.EventListener._inherits)

  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(scijump.EventListener._implementation)

  // Insert-UserCode-Here(scijump.EventListener._implementation)

    // DO-NOT-DELETE splicer.end(scijump.EventListener._implementation)

  public:
    // default constructor, used for data wrapping(required)
    EventListener_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
      EventListener_impl( struct scijump_EventListener__object * ior ) : 
        StubBase(ior,true), 
    ::gob::ccb::EventListener((ior==NULL) ? NULL : &((
      *ior).d_gob.ccb_eventlistener)) , _wrapped(false) {_ctor();}


    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~EventListener_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:


    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude_impl() ;

    /**
     *  This is where event processing by a listener takes place. This
     * is a call-back method that a topic subscriber implements and 
     * gets called for each new event.
     * @topicName - The topic for which the Event was created and sent.
     * @theEvent - The payload.
     */
    void
    processEvent_impl (
      /* in */const ::std::string& topicName,
      /* in */::gob::ccb::Event& theEvent
    )
    ;

  };  // end class EventListener_impl

} // end namespace scijump

// DO-NOT-DELETE splicer.begin(scijump.EventListener._hmisc)
// DO-NOT-DELETE splicer.end(scijump.EventListener._hmisc)

#endif
