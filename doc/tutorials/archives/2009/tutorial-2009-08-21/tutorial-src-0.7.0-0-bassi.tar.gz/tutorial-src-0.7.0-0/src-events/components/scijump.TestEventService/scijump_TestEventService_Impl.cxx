// 
// File:          scijump_TestEventService_Impl.cxx
// Symbol:        scijump.TestEventService-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for scijump.TestEventService
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "scijump_TestEventService_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_scijump_EventListener_hxx
#include "scijump_EventListener.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_gob.ccb_ports_PublisherEventService_hxx
#include "gob.ccb_ports_PublisherEventService.hxx"
#endif
#ifndef included_gob.ccb_ports_SubscriberEventService_hxx
#include "gob.ccb_ports_SubscriberEventService.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(scijump.TestEventService._includes)

#include <iostream>

  // Bocca generated code. bocca.protected.begin(scijump.TestEventService._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(scijump.TestEventService._includes)

  // Insert-UserCode-Here {scijump.TestEventService._includes:epilog} (additional includes or code)

// DO-NOT-DELETE splicer.end(scijump.TestEventService._includes)

// special constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
scijump::TestEventService_impl::TestEventService_impl() : StubBase(
  reinterpret_cast< void*>(::scijump::TestEventService::_wrapObj(
  reinterpret_cast< void*>(this))),false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(scijump.TestEventService._ctor2)
  // Insert-Code-Here {scijump.TestEventService._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(scijump.TestEventService._ctor2)
}

// user defined constructor
void scijump::TestEventService_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(scijump.TestEventService._ctor)
    
  // Insert-UserCode-Here {scijump.TestEventService._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(scijump.TestEventService._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR scijump.TestEventService: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(scijump.TestEventService._ctor)

  // Insert-UserCode-Here {scijump.TestEventService._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(scijump.TestEventService._ctor)
}

// user defined destructor
void scijump::TestEventService_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(scijump.TestEventService._dtor)
  // Insert-UserCode-Here {scijump.TestEventService._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(scijump.TestEventService._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR scijump.TestEventService: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(scijump.TestEventService._dtor) 

  // DO-NOT-DELETE splicer.end(scijump.TestEventService._dtor)
}

// static class initializer
void scijump::TestEventService_impl::_load() {
  // DO-NOT-DELETE splicer.begin(scijump.TestEventService._load)
  // Insert-Code-Here {scijump.TestEventService._load} (class initialization)
  // DO-NOT-DELETE splicer.end(scijump.TestEventService._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
scijump::TestEventService_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(scijump.TestEventService.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(scijump.TestEventService.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "scijump.TestEventService: Error casting self to gov::cca::Port");
  } 


  // Provide a gov.cca.ports.GoPort port with port name go 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "go", // port instance name
                   "gov.cca.ports.GoPort",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "scijump.TestEventService: Error calling addProvidesPort(port,"
        "\"go\", \"gov.cca.ports.GoPort\", typeMap) ", -2);
    throw;
  }    

  // Use a gob.ccb.ports.PublisherEventService port with port name publish 
  try{
    this->d_services.registerUsesPort(
                   "publish", // port instance name
                   "gob.ccb.ports.PublisherEventService",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "scijump.TestEventService: Error calling registerUsesPort(\"publish\", "
       "\"gob.ccb.ports.PublisherEventService\", typeMap) ", -2);
    throw;
  }

  // Use a gob.ccb.ports.SubscriberEventService port with port name subscribe 
  try{
    this->d_services.registerUsesPort(
                   "subscribe", // port instance name
                   "gob.ccb.ports.SubscriberEventService",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "scijump.TestEventService: Error calling registerUsesPort(\"subscribe\", "
       "\"gob.ccb.ports.SubscriberEventService\", typeMap) ", -2);
    throw;
  }


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(scijump.TestEventService.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(scijump.TestEventService.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
scijump::TestEventService_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(scijump.TestEventService.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(scijump.TestEventService.boccaReleaseServices)
  this->d_services=0;


  // Un-provide gov.cca.ports.GoPort port with port name go 
  try{
    services.removeProvidesPort("go");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "scijump.TestEventService: Error calling removeProvidesPort("
              << "\"go\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release gob.ccb.ports.PublisherEventService port with port name publish 
  try{
    services.unregisterUsesPort("publish");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "scijump.TestEventService: Error calling unregisterUsesPort("
              << "\"publish\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release gob.ccb.ports.SubscriberEventService port with port name subscribe 
  try{
    services.unregisterUsesPort("subscribe");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "scijump.TestEventService: Error calling unregisterUsesPort("
              << "\"subscribe\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(scijump.TestEventService.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(scijump.TestEventService.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
scijump::TestEventService_impl::boccaForceUsePortInclude_impl (
  /* in */::gob::ccb::ports::PublisherEventService& dummy0,
  /* in */::gob::ccb::ports::SubscriberEventService& dummy1,
  /* in */::scijump::EventListener& dummy2 ) 
{
  // DO-NOT-DELETE splicer.begin(scijump.TestEventService.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(scijump.TestEventService.boccaForceUsePortInclude)
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;

  // Bocca generated code. bocca.protected.end(scijump.TestEventService.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(scijump.TestEventService.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
scijump::TestEventService_impl::setServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(scijump.TestEventService.setServices)

  // Insert-UserCode-Here{scijump.TestEventService.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(scijump.TestEventService.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(scijump.TestEventService.setServices)
  
  // Insert-UserCode-Here{scijump.TestEventService.setServices:epilog}

  // DO-NOT-DELETE splicer.end(scijump.TestEventService.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
scijump::TestEventService_impl::releaseServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(scijump.TestEventService.releaseServices)

  // Insert-UserCode-Here {scijump.TestEventService.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(scijump.TestEventService.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(scijump.TestEventService.releaseServices)
    
  // DO-NOT-DELETE splicer.end(scijump.TestEventService.releaseServices)
}

/**
 *  
 * Execute some encapsulated functionality on the component. 
 * Return 0 if ok, -1 if internal error but component may be 
 * used further, and -2 if error so severe that component cannot
 * be further used safely.
 */
int32_t
scijump::TestEventService_impl::go_impl () 

{
  // DO-NOT-DELETE splicer.begin(scijump.TestEventService.go)
// User editable portion is in the middle at the next Insert-UserCode-Here line.


// Bocca generated code. bocca.protected.begin(scijump.TestEventService.go:boccaGoProlog)
  int bocca_status = 0;
  // The user's code should set bocca_status 0 if computation proceeded ok.
  // The user's code should set bocca_status -1 if computation failed but might
  // succeed on another call to go(), e.g. when a required port is not yet 
  // connected.
  // The user's code should set bocca_status -2 if the computation failed and 
  // can never succeed in a future call.
  // The user's code should NOT use return in this function.
  // Exceptions that are not caught in user code will be converted to 
  // status -2.

  gov::cca::Port port;

  // nil if not fetched and cast successfully:
  gob::ccb::ports::PublisherEventService publish; 
  // True when releasePort is needed (even if cast fails):
  bool publish_fetched = false; 
  // nil if not fetched and cast successfully:
  gob::ccb::ports::SubscriberEventService subscribe; 
  // True when releasePort is needed (even if cast fails):
  bool subscribe_fetched = false; 
  // Use a gob.ccb.ports.PublisherEventService port with port name publish 
  try{
    port = this->d_services.getPort("publish");
  } catch ( ::gov::cca::CCAException ex )  {
    // we will continue with port nil (never successfully assigned) and 
    // set a flag.

#ifdef _BOCCA_STDERR
    std::cerr << "scijump.TestEventService: Error calling getPort(\"publish\") "
              " at " << __FILE__ << ":" << __LINE__ -5 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }
  if ( port._not_nil() ) {
    // even if the next cast fails, must release.
    publish_fetched = true; 
    publish = ::babel_cast< gob::ccb::ports::PublisherEventService >(port);
    if (publish._is_nil()) {

#ifdef _BOCCA_STDERR
      std::cerr << "scijump.TestEventService: Error casting gov::cca::Port "
                << "publish to type "
                << "gob::ccb::ports::PublisherEventService" << std::endl;
#endif //_BOCCA_STDERR

      goto BOCCAEXIT; // we cannot correctly continue. clean up and leave.
    } 
  } 

  // Use a gob.ccb.ports.SubscriberEventService port with port name subscribe 
  try{
    port = this->d_services.getPort("subscribe");
  } catch ( ::gov::cca::CCAException ex )  {
    // we will continue with port nil (never successfully assigned) and 
    // set a flag.

#ifdef _BOCCA_STDERR
    std::cerr << "scijump.TestEventService: Error calling getPort(\"subscribe\") "
              " at " << __FILE__ << ":" << __LINE__ -5 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }
  if ( port._not_nil() ) {
    // even if the next cast fails, must release.
    subscribe_fetched = true; 
    subscribe = ::babel_cast< gob::ccb::ports::SubscriberEventService >(port);
    if (subscribe._is_nil()) {

#ifdef _BOCCA_STDERR
      std::cerr << "scijump.TestEventService: Error casting gov::cca::Port "
                << "subscribe to type "
                << "gob::ccb::ports::SubscriberEventService" << std::endl;
#endif //_BOCCA_STDERR

      goto BOCCAEXIT; // we cannot correctly continue. clean up and leave.
    } 
  } 


// Bocca generated code. bocca.protected.end(scijump.TestEventService.go:boccaGoProlog)



  // When this try/catch block is rewritten by the user, we will not change it.
  try {

    // All port instances should be rechecked for ._not_nil before calling in 
    // user code. Not all ports need be connected in arbitrary use.
    // The uses ports appear as local variables here named exactly as on the 
    // bocca commandline.

	if ( publish._is_nil() ) {
		bocca_status = -2;
		std::cerr << "scijump.TestEventService.go: framework didn't provide publish port" << std::endl;
	}
	if (subscribe._is_nil() ) {
		bocca_status = -2;
		std::cerr << "scijump.TestEventService.go: framework didn't provide subscribe port" << std::endl;
	}
	if (bocca_status == 0) {
		// don't do these if ports not there.
		gob::ccb::Topic sampleTopic;
		gob::ccb::Subscription sampleSub;
		scijump::EventListener stestListener;
		gob::ccb::EventListener testListener;

		sampleTopic = publish.getTopic("SampleTopic");
		std::cout << "Topic created\n";

		sampleSub = subscribe.getSubscription("SampleTopic");
		std::cout << "Subscription created\n";

		stestListener = scijump::EventListener::_create();
		testListener = stestListener;

		sampleSub.registerEventListener("myTestListener",testListener);
		std::cout << "Listener registered successfully\n";

		gov::cca::TypeMap map = d_services.createTypeMap();
		map.putString("payload","event1 payload");

		sampleTopic.sendEvent("SampleTopic", map);

		std::cout << "Event sent successfully\n" << std::endl;

		subscribe.processEvents();
	}

  } 
  // If unknown exceptions in the user code are tolerable and restart is ok, 
  // return -1 instead. -2 means the component is so confused that it and 
  // probably the application should be destroyed.
  // babel requires exact exception catching due to c++ binding of interfaces.
  catch (gov::cca::CCAException ex) {
    bocca_status = -2;
    std::string enote = ex.getNote();

#ifdef _BOCCA_STDERR
    std::cerr << "CCAException in user go code: " << enote << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;;
#endif

  }
  catch (sidl::RuntimeException ex) {
    bocca_status = -2;
    std::string enote = ex.getNote();

#ifdef _BOCCA_STDERR
    std::cerr << "RuntimeException in user go code: " << enote << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;;
#endif

  }
  catch (sidl::SIDLException ex) {
    bocca_status = -2;
    std::string enote = ex.getNote();

#ifdef _BOCCA_STDERR
    std::cerr << "SIDLException in user go code: " << enote << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;;
#endif

  }
  catch (sidl::BaseException ex) {
    bocca_status = -2;
    std::string enote = ex.getNote();

#ifdef _BOCCA_STDERR
    std::cerr << "BaseException in user go code: " << enote << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;;
#endif

  }
  catch (std::exception ex) {
    bocca_status = -2;

#ifdef _BOCCA_STDERR
    std::cerr << "C++ exception in user go code: " << ex.what() << std::endl;
    std::cerr << "Returning -2 from go()"  << std::endl;
#endif

  }
  catch (...) {
    bocca_status = -2;

#ifdef _BOCCA_STDERR
    std::cerr << "Odd exception in user go code " << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;
#endif

  }


  BOCCAEXIT:; // target point for error and regular cleanup. do not delete.
// Bocca generated code. bocca.protected.begin(scijump.TestEventService.go:boccaGoEpilog)

  // release publish 
  if (publish_fetched) {
    publish_fetched = false;
    try{
      this->d_services.releasePort("publish");
    } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
      std::cerr << "scijump.TestEventService: Error calling releasePort("
                << "\"publish\") at " 
                << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
                << std::endl;
#endif // _BOCCA_STDERR

    }
    // c++ port reference will be dropped when function exits, but we 
    // must tell framework.
  }

  // release subscribe 
  if (subscribe_fetched) {
    subscribe_fetched = false;
    try{
      this->d_services.releasePort("subscribe");
    } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
      std::cerr << "scijump.TestEventService: Error calling releasePort("
                << "\"subscribe\") at " 
                << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
                << std::endl;
#endif // _BOCCA_STDERR

    }
    // c++ port reference will be dropped when function exits, but we 
    // must tell framework.
  }


  return bocca_status;
// Bocca generated code. bocca.protected.end(scijump.TestEventService.go:boccaGoEpilog)

  // DO-NOT-DELETE splicer.end(scijump.TestEventService.go)
}


// DO-NOT-DELETE splicer.begin(scijump.TestEventService._misc)
// Insert-Code-Here {scijump.TestEventService._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(scijump.TestEventService._misc)

