// 
// File:          pde_ICbzchem_Impl.cxx
// Symbol:        pde.ICbzchem-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.ICbzchem
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_ICbzchem_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_pde_FieldVar_hxx
#include "pde_FieldVar.hxx"
#endif
#ifndef included_pde_Mesh_hxx
#include "pde_Mesh.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.ICbzchem._includes)

  // Insert-UserCode-Here {pde.ICbzchem._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(pde.ICbzchem._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.ICbzchem._includes)

  // Insert-UserCode-Here {pde.ICbzchem._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.ICbzchem._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::ICbzchem_impl::ICbzchem_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::ICbzchem::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(pde.ICbzchem._ctor2)
  // DO-NOT-DELETE splicer.end(pde.ICbzchem._ctor2)
}

// user defined constructor
void pde::ICbzchem_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.ICbzchem._ctor)
    
  // Insert-UserCode-Here {pde.ICbzchem._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(pde.ICbzchem._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.ICbzchem: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.ICbzchem._ctor)

  // Insert-UserCode-Here {pde.ICbzchem._ctor:epilog} (constructor method)

  // Magnitude of the background conditions for T, [HBrO2] and [Mox]; also perturbation in [HBrO2]
     var0Mag_ = var1Mag_ = var2Mag_ = 0.0 ;  // some constant values
     perturbMag_ = 0.1 ; // and a small perturbation.

  // Position of the perturbation spots
     spotOne_ = 0.35;
     spotTwo_ = 0.65 ;

  // Size of perturbation spots
     radiusSize_ = 0.03 ;

  // DO-NOT-DELETE splicer.end(pde.ICbzchem._ctor)
}

// user defined destructor
void pde::ICbzchem_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.ICbzchem._dtor)
  // Insert-UserCode-Here {pde.ICbzchem._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.ICbzchem._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.ICbzchem: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.ICbzchem._dtor) 

  // DO-NOT-DELETE splicer.end(pde.ICbzchem._dtor)
}

// static class initializer
void pde::ICbzchem_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.ICbzchem._load)
  // Insert-Code-Here {pde.ICbzchem._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.ICbzchem._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
pde::ICbzchem_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.ICbzchem.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.ICbzchem.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "pde.ICbzchem: Error casting self to gov::cca::Port");
  } 


  // Provide a pde.ICPort port with port name ic 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "ic", // port instance name
                   "pde.ICPort",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "pde.ICbzchem: Error calling addProvidesPort(port,"
        "\"ic\", \"pde.ICPort\", typeMap) ", -2);
    throw;
  }    


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(pde.ICbzchem.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(pde.ICbzchem.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
pde::ICbzchem_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.ICbzchem.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.ICbzchem.boccaReleaseServices)
  this->d_services=0;


  // Un-provide pde.ICPort port with port name ic 
  try{
    services.removeProvidesPort("ic");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.ICbzchem: Error calling removeProvidesPort("
              << "\"ic\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(pde.ICbzchem.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.ICbzchem.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::ICbzchem_impl::boccaForceUsePortInclude_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.ICbzchem.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.ICbzchem.boccaForceUsePortInclude)

  // Bocca generated code. bocca.protected.end(pde.ICbzchem.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.ICbzchem.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
pde::ICbzchem_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.ICbzchem.setServices)

  // Insert-UserCode-Here{pde.ICbzchem.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(pde.ICbzchem.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(pde.ICbzchem.setServices)
  
  // Insert-UserCode-Here{pde.ICbzchem.setServices:epilog}

  // DO-NOT-DELETE splicer.end(pde.ICbzchem.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
pde::ICbzchem_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.ICbzchem.releaseServices)

  // Insert-UserCode-Here {pde.ICbzchem.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(pde.ICbzchem.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(pde.ICbzchem.releaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.ICbzchem.releaseServices)
}

/**
 *  Apply an initialization to the array of VectorFieldVariables being sent in.
 * @param vfv : an array of FieldVar
 * @return 0 if OK, negative if error occurs.
 */
int32_t
pde::ICbzchem_impl::setInitialConditions_impl (
  /* inout array<pde.FieldVar> */::sidl::array< ::pde::FieldVar>& vfv,
  /* in */::pde::Mesh m ) 
{
  // DO-NOT-DELETE splicer.begin(pde.ICbzchem.setInitialConditions)
  // Insert-Code-Here {pde.ICbzchem.setInitialConditions} (setInitialConditions method)
    
       /**
       This Initial Condition is good only when we have 3 variables in a 2D domain.
       Check and return -1 if not true. Also, these variables have to be in the same
       vfv i.e. only 1 FieldVar is expected.
    */
    if (vfv.length(0) != 1) return (-1) ; // I need 1 fv in that array.
    
    ::pde::FieldVar fv = vfv[0] ;
    
    // Check that this is a 2D problem; else return -2;
    if (fv.getDimension() != 2) return (-2) ; // This is a 2D problem.

    // Check that we have 3 vars. if not, return -3
    if (fv.getNVars() != 3) return (-3);

    /**
       I will have 2 spots at (0.35, 0.35) and (0.65, 0.65) of the domain.
       The change in concentration will be in [HBrO2] i.e. var #1. var 0 and var2
       will be initialized to constants.
    */
    sidl::array<int> shape = m.getShape() ;
    double radius = radiusSize_ * sqrt( (float) shape[0] * shape[1] ) ;
    std::vector< double > center1, center2;
    center1.push_back( spotOne_*shape[0] ) ;  center1.push_back( spotOne_*shape[1] ) ; 
    center2.push_back( spotTwo_*shape[0] ) ;  center2.push_back( spotTwo_*shape[1] ) ; 

    /**
       Loop over all boxes. For each box, extract its data pointers, its lower and upper bound
       and step through all grid points and initialize var0 and var 2 to a constant and var 1 to
       the number given by the spots
    */
    int32_t time = 0;
    for(int32_t iregion = 0; iregion < fv.getRegionCount(); iregion++)
    {
	// get some info about this region.
	sidl::array<double> data = fv.getData(time, iregion) ;
	sidl::array<int32_t> lower = fv.getLowerCorner(iregion) ;
	sidl::array<int32_t> upper = fv.getUpperCorner(iregion) ;

	// Loop over all the points in this region.
	for (int32_t iy = lower[1] ; iy <= upper[1]; iy++)
	    for(int32_t ix = lower[0]; ix <= upper[0]; ix++)
	    {
		// var0 is a constant
		int32_t indexV0 = fv.coordToIndex(0, lower, upper, ix, iy, 0) ;
		data.set(indexV0,var0Mag_) ;

		// var 1 is affected by the constant mag and a perturbation, dependent on the 
		// distance from center 1 and 2.
		double d1 = sqrt((float) (ix-center1[0])*(ix-center1[0]) + (iy-center1[1])*(iy-center1[1]) ) ;
		double d2 = sqrt((float) (ix-center2[0])*(ix-center2[0]) + (iy-center2[1])*(iy-center2[1]) ) ;
		double perturb = perturbMag_ * ( exp( - (d1*d1)/(radius*radius) ) + 
		                                 exp( - (d2*d2)/(radius*radius) ) ) ;	
		int32_t indexV1 = fv.coordToIndex(1, lower, upper, ix, iy, 0) ;
		data.set(indexV1, (var1Mag_ + perturb)) ;

		// var 2 is again a constant
		int32_t indexV2 = fv.coordToIndex(2, lower, upper, ix, iy, 0) ;
		data.set(indexV2, var2Mag_) ;
	    } // End of loop over all points in 1 region.
    } // End of loop over regions
    
    return 0 ;
  // DO-NOT-DELETE splicer.end(pde.ICbzchem.setInitialConditions)
}


// DO-NOT-DELETE splicer.begin(pde.ICbzchem._misc)
// Insert-Code-Here {pde.ICbzchem._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(pde.ICbzchem._misc)

