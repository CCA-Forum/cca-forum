// 
// File:          pde_BCFactory_Impl.cxx
// Symbol:        pde.BCFactory-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.BCFactory
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_BCFactory_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_pde_BCconstant_hxx
#include "pde_BCconstant.hxx"
#endif
#ifndef included_pde_BoundaryCondition_hxx
#include "pde_BoundaryCondition.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_DLL_hxx
#include "sidl_DLL.hxx"
#endif
#ifndef included_sidl_Loader_hxx
#include "sidl_Loader.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.BCFactory._includes)

  // Insert-UserCode-Here {pde.BCFactory._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(pde.BCFactory._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.BCFactory._includes)

  // Insert-UserCode-Here {pde.BCFactory._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.BCFactory._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::BCFactory_impl::BCFactory_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::BCFactory::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(pde.BCFactory._ctor2)
  // Insert-Code-Here {pde.BCFactory._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.BCFactory._ctor2)
}

// user defined constructor
void pde::BCFactory_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.BCFactory._ctor)
    
  // Insert-UserCode-Here {pde.BCFactory._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(pde.BCFactory._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.BCFactory: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.BCFactory._ctor)

  // Insert-UserCode-Here {pde.BCFactory._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(pde.BCFactory._ctor)
}

// user defined destructor
void pde::BCFactory_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.BCFactory._dtor)
  // Insert-UserCode-Here {pde.BCFactory._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.BCFactory._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.BCFactory: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.BCFactory._dtor) 

  // DO-NOT-DELETE splicer.end(pde.BCFactory._dtor)
}

// static class initializer
void pde::BCFactory_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.BCFactory._load)
  // Insert-Code-Here {pde.BCFactory._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.BCFactory._load)
}

// user defined static methods:
/**
 * Method:  needs[]
 */
void
pde::BCFactory_impl::needs_impl (
  /* in */::sidl::DLL dummy0,
  /* in */::sidl::Loader dummy1 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.BCFactory.needs)
	(void) dummy0; (void)dummy1;
  // DO-NOT-DELETE splicer.end(pde.BCFactory.needs)
}


// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
pde::BCFactory_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.BCFactory.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.BCFactory.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "pde.BCFactory: Error casting self to gov::cca::Port");
  } 


  // Provide a pde.BCSource port with port name BCSource 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "BCSource", // port instance name
                   "pde.BCSource",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "pde.BCFactory: Error calling addProvidesPort(port,"
        "\"BCSource\", \"pde.BCSource\", typeMap) ", -2);
    throw;
  }    


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(pde.BCFactory.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(pde.BCFactory.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
pde::BCFactory_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.BCFactory.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.BCFactory.boccaReleaseServices)
  this->d_services=0;


  // Un-provide pde.BCSource port with port name BCSource 
  try{
    services.removeProvidesPort("BCSource");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.BCFactory: Error calling removeProvidesPort("
              << "\"BCSource\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(pde.BCFactory.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.BCFactory.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::BCFactory_impl::boccaForceUsePortInclude_impl (
  /* in */::pde::BCconstant dummy0 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.BCFactory.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.BCFactory.boccaForceUsePortInclude)
    (void)dummy0;

  // Bocca generated code. bocca.protected.end(pde.BCFactory.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.BCFactory.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
pde::BCFactory_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.BCFactory.setServices)

  // Insert-UserCode-Here{pde.BCFactory.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(pde.BCFactory.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(pde.BCFactory.setServices)
  
  // Insert-UserCode-Here{pde.BCFactory.setServices:epilog}

  // DO-NOT-DELETE splicer.end(pde.BCFactory.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
pde::BCFactory_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.BCFactory.releaseServices)

  // Insert-UserCode-Here {pde.BCFactory.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(pde.BCFactory.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(pde.BCFactory.releaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.BCFactory.releaseServices)
}

/**
 * Method:  createBoundaryCondition[]
 */
::pde::BoundaryCondition
pde::BCFactory_impl::createBoundaryCondition_impl (
  /* in */const ::std::string& bcSidlName ) 
{
  // DO-NOT-DELETE splicer.begin(pde.BCFactory.createBoundaryCondition)
	pde::BoundaryCondition result;
	if (bcSidlName == "pde.BCconstant") {
		// the statically linked style
		pde::BCconstant bc = pde::BCconstant::_create();
		result = bc; // implicit cast in c++ binding
	} else {
		// using the sidl loader at runtime.
		sidl::BaseClass base;
		sidl::DLL dll = sidl::Loader::findLibrary(bcSidlName, "ior/impl", sidl::Scope_SCLSCOPE, sidl::Resolve_SCLRESOLVE);
		if (dll._is_nil()) {
			std::cout << ":-( Could not load boundary condition using "
				"sidl::Loader::findLibrary for library: " << bcSidlName << std::endl;
			// dump_babel_dl_info(); a ccaffeine call
		}
		base = dll.createClass(bcSidlName);
		if (base._is_nil()) {
			std::cout <<":-( For some reason, even though we loaded the class"
				"successfully, it could not be instantiated.\n"
				"Is your component compiled with compatible "
				"compilers? Is it installed in the right path?" << std::endl;
		} else {
			result = ::babel_cast< pde::BoundaryCondition> (base); 
		}
	}
	return result;
  // DO-NOT-DELETE splicer.end(pde.BCFactory.createBoundaryCondition)
}


// DO-NOT-DELETE splicer.begin(pde.BCFactory._misc)
// Insert-Code-Here {pde.BCFactory._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(pde.BCFactory._misc)

