// 
// File:          pde_PatchCxx_Impl.hxx
// Symbol:        pde.PatchCxx-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.PatchCxx
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_pde_PatchCxx_Impl_hxx
#define included_pde_PatchCxx_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_pde_PatchCxx_IOR_h
#include "pde_PatchCxx_IOR.h"
#endif
#ifndef included_bsl_arr_hxx
#include "bsl_arr.hxx"
#endif
#ifndef included_pde_BoundPos_hxx
#include "pde_BoundPos.hxx"
#endif
#ifndef included_pde_Patch_hxx
#include "pde_Patch.hxx"
#endif
#ifndef included_pde_PatchCxx_hxx
#include "pde_PatchCxx.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(pde.PatchCxx._hincludes)
#include <vector>
#include <iostream>
#include <sstream>
#include <string>

// DO-NOT-DELETE splicer.end(pde.PatchCxx._hincludes)
// DO-NOT-DELETE splicer.begin(pde.PatchCxx._includes)
#include <vector>
#include <iostream>
#include <sstream>
#include <string>

// DO-NOT-DELETE splicer.end(pde.PatchCxx._includes)

namespace pde { 

  /**
   * Symbol "pde.PatchCxx" (version 0.0)
   */
  class PatchCxx_impl : public virtual ::pde::PatchCxx 
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx._inherits)
  // Insert-Code-Here {pde.PatchCxx._inherits} (optional inheritance here)
  // DO-NOT-DELETE splicer.end(pde.PatchCxx._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(pde.PatchCxx._implementation)
    /// list of neighbor lists.
	
	static int64_t nextid; /// generator value
	std::vector< int64_t > nids[6];
	#define NLO0 0	///< list of neighbors below in the x (0,1) direction
	#define NHI0 1
	#define NLO1 2	///< list of neighbors below in the y (2,3) direction
	#define NHI1 3
	#define NLO2 4
	#define NHI2 5

	int64_t b_id; // global patch id, not local index id.
	int b_procid; // = -1;
	int32_t b_dim; // = -1;
	int32_t *b_firstIndices; // = 0;
	int32_t *b_lastIndices; // = 0;
	int32_t *b_lengths; // = 0;
	int32_t *b_firstAllocated; // = 0;
	int32_t *b_lastAllocated; // = 0;
	int32_t *b_lengthsAllocated; // = 0;
	bool b_allocate(); //return false if a problem.
	bool allocationSet; // false
	std::vector< pde::BoundPos > boundaries;
    // DO-NOT-DELETE splicer.end(pde.PatchCxx._implementation)

  public:
    // default constructor, used for data wrapping(required)
    PatchCxx_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    PatchCxx_impl( struct pde_PatchCxx__object * s ) : StubBase(s,true), 
      _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~PatchCxx_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:
    /**
     * user defined static method
     */
    static int64_t
    nextId_impl() ;

    /**
     * user defined non-static method.
     */
    void
    init1d_impl (
      /* in */int64_t id,
      /* in */int32_t procid,
      /* in */int32_t low0,
      /* in */int32_t high0
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    init2d_impl (
      /* in */int64_t id,
      /* in */int32_t procid,
      /* in */int32_t low0,
      /* in */int32_t high0,
      /* in */int32_t low1,
      /* in */int32_t high1
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    init3d_impl (
      /* in */int64_t id,
      /* in */int32_t procid,
      /* in */int32_t low0,
      /* in */int32_t high0,
      /* in */int32_t low1,
      /* in */int32_t high1,
      /* in */int32_t low2,
      /* in */int32_t high2
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    addBoundary_impl (
      /* in */::pde::BoundPos direction
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    addNeighbor_impl (
      /* in */::pde::BoundPos direction,
      /* in */int64_t nid
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    setProcId_impl (
      /* in */int32_t id
    )
    ;

    /**
     * user defined non-static method.
     */
    int32_t
    size_impl() ;
    /**
     * user defined non-static method.
     */
    ::std::string
    toString_impl() ;

    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude_impl (
      /* in */::bsl::arr dummy0
    )
    ;


    /**
     *  Get the number of dimensions on this box (1..3).
     * @return the size of arrays that will be returned by
     * get[[[First,Last]Indices],[[Before,After]GhostSizes]]
     */
    int32_t
    getDimension_impl() ;

    /**
     *  Get the lowest index of valid (patch-owned) data
     * (in global index space) for each dimension. 
     * @return the first indices of this block.
     */
    ::sidl::array<int32_t>
    getFirstIndices_impl() ;

    /**
     *  Get the highest index of valid (patch-owned) data
     * (in global index space) for each dimension. 
     * @return the last indices of this block. 
     */
    ::sidl::array<int32_t>
    getLastIndices_impl() ;

    /**
     *  Get the length (number of cells) in each dimension.
     * @return the size of this cell block. 
     */
    ::sidl::array<int32_t>
    getLengths_impl() ;

    /**
     *  test coordinate p for being in the space defined
     * by the box.
     * @param p an array of indices of the same or lower
     * dimensionality as the box.
     * @return true if p contained in box.
     */
    bool
    contains_impl (
      /* in array<int> */::sidl::array<int32_t> p
    )
    ;


    /**
     *  alternate way of getting firstIndices[0]. 
     */
    int32_t
    getXBegin_impl() ;

    /**
     *  alternate way of getting lastIndices[0]. 
     */
    int32_t
    getXEnd_impl() ;

    /**
     *  alternate way of getting firstIndices[1].
     */
    int32_t
    getYBegin_impl() ;

    /**
     *  alternate way of getting lastIndices[1] 
     */
    int32_t
    getYEnd_impl() ;

    /**
     *  alternate way of getting firstIndices[2] 
     */
    int32_t
    getZBegin_impl() ;

    /**
     *  alternate way of getting lastIndices[2]
     */
    int32_t
    getZEnd_impl() ;

    /**
     *  alternate way of getting lengths[0]. 
     */
    int32_t
    getXLen_impl() ;

    /**
     *  alternate way of getting lengths[1].
     */
    int32_t
    getYLen_impl() ;

    /**
     *  alternate way of getting lengths[2]
     */
    int32_t
    getZLen_impl() ;

    /**
     * Query which edges are coincident with the domain 
     * boundary.
     * 
     * @return an array with as many elements as there are boundary edges,
     * or a nil array if there are no boundaries on the patch.
     * The array will be indexed from 0.
     */
    ::sidl::array< ::pde::BoundPos>
    getBoundaryDirections_impl() ;

    /**
     * Get the corners of the boundary region in the given direction.
     * Throws an exception if the direction is not a boundary.
     * @param direction the side of the patch of interest.
     * @param lower the lower bound corner of the answer.
     * @param upper the upper bound corner of the answer.
     */
    void
    getBoundaryIntersection_impl (
      /* in */::pde::BoundPos direction,
      /* inout array<int> */::sidl::array<int32_t>& lower,
      /* inout array<int> */::sidl::array<int32_t>& upper
    )
    ;


    /**
     * Get the patch ids of neighbors in a direction; often there is just one,
     * but there may be more.
     * 
     * @param boundaryType element of BoundPos for the direction desired.
     * @return the ids in a particular direction.
     */
    ::sidl::array<int64_t>
    getNeighborIds_impl (
      /* in */::pde::BoundPos boundaryType
    )
    ;


    /**
     *  @return the global identifier of this patch with its domain. 
     */
    int64_t
    getGlobalId_impl() ;

    /**
     *  @return the process id, in mpi rank terms, of the process which owns this patch's data arrays. 
     */
    int32_t
    getProcId_impl() ;
  };  // end class PatchCxx_impl

} // end namespace pde

// DO-NOT-DELETE splicer.begin(pde.PatchCxx._misc)
// Insert-Code-Here {pde.PatchCxx._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(pde.PatchCxx._misc)

#endif
