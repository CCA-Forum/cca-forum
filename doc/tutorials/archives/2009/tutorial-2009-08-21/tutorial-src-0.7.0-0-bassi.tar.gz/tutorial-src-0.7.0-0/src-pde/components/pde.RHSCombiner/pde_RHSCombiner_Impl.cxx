// 
// File:          pde_RHSCombiner_Impl.cxx
// Symbol:        pde.RHSCombiner-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.RHSCombiner
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_RHSCombiner_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_bsl_arr_hxx
#include "bsl_arr.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_ParameterPortFactory_hxx
#include "gov_cca_ports_ParameterPortFactory.hxx"
#endif
#ifndef included_pde_MeshColl_hxx
#include "pde_MeshColl.hxx"
#endif
#ifndef included_pde_NamedPatchPort_hxx
#include "pde_NamedPatchPort.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.RHSCombiner._includes)

  // Insert-UserCode-Here {pde.RHSCombiner._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(pde.RHSCombiner._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.RHSCombiner._includes)

  // Insert-UserCode-Here {pde.RHSCombiner._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.RHSCombiner._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::RHSCombiner_impl::RHSCombiner_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::RHSCombiner::_wrapObj(reinterpret_cast< void*>(this))),false) , 
  _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(pde.RHSCombiner._ctor2)
  // Insert-Code-Here {pde.RHSCombiner._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.RHSCombiner._ctor2)
}

// user defined constructor
void pde::RHSCombiner_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.RHSCombiner._ctor)
    
  // Insert-UserCode-Here {pde.RHSCombiner._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(pde.RHSCombiner._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.RHSCombiner: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.RHSCombiner._ctor)

  // Insert-UserCode-Here {pde.RHSCombiner._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(pde.RHSCombiner._ctor)
}

// user defined destructor
void pde::RHSCombiner_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.RHSCombiner._dtor)
  // Insert-UserCode-Here {pde.RHSCombiner._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.RHSCombiner._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.RHSCombiner: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.RHSCombiner._dtor) 

  // DO-NOT-DELETE splicer.end(pde.RHSCombiner._dtor)
}

// static class initializer
void pde::RHSCombiner_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.RHSCombiner._load)
  // Insert-Code-Here {pde.RHSCombiner._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.RHSCombiner._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
pde::RHSCombiner_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.RHSCombiner.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.RHSCombiner.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "pde.RHSCombiner: Error casting self to gov::cca::Port");
  } 


  // Provide a pde.NamedPatchPort port with port name RHS 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "RHS", // port instance name
                   "pde.NamedPatchPort",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "pde.RHSCombiner: Error calling addProvidesPort(port,"
        "\"RHS\", \"pde.NamedPatchPort\", typeMap) ", -2);
    throw;
  }    

  // Use a gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    this->d_services.registerUsesPort(
                   "ppf", // port instance name
                   "gov.cca.ports.ParameterPortFactory",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.RHSCombiner: Error calling registerUsesPort(\"ppf\", "
       "\"gov.cca.ports.ParameterPortFactory\", typeMap) ", -2);
    throw;
  }

  // Use a pde.NamedPatchPort port with port name reaction 
  try{
    this->d_services.registerUsesPort(
                   "reaction", // port instance name
                   "pde.NamedPatchPort",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.RHSCombiner: Error calling registerUsesPort(\"reaction\", "
       "\"pde.NamedPatchPort\", typeMap) ", -2);
    throw;
  }

  // Use a pde.NamedPatchPort port with port name diffusion 
  try{
    this->d_services.registerUsesPort(
                   "diffusion", // port instance name
                   "pde.NamedPatchPort",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.RHSCombiner: Error calling registerUsesPort(\"diffusion\", "
       "\"pde.NamedPatchPort\", typeMap) ", -2);
    throw;
  }

  // Use a pde.NamedPatchPort port with port name dump 
  try{
    this->d_services.registerUsesPort(
                   "dump", // port instance name
                   "pde.NamedPatchPort",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.RHSCombiner: Error calling registerUsesPort(\"dump\", "
       "\"pde.NamedPatchPort\", typeMap) ", -2);
    throw;
  }


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(pde.RHSCombiner.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(pde.RHSCombiner.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
pde::RHSCombiner_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.RHSCombiner.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.RHSCombiner.boccaReleaseServices)
  this->d_services=0;


  // Un-provide pde.NamedPatchPort port with port name RHS 
  try{
    services.removeProvidesPort("RHS");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.RHSCombiner: Error calling removeProvidesPort("
              << "\"RHS\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    services.unregisterUsesPort("ppf");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.RHSCombiner: Error calling unregisterUsesPort("
              << "\"ppf\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release pde.NamedPatchPort port with port name reaction 
  try{
    services.unregisterUsesPort("reaction");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.RHSCombiner: Error calling unregisterUsesPort("
              << "\"reaction\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release pde.NamedPatchPort port with port name diffusion 
  try{
    services.unregisterUsesPort("diffusion");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.RHSCombiner: Error calling unregisterUsesPort("
              << "\"diffusion\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release pde.NamedPatchPort port with port name dump 
  try{
    services.unregisterUsesPort("dump");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.RHSCombiner: Error calling unregisterUsesPort("
              << "\"dump\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(pde.RHSCombiner.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.RHSCombiner.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::RHSCombiner_impl::boccaForceUsePortInclude_impl (
  /* in */::gov::cca::ports::ParameterPortFactory dummy0,
  /* in */::pde::NamedPatchPort dummy1,
  /* in */::pde::NamedPatchPort dummy2,
  /* in */::pde::NamedPatchPort dummy3,
  /* in */::bsl::arr dummy4 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.RHSCombiner.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.RHSCombiner.boccaForceUsePortInclude)
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;
    (void)dummy3;
    (void)dummy4;

  // Bocca generated code. bocca.protected.end(pde.RHSCombiner.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.RHSCombiner.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
pde::RHSCombiner_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.RHSCombiner.setServices)

  // Insert-UserCode-Here{pde.RHSCombiner.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(pde.RHSCombiner.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(pde.RHSCombiner.setServices)
  
  // Insert-UserCode-Here{pde.RHSCombiner.setServices:epilog}

  // DO-NOT-DELETE splicer.end(pde.RHSCombiner.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
pde::RHSCombiner_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.RHSCombiner.releaseServices)

  // Insert-UserCode-Here {pde.RHSCombiner.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(pde.RHSCombiner.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(pde.RHSCombiner.releaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.RHSCombiner.releaseServices)
}

/**
 * Method:  setData[]
 */
int32_t
pde::RHSCombiner_impl::setData_impl (
  /* in */int32_t ndim,
  /* in array<double> */::sidl::array<double> dataNamed,
  /* in array<int> */::sidl::array<int32_t> lowerCorner,
  /* in array<int> */::sidl::array<int32_t> upperCorner,
  /* in array<int> */::sidl::array<int32_t> shape,
  /* in */int32_t nvars,
  /* in */::pde::MeshColl mc,
  /* in */const ::std::string& name ) 
{
  // DO-NOT-DELETE splicer.begin(pde.RHSCombiner.setData)
	return 0; // we don't need this for the combiner
  // DO-NOT-DELETE splicer.end(pde.RHSCombiner.setData)
}

/**
 * Method:  compute[]
 */
int32_t
pde::RHSCombiner_impl::compute_impl (
  /* in */int32_t ndim,
  /* in array<double> */::sidl::array<double> data1,
  /* in array<int> */::sidl::array<int32_t> lowerCorner,
  /* in array<int> */::sidl::array<int32_t> upperCorner,
  /* in array<int> */::sidl::array<int32_t> shape,
  /* in */int32_t nvars,
  /* in */::pde::MeshColl mc,
  /* inout array<double> */::sidl::array<double>& data2 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.RHSCombiner.compute)
    gov::cca::Port dport, rport, lport;
    pde::NamedPatchPort diffusion;
    pde::NamedPatchPort reaction;
    pde::NamedPatchPort dump;

    ::sidl::array<double> tmp = bsl::arr::cloneDouble1(data2); // cast errro
    
    try {
	lport = this->d_services.getPort("dump");
	dump = ::babel_cast< pde::NamedPatchPort >(lport);
    } 
    catch (...) {
	std::cout << "skipping logging in rhs compute" << std::endl;
	// info: dump skipped- not connected
    }

    try {
	dport = this->d_services.getPort("diffusion");
	diffusion = ::babel_cast< pde::NamedPatchPort >(dport);
    } 
    catch (...) {
	std::cout << "skipping diffusion in rhs compute" << std::endl;
	// info: diffusion skipped- not connected
    }

  if (dport._not_nil()) {
    if (diffusion._is_nil()) {
      this->d_services.releasePort("diffusion");
      BOCCA_THROW_CXX(sidl::SIDLException, "pde.RHSCombiner: Error casting gov::cca::Port diffusion to type pde::NamedPatchPort");
    }
    // compute
    diffusion.setComputeInfoUniform(d_boundaryWidth, d_stencil_radius, d_meshShape, d_delta);
    bsl::arr::fill(tmp, 0.0);

    if (dump._not_nil()) 
    {
	sidl::array<int> idummy;
	sidl::array<double> dummy;
	dump.setData(0, dummy, idummy, idummy, idummy, 0, pde::MeshColl_CENTERS, "driver.ex1.rhs.prediff.log");
	dump.compute(ndim, data1, lowerCorner, upperCorner, shape, nvars, mc, tmp);
    }

    diffusion.compute(ndim, data1, lowerCorner, upperCorner, shape, nvars, mc, tmp);

    if (dump._not_nil()) 
    {
	sidl::array<int> idummy;
	sidl::array<double> dummy;
	dump.setData(0, dummy, idummy, idummy, idummy, 0, pde::MeshColl_CENTERS, "driver.ex1.rhs.middiff.log");
	dump.compute(ndim, data1, lowerCorner, upperCorner, shape, nvars, mc, tmp);
    }
    
    int32_t top = data1.upper(0);
    for (int32_t i = data1.lower(0); i <= top; i++) data2.set(i, data2[i] + tmp[i]);
    
    if (dump._not_nil()) {
	sidl::array<int> idummy;
	sidl::array<double> dummy;
	dump.setData(0, dummy, idummy, idummy, idummy, 0, pde::MeshColl_CENTERS, "driver.ex1.rhs.postdiff.log");
	dump.compute(ndim, data1, lowerCorner, upperCorner, shape, nvars, mc, data2);
    }
    this->d_services.releasePort("diffusion");
  }

  try {
      rport = this->d_services.getPort("reaction");
      reaction = ::babel_cast< pde::NamedPatchPort >(rport);
  } 
  catch (...) {
      std::cout << "skipping reaction in rhs compute" << std::endl;
      // info: reaction skipped- not connected
  }
  
  if (rport._not_nil()) {
      if (reaction._is_nil()) {
	  this->d_services.releasePort("reaction");
	  BOCCA_THROW_CXX(sidl::SIDLException, "pde.RHSCombiner: Error casting gov::cca::Port reaction to type pde::NamedPatchPort");
      }
      // compute
      reaction.setComputeInfoUniform(d_boundaryWidth, d_stencil_radius, d_meshShape, d_delta);
      bsl::arr::fill(tmp, 0.0);
      
      if (dump._not_nil()) {
	  sidl::array<int> idummy;
	  sidl::array<double> dummy;
	  dump.setData(0, dummy, idummy, idummy, idummy, 0, pde::MeshColl_CENTERS, "driver.ex1.rhs.prerxn.log");
	  dump.compute(ndim, data1, lowerCorner, upperCorner, shape, nvars, mc, tmp);
      }
      
      reaction.compute(ndim, data1, lowerCorner, upperCorner, shape, nvars, mc, tmp);
      
      if (dump._not_nil()) {
	  sidl::array<int> idummy;
	  sidl::array<double> dummy;
	  dump.setData(0, dummy, idummy, idummy, idummy, 0, pde::MeshColl_CENTERS, "driver.ex1.rhs.midrxn.log");
	  dump.compute(ndim, data1, lowerCorner, upperCorner, shape, nvars, mc, tmp);
      }
      
      int32_t top = data1.upper(0);
      for (int32_t i = data1.lower(0); i <= top; i++) data2.set(i, data2[i] + tmp[i]);
      
      if (dump._not_nil()) {
	  sidl::array<int> idummy;
	  sidl::array<double> dummy;
	  dump.setData(0, dummy, idummy, idummy, idummy, 0, pde::MeshColl_CENTERS, "driver.ex1.rhs.postrxn.log");
	  dump.compute(ndim, data1, lowerCorner, upperCorner, shape, nvars, mc, data2);
      }
      this->d_services.releasePort("reaction");
  }
  
  if (dump._not_nil()) {
      this->d_services.releasePort("dump");
  }
  return 0;
  
  // DO-NOT-DELETE splicer.end(pde.RHSCombiner.compute)
}

/**
 * Set extra data for processing several patches of the same sort.
 * @param boundaryWidth something
 * @param stencil_radius something else
 * @param meshShape mesh size in each dimension (excludes boundaries).
 * @param delta grid spacing in each dimension (uniform cell size assumed).
 */
int32_t
pde::RHSCombiner_impl::setComputeInfoUniform_impl (
  /* in */int32_t boundaryWidth,
  /* in */int32_t stencil_radius,
  /* in array<int> */::sidl::array<int32_t> meshShape,
  /* in array<double> */::sidl::array<double> delta ) 
{
  // DO-NOT-DELETE splicer.begin(pde.RHSCombiner.setComputeInfoUniform)
	d_boundaryWidth = boundaryWidth;
	d_stencil_radius = stencil_radius;
	d_meshShape = bsl::arr::cloneInt1(meshShape);
	d_delta = bsl::arr::cloneDouble1(delta);
  // DO-NOT-DELETE splicer.end(pde.RHSCombiner.setComputeInfoUniform)
}

/**
 * A method to indicate that all state set by set can now be forgotten 
 */
void
pde::RHSCombiner_impl::clearData_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.RHSCombiner.clearData)
	// we don't need this for the combiner
  // DO-NOT-DELETE splicer.end(pde.RHSCombiner.clearData)
}


// DO-NOT-DELETE splicer.begin(pde.RHSCombiner._misc)
// Insert-Code-Here {pde.RHSCombiner._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(pde.RHSCombiner._misc)

