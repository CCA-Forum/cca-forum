// 
// File:          bsl_morph_Impl.cxx
// Symbol:        bsl.morph-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for bsl.morph
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "bsl_morph_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_bsl_datatype_hxx
#include "bsl_datatype.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(bsl.morph._includes)

  // Insert-UserCode-Here {bsl.morph._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(bsl.morph._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(bsl.morph._includes)

  // Insert-UserCode-Here {bsl.morph._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(bsl.morph._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
bsl::morph_impl::morph_impl() : StubBase(reinterpret_cast< void*>(
  ::bsl::morph::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(bsl.morph._ctor2)
  // Insert-Code-Here {bsl.morph._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(bsl.morph._ctor2)
}

// user defined constructor
void bsl::morph_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(bsl.morph._ctor)
    
  // Insert-UserCode-Here {bsl.morph._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(bsl.morph._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR bsl.morph: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(bsl.morph._ctor)

  // Insert-UserCode-Here {bsl.morph._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(bsl.morph._ctor)
}

// user defined destructor
void bsl::morph_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(bsl.morph._dtor)
  // Insert-UserCode-Here {bsl.morph._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(bsl.morph._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR bsl.morph: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(bsl.morph._dtor) 

  // DO-NOT-DELETE splicer.end(bsl.morph._dtor)
}

// static class initializer
void bsl::morph_impl::_load() {
  // DO-NOT-DELETE splicer.begin(bsl.morph._load)
  // Insert-Code-Here {bsl.morph._load} (class initialization)
  // DO-NOT-DELETE splicer.end(bsl.morph._load)
}

// user defined static methods:
/**
 * Method:  datatype2string[]
 */
::std::string
bsl::morph_impl::datatype2string_impl (
  /* in */::bsl::datatype dt ) 
{
  // DO-NOT-DELETE splicer.begin(bsl.morph.datatype2string)
  // Insert-Code-Here {bsl.morph.datatype2string} (datatype2string method)
    
    // DO-DELETE-WHEN-IMPLEMENTING exception.begin()
    /*
     * This method has not been implemented
     */
    ::sidl::NotImplementedException ex = ::sidl::NotImplementedException::_create();
    ex.setNote("This method has not been implemented");
    ex.add(__FILE__, __LINE__, "datatype2string");
    throw ex;
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(bsl.morph.datatype2string)
}

/**
 * Method:  string2datatype[]
 */
::bsl::datatype
bsl::morph_impl::string2datatype_impl (
  /* in */const ::std::string& s ) 
{
  // DO-NOT-DELETE splicer.begin(bsl.morph.string2datatype)
  // Insert-Code-Here {bsl.morph.string2datatype} (string2datatype method)
    
    // DO-DELETE-WHEN-IMPLEMENTING exception.begin()
    /*
     * This method has not been implemented
     */
    ::sidl::NotImplementedException ex = ::sidl::NotImplementedException::_create();
    ex.setNote("This method has not been implemented");
    ex.add(__FILE__, __LINE__, "string2datatype");
    throw ex;
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(bsl.morph.string2datatype)
}

/**
 *  replace all occurences of match in buffer with replacement and return a
 * result. buffer is not modified. match is a literal, not a regular expression.
 */
::std::string
bsl::morph_impl::replaceAll_impl (
  /* in */const ::std::string& buffer,
  /* in */const ::std::string& match,
  /* in */const ::std::string& replacement ) 
{
  // DO-NOT-DELETE splicer.begin(bsl.morph.replaceAll)
        size_t m;
	std::string result = buffer;
        for(m = 0; m != std::string::npos; m = bsl_morph_substitute(m, result, match, replacement));
	return result;
  // DO-NOT-DELETE splicer.end(bsl.morph.replaceAll)
}


// user defined non-static methods:
/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
bsl::morph_impl::boccaForceUsePortInclude_impl (
  /* in */::bsl::datatype dummy0 ) 
{
  // DO-NOT-DELETE splicer.begin(bsl.morph.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(bsl.morph.boccaForceUsePortInclude)
    (void)dummy0;

  // Bocca generated code. bocca.protected.end(bsl.morph.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(bsl.morph.boccaForceUsePortInclude)
}


// DO-NOT-DELETE splicer.begin(bsl.morph._misc)

//#include <string.h>
#include <string>

/* This function substitutes string line for the      */
/* first occurance of string a in after location m    */
/* in line. It checks whether the character following */
/* a is a letter, and if it is, the substitution is   */
/* not made. Substitute returns npos if the string a  */
/* isn't found, and otherwise it returns a position   */
/* number past where a is found. Then substitute can  */
/* be called again to find another occurrance of a.   */

size_t bsl_morph_substitute(size_t m, std::string& line, std::string a, std::string b)
{
     std::string alpha = "abcdefghijklmnopqrstuvwxyz";
     size_t n, k;
     n = line.find(a, m);
     if ( n == std::string::npos) return n;  //not found
     k = n+a.length(); //next character position after a
     if (line.length() > k && alpha.find(line[k]) != std::string::npos) return k;
     line = line.substr(0, n) + b + line.substr(k);
     return n+b.length();
}
// DO-NOT-DELETE splicer.end(bsl.morph._misc)

