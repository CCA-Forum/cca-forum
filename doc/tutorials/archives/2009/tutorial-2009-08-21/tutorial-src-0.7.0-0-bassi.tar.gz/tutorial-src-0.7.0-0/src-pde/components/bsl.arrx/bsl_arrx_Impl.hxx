// 
// File:          bsl_arrx_Impl.hxx
// Symbol:        bsl.arrx-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for bsl.arrx
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_bsl_arrx_Impl_hxx
#define included_bsl_arrx_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_bsl_arrx_IOR_h
#include "bsl_arrx_IOR.h"
#endif
#ifndef included_bsl_arrx_hxx
#include "bsl_arrx.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(bsl.arrx._includes)
// Insert-Code-Here {bsl.arrx._includes} (includes or arbitrary code)
// DO-NOT-DELETE splicer.end(bsl.arrx._includes)

namespace bsl { 

  /**
   * Symbol "bsl.arrx" (version 0.0)
   */
  class arrx_impl : public virtual ::bsl::arrx 
  // DO-NOT-DELETE splicer.begin(bsl.arrx._inherits)
  // Insert-Code-Here {bsl.arrx._inherits} (optional inheritance here)
  // DO-NOT-DELETE splicer.end(bsl.arrx._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(bsl.arrx._implementation)
        static std::string toIndexString(int32_t *indices, int32_t dimen);
        static int next(const int dimen, int32_t ind[], const int32_t lower[], const int32_t upper[]);
    // DO-NOT-DELETE splicer.end(bsl.arrx._implementation)

  public:
    // default constructor, used for data wrapping(required)
    arrx_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    arrx_impl( struct bsl_arrx__object * s ) : StubBase(s,true), _wrapped(
      false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~arrx_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:
    /**
     * user defined static method
     */
    static ::std::string
    sfrom_impl (
      /* in array<int> */::sidl::array<int32_t> a
    )
    ;

    /**
     * user defined static method
     */
    static ::std::string
    sfrom_impl (
      /* in array<bool> */::sidl::array<bool> a
    )
    ;

    /**
     * user defined static method
     */
    static ::std::string
    sfrom_impl (
      /* in array<long> */::sidl::array<int64_t> a
    )
    ;

    /**
     * user defined static method
     */
    static ::std::string
    sfrom_impl (
      /* in array<float> */::sidl::array<float> a
    )
    ;

    /**
     * user defined static method
     */
    static ::std::string
    sfrom_impl (
      /* in array<double> */::sidl::array<double> a
    )
    ;

    /**
     * user defined static method
     */
    static ::std::string
    sfrom_impl (
      /* in array<string> */::sidl::array< ::std::string> a
    )
    ;

    /**
     * user defined static method
     */
    static ::std::string
    sfrom_impl (
      /* in array<fcomplex> */::sidl::array< ::sidl::fcomplex> a
    )
    ;

    /**
     * user defined static method
     */
    static ::std::string
    sfrom_impl (
      /* in array<dcomplex> */::sidl::array< ::sidl::dcomplex> a
    )
    ;



    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude_impl() ;
  };  // end class arrx_impl

} // end namespace bsl

// DO-NOT-DELETE splicer.begin(bsl.arrx._misc)
// Insert-Code-Here {bsl.arrx._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(bsl.arrx._misc)

#endif
