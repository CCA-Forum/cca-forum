#!/bin/bash

if ! test -d $ODE_STUDENT_SRC; then
  mkdir -p $SCRATCH/CCA/tutorial-src/obj
  cd $WORKDIR/tutorial-src/obj
  echo "Copying ODE tutorial files - this may take a while"
  cp  -r $ODE_SRC . 2>& 1 > /dev/null 
#  tar zxf $ODE_SRC/../../pde-src.tar.gz
  cd ode
  ./configure
  bocca config --update
  wd=`pwd`
  for f in `find $wd -name .*depends -or -name .*package`; do
     echo "Fixing $f" 
     sed_cmd="s|$ODE_SRC|$ODE_STUDENT_SRC|g";
     sed -e $sed_cmd $f > $f.tmp;
     mv $f.tmp $f;
  done;
  find $wd -name *.la | xargs rm
  make SHELL=/bin/bash -C ports
  make SHELL=/bin/bash -C components
  make SHELL=/bin/bash check
else
  echo "$ODE_STUDENT_SRC exists, you must remove it first."
fi
