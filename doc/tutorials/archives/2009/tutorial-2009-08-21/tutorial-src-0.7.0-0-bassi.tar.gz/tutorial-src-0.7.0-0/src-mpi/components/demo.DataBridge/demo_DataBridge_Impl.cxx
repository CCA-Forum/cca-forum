// 
// File:          demo_DataBridge_Impl.cxx
// Symbol:        demo.DataBridge-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for demo.DataBridge
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "demo_DataBridge_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(demo.DataBridge._includes)

  // Insert-UserCode-Here {demo.DataBridge._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(demo.DataBridge._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(demo.DataBridge._includes)

#include <mpi.h>
#include <sys/types.h>
#include <unistd.h>
#include "dev_cca_ports_MPIService.hxx"


// DO-NOT-DELETE splicer.end(demo.DataBridge._includes)

// special constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
demo::DataBridge_impl::DataBridge_impl() : StubBase(reinterpret_cast< void*>(
  ::demo::DataBridge::_wrapObj(reinterpret_cast< void*>(this))),false) , 
  _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(demo.DataBridge._ctor2)
  // Insert-Code-Here {demo.DataBridge._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(demo.DataBridge._ctor2)
}

// user defined constructor
void demo::DataBridge_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(demo.DataBridge._ctor)
    
  // Insert-UserCode-Here {demo.DataBridge._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(demo.DataBridge._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR demo.DataBridge: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(demo.DataBridge._ctor)

  // Insert-UserCode-Here {demo.DataBridge._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(demo.DataBridge._ctor)
}

// user defined destructor
void demo::DataBridge_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(demo.DataBridge._dtor)
  // Insert-UserCode-Here {demo.DataBridge._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(demo.DataBridge._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR demo.DataBridge: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(demo.DataBridge._dtor) 

  // DO-NOT-DELETE splicer.end(demo.DataBridge._dtor)
}

// static class initializer
void demo::DataBridge_impl::_load() {
  // DO-NOT-DELETE splicer.begin(demo.DataBridge._load)
  // Insert-Code-Here {demo.DataBridge._load} (class initialization)
  // DO-NOT-DELETE splicer.end(demo.DataBridge._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
demo::DataBridge_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(demo.DataBridge.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(demo.DataBridge.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "demo.DataBridge: Error casting self to gov::cca::Port");
  } 


  // Provide a demo.SCMDComponentSetup port with port name SCMDComponentSetup 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "SCMDComponentSetup", // port instance name
                   "demo.SCMDComponentSetup",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "demo.DataBridge: Error calling addProvidesPort(port,"
        "\"SCMDComponentSetup\", \"demo.SCMDComponentSetup\", typeMap) ", -2);
    throw;
  }    


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(demo.DataBridge.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(demo.DataBridge.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
demo::DataBridge_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(demo.DataBridge.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(demo.DataBridge.boccaReleaseServices)
  this->d_services=0;


  // Un-provide demo.SCMDComponentSetup port with port name SCMDComponentSetup 
  try{
    services.removeProvidesPort("SCMDComponentSetup");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "demo.DataBridge: Error calling removeProvidesPort("
              << "\"SCMDComponentSetup\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(demo.DataBridge.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(demo.DataBridge.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
demo::DataBridge_impl::boccaForceUsePortInclude_impl () 

{
  // DO-NOT-DELETE splicer.begin(demo.DataBridge.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(demo.DataBridge.boccaForceUsePortInclude)

  // Bocca generated code. bocca.protected.end(demo.DataBridge.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(demo.DataBridge.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
demo::DataBridge_impl::setServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(demo.DataBridge.setServices)

  // Insert-UserCode-Here{demo.DataBridge.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(demo.DataBridge.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(demo.DataBridge.setServices)
  
  // Insert-UserCode-Here{demo.DataBridge.setServices:epilog}

  // DO-NOT-DELETE splicer.end(demo.DataBridge.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
demo::DataBridge_impl::releaseServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(demo.DataBridge.releaseServices)

  // Insert-UserCode-Here {demo.DataBridge.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(demo.DataBridge.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(demo.DataBridge.releaseServices)
    
  // DO-NOT-DELETE splicer.end(demo.DataBridge.releaseServices)
}

/**
 *  functions for an mcmd bridge component native to a framework
 * spanning all processes and also inserted in a scmd frame covering
 * a subset of the processes.
 * @param subServices a Services handle obtained with getServices on
 * the scmd frame.
 */
void
demo::DataBridge_impl::setServicesInSubdomain_impl (
  /* in */::gov::cca::Services& subServices ) 
{
  // DO-NOT-DELETE splicer.begin(demo.DataBridge.setServicesInSubdomain)

	char hostname[256]; size_t len=255;
	gethostname(hostname,len);
	pid_t pid = getpid();

	scmd_services = subServices;
	gov::cca::TypeMap nulltm;

	{ // scmd frame interaction
        scmd_services.registerUsesPort("MPIService","dev.cca.ports.MPIService",nulltm);
	gov::cca::Port port = scmd_services.getPort("MPIService");
	dev::cca::ports::MPIService msp = ::babel_cast< dev::cca::ports::MPIService > (port);
	int64_t fcomm = msp.getComm();
	MPI_Fint cfcomm = (MPI_Fint)fcomm;
	MPI_Comm scmdcomm = MPI_Comm_f2c(cfcomm);
	int size= -1;
	int rank= -1;
	MPI_Comm_rank(scmdcomm, &rank);
	MPI_Comm_size(scmdcomm, &size);
	std::cout << "demo::DataBridge_impl::setServicesInSubdomain found scmd mpi rank/size of " << 
		rank << "/" << size <<  " in pid " << pid << " on host " << hostname << std::endl;
	msp.releaseComm(fcomm);
	scmd_services.releasePort("MPIService");
        scmd_services.unregisterUsesPort("MPIService");
	}

	{ // mcmd frame interaction
        d_services.registerUsesPort("MPIService","dev.cca.ports.MPIService",nulltm);
	gov::cca::Port port = d_services.getPort("MPIService");
	dev::cca::ports::MPIService msp = ::babel_cast< dev::cca::ports::MPIService > (port);
	int64_t fcomm = msp.getComm();
	MPI_Fint cfcomm = (MPI_Fint)fcomm;
	MPI_Comm dcomm = MPI_Comm_f2c(cfcomm);
	int size= -1;
	int rank= -1;
	MPI_Comm_rank(dcomm, &rank);
	MPI_Comm_size(dcomm, &size);
	std::cout << "demo::DataBridge_impl::setServicesInSubdomain found MCMD mpi rank/size of " << 
		rank << "/" << size  << " in pid " << pid << " on host " << hostname << std::endl;
	msp.releaseComm(fcomm);
	d_services.releasePort("MPIService");
        d_services.unregisterUsesPort("MPIService");
	}

	// more here if the bridge provided anything else.
  // DO-NOT-DELETE splicer.end(demo.DataBridge.setServicesInSubdomain)
}

/**
 *  counterpart of setServicesInSubdomain.
 * @param subServices the same instance of Services given to setServicesInSubdomain.
 */
void
demo::DataBridge_impl::releaseServicesInSubdomain_impl (
  /* in */::gov::cca::Services& subServices ) 
{
  // DO-NOT-DELETE splicer.begin(demo.DataBridge.releaseServicesInSubdomain)
	// more here if the bridge provided anything else
	scmd_services = 0;
  // DO-NOT-DELETE splicer.end(demo.DataBridge.releaseServicesInSubdomain)
}


// DO-NOT-DELETE splicer.begin(demo.DataBridge._misc)
// Insert-Code-Here {demo.DataBridge._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(demo.DataBridge._misc)

