#include "dc/babel.12/babel-cca/AllBabelCCA.hxx"
#include <mpi.h>
#include "mpi/dev_cca_ports_MPISetup.hxx"
#include "mpitest/demo_SCMDComponentSetup.hxx"

/* One of the goals of CCA standards is to make the simple things easy and the
   hard things possible. Where necessary, we will err on the side of possibility
   rather than ease. MPMD coding is relatively hard.
 */
int main(int argc, char **argv)
{
  
  MPI_Init(NULL,NULL);
  {
  ccaffeine::AbstractFramework caf = ccaffeine::AbstractFramework::_create();
  gov::cca::TypeMap nulltm;
  std::string args = "--path /home/baallan/cca/sf/pde-hands-on/obj/mpiinstall/share/cca:/home/baallan/cca/sf/pde-hands-on/obj/mpiinstall/lib";
  caf.initialize(args,0,false); // set up ccaffeine without default internal mpiservice support.
  gov::cca::AbstractFramework top = caf;
  // ccaffeine dependency ends here.

  // Get a Services handle for main() acting as a component 'main' in frame 'top'.
  // Its phantom sidl class name is mcmd.main.
  gov::cca::Services topServices = top.getServices("main","mcmd.main", nulltm);
  topServices.registerUsesPort("topBuilder","gov.cca.ports.BuilderService", nulltm);
  gov::cca::Port port = topServices.getPort("topBuilder");

  // get BuilderService and load an mpiservice implementation in the top frame
  gov::cca::ports::BuilderService topBuilderService = ::babel_cast< gov::cca::ports::BuilderService >(port);
  gov::cca::ComponentID topframeComponentID = topBuilderService.getComponentID("main");
  gov::cca::ComponentID mpiTopComponentID = topBuilderService.createInstance("MPITop", "dev.cca.common.MPICommSource", nulltm);

  // grab the MPISetup port and initialize it with the world communicator.
  topServices.registerUsesPort("MPISetup", "dev.cca.ports.MPISetup", nulltm);
  gov::cca::ConnectionID mpiSetupConnID = topBuilderService.connect(topframeComponentID,"MPISetup", mpiTopComponentID, "MPISetup");
  port = topServices.getPort("MPISetup");
  dev::cca::ports::MPISetup topMPISetup = ::babel_cast< dev::cca::ports::MPISetup >(port);
  // note excruciatingly explicit casting
  MPI_Fint top_fortran_comm = MPI_Comm_c2f(MPI_COMM_WORLD);
  int64_t top_sidl_comm = (int64_t)top_fortran_comm; 
  topMPISetup.initAsService( top_sidl_comm );
  // frame top now has a running MPIService that was loaded as a component.

  // Now in the top frame create some application specific data interchange component
  // It will use the MPIService in the top frame.
  // Eventually it will also appear as a component in each of the scmd subdomains.
  gov::cca::ComponentID topDataBridgeComponentID = topBuilderService.createInstance("DataBridge", "demo.DataBridge", nulltm);


  // for simple mcmd use, we construct scmd subdomains with non-overlapping communicators.
  gov::cca::AbstractFramework scmd = top.createEmptyFramework();

  // set the main program up as a component in the scmd frames.
  gov::cca::Services scmdServices = scmd.getServices("submain","scmd.main",nulltm);
  
  // split the mpi world naively into subdomains 'ODDS' and 'EVENS'.
  // This example can work with any number of subdomains (non-overlapping); it is not limited to 2 subdomains.
  int worldrank = -1;
  MPI_Comm_rank(MPI_COMM_WORLD, &worldrank);
  MPI_Comm scmd_comm;
  MPI_Comm_split(MPI_COMM_WORLD, worldrank % 2, worldrank, &scmd_comm);

  scmdServices.registerUsesPort("scmdBuilder","gov.cca.ports.BuilderService", nulltm);
  port = scmdServices.getPort("scmdBuilder");

  // get BuilderService and load an mpiservice implementation in the scmd frames
  gov::cca::ports::BuilderService scmdBuilderService = ::babel_cast< gov::cca::ports::BuilderService >(port);
  gov::cca::ComponentID scmdframeComponentID = scmdBuilderService.getComponentID("submain");
  gov::cca::ComponentID mpiScmdComponentID = scmdBuilderService.createInstance("MPIScmd", "dev.cca.common.MPICommSource", nulltm);

  // grab the scmd frame MPISetup port and initialize it with the scmd subdomain communicator.
  scmdServices.registerUsesPort("MPISetup", "dev.cca.ports.MPISetup", nulltm);
  gov::cca::ConnectionID scmdMPISetupConnID = scmdBuilderService.connect(scmdframeComponentID,"MPISetup", mpiScmdComponentID, "MPISetup");
  port = scmdServices.getPort("MPISetup");
  dev::cca::ports::MPISetup scmdMPISetup = ::babel_cast< dev::cca::ports::MPISetup >(port);
  // note excruciatingly explicit casting again
  MPI_Fint scmd_fortran_comm = MPI_Comm_c2f(scmd_comm);
  int64_t scmd_sidl_comm = (int64_t)scmd_fortran_comm; 
  scmdMPISetup.initAsService( scmd_sidl_comm );
  // frame scmd now has a running MPIService that was loaded as a component.


  // Now we make the bridge component created in the top frame appear in the scmd frame.
  // This is just like setting up main to act as a component in both the top and scmd frames.
  gov::cca::Services scmdDataBridgeServices = scmd.getServices("scmdDataBridge", "demo.DataBridge", nulltm);

  // We tell the DataBridge about the second (sub)framework instance
  // that it is participating in by calling a method DataBridge defines on a port it
  // provides to the top frame.
  topServices.registerUsesPort("SCMDComponentSetup", "demo.SCMDComponentSetup", nulltm);
  gov::cca::ConnectionID scmdComponentSetupConnID = topBuilderService.connect(topframeComponentID,"SCMDComponentSetup", topDataBridgeComponentID, "SCMDComponentSetup");
  port = topServices.getPort("SCMDComponentSetup");
  demo::SCMDComponentSetup scmdComponentSetup = ::babel_cast< demo::SCMDComponentSetup >(port);
  scmdComponentSetup.setServicesInSubdomain(scmdDataBridgeServices);
  // The databridge now appears as a component in each of the scmd subdomains.
  
  /// now frame and run something in the scmd frames. Exactly what depends on your subdomain.
  if (worldrank % 2) { 
    // subdomain ODDS. use scmdBuilderService to do whatever you want in this domain.
    // scmd components using mpiservice will automatically get the correct communicators.
  } else {
    // subdomain EVENS. use scmdBuilderService to do whatever you want in this domain.
  }

  // compute done. now tear it all down in reverse.

  // shutdown databridge ports in scmd frame and disconnect from it in top frame.
  scmdComponentSetup.releaseServicesInSubdomain(scmdDataBridgeServices);
  topServices.releasePort("SCMDComponentSetup");
  topBuilderService.disconnect(scmdComponentSetupConnID,0);
  topServices.unregisterUsesPort("SCMDComponentSetup");

  // deregister databridge from scmd frame.
  scmd.releaseServices(scmdDataBridgeServices);
  // shut down mpiservice in scmd frame and destroy mpisetup server there
  scmdMPISetup.finalize(false);
  MPI_Comm_free(&scmd_comm);
  scmdServices.releasePort("MPISetup");
  scmdBuilderService.disconnect(scmdMPISetupConnID, 0 ); 
  scmdServices.unregisterUsesPort("MPISetup");
  scmdBuilderService.destroyInstance(mpiScmdComponentID,0);

  // disconnect from scmd builder and close scmd frame
  scmdServices.releasePort("scmdBuilder");
  scmdServices.unregisterUsesPort("scmdBuilder");
  scmd.releaseServices(scmdServices);
  scmd.shutdownFramework();


  // destroy databridge in top frame
  topBuilderService.destroyInstance(topDataBridgeComponentID, 0);
  // shut down mpiservice in top frame and destroy mpisetup server there
  topMPISetup.finalize( false ); 
  topServices.releasePort("MPISetup");
  topBuilderService.disconnect(mpiSetupConnID, 0);
  topServices.unregisterUsesPort("MPISetup");
  topBuilderService.destroyInstance(mpiTopComponentID, 0);

  // disconnect from top builder and close top frame
  topServices.releasePort("topBuilder");
  topServices.unregisterUsesPort("topBuilder");
  top.releaseServices(topServices);
  top.shutdownFramework();

  // The dtor on everything needs to be finished before MPI_Finalize,
  // so we close the scope. In other languages, we would need deleteref on
  // the mpisetup port instances we're holding. Else mpich will exit(1)
  // if shutdown deallocates lingering references after the return 0 here.
  }
  MPI_Finalize();

  return 0;
}
