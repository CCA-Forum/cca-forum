/*
 * File:          funcwrap_Finder_Impl.h
 * Symbol:        funcwrap.Finder-v0.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for funcwrap.Finder
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_funcwrap_Finder_Impl_h
#define included_funcwrap_Finder_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_funcwrap_Finder_h
#include "funcwrap_Finder.h"
#endif
#ifndef included_funcwrap_Rootfind_h
#include "funcwrap_Rootfind.h"
#endif
#ifndef included_funcwrap_SearchFunction_h
#include "funcwrap_SearchFunction.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif

/* DO-NOT-DELETE splicer.begin(funcwrap.Finder._includes) */
/* Insert-Code-Here {funcwrap.Finder._includes} (include files) */
/* DO-NOT-DELETE splicer.end(funcwrap.Finder._includes) */

/*
 * Private data for class funcwrap.Finder
 */

struct funcwrap_Finder__data {
  /* DO-NOT-DELETE splicer.begin(funcwrap.Finder._data) */
  /* Insert-Code-Here {funcwrap.Finder._data} (private data members) */
  int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(funcwrap.Finder._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct funcwrap_Finder__data*
funcwrap_Finder__get_data(
  funcwrap_Finder);

extern void
funcwrap_Finder__set_data(
  funcwrap_Finder,
  struct funcwrap_Finder__data*);

extern
void
impl_funcwrap_Finder__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_funcwrap_Finder__ctor(
  /* in */ funcwrap_Finder self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_funcwrap_Finder__ctor2(
  /* in */ funcwrap_Finder self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_funcwrap_Finder__dtor(
  /* in */ funcwrap_Finder self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct funcwrap_Finder__object* 
  impl_funcwrap_Finder_fconnect_funcwrap_Finder(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct funcwrap_Finder__object* 
  impl_funcwrap_Finder_fcast_funcwrap_Finder(void* bi, sidl_BaseInterface* _ex);
extern struct funcwrap_Rootfind__object* 
  impl_funcwrap_Finder_fconnect_funcwrap_Rootfind(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct funcwrap_Rootfind__object* 
  impl_funcwrap_Finder_fcast_funcwrap_Rootfind(void* bi, sidl_BaseInterface* 
  _ex);
extern struct funcwrap_SearchFunction__object* 
  impl_funcwrap_Finder_fconnect_funcwrap_SearchFunction(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct funcwrap_SearchFunction__object* 
  impl_funcwrap_Finder_fcast_funcwrap_SearchFunction(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_funcwrap_Finder_fconnect_sidl_BaseClass(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_funcwrap_Finder_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_funcwrap_Finder_fconnect_sidl_BaseInterface(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_funcwrap_Finder_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_ClassInfo__object* 
  impl_funcwrap_Finder_fconnect_sidl_ClassInfo(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_funcwrap_Finder_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_funcwrap_Finder_fconnect_sidl_RuntimeException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_funcwrap_Finder_fcast_sidl_RuntimeException(void* bi, 
  sidl_BaseInterface* _ex);
extern
int32_t
impl_funcwrap_Finder_rootfind(
  /* in */ funcwrap_Finder self,
  /* in */ funcwrap_SearchFunction f,
  /* in */ double tolerance,
  /* in */ double xguess,
  /* in */ double xlow,
  /* in */ double xhigh,
  /* in */ int32_t maxit,
  /* out */ double* xout,
  /* out */ double* errout,
  /* out */ int32_t* fcount,
  /* out */ sidl_BaseInterface *_ex);

extern struct funcwrap_Finder__object* 
  impl_funcwrap_Finder_fconnect_funcwrap_Finder(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct funcwrap_Finder__object* 
  impl_funcwrap_Finder_fcast_funcwrap_Finder(void* bi, sidl_BaseInterface* _ex);
extern struct funcwrap_Rootfind__object* 
  impl_funcwrap_Finder_fconnect_funcwrap_Rootfind(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct funcwrap_Rootfind__object* 
  impl_funcwrap_Finder_fcast_funcwrap_Rootfind(void* bi, sidl_BaseInterface* 
  _ex);
extern struct funcwrap_SearchFunction__object* 
  impl_funcwrap_Finder_fconnect_funcwrap_SearchFunction(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct funcwrap_SearchFunction__object* 
  impl_funcwrap_Finder_fcast_funcwrap_SearchFunction(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_funcwrap_Finder_fconnect_sidl_BaseClass(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_funcwrap_Finder_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_funcwrap_Finder_fconnect_sidl_BaseInterface(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_funcwrap_Finder_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_ClassInfo__object* 
  impl_funcwrap_Finder_fconnect_sidl_ClassInfo(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_funcwrap_Finder_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_funcwrap_Finder_fconnect_sidl_RuntimeException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_funcwrap_Finder_fcast_sidl_RuntimeException(void* bi, 
  sidl_BaseInterface* _ex);
#ifdef __cplusplus
}
#endif
#endif
