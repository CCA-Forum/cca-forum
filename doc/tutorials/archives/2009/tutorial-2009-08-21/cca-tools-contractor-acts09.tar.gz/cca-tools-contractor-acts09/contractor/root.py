# This file is part of Contractor
# Original author: James Amundson, amundson@fnal.gov
# (c) 2007 Fermi Research Alliance, LLC
# For copying information, see the file LICENSE 

#!/usr/bin/env python
import os,sys,glob,time

from utils import *
from nodes import *

class Root:
    def __init__(self, base=None, db="db", build="build",
                 install="install"):
        self.vars = {}
        if base:
            self.vars['base_dir'] = os.path.abspath(base)
        else:
            self.vars['base_dir'] = os.path.abspath(os.getcwd())
        self.vars['db_dir'] = abs_rel_dir(self.vars['base_dir'],db)
        self.vars['archive_dir'] = \
                                 abs_rel_dir(self.vars['base_dir'],"archives")
        self.vars['urlcache_dir'] = \
                                  abs_rel_dir(self.vars['base_dir'],"urlcache")
        self.vars['config_dir'] = \
                                  abs_rel_dir(self.vars['base_dir'],"config")
        self.vars['build_dir'] = abs_rel_dir(self.vars['base_dir'],build)
        self.vars['install_dir'] = abs_rel_dir(self.vars['base_dir'],install)

        self.vars['tag_dir'] = os.path.join(self.vars['db_dir'],"tags")
        self.vars['log_dir'] = os.path.join(self.vars['db_dir'],"logs")

        self.extra_dist_list = []
        self._init_env()
        self.dist = Command('dist',self._dist)
        target(self.dist)
        clean = Command_string('clean','/bin/rm -rf %s %s %s' % \
                               (self.vars['db_dir'], self.vars['build_dir'],
                                self.vars['install_dir']))
        target(clean)
        create_setup = File('create_setup','setup.sh', self._create_setup)
        self.dirs = Directories('root_dirs',[self.vars['base_dir'],
                                             self.vars['db_dir'],
                                             self.vars['archive_dir'],
                                             self.vars['urlcache_dir'],
                                             self.vars['build_dir'],
                                             self.vars['install_dir'],
                                             self.vars['tag_dir'],
                                             self.vars['log_dir'],
                                             self.vars['config_dir']])
        self.dirs.depends(create_setup)
        self.tarball_dir = None

    def _init_env(self):
        env_path_add('PATH',os.path.join(self.vars['install_dir'],'bin'))
        env_path_add('LD_LIBRARY_PATH',
                     os.path.join(self.vars['install_dir'],'lib'))

    def _create_setup(self,filename):
        f = open(filename,"w")
        f.write('PATH="%s:$PATH"\n' % \
                os.path.join(self.vars['install_dir'],'bin'))
        f.write('export PATH\n')
        f.write('LD_LIBRARY_PATH="%s:$LD_LIBRARY_PATH"\n' % \
                os.path.join(self.vars['install_dir'],'lib'))
        f.write('export LD_LIBRARY_PATH\n')
        ver = str(sys.version_info[0]) + "." + str(sys.version_info[1])
        f.write("PYTHONPATH=%s:$PYTHONPATH\n" % (self.vars['install_dir'] + \
        	"/lib/python" + ver + "/site-packages"))
        f.write("export PYTHONPATH\n")

    def get_vars(self):
        return self.vars

    def get_var(self,name):
        return self.vars[name]

    def get_name(self):
        return 'root'

    def get_dist(self):
        return self.dist

    def dirs_node(self):
        return self.dirs

    def extra_dist(self,name):
        self.extra_dist_list.append(name)

    def set_tarball_dir(self,name):
        self.tarball_dir = name

    def set_install_dir(self,name):
        self.vars['install_dir'] = name % self.vars

    def _dist(self):
        os.chdir(self.vars['base_dir'])
        os.chdir("..")
        orig_dir_name = os.path.basename(self.vars['base_dir'])
        tmp_move = 0
        if self.tarball_dir:
            dir_name = self.tarball_dir
            if os.path.exists(dir_name):
                tmp_move = 1
                os.rename(dir_name, dir_name+'contractor_tmp')
            os.rename(orig_dir_name,dir_name)
        else:
            dir_name = orig_dir_name
        tarfile_name = os.path.join(dir_name,"%s.tar.gz" % dir_name)
        content_args = os.path.join(dir_name,"contract.py")
        content_args += " " + os.path.join(dir_name,"contractor")
        content_args += " " + os.path.join(dir_name,"archives")
        content_args += " " + os.path.join(dir_name,"packages")
        for extra in self.extra_dist_list:
            content_args += " " + os.path.join(dir_name,extra)
        command = "tar '--exclude=*.pyc' --exclude='*~' -zcf " + tarfile_name + " " + \
                  content_args
        retval = os.system(command)
        if self.tarball_dir:
            os.rename(dir_name,orig_dir_name)
            if tmp_move:
                os.rename(dir_name+'contractor_tmp',dir_name)
        if not retval:
            print "wrote", os.path.basename(tarfile_name)
        else:
            sys.stderr.write("tarball creation failed!\n")
            sys.exit(1)
        os.chdir(self.vars['base_dir'])

local_root = Root()
