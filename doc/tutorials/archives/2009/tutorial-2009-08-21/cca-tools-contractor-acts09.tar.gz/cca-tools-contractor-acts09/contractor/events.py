# This file is part of Contractor
# Original author: James Amundson, amundson@fnal.gov
# (c) 2007 Fermi Research Alliance, LLC
# For copying information, see the file LICENSE 

#!/usr/bin/env python

_callbacks = { "node-started": [],
			   "node-finished": [],
			   "error": [] }

def connect(event, callback):
	if not _callbacks.has_key(event):
		_callbacks[event] = []
	_callbacks[event].append(callback)

def signal(event, data):
	if _callbacks.has_key(event):
		for callback in _callbacks[event]:
			callback(data)
