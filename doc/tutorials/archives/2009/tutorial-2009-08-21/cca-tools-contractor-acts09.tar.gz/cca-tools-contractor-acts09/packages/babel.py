#!/usr/bin/env python

import os, os.path

from contractor import *
from libxml2 import *
from chasm import *
from language_options import *
from common import nightly, toolsurl, nightlyurl

# The following version will be used if user doesn't explicitly specify the babel_version
# option when invoking contract.py --configure 
default_babel_version = '1.4.0'
babel_trunk_version = '1.4.0' # no idea why it's the same

babel_internal = Option(local_root, "babel_internal", True, bool,
                        "Install internal version of babel", deps=[nightly])

babel_version_opt = Option(local_root, "babel_version", default_babel_version, str, \
                        "Babel version")

babel_version = default_babel_version
 
supported_babel_versions = ['1.0.8', '1.2.1', '1.4.0', 'trunk']

if nightly.get():
    if babel_version_opt.get().startswith('1.0'):
        babel_version = "1.0.8"
        babel_url = nightlyurl + 'babel-' + babel_version + '.tar.gz'
    elif babel_version_opt.get().lower() == 'trunk':
        babel_url = nightlyurl + 'babel-trunk.tar.gz'
        babel_version = babel_trunk_version
        print '%sWarning: Using babel trunk is highly unstable.%s' % (error_msg_pre, error_msg_post)
    else:
        babel_version = "1.4.0"
        babel_url = nightlyurl + 'babel-' + babel_version + '.tar.gz'
else:
    if babel_version_opt.get() in supported_babel_versions:
        babel_version = babel_version_opt.get()
        babel_url = toolsurl + "babel-" + babel_version + ".tar.gz"
    else:
        print "%sUnsupported Babel version specified. Supported versions: %s%s", (error_msg_pre, supported_babel_versions, error_msg_post)
        sys.exit(1)
       

# Extra checks to perform on babel configure output
class LibXML2Check(Stage):
    def __init__(self):
        Stage.__init__(self, "check-libxml2")
    
    def build_method(self):
        Stage.build_method(self)
        log = open("%(log_dir)s/configure" % self._vars()).read()
        if log.find("checking for xml2-config... no") != -1:
            print "libxml2 check failed"
            sys.exit(1)

class PythonSharedLibCheck(Stage):
    def __init__(self):
        Stage.__init__(self,'check-libpython')
    
    def build_method(self):
        Stage.build_method(self)
        log = open("%(log_dir)s/configure" % self._vars()).read()
        if log.find("checking if Python shared library is available...  no") != -1:
            # Babel happily continues by disabling python, we don't want that
            # Print a message and go grab python, then reconfigure
            print "Python dynamic library check failed despite our best efforts"
            sys.exit(1)
            
# Overloaded Babel Package stages

class BabelConfigure(Stage):
    def __init__(self):
        Stage.__init__(self, "configure")
    
    def build_method(self):
        Stage.build_method(self)
        # Create a temporary build directory
        if not os.path.isdir(os.path.join(self._var("build_dir"), "build")):
            os.makedirs(os.path.join(self._var("build_dir"), "build"))
       
        extra_config_opts = '' 

        # Check if javaconfig exists
        if not java.get() and check_bin("javaconfig"):
            # Get the java include path
            print "javaconfig found, not setting JNI_INCLUDES..."
        else:
            javapath = check_bin(java.get())
            if javapath.startswith(os.sep): javapath = os.path.realpath(javapath)
            if javapath: 
                print 'Using Java: ' + javapath
                javac = check_bin(os.path.join(os.path.dirname(javapath),'javac'))
                if javac:
                    #os.environ['JAVAC'] = javac
                    #print 'Setting JAVAC environment variable to: ' + javac
                    # Add . to CLASSPATH
                    if 'CLASSPATH' in os.environ:
                        os.environ['CLASSPATH'] = '.' + os.pathsep + os.environ['CLASSPATH']
                    else:
                        os.environ['CLASSPATH'] = '.'
                    os.environ['PATH'] = javapath + os.pathsep + os.environ['PATH']
            if "JNI_INCLUDES" not in os.environ.keys():
                if javapath:
                    dir = os.path.dirname(javapath)
                    levels = dir.count(os.sep)
                    d = dir
                    for i in range(levels-2):
                        d += os.sep + '..'
                        p = os.path.join(d,'include')
                        if os.path.exists(os.path.join(p,'jni.h')):
                            os.environ["JNI_INCLUDES"] = os.path.abspath(p)
                            print 'Setting JNI_INCLUDES environment variable to: ' + os.environ["JNI_INCLUDES"]
                            break
                    if  "JNI_INCLUDES" not in os.environ.keys(): 
                        paths = os.popen("find " + os.path.join(dir,'..') + " -name \"jni.h\"").read().split("\n")
                        if paths and paths[0]: 
                            path = os.path.dirname(paths[0])
                            os.environ["JNI_INCLUDES"] = os.path.abspath(path)
                            print 'Setting JNI_INCLUDES environment variable to: ' + os.environ["JNI_INCLUDES"]
                if "JNI_INCLUDES" not in os.environ.keys():
                    # Find the include files manually if possible
                    paths = os.popen("locate \"jni.h\"").read().split("\n")
                    if len(paths):
                        path = os.path.dirname(paths[0])
                        os.environ["JNI_INCLUDES"] = os.path.abspath(path)
                        print 'Setting JNI_INCLUDES environment variable to: ' + os.environ["JNI_INCLUDES"]
                    else:
                        print "Couldn't find jni.h! Please set the JNI_INCLUDES variable to the full path "\
                              + "containing jni.h."
            else:
                print 'Found JNI_INCLUDES environment variable: ' + os.environ["JNI_INCLUDES"]
                
                
        # Unset MPI-related env. variables since they tend to break babel configure
        # (reset them after babel configure done)
        mpivars = ['MPI_PREFIX','MPI_DIR']
        backupmpivars = {}
        for var in mpivars:
            if var in os.environ.keys():
                backupmpivars[var] = os.environ[var]
                del os.environ[var]
        
        # Check if language features could be available
        lang_args = ""
        if check_bin(f90.get()):
            if babel_version.startswith('1.0.'):
                lang_args += " --with-chasm="
                if chasm_prefix.get() == "":
                    lang_args += chasm.get_var("root.install_dir")
                else:
                    lang_args += chasm_prefix.get()
            lang_args += " --enable-fortran90=" + f90.get()
        else:
            lang_args = " --disable-fortran90"
        
        if check_bin(f77.get()):
            lang_args += " --enable-fortran77=" + f77.get()
        else:
            lang_args += " --disable-fortran77"
        
        if check_bin(cxx.get()):
            lang_args += " --enable-cxx=" + cxx.get()
        # CXX cannot be disabled currently (Babel configure does not allow it) - BN
        #else:
        #    lang_args += " --disable-cxx"
        else:
            print "Babel can't disable CXX support... ignoring"
        
        if check_bin(java.get()):
            base = os.path.basename(java.get())
            if base:
                lang_args += " --enable-java=" + java.get()
                if "JAVA_HOME" in os.environ.keys():
                    # To avoid a configure bug in babel (issue 590)
                    del os.environ["JAVA_HOME"]
            else:
                lang_args += " --enable-java"
        else:
            lang_args += " --disable-java"
        from python import python_exec, python_version
        pythonpath =  python_exec.get()
        if pythonpath == 'internal':
            pythonpath = check_bin(os.path.join(self._var("root.install_dir"),'bin','python'+python_version.get()))
        if pythonpath:
            lang_args += " --enable-python="
            #if python_prefix.get() not in ["", "External"]:
            #    lang_args += os.path.join(python_prefix.get(), "bin") + os.sep
            lang_args += pythonpath
        else:
            lang_args += " --disable-python"
            
        if check_bin(cc.get()):
            os.environ["CC"] = cc.get()
        
        # Check libxml2 stuff
        libxml2_args = ""
	if babel_version_opt.get().startswith('1.0'):
            p = libxml2_prefix.get()
            if p not in ["", "External"]:
                libxml2_args += " --with-libxml2=" + p

        os.chdir(os.path.join(self._var("build_dir"), "build"))
        system_or_die("%(src_dir)s/configure --prefix=%(root.install_dir)s" % self._vars() \
                      + lang_args + libxml2_args + extra_config_opts, self._log())
        
        # Restore mpi env variable settings if any
        if backupmpivars: os.environ.update(backupmpivars)

        # Missing revision file fix (stops babel complaints about missing version info)
        revfile = os.path.join(self._var("build_dir"),'bin','revision.txt')
        revfiletarget = os.path.join(self._var("build_dir"),'build','compiler', 'gov', 'llnl', 'babel', 'revision.txt')
        if os.path.exists(revfile) and not os.path.exists(revfiletarget):
             from shutil import copyfile
             os.makedirs(os.path.dirname(revfiletarget))
             copyfile(revfile,revfiletarget)
        
        os.chdir(self._var("root.base_dir"))

class BabelMake(Stage):
    def __init__(self):
        Stage.__init__(self, "make", parallel=True)
    
    def build_method(self):
        self.processes = get_num_cores(dynamic=True)
        Stage.build_method(self)
        os.chdir(os.path.join(self._var("build_dir"), "build"))
        system_or_die("make -j" + str(self.processes), self._log())
        os.chdir(self._var("root.base_dir"))

class BabelInstall(Stage):
    def __init__(self):
        Stage.__init__(self, "install", parallel=True)
    
    def build_method(self):
        self.processes = get_num_cores()
        Stage.build_method(self)
        os.chdir(os.path.join(self._var("build_dir"), "build"))
        if babel_version.startswith('1.0'):
            system_or_die("make install", self._log())
        else:
            system_or_die("make -j" + str(get_num_cores()) + " install", self._log())
        # validate version
        babel_ver, babel_ver_from_config = validateBabelVersion() 
        if babel_ver.count('.') < 2:
            print "%sWarning: unable to determine valid babel version! Babel version is %s, " \
                  + "which likely will not work downstream.%s" % (error_msg_pre,babel_ver,error_msg_post)
        os.chdir(self._var("root.base_dir"))

# Misc methods

def validateBabelVersion():
    babel_ver = ''
    babel_ver_from_config = ''
    failed = False

    if os.access("%s/bin/babel-config" % babel.get_var("root.install_dir"), \
                os.X_OK):
        i = 0
        while babel_ver_from_config == '' and i < 10:
            babel_ver_from_config = os.popen("%s/bin/babel-config --version" % \
                            babel.get_var("root.install_dir")).read().strip()
            i += 1
        if babel_ver_from_config.count('.') < 2:
            vinfo = os.popen("%s/bin/babel --version" % \
                    babel.get_var("root.install_dir")).readlines()
            if vinfo:
                for word in vinfo[0].split():
                    if word.count('.') == 2:
                        babel_ver = word.strip()
            else:
                failed = True
        else:
            babel_ver = babel_ver_from_config
    else:
        failed = True

    if failed:
        print "Can't find or execute babel-config to get version info (setting Babel to internal)."

    #print 'Babel version is: ', str(babel_ver)

    return babel_ver, babel_ver_from_config


if babel_internal.get():
    from python import python,numpy
    if babel_version.startswith('1.0') and not babel_version_opt.get().startswith('1.4'):
        babel = Package(local_root, "babel",
                    [Unpack(url = babel_url), \
                    BabelConfigure(), LibXML2Check(), PythonSharedLibCheck(), \
                    BabelMake(), BabelInstall()],
                    [libxml2, chasm, python, numpy])
    else:
        babel = Package(local_root, "babel",
                    [Unpack(url = babel_url), \
                    BabelConfigure(), PythonSharedLibCheck(), \
                    BabelMake(), BabelInstall()],
                    [python, numpy])
else:
    babel = External_package("babel")
    

