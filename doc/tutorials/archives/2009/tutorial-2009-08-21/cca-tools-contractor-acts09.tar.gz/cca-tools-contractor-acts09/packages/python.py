#!/usr/bin/env python

import os
import sys

from contractor import *
from common import *

pythonpath = None
PYTHON = ["python2.5", "python2.4", "python2.6", "python2.3", "python2.2", "python"]
internal_python_version = '2.5.1'


# WARNING: The python module is in the process of being rewritten, so will be messy for a little while

class PythonConfigure(Stage):
    def __init__(self):
        Stage.__init__(self, "configure")
    
    def build_method(self):
        Stage.build_method(self)
        system = os.popen('uname -s').read().strip()
        if system == 'Darwin':
            # Grab prebuilt dylib
            pass

               
def python_check():
    """
    Try to find a working python or use the internal one if we are going to
    build it!
    """
    pythonpath = python_lib_check()

    if not pythonpath: 
        pythonpath = 'internal'

    return pythonpath
    

def python_version_check():
    return str(sys.version_info[0]) + "." + str(sys.version_info[1])

def python_lib_check():
    ver = str(sys.version_info[0]) + "." + str(sys.version_info[1])
    pythonpath = None
    libsuffixes=['.so','.dylib','.dll']

    # python_* variables are set in common.py
    libdirs = [python_libdir]

    if python_version.get(): ver = python_version.get()
    if python_exec.get(): 
        pythonpath = os.path.realpath(python_exec.get())
    else: 
        if not python_version.get():
            for p in PYTHON:
                pythonpath = check_bin('python' + ver)
                if pythonpath: break
        else:
            pythonpath = check_bin('python' + python_version.get())
    if not pythonpath:
        return ""
    
    python_prefixstr = os.path.dirname(pythonpath) 
    libdirs.append(os.path.join(os.path.dirname(python_prefixstr),'lib'))
    libdirs.append(os.path.join(os.path.dirname(python_prefixstr),'lib64'))

    python_config = check_bin("python-config", prefix=python_prefixstr)

    args=''
    if python_config:
        args = os.popen(python_config + " --libs").read().strip()
    else:
        python_config = check_bin("python" + ver + "-config")
        if python_config:
            args = os.popen("python" + ver + "-config --libs").read()
        else:
            # Use find to locate the library
            libs = []
            for suffix in libsuffixes: 
                libs.extend(os.popen('find ' + python_libdir + ' -name python' + ver + '.%s*' % suffix).readlines())
            if libs: 
                args = '-L' + os.path.dirname(libs[0].strip()) + "-lpython" + ver
    
    if not check_compile(flags = args): pythonpath = ''
	
    if not pythonpath:
        'Could not find a Python dynamic library (required for Python components).'

	# Check for Python.h
    if pythonpath.startswith(os.sep):
    	pythonprefix=os.path.dirname(os.path.dirname(pythonpath))
        found = False
        incldirs = ['python'+ver,'python']
        for dir in incldirs:
            if os.path.exists(os.path.join(pythonprefix,'include',dir,'Python.h')):
                found=True
        if not found:
            print 'Could not find Python.h (required for Python components).'
            pythonpath = ''   

    return pythonpath

def numpy_check():
    pythonpath = check_bin(python_exec.get())
    if pythonpath:
        if len(os.popen(pythonpath + " -c 'import numpy' 2>&1").readlines()) == 0:
            return False
    return True

def get_python_configure_args():
    # Try to incorporate existing python configure opts from the python executing this script
    from distutils import sysconfig
    config_args = sysconfig.get_config_var('CONFIG_ARGS').split("' '")
    python_config_opts = ''
    if python_exec.get() != 'internal': return python_config_opts
    if config_args:
        for v in config_args:
            v=v.strip().strip("'").rstrip("'")
            skip = False
            if re.search(r'--\w*dir=.*',v): continue
            for prfx in ['--prefix','--disable-shared','--enable-shared','--enable-framework','--enable-universalsdk']:
                if v.startswith(prfx): skip = True
            if not skip:
                opt = v
                if v.count('=') > 0:
                    name,val=v.split('=')
                    # If there are spaces in the value for an option, put the value in single quotes
                    if val.count(' ')>0: opt = " %s='%s'" % (name,val)   
                python_config_opts += ' ' + opt
    python_config_opts += ' --enable-shared --without-cxx'
    return python_config_opts

# Options 
python_exec = Option(local_root, "python", "", str, "Python interpreter", \
                function = python_check)

python_version = Option(local_root, "python_version", "", str, \
                        "Python version",
                        function = python_version_check)

python_configure_args = Option(local_root, "python_configure_args", "", str, \
                        "Python configuration options (used only when python is set to \"internal\")",
                        function = get_python_configure_args)

numpy_internal = Option(local_root, "numpy_internal", False, bool, \
                            "Should we build numpy (True) or try to use an existing one (False)", \
                            function = numpy_check, deps = [python_exec,python_version])

py_version = "2.5.1"
if python_version.get():
    py_version = python_version.get()
if py_version.startswith(os.sep):
    py_version = os.popen(os.path.join(py_version,'bin','python') + ' --version').read().strip()

python_url = "http://www.python.org/ftp/python/" + py_version + \
             "/Python-" + py_version + ".tar.bz2"
             
numpy_version = "1.0.3-2"
numpy_url = "http://www.cca-forum.org/download/cca-tools/dependencies/numpy-" + \
            numpy_version + ".tar.gz"

if python_exec.get() == 'internal':
    python = Package(root = local_root, name="python", stages = [Unpack(url = python_url), \
                    Configure(extra_args = python_configure_args.get()), Make(), \
                    Install()], depends = [], optiondeps = [python_version])
else:
    prefix = os.path.dirname(os.path.dirname(python_exec.get()))
    python = External_package("python",prefix=prefix)

if numpy_internal.get() or python_exec.get() == 'internal':
    #print 'numpy_internal.get() = ', numpy_internal.get()
    numpy = Package(local_root, "numpy", [Unpack(url = numpy_url), \
                    Py_install()], [python])
else:
    numpy = External_package("numpy")
