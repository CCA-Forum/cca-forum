#!/usr/bin/env python

import os

from contractor import *

def libxml2_check():
	if check_bin("xml2-config"):
		return os.popen("xml2-config --prefix").read().strip()
	elif check_lib("libxml2"):
		return "External"
	else:
		return ""

libxml2_prefix = Option(local_root, "libxml2_prefix", "", str,
						  "Prefix to the libxml2 installation", \
						  function = libxml2_check)

libxml2_version = "2.6.28"
libxml2_url = "http://www.cca-forum.org/download/cca-tools/dependencies/libxml2-" + libxml2_version + ".tar.gz"

if libxml2_prefix.get() == "":
	libxml2 = Package(local_root, "libxml2", [Unpack(url = libxml2_url), \
											  Configure(), Make(), Install()])
else:
	libxml2 = External_package("libxml2")

