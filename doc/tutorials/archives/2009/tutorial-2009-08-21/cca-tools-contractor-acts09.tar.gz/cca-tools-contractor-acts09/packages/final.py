#!/usr/bin/env python

import os

from contractor import *
from ccaffeine import *
from ccafe_gui import *
from bocca import *

msg = "echo 'Finished building and installing the CCA toolchain'"

final = Package(local_root, "final", \
            [Build_command("message", msg)], \
            [ccaffeine, bocca, ccafe_gui])
