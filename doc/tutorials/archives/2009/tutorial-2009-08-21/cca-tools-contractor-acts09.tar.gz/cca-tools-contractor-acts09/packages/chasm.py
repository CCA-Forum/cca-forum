#!/usr/bin/env python

import os, os.path

from contractor import *
from language_options import f90, f90_vendor
from common import toolsurl

chasm_prefix = Option(local_root, "chasm_prefix", "", str, \
						"Location of chasm if it is already installed", \
						deps = [f90, f90_vendor])

#chasm_version = "1.4.RC2"
#chasm_url = "http://downloads.sourceforge.net/chasm-interop/chasm_" + \
#			chasm_version + ".tar.gz"

chasm_version = "1.4"
chasm_url = 'http://www.cca-forum.org/download/cca-tools/dependencies/chasm-' + chasm_version + '.tar.gz'

configure_args = '--with-F90-vendor=%s --with-F90=%s' % \
				(f90_vendor.get(), f90.get())

CFLAGS = ""
CPPFLAGS = ""

class ChasmUnpack(Unpack):
    def __init__(self):
        Unpack.__init__(self, url = chasm_url)
    
    def build_method(self):
        Unpack.build_method(self)
        os.chdir(self._var("build_dir"))
        if not os.path.exists(os.path.join(self._var("build_dir"),"configure.in")):
            system_or_die("mv chasm-" + chasm_version + "/* . && rm -rf chasm-" + chasm_version, self._log())
        os.chdir(self._var("root.base_dir"))
            
class ChasmConfigure(Configure):
	def __init__(self):
		Configure.__init__(self, extra_args = configure_args)
	
	def build_method(self):
		if os.environ.has_key("CFLAGS"):
			CFLAGS = os.environ["CFLAGS"]
		os.environ["CFLAGS"] = "-fPIC"
		if os.environ.has_key("CPPFLAGS"):
			CPPFLAGS = os.environ("CPPFLAGS")
		os.environ["CPPFLAGS"] = "-fPIC"
		Configure.build_method(self)

class ChasmMake(Make):
	def __init__(self):
		Make.__init__(self)
	
	def build_method(self):
		Make.build_method(self)
		if CFLAGS:
			os.environ["CFLAGS"] = CFLAGS
		else:
			del os.environ["CFLAGS"]
		if CPPFLAGS:
			os.environ["CPPFLAGS"] = CPPFLAGS
		else:
			del os.environ["CPPFLAGS"]

if chasm_prefix.get() == "" and check_bin(f90.get()):
	chasm = Package(local_root, "chasm-" + chasm_version,
					[ChasmUnpack(), ChasmConfigure(), \
					ChasmMake(), Install()])
else:
	chasm = External_package("chasm")

