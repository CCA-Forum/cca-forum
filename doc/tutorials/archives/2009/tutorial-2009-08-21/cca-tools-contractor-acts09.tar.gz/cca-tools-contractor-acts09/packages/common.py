#!/usr/bin/env python

from contractor import *
from distutils import sysconfig


prefix = Option(local_root, "prefix", "%(base_dir)s/install", str, \
                "Install all tools in the specified directory")

###
### Because this particular set of tools originated as nightlies, 
### contractor requires that we treat this build as a nightly too.
###
#nightly = Option(local_root, 'nightly', False, bool, 'Install nightly snapshots of Babel and CCA tools')
nightly = Option(local_root, 'nightly', True, bool, 'Install nightly snapshots of Babel and CCA tools')

nightlyurl = 'http://www.cca-forum.org/download/tutorial/cca-tools-acts09/'
toolsurl = 'http://www.cca-forum.org/download/tutorial/cca-tools-acts09/'

python_libdir=sysconfig.get_config_var('LIBDIR')
python_platform=sysconfig.get_config_var('PLATDIR')
