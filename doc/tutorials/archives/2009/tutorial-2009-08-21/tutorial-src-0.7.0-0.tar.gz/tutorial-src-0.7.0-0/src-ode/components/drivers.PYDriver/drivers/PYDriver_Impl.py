#
# File:          PYDriver_Impl.py
# Symbol:        drivers.PYDriver-v0.0
# Symbol Type:   class
# Babel Version: 1.0.8
# Description:   Implementation of sidl class drivers.PYDriver in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
#


# DO-NOT-DELETE splicer.begin(_initial)
# Put your code here...
# DO-NOT-DELETE splicer.end(_initial)

import drivers.PYDriver
import gov.cca.CCAException
import gov.cca.Component
import gov.cca.ComponentRelease
import gov.cca.Port
import gov.cca.Services
import gov.cca.ports.GoPort
import integrator.IntegratorPort
import sidl.BaseClass
import sidl.BaseInterface
import sidl.ClassInfo
import sidl.RuntimeException
import sidl.NotImplementedException

# DO-NOT-DELETE splicer.begin(_before_type)
import sys
# DO-NOT-DELETE splicer.end(_before_type)

class PYDriver:

# All calls to sidl methods should use __IORself

# Normal Babel creation pases in an IORself. If IORself == None
# that means this Impl class is being constructed for native delegation
  def __init__(self, IORself = None):
    if (IORself == None):
      self.__IORself = drivers.PYDriver.PYDriver(impl = self)
    else:
      self.__IORself = IORself
# DO-NOT-DELETE splicer.begin(__init__)
    # Put your code here...
    # Bocca generated code. bocca.protected.begin(drivers.PYDriver._init) 
    self.d_services = None
    self.bocca_print_errs = True
    # Bocca generated code. bocca.protected.end(drivers.PYDriver._init) 
    # Put your code here...
    # Put your code here...
    self.d_services = None 
# DO-NOT-DELETE splicer.end(__init__)

# Returns the IORself (client stub) of the Impl, mainly for use
# with native delegation
  def _getStub(self):
    return self.__IORself

  def boccaSetServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

# DO-NOT-DELETE splicer.begin(boccaSetServices)
# DO-NOT-EDIT-BOCCA
# Bocca generated code. bocca.protected.begin(boccaSetServices) 
    self.d_services = services
    # Create a typemap
    mymap = services.createTypeMap()
    
    port = gov.cca.Port.Port(self.__IORself)  # CAST 
    if not port:
      ex = sidl.SIDLException.SIDLException()
      ex.setNote(__name__,0, 'Error casting self drivers.PYDriver to to gov.cca.Port')
      raise sidl.SIDLException._Exception, ex
    # Provide a gov.cca.ports.GoPort port with port name go 
    try:
      self.d_services.addProvidesPort(port,    # the implementing object
                              'go',       # the name the user will see
                              'gov.cca.ports.GoPort',          # the sidl name of the port type.
                              mymap);         # extra properties.
    except sidl.BaseException._Exception, e:
      (etype, eobj, etb) = sys.exc_info()
      eobj.add(__name__, 0, 'Error - could not addProvidesPort(port,"go","gov.cca.ports.GoPort",mymap)')
      raise sidl.BaseException._Exception, e
    # Register a use port of type integrator.IntegratorPort with port name integrate
    try:
      self.d_services.registerUsesPort('integrate',   # the name the user will see
                                'integrator.IntegratorPort',     # the sidl name of the port type.
                                mymap);       # extra properties.
    except sidl.BaseException._Exception, e:
      (etype, eobj, etb) = sys.exc_info()
      eobj.add(__name__, 0, 'Error - could not registerUsesPort("integrate","integrator.IntegratorPort",mymap)')
      raise sidl.BaseException._Exception, e
    compRelease = gov.cca.ComponentRelease.ComponentRelease(self.__IORself)
    try:
      self.d_services.registerForRelease(compRelease)
    except sidl.BaseException._Exception, e:
      (etype, eobj, etb) = sys.exc_info()
      eobj.exception.add(__name__,0, 'Error - could not registerForRelease(self) in drivers.PYDriver')
      raise sidl.BaseException._Exception, e
      
    return
# Bocca generated code. bocca.protected.end(boccaSetServices)
# DO-NOT-DELETE splicer.end(boccaSetServices)

  def boccaReleaseServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

    # DO-NOT-DELETE splicer.begin(boccaReleaseServices)
    # DO-NOT-EDIT-BOCCA
    # Bocca generated code. bocca.protected.begin(drivers.PYDriver.boccaReleaseServices)
    self.d_services = None
    # UN-Provide a gov.cca.ports.GoPort port with port name go 
    try:
      services.removeProvidesPort('go')
    except sidl.BaseException._Exception, e:
      (etype, eobj, etb) = sys.exc_info()
      eobj.exception.add(__name__,0, 'Error - could not remove provided port gov.cca.ports.GoPort:go')
      raise sidl.BaseException._Exception, e
    # Un-Register a use port of type integrator.IntegratorPort with port name integrate
    try:
      services.unregisterUsesPort('integrate')
    except sidl.BaseException._Exception, e:
      (etype, eobj, etb) = sys.exc_info()
      eobj.exception.add(__name__,0, 'Error - could not unregisterUsesPort("integrate")')
      raise sidl.BaseException._Exception, e
    return
    # Bocca generated code. bocca.protected.end(drivers.PYDriver.boccaReleaseServices)
    # DO-NOT-DELETE splicer.end(boccaReleaseServices)

  def boccaForceUsePortInclude(self, dummy0):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # integrator.IntegratorPort dummy0
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

    """\
 This function should never be called, but helps babel generate better code. 
"""
    # DO-NOT-DELETE splicer.begin(boccaForceUsePortInclude)
    # DO-NOT-EDIT-BOCCA
    # Bocca generated code. bocca.protected.begin(boccaForceUsePortInclude)
    o0 = dummy0
    return
    # Bocca generated code. bocca.protected.end(boccaForceUsePortInclude)
    # DO-NOT-DELETE splicer.end(boccaForceUsePortInclude)

  def setServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

    """\
 Starts up a component presence in the calling framework.
@param services the component instance's handle on the framework world.
Contracts concerning Svc and setServices:

The component interaction with the CCA framework
and Ports begins on the call to setServices by the framework.

This function is called exactly once for each instance created
by the framework.

The argument Svc will never be nil/null.

Those uses ports which are automatically connected by the framework
(so-called service-ports) may be obtained via getPort during
setServices.
"""
    # DO-NOT-DELETE splicer.begin(setServices)
    # Put your code here... prolog
    # bocca-default-code. User may edit or delete.begin(setServices)
    self.boccaSetServices(services)
    # bocca-default-code. User may edit or delete.end(setServices)
    # Put your code here... epilog
    # DO-NOT-DELETE splicer.end(setServices)

  def releaseServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

    """\
Shuts down a component presence in the calling framework.
@param services the component instance's handle on the framework world.
Contracts concerning Svc and setServices:

This function is called exactly once for each callback registered
through Services.

The argument Svc will never be nil/null.
The argument Svc will always be the same as that received in
setServices.

During this call the component should release any interfaces
acquired by getPort().

During this call the component should reset to nil any stored
reference to Svc.

After this call, the component instance will be removed from the
framework. If the component instance was created by the
framework, it will be destroyed, not recycled, The behavior of
any port references obtained from this component instance and
stored elsewhere becomes undefined.

Notes for the component implementor:
1) The component writer may perform blocking activities
within releaseServices, such as waiting for remote computations
to shutdown.
2) It is good practice during releaseServices for the component
writer to remove or unregister all the ports it defined.
"""
    # DO-NOT-DELETE splicer.begin(releaseServices)
    
    # put your code here ... prolog
    # bocca-default-code. User may edit or delete.begin(releaseServices)
    self.boccaReleaseServices(services)
    # bocca-default-code. User may edit or delete.end(releaseServices)
    # put your code here ... epilog
    # DO-NOT-DELETE splicer.end(releaseServices)

  def go(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # int _return
    #

    """\
 
Execute some encapsulated functionality on the component. 
Return 0 if ok, -1 if internal error but component may be 
used further, and -2 if error so severe that component cannot
be further used safely.
"""
# DO-NOT-DELETE splicer.begin(go)
    # Put your code here...
      
    try:
      intport = self.d_services.getPort('integrate')
      myintport = integrator.IntegratorPort.IntegratorPort(intport);   # Casting !!!!
    except:
      print 'Caught an exception in call to getPort()'
      print sys.exc_type, sys.exc_info()
    
    result = myintport.integrate(0.0, 1.0, 100000)  
    print 'Result = ', result
    sys.stdout.flush()
    
    self.d_services.releasePort('integrate')
    
    return 0
# DO-NOT-DELETE splicer.end(go)

# DO-NOT-DELETE splicer.begin(_final)
# Put your code here...
# DO-NOT-DELETE splicer.end(_final)
