// 
// File:          arrayOps_NonLinearOp_Impl.cxx
// Symbol:        arrayOps.NonLinearOp-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for arrayOps.NonLinearOp
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "arrayOps_NonLinearOp_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp._includes)
  // Insert-UserCode-Here {arrayOps.NonLinearOp._includes:prolog} (additional includes or code)
  // Bocca generated code. bocca.protected.begin(arrayOps.NonLinearOp._includes)
#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR
#include <iostream>
#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR
#endif // _BOCCA_STDERR
  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics will
  // include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif
  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}
  // This simplifies exception extending and rethrowing in c++, like SIDL_CHECK in C.
  // EX_OBJ must be the caught exception and is extended with msg and file/line/func added.
  // Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}
  // Bocca generated code. bocca.protected.end(arrayOps.NonLinearOp._includes)
  // Insert-UserCode-Here {arrayOps.NonLinearOp._includes:epilog} (additional includes or code)
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
arrayOps::NonLinearOp_impl::NonLinearOp_impl() : StubBase(reinterpret_cast< 
  void*>(::arrayOps::NonLinearOp::_wrapObj(reinterpret_cast< void*>(this))),
  false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp._ctor2)
  // Insert-Code-Here {arrayOps.NonLinearOp._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp._ctor2)
}

// user defined constructor
void arrayOps::NonLinearOp_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp._ctor)
    
  // Insert-UserCode-Here {arrayOps.NonLinearOp._ctor:prolog} (constructor method) 
  // bocca-default-code. User may edit or delete.begin(arrayOps.NonLinearOp._ctor)
   #if _BOCCA_CTOR_MESSAGES
     std::cerr << "CTOR arrayOps.NonLinearOp: " << BOOST_CURRENT_FUNCTION << " constructing " << this << std::endl;
   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(arrayOps.NonLinearOp._ctor)
    this->nrows = 0;
    this->ncols = 0;
    this->myArray = NULL;
  // Insert-UserCode-Here {arrayOps.NonLinearOp._ctor:epilog} (constructor method)
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp._ctor)
}

// user defined destructor
void arrayOps::NonLinearOp_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp._dtor)
  // Insert-UserCode-Here {arrayOps.NonLinearOp._dtor} (destructor method) 
    this->init();
  // bocca-default-code. User may edit or delete.begin(arrayOps.NonLinearOp._dtor) */
   #if _BOCCA_CTOR_MESSAGES
     std::cerr << "DTOR arrayOps.NonLinearOp: " << BOOST_CURRENT_FUNCTION << " destructing " << this << std::endl;
   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(arrayOps.NonLinearOp._dtor) 
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp._dtor)
}

// static class initializer
void arrayOps::NonLinearOp_impl::_load() {
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp._load)
  // Insert-Code-Here {arrayOps.NonLinearOp._load} (class initialization)
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
arrayOps::NonLinearOp_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(arrayOps.NonLinearOp.boccaSetServices)
  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;
  this->d_services = services;
  typeMap = this->d_services.createTypeMap();
  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , "arrayOps.NonLinearOp: Error casting self to gov::cca::Port");
  } 
  // Provide a arrayop.NonLinearOp port with port name NonLinearPort 
  try{
    this->d_services.addProvidesPort(port, // implementing object
                                     "NonLinearPort", // port instance name
                                     "arrayop.NonLinearOp", // full sidl type of port
                                     typeMap); // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, "arrayOps.NonLinearOp: Error calling addProvidesPort(port,\"NonLinearPort\", \"arrayop.NonLinearOp\", typeMap) ", -2);
    throw;
  }    
  gov::cca::ComponentRelease cr = ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(arrayOps.NonLinearOp.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
arrayOps::NonLinearOp_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(arrayOps.NonLinearOp.boccaReleaseServices)
  this->d_services=0;
  // Un-provide arrayop.NonLinearOp port with port name NonLinearPort 
  try{
    services.removeProvidesPort("NonLinearPort");
  } catch ( ::gov::cca::CCAException ex )  {
#ifdef _BOCCA_STDERR
    std::cerr << "arrayOps.NonLinearOp: Error calling removeProvidesPort(\"NonLinearPort\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() << std::endl;
#endif // _BOCCA_STDERR
  }
  return;
  // Bocca generated code. bocca.protected.end(arrayOps.NonLinearOp.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
arrayOps::NonLinearOp_impl::boccaForceUsePortInclude_impl () 

{
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(arrayOps.NonLinearOp.boccaForceUsePortInclude)
  // Bocca generated code. bocca.protected.end(arrayOps.NonLinearOp.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument Svc will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
arrayOps::NonLinearOp_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp.setServices)
  // Insert-UserCode-Here{arrayOps.NonLinearOp.setServices:prolog}
  // bocca-default-code. User may edit or delete.begin(arrayOps.NonLinearOp.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(arrayOps.NonLinearOp.setServices)
  
  // Insert-UserCode-Here{arrayOps.NonLinearOp.setServices:epilog}
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument Svc will never be nil/null.
 * The argument Svc will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to Svc.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
arrayOps::NonLinearOp_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp.releaseServices)
  // Insert-UserCode-Here {arrayOps.NonLinearOp.releaseServices} 
  // bocca-default-code. User may edit or delete.begin(arrayOps.NonLinearOp.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(arrayOps.NonLinearOp.releaseServices)
    
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp.releaseServices)
}

/**
 * Method:  init[]
 */
void
arrayOps::NonLinearOp_impl::init_impl () 

{
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp.init)
  // Insert-Code-Here {arrayOps.NonLinearOp.init} (init method)
    
    if (myArray != NULL)
      free(myArray);
    myArray = NULL;
    nrows = 0;
    ncols = 0;
    return;
    
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp.init)
}

/**
 * Method:  logMat[]
 */
int32_t
arrayOps::NonLinearOp_impl::logMat_impl (
  /* in */double alpha,
  /* in rarray[m,n] */double* A,
  /* inout rarray[m,n] */double* R,
  /* in */int32_t m,
  /* in */int32_t n ) 
{
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp.logMat)
  // Insert-Code-Here {arrayOps.NonLinearOp.logMat} (logMat method)
    
  if (this->myArray == NULL){
    this->myArray = (double *) calloc(n * m, sizeof(double));
    this->nrows = m;
    this->ncols = n;
  }
  else if (this->nrows != m || this->ncols != n){  /* Size mismatch with previous calls */
     fprintf(stderr, "EEROR:: %s:%d: Size mismatch in nonlinear operator.\n",
             __FILE__, __LINE__);
     return -1;
  }
  for (int i = 0; i < m; i++) {
    for (int j = 0; j < n; j++) {
      int index = j*m + i;       /* Raw arrays A, R are column major */
      int myindex = i*n + j;     /* Local array is raw major */
      this->myArray[myindex] += log10(A[index]);
      R[index] = this->myArray[myindex];
    }
  }
  return 0;
    
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp.logMat)
}

/**
 * Method:  mulMatMat[]
 */
int32_t
arrayOps::NonLinearOp_impl::mulMatMat_impl (
  /* in */double beta,
  /* in array<double,2> */::sidl::array<double> A,
  /* in array<double,2> */::sidl::array<double> M,
  /* inout array<double,2> */::sidl::array<double>& R ) 
{
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp.mulMatMat)
  // Insert-Code-Here {arrayOps.NonLinearOp.mulMatMat} (mulMatMat method)
    
  int A_ndim = A.dimen(),
      A_nrows = A.length(0),
      A_ncols = A.length(1),
      M_ndim = M.dimen(),
      M_nrows = M.length(0),
      M_ncols = M.length(1),
      R_ndim = R.dimen(),
      R_nrows = R.length(0),
      R_ncols = R.length(1);
  double *A_data = A.first(),
         *M_data = M.first(),
         *R_data = R.first();
  if (! (A_ndim == M_ndim && M_ndim == R_ndim)) {
     fprintf(stderr, "EEROR:: %s:%d: Dimension mismatch in incoming array arguments.\n",
             __FILE__, __LINE__);
     fprintf(stderr, "A_ndim = %d   M_ndim = %d  R_ndim = %d\n",
             A_ndim, M_ndim, R_ndim);
     return -1;
  }
  if (A_ndim != 2){
     fprintf(stderr, "EEROR:: %s:%d: Method supports only two dimensional arrays.\n",
             __FILE__, __LINE__);
     return -1;
  }
  if (! (A_nrows == M_nrows && M_nrows == R_nrows )) {
     fprintf(stderr, "EEROR:: %s:%d: Mismatch number of rows in incoming array arguments.\n",
             __FILE__, __LINE__);
     fprintf(stderr, "A_nrows = %d   M_nrows = %d  R_nrows = %d\n",
             A_nrows, M_nrows, R_nrows);
     return -1;
  }
  if (! (A_ncols == M_ncols && M_ncols == R_ncols )) {
     fprintf(stderr, "EEROR:: %s:%d: Mismatch number of rows in incoming array arguments.\n",
             __FILE__, __LINE__);
     fprintf(stderr, "A_ncols = %d   M_ncols = %d  R_ncols = %d\n",
             A_ncols, M_ncols, R_ncols);
     return -1;
  }
  if (this->myArray == NULL){
    this->myArray = (double *) calloc(A_nrows * A_ncols, sizeof(double));
    this->nrows = A_nrows;
    this->ncols = A_ncols;
  }
  else if (! (A_ncols == this->ncols && A_nrows == this->nrows)) {
     fprintf(stderr, "EEROR:: %s:%d: Size mismatch in nonlinear operator.\n",
             __FILE__, __LINE__);
     return -1;
  }
  for (int i = 0; i < A_nrows; i++) {
    for (int j = 0; j < A_ncols; j++) {
      int index = i*A_ncols + j;       /*  Local array is row-major */
      (this->myArray)[index] += A.get(i,j) * M.get(i,j); /* SIDl C++ array binding handles order */
      R.set(i, j, (this->myArray)[index]);
    }
  }
  return 0;
    
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp.mulMatMat)
}

/**
 * Method:  getResult[]
 */
int32_t
arrayOps::NonLinearOp_impl::getResult_impl (
  /* inout rarray[m,n] */double* R,
  /* in */int32_t m,
  /* in */int32_t n ) 
{
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp.getResult)
  // Insert-Code-Here {arrayOps.NonLinearOp.getResult} (getResult method)
    
  if (this->myArray == NULL){
     fprintf(stderr, "EEROR:: %s:%d: getResults() called before any array operations.\n",
             __FILE__, __LINE__);
     return -1;
  }
  else if (! (n == this->ncols && m == this->nrows)) {
     fprintf(stderr, "EEROR:: %s:%d: Size mismatch in getResult() arguments.\n",
             __FILE__, __LINE__);
     return -1;
  }
  for (int i = 0; i < this->nrows; i++) {
    for (int j = 0; j < this->ncols; j++) {
      int index = i*this->ncols + j;       /*  Local array is row-major */
      int rindex = j*this->nrows + i;      /* Raw array R is column major */
      R[rindex] =  (this->myArray)[index];
    }
  }
  return 0;
    
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp.getResult)
}


// DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp._misc)
// Insert-Code-Here {arrayOps.NonLinearOp._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp._misc)

