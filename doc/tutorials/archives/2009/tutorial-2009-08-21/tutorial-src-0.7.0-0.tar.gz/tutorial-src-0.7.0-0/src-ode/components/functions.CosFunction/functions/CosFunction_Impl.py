#
# File:          CosFunction_Impl.py
# Symbol:        functions.CosFunction-v0.0
# Symbol Type:   class
# Babel Version: 1.0.8
# Description:   Implementation of sidl class functions.CosFunction in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
#


# DO-NOT-DELETE splicer.begin(_initial)
# DO-NOT-DELETE splicer.end(_initial)

import function.FunctionPort
import functions.CosFunction
import gov.cca.CCAException
import gov.cca.Component
import gov.cca.ComponentRelease
import gov.cca.Port
import gov.cca.Services
import sidl.BaseClass
import sidl.BaseInterface
import sidl.ClassInfo
import sidl.RuntimeException
import sidl.NotImplementedException

# DO-NOT-DELETE splicer.begin(_before_type)
import sys
# DO-NOT-DELETE splicer.end(_before_type)

class CosFunction:

# All calls to sidl methods should use __IORself

# Normal Babel creation pases in an IORself. If IORself == None
# that means this Impl class is being constructed for native delegation
  def __init__(self, IORself = None):
    if (IORself == None):
      self.__IORself = functions.CosFunction.CosFunction(impl = self)
    else:
      self.__IORself = IORself
# DO-NOT-DELETE splicer.begin(__init__)
    # Put your code here...
    # Bocca generated code. bocca.protected.begin(functions.CosFunction._init) 
    self.d_services = None
    self.bocca_print_errs = True
    # Bocca generated code. bocca.protected.end(functions.CosFunction._init) 
    # Put your code here...
# DO-NOT-DELETE splicer.end(__init__)

# Returns the IORself (client stub) of the Impl, mainly for use
# with native delegation
  def _getStub(self):
    return self.__IORself

  def boccaSetServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

# DO-NOT-DELETE splicer.begin(boccaSetServices)
# DO-NOT-EDIT-BOCCA
# Bocca generated code. bocca.protected.begin(boccaSetServices) 
    self.d_services = services
    # Create a typemap
    mymap = services.createTypeMap()
    
    port = gov.cca.Port.Port(self.__IORself)  # CAST 
    if not port:
      ex = sidl.SIDLException.SIDLException()
      ex.setNote(__name__,0, 'Error casting self functions.CosFunction to to gov.cca.Port')
      raise sidl.SIDLException._Exception, ex
    # Provide a function.FunctionPort port with port name function 
    try:
      self.d_services.addProvidesPort(port,    # the implementing object
                              'function',       # the name the user will see
                              'function.FunctionPort',          # the sidl name of the port type.
                              mymap);         # extra properties.
    except sidl.BaseException._Exception, e:
      (etype, eobj, etb) = sys.exc_info()
      eobj.add(__name__, 0, 'Error - could not addProvidesPort(port,"function","function.FunctionPort",mymap)')
      raise sidl.BaseException._Exception, e
    compRelease = gov.cca.ComponentRelease.ComponentRelease(self.__IORself)
    try:
      self.d_services.registerForRelease(compRelease)
    except sidl.BaseException._Exception, e:
      (etype, eobj, etb) = sys.exc_info()
      eobj.exception.add(__name__,0, 'Error - could not registerForRelease(self) in functions.CosFunction')
      raise sidl.BaseException._Exception, e
      
    return
# Bocca generated code. bocca.protected.end(boccaSetServices)
# DO-NOT-DELETE splicer.end(boccaSetServices)

  def boccaReleaseServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

    # DO-NOT-DELETE splicer.begin(boccaReleaseServices)
    # DO-NOT-EDIT-BOCCA
    # Bocca generated code. bocca.protected.begin(functions.CosFunction.boccaReleaseServices)
    self.d_services = None
    # UN-Provide a function.FunctionPort port with port name function 
    try:
      services.removeProvidesPort('function')
    except sidl.BaseException._Exception, e:
      (etype, eobj, etb) = sys.exc_info()
      eobj.exception.add(__name__,0, 'Error - could not remove provided port function.FunctionPort:function')
      raise sidl.BaseException._Exception, e
    return
    # Bocca generated code. bocca.protected.end(functions.CosFunction.boccaReleaseServices)
    # DO-NOT-DELETE splicer.end(boccaReleaseServices)

  def boccaForceUsePortInclude(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

    """\
 This function should never be called, but helps babel generate better code. 
"""
    # DO-NOT-DELETE splicer.begin(boccaForceUsePortInclude)
    # DO-NOT-EDIT-BOCCA
    # Bocca generated code. bocca.protected.begin(boccaForceUsePortInclude)
    return
    # Bocca generated code. bocca.protected.end(boccaForceUsePortInclude)
    # DO-NOT-DELETE splicer.end(boccaForceUsePortInclude)

  def setServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

    """\
 Starts up a component presence in the calling framework.
@param services the component instance's handle on the framework world.
Contracts concerning Svc and setServices:

The component interaction with the CCA framework
and Ports begins on the call to setServices by the framework.

This function is called exactly once for each instance created
by the framework.

The argument Svc will never be nil/null.

Those uses ports which are automatically connected by the framework
(so-called service-ports) may be obtained via getPort during
setServices.
"""
    # DO-NOT-DELETE splicer.begin(setServices)
    # Put your code here... prolog
    # bocca-default-code. User may edit or delete.begin(setServices)
    self.boccaSetServices(services)
    # bocca-default-code. User may edit or delete.end(setServices)
    # Put your code here... epilog
    # DO-NOT-DELETE splicer.end(setServices)

  def releaseServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

    """\
Shuts down a component presence in the calling framework.
@param services the component instance's handle on the framework world.
Contracts concerning Svc and setServices:

This function is called exactly once for each callback registered
through Services.

The argument Svc will never be nil/null.
The argument Svc will always be the same as that received in
setServices.

During this call the component should release any interfaces
acquired by getPort().

During this call the component should reset to nil any stored
reference to Svc.

After this call, the component instance will be removed from the
framework. If the component instance was created by the
framework, it will be destroyed, not recycled, The behavior of
any port references obtained from this component instance and
stored elsewhere becomes undefined.

Notes for the component implementor:
1) The component writer may perform blocking activities
within releaseServices, such as waiting for remote computations
to shutdown.
2) It is good practice during releaseServices for the component
writer to remove or unregister all the ports it defined.
"""
    # DO-NOT-DELETE splicer.begin(releaseServices)
    
    # put your code here ... prolog
    # bocca-default-code. User may edit or delete.begin(releaseServices)
    self.boccaReleaseServices(services)
    # bocca-default-code. User may edit or delete.end(releaseServices)
    # put your code here ... epilog
    # DO-NOT-DELETE splicer.end(releaseServices)

  def init(self, params):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # array<double> params
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

# DO-NOT-DELETE splicer.begin(init)
 
 
 
    # DO-DELETE-WHEN-IMPLEMENTING exception.begin()
    # 
    # This method has not been implemented.
    # 
    noImpl = sidl.NotImplementedException.NotImplementedException()
    noImpl.setNote("This method has not been implmented.")
    raise  sidl.NotImplementedException._Exception, noImpl
    # DO-DELETE-WHEN-IMPLEMENTING exception.end()
 
# DO-NOT-DELETE splicer.end(init)

  def evaluate(self, x):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # double x
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # double _return
    #

# DO-NOT-DELETE splicer.begin(evaluate)
 
 
 
    import math
    return math.cos(x)
 
# DO-NOT-DELETE splicer.end(evaluate)

# DO-NOT-DELETE splicer.begin(_final)
# DO-NOT-DELETE splicer.end(_final)
