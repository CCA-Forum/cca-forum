// 
// File:          arrayOps_NonLinearOp_Impl.hxx
// Symbol:        arrayOps.NonLinearOp-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for arrayOps.NonLinearOp
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_arrayOps_NonLinearOp_Impl_hxx
#define included_arrayOps_NonLinearOp_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_arrayOps_NonLinearOp_IOR_h
#include "arrayOps_NonLinearOp_IOR.h"
#endif
#ifndef included_arrayOps_NonLinearOp_hxx
#include "arrayOps_NonLinearOp.hxx"
#endif
#ifndef included_arrayop_NonLinearOp_hxx
#include "arrayop_NonLinearOp.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Component_hxx
#include "gov_cca_Component.hxx"
#endif
#ifndef included_gov_cca_ComponentRelease_hxx
#include "gov_cca_ComponentRelease.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif


// DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp._hincludes)
// Insert-Code-Here {arrayOps.NonLinearOp._hincludes} (includes or arbitrary code)
// DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp._hincludes)

namespace arrayOps { 

  /**
   * Symbol "arrayOps.NonLinearOp" (version 0.0)
   */
  class NonLinearOp_impl : public virtual ::arrayOps::NonLinearOp 
  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp._inherits)
  // Insert-Code-Here {arrayOps.NonLinearOp._inherits} (optional inheritance here)
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

  // DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp._implementation)
  // Insert-UserCode-Here(arrayOps.NonLinearOp._implementation)
  // Bocca generated code. bocca.protected.begin(arrayOps.NonLinearOp._implementation)
  
   gov::cca::Services    d_services; // our cca handle.
 
  // Bocca generated code. bocca.protected.end(arrayOps.NonLinearOp._implementation)
    int    nrows;
    int    ncols;
    double *myArray;
    
  // DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp._implementation)

  public:
    // default constructor, used for data wrapping(required)
    NonLinearOp_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    NonLinearOp_impl( struct arrayOps_NonLinearOp__object * s ) : StubBase(s,
      true), _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~NonLinearOp_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    void
    boccaSetServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;

    /**
     * user defined non-static method.
     */
    void
    boccaReleaseServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;


    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude_impl() ;

    /**
     *  Starts up a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning Svc and setServices:
     * 
     * The component interaction with the CCA framework
     * and Ports begins on the call to setServices by the framework.
     * 
     * This function is called exactly once for each instance created
     * by the framework.
     * 
     * The argument Svc will never be nil/null.
     * 
     * Those uses ports which are automatically connected by the framework
     * (so-called service-ports) may be obtained via getPort during
     * setServices.
     */
    void
    setServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;


    /**
     * Shuts down a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning Svc and setServices:
     * 
     * This function is called exactly once for each callback registered
     * through Services.
     * 
     * The argument Svc will never be nil/null.
     * The argument Svc will always be the same as that received in
     * setServices.
     * 
     * During this call the component should release any interfaces
     * acquired by getPort().
     * 
     * During this call the component should reset to nil any stored
     * reference to Svc.
     * 
     * After this call, the component instance will be removed from the
     * framework. If the component instance was created by the
     * framework, it will be destroyed, not recycled, The behavior of
     * any port references obtained from this component instance and
     * stored elsewhere becomes undefined.
     * 
     * Notes for the component implementor:
     * 1) The component writer may perform blocking activities
     * within releaseServices, such as waiting for remote computations
     * to shutdown.
     * 2) It is good practice during releaseServices for the component
     * writer to remove or unregister all the ports it defined.
     */
    void
    releaseServices_impl (
      /* in */::gov::cca::Services services
    )
    // throws:
    //     ::gov::cca::CCAException
    //     ::sidl::RuntimeException
    ;

    /**
     * user defined non-static method.
     */
    void
    init_impl() ;
    /**
     * user defined non-static method.
     */
    int32_t
    logMat_impl (
      /* in */double alpha,
      /* in rarray[m,n] */double* A,
      /* inout rarray[m,n] */double* R,
      /* in */int32_t m,
      /* in */int32_t n
    )
    ;

    /**
     * user defined non-static method.
     */
    int32_t
    mulMatMat_impl (
      /* in */double beta,
      /* in array<double,2> */::sidl::array<double> A,
      /* in array<double,2> */::sidl::array<double> M,
      /* inout array<double,2> */::sidl::array<double>& R
    )
    ;

    /**
     * user defined non-static method.
     */
    int32_t
    getResult_impl (
      /* inout rarray[m,n] */double* R,
      /* in */int32_t m,
      /* in */int32_t n
    )
    ;

  };  // end class NonLinearOp_impl

} // end namespace arrayOps

// DO-NOT-DELETE splicer.begin(arrayOps.NonLinearOp._hmisc)
// Insert-Code-Here {arrayOps.NonLinearOp._hmisc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(arrayOps.NonLinearOp._hmisc)

#endif
