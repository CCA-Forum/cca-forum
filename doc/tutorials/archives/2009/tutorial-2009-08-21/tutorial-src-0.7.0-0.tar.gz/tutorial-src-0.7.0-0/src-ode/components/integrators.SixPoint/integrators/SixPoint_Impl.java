/*
 * File:          SixPoint_Impl.java
 * Symbol:        integrators.SixPoint-v0.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for integrators.SixPoint
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package integrators;

import function.FunctionPort;
import gov.cca.CCAException;
import gov.cca.Component;
import gov.cca.ComponentRelease;
import gov.cca.Port;
import gov.cca.Services;
import integrator.IntegratorPort;
import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;

// DO-NOT-DELETE splicer.begin(integrators.SixPoint._imports)
// DO-NOT-DELETE splicer.end(integrators.SixPoint._imports)

/**
 * Symbol "integrators.SixPoint" (version 0.0)
 */
public class SixPoint_Impl extends SixPoint
{

   // DO-NOT-DELETE splicer.begin(integrators.SixPoint._data)
   // Bocca generated code. bocca.protected.begin(integrators.SixPoint._data)
    gov.cca.Services    d_services;
    public boolean bocca_print_errs = true;
   // Bocca generated code. bocca.protected.end(integrators.SixPoint._data)
    // DO-NOT-DELETE splicer.end(integrators.SixPoint._data)

  static { 
  // DO-NOT-DELETE splicer.begin(integrators.SixPoint._load)
  // DO-NOT-DELETE splicer.end(integrators.SixPoint._load)
  }

  /**
   * User defined constructor
   */
  public SixPoint_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(integrators.SixPoint.SixPoint)
    // DO-NOT-DELETE splicer.end(integrators.SixPoint.SixPoint)
  }

  /**
   * Back door constructor
   */
  public SixPoint_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(integrators.SixPoint._wrap)
    // DO-NOT-DELETE splicer.end(integrators.SixPoint._wrap)
  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(integrators.SixPoint._dtor)
    // Insert-Code-Here {integrators.SixPoint._dtor} (destructor)
    // DO-NOT-DELETE splicer.end(integrators.SixPoint._dtor)
  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(integrators.SixPoint.finalize)
    // DO-NOT-DELETE splicer.end(integrators.SixPoint.finalize)
  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  boccaSetServices[]
   */
  public void boccaSetServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
// DO-NOT-DELETE splicer.begin(integrators.SixPoint.boccaSetServices)
// DO-NOT-EDIT-BOCCA
// Bocca generated code. bocca.protected.begin(integrators.SixPoint.boccaSetServices)
   gov.cca.TypeMap typeMap;
   gov.cca.Port    port;
   this.d_services = services;
   typeMap = this.d_services.createTypeMap();
   port = (gov.cca.Port)(this);
  // Provide a integrator.IntegratorPort port with port name integrate 
   try{
      this.d_services.addProvidesPort(port, // the implementing object
                                      "integrate", // the name the user sees
                                      "integrator.IntegratorPort", // the sidl name of the port type
                                      typeMap); // extra properties
   } catch ( gov.cca.CCAException.Wrapper ex )  {
      String msg = "Error calling addProvidesPort(port,\"integrate\", \"integrator.IntegratorPort\", typeMap) ";
      ex.add(msg);
      throw ex;
   }    
  // Use a function.FunctionPort port with port name function 
   try{
      this.d_services.registerUsesPort("function", // name the user sees
                                       "function.FunctionPort", // sidl name of the port type
                                       typeMap); // extra properties
   } catch ( gov.cca.CCAException.Wrapper ex )  {
      String msg = "Error calling registerUsesPort(\"function\", \"function.FunctionPort\", typeMap) ";
      ex.add(msg);
      throw ex;
   }
   gov.cca.ComponentRelease cr = (gov.cca.ComponentRelease)this; // CAST
   this.d_services.registerForRelease(cr);
   return;
// Bocca generated code. bocca.protected.end(integrators.SixPoint.boccaSetServices)
// DO-NOT-DELETE splicer.end(integrators.SixPoint.boccaSetServices)
  }

  /**
   * Method:  boccaReleaseServices[]
   */
  public void boccaReleaseServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
  // DO-NOT-DELETE splicer.begin(integrators.SixPoint.boccaReleaseServices)
  // Bocca generated code. bocca.protected.begin(integrators.SixPoint.boccaReleaseServices)
   this.d_services=null;
  // Un-provide integrator.IntegratorPort port with port name integrate 
  try{
    services.removeProvidesPort("integrate");
  } catch ( gov.cca.CCAException.Wrapper ex )  {
    if (bocca_print_errs) {
      System.err.print("integrators.SixPoint: Error calling removeProvidesPort(\"integrate\"): " +ex.getNote());
    }
  }
  // Release function.FunctionPort port with port name function 
  try{
    services.unregisterUsesPort("function");
  } catch ( gov.cca.CCAException.Wrapper ex )  {
    if (bocca_print_errs) {
      System.err.println("integrators.SixPoint: Error calling unregisterUsesPort(\"function\"): " +ex.getNote());
    }
  }
   return;
  // Bocca generated code. bocca.protected.end(integrators.SixPoint.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(integrators.SixPoint.boccaReleaseServices)
  }

  /**
   *  This function should never be called, but helps babel generate better code. 
   */
  public void boccaForceUsePortInclude_Impl (
    /*in*/ function.FunctionPort dummy0 ) 
    throws sidl.RuntimeException.Wrapper
  {
  // DO-NOT-DELETE splicer.begin(integrators.SixPoint.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(integrators.SixPoint.boccaForceUsePortInclude)
    Object o;
    o = dummy0;
  // Bocca generated code. bocca.protected.end(integrators.SixPoint.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(integrators.SixPoint.boccaForceUsePortInclude)
  }

  /**
   *  Starts up a component presence in the calling framework.
   * @param services the component instance's handle on the framework world.
   * Contracts concerning Svc and setServices:
   * 
   * The component interaction with the CCA framework
   * and Ports begins on the call to setServices by the framework.
   * 
   * This function is called exactly once for each instance created
   * by the framework.
   * 
   * The argument Svc will never be nil/null.
   * 
   * Those uses ports which are automatically connected by the framework
   * (so-called service-ports) may be obtained via getPort during
   * setServices.
   */
  public void setServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
  // DO-NOT-DELETE splicer.begin(integrators.SixPoint.setServices)
  // Insert-Code-Here {integrators.SixPoint.setServices} (setServices method prolog)
  // bocca-default-code. User may edit or delete.begin(integrators.SixPoint.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(integrators.SixPoint.setServices)
  // Insert-Code-Here {integrators.SixPoint.setServices} (setServices method epilog)
  // DO-NOT-DELETE splicer.end(integrators.SixPoint.setServices)
  }

  /**
   * Shuts down a component presence in the calling framework.
   * @param services the component instance's handle on the framework world.
   * Contracts concerning Svc and setServices:
   * 
   * This function is called exactly once for each callback registered
   * through Services.
   * 
   * The argument Svc will never be nil/null.
   * The argument Svc will always be the same as that received in
   * setServices.
   * 
   * During this call the component should release any interfaces
   * acquired by getPort().
   * 
   * During this call the component should reset to nil any stored
   * reference to Svc.
   * 
   * After this call, the component instance will be removed from the
   * framework. If the component instance was created by the
   * framework, it will be destroyed, not recycled, The behavior of
   * any port references obtained from this component instance and
   * stored elsewhere becomes undefined.
   * 
   * Notes for the component implementor:
   * 1) The component writer may perform blocking activities
   * within releaseServices, such as waiting for remote computations
   * to shutdown.
   * 2) It is good practice during releaseServices for the component
   * writer to remove or unregister all the ports it defined.
   */
  public void releaseServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
  // DO-NOT-DELETE splicer.begin(integrators.SixPoint.releaseServices)
  // Insert-Code-Here {integrators.SixPoint.releaseServices} (releaseServices method prolog)
  // bocca-default-code. User may edit or delete.end(integrators.SixPoint.releaseServices)
     boccaReleaseServices(services); 
  // bocca-default-code. User may edit or delete.end(integrators.SixPoint.releaseServices)
  // Insert-Code-Here {integrators.SixPoint.releaseServices} (releaseServices method epilog)
  // DO-NOT-DELETE splicer.end(integrators.SixPoint.releaseServices)
  }

  /**
   * Integrate numerically.
   * @param lowBound the start of the range to integrate f(x) where x is scalar.
   * @param upBound the end of the range to integrate.
   * @param count the number of times to apply the integration rule within the range.
   * @return integral from lowBound to upBound using count intervals of some quadrature.
   * @throws CCAException or SidlRuntimeException when no proper function port is available.
   */
  public double integrate_Impl (
    /*in*/ double lowBound,
    /*in*/ double upBound,
    /*in*/ int count ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(integrators.SixPoint.integrate)
 
 
    int NPTS=6;
    double multiplier[] = { 19, 75, 50, 50, 75, 19};
    double coef = 5.0/288.0;
    gov.cca.Port port = d_services.getPort("function");
    // port is never None according to the cca spec or we would be handling an exception
    // but the cast can still fail if someone lied to the framework.
    function.FunctionPort funport = (function.FunctionPort) port._cast2("function.FunctionPort");
    if (funport == null) {
      // If the framework does it's job right, this never happens.
      sidl.SIDLException ex = new sidl.SIDLException();
      ex.setNote("SixPoint connected to a lying component");
      ex.add("SixPoint.integrate" , 0, "Function port not properly connected.");
      sidl.RuntimeException.Wrapper rex = (sidl.RuntimeException.Wrapper)sidl.RuntimeException.Wrapper._cast(ex);
      throw rex;
    }
    double dx = (upBound - lowBound) / count;
    double h = dx / (NPTS - 1);
    int j = 0;
    double sum = 0.0;
    while (j < count) {
      double start = lowBound +  dx * j;
      int i = 0;
      while (i < NPTS) {
        double x =  start + h*i;
        double temp = funport.evaluate(x);
        sum += multiplier[i] * temp;
        i += 1;
      }
      j += 1;
    }
    double retval = sum * h * coef;
    d_services.releasePort("function");
    return retval;
 
    // DO-NOT-DELETE splicer.end(integrators.SixPoint.integrate)
  }


  // DO-NOT-DELETE splicer.begin(integrators.SixPoint._misc)
  // DO-NOT-DELETE splicer.end(integrators.SixPoint._misc)

} // end class SixPoint

