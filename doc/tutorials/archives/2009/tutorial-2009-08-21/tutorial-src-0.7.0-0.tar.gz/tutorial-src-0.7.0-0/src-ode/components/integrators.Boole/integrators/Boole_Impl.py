#
# File:          Boole_Impl.py
# Symbol:        integrators.Boole-v0.0
# Symbol Type:   class
# Babel Version: 1.0.8
# Description:   Implementation of sidl class integrators.Boole in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
#


# DO-NOT-DELETE splicer.begin(_initial)
# DO-NOT-DELETE splicer.end(_initial)

import function.FunctionPort
import gov.cca.CCAException
import gov.cca.Component
import gov.cca.ComponentRelease
import gov.cca.Port
import gov.cca.Services
import integrator.IntegratorPort
import integrators.Boole
import sidl.BaseClass
import sidl.BaseInterface
import sidl.ClassInfo
import sidl.RuntimeException
import sidl.NotImplementedException

# DO-NOT-DELETE splicer.begin(_before_type)
import sys
# DO-NOT-DELETE splicer.end(_before_type)

class Boole:

# All calls to sidl methods should use __IORself

# Normal Babel creation pases in an IORself. If IORself == None
# that means this Impl class is being constructed for native delegation
  def __init__(self, IORself = None):
    if (IORself == None):
      self.__IORself = integrators.Boole.Boole(impl = self)
    else:
      self.__IORself = IORself
# DO-NOT-DELETE splicer.begin(__init__)
    # Put your code here...
    # Bocca generated code. bocca.protected.begin(integrators.Boole._init) 
    self.d_services = None
    self.bocca_print_errs = True
    # Bocca generated code. bocca.protected.end(integrators.Boole._init) 
    # Put your code here...
# DO-NOT-DELETE splicer.end(__init__)

# Returns the IORself (client stub) of the Impl, mainly for use
# with native delegation
  def _getStub(self):
    return self.__IORself

  def boccaSetServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

# DO-NOT-DELETE splicer.begin(boccaSetServices)
# DO-NOT-EDIT-BOCCA
# Bocca generated code. bocca.protected.begin(boccaSetServices) 
    self.d_services = services
    # Create a typemap
    mymap = services.createTypeMap()
    
    port = gov.cca.Port.Port(self.__IORself)  # CAST 
    if not port:
      ex = sidl.SIDLException.SIDLException()
      ex.setNote(__name__,0, 'Error casting self integrators.Boole to to gov.cca.Port')
      raise sidl.SIDLException._Exception, ex
    # Provide a integrator.IntegratorPort port with port name integrate 
    try:
      self.d_services.addProvidesPort(port,    # the implementing object
                              'integrate',       # the name the user will see
                              'integrator.IntegratorPort',          # the sidl name of the port type.
                              mymap);         # extra properties.
    except sidl.BaseException._Exception, e:
      (etype, eobj, etb) = sys.exc_info()
      eobj.add(__name__, 0, 'Error - could not addProvidesPort(port,"integrate","integrator.IntegratorPort",mymap)')
      raise sidl.BaseException._Exception, e
    # Register a use port of type function.FunctionPort with port name function
    try:
      self.d_services.registerUsesPort('function',   # the name the user will see
                                'function.FunctionPort',     # the sidl name of the port type.
                                mymap);       # extra properties.
    except sidl.BaseException._Exception, e:
      (etype, eobj, etb) = sys.exc_info()
      eobj.add(__name__, 0, 'Error - could not registerUsesPort("function","function.FunctionPort",mymap)')
      raise sidl.BaseException._Exception, e
    compRelease = gov.cca.ComponentRelease.ComponentRelease(self.__IORself)
    try:
      self.d_services.registerForRelease(compRelease)
    except sidl.BaseException._Exception, e:
      (etype, eobj, etb) = sys.exc_info()
      eobj.exception.add(__name__,0, 'Error - could not registerForRelease(self) in integrators.Boole')
      raise sidl.BaseException._Exception, e
      
    return
# Bocca generated code. bocca.protected.end(boccaSetServices)
# DO-NOT-DELETE splicer.end(boccaSetServices)

  def boccaReleaseServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

    # DO-NOT-DELETE splicer.begin(boccaReleaseServices)
    # DO-NOT-EDIT-BOCCA
    # Bocca generated code. bocca.protected.begin(integrators.Boole.boccaReleaseServices)
    self.d_services = None
    # UN-Provide a integrator.IntegratorPort port with port name integrate 
    try:
      services.removeProvidesPort('integrate')
    except sidl.BaseException._Exception, e:
      (etype, eobj, etb) = sys.exc_info()
      eobj.exception.add(__name__,0, 'Error - could not remove provided port integrator.IntegratorPort:integrate')
      raise sidl.BaseException._Exception, e
    # Un-Register a use port of type function.FunctionPort with port name function
    try:
      services.unregisterUsesPort('function')
    except sidl.BaseException._Exception, e:
      (etype, eobj, etb) = sys.exc_info()
      eobj.exception.add(__name__,0, 'Error - could not unregisterUsesPort("function")')
      raise sidl.BaseException._Exception, e
    return
    # Bocca generated code. bocca.protected.end(integrators.Boole.boccaReleaseServices)
    # DO-NOT-DELETE splicer.end(boccaReleaseServices)

  def boccaForceUsePortInclude(self, dummy0):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # function.FunctionPort dummy0
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

    """\
 This function should never be called, but helps babel generate better code. 
"""
    # DO-NOT-DELETE splicer.begin(boccaForceUsePortInclude)
    # DO-NOT-EDIT-BOCCA
    # Bocca generated code. bocca.protected.begin(boccaForceUsePortInclude)
    o0 = dummy0
    return
    # Bocca generated code. bocca.protected.end(boccaForceUsePortInclude)
    # DO-NOT-DELETE splicer.end(boccaForceUsePortInclude)

  def setServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

    """\
 Starts up a component presence in the calling framework.
@param services the component instance's handle on the framework world.
Contracts concerning Svc and setServices:

The component interaction with the CCA framework
and Ports begins on the call to setServices by the framework.

This function is called exactly once for each instance created
by the framework.

The argument Svc will never be nil/null.

Those uses ports which are automatically connected by the framework
(so-called service-ports) may be obtained via getPort during
setServices.
"""
    # DO-NOT-DELETE splicer.begin(setServices)
    # Put your code here... prolog
    # bocca-default-code. User may edit or delete.begin(setServices)
    self.boccaSetServices(services)
    # bocca-default-code. User may edit or delete.end(setServices)
    # Put your code here... epilog
    # DO-NOT-DELETE splicer.end(setServices)

  def releaseServices(self, services):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # gov.cca.Services services
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

    """\
Shuts down a component presence in the calling framework.
@param services the component instance's handle on the framework world.
Contracts concerning Svc and setServices:

This function is called exactly once for each callback registered
through Services.

The argument Svc will never be nil/null.
The argument Svc will always be the same as that received in
setServices.

During this call the component should release any interfaces
acquired by getPort().

During this call the component should reset to nil any stored
reference to Svc.

After this call, the component instance will be removed from the
framework. If the component instance was created by the
framework, it will be destroyed, not recycled, The behavior of
any port references obtained from this component instance and
stored elsewhere becomes undefined.

Notes for the component implementor:
1) The component writer may perform blocking activities
within releaseServices, such as waiting for remote computations
to shutdown.
2) It is good practice during releaseServices for the component
writer to remove or unregister all the ports it defined.
"""
    # DO-NOT-DELETE splicer.begin(releaseServices)
    
    # put your code here ... prolog
    # bocca-default-code. User may edit or delete.begin(releaseServices)
    self.boccaReleaseServices(services)
    # bocca-default-code. User may edit or delete.end(releaseServices)
    # put your code here ... epilog
    # DO-NOT-DELETE splicer.end(releaseServices)

  def integrate(self, lowBound, upBound, count):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # double lowBound
    # double upBound
    # int count
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # double _return
    #

    """\
Integrate numerically.
@param lowBound the start of the range to integrate f(x) where x is scalar.
@param upBound the end of the range to integrate.
@param count the number of times to apply the integration rule within the range.
@return integral from lowBound to upBound using count intervals of some quadrature.
@throws CCAException or SidlRuntimeException when no proper function port is available.
"""
# DO-NOT-DELETE splicer.begin(integrate)
 
 
    NPTS=5
    multiplier = [ 7, 32, 12, 32, 7 ]
    coef = 2.0/45.0
    port = self.d_services.getPort("function")
    # port is never None according to the cca spec or we would be handling an exception
    funport = function.FunctionPort.FunctionPort(port);
    if not funport:
      # If the framework does it's job right, this never happens.
      ex = sidl.SIDLException.SIDLException()
      ex.setNote("Boole connected to a lying component")
      ex.add(__name__, 0, "Function port not properly connected.")
      raise sidl.SIDLException.SIDLException._Exception, ex
    count = 1
    dx = (upBound - lowBound) / count
    h = dx / (NPTS - 1)
    j = 0
    sum = 0.0
    while j < count:
      start = lowBound +  dx * j
      i = 0
      while i < NPTS:
        x =  start + h*i
        temp = funport.evaluate(x)
        sum += multiplier[i] * temp
        i += 1
      j += 1
    retval = sum * coef * h
    self.d_services.releasePort("function")
    return retval
 
# DO-NOT-DELETE splicer.end(integrate)

# DO-NOT-DELETE splicer.begin(_final)
# DO-NOT-DELETE splicer.end(_final)
