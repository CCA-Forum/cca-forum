#ifndef rootfind_h_seen
#define rootfind_h_seen

#ifdef cplusplus
extern "C" {
#endif

/* A continuous function in one variable.
  status = searchFunction(x, f_x);
  @param x the variable input.
  @param f_x the function value output.
  @return status 0 if evaluation is ok, -1 if x given is invalid.
 */
typedef int(*searchFunction)(double x, double* value_addr);

extern int rootfind(searchFunction f, double tolerance, double xguess, double xlow, double xhigh, int maxit, double* xout_addr, double* errout_addr, int* fcount_addr);

#ifdef cplusplus
}
#endif
#endif /* rootfind_h_seen*/
