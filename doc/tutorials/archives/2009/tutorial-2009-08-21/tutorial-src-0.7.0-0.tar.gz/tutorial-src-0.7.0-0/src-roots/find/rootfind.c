#include "rootfind.h"

int simplefunc(double x, double* value)
{
	*value = 2*x*x - 4; /* +/- sqrt 2 */
}

int rootfind(searchFunction f, double tolerance, double xguess, double xlow, double xhigh, int maxit, double* xout, double* errout, int* fcount)
{
	#define EVAL(x,val) status = f(x, &(val)); (*fcount)++; if (status!=0) return status
	double vlow, vhigh, vguess;
	int status=0, icount=0;
	EVAL(xlow,vlow);
	EVAL(xhigh,vhigh);
	*xout = xguess;

	// fixme
        EVAL(xguess,*errout);

	return status;
	#undef EVAL
}

#include <stdio.h>
int main(int argc, char **argv)
{
	double xout=2.718, errout=2.718;
	int fcount = 0;
	rootfind(simplefunc, 0.1, 1.0, 0.0, 2.0, 5, &xout, &errout, &fcount);
	printf("root is: %g, fcount is %d, err=%g\n",xout, fcount, errout);
	return 0;
}
