/*
 * File:          funcwrap_SearchFuncC_Impl.c
 * Symbol:        funcwrap.SearchFuncC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for funcwrap.SearchFuncC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "funcwrap.SearchFuncC" (version 0.0)
 */

#include "funcwrap_SearchFuncC_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"

/* DO-NOT-DELETE splicer.begin(funcwrap.SearchFuncC._includes) */
/* Insert-Code-Here {funcwrap.SearchFuncC._includes} (includes and arbitrary code) */
/* DO-NOT-DELETE splicer.end(funcwrap.SearchFuncC._includes) */

#define SIDL_IOR_MAJOR_VERSION 1
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_funcwrap_SearchFuncC__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_funcwrap_SearchFuncC__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(funcwrap.SearchFuncC._load) */
    /* Insert-Code-Here {funcwrap.SearchFuncC._load} (static class initializer method) */
    
    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin() */
    /* 
     * This method has not been implemented.
     */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end() */
    
    /* DO-NOT-DELETE splicer.end(funcwrap.SearchFuncC._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_funcwrap_SearchFuncC__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_funcwrap_SearchFuncC__ctor(
  /* in */ funcwrap_SearchFuncC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(funcwrap.SearchFuncC._ctor) */
    struct funcwrap_SearchFuncC__data *dptr = (struct funcwrap_SearchFuncC__data*)malloc(sizeof(struct funcwrap_SearchFuncC__data));
    if (dptr) {
      dptr->f = NULL;
    }
    funcwrap_SearchFuncC__set_data(self, dptr);
    /* DO-NOT-DELETE splicer.end(funcwrap.SearchFuncC._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_funcwrap_SearchFuncC__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_funcwrap_SearchFuncC__ctor2(
  /* in */ funcwrap_SearchFuncC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(funcwrap.SearchFuncC._ctor2) */
    /* Insert-Code-Here {funcwrap.SearchFuncC._ctor2} (special constructor method) */
    
    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin() */
    /* 
     * This method has not been implemented.
     */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end() */
    
    /* DO-NOT-DELETE splicer.end(funcwrap.SearchFuncC._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_funcwrap_SearchFuncC__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_funcwrap_SearchFuncC__dtor(
  /* in */ funcwrap_SearchFuncC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(funcwrap.SearchFuncC._dtor) */
    /* Insert-Code-Here {funcwrap.SearchFuncC._dtor} (destructor method) */
    /*
     * // boilerplate destructor
     * struct funcwrap_SearchFuncC__data *dptr = funcwrap_SearchFuncC__get_data(self);
     * if (dptr) {
     *   // free contained in dtor before next line
     *   free(dptr);
     *   funcwrap_SearchFuncC__set_data(self, NULL);
     * }
     */

    /* DO-NOT-DELETE splicer.end(funcwrap.SearchFuncC._dtor) */
  }
}

/*
 * Method:  setFPointer[]
 */

#undef __FUNC__
#define __FUNC__ "impl_funcwrap_SearchFuncC_setFPointer"

#ifdef __cplusplus
extern "C"
#endif
void
impl_funcwrap_SearchFuncC_setFPointer(
  /* in */ funcwrap_SearchFuncC self,
  /* in */ void* cfunc,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(funcwrap.SearchFuncC.setFPointer) */
    struct funcwrap_SearchFuncC__data *pd;
    pd = funcwrap_SearchFuncC__get_data(self);
    pd->f = cfunc;
    /* DO-NOT-DELETE splicer.end(funcwrap.SearchFuncC.setFPointer) */
  }
}

/*
 * Method:  getFPointer[]
 */

#undef __FUNC__
#define __FUNC__ "impl_funcwrap_SearchFuncC_getFPointer"

#ifdef __cplusplus
extern "C"
#endif
void*
impl_funcwrap_SearchFuncC_getFPointer(
  /* in */ funcwrap_SearchFuncC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(funcwrap.SearchFuncC.getFPointer) */
    struct funcwrap_SearchFuncC__data *pd;
    pd = funcwrap_SearchFuncC__get_data(self);
    return pd->f;
    
    /* DO-NOT-DELETE splicer.end(funcwrap.SearchFuncC.getFPointer) */
  }
}

/*
 * Method:  eval[]
 */

#undef __FUNC__
#define __FUNC__ "impl_funcwrap_SearchFuncC_eval"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_funcwrap_SearchFuncC_eval(
  /* in */ funcwrap_SearchFuncC self,
  /* in */ double x,
  /* out */ double* value,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(funcwrap.SearchFuncC.eval) */
    struct funcwrap_SearchFuncC__data *pd;
    pd = funcwrap_SearchFuncC__get_data(self);
    return pd->f(x, value);
    /* DO-NOT-DELETE splicer.end(funcwrap.SearchFuncC.eval) */
  }
}
/* Babel internal methods, Users should not edit below this line. */
struct funcwrap_SearchFuncC__object* 
  impl_funcwrap_SearchFuncC_fconnect_funcwrap_SearchFuncC(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return funcwrap_SearchFuncC__connectI(url, ar, _ex);
}
struct funcwrap_SearchFuncC__object* 
  impl_funcwrap_SearchFuncC_fcast_funcwrap_SearchFuncC(void* bi, 
  sidl_BaseInterface* _ex) {
  return funcwrap_SearchFuncC__cast(bi, _ex);
}
struct funcwrap_SearchFunction__object* 
  impl_funcwrap_SearchFuncC_fconnect_funcwrap_SearchFunction(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return funcwrap_SearchFunction__connectI(url, ar, _ex);
}
struct funcwrap_SearchFunction__object* 
  impl_funcwrap_SearchFuncC_fcast_funcwrap_SearchFunction(void* bi, 
  sidl_BaseInterface* _ex) {
  return funcwrap_SearchFunction__cast(bi, _ex);
}
struct sidl_BaseClass__object* 
  impl_funcwrap_SearchFuncC_fconnect_sidl_BaseClass(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connectI(url, ar, _ex);
}
struct sidl_BaseClass__object* impl_funcwrap_SearchFuncC_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex) {
  return sidl_BaseClass__cast(bi, _ex);
}
struct sidl_BaseInterface__object* 
  impl_funcwrap_SearchFuncC_fconnect_sidl_BaseInterface(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connectI(url, ar, _ex);
}
struct sidl_BaseInterface__object* 
  impl_funcwrap_SearchFuncC_fcast_sidl_BaseInterface(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_BaseInterface__cast(bi, _ex);
}
struct sidl_ClassInfo__object* 
  impl_funcwrap_SearchFuncC_fconnect_sidl_ClassInfo(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connectI(url, ar, _ex);
}
struct sidl_ClassInfo__object* impl_funcwrap_SearchFuncC_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex) {
  return sidl_ClassInfo__cast(bi, _ex);
}
struct sidl_RuntimeException__object* 
  impl_funcwrap_SearchFuncC_fconnect_sidl_RuntimeException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_RuntimeException__connectI(url, ar, _ex);
}
struct sidl_RuntimeException__object* 
  impl_funcwrap_SearchFuncC_fcast_sidl_RuntimeException(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_RuntimeException__cast(bi, _ex);
}
