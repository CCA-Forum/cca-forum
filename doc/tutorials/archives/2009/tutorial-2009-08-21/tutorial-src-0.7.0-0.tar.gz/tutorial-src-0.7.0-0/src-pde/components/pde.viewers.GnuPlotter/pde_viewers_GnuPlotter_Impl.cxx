// 
// File:	  pde_viewers_GnuPlotter_Impl.cxx
// Symbol:	pde.viewers.GnuPlotter-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.viewers.GnuPlotter
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_viewers_GnuPlotter_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_bsl_arr_hxx
#include "bsl_arr.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_ParameterPortFactory_hxx
#include "gov_cca_ports_ParameterPortFactory.hxx"
#endif
#ifndef included_pde_FieldVar_hxx
#include "pde_FieldVar.hxx"
#endif
#ifndef included_pde_Mesh_hxx
#include "pde_Mesh.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter._includes)

  // Insert-UserCode-Here {pde.viewers.GnuPlotter._includes:prolog} (additional includes or code)
#include <fstream>

  // Bocca generated code. bocca.protected.begin(pde.viewers.GnuPlotter._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.viewers.GnuPlotter._includes)

  // Insert-UserCode-Here {pde.viewers.GnuPlotter._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::viewers::GnuPlotter_impl::GnuPlotter_impl() : StubBase(reinterpret_cast< 
  void*>(::pde::viewers::GnuPlotter::_wrapObj(reinterpret_cast< void*>(this))),
  false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter._ctor2)
  // Insert-Code-Here {pde.viewers.GnuPlotter._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter._ctor2)
}

// user defined constructor
void pde::viewers::GnuPlotter_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter._ctor)
    
  // Insert-UserCode-Here {pde.viewers.GnuPlotter._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(pde.viewers.GnuPlotter._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.viewers.GnuPlotter: " << BOOST_CURRENT_FUNCTION 
	       << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.viewers.GnuPlotter._ctor)

  // Insert-UserCode-Here {pde.viewers.GnuPlotter._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter._ctor)
}

// user defined destructor
void pde::viewers::GnuPlotter_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter._dtor)
  // Insert-UserCode-Here {pde.viewers.GnuPlotter._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.viewers.GnuPlotter._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.viewers.GnuPlotter: " << BOOST_CURRENT_FUNCTION 
	       << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.viewers.GnuPlotter._dtor) 

  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter._dtor)
}

// static class initializer
void pde::viewers::GnuPlotter_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter._load)
  // Insert-Code-Here {pde.viewers.GnuPlotter._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
pde::viewers::GnuPlotter_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.viewers.GnuPlotter.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
		     "pde.viewers.GnuPlotter: Error casting self to gov::cca::Port");
  } 


  // Provide a pde.RenderPort port with port name printer 
  try{
    this->d_services.addProvidesPort(
		   port,	      // implementing object
		   "printer", // port instance name
		   "pde.RenderPort",     // full sidl type of port
		   typeMap);	  // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
	"pde.viewers.GnuPlotter: Error calling addProvidesPort(port,"
	"\"printer\", \"pde.RenderPort\", typeMap) ", -2);
    throw;
  }    

  // Use a gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    this->d_services.registerUsesPort(
		   "ppf", // port instance name
		   "gov.cca.ports.ParameterPortFactory",     // full sidl type of port
		    typeMap);	 // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.viewers.GnuPlotter: Error calling registerUsesPort(\"ppf\", "
       "\"gov.cca.ports.ParameterPortFactory\", typeMap) ", -2);
    throw;
  }


  gov::cca::ComponentRelease cr = 
	::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(pde.viewers.GnuPlotter.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
pde::viewers::GnuPlotter_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.viewers.GnuPlotter.boccaReleaseServices)
  this->d_services=0;


  // Un-provide pde.RenderPort port with port name printer 
  try{
    services.removeProvidesPort("printer");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.viewers.GnuPlotter: Error calling removeProvidesPort("
	      << "\"printer\") at " 
	      << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
	      << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    services.unregisterUsesPort("ppf");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.viewers.GnuPlotter: Error calling unregisterUsesPort("
	      << "\"ppf\") at " 
	      << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
	      << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(pde.viewers.GnuPlotter.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::viewers::GnuPlotter_impl::boccaForceUsePortInclude_impl (
  /* in */::gov::cca::ports::ParameterPortFactory dummy0,
  /* in */::bsl::arr dummy1 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.viewers.GnuPlotter.boccaForceUsePortInclude)
    (void)dummy0;
    (void)dummy1;

  // Bocca generated code. bocca.protected.end(pde.viewers.GnuPlotter.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
pde::viewers::GnuPlotter_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter.setServices)

  // Insert-UserCode-Here{pde.viewers.GnuPlotter.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(pde.viewers.GnuPlotter.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(pde.viewers.GnuPlotter.setServices)
  
  // Insert-UserCode-Here{pde.viewers.GnuPlotter.setServices:epilog}

  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
pde::viewers::GnuPlotter_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter.releaseServices)

  // Insert-UserCode-Here {pde.viewers.GnuPlotter.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(pde.viewers.GnuPlotter.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(pde.viewers.GnuPlotter.releaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter.releaseServices)
}

/**
 * Method:  setOutput[]
 */
void
pde::viewers::GnuPlotter_impl::setOutput_impl (
  /* in */const ::std::string& destination ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter.setOutput)
	fname = destination;
  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter.setOutput)
}

/**
 * Method:  setIncludeBoundaries[]
 */
void
pde::viewers::GnuPlotter_impl::setIncludeBoundaries_impl (
  /* in */int32_t useBounds ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter.setIncludeBoundaries)
	(void) useBounds;
  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter.setIncludeBoundaries)
}

/**
 * Method:  setAnimateImages[]
 */
void
pde::viewers::GnuPlotter_impl::setAnimateImages_impl (
  /* in */int32_t animateFrames ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter.setAnimateImages)
  // Insert-Code-Here {pde.viewers.GnuPlotter.setAnimateImages} (setAnimateImages method)
    
    // DO-DELETE-WHEN-IMPLEMENTING exception.begin()
    /*
     * This method has not been implemented
     */
    ::sidl::NotImplementedException ex = ::sidl::NotImplementedException::_create();
    ex.setNote("This method has not been implemented");
    ex.add(__FILE__, __LINE__, "setAnimateImages");
    throw ex;
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter.setAnimateImages)
}

/**
 * Method:  showMesh[]
 */
void
pde::viewers::GnuPlotter_impl::showMesh_impl (
  /* in */::pde::Mesh m ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter.showMesh)
   	(void)m;
	std::cout << "GnuPlotter doesn't have dumper for showing just the grid yet." << std::endl; 
  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter.showMesh)
}

/**
 * Method:  showField[]
 */
void
pde::viewers::GnuPlotter_impl::showField_impl (
  /* in */::pde::Mesh m,
  /* in */::pde::FieldVar fv ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter.showField)

    std::cout << "GnuPlotter::showField() Entry." << std::endl;

    if (fname.length() < 1) 
	fname = "pde.viewers.GnuPlotter.showField.out";

    // add the proc number to the output file.
    int32_t procNo = m.getProcId() ;
    // std::stringstream s ; s << fname << ".GnuPlotter" << "." << procNo ;
    std::stringstream s ; s << fname << "." << procNo ;
    fname = s.str() ;
    
    std::cout << "\tfname set to: " << fname << std::endl;

    int32_t dim = fv.getDimension();
    int32_t nvars = fv.getNVars();
    int32_t pcount = fv.getRegionCount();

    std::fstream f( fname.c_str(),  std::fstream::out );
    std::cout << "Writing fieldvar to " << fname << std::endl;
    f <<  "# Name: " << fv.getName() << std::endl;
    f <<  "# Dimension: " << dim << std::endl;
    f <<  "# NVars: " << nvars << std::endl;
    f <<  "# BoundaryWidth: " << fv.getBoundaryWidth() << std::endl;
    f <<  "# MeshColl: " << fv.getMeshColl() << std::endl;

    int32_t tlow, thigh;
    sidl::array< double > delta = m.getDistances();
    sidl::array< int32_t > gridshape = m.getShape();
    for (int32_t i= delta.lower(0); i <= delta.upper(0); i++) 
	delta.set(i, delta[i]/gridshape[i]);

    m.getTimeRange(tlow, thigh);
    f <<  "# TimeRange: " << tlow << " , " << thigh << std::endl;

    int32_t ct = fv.getCurrentTime();
    f << "# CurrentTime: " << ct << std::endl;
    f << "# StepsCompleted: " << m.stepsCompleted() << std::endl;

    for (int32_t k=0; k < pcount; k++) // Loop over regions
    {
		f << std::endl <<"# Region " << k << " data" << std::endl;
		sidl::array< int32_t > lens = fv.getShape(k);
		f <<  "# Shape: " ;
		for (int i = 0; i < dim; i++) 
	    	f << "[" << lens[i] << "]";
	
		sidl::array< int32_t > first = fv.getLowerCorner(k);
		sidl::array< int32_t > last = fv.getUpperCorner(k);
		for (int32_t j= 0; j < dim; j++) 
			f << "[" << first[j] << ".." << last[j] << "|" << lens[j] <<"]";
		f <<  std::endl;

		// real x y z, value for each var
		sidl::array< double > data = fv.getData( ct, k);
		int32_t dmax = data.upper(0);
		int32_t coord[3];
		int64_t volume = m.shapeVolume(lens);

		// Loop over points in a region
		for (int d = data.lower(0); d < volume; d++)
		{
			fv.indexToCoord(d, first, last, coord[0], coord[1], coord[2]);
			for (int q = 0; q < dim; q++) 
			f << coord[q] * delta[q] << " " ;

			for (int32_t ivar = 0; ivar < nvars; ivar++) 
				f << data[d+ivar*volume] << " ";

			f << std::endl;

			// After writing out 1 horizontal line, add extra line
			if ( (d+1)%lens[0] == 0 ) f << std::endl ;

		} // End of loop over grid points
		f <<  std::endl;

    } // End of loop over regions
    f << std::endl;

	f.close();

	// Write out a GnuPlot Script to generate a nice 2-D Jpg image...

	std::string showfname;
    std::stringstream sfs ; sfs << fname << ".showgp" ;
    showfname = sfs.str() ;

	std::cout << "Show GnuPlot Script File: " << showfname << std::endl;

    std::fstream sf( showfname.c_str(),  std::fstream::out );

	sf << "set pm3d map" << std::endl;
	sf << "set out '" << fname << ".jpg'" << std::endl;
	sf << "set term jpeg" << std::endl;
	sf << "splot '" << fname << "'" << std::endl;

	sf.close();

	// Now call GnuPlot with the given script...

	std::string gpcmd;
    std::stringstream gpcs ; gpcs << "gnuplot " << showfname ;
    gpcmd = gpcs.str() ;

	std::cout << "Executing:  " << gpcmd << std::endl;

	int cc = system( gpcmd.c_str() );

	std::cout << "GnuPlot Command Returned cc=" << cc << std::endl;

  // DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter.showField)
}


// DO-NOT-DELETE splicer.begin(pde.viewers.GnuPlotter._misc)
// Insert-Code-Here {pde.viewers.GnuPlotter._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(pde.viewers.GnuPlotter._misc)

