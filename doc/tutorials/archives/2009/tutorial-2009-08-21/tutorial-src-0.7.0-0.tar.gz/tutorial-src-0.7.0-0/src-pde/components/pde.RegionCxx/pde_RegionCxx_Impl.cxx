// 
// File:          pde_RegionCxx_Impl.cxx
// Symbol:        pde.RegionCxx-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.RegionCxx
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_RegionCxx_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_bsl_arr_hxx
#include "bsl_arr.hxx"
#endif
#ifndef included_pde_BoundPos_hxx
#include "pde_BoundPos.hxx"
#endif
#ifndef included_pde_MeshColl_hxx
#include "pde_MeshColl.hxx"
#endif
#ifndef included_pde_Patch_hxx
#include "pde_Patch.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx._includes)

  // Insert-UserCode-Here {pde.RegionCxx._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(pde.RegionCxx._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.RegionCxx._includes)

  // Insert-UserCode-Here {pde.RegionCxx._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.RegionCxx._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::RegionCxx_impl::RegionCxx_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::RegionCxx::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx._ctor2)
  // Insert-Code-Here {pde.RegionCxx._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.RegionCxx._ctor2)
}

// user defined constructor
void pde::RegionCxx_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx._ctor)
    
  // Insert-UserCode-Here {pde.RegionCxx._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(pde.RegionCxx._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.RegionCxx: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.RegionCxx._ctor)

     tl = -1; th = -2; tcur = 0;

  // DO-NOT-DELETE splicer.end(pde.RegionCxx._ctor)
}

// user defined destructor
void pde::RegionCxx_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx._dtor)
  // Insert-UserCode-Here {pde.RegionCxx._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.RegionCxx._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.RegionCxx: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.RegionCxx._dtor) 

  // DO-NOT-DELETE splicer.end(pde.RegionCxx._dtor)
}

// static class initializer
void pde::RegionCxx_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx._load)
  // Insert-Code-Here {pde.RegionCxx._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.RegionCxx._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  init[]
 */
void
pde::RegionCxx_impl::init_impl (
  /* in */::pde::Patch p,
  /* in */int32_t sstencil,
  /* in */int32_t bwidth,
  /* in */int32_t nvars,
  /* in */::pde::MeshColl T,
  /* in */int32_t tlo,
  /* in */int32_t thi ) 
{
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx.init)
	patch = p;
	th = thi;
	tl = tlo;
	int32_t tlen = thi-tlo+1;
	int32_t dlen = computeDataSize(p,sstencil,bwidth,nvars,T);
	for (int j = 0; j < tlen; j++) {
		sidl::array< double > dtmp = sidl::array< double >::create1d(dlen) ;
		timeslices.push_back( dtmp );
	}
  // DO-NOT-DELETE splicer.end(pde.RegionCxx.init)
}

/**
 * Method:  finalize[]
 */
void
pde::RegionCxx_impl::finalize_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx.finalize)
	timeslices.clear();
	::pde::Patch x;
	patch = x;
        sidl::array< int32_t > dummy;
	firstAll =  dummy;
	lastAll = dummy;
	shapeAll = dummy;
	th = -100;
	tl = -99;
  // DO-NOT-DELETE splicer.end(pde.RegionCxx.finalize)
}

/**
 * Method:  computeDataSize[]
 */
int32_t
pde::RegionCxx_impl::computeDataSize_impl (
  /* in */::pde::Patch p,
  /* in */int32_t sstencil,
  /* in */int32_t bwidth,
  /* in */int32_t nvars,
  /* in */::pde::MeshColl T ) 
{
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx.computeDataSize)
        int32_t result;
        sidl::array< int32_t > first, last, shape, firstIndices, lastIndices;
        // get valid region corners
        firstIndices = p.getFirstIndices();
        lastIndices = p.getLastIndices();
        // make space to compute allocated region corners
        int32_t pdim = p.getDimension();
        first = sidl::array< int32_t >::create1d(pdim);
        shape = sidl::array< int32_t >::create1d(pdim);
        last = sidl::array< int32_t >::create1d(pdim);
        // start with the patch limits
        first.copy(firstIndices);
        last.copy(lastIndices);
        // expand corners required for
        // for collocation type, boundary on each edge or not and stencil on each edge or not.
        // and store in first,last.
#define L0 0
#define H0 1
#define L1 2
#define H1 3
#define L2 4
#define H2 5
        sidl::array< pde::BoundPos > outer = p.getBoundaryDirections();
        // sidl::array< int64_t > outer = p.getBoundaryDirections();
        bool sidesdone[6] = {false, false, false, false, false, false};
        // fix boundary sides
        for (int i = 0; outer._not_nil() && i <= outer.upper(0); i++) {
                pde::BoundPos pos = outer[i];
                // pde::BoundPos pos = static_cast< pde::BoundPos>(outer[i]);
                switch (pos) {
                case pde::BoundPos_LOW0: {
                        sidesdone[L0] = true;
                        int32_t low0 = first[0];
                        low0 -= bwidth;
                        first.set(0,low0);
                        break;
                }
                case pde::BoundPos_HIGH0: {
                        sidesdone[H0] = true;
                        int32_t high0 = last[0];
                        high0 += bwidth;
                        last.set(0,high0);
                        break;
                }
                case pde::BoundPos_LOW1: {
                        sidesdone[L1] = true;
                        int32_t low1 = first[1];
                        low1 -= bwidth;
                        first.set(1,low1);
                        break;
                }
                case pde::BoundPos_HIGH1: {
                        sidesdone[H1] = true;
                        int32_t high1 = last[1];
                        high1 += bwidth;
                        last.set(1,high1);
                        break;
                }
                case pde::BoundPos_LOW2: {
                        sidesdone[L2] = true;
                        int32_t low2 = first[2];
                        low2 -= bwidth;
                        first.set(2,low2);
                        break;
                }
                case pde::BoundPos_HIGH2: {
                        sidesdone[H2] = true;
                        int32_t high2 = last[2];
                        high2 += bwidth;
                        last.set(2,high2);
                        break;
                }
                default:
                        BOCCA_THROW_CXX(sidl::SIDLException,"unexpected bound enum value.");
                }
        }
        // fix stencil sides (which are all sides that are not bounds)
        for (int i = 0; i < pdim; i++) {
                if (! sidesdone[2*i]) {
                        int32_t low = first[i];
                        low -= sstencil;
                        first.set(i, low);
                }
                if (! sidesdone[2*i+1]) {
                        int32_t high = last[i];
                        high += sstencil;
                        last.set(i, high);
                }
        }
        // expand for collocations
        switch (T) {
        case pde::MeshColl_CENTERS:
                break; // no extra.
        default:
                BOCCA_THROW_CXX(sidl::SIDLException, "unsupported collocation type.");
        }
        // calc nx*ny*nz*nvars and return it.
	volume = 1;
        for (int i=0; i < pdim; i++) {
                int32_t si = last[i]-first[i] + 1;
		shape.set(i, si);
                volume *= (last[i]-first[i] + 1);
        }
        result = nvars * volume;
	firstAll = first;
	lastAll = last;
	shapeAll = shape;
        return result;

  // DO-NOT-DELETE splicer.end(pde.RegionCxx.computeDataSize)
}

/**
 *  return the range within the source patch that overlaps this region and its ghost cells.
 * @return false if no overlap, true if overlap.
 */
bool
pde::RegionCxx_impl::computeOverlap_impl (
  /* in */::pde::Patch source,
  /* inout rarray[d] */int32_t* windowLowerCorner,
  /* inout rarray[d] */int32_t* windowUpperCorner,
  /* in */int32_t d ) 
{
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx.computeOverlap)
	sidl::array<int32_t> sfirst, slast; // owned range in source
	sfirst = source.getFirstIndices();
	slast = source.getLastIndices();
	for (int32_t i = 0; i < sfirst.length(); i++) {
		// each axis must have some overlap
		int32_t l1, l2, h1, h2, b, e;
		l1 = sfirst[i];
		h1 = slast[i];
		l2 = firstAll[i];
		h2 = lastAll[i];
		b = (l1 > l2) ? l1 : l2; // max of lows
		e = (h1 > h2) ? h2 : h1; // min of highs
		if (b > e) return false; // non-overlapping
		windowLowerCorner[i] = b;
		windowUpperCorner[i] = e;
	}
	return true;
  // DO-NOT-DELETE splicer.end(pde.RegionCxx.computeOverlap)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::RegionCxx_impl::boccaForceUsePortInclude_impl (
  /* in */::pde::MeshColl dummy0,
  /* in */::pde::Patch dummy1,
  /* in */::pde::BoundPos dummy2,
  /* in */::bsl::arr dummy3 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.RegionCxx.boccaForceUsePortInclude)
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;
    (void)dummy3;

  // Bocca generated code. bocca.protected.end(pde.RegionCxx.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.RegionCxx.boccaForceUsePortInclude)
}

/**
 * Method:  getLowerCorner[]
 */
::sidl::array<int32_t>
pde::RegionCxx_impl::getLowerCorner_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx.getLowerCorner)
	return firstAll;
  // DO-NOT-DELETE splicer.end(pde.RegionCxx.getLowerCorner)
}

/**
 *  
 * @return upper bounding box corner of the regionId given.
 * result array will be getDimension() long.
 */
::sidl::array<int32_t>
pde::RegionCxx_impl::getUpperCorner_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx.getUpperCorner)
	return lastAll;
  // DO-NOT-DELETE splicer.end(pde.RegionCxx.getUpperCorner)
}

/**
 *  @return  array 'dimension' long with sizes in X,Y,Z directions. 
 */
::sidl::array<int32_t>
pde::RegionCxx_impl::getShape_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx.getShape)
	return shapeAll;
  // DO-NOT-DELETE splicer.end(pde.RegionCxx.getShape)
}

/**
 *  
 * @return 1d array with size the product of getShape()[i] for all i=[0.dim-1].
 */
::sidl::array<double>
pde::RegionCxx_impl::getData_impl (
  /* in */int32_t time ) 
{
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx.getData)
    int index = timeZeroed(time);
    return timeslices.at(index);
  // DO-NOT-DELETE splicer.end(pde.RegionCxx.getData)
}

/**
 *  return the underlying mesh geometry section. 
 */
::pde::Patch
pde::RegionCxx_impl::getPatch_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx.getPatch)
	return patch;
  // DO-NOT-DELETE splicer.end(pde.RegionCxx.getPatch)
}

/**
 *  left rotate the array. yea verily, the first shall become last. 
 */
void
pde::RegionCxx_impl::cycletimes_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx.cycletimes)
                std::vector < sidl::array< double > >::iterator diter;
                diter = timeslices.begin();
                sidl::array< double > tmp = *diter;
                timeslices.erase(diter);
                timeslices.push_back(tmp);
  // DO-NOT-DELETE splicer.end(pde.RegionCxx.cycletimes)
}

/**
 * Method:  setCurrentTime[]
 */
void
pde::RegionCxx_impl::setCurrentTime_impl (
  /* in */int32_t time ) 
{
  // DO-NOT-DELETE splicer.begin(pde.RegionCxx.setCurrentTime)
	tcur = time;
  // DO-NOT-DELETE splicer.end(pde.RegionCxx.setCurrentTime)
}


// DO-NOT-DELETE splicer.begin(pde.RegionCxx._misc)
// Insert-Code-Here {pde.RegionCxx._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(pde.RegionCxx._misc)

