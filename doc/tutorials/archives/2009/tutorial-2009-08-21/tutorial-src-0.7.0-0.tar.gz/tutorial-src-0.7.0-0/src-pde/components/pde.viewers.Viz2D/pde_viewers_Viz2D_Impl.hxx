// 
// File:          pde_viewers_Viz2D_Impl.hxx
// Symbol:        pde.viewers.Viz2D-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.viewers.Viz2D
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_pde_viewers_Viz2D_Impl_hxx
#define included_pde_viewers_Viz2D_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_pde_viewers_Viz2D_IOR_h
#include "pde_viewers_Viz2D_IOR.h"
#endif
#ifndef included_bsl_arr_hxx
#include "bsl_arr.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Component_hxx
#include "gov_cca_Component.hxx"
#endif
#ifndef included_gov_cca_ComponentRelease_hxx
#include "gov_cca_ComponentRelease.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_ParameterPortFactory_hxx
#include "gov_cca_ports_ParameterPortFactory.hxx"
#endif
#ifndef included_pde_BoundPos_hxx
#include "pde_BoundPos.hxx"
#endif
#ifndef included_pde_FieldVar_hxx
#include "pde_FieldVar.hxx"
#endif
#ifndef included_pde_Mesh_hxx
#include "pde_Mesh.hxx"
#endif
#ifndef included_pde_Patch_hxx
#include "pde_Patch.hxx"
#endif
#ifndef included_pde_RenderPort_hxx
#include "pde_RenderPort.hxx"
#endif
#ifndef included_pde_viewers_Viz2D_hxx
#include "pde_viewers_Viz2D.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif


// DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D._hincludes)
// Insert-Code-Here {pde.viewers.Viz2D._includes} (includes or arbitrary code)

// GD Header

#include "gd.h"

#define VIZGIFFER_GIF	1
#define VIZGIFFER_JPEG	2
#define VIZGIFFER_PNG	3

#ifdef HAVE_MPI

// MPI Header

#undef SEEK_SET
#undef SEEK_CUR
#undef SEEK_END

#include "mpi.h"

#endif

// Floating Point Equivalence Macro

#define EQUIV_DELTA     0.000001

#define EQUIV( _d1, _d2 ) \
( ( (_d1) != 0.0 ) ? \
	( ( fabs( (_d1) - (_d2) ) / fabs( _d1 ) ) < EQUIV_DELTA ) \
	: ( fabs( (_d1) - (_d2) ) < EQUIV_DELTA ) )

// Memory Allocation Debug Macros

#ifdef MEM_DEBUG

// Debug Versions

#define MALLOC( _d ) \
	( printf( "malloc size = %u\n", (unsigned) (_d) ), \
		TMP_PTR = (void *) malloc( _d ), \
		printf( "\tmem returned = 0x%lx\n", (long) TMP_PTR ), \
		fflush( stdout ), \
		TMP_PTR )

#define FREE( _c ) \
	( printf( "free ptr = 0x%lx\n", (long) _c ), fflush( stdout ), \
		free( _c ) )

#else

// Non-Debug Versions

#define MALLOC( _d )            malloc( _d )

#define FREE( _c )              free( _c )

#endif

// DO-NOT-DELETE splicer.end(pde.viewers.Viz2D._hincludes)
// DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D._includes)
// Insert-Code-Here {pde.viewers.Viz2D._includes} (includes or arbitrary code)

// GD Header

#include "gd.h"

#define VIZGIFFER_GIF	1
#define VIZGIFFER_JPEG	2
#define VIZGIFFER_PNG	3

#ifdef HAVE_MPI

// MPI Header

#undef SEEK_SET
#undef SEEK_CUR
#undef SEEK_END

#include "mpi.h"

#endif

// Floating Point Equivalence Macro

#define EQUIV_DELTA     0.000001

#define EQUIV( _d1, _d2 ) \
( ( (_d1) != 0.0 ) ? \
	( ( fabs( (_d1) - (_d2) ) / fabs( _d1 ) ) < EQUIV_DELTA ) \
	: ( fabs( (_d1) - (_d2) ) < EQUIV_DELTA ) )

// Memory Allocation Debug Macros

#ifdef MEM_DEBUG

// Debug Versions

#define MALLOC( _d ) \
	( printf( "malloc size = %u\n", (unsigned) (_d) ), \
		TMP_PTR = (void *) malloc( _d ), \
		printf( "\tmem returned = 0x%lx\n", (long) TMP_PTR ), \
		fflush( stdout ), \
		TMP_PTR )

#define FREE( _c ) \
	( printf( "free ptr = 0x%lx\n", (long) _c ), fflush( stdout ), \
		free( _c ) )

#else

// Non-Debug Versions

#define MALLOC( _d )            malloc( _d )

#define FREE( _c )              free( _c )

#endif

// DO-NOT-DELETE splicer.end(pde.viewers.Viz2D._includes)

namespace pde { 
  namespace viewers { 

    /**
     * Symbol "pde.viewers.Viz2D" (version 0.0)
     */
    class Viz2D_impl : public virtual ::pde::viewers::Viz2D 
    // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D._inherits)
    // Insert-Code-Here {pde.viewers.Viz2D._inherits} (optional inheritance here)
    // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D._inherits)
    {

    // All data marked protected will be accessable by 
    // descendant Impl classes
    protected:

      bool _wrapped;

  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D._implementation)

  // Insert-UserCode-Here(pde.viewers.Viz2D._implementation)

	// Support Routine Declarations

#ifdef HAVE_MPI
	void get_mpi_info( MPI_Comm *, int *, int * );
#endif

	void allocate_global_data( int );

	void color_value_img( gdImagePtr, int *, double, int );
	void color_value_str( char *, double );
	void do_dump_gif_file( ::sidl::array<double>, int, int, char * );
	void handle_min_max( double, double );

	// File Name Prefix
	std::string FILE_PREFIX;

	// Display Size
	int GIF_HEIGHT;
	int GIF_WIDTH;

	// Color Map
	double COLOR_MIN_VALUE;
	double COLOR_MAX_VALUE;
	int COLOR_MAP_INITD;
	int AUTO_COLOR_MAP;
	int LAZY_COLOR_MAP;

	// Verbosity
	int vflag;

	// Global Decomposition
	int GLB[2], GUB[2];

	// Global Data Pointer
	double *GDATA;
	int GSIZE;

	// Use Boundaries in Images Flag...
	int useBoundsFlag;

	// Assemble Animated Images...
	int animateFramesFlag;

	// Cruft to Keep Track of Any Animated Gifs In Progress...  :-o
	FILE *openAnimFilePointers[100];
	char *openAnimFileNames[100];
	int numOpenAnimFiles;

	// Output Format
	int GDFORMAT;

	// Sequence Counter
	int SEQUENCE;

#ifdef HAVE_MPI
	// MPI Communicator
	MPI_Comm COMM;
	int useMPI;
#endif

#ifdef MEM_DEBUG

	// Memory Allocation Temporary Pointer
	void *TMP_PTR;

#endif

	// Additional Option/Parameter Setting Methods...
	// (should eventually go into official public SIDL interface...)

#ifdef HAVE_MPI
	void setMPIComm( int64_t comm );
#endif

	void setDisplaySize( int32_t width, int32_t height );

	void setColorMapAuto();
	void setColorMapLazy();
	void setColorMapRange( double min, double max );

	void setOutputFormatGif();
	void setOutputFormatJpeg();
	void setOutputFormatPng();

	void setVerbose( int32_t onoff );

	void setGlobalBounds( int32_t glbrow, int32_t glbcol,
			int32_t gubrow, int32_t gubcol );

	void initializeGlobalData( int32_t doClear );

	void collectVizData( const char *fieldName, ::sidl::array<double> data,
			int32_t rowLowBoundWidth, int32_t rowHighBoundWidth,
			int32_t colLowBoundWidth, int32_t colHighBoundWidth,
			int32_t nrows, int32_t ncols,
			int32_t growstart, int32_t gcolstart );

	void dumpVizFile( const char *fieldName );

  // Bocca generated code. bocca.protected.begin(pde.viewers.Viz2D._implementation)
  
   gov::cca::Services    d_services; // our cca handle.
 

  // Bocca generated code. bocca.protected.end(pde.viewers.Viz2D._implementation)

  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D._implementation)

    public:
      // default constructor, used for data wrapping(required)
      Viz2D_impl();
      // sidl constructor (required)
      // Note: alternate Skel constructor doesn't call addref()
      // (fixes bug #275)
      Viz2D_impl( struct pde_viewers_Viz2D__object * s ) : StubBase(s,true), 
        _wrapped(false) { _ctor(); }

      // user defined construction
      void _ctor();

      // virtual destructor (required)
      virtual ~Viz2D_impl() { _dtor(); }

      // user defined destruction
      void _dtor();

      // true if this object was created by a user newing the impl
      inline bool _isWrapped() {return _wrapped;}

      // static class initializer
      static void _load();

    public:

      /**
       * user defined non-static method.
       */
      void
      boccaSetServices_impl (
        /* in */::gov::cca::Services services
      )
      // throws:
      //     ::gov::cca::CCAException
      //     ::sidl::RuntimeException
      ;

      /**
       * user defined non-static method.
       */
      void
      boccaReleaseServices_impl (
        /* in */::gov::cca::Services services
      )
      // throws:
      //     ::gov::cca::CCAException
      //     ::sidl::RuntimeException
      ;


      /**
       *  This function should never be called, but helps babel generate better code. 
       */
      void
      boccaForceUsePortInclude_impl (
        /* in */::gov::cca::ports::ParameterPortFactory dummy0,
        /* in */::pde::Patch dummy1,
        /* in */::pde::BoundPos dummy2,
        /* in */::bsl::arr dummy3
      )
      ;


      /**
       *  Starts up a component presence in the calling framework.
       * @param services the component instance's handle on the framework world.
       * Contracts concerning services and setServices:
       * 
       * The component interaction with the CCA framework
       * and Ports begins on the call to setServices by the framework.
       * 
       * This function is called exactly once for each instance created
       * by the framework.
       * 
       * The argument services will never be nil/null.
       * 
       * Those uses ports which are automatically connected by the framework
       * (so-called service-ports) may be obtained via getPort during
       * setServices.
       */
      void
      setServices_impl (
        /* in */::gov::cca::Services services
      )
      // throws:
      //     ::gov::cca::CCAException
      //     ::sidl::RuntimeException
      ;


      /**
       * Shuts down a component presence in the calling framework.
       * @param services the component instance's handle on the framework world.
       * Contracts concerning services and setServices:
       * 
       * This function is called exactly once for each callback registered
       * through Services.
       * 
       * The argument services will never be nil/null.
       * The argument services will always be the same as that received in
       * setServices.
       * 
       * During this call the component should release any interfaces
       * acquired by getPort().
       * 
       * During this call the component should reset to nil any stored
       * reference to services.
       * 
       * After this call, the component instance will be removed from the
       * framework. If the component instance was created by the
       * framework, it will be destroyed, not recycled, The behavior of
       * any port references obtained from this component instance and
       * stored elsewhere becomes undefined.
       * 
       * Notes for the component implementor:
       * 1) The component writer may perform blocking activities
       * within releaseServices, such as waiting for remote computations
       * to shutdown.
       * 2) It is good practice during releaseServices for the component
       * writer to remove or unregister all the ports it defined.
       */
      void
      releaseServices_impl (
        /* in */::gov::cca::Services services
      )
      // throws:
      //     ::gov::cca::CCAException
      //     ::sidl::RuntimeException
      ;

      /**
       * user defined non-static method.
       */
      void
      setOutput_impl (
        /* in */const ::std::string& destination
      )
      ;

      /**
       * user defined non-static method.
       */
      void
      setIncludeBoundaries_impl (
        /* in */int32_t useBounds
      )
      ;

      /**
       * user defined non-static method.
       */
      void
      setAnimateImages_impl (
        /* in */int32_t animateFrames
      )
      ;

      /**
       * user defined non-static method.
       */
      void
      showMesh_impl (
        /* in */::pde::Mesh m
      )
      ;

      /**
       * user defined non-static method.
       */
      void
      showField_impl (
        /* in */::pde::Mesh m,
        /* in */::pde::FieldVar fv
      )
      ;

    };  // end class Viz2D_impl

  } // end namespace viewers
} // end namespace pde

// DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D._misc)
// Insert-Code-Here {pde.viewers.Viz2D._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(pde.viewers.Viz2D._misc)

#endif
