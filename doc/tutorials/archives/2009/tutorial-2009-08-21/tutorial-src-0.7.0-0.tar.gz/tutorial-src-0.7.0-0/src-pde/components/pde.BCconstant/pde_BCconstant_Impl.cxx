// 
// File:          pde_BCconstant_Impl.cxx
// Symbol:        pde.BCconstant-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.BCconstant
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_BCconstant_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_bsl_arr_hxx
#include "bsl_arr.hxx"
#endif
#ifndef included_pde_BoundPos_hxx
#include "pde_BoundPos.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.BCconstant._includes)

  // Insert-UserCode-Here {pde.BCconstant._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(pde.BCconstant._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.BCconstant._includes)

  // Insert-UserCode-Here {pde.BCconstant._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.BCconstant._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::BCconstant_impl::BCconstant_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::BCconstant::_wrapObj(reinterpret_cast< void*>(this))),false) , 
  _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(pde.BCconstant._ctor2)
  // Insert-Code-Here {pde.BCconstant._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.BCconstant._ctor2)
}

// user defined constructor
void pde::BCconstant_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.BCconstant._ctor)
    
  // Insert-UserCode-Here {pde.BCconstant._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(pde.BCconstant._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.BCconstant: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.BCconstant._ctor)

  // Insert-UserCode-Here {pde.BCconstant._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(pde.BCconstant._ctor)
}

// user defined destructor
void pde::BCconstant_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.BCconstant._dtor)
  // Insert-UserCode-Here {pde.BCconstant._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.BCconstant._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.BCconstant: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.BCconstant._dtor) 

  // DO-NOT-DELETE splicer.end(pde.BCconstant._dtor)
}

// static class initializer
void pde::BCconstant_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.BCconstant._load)
  // Insert-Code-Here {pde.BCconstant._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.BCconstant._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::BCconstant_impl::boccaForceUsePortInclude_impl (
  /* in */::bsl::arr dummy0 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.BCconstant.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.BCconstant.boccaForceUsePortInclude)
    (void)dummy0;

  // Bocca generated code. bocca.protected.end(pde.BCconstant.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.BCconstant.boccaForceUsePortInclude)
}

/**
 *  GetProperty Methods to set and get properties based on key-value pairs. Any 
 * component implementing this Boundary Conditions Port would have
 * its own keys.
 * @param key_name : a string identifying the property. Examples
 * include "InflowVelocity", "NumberOfBoundaryCells" etc.
 * @param value : an int/long/double that contains the value of the
 * property identified by the key_name. If the key is unknown in a get
 * operation, the value given is the value that comes back.
 */
void
pde::BCconstant_impl::getPropI_impl (
  /* in */const ::std::string& key_name,
  /* inout */int32_t& value ) 
{
  // DO-NOT-DELETE splicer.begin(pde.BCconstant.getPropI)
	std::map<std::string,int32_t>::iterator iter = d_ints.find(key_name);
	if ( iter == d_ints.end() ) {
		return;
	}
	value = d_ints[key_name];
  // DO-NOT-DELETE splicer.end(pde.BCconstant.getPropI)
}

/**
 * Method:  getPropD[]
 */
void
pde::BCconstant_impl::getPropD_impl (
  /* in */const ::std::string& key_name,
  /* inout */double& value ) 
{
  // DO-NOT-DELETE splicer.begin(pde.BCconstant.getPropD)
	std::map<std::string,double>::iterator iter = d_doubles.find(key_name);
	if ( iter == d_doubles.end() ) {
		return;
	}
	value = d_doubles[key_name];
  // DO-NOT-DELETE splicer.end(pde.BCconstant.getPropD)
}

/**
 * Method:  setPropI[]
 */
void
pde::BCconstant_impl::setPropI_impl (
  /* in */const ::std::string& key_name,
  /* in */int32_t value ) 
{
  // DO-NOT-DELETE splicer.begin(pde.BCconstant.setPropI)
	d_ints[key_name] = value;
  // DO-NOT-DELETE splicer.end(pde.BCconstant.setPropI)
}

/**
 * Method:  setPropD[]
 */
void
pde::BCconstant_impl::setPropD_impl (
  /* in */const ::std::string& key_name,
  /* in */double value ) 
{
  // DO-NOT-DELETE splicer.begin(pde.BCconstant.setPropD)
	d_doubles[key_name] = value;
  // DO-NOT-DELETE splicer.end(pde.BCconstant.setPropD)
}

/**
 *  mark start of processing a fieldvar 
 */
void
pde::BCconstant_impl::startApplication_impl (
  /* in */const ::std::string& fvName ) 
{
  // DO-NOT-DELETE splicer.begin(pde.BCconstant.startApplication)
	// we don't care, except for debugging
	(void)fvName;
  // DO-NOT-DELETE splicer.end(pde.BCconstant.startApplication)
}

/**
 * Method:  setWindow[]
 */
int32_t
pde::BCconstant_impl::setWindow_impl (
  /* in */::pde::BoundPos side,
  /* in array<int> */::sidl::array<int32_t> window_lower_bound,
  /* in array<int> */::sidl::array<int32_t> window_upper_bound,
  /* in array<int> */::sidl::array<int32_t> window_shape ) 
{
  // DO-NOT-DELETE splicer.begin(pde.BCconstant.setWindow)
	d_win_hi = bsl::arr::cloneInt1(window_upper_bound);
	d_win_lo = bsl::arr::cloneInt1(window_lower_bound);
	d_win_shape = bsl::arr::cloneInt1(window_shape);
  // DO-NOT-DELETE splicer.end(pde.BCconstant.setWindow)
}

/**
 * Method:  setWindowRaw[]
 */
int32_t
pde::BCconstant_impl::setWindowRaw_impl (
  /* in */::pde::BoundPos side,
  /* in rarray[dim] */int32_t* window_lower_bound,
  /* in rarray[dim] */int32_t* window_upper_bound,
  /* in rarray[dim] */int32_t* window_shape,
  /* in */int32_t dim ) 
{
  // DO-NOT-DELETE splicer.begin(pde.BCconstant.setWindowRaw)
	d_win_hi = ::sidl::array<int32_t>::create1d(dim);
	d_win_lo = ::sidl::array<int32_t>::create1d(dim);
	d_win_shape = ::sidl::array<int32_t>::create1d(dim);
	bsl::arr::load1(d_win_hi, window_upper_bound, dim);
	bsl::arr::load1(d_win_lo, window_lower_bound, dim);
	bsl::arr::load1(d_win_shape, window_shape, dim);
  // DO-NOT-DELETE splicer.end(pde.BCconstant.setWindowRaw)
}

/**
 * Method:  compute[]
 */
int32_t
pde::BCconstant_impl::compute_impl (
  /* inout array<double> */::sidl::array<double>& uc,
  /* in array<int> */::sidl::array<int32_t> lbc,
  /* in array<int> */::sidl::array<int32_t> ubc,
  /* in array<int> */::sidl::array<int32_t> shapec,
  /* in */int32_t nvars ) 
{
  // DO-NOT-DELETE splicer.begin(pde.BCconstant.compute)
	int32_t loCoord[3] = {-100, -100, -100}, hiCoord[3] = {-100, -100, -100};
	int32_t dim = d_win_lo.length();
	if (dim > 3 || dim <1) {
		BOCCA_THROW_CXX(sidl::SIDLException, "unsupported dimension in pde::BCconstant_impl::compute_impl");
	}
	double value = -10.0;
	getPropD("boundaryValue", value);
	bool overlaps = bsl::arr::computeIntersection(d_win_lo, d_win_hi, lbc, ubc, loCoord, hiCoord, dim);
	if ( overlaps ) {
		for (int32_t v = 0; v < nvars; v++) {
			int32_t i,j,k, i0,j0,k0, i1,j1,k1;
			k0=0; k1=0; j0=0; j1=0;
			i0 = loCoord[0]; 
			i1 = hiCoord[0];
			if (dim > 1) {
				j0 = loCoord[1]; j1 = hiCoord[1];
			}
			if (dim > 2) {
				k0 = loCoord[2]; k1 = hiCoord[2];
			}
			for (k = k0; k <= k1; k++) {
				for (j = j0; j <= j1; j++) {
					for (i = i0; i <= i1; i++) {
						int32_t destindex;
						destindex = bsl::arr::coordToIndex(v, lbc, ubc, i, j, k);
						uc.set(destindex, value);

					}
				}
			}
		}
        }
  // DO-NOT-DELETE splicer.end(pde.BCconstant.compute)
}

/**
 *  mark end of processing of the region list within a single field var. 
 */
void
pde::BCconstant_impl::endApplication_impl (
  /* in */const ::std::string& fvName ) 
{
  // DO-NOT-DELETE splicer.begin(pde.BCconstant.endApplication)
	// we don't care, except for debugging
	(void)fvName;
  // DO-NOT-DELETE splicer.end(pde.BCconstant.endApplication)
}


// DO-NOT-DELETE splicer.begin(pde.BCconstant._misc)
// Insert-Code-Here {pde.BCconstant._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(pde.BCconstant._misc)

