// 
// File:          pde_ICspots_Impl.cxx
// Symbol:        pde.ICspots-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.ICspots
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_ICspots_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_ParameterPortFactory_hxx
#include "gov_cca_ports_ParameterPortFactory.hxx"
#endif
#ifndef included_pde_FieldVar_hxx
#include "pde_FieldVar.hxx"
#endif
#ifndef included_pde_Mesh_hxx
#include "pde_Mesh.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.ICspots._includes)

  // Insert-UserCode-Here {pde.ICspots._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(pde.ICspots._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.ICspots._includes)

  // Insert-UserCode-Here {pde.ICspots._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.ICspots._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::ICspots_impl::ICspots_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::ICspots::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(pde.ICspots._ctor2)
  // Insert-Code-Here {pde.ICspots._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.ICspots._ctor2)
}

// user defined constructor
void pde::ICspots_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.ICspots._ctor)
    
  // Insert-UserCode-Here {pde.ICspots._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(pde.ICspots._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.ICspots: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.ICspots._ctor)

  // Insert-UserCode-Here {pde.ICspots._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(pde.ICspots._ctor)
}

// user defined destructor
void pde::ICspots_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.ICspots._dtor)
  // Insert-UserCode-Here {pde.ICspots._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.ICspots._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.ICspots: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.ICspots._dtor) 

  // DO-NOT-DELETE splicer.end(pde.ICspots._dtor)
}

// static class initializer
void pde::ICspots_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.ICspots._load)
  // Insert-Code-Here {pde.ICspots._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.ICspots._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
pde::ICspots_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.ICspots.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.ICspots.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "pde.ICspots: Error casting self to gov::cca::Port");
  } 


  // Provide a pde.ICPort port with port name ic 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "ic", // port instance name
                   "pde.ICPort",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "pde.ICspots: Error calling addProvidesPort(port,"
        "\"ic\", \"pde.ICPort\", typeMap) ", -2);
    throw;
  }    

  // Use a gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    this->d_services.registerUsesPort(
                   "ppf", // port instance name
                   "gov.cca.ports.ParameterPortFactory",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.ICspots: Error calling registerUsesPort(\"ppf\", "
       "\"gov.cca.ports.ParameterPortFactory\", typeMap) ", -2);
    throw;
  }


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(pde.ICspots.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(pde.ICspots.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
pde::ICspots_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.ICspots.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.ICspots.boccaReleaseServices)
  this->d_services=0;


  // Un-provide pde.ICPort port with port name ic 
  try{
    services.removeProvidesPort("ic");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.ICspots: Error calling removeProvidesPort("
              << "\"ic\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    services.unregisterUsesPort("ppf");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.ICspots: Error calling unregisterUsesPort("
              << "\"ppf\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(pde.ICspots.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.ICspots.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::ICspots_impl::boccaForceUsePortInclude_impl (
  /* in */::gov::cca::ports::ParameterPortFactory dummy0 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.ICspots.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.ICspots.boccaForceUsePortInclude)
    (void)dummy0;

  // Bocca generated code. bocca.protected.end(pde.ICspots.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.ICspots.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
pde::ICspots_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.ICspots.setServices)

  // Insert-UserCode-Here{pde.ICspots.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(pde.ICspots.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(pde.ICspots.setServices)
  
  // define our parameters and the
  userinput = services.createTypeMap();
  ::gov::cca::Port gcp = services.getPort("ppf");
  
  if (gcp._is_nil()) {
    BOCCA_THROW_CXX(sidl::SIDLException, "ParameterPortFactory not provided by framework");
  }
  ::gov::cca::ports::ParameterPortFactory ppf;
  ppf = ::babel_cast< gov::cca::ports::ParameterPortFactory >(gcp);
  if (ppf._is_nil()) {
    BOCCA_THROW_CXX(sidl::SIDLException, "Bogus ParameterPortFactory provided");
  }
  
  ppf.initParameterData(userinput, "userinput");
  ppf.setBatchTitle(userinput, "Spot parameters");
  ppf.addRequestDouble(userinput, "background", "The initial background field value", "field background", 0.25, 0, 1.0e12);
  ppf.addRequestDouble(userinput, "spotvalue", "Initial hot spot field value", "hotspot value", 2.5, 0, 1.0e22);
  ppf.addRequestInt(userinput, "spotradius", "Radius (cell number) of spots", "radius cells", 0, 0, 100);
  ppf.addRequestInt(userinput, "spotcount", "How many spots to create", "spot count", 3, 0, 100);
  ppf.addRequestInt(userinput, "varnumber", "Field element for this IC", "variable number", 0, 0, 10000);
  ppf.addRequestString(userinput, "fieldname", "Field needed for this IC if more than one field given", "field name", "first");
  ppf.addParameterPort(userinput, services);
  services.releasePort("ppf");

  // DO-NOT-DELETE splicer.end(pde.ICspots.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
pde::ICspots_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.ICspots.releaseServices)

  ::gov::cca::Port gcp = services.getPort("ppf");

  if (gcp._not_nil()) {
    ::gov::cca::ports::ParameterPortFactory ppf;
    ppf = ::babel_cast< gov::cca::ports::ParameterPortFactory >(gcp);
    if (ppf._not_nil()) {
      ppf.removeParameterPort(userinput, services);
      services.releasePort("ppf");
    }
  }


  // bocca-default-code. User may edit or delete.begin(pde.ICspots.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(pde.ICspots.releaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.ICspots.releaseServices)
}

/**
 *  Apply an initialization to the array of VectorFieldVariables being sent in.
 * @param vfv : an array of FieldVar
 * @return 0 if OK, negative if error occurs.
 */
int32_t
pde::ICspots_impl::setInitialConditions_impl (
  /* inout array<pde.FieldVar> */::sidl::array< ::pde::FieldVar>& vfv,
  /* in */::pde::Mesh m ) 
{
  // DO-NOT-DELETE splicer.begin(pde.ICspots.setInitialConditions)
	::pde::FieldVar fv;
	if (vfv.length(0) > 1) {
		// if more than one, insist on name matching fieldname.
		for (int32_t i = vfv.lower(0); i <= vfv.upper(0); i++) {
			if (vfv[i].getName() == userinput.getString("fieldname","any")) {
				fv = vfv[i];
				break;
			}
		}
	} else {
		// if only one, don't care what it is called.
		fv = vfv[0];
	}
	if (fv._is_nil()) {
		return -1;
	} else {
		sidl::array< int32_t > first;
		sidl::array< int32_t > last;
		sidl::array< double > data;
		int32_t top, patchcount;
		double background = userinput.getDouble("background", 0);
		double spotvalue = userinput.getDouble("spotvalue", 0);
		int32_t spotradius = userinput.getInt("spotradius", 0);
		int32_t spotcount = userinput.getInt("spotcount", 0);
		int32_t varnumber = userinput.getInt("varnumber", 0);
		int32_t maxvar = fv.getNVars();
		if (maxvar >1 && varnumber >= maxvar) {
			return -1;
			// if we only have one var, we ignore varnumber.
			// otherwise, range check is performed.
		}

		// fill background.
		for (int32_t ir = 0; ir < fv.getRegionCount(); ir++) {
			data = fv.getData(0, ir);
			// double *datap = data.first(); // raw data pointer 
			// valid iff (data.is1dPacked() == true)
			first = fv.getLowerCorner(ir);
			last = fv.getUpperCorner(ir);
			top = data.upper(0);
			for (int k = data.lower(0); k <= top; k++) { 
				data.set(k, background);
			}
		}
		// create spots.
		sidl::array< int32_t > meshshape = m.getShape();
		int32_t dim = fv.getDimension();
		if (dim == 1) {
			int32_t skip = meshshape[0] / spotcount;
			int32_t shift = skip / 2;
			std::vector< int32_t> centers;
			for (int i = (skip - shift); i < meshshape[0]; i += skip) {
				for (int32_t j = i - spotradius; j <= (i+spotradius); j++) {
					centers.push_back(j);
				}
			}
			for (int32_t ir = 0; ir < fv.getRegionCount(); ir++) {
				data = fv.getData(0, ir);
				first = fv.getLowerCorner(ir);
				last = fv.getUpperCorner(ir);
				sidl::array< int32_t > point = sidl::array< int32_t >::create1d(1);
				for (int32_t s = 0; s < centers.size(); s++) {
					point.set(0, centers[s]);
					if (m.boxContains(first, last, point)) {
						int32_t index = fv.coordToIndex(varnumber, first, last, centers[s], 0, 0);
						data.set(index,spotvalue);
					}
				}
			}
		}
		if (dim == 2) {
			int32_t xskip = meshshape[0] / spotcount;
			int32_t yskip = meshshape[1] / spotcount;
			int32_t xshift = xskip / 2;
			int32_t yshift = yskip / 2;
			std::vector< int32_t> centers;
			int i = xskip - xshift;
			int j = yskip - yshift;
			for ( ; i < meshshape[0] && j < meshshape[1]; ) {
				for (int32_t i1 = i - spotradius; i1 <= (i+spotradius); i1++) {
					for (int32_t j1 = j - spotradius; j1 <= (j+spotradius); j1++) {
						centers.push_back(i1);
						centers.push_back(j1);
					}
				}
				i += xskip; j += yskip;
			}
			for (int32_t ir = 0; ir < fv.getRegionCount(); ir++) {
				data = fv.getData(0, ir);
				first = fv.getLowerCorner(ir);
				last = fv.getUpperCorner(ir);
				sidl::array< int32_t > point = sidl::array< int32_t >::create1d(2);
				for (int32_t s = 0; s < centers.size(); s+=2) {
					point.set(0, centers[s]);
					point.set(1, centers[s+1]);
					if (m.boxContains(first, last, point)) {
						int32_t index = fv.coordToIndex(varnumber, first, last, centers[s], centers[s+1], 0);
						data.set(index,spotvalue);
					}
				}
			}
		}
		if (dim == 3) {
			int32_t xskip = meshshape[0] / spotcount;
			int32_t yskip = meshshape[1] / spotcount;
			int32_t zskip = meshshape[2] / spotcount;
			int32_t xshift = xskip / 2;
			int32_t yshift = yskip / 2;
			int32_t zshift = zskip / 2;
			std::vector< int32_t> centers;
			int i = xskip - xshift;
			int j = yskip - yshift;
			int k = zskip - zshift;
			for ( ; i < meshshape[0] && j < meshshape[1] && k < meshshape[2]; ) {
				for (int32_t i1 = i - spotradius; i1 <= (i+spotradius); i1++) {
					for (int32_t j1 = j - spotradius; j1 <= (j+spotradius); j1++) {
						for (int32_t k1 = k - spotradius; k1 <= (k+spotradius); k1++) {
							centers.push_back(i1);
							centers.push_back(j1);
							centers.push_back(k1);
						}
					}
				}
				i += xskip; j += yskip; k += zskip;
			}
			for (int32_t ir = 0; ir < fv.getRegionCount(); ir++) {
				data = fv.getData(0, ir);
				first = fv.getLowerCorner(ir);
				last = fv.getUpperCorner(ir);
				sidl::array< int32_t > point = sidl::array< int32_t >::create1d(3);
				for (int32_t s = 0; s < centers.size(); s+=3) {
					point.set(0, centers[s]);
					point.set(1, centers[s+1]);
					point.set(2, centers[s+2]);
					if (m.boxContains(first, last, point)) {
						int32_t index = fv.coordToIndex(varnumber, first, last, centers[s], centers[s+1], centers[s+2]);
						data.set(index, spotvalue);
					}
				}
			}
		}
		
	}
	return 0;
  // DO-NOT-DELETE splicer.end(pde.ICspots.setInitialConditions)
}


// DO-NOT-DELETE splicer.begin(pde.ICspots._misc)
// Insert-Code-Here {pde.ICspots._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(pde.ICspots._misc)

