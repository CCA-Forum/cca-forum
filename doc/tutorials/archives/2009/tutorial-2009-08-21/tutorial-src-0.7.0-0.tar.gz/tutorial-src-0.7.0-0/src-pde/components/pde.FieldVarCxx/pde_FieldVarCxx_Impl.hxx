// 
// File:          pde_FieldVarCxx_Impl.hxx
// Symbol:        pde.FieldVarCxx-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.FieldVarCxx
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_pde_FieldVarCxx_Impl_hxx
#define included_pde_FieldVarCxx_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_pde_FieldVarCxx_IOR_h
#include "pde_FieldVarCxx_IOR.h"
#endif
#ifndef included_pde_BoundPos_hxx
#include "pde_BoundPos.hxx"
#endif
#ifndef included_pde_BoundaryCondition_hxx
#include "pde_BoundaryCondition.hxx"
#endif
#ifndef included_pde_FieldVar_hxx
#include "pde_FieldVar.hxx"
#endif
#ifndef included_pde_FieldVarCxx_hxx
#include "pde_FieldVarCxx.hxx"
#endif
#ifndef included_pde_Mesh_hxx
#include "pde_Mesh.hxx"
#endif
#ifndef included_pde_MeshColl_hxx
#include "pde_MeshColl.hxx"
#endif
#ifndef included_pde_Patch_hxx
#include "pde_Patch.hxx"
#endif
#ifndef included_pde_Region_hxx
#include "pde_Region.hxx"
#endif
#ifndef included_pde_RegionCxx_hxx
#include "pde_RegionCxx.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(pde.FieldVarCxx._hincludes)

#include <vector>
#include <map>

#ifdef HAVE_MPI 

#include <iostream>
#include <cassert>
#include "mpi.h"

/*
  This is a class that helps to perform non-blocking MPI_Isends and MPI_Irecvs. These
  non-blocking send and recvs are used to update ghost cells in a Region. The Request
  object does not care about Region per se, since it works with arrays. Each region
  can have separate arrays (1D sidl::array<double>) which contain data for a 1D/2D/3D physical
  space and for multiple variables, ie the sidl:array is NX * NY * NZ * NVARS long.

  When you form a request, you specify:

  0) What kind of a request this is - SEND or RECV.

  1) which dimension, idim, this request will deal with. Valid numbers are 0, 1 and 2.

  2) which side (iside) of this dimension it will deal with. Valid values are LO and HI = {0, 1}.
  This LO/HI is for the region for which the request is being prepared.

  3) which region (srcRegionId) will supply the data, and which processor (srcProcId) is it on.

  4) which region (destRegionId) will recv the data and which proc (destProcId) is it on. 
  (3) and (4) are used to make a tag for the message. A message being sent out has a tag =
  srcRegionId * 100 + 10*idim + iside (iside of the src region from where the data will be taken).
  

  5) shape of the region, whose data which will be sent over or received into. shape has to be 4 long.
  if a 2D region, make shape[2] = 1, and shape[3] = nvars

  6) stencil width and boundary width. (5) and (6) will be used to create a MPI_Datatype, to be
  used during data transfer.

  The object will contain 1 internal object of type MPI_Request and one of type MPI_Status.
  
  It will have the following methods

  MPI_Request getMPIRequest(), which returns the request it has. This is a shallow copy

  executeRequest(double *data), which has the pointer to a 1D array which contains the data
  to be transfered over. This is where an MPI_Isend or MPI_Irecv is executed and the MPI_Request
  object is filled up.
*/

namespace pde
{
    class NBRequest
    {
        public :

	typedef enum {ERROR_LOHISIDE = -1, LO, HI} LoHiSideType ;

	typedef enum {ERROR_SENDRECV = -1, SEND, RECV} SendRecvType ;

	NBRequest()
        {
	    isInit_ = false ;
	}

	void init( SendRecvType sendrecv, int32_t idim, LoHiSideType lohi, 
		   sidl::array<int32_t> shape, int32_t halowidth, int64_t  srcRegionId, 
		   int32_t srcProcId, int64_t destRegionId, int32_t destProcId, MPI_Comm comm )
	{
	    sendrecv_ = sendrecv ;
	    myDim_    = idim ;
	    lohi_     = lohi ;

	    nx_ = shape[0] ; ny_ = shape[1] ; nz_ = shape[2] ; nvars_ = shape[3] ; 
	    haloWidth_ = halowidth ;

	    srcProcId_   = srcProcId   ; destProcId_   = destProcId ;
	    srcRegionId_ = srcRegionId ; destRegionId_ = destRegionId ;

	    /*
	      Create a datatype that can automatically pull out or shove in the correct data into 
	      a 1D array. Note that this 1D array actually represents a 4D array, data(NX, NY, NZ, NVARS),
	      fortran style.
	    */
	    if ( myDim_ == 1 )
	    {
		MPI_Type_vector(ny_*nz_*nvars_, haloWidth_, nx_, MPI_DOUBLE, &dim1Datatype_) ;
		MPI_Type_commit(&dim1Datatype_) ;
	    }

	    if ( myDim_ == 2 )
	    {
		MPI_Type_vector(nz_*nvars_, nx_*haloWidth_, nx_*ny_, MPI_DOUBLE, &dim2Datatype_) ;
		MPI_Type_commit(&dim2Datatype_) ;
	    }

	    if ( myDim_ == 3 )
	    {
		MPI_Type_vector(nvars_, nx_*ny_*haloWidth_, nx_*ny_*nz_, MPI_DOUBLE, &dim3Datatype_) ;
		MPI_Type_commit(&dim3Datatype_) ;
	    }

	    comm_ = comm ;
	    isInit_ = true ;
	}

	bool getInitStatus() { return isInit_ ; }
	
	~NBRequest()
	 {
	     if (myDim_ == 1) MPI_Type_free( &dim1Datatype_ ) ;
	     if (myDim_ == 2) MPI_Type_free( &dim2Datatype_ ) ;
	     if (myDim_ == 3) MPI_Type_free( &dim3Datatype_ ) ;
	 }

	void executeNBRequest(double *data)
	{
	    assert(isInit_ == true) ;

	    MPI_Datatype *dtype ;
	    if (myDim_ == 1) dtype = &dim1Datatype_ ;
	    if (myDim_ == 2) dtype = &dim2Datatype_ ;
	    if (myDim_ == 3) dtype = &dim3Datatype_ ;

	    int rank ; MPI_Comm_rank(comm_, &rank) ;

	    if ( sendrecv_ == SEND )
	    {
		int tag = (int) srcRegionId_ * 100 + 10 * myDim_ + lohi_ ;

#ifdef DEBUG		
		std::cout << " Proc: " << rank << "; sending data to " << destProcId_
			  << " with tag " << tag << std:: endl << std::flush ;
#endif
		MPI_Isend(data, 1, *dtype, destProcId_, tag, comm_, &request_) ;
	    }
	    else if ( sendrecv_ == RECV )
	    {
		// if i am recv'ing and this data is supposed to come to my lo side, it must
		// be coming from the src's hi side and vice-versa. since the message tag is
		// in terms of the src's lo-hi side, we should use the src's lo-hi side, rather
		// than mine. Figure out which lo-hi index i should use.
		int srclohi ;
		if ( lohi_ == LO ) srclohi = HI ;
		if ( lohi_ == HI ) srclohi = LO ;
		int tag  = (int) srcRegionId_ * 100 + 10 * myDim_ + srclohi ;
#ifdef DEBUG
		std::cout << " Proc: " << rank << "; recving  data from " << srcProcId_
			  << " with tag " << tag << std:: endl << std::flush ;
#endif
		MPI_Irecv(data, 1, *dtype, srcProcId_, tag, comm_, &request_) ;
	    }
	    else
	    {
		std::cerr << " pde::NBRequest::executeNBRequest(): sendrecv type " 
			  << sendrecv_ << " not recognised. Exit " << std::endl ;
		std::terminate();
	    }
	}

	MPI_Request getMPIRequest() {return request_ ;}

	SendRecvType getSendRecvType() { return sendrecv_ ; }

        private :

	bool isInit_ ;

	int32_t myDim_, haloWidth_, srcProcId_, destProcId_ ;
	int64_t srcRegionId_, destRegionId_ ;

	LoHiSideType lohi_ ;
	SendRecvType sendrecv_ ;

	int nx_, ny_, nz_, nvars_ ;

	MPI_Datatype dim1Datatype_, dim2Datatype_, dim3Datatype_ ;
	MPI_Request request_ ;
	MPI_Comm comm_ ;
    } ;
};
 
#endif // End of HAVE_MPI

// extern "C" 
// {
//     struct MPI_Request 
//     {
// 	int dummy;
//     };
// }

// DO-NOT-DELETE splicer.end(pde.FieldVarCxx._hincludes)

// DO-NOT-DELETE splicer.begin(pde.FieldVarCxx._includes)

#include <vector>
#include <map>

#ifdef HAVE_MPI 

#include <iostream>
#include <cassert>
#include "mpi.h"

/*
  This is a class that helps to perform non-blocking MPI_Isends and MPI_Irecvs. These
  non-blocking send and recvs are used to update ghost cells in a Region. The Request
  object does not care about Region per se, since it works with arrays. Each region
  can have separate arrays (1D sidl::array<double>) which contain data for a 1D/2D/3D physical
  space and for multiple variables, ie the sidl:array is NX * NY * NZ * NVARS long.

  When you form a request, you specify:

  0) What kind of a request this is - SEND or RECV.

  1) which dimension, idim, this request will deal with. Valid numbers are 0, 1 and 2.

  2) which side (iside) of this dimension it will deal with. Valid values are LO and HI = {0, 1}.
  This LO/HI is for the region for which the request is being prepared.

  3) which region (srcRegionId) will supply the data, and which processor (srcProcId) is it on.

  4) which region (destRegionId) will recv the data and which proc (destProcId) is it on. 
  (3) and (4) are used to make a tag for the message. A message being sent out has a tag =
  srcRegionId * 100 + 10*idim + iside (iside of the src region from where the data will be taken).
  

  5) shape of the region, whose data which will be sent over or received into. shape has to be 4 long.
  if a 2D region, make shape[2] = 1, and shape[3] = nvars

  6) stencil width and boundary width. (5) and (6) will be used to create a MPI_Datatype, to be
  used during data transfer.

  The object will contain 1 internal object of type MPI_Request and one of type MPI_Status.
  
  It will have the following methods

  MPI_Request getMPIRequest(), which returns the request it has. This is a shallow copy

  executeRequest(double *data), which has the pointer to a 1D array which contains the data
  to be transfered over. This is where an MPI_Isend or MPI_Irecv is executed and the MPI_Request
  object is filled up.
*/

namespace pde
{
    class NBRequest
    {
        public :

	typedef enum {ERROR_LOHISIDE = -1, LO, HI} LoHiSideType ;

	typedef enum {ERROR_SENDRECV = -1, SEND, RECV} SendRecvType ;

	NBRequest()
        {
	    isInit_ = false ;
	}

	void init( SendRecvType sendrecv, int32_t idim, LoHiSideType lohi, 
		   sidl::array<int32_t> shape, int32_t halowidth, int64_t  srcRegionId, 
		   int32_t srcProcId, int64_t destRegionId, int32_t destProcId, MPI_Comm comm )
	{
	    sendrecv_ = sendrecv ;
	    myDim_    = idim ;
	    lohi_     = lohi ;

	    nx_ = shape[0] ; ny_ = shape[1] ; nz_ = shape[2] ; nvars_ = shape[3] ; 
	    haloWidth_ = halowidth ;

	    srcProcId_   = srcProcId   ; destProcId_   = destProcId ;
	    srcRegionId_ = srcRegionId ; destRegionId_ = destRegionId ;

	    /*
	      Create a datatype that can automatically pull out or shove in the correct data into 
	      a 1D array. Note that this 1D array actually represents a 4D array, data(NX, NY, NZ, NVARS),
	      fortran style.
	    */
	    if ( myDim_ == 1 )
	    {
		MPI_Type_vector(ny_*nz_*nvars_, haloWidth_, nx_, MPI_DOUBLE, &dim1Datatype_) ;
		MPI_Type_commit(&dim1Datatype_) ;
	    }

	    if ( myDim_ == 2 )
	    {
		MPI_Type_vector(nz_*nvars_, nx_*haloWidth_, nx_*ny_, MPI_DOUBLE, &dim2Datatype_) ;
		MPI_Type_commit(&dim2Datatype_) ;
	    }

	    if ( myDim_ == 3 )
	    {
		MPI_Type_vector(nvars_, nx_*ny_*haloWidth_, nx_*ny_*nz_, MPI_DOUBLE, &dim3Datatype_) ;
		MPI_Type_commit(&dim3Datatype_) ;
	    }

	    comm_ = comm ;
	    isInit_ = true ;
	}

	bool getInitStatus() { return isInit_ ; }
	
	~NBRequest()
	 {
	     if (myDim_ == 1) MPI_Type_free( &dim1Datatype_ ) ;
	     if (myDim_ == 2) MPI_Type_free( &dim2Datatype_ ) ;
	     if (myDim_ == 3) MPI_Type_free( &dim3Datatype_ ) ;
	 }

	void executeNBRequest(double *data)
	{
	    assert(isInit_ == true) ;

	    MPI_Datatype *dtype ;
	    if (myDim_ == 1) dtype = &dim1Datatype_ ;
	    if (myDim_ == 2) dtype = &dim2Datatype_ ;
	    if (myDim_ == 3) dtype = &dim3Datatype_ ;

	    int rank ; MPI_Comm_rank(comm_, &rank) ;

	    if ( sendrecv_ == SEND )
	    {
		int tag = (int) srcRegionId_ * 100 + 10 * myDim_ + lohi_ ;

#ifdef DEBUG		
		std::cout << " Proc: " << rank << "; sending data to " << destProcId_
			  << " with tag " << tag << std:: endl << std::flush ;
#endif
		MPI_Isend(data, 1, *dtype, destProcId_, tag, comm_, &request_) ;
	    }
	    else if ( sendrecv_ == RECV )
	    {
		// if i am recv'ing and this data is supposed to come to my lo side, it must
		// be coming from the src's hi side and vice-versa. since the message tag is
		// in terms of the src's lo-hi side, we should use the src's lo-hi side, rather
		// than mine. Figure out which lo-hi index i should use.
		int srclohi ;
		if ( lohi_ == LO ) srclohi = HI ;
		if ( lohi_ == HI ) srclohi = LO ;
		int tag  = (int) srcRegionId_ * 100 + 10 * myDim_ + srclohi ;
#ifdef DEBUG
		std::cout << " Proc: " << rank << "; recving  data from " << srcProcId_
			  << " with tag " << tag << std:: endl << std::flush ;
#endif
		MPI_Irecv(data, 1, *dtype, srcProcId_, tag, comm_, &request_) ;
	    }
	    else
	    {
		std::cerr << " pde::NBRequest::executeNBRequest(): sendrecv type " 
			  << sendrecv_ << " not recognised. Exit " << std::endl ;
		std::terminate();
	    }
	}

	MPI_Request getMPIRequest() {return request_ ;}

	SendRecvType getSendRecvType() { return sendrecv_ ; }

        private :

	bool isInit_ ;

	int32_t myDim_, haloWidth_, srcProcId_, destProcId_ ;
	int64_t srcRegionId_, destRegionId_ ;

	LoHiSideType lohi_ ;
	SendRecvType sendrecv_ ;

	int nx_, ny_, nz_, nvars_ ;

	MPI_Datatype dim1Datatype_, dim2Datatype_, dim3Datatype_ ;
	MPI_Request request_ ;
	MPI_Comm comm_ ;
    } ;
};
 
#endif // End of HAVE_MPI

// extern "C" 
// {
//     struct MPI_Request 
//     {
// 	int dummy;
//     };
// }

// DO-NOT-DELETE splicer.end(pde.FieldVarCxx._includes)

namespace pde { 

  /**
   * Symbol "pde.FieldVarCxx" (version 0.0)
   */
  class FieldVarCxx_impl : public virtual ::pde::FieldVarCxx 
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx._inherits)
  // Insert-Code-Here {pde.FieldVarCxx._inherits} (optional inheritance here)
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

      bool _wrapped;
      
      // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx._implementation)
      bool inited;
      bool forceReceives;
      std::vector< pde::RegionCxx > regions; 
      std::map< int64_t, int32_t > regionindex; // key globalid, value index in regions vector
      

      ::std::string fname;
      int32_t fnvars, d_dim, d_stencil;
      ::pde::MeshColl coll;
      ::pde::Mesh mesh;
      ::pde::BoundaryCondition boundary;
      
      int32_t tcur;
      
      // return low and high enum values for the dim given.
      void dim2BoundPos(int32_t dim, pde::BoundPos & lo, pde::BoundPos & hi);

#ifdef HAVE_MPI
      std::vector< ::pde::NBRequest * > recvReqs_, sendReqs_ ;

      void updateGhostsPostRecvs_( ::pde::Patch &srcPatch, ::pde::RegionCxx &destRegion,
				   int idim, ::pde::NBRequest::LoHiSideType lohi, 
				   int64_t time, ::pde::NBRequest *request) ;

      void updateGhostsPostSends_( ::pde::RegionCxx &srcRegion, ::pde::Patch &destPatch,
				   int idim, ::pde::NBRequest::LoHiSideType lohi, 
				   int64_t time, ::pde::NBRequest *request) ;
#endif
      
    // DO-NOT-DELETE splicer.end(pde.FieldVarCxx._implementation)

  public:
    // default constructor, used for data wrapping(required)
    FieldVarCxx_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    FieldVarCxx_impl( struct pde_FieldVarCxx__object * s ) : StubBase(s,true), 
      _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~FieldVarCxx_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    void
    init_impl (
      /* in */const ::std::string& name,
      /* in */int32_t nvars,
      /* in */::pde::MeshColl T,
      /* in */::pde::BoundaryCondition bc,
      /* in */::pde::Mesh m,
      /* in array<pde.Patch> */::sidl::array< ::pde::Patch> localpatches
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    finalize_impl() ;
    /**
     * user defined non-static method.
     */
    void
    updateGhosts_impl (
      /* in */::pde::BoundPos direction,
      /* in */::pde::RegionCxx source,
      /* inout */::pde::RegionCxx& dest
    )
    ;


    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude_impl (
      /* in */::pde::Patch dummy0,
      /* in */::pde::RegionCxx dummy1,
      /* in */::pde::BoundPos dummy2,
      /* in */::pde::Mesh dummy3,
      /* in */::pde::Region dummy4
    )
    ;


    /**
     *  what's the spatial dimension of the data ? Error returns -1 
     */
    int32_t
    getDimension_impl() ;

    /**
     *  @return number of regions assigned to the local process. The
     * regionIds used in other functions range [0 - getRegionCount()-1]
     */
    int32_t
    getRegionCount_impl() ;

    /**
     *  number of dependent vars in the vector. 
     */
    int32_t
    getNVars_impl() ;

    /**
     *  
     * @return lower bounding box corner of the regionId given.
     * result array will be getDimension() long.
     */
    ::sidl::array<int32_t>
    getLowerCorner_impl (
      /* in */int32_t regionId
    )
    ;


    /**
     *  
     * @return upper bounding box corner of the local regionId given.
     * result array will be getDimension() long.
     */
    ::sidl::array<int32_t>
    getUpperCorner_impl (
      /* in */int32_t regionId
    )
    ;


    /**
     *  @return  array 'dimension' long with sizes in X,Y,Z directions. 
     */
    ::sidl::array<int32_t>
    getShape_impl (
      /* in */int32_t regionId
    )
    ;

    /**
     * user defined non-static method.
     */
    ::pde::Patch
    getPatch_impl (
      /* in */int32_t regionId
    )
    ;


    /**
     *  @param regionId in range [0..getRegionCount).
     * @return 1d array with size the product of getShape()[i] for all i=[0.dim-1].
     */
    ::sidl::array<double>
    getData_impl (
      /* in */int32_t time,
      /* in */int32_t regionId
    )
    ;


    /**
     *  Get mesh position indices from corners and position in 1d data array if all from the same regionId.
     * outputs are undefined if first/last are outside dimensions [1..3].
     * @param index position in data 1d array.
     * @param lowerCorner
     * @param upperCorner
     * @param i0 output index in dimension 0.
     * @param i1 output index in dimension 0 if 2 or 3d, else undefined.
     * @param i2 output index in dimension 0 if 2 or 3d, else undefined.
     */
    void
    indexToCoord_impl (
      /* in */int32_t index,
      /* in array<int> */::sidl::array<int32_t> lowerCorner,
      /* in array<int> */::sidl::array<int32_t> upperCorner,
      /* out */int32_t& i0,
      /* out */int32_t& i1,
      /* out */int32_t& i2
    )
    ;


    /**
     *  Get position in 1d data array from mesh position indices if all from the same regionId.
     * Output is undefined if first/last are outside dimensions [1..3].
     * @param varNumber a number from [0..getNVars-1].
     * @param lowerCorner
     * @param upperCorner
     * @param i0 output index in dimension 0.
     * @param i1 output index in dimension 0 if 2 or 3d, else undefined.
     * @param i2 output index in dimension 0 if 2 or 3d, else undefined.
     * @return index position in data 1d array.
     */
    int32_t
    coordToIndex_impl (
      /* in */int32_t varNumber,
      /* in array<int> */::sidl::array<int32_t> lowerCorner,
      /* in array<int> */::sidl::array<int32_t> upperCorner,
      /* in */int32_t i0,
      /* in */int32_t i1,
      /* in */int32_t i2
    )
    ;


    /**
     *  get the type of mesh collocation you have 
     */
    ::pde::MeshColl
    getMeshColl_impl() ;

    /**
     *  get name of this fieldvariable. 
     */
    ::std::string
    getName_impl() ;

    /**
     *  @return Width of the halo/ghost cells for stencil purposes. 
     */
    int32_t
    getStencilWidth_impl() ;

    /**
     *  @return Width of the halo cells for BC purposes. 
     */
    int32_t
    getBoundaryWidth_impl() ;
    /**
     * user defined non-static method.
     */
    void
    dim2BoundPos_impl (
      /* in */int32_t dim,
      /* out */::pde::BoundPos& lo,
      /* out */::pde::BoundPos& hi
    )
    ;


    /**
     *  BC and adapt bndry update. 
     */
    int32_t
    boundaryUpdate_impl (
      /* in */int32_t time
    )
    ;


    /**
     *  @return total ticks recorded. 
     */
    int32_t
    getCurrentTime_impl() ;

    /**
     *  increment time (add 1 to total ticks recorded). Success return 0 
     */
    int32_t
    incrementTime_impl() ;

    /**
     *  @name  Data movement, swap, copy methods
     * @return  Error returns -1, else 0
     */
    int32_t
    cycleTimes_impl() ;

    /**
     *  update ghost cells for time given. 
     */
    int32_t
    synchronize_impl (
      /* in */int32_t time
    )
    ;

  };  // end class FieldVarCxx_impl

} // end namespace pde

// DO-NOT-DELETE splicer.begin(pde.FieldVarCxx._misc)
// Insert-Code-Here {pde.FieldVarCxx._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(pde.FieldVarCxx._misc)

#endif
