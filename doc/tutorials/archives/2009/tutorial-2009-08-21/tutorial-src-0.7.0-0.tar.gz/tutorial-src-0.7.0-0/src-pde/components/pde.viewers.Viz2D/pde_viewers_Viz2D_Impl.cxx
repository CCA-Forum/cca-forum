// 
// File:          pde_viewers_Viz2D_Impl.cxx
// Symbol:        pde.viewers.Viz2D-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.viewers.Viz2D
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_viewers_Viz2D_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_bsl_arr_hxx
#include "bsl_arr.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_ParameterPortFactory_hxx
#include "gov_cca_ports_ParameterPortFactory.hxx"
#endif
#ifndef included_pde_BoundPos_hxx
#include "pde_BoundPos.hxx"
#endif
#ifndef included_pde_FieldVar_hxx
#include "pde_FieldVar.hxx"
#endif
#ifndef included_pde_Mesh_hxx
#include "pde_Mesh.hxx"
#endif
#ifndef included_pde_Patch_hxx
#include "pde_Patch.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D._includes)

  // Insert-UserCode-Here {pde.viewers.Viz2D._includes:prolog} (additional includes or code)

#include <cstring>

  // Bocca generated code. bocca.protected.begin(pde.viewers.Viz2D._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.viewers.Viz2D._includes)

  // Insert-UserCode-Here {pde.viewers.Viz2D._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::viewers::Viz2D_impl::Viz2D_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::viewers::Viz2D::_wrapObj(reinterpret_cast< void*>(this))),false) , 
  _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D._ctor2)
  // Insert-Code-Here {pde.viewers.Viz2D._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D._ctor2)
}

// user defined constructor
void pde::viewers::Viz2D_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D._ctor)
    
  // Insert-UserCode-Here {pde.viewers.Viz2D._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(pde.viewers.Viz2D._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.viewers.Viz2D: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.viewers.Viz2D._ctor)

  // Insert-UserCode-Here {pde.viewers.Viz2D._ctor:epilog} (constructor method)

	// Initialize Internal Settings

	// File Name Prefix
	FILE_PREFIX = "vizzer.";

	// Display Size
	GIF_HEIGHT = 800;
	GIF_WIDTH = 800;

	// Color Map

	COLOR_MIN_VALUE = -1000.0;
	COLOR_MAX_VALUE = 1000.0;

	COLOR_MAP_INITD = 0;

	AUTO_COLOR_MAP = 0;
	LAZY_COLOR_MAP = 1;

	// Verbosity
	vflag = 1;

	// Global Decomposition
	// - initially not set, default behavior is that there
	// *is* no global decomposition...  :-)
	GLB[0] = GLB[1] = -1;
	GUB[0] = GUB[1] = -1;

	// Initialize Global Data Holder Pointer
	GDATA = (double *) NULL;
	GSIZE = -1;

	// Use Boundaries in Image Flag by Default
	// useBoundsFlag = 1;
	useBoundsFlag = 0;

	// Assemble Animated Images...
	animateFramesFlag = 0;

	// Cruft to Keep Track of Any Animated Gifs In Progress...  :-o
	for ( int f=0 ; f < 100 ; f++ ) {
		openAnimFilePointers[f] = (FILE *) NULL;
		openAnimFileNames[f] = (char *) NULL;
	}
	numOpenAnimFiles = 0;

	// Output Format
	GDFORMAT = VIZGIFFER_GIF;

	// Sequence Counter
	SEQUENCE = 0;

#ifdef HAVE_MPI
	// Clear MPI Communicator Setting
	COMM = MPI_COMM_WORLD;
	useMPI = 1;
#endif

  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D._ctor)
}

// user defined destructor
void pde::viewers::Viz2D_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D._dtor)
  // Insert-UserCode-Here {pde.viewers.Viz2D._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.viewers.Viz2D._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.viewers.Viz2D: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.viewers.Viz2D._dtor) 

	// Free Any Global Data Holder Storage
	if ( GDATA != NULL )
	{
		FREE( GDATA );
		GDATA = (double *) NULL;

		GSIZE = -1;
	}

	// Finish and Close Any Open Animation File Pointers!
	for ( int f=0 ; f < numOpenAnimFiles ; f++ ) {
		if ( openAnimFilePointers[f] != NULL ) {
			std::cout << "Finishing Animation File \""
					<< openAnimFileNames[f] << "\""
					<< std::endl;
			gdImageGifAnimEnd( openAnimFilePointers[f] );
			std::cout << "Closing Animation File \""
					<< openAnimFileNames[f] << "\""
					<< std::endl;
			fclose( openAnimFilePointers[f] );
			std::cout << "Freeing Animation File \""
					<< openAnimFileNames[f] << "\" List Info"
					<< std::endl;
			openAnimFilePointers[f] = (FILE *) NULL;
			if ( openAnimFileNames[f] != NULL ) {
				FREE( openAnimFileNames[f] );
				openAnimFileNames[f] = (char *) NULL;
			}
		}
	}

  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D._dtor)
}

// static class initializer
void pde::viewers::Viz2D_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D._load)
  // Insert-Code-Here {pde.viewers.Viz2D._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
pde::viewers::Viz2D_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.viewers.Viz2D.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "pde.viewers.Viz2D: Error casting self to gov::cca::Port");
  } 


  // Provide a pde.RenderPort port with port name vizzer 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "vizzer", // port instance name
                   "pde.RenderPort",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "pde.viewers.Viz2D: Error calling addProvidesPort(port,"
        "\"vizzer\", \"pde.RenderPort\", typeMap) ", -2);
    throw;
  }    

  // Use a gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    this->d_services.registerUsesPort(
                   "ppf", // port instance name
                   "gov.cca.ports.ParameterPortFactory",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.viewers.Viz2D: Error calling registerUsesPort(\"ppf\", "
       "\"gov.cca.ports.ParameterPortFactory\", typeMap) ", -2);
    throw;
  }


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(pde.viewers.Viz2D.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
pde::viewers::Viz2D_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.viewers.Viz2D.boccaReleaseServices)
  this->d_services=0;


  // Un-provide pde.RenderPort port with port name vizzer 
  try{
    services.removeProvidesPort("vizzer");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.viewers.Viz2D: Error calling removeProvidesPort("
              << "\"vizzer\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    services.unregisterUsesPort("ppf");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.viewers.Viz2D: Error calling unregisterUsesPort("
              << "\"ppf\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(pde.viewers.Viz2D.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::viewers::Viz2D_impl::boccaForceUsePortInclude_impl (
  /* in */::gov::cca::ports::ParameterPortFactory dummy0,
  /* in */::pde::Patch dummy1,
  /* in */::pde::BoundPos dummy2,
  /* in */::bsl::arr dummy3 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.viewers.Viz2D.boccaForceUsePortInclude)
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;
    (void)dummy3;

  // Bocca generated code. bocca.protected.end(pde.viewers.Viz2D.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
pde::viewers::Viz2D_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D.setServices)

  // Insert-UserCode-Here{pde.viewers.Viz2D.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(pde.viewers.Viz2D.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(pde.viewers.Viz2D.setServices)
  
  // Insert-UserCode-Here{pde.viewers.Viz2D.setServices:epilog}

  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
pde::viewers::Viz2D_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D.releaseServices)

  // Insert-UserCode-Here {pde.viewers.Viz2D.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(pde.viewers.Viz2D.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(pde.viewers.Viz2D.releaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D.releaseServices)
}

/**
 * Method:  setOutput[]
 */
void
pde::viewers::Viz2D_impl::setOutput_impl (
  /* in */const ::std::string& destination ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D.setOutput)
  // Insert-Code-Here {pde.viewers.Viz2D.setOutput} (setOutput method)
    
	FILE_PREFIX = destination;
    
  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D.setOutput)
}

/**
 * Method:  setIncludeBoundaries[]
 */
void
pde::viewers::Viz2D_impl::setIncludeBoundaries_impl (
  /* in */int32_t useBounds ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D.setIncludeBoundaries)
    
	useBoundsFlag = useBounds;
    
  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D.setIncludeBoundaries)
}

/**
 * Method:  setAnimateImages[]
 */
void
pde::viewers::Viz2D_impl::setAnimateImages_impl (
  /* in */int32_t animateFrames ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D.setAnimateImages)
    
	animateFramesFlag = animateFrames;
    
  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D.setAnimateImages)
}

/**
 * Method:  showMesh[]
 */
void
pde::viewers::Viz2D_impl::showMesh_impl (
  /* in */::pde::Mesh m ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D.showMesh)
	std::cout << "pde.viewers.Viz2D.showMesh not implemented (and not planned?)" << std::endl; 
  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D.showMesh)
}

/**
 * Method:  showField[]
 */
void
pde::viewers::Viz2D_impl::showField_impl (
  /* in */::pde::Mesh m,
  /* in */::pde::FieldVar fv ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D.showField)
  // Insert-Code-Here {pde.viewers.Viz2D.showField} (showField method)
    
	std::cout << "showField(): Field Name = " << fv.getName()
		<< std::endl;

#ifdef HAVE_MPI
	// Is there anybody out there...?
	if ( m.getProcCount() > 1 ) {
		int64_t fieldComm = m.getCommunicator();
		setMPIComm( fieldComm );
		useMPI = 1;
	}
	// Nope, we're all alone...  (snif)
	else {
		useMPI = 0;
	}
#endif

	sidl::array< int32_t > meshShape = m.getShape();

	int nDims = m.getDimension();

	if ( nDims > 2 ) {
		std::cout << "showField() Uh-Oh, nDims=" << nDims
			<< " Not Supported...  :-o"
			<< std::endl;
		std::cout << "showField() Bailing Out..."
			<< std::endl;
		return;
	}

	for ( int i=0 ; i < nDims ; i++ ) {
		std::cout << "meshShape[" << i << "]=" << meshShape[i]
				<< std::endl;
	}

	int fieldTime = m.currentTime();

	int numFieldRegions = fv.getRegionCount();

	int dumpFile = 1;

	for ( int fr=0 ; fr < numFieldRegions ; fr++ ) {

		std::cout << "Field Region #" << fr << std::endl;

		sidl::array< int32_t > lowerCorner = fv.getLowerCorner( fr );
		sidl::array< int32_t > upperCorner = fv.getUpperCorner( fr );

		sidl::array< int32_t > fieldShape = fv.getShape( fr );

		sidl::array< double > fieldData = fv.getData( fieldTime, fr );

		for ( int i=0 ; i < nDims ; i++ ) {
			std::cout << "lowerCorner[" << i << "]=" << lowerCorner[i]
					<< std::endl;
			std::cout << "upperCorner[" << i << "]=" << upperCorner[i]
					<< std::endl;
			std::cout << "fieldShape[" << i << "]=" << fieldShape[i]
					<< std::endl;
		}

		int stencilWidth = fv.getStencilWidth();

		int boundaryWidth = fv.getBoundaryWidth();

		Patch fieldPatch = fv.getPatch( fr );

		sidl::array< pde::BoundPos > boundaries =
		// sidl::array< int64_t > boundaries =
				fieldPatch.getBoundaryDirections();

		int rowLowBoundWidth = boundaryWidth;
		int rowHighBoundWidth = boundaryWidth;

		int colLowBoundWidth = boundaryWidth;
		int colHighBoundWidth = boundaryWidth;

		for ( int i=0 ;
				boundaries._not_nil() && i <= boundaries.upper(0) ;
				i++ ) {

			pde::BoundPos pos =
					boundaries[i];
					// static_cast< pde::BoundPos >(boundaries[i]);

			std::cout << "loop i=" << i << ": "
					<< "boundaries pos = " << pos
					<< std::endl;

			switch ( pos ) {

				case pde::BoundPos_LOW0: {
					std::cout << "boundaries[" << i << "] = LOW0: "
							<< "incrementing rowLowBoundWidth by "
							<< stencilWidth << std::endl;
					rowLowBoundWidth += stencilWidth;
					break;
				}

				case pde::BoundPos_HIGH0: {
					std::cout << "boundaries[" << i << "] = HIGH0: "
							<< "incrementing rowHighBoundWidth by "
							<< stencilWidth << std::endl;
					rowHighBoundWidth += stencilWidth;
					break;
				}

				case pde::BoundPos_LOW1: {
					std::cout << "boundaries[" << i << "] = LOW1: "
							<< "incrementing colLowBoundWidth by "
							<< stencilWidth << std::endl;
					colLowBoundWidth += stencilWidth;
					break;
				}

				case pde::BoundPos_HIGH1: {
					std::cout << "boundaries[" << i << "] = HIGH1: "
							<< "incrementing colHighBoundWidth by "
							<< stencilWidth << std::endl;
					colHighBoundWidth += stencilWidth;
					break;
				}

				case pde::BoundPos_LOW2: {
					std::cout << "boundaries[" << i << "] = LOW2: "
							<< "ignoring, no 3-D handling yet..."
							<< std::endl;
					// 3rd Dimension...  :-o
					break;
				}

				case pde::BoundPos_HIGH2: {
					std::cout << "boundaries[" << i << "] = HIGH2: "
							<< "ignoring, no 3-D handling yet..."
							<< std::endl;
					// 3rd Dimension...  :-o
					break;
				}

				default: {
					BOCCA_THROW_CXX( sidl::SIDLException,
							"unexpected bound enum value." );
				}
			}
		}

		std::cout << "pde::viewers::Viz2D_impl::showField():"
				<< " rowLowBoundWidth=" << rowLowBoundWidth
				<< " rowHighBoundWidth=" << rowHighBoundWidth
				<< " colLowBoundWidth=" << colLowBoundWidth
				<< " colHighBoundWidth=" << colHighBoundWidth
				<< std::endl;

		if ( useBoundsFlag == 0 ) {

			std::cout << "Bounds Not Used in Image..." << std::endl;

			if ( nDims == 1 ) {

				setGlobalBounds( 0, 0, 0, meshShape[0] - 1 );

				initializeGlobalData( !fr );

				collectVizData( fv.getName().c_str(), fieldData,
						0, 0,
						// colLowBoundWidth, colHighBoundWidth,
						boundaryWidth, boundaryWidth,
						1, fieldShape[0],
						0, lowerCorner[0] );
			}

			else if ( nDims == 2 ) {

				setGlobalBounds( 0, 0, meshShape[0] - 1, meshShape[1] - 1 );

				initializeGlobalData( !fr );

				collectVizData( fv.getName().c_str(), fieldData,
						// rowLowBoundWidth, rowHighBoundWidth,
						// colLowBoundWidth, colHighBoundWidth,
						boundaryWidth, boundaryWidth,
						boundaryWidth, boundaryWidth,
						fieldShape[0], fieldShape[1],
						lowerCorner[0] + boundaryWidth,
						lowerCorner[1] + boundaryWidth );
			}

			dumpFile = 1;
		}

		else {

			std::cout << "Using Patch Bounds in Image..." << std::endl;
			std::cout << "Generate Separate Image Per Patch." << std::endl;

			// Allocate storage and copy over local data...

			double *data2D = (double *) MALLOC(
					fieldShape[0] * fieldShape[1] * sizeof( double ) );

			if ( data2D == NULL ) {
				std::cout
						<< "pde::viewers::Viz2D_impl::showField(): "
						<< "destination array is nil!" << std::endl;
				return;
			}

			int nrows = 0, ncols = 0;

			if ( nDims == 1 ) {
				nrows = 1;
				ncols = fieldShape[0];
			}

			else if ( nDims == 2 ) {
				nrows = fieldShape[0];
				ncols = fieldShape[1];
			}

			double *ptr;

			double dval;

			if ( fieldData.dimen() == 1 ) {

				ptr = data2D;

				for ( int i=0 ; i < nrows ; i++ )
				{
					for ( int j=0 ; j < ncols ; j++ )
					{
						dval = fieldData.get( ( i * ncols ) + j );

						std::cout << "i=" << i << " j=" << j
								<< " fieldData.get( "
								<< ( i * ncols ) + j
								<< " ) = " << dval << std::endl;

						*ptr++ = dval;
					}
				}
			}

			else if ( fieldData.dimen() == 2 ) {

				for ( int i=0 ; i < nrows ; i++ )
				{
					for ( int j=0 ; j < ncols ; j++ )
					{
						dval = fieldData.get( i, j );

						std::cout << "fieldData.get( " << i << ", " << j
								<< " ) = " << dval << std::endl;

						*ptr++ = dval;
					}
				}
			}

			else {
				std::cout << "pde::viewers::Viz2D_impl::showField(): "
						<< "unsupported data array dimension = "
						<< fieldData.dimen() << std::endl;
			}

			// Create SIDL array...

			::sidl::array<double> vdata;

			char fname[1024];

			int lower[2], upper[2];
			int strides[2];

			lower[0] = lower[1] = 0;
			// upper[0] = nrows;  upper[1] = ncols;
			upper[0] = ncols;  upper[1] = nrows;

			// strides[0] = ncols;  strides[1] = 1;
			strides[0] = nrows;  strides[1] = 1;

			vdata.borrow( data2D, 2, lower, upper, strides );

			if ( vdata._is_nil() ) {
				std::cout
						<< "pde::viewers::Viz2D_impl::showField(): "
						<< "vdata is nil!" << std::endl;
				return;
			}

			// Dump a Gif image file for my local data

			if ( animateFramesFlag == 0 ) {
				sprintf( fname, "%s.%s.%05d.patch%d",
						(char *) FILE_PREFIX.c_str(), fv.getName().c_str(),
						SEQUENCE, fr );
			}

			// Omit Sequence and Patch Number for Animated GIFs...

			else {
				sprintf( fname, "%s.%s.patch",
						(char *) FILE_PREFIX.c_str(),
						fv.getName().c_str() );
			}

			if ( vflag )
				std::cout << "showField() dumping to " << fname
						<< std::endl;

			do_dump_gif_file( vdata, upper[0], upper[1], fname );

			/*
			if ( nDims == 1 ) {

				setGlobalBounds( 0, -colLowBoundWidth,
						0, meshShape[0] + colHighBoundWidth );

				initializeGlobalData( !fr );

				collectVizData( fv.getName().c_str(), fieldData,
						0, 0, 0, 0,
						1, fieldShape[0],
						0, lowerCorner[0] );
			}

			else if ( nDims == 2 ) {

				setGlobalBounds( -rowLowBoundWidth, -colLowBoundWidth,
						meshShape[0] + rowHighBoundWidth,
						meshShape[1] + colHighBoundWidth );

				initializeGlobalData( !fr );

				collectVizData( fv.getName().c_str(), fieldData,
						0, 0, 0, 0,
						fieldShape[0], fieldShape[1],
						lowerCorner[0],
						lowerCorner[1] );
			}
			*/

			dumpFile = 0;
		}
	}

	if ( dumpFile )
		dumpVizFile( fv.getName().c_str() );

  // DO-NOT-DELETE splicer.end(pde.viewers.Viz2D.showField)
}


// DO-NOT-DELETE splicer.begin(pde.viewers.Viz2D._misc)
// Insert-Code-Here {pde.viewers.Viz2D._misc} (miscellaneous code)


#ifdef HAVE_MPI
void pde::viewers::Viz2D_impl::setMPIComm( int64_t comm ) {
	COMM = (MPI_Comm) MPI_Comm_f2c( comm );
}
#endif

void pde::viewers::Viz2D_impl::setDisplaySize(
		int32_t width, int32_t height ) {
	GIF_HEIGHT = height;
	GIF_WIDTH = width;
}

void pde::viewers::Viz2D_impl::setColorMapAuto() {
	AUTO_COLOR_MAP = 1;
	LAZY_COLOR_MAP = 0;
}

void pde::viewers::Viz2D_impl::setColorMapLazy() {
	LAZY_COLOR_MAP = 1;
	AUTO_COLOR_MAP = 0;
}

void pde::viewers::Viz2D_impl::setColorMapRange(
		double min, double max ) {
	COLOR_MIN_VALUE = min;
	COLOR_MAX_VALUE = max;
}

void pde::viewers::Viz2D_impl::setOutputFormatGif() {
	GDFORMAT = VIZGIFFER_GIF;
}

void pde::viewers::Viz2D_impl::setOutputFormatJpeg() {
	GDFORMAT = VIZGIFFER_JPEG;
}

void pde::viewers::Viz2D_impl::setOutputFormatPng() {
	GDFORMAT = VIZGIFFER_PNG;
}

void pde::viewers::Viz2D_impl::setVerbose( int32_t onoff ) {
	vflag = onoff;
}

void pde::viewers::Viz2D_impl::setGlobalBounds(
		int32_t glbrow, int32_t glbcol,
		int32_t gubrow, int32_t gubcol ) {

	// Save Global Bound Values

	if ( vflag )
		std::cout << "pde::viewers::Viz2D_impl::setGlobalBounds(): "
				<< "glbrow=" << glbrow << " glbcol=" << glbcol
				<< " gubrow=" << gubrow << " gubcol=" << gubcol
				<< std::endl;

	GLB[0] = glbrow;
	GLB[1] = glbcol;

	GUB[0] = gubrow;
	GUB[1] = gubcol;
}

void pde::viewers::Viz2D_impl::initializeGlobalData( int32_t doClear ) {

	int myrank;

#ifdef HAVE_MPI
	// Check on our MPI situation...
	get_mpi_info( (MPI_Comm *) NULL, &myrank, (int *) NULL );
#else
	myrank = 0;
#endif

	// Make sure any global storage is allocated...

	allocate_global_data( myrank );

	// Handle Any Global Decomposition

	if ( GDATA && doClear ) {

		// Initialize the Global Data Storage

		for ( int i=0 ; i < GSIZE ; i++ )
			GDATA[i] = -1;
	}
}

void pde::viewers::Viz2D_impl::collectVizData(
		const char *fieldName, ::sidl::array<double> data,
		int32_t rowLowBoundWidth, int32_t rowHighBoundWidth,
		int32_t colLowBoundWidth, int32_t colHighBoundWidth,
		int32_t nrows, int32_t ncols,
		int32_t growstart, int32_t gcolstart ) {

#ifdef HAVE_MPI
	MPI_Comm comm;
#endif

	double *ptr;

	void *buffer;

	char fname[1024];

	int lower[2], upper[2];
	int strides[2];

	int position, size, tmp;
	int myrank, numvizzers;
	int stride;
	int i, j;
	int cc;

	std::cout << "pde::viewers::Viz2D_impl::collectVizData():"
			<< " fieldName=" << fieldName
			<< " rowLowBoundWidth=" << rowLowBoundWidth
			<< " rowHighBoundWidth=" << rowHighBoundWidth
			<< " colLowBoundWidth=" << colLowBoundWidth
			<< " colHighBoundWidth=" << colHighBoundWidth
			<< " nrows=" << nrows
			<< " ncols=" << ncols
			<< " growstart=" << growstart
			<< " gcolstart=" << gcolstart
			<< std::endl;

	// Assemble the data

	if ( data._is_nil() ) {
		std::cout << "pde::viewers::Viz2D_impl::collectVizData(): "
				<< "Data is nil!" << std::endl;
		return;
	}

	int32_t eff_nrows = nrows - rowLowBoundWidth - rowHighBoundWidth;
	int32_t eff_ncols = ncols - colLowBoundWidth - colHighBoundWidth;

	std::cout << "pde::viewers::Viz2D_impl::collectVizData():"
			<< " eff_nrows=" << eff_nrows
			<< " eff_ncols=" << eff_ncols
			<< std::endl;

#ifdef HAVE_MPI
	// Check on our MPI situation...
	get_mpi_info( &comm, &myrank, &numvizzers );
#else
	myrank = 0;
	numvizzers = 1;
#endif

#ifdef HAVE_MPI

	// If I'm not the root vizzer, forward my data and return

	if ( myrank && useMPI == 1 )
	{
		// Determine Buffer Size

		size = 0;

		MPI_Pack_size( 4, MPI_INT, comm, &tmp );
		size += tmp;

		MPI_Pack_size( eff_nrows * eff_ncols, MPI_DOUBLE, comm, &tmp );
		size += tmp;

		buffer = MALLOC( size * sizeof( char ) );

		if ( buffer == NULL ) {
			std::cout << "pde::viewers::Viz2D_impl::collectVizData(): "
					<< "message buffer is nil!" << std::endl;
			return;
		}

		// Pack up meta-data

		position = 0;

		MPI_Pack( &eff_nrows, 1, MPI_INT, buffer, size, &position, comm );
		MPI_Pack( &eff_ncols, 1, MPI_INT, buffer, size, &position, comm );

		MPI_Pack( &growstart, 1, MPI_INT, buffer, size, &position,
				comm );
		MPI_Pack( &gcolstart, 1, MPI_INT, buffer, size, &position,
				comm );

		// Pack up data array

		double dval;

		if ( data.dimen() == 1 ) {

			for ( i=rowLowBoundWidth ;
					i < nrows - rowHighBoundWidth ; i++ )
			{
				for ( j=colLowBoundWidth ;
						j < ncols - colHighBoundWidth ; j++ )
				{
					dval = data.get( ( i * ncols ) + j );

					std::cout << "i=" << i << " j=" << j
							<< " data.get( " << ( i * ncols ) + j
							<< " ) = " << dval << std::endl;

					MPI_Pack( &dval, 1, MPI_DOUBLE, buffer, size,
							&position, comm );
				}
			}
		}

		else if ( data.dimen() == 2 ) {

			for ( i=rowLowBoundWidth ;
					i < nrows - rowHighBoundWidth ; i++ )
			{
				for ( j=colLowBoundWidth ;
						j < ncols - colHighBoundWidth ; j++ )
				{
					dval = data.get( i, j );

					std::cout << "data.get( " << i << ", " << j
							<< " ) = " << dval << std::endl;

					MPI_Pack( &dval, 1, MPI_DOUBLE, buffer, size,
							&position, comm );
				}
			}
		}

		else {
			std::cout << "pde::viewers::Viz2D_impl::collectVizData(): "
					<< "unsupported data array dimension = "
					<< data.dimen() << std::endl;
		}

		// Send to master vizzer...

		MPI_Send( buffer, position, MPI_PACKED, 0, 123, comm );

		if ( vflag )
			std::cout << "pde::viewers::Viz2D_impl::collectVizData(): "
					<< "data message sent to vizzer 0." << std::endl;

		return;
	}

#endif

	// Handle rest of global array Gif...

	if ( GDATA ) {

		if ( vflag )
			std::cout << "pde::viewers::Viz2D_impl::collectVizData(): "
					<< "handling my (vizzer0) global data "
					<< "dimen=" << data.dimen()
					<< std::endl;

		// Copy my local data to its place in global...

		// stride = GUB[1] - GLB[1] + 1;
		stride = GUB[0] - GLB[0] + 1;

		if ( data.dimen() == 1 ) {

			// for ( i=rowLowBoundWidth ;
					// i < nrows - rowHighBoundWidth ; i++ )
			for ( i=colLowBoundWidth ;
					i < ncols - colHighBoundWidth ; i++ )
			{
				//ptr = GDATA + ( ( ( growstart - GLB[0] ) + i ) * stride )
						// + ( gcolstart - GLB[1] );
				ptr = GDATA
					+ ( ( ( gcolstart - GLB[1] ) + i - colLowBoundWidth ) * stride )
					+ ( growstart - GLB[0] );

				// std::cout << "GDATA Row Starting at "
						// << ( ( ( growstart - GLB[0] ) + i ) * stride )
								// + ( gcolstart - GLB[1] )
						// << "(" << ptr - GDATA << ")"
						// << std::endl;
				std::cout << "GDATA Row Starting at "
						<< ( ( ( gcolstart - GLB[1] ) + i ) * stride )
								+ ( growstart - GLB[0] )
						<< "(" << ptr - GDATA << ")"
						<< std::endl;

				// for ( j=colLowBoundWidth ;
						// j < ncols - colHighBoundWidth ; j++ )
				for ( j=rowLowBoundWidth ;
						j < nrows - rowHighBoundWidth ; j++ )
				{
					// std::cout << "i=" << i << " j=" << j
							// << " data.get( " << ( i * ncols ) + j
							// << " ) = " << data.get( ( i * ncols ) + j )
							// << std::endl;
					std::cout << "i=" << i << " j=" << j
							<< " data.get( " << ( i * nrows ) + j
							<< " ) = " << data.get( ( i * nrows ) + j )
							<< std::endl;

					// *ptr++ = data.get( ( i * ncols ) + j );
					*ptr++ = data.get( ( i * nrows ) + j );
				}

				std::cout << "GDATA Row Ended at "
						<< "(" << ptr - GDATA << ")"
						<< std::endl;
			}
			for ( int x=0 ; x < GSIZE ; x++ )
				std::cout << "GDATA[" << x << "]=" << GDATA[x]
						<< std::endl;
		}

		else if ( data.dimen() == 2 ) {

			// for ( i=rowLowBoundWidth ;
					// i < nrows - rowHighBoundWidth ; i++ )
			for ( i=colLowBoundWidth ;
					i < ncols - colHighBoundWidth ; i++ )
			{
				//ptr = GDATA + ( ( growstart + i ) * stride ) + gcolstart;
				ptr = GDATA + ( ( gcolstart + i ) * stride ) + growstart;

				// for ( j=colLowBoundWidth ;
						// j < ncols - colHighBoundWidth ; j++ )
				for ( j=rowLowBoundWidth ;
						j < nrows - rowHighBoundWidth ; j++ )
				{
					std::cout << "data.get( " << i << ", " << j
							<< " ) = " << data.get( i, j )
							<< std::endl;

					*ptr++ = data.get( i, j );
				}
			}
		}

		else {
			std::cout << "pde::viewers::Viz2D_impl::collectVizData(): "
					<< "unsupported data array dimension = "
					<< data.dimen() << std::endl;
		}
	}

	else {

		if ( vflag )
			std::cout << "pde::viewers::Viz2D_impl::collectVizData(): "
					<< "handling my (vizzer0) local data..."
					<< std::endl;

		// Allocate storage and copy over local data...

		double *data2D = (double *) MALLOC( eff_nrows * eff_ncols
				* sizeof( double ) );

		if ( data2D == NULL ) {
			std::cout
					<< "pde::viewers::Viz2D_impl::collectVizData(): "
					<< "destination array is nil!" << std::endl;
			return;
		}

		double dval;

		if ( data.dimen() == 1 ) {

			ptr = data2D;

			for ( i=rowLowBoundWidth ;
					i < nrows - rowHighBoundWidth ; i++ )
			{
				for ( j=colLowBoundWidth ;
						j < ncols - colHighBoundWidth ; j++ )
				{
					dval = data.get( ( i * ncols ) + j );

					std::cout << "i=" << i << " j=" << j
							<< " data.get( " << ( i * ncols ) + j
							<< " ) = " << dval << std::endl;

					*ptr++ = dval;
				}
			}
		}

		else if ( data.dimen() == 2 ) {

			for ( i=rowLowBoundWidth ;
					i < nrows - rowHighBoundWidth ; i++ )
			{
				for ( j=colLowBoundWidth ;
						j < ncols - colHighBoundWidth ; j++ )
				{
					dval = data.get( i, j );

					std::cout << "data.get( " << i << ", " << j
							<< " ) = " << dval << std::endl;

					*ptr++ = dval;
				}
			}
		}

		else {
			std::cout << "pde::viewers::Viz2D_impl::collectVizData(): "
					<< "unsupported data array dimension = "
					<< data.dimen() << std::endl;
		}

		// Create SIDL array...

		::sidl::array<double> vdata;

		lower[0] = lower[1] = 0;
		// upper[0] = eff_nrows;  upper[1] = eff_ncols;
		upper[0] = eff_ncols;  upper[1] = eff_nrows;

		// strides[0] = eff_ncols;  strides[1] = 1;
		strides[0] = eff_nrows;  strides[1] = 1;

		vdata.borrow( data2D, 2, lower, upper, strides );

		if ( vdata._is_nil() ) {
			std::cout
					<< "pde::viewers::Viz2D_impl::dumpVizFile(): "
					<< "vdata is nil!" << std::endl;
			return;
		}

		// Dump a Gif image file for my local data

		if ( animateFramesFlag == 0 ) {
			sprintf( fname, "%s.%s.%05d%s",
					(char *) FILE_PREFIX.c_str(), fieldName, SEQUENCE,
					( numvizzers > 1 ) ? ".0" : "" );
		}

		// Omit Sequence Number for Animated GIFs...

		else {
			sprintf( fname, "%s.%s%s",
					(char *) FILE_PREFIX.c_str(), fieldName,
					( numvizzers > 1 ) ? ".0" : "" );
		}

		if ( vflag )
			std::cout << "collectVizData() dumping to " << fname
					<< std::endl;

		do_dump_gif_file( vdata, upper[0], upper[1], fname );
	}
}

void pde::viewers::Viz2D_impl::dumpVizFile( const char *fieldName ) {

#ifdef HAVE_MPI
	MPI_Comm comm;
#endif

	double *ptr;

	void *buffer;

	char fname[1024];

	int lower[2], upper[2], strides[2];

	int position, size, tmp;
	int myrank, numvizzers;
	int stride;
	int i, j;
	int seq;
	int cc;

	// Be sure to bump sequence counter...

	seq = SEQUENCE++;

#ifdef HAVE_MPI
	// Check on our MPI situation...
	get_mpi_info( &comm, &myrank, &numvizzers );
#else
	myrank = 0;
	numvizzers = 1;
#endif

#ifdef HAVE_MPI

	// If I'm not the root vizzer, forward my data and return

	if ( myrank && useMPI == 1 )
	{
		std::cout << "pde::viewers::Viz2D_impl::dumpVizFile(): "
				<< "not master vizzer."
				<< std::endl;
		std::cout << "(Send message to) "
				<< "tell it we're done with this frame."
				<< std::endl;
		return;

		// Determine Buffer Size

		MPI_Pack_size( 4, MPI_INT, comm, &size );

		buffer = MALLOC( size * sizeof( char ) );

		if ( buffer == NULL ) {
			std::cout << "pde::viewers::Viz2D_impl::dumpVizFile(): "
					<< "message buffer is nil!" << std::endl;
			return;
		}

		// Pack up meta-data

		position = 0;

		// "We're Done."
		tmp = -1;

		MPI_Pack( &tmp, 1, MPI_INT, buffer, size, &position, comm );
		MPI_Pack( &tmp, 1, MPI_INT, buffer, size, &position, comm );
		MPI_Pack( &tmp, 1, MPI_INT, buffer, size, &position, comm );
		MPI_Pack( &tmp, 1, MPI_INT, buffer, size, &position, comm );

		// Send to master vizzer...

		MPI_Send( buffer, position, MPI_PACKED, 0, 123, comm );

		if ( vflag )
			std::cout << "pde::viewers::Viz2D_impl::dumpVizFile(): "
					<< "done message sent to vizzer 0." << std::endl;

		return;
	}

	// Receive data from any other participants...

	MPI_Status status;

	size = -1;

	int vdone = 1;  // the master is always ready...  :-D

	while ( vdone < numvizzers && useMPI == 1 )
	{
		// Check for Next Message (better be there, we're blocking!)

		if ( vflag )
			std::cout << "pde::viewers::Viz2D_impl::dumpVizFile(): "
					<< "blocking for vizzer messages..."
					<< std::endl;

		MPI_Probe( MPI_ANY_SOURCE, 123, comm, &status );

		MPI_Get_count( &status, MPI_PACKED, &tmp );

		// Allocate new buffer...

		if ( tmp > size )
		{
			if ( size > 0 )
				FREE( buffer );

			size = tmp;

			buffer = MALLOC( size * sizeof( char ) );

			if ( buffer == NULL ) {
				std::cout << "pde::viewers::Viz2D_impl::dumpVizFile(): "
						<< "message buffer is nil!" << std::endl;
				return;
			}
		}

		// Receive the message

		cc = MPI_Recv( buffer, size, MPI_PACKED, status.MPI_SOURCE, 123,
				comm, &status );

		if ( vflag )
			std::cout << "pde::viewers::Viz2D_impl::dumpVizFile(): "
					<< "message received from vizzer #"
					<< status.MPI_SOURCE
					<< std::endl;

		// Unpack the meta-shtuff...

		int vgrowstart, vgcolstart;
		int vnrows, vncols;

		position = 0;

		MPI_Unpack( buffer, size, &position, &vnrows, 1, MPI_INT, comm );
		MPI_Unpack( buffer, size, &position, &vncols, 1, MPI_INT, comm );

		MPI_Unpack( buffer, size, &position, &vgrowstart, 1, MPI_INT,
				comm );
		MPI_Unpack( buffer, size, &position, &vgcolstart, 1, MPI_INT,
				comm );

		if ( vflag )
			std::cout << "pde::viewers::Viz2D_impl::dumpVizFile(): "
					<< "vizzer#" << status.MPI_SOURCE
					<< " vnrows=" << vnrows << " vncols=" << vncols
					<< " vgrowstart=" << vgrowstart
					<< " vgcolstart=" << vgcolstart
					<< std::endl;

		// Is This Vizzer Done...?

		if ( vnrows < 0 && vncols < 0
				&& vgrowstart < 0 && vgcolstart < 0 ) {

			// This Vizzer is Done.
			vdone++;
		}

		// Otherwise, There's Data to Wrangle...

		else {

			// There's a global decomposition, unpack data in its place...

			if ( GDATA )
			{
				if ( vflag )
					std::cout
							<< "pde::viewers::Viz2D_impl::dumpVizFile(): "
							<< "vizzer#" << status.MPI_SOURCE
							<< " unpacking global data in place"
							<< std::endl;

				// stride = GUB[1] - GLB[1] + 1;
				stride = GUB[0] - GLB[0] + 1;

				// for ( i=0 ; i < vnrows ; i++ )
				for ( i=0 ; i < vncols ; i++ )
				{
					// ptr = GDATA + ( ( vgrowstart + i ) * stride )
							// + vgcolstart;
					ptr = GDATA + ( ( vgcolstart + i ) * stride )
							+ vgrowstart;

					// for ( j=0 ; j < vncols ; j++ )
					for ( j=0 ; j < vnrows ; j++ )
						MPI_Unpack( buffer, size, &position,
								ptr++, 1, MPI_DOUBLE, comm );
				}
			}

			// No global array, dump each patch individually...

			else
			{
				if ( vflag )
					std::cout
							<< "pde::viewers::Viz2D_impl::dumpVizFile(): "
							<< "vizzer#" << status.MPI_SOURCE
							<< " unpacking local data patch"
							<< std::endl;

				// Allocate storage and unpack incoming data...

				ptr = (double *) MALLOC( vnrows * vncols
						* sizeof( double ) );

				if ( ptr == NULL ) {
					std::cout
							<< "pde::viewers::Viz2D_impl::dumpVizFile(): "
							<< "destination array is nil!" << std::endl;
					return;
				}

				MPI_Unpack( buffer, size, &position,
						ptr, vnrows * vncols, MPI_DOUBLE, comm );

				// Create SIDL array and dump a Gif...

				::sidl::array<double> vdata;

				lower[0] = lower[1] = 0;
				// upper[0] = vnrows;  upper[1] = vncols;
				upper[0] = vncols;  upper[1] = vnrows;

				// strides[0] = vncols;  strides[1] = 1;
				strides[0] = vnrows;  strides[1] = 1;

				vdata.borrow( ptr, 2, lower, upper, strides );

				if ( vdata._is_nil() ) {
					std::cout
							<< "pde::viewers::Viz2D_impl::dumpVizFile(): "
							<< "vdata is nil!" << std::endl;
					return;
				}

				// Create the image file prefix

				if ( animateFramesFlag == 0 ) {
					sprintf( fname, "%s.%s.%05d.%d",
							(char *) FILE_PREFIX.c_str(), fieldName, seq,
							status.MPI_SOURCE );
				}

				// Omit Sequence Number for Animated GIFs...

				else {
					sprintf( fname, "%s.%s.%d",
							(char *) FILE_PREFIX.c_str(), fieldName,
							status.MPI_SOURCE );
				}

				if ( vflag )
					std::cout << "dumpVizFile() dumping to " << fname
							<< std::endl;

				do_dump_gif_file( vdata, upper[0], upper[1], fname );
			}
		}
	}

#endif

	// Handle dumping global array Gif...

	if ( GDATA ) {

		// Make a SIDL array out of it...

		::sidl::array<double> gdata;

		lower[0] = lower[1] = 0;

		// upper[0] = GUB[0] - GLB[0] + 1;
		// upper[1] = GUB[1] - GLB[1] + 1;
		upper[0] = GUB[1] - GLB[1] + 1;
		upper[1] = GUB[0] - GLB[0] + 1;

		// strides[0] = GUB[1] - GLB[1] + 1;
		strides[0] = GUB[0] - GLB[0] + 1;
		strides[1] = 1;

		gdata.borrow( GDATA, 2, lower, upper, strides );

		if ( gdata._is_nil() ) {
			std::cout << "pde::viewers::Viz2D_impl::dumpVizFile(): "
					<< "gdata is nil!" << std::endl;
			return;
		}

		// Create the image file prefix

		if ( animateFramesFlag == 0 ) {
			sprintf( fname, "%s.%s.%05d",
					(char *) FILE_PREFIX.c_str(), fieldName, seq );
		}

		// Omit Sequence Number for Animated GIFs...

		else {
			sprintf( fname, "%s.%s",
					(char *) FILE_PREFIX.c_str(), fieldName );
		}

		if ( vflag )
			std::cout << "dumpVizFile() dumping to " << fname
					<< std::endl;

		do_dump_gif_file( gdata, upper[0], upper[1], fname );
	}
}

#ifdef HAVE_MPI

void pde::viewers::Viz2D_impl::get_mpi_info( MPI_Comm *commp,
		int *rankp, int *sizep ) {

	int cc;

	if ( useMPI == 0 ) {
		if ( commp != NULL )
			*commp = (MPI_Comm) -1;
		if ( rankp != NULL )
			*rankp = 0;
		if ( sizep != NULL )
			*sizep = 1;
		return;
	}

#ifdef BRAVE_VIZ_MPI_INIT

	// See if MPI has been, or can be, initialized...

	MPI_Initialized( &cc );

	if ( !cc )
	{
		cc = MPI_Init( (int *) NULL, (char ***) NULL );

		if ( cc != MPI_SUCCESS )
		{
			if ( commp != NULL )
				*commp = (MPI_Comm) -1;

			if ( rankp != NULL )
				*rankp = 0;
			if ( sizep != NULL )
				*sizep = 1;

			return;
		}
	}

#endif

	// Get my communicator

	if ( commp != NULL )
		*commp = COMM;

	// Determine my identity and the group size for that communicator

	if ( rankp != NULL )
		MPI_Comm_rank( COMM, rankp );

	if ( sizep != NULL )
		MPI_Comm_size( COMM, sizep );
}

#endif

void pde::viewers::Viz2D_impl::allocate_global_data( int myrank ) {

	// Allocate Storage for Global Data Array

	if ( !myrank
			&& ( GLB[0] != -1 || GUB[0] != -1
				|| GLB[1] != -1 || GUB[1] != -1 ) )
	{
		int tmp;

		tmp = ( GUB[0] - GLB[0] + 1 ) * ( GUB[1] - GLB[1] + 1 );

		if ( vflag )
			std::cout << "pde::viewers::Viz2D_impl::setGlobalBounds(): "
					<< "new global data size=" << tmp
					<< std::endl;

		// Reallocate
		if ( tmp > GSIZE )
		{
			if ( vflag )
				std::cout
					<< "pde::viewers::Viz2D_impl::setGlobalBounds():"
					<< " reallocating" << std::endl;

			double *newGDATA = (double *) MALLOC( tmp * sizeof( double ) );

			if ( newGDATA == NULL ) {
				fprintf( stderr,
				"\nError Allocating Global Data Array (%dx%d)=%d\n\n",
					( GUB[0] - GLB[0] + 1 ), ( GUB[1] - GLB[1] + 1 ),
					tmp );
				if ( GDATA != NULL )
					FREE( GDATA );
				GSIZE = -1;
			}
			else {
				if ( GDATA != NULL ) {
					for ( int i=0 ; i < GSIZE ; i++ )
						newGDATA[i] = GDATA[i];
					FREE( GDATA );
				}
				GDATA = newGDATA;
				GSIZE = tmp;
			}
		}

		else if ( vflag )
			std::cout << "pde::viewers::Viz2D_impl::setGlobalBounds(): "
					<< "< GSIZE=" << GSIZE << std::endl;
	}
	
	else
	{
		if ( vflag )
			std::cout << "pde::viewers::Viz2D_impl::setGlobalBounds(): "
					<< "(myrank=" << myrank << ") "
					<< "no bounds..." << std::endl;

		if ( GDATA != NULL )
		{
			if ( vflag )
				std::cout
					<< "pde::viewers::Viz2D_impl::setGlobalBounds(): "
					<< "freeing GDATA..." << std::endl;

			FREE( GDATA );

			GDATA = (double *) NULL;
		}
	}
}

void pde::viewers::Viz2D_impl::do_dump_gif_file(
		::sidl::array<double> data,
		int nrows, int ncols, char *fname ) {

	FILE *gif;

	gdImagePtr img = (gdImagePtr) NULL;

	char cmd[1024];
	char temp[255];

	double min, max;
	double pxscale;
	double pyscale;
	double pscale;
	double dval;

	int i, j, k;
	int newsize;
	int nrects;
	int xscale;
	int yscale;
	int wt, ht;
	int x1, y1;
	int x2, y2;
	int color;
	int scale;
	int x, y;
	int fd;
	int r;

	std::cout << "do_dump_gif_file()"
			<< " nrows=" << nrows
			<< " ncols=" << ncols
			<< " fname=" << fname
			<< std::endl;

	/* Calc Total Num of Rects Needed */

	nrects = nrows * ncols;

	xscale = GIF_WIDTH / ncols;
	yscale = GIF_HEIGHT / nrows;

	scale = ( xscale < yscale ) ? xscale : yscale;
	scale = scale ? scale : 1;

	/* Create GIF Image */

	if ( img == NULL )
	{
		/* Determine Actual Width & Height */

		wt = scale * ncols;
		ht = scale * nrows;

		/* Create GIF Image */

		img = gdImageCreate( wt, ht );

		/* Set Image to Interlaced */

		if ( GDFORMAT == VIZGIFFER_GIF )
			gdImageInterlace( img, 1 );
	}

	/* Automatically Determine Color Map Range */

	if ( AUTO_COLOR_MAP || LAZY_COLOR_MAP )
	{
		if ( vflag )
			printf( "\tDetermining color map range.\n" );

		/* Determine Min & Max Values */

		for ( i=0 ; i < nrows ; i++ )
		{
			for ( j=0 ; j < ncols ; j++ )
			{
				dval = data.get( i, j );

				// if ( vflag )
					// printf( "data[%d][%d]=%lf\n", i, j, dval );

				if ( !i && !j )
					min = max = dval;

				else
				{
					min = ( dval < min ) ? dval : min;
					max = ( dval > max ) ? dval : max;
				}
			}
		}

		handle_min_max( min, max );
	}

	/* Fill Color Map */

	for ( j=0 ; j < 255 ; j++ )
	{
		color_value_img( img, &color,
			( (double) ( j
					* (COLOR_MAX_VALUE - COLOR_MIN_VALUE + 1) )
				/ (double) 255 )
			+ (double) COLOR_MIN_VALUE,
			1 );
	}

	/* Draw Rects */

	if ( vflag )
		printf( "\tDrawing rectangles.\n" );

	/* Draw 'Em */

	for ( i=0 ; i < nrows ; i++ )
	{
		for ( j=0 ; j < ncols ; j++ )
		{
			x = ( scale * j );
			y = ( scale * i );

			x1 = x;
			y1 = y;
			x2 = x + scale - 1;
			y2 = y + scale - 1;

			dval = data.get( i, j );

			color_value_img( img, &color, dval, 0 );

			gdImageFilledRectangle( img, x1, y1, x2, y2, color );
		}
	}

	// Don't Animate, Just Dump the File...

	if ( animateFramesFlag == 0 || GDFORMAT != VIZGIFFER_GIF ) {

		if ( animateFramesFlag != 0 ) {
			std::cout << "Warning: Animation Mode Only Compatible with "
					<< "GIF Image Format - Animation Disabled...!"
					<< std::endl;
		}

		/* Write Temporary File */

		sprintf( temp, ".gifferXXXXXX" );

		fd = mkstemp( temp );

		gif = fdopen( fd, "w" );

		if ( gif != NULL )
		{
			// Skipping Jpeg for now...  :-o
			/* if ( GDFORMAT == VIZGIFFER_JPEG )
				gdImageJpeg( img, gif, -1 );

			else */ if ( GDFORMAT == VIZGIFFER_PNG )
				gdImagePng( img, gif );

			else
				gdImageGif( img, gif );
	
			fclose( gif );

			/* Move to Final File - Better Atomic Operation */

			if ( GDFORMAT == VIZGIFFER_JPEG )
				sprintf( cmd, "mv %s %s.jpg", temp, fname );

			else if ( GDFORMAT == VIZGIFFER_PNG )
				sprintf( cmd, "mv %s %s.png", temp, fname );

			else
				sprintf( cmd, "mv %s %s.gif", temp, fname );

			system( cmd );

			if ( 1 || vflag ) {
				printf( "\tNew %s image file \"%s\" created.\n",
					( GDFORMAT == VIZGIFFER_JPEG ) ? "Jpeg" :
						( ( GDFORMAT == VIZGIFFER_PNG ) ? "Png" : "GIF" ),
					fname );
			}
		}

		else {
			std::cout << std::endl
					<< "Error Opening Image Output File \""
					<< fname << "\" - Image Not Written!!!"
					<< std::endl;
		}
	}

	// Create/Add to Animated GIF Image File...

	else {

		// Build the proper file name...
		sprintf( temp, "%s.gif", fname );

		// Find an Existing Open File Pointer...
		// (No, this isn't risky at all... :-D)
		int findex = -1;
		for ( int f=0 ; findex < 0 && f < numOpenAnimFiles ; f++ ) {
			if ( openAnimFileNames[f] != NULL
					&& !strcmp( openAnimFileNames[f], temp ) ) {
				findex = f;
			}
		}

		// Start a New Animation File...
		if ( findex == -1 ) {

			gif = fopen( temp, "w" );

			if ( gif != NULL ) {

				// Add This Animated Image File to Our List...
				findex = numOpenAnimFiles++;
				openAnimFileNames[ findex ] = strdup( temp );
				openAnimFilePointers[ findex ] = gif;

				// Prepare the File for Animation...
				gdImageGifAnimBegin( img, gif, /* GlobalColorMap */ 0, 3 );

				std::cout << std::endl
						<< "New Animated GIF Image Output File \""
						<< temp << "\" Created!!!"
						<< std::endl;
			}
			else {
				std::cout << std::endl
						<< "Error Opening Image Output File \""
						<< temp << "\" - Animated Image Not Written!!!"
						<< std::endl;
			}
		}

		// Append to Existing Animation File...
		else {
			gif = openAnimFilePointers[ findex ];
		}

		// Stuff the Tree Up...

		if ( gif != NULL ) {
			gdImageGifAnimAdd( img, gif, /* LocalColorMap */ 1,
					/* LeftOffset */ 0, /* TopOffset */ 0,
					/* Delay in 1/100s */ 300, gdDisposalNone,
					/* PreVim */ (gdImagePtr) NULL );
			std::cout << std::endl
					<< "Image Added to Animated GIF Image Output File \""
					<< temp << "\""
					<< std::endl;
		}
	}

	/* Free GIF Image */

	gdImageDestroy( img );
}

void pde::viewers::Viz2D_impl::handle_min_max(
		double min, double max ) {

	double ddiff, cdiff;
	double thresh;

	/* Handle Auto Color Map */

	if ( AUTO_COLOR_MAP )
	{
		if ( COLOR_MIN_VALUE != min || COLOR_MAX_VALUE != max )
		{
			if ( vflag )
				printf( "\t\tNew auto color map range = [%lf,%lf].\n",
						min, max );

			COLOR_MIN_VALUE = min;
			COLOR_MAX_VALUE = max;
		}
	}

	/* Handle Lazy Color Map */

	else if ( LAZY_COLOR_MAP )
	{
		if ( !COLOR_MAP_INITD )
		{
			if ( vflag )
				printf(
					"\t\tNew init lazy color map range = [%lf,%lf].\n",
						min, max );

			COLOR_MIN_VALUE = min;
			COLOR_MAX_VALUE = max;

			COLOR_MAP_INITD = 1;
		}

		else
		{
			/* Color Range */
			cdiff = (double) fabs( (double)
				( COLOR_MAX_VALUE - COLOR_MIN_VALUE ) );

			/* Data Range */
			ddiff = (double) fabs( (double) ( max - min ) );

			/* Cut-Off is 50% of Max Threshold */
			thresh = 0.50 * ( ( ddiff > cdiff ) ? ddiff : cdiff );

			if ( max - COLOR_MIN_VALUE <= thresh
				|| COLOR_MAX_VALUE - min <= thresh )
			{
				if ( vflag )
					printf(
						"\t\tNew lazy color map range = [%lf,%lf].\n",
							min, max );

				COLOR_MIN_VALUE = min;
				COLOR_MAX_VALUE = max;
			}
		}
	}
}

void pde::viewers::Viz2D_impl::color_value_img( gdImagePtr img,
		int *color, double value, int allocate ) {

	double ratio;

	double R;
	double G;
	double B;

	if ( EQUIV( COLOR_MIN_VALUE, COLOR_MAX_VALUE ) )
	{
		if ( value > COLOR_MIN_VALUE )
		{
			R = 255.0;
			G = 0.0;
			B = 0.0;
		}

		else if ( value < COLOR_MIN_VALUE )
		{
			R = 0.0;
			G = 0.0;
			B = 255.0;
		}

		else
		{
			R = 0.0;
			G = 255.0;
			B = 0.0;
		}
	}

	else
	{
		ratio = ( value - COLOR_MIN_VALUE )
			 / ( COLOR_MAX_VALUE - COLOR_MIN_VALUE );

		B = 255.0 - ( 255.0 * ratio );

		B = ( B < 0 ) ? 0.0 : B;
		B = ( B > 255.0 ) ? 255.0 : B;

		if ( ratio > 0.5 )
			G = 255.0 - ( 255.0 * ( ratio - 0.5 ) * 2.0 );

		else
			G = 255.0 * ratio * 2.0;

		G = ( G < 0 ) ? 0.0 : G;
		G = ( G > 255.0 ) ? 255.0 : G;

		R = 255.0 * ratio;

		R = ( R < 0 ) ? 0.0 : R;
		R = ( R > 255.0 ) ? 255.0 : R;
	}

	if ( allocate )
	{
		*color = gdImageColorAllocate( img, (int) R, (int) G, (int) B );

		if ( *color >= 0 ) return;
	}

	*color = gdImageColorExact( img, (int) R, (int) G, (int) B );

	if ( *color < 0 )
	{
		*color = gdImageColorClosest( img, (int) R, (int) G, (int) B );

		if ( *color < 0 )
		{
			printf( "*" );  fflush( stdout );
		}
	}
}

void pde::viewers::Viz2D_impl::color_value_str( char color[16],
		double value ) {

	char Rstr[4];
	char Gstr[4];
	char Bstr[4];

	double ratio;

	double R;
	double G;
	double B;

	if ( EQUIV( COLOR_MIN_VALUE, COLOR_MAX_VALUE ) )
	{
		if ( value > COLOR_MIN_VALUE )
		{
			R = 255.0;
			G = 0.0;
			B = 0.0;
		}

		else if ( value < COLOR_MIN_VALUE )
		{
			R = 0.0;
			G = 0.0;
			B = 255.0;
		}

		else
		{
			R = 0.0;
			G = 255.0;
			B = 0.0;
		}
	}

	else
	{
		ratio = ( value - COLOR_MIN_VALUE )
			 / ( COLOR_MAX_VALUE - COLOR_MIN_VALUE );

		B = 255.0 - ( 255.0 * ratio );

		B = ( B < 0 ) ? 0.0 : B;
		B = ( B > 255.0 ) ? 255.0 : B;

		if ( ratio > 0.5 )
			G = 255.0 - ( 255.0 * ( ratio - 0.5 ) * 2.0 );

		else
			G = 255.0 * ratio * 2.0;

		G = ( G < 0 ) ? 0.0 : G;
		G = ( G > 255.0 ) ? 255.0 : G;

		R = 255.0 * ratio;

		R = ( R < 0 ) ? 0.0 : R;
		R = ( R > 255.0 ) ? 255.0 : R;
	}

	if ( (int) R > 0xf )
		sprintf( Rstr, "%2x", (int) R );
	else
		sprintf( Rstr, "0%1x", (int) R );

	if ( (int) G > 0xf )
		sprintf( Gstr, "%2x", (int) G );
	else
		sprintf( Gstr, "0%1x", (int) G );

	if ( (int) B > 0xf )
		sprintf( Bstr, "%2x", (int) B );
	else
		sprintf( Bstr, "0%1x", (int) B );

	sprintf( color, "#%s%s%s", Rstr, Gstr, Bstr );
}

// DO-NOT-DELETE splicer.end(pde.viewers.Viz2D._misc)

