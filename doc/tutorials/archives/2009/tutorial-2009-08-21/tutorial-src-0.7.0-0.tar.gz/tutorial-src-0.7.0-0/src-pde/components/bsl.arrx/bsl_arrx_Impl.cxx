// 
// File:          bsl_arrx_Impl.cxx
// Symbol:        bsl.arrx-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for bsl.arrx
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "bsl_arrx_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(bsl.arrx._includes)

  // Insert-UserCode-Here {bsl.arrx._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(bsl.arrx._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(bsl.arrx._includes)

  // Insert-UserCode-Here {bsl.arrx._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(bsl.arrx._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
bsl::arrx_impl::arrx_impl() : StubBase(reinterpret_cast< void*>(
  ::bsl::arrx::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(bsl.arrx._ctor2)
  // Insert-Code-Here {bsl.arrx._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(bsl.arrx._ctor2)
}

// user defined constructor
void bsl::arrx_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(bsl.arrx._ctor)
    
  // Insert-UserCode-Here {bsl.arrx._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(bsl.arrx._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR bsl.arrx: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(bsl.arrx._ctor)

  // Insert-UserCode-Here {bsl.arrx._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(bsl.arrx._ctor)
}

// user defined destructor
void bsl::arrx_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(bsl.arrx._dtor)
  // Insert-UserCode-Here {bsl.arrx._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(bsl.arrx._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR bsl.arrx: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(bsl.arrx._dtor) 

  // DO-NOT-DELETE splicer.end(bsl.arrx._dtor)
}

// static class initializer
void bsl::arrx_impl::_load() {
  // DO-NOT-DELETE splicer.begin(bsl.arrx._load)
  // Insert-Code-Here {bsl.arrx._load} (class initialization)
  // DO-NOT-DELETE splicer.end(bsl.arrx._load)
}

// user defined static methods:
/**
 * Method:  sfrom[int]
 */
::std::string
bsl::arrx_impl::sfrom_impl (
  /* in array<int> */::sidl::array<int32_t> a ) 
{
  // DO-NOT-DELETE splicer.begin(bsl.arrx.sfromint)
#define PRINT_GENERIC(scalartype) \
        std::stringstream ss; \
        int32_t atype, i, dim; \
        int32_t lower[7] = { 0, 0, 0, 0, 0, 0, 0 }; \
        int32_t upper[7] = { 0, 0, 0, 0, 0, 0, 0 }; \
        int32_t indices[7] = { 0, 0, 0, 0, 0, 0, 0 }; \
        if (a._is_nil()) { \
                return std::string("nil_array_" #scalartype); \
        } \
        dim = a.dimen(); \
        for (i=0; i < dim; i++) { \
                lower[i] = a.lower(i); \
                indices[i] = lower[i]; \
                upper[i] = a.upper(i); \
        } \
        bool first = true; \
        do { \
                scalartype val = a.get(indices); \
                if (!first) { \
                        ss << ", "; \
                } else { \
                        first = false; \
                } \
                ss << bsl::arrx_impl::toIndexString(indices, dim) << " " << val; \
        } while ( next(dim, indices, lower, upper) ); \
        return ss.str()

        PRINT_GENERIC(int32_t);
  // DO-NOT-DELETE splicer.end(bsl.arrx.sfromint)
}

/**
 * Method:  sfrom[bool]
 */
::std::string
bsl::arrx_impl::sfrom_impl (
  /* in array<bool> */::sidl::array<bool> a ) 
{
  // DO-NOT-DELETE splicer.begin(bsl.arrx.sfrombool)
	PRINT_GENERIC(bool);
  // DO-NOT-DELETE splicer.end(bsl.arrx.sfrombool)
}

/**
 * Method:  sfrom[long]
 */
::std::string
bsl::arrx_impl::sfrom_impl (
  /* in array<long> */::sidl::array<int64_t> a ) 
{
  // DO-NOT-DELETE splicer.begin(bsl.arrx.sfromlong)
	PRINT_GENERIC(int64_t);
  // DO-NOT-DELETE splicer.end(bsl.arrx.sfromlong)
}

/**
 * Method:  sfrom[float]
 */
::std::string
bsl::arrx_impl::sfrom_impl (
  /* in array<float> */::sidl::array<float> a ) 
{
  // DO-NOT-DELETE splicer.begin(bsl.arrx.sfromfloat)
        PRINT_GENERIC(float);
  // DO-NOT-DELETE splicer.end(bsl.arrx.sfromfloat)
}

/**
 * Method:  sfrom[double]
 */
::std::string
bsl::arrx_impl::sfrom_impl (
  /* in array<double> */::sidl::array<double> a ) 
{
  // DO-NOT-DELETE splicer.begin(bsl.arrx.sfromdouble)
        PRINT_GENERIC(double);
  // DO-NOT-DELETE splicer.end(bsl.arrx.sfromdouble)
}

/**
 * Method:  sfrom[string]
 */
::std::string
bsl::arrx_impl::sfrom_impl (
  /* in array<string> */::sidl::array< ::std::string> a ) 
{
  // DO-NOT-DELETE splicer.begin(bsl.arrx.sfromstring)
        PRINT_GENERIC(std::string);
  // DO-NOT-DELETE splicer.end(bsl.arrx.sfromstring)
}

/**
 * Method:  sfrom[fcomplex]
 */
::std::string
bsl::arrx_impl::sfrom_impl (
  /* in array<fcomplex> */::sidl::array< ::sidl::fcomplex> a ) 
{
  // DO-NOT-DELETE splicer.begin(bsl.arrx.sfromfcomplex)
        PRINT_GENERIC( sidl::fcomplex );
  // DO-NOT-DELETE splicer.end(bsl.arrx.sfromfcomplex)
}

/**
 * Method:  sfrom[dcomplex]
 */
::std::string
bsl::arrx_impl::sfrom_impl (
  /* in array<dcomplex> */::sidl::array< ::sidl::dcomplex> a ) 
{
  // DO-NOT-DELETE splicer.begin(bsl.arrx.sfromdcomplex)
        PRINT_GENERIC( sidl::dcomplex );
  // DO-NOT-DELETE splicer.end(bsl.arrx.sfromdcomplex)
}


// user defined non-static methods:
/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
bsl::arrx_impl::boccaForceUsePortInclude_impl () 

{
  // DO-NOT-DELETE splicer.begin(bsl.arrx.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(bsl.arrx.boccaForceUsePortInclude)

  // Bocca generated code. bocca.protected.end(bsl.arrx.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(bsl.arrx.boccaForceUsePortInclude)
}


// DO-NOT-DELETE splicer.begin(bsl.arrx._misc)


::std::string
bsl::arrx_impl::toIndexString(int32_t *indices, int32_t dimen)
{
        std::stringstream ss;
        for (int i = 0; i< dimen; i++) {
                ss << "[" << indices[i] << "]";
        }
        return ss.str();
}

int
bsl::arrx_impl::next(const int dimen, int32_t ind[], const int32_t lower[], const int32_t upper[])
{
  int i = 0;
  while ((i < dimen) && (++(ind[i]) > upper[i])) {
    ind[i] = lower[i];
    ++i;
  }
  return i < dimen;
}

// DO-NOT-DELETE splicer.end(bsl.arrx._misc)

