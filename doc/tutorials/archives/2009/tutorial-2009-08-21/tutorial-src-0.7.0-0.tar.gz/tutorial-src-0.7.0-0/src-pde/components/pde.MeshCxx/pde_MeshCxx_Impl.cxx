// 
// File:          pde_MeshCxx_Impl.cxx
// Symbol:        pde.MeshCxx-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.MeshCxx
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_MeshCxx_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_bsl_arr_hxx
#include "bsl_arr.hxx"
#endif
#ifndef included_pde_BoundPos_hxx
#include "pde_BoundPos.hxx"
#endif
#ifndef included_pde_BoundaryCondition_hxx
#include "pde_BoundaryCondition.hxx"
#endif
#ifndef included_pde_FieldVar_hxx
#include "pde_FieldVar.hxx"
#endif
#ifndef included_pde_FieldVarCxx_hxx
#include "pde_FieldVarCxx.hxx"
#endif
#ifndef included_pde_MeshColl_hxx
#include "pde_MeshColl.hxx"
#endif
#ifndef included_pde_Patch_hxx
#include "pde_Patch.hxx"
#endif
#ifndef included_pde_PatchCxx_hxx
#include "pde_PatchCxx.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx._includes)

  // Insert-UserCode-Here {pde.MeshCxx._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(pde.MeshCxx._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.MeshCxx._includes)

  // Insert-UserCode-Here {pde.MeshCxx._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.MeshCxx._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::MeshCxx_impl::MeshCxx_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::MeshCxx::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx._ctor2)
  // Insert-Code-Here {pde.MeshCxx._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.MeshCxx._ctor2)
}

// user defined constructor
void pde::MeshCxx_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx._ctor)
    
	configured = false;
	dim = 0;
	coll = pde::MeshColl_ErrorMC;
	bwd = 0;
	for (int i=0; i < 3; i++) { ishape[i] =  0; }
	strad = 0;
	tlow = 0, thigh = 0;
	tcur = 0;
	steps = 0;
	commset = false;
	composed = false;
	fcomm = 0;
	d_procrank = 0;
	d_procsize = 1;
#ifdef HAVE_MPI
	ccomm = MPI_COMM_NULL;
#endif

// macro for use later that we don't want in the includes block.
#define COMPOSED(fcn) \
	if (d_allpatches._is_nil()) { \
	std::cout << "d_allpatches._is_nil in " << fcn << std::endl; \
	} \
	if (d_allpatches._is_nil()) \
	BOCCA_THROW_CXX(sidl::SIDLException, "function called before pde.MeshCxx.compose* called:" fcn)

// macro for use later that we don't want in the includes block.
#define CONFIGURED(fcn) \
	if (!configured) \
	BOCCA_THROW_CXX(sidl::SIDLException, "function called before pde.MeshCxx.configure called:" fcn)

  // bocca-default-code. User may edit or delete.begin(pde.MeshCxx._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.MeshCxx: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.MeshCxx._ctor)

  // Insert-UserCode-Here {pde.MeshCxx._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(pde.MeshCxx._ctor)
}

// user defined destructor
void pde::MeshCxx_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx._dtor)
  // Insert-UserCode-Here {pde.MeshCxx._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.MeshCxx._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.MeshCxx: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.MeshCxx._dtor) 

  // DO-NOT-DELETE splicer.end(pde.MeshCxx._dtor)
}

// static class initializer
void pde::MeshCxx_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx._load)
  // Insert-Code-Here {pde.MeshCxx._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.MeshCxx._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 *  If mpi is to be supported, this must be called with.
 * If this is not called, the mesh will operate in serial mode.
 * @param fcomm a valid fortran-form communicator properly converted to a sidl long.
 */
void
pde::MeshCxx_impl::setCommunicator_impl (
  /* in */int64_t fcomm ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.setCommunicator)
	if (composed) {
		return; // can't do it twice. can't do it after any compose either.
	}
	this->fcomm = fcomm; // doesn't matter much if no mpi present
#ifdef HAVE_MPI
	commset = true;
	MPI_Fint commF = (MPI_Fint)fcomm;
	ccomm = MPI_Comm_f2c(commF);
	MPI_Comm_rank(ccomm, &d_procrank);
	MPI_Comm_size(ccomm, &d_procsize);
#endif

  // DO-NOT-DELETE splicer.end(pde.MeshCxx.setCommunicator)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::MeshCxx_impl::boccaForceUsePortInclude_impl (
  /* in */::bsl::arr dummy0,
  /* in */::pde::PatchCxx dummy1,
  /* in */::pde::FieldVarCxx dummy2,
  /* in */::pde::BoundPos dummy3 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.MeshCxx.boccaForceUsePortInclude)
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;
    (void)dummy3;

  // Bocca generated code. bocca.protected.end(pde.MeshCxx.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.boccaForceUsePortInclude)
}

/**
 *  Set up the grid for all FieldVar defined on this Grid.
 * 
 * @param ndim an integer denoting the dimensionality. 1D, 2D or 3D.
 * @param mc the mesh collocation type.
 * @param boundaryWidthDefault halo of boundary cells.
 * @param shape a 1D array dim long containing the mesh resolution in each direction.
 * @param distances real space lengths of each axis.
 * @param stencil_radius maximum radius for space stencils.
 * @param time_high : how many intermediate stages of data to keep. in RK2, the values are 1, -1. 
 * @param time_low : how many intermediate stages of data to keep. in RK2, the values are 1, -1. 
 */
void
pde::MeshCxx_impl::configure_impl (
  /* in */int32_t ndim,
  /* in */::pde::MeshColl mc,
  /* in */int32_t boundaryWidthDefault,
  /* in array<int> */::sidl::array<int32_t> shape,
  /* in array<double> */::sidl::array<double> distances,
  /* in */int32_t stencil_radius,
  /* in */int32_t time_low,
  /* in */int32_t time_high ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.configure)
	if (configured) {
		BOCCA_THROW_CXX(sidl::SIDLException, "pde.MeshCxx.configure called twice.");
	}
	if (ndim <1 || ndim > 3) {
		BOCCA_THROW_CXX(sidl::SIDLException, "bad ndim given to pde.MeshCxx.configure.");
	}
	if (shape.length() < ndim || shape.stride(0) != 1) { 
		BOCCA_THROW_CXX(sidl::SIDLException, "ndim and length of shape are inconsistent in pde.MeshCxx.configure.");
	}
	if (distances.length() < ndim) {
		BOCCA_THROW_CXX(sidl::SIDLException, "ndim and length of distances are inconsistent in pde.MeshCxx.configure.");
	}
	dim = ndim;
	coll = mc;
	bwd = boundaryWidthDefault;
	strad = stencil_radius;
	tlow = time_low;
	thigh = time_high;

	int k=0;
	int low = shape.lower(0);
	for (int i = low; i < low+ndim; i++) {
		ishape[k] = shape[i];
		k++;
	}
	k=0;
	low = distances.lower(0);
	for (int i = low; i < low+ndim; i++) {
		lengths[k] = distances.get(i);
		k++;
	}
	configured = true;
    
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.configure)
}

/**
 *  @name QUERY METHODS. 
 * Needed by any component which needs to find the geometrical
 * location of a bounding box. Also needed by integrators.
 */
int32_t
pde::MeshCxx_impl::getDimension_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.getDimension)
	CONFIGURED("getDimension");
	return dim; 
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.getDimension)
}

/**
 * Method:  getShape[]
 */
::sidl::array<int32_t>
pde::MeshCxx_impl::getShape_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.getShape)
	CONFIGURED("getShape");
	sidl::array<int32_t> result = sidl::array<int32_t>::create1d(dim);
	for (int i = 0; i < dim; i++) {
		result.set(i, ishape[i]);
	}
	return result;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.getShape)
}

/**
 * Method:  getDistances[]
 */
::sidl::array<double>
pde::MeshCxx_impl::getDistances_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.getDistances)
	CONFIGURED("getDistances");
	sidl::array<double> result = sidl::array<double>::create1d(dim);
	for (int i = 0; i < dim; i++) {
		result.set(i, lengths[i]);
	}
	return result;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.getDistances)
}

/**
 *  Get the maximum boundary (halo) width for all FieldVar from this mesh.
 * @return Error : returns -1
 */
int32_t
pde::MeshCxx_impl::getBoundaryWidth_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.getBoundaryWidth)
	CONFIGURED("getBoundaryWidth");
	return bwd;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.getBoundaryWidth)
}

/**
 *  These will return the radius of the space stencil.  
 */
int32_t
pde::MeshCxx_impl::getSpaceStencil_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.getSpaceStencil)
	CONFIGURED("getSpaceStencil");
	return strad; 
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.getSpaceStencil)
}

/**
 *  return the range of labels for time steps. 
 */
void
pde::MeshCxx_impl::getTimeRange_impl (
  /* out */int32_t& time_alias_low,
  /* out */int32_t& time_alias_high ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.getTimeRange)
	CONFIGURED("getTimeRange");
	time_alias_low = tlow;
	time_alias_high = thigh;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.getTimeRange)
}

/**
 *  Compose the data. This is called after configure.
 * Define the domain to be the global union of npatches slabs.
 * Decomposition algorithm will try to even the number of
 * mesh cells on each processor if parallelism is in use.
 * In parallel case, if npatches < nproc, empty patches result.
 * @return Error : return -1, else 0
 */
int32_t
pde::MeshCxx_impl::compose1_impl (
  /* in */int32_t npatches ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.compose1)
	CONFIGURED("compose1");
	if (composed) {
		return -1; // already been composed somehow.
	}
	composed = true;
	int32_t nx = ishape[0];
	if (nx < npatches) {
		BOCCA_THROW_CXX(sidl::SIDLException, "compose1 given more patches than there are grid cells in first dimension.");
	}
	
	// init all patches
	sidl::array< pde::PatchCxx > tmp_allpatches = sidl::array< pde::PatchCxx >::create1d(npatches);
	for (int i = 0; i < npatches; i++) {
		tmp_allpatches.set(i, pde::PatchCxx::_create() );
	}
	for (int i = 0; i < npatches; i++) {
		sidl::array< int32_t > decomp = bsl::arr::decompose1dC(nx, npatches, i);
		int64_t nid = pde::PatchCxx::nextId();
		pde::PatchCxx np = tmp_allpatches[i];

		switch (dim) {
		case 1:
			std::cout << "pde.MeshCxx.compose1 patch " << nid << " low " << decomp[0] << " hi " << decomp[1] << std::endl;
			np.init1d(nid, -1, decomp[0], decomp[1]);
			if (i == 0) {
				np.addBoundary(pde::BoundPos_LOW0);
			}
			if (i == (npatches-1) ) {
				np.addBoundary(pde::BoundPos_HIGH0);
			}
			break;
		case 2:
			np.init2d(nid, -1, decomp[0], decomp[1], 0,ishape[1]-1);
			if (i == 0) {
				np.addBoundary(pde::BoundPos_LOW0);
			}
			if (i == (npatches-1) ) {
				np.addBoundary(pde::BoundPos_HIGH0);
			}
			// second axis not split, so we have both bounds in that direction.
			np.addBoundary(pde::BoundPos_LOW1); 
			np.addBoundary(pde::BoundPos_HIGH1);
			break;
		case 3:
			np.init3d(nid, -1, decomp[0], decomp[1], 0,ishape[1]-1, 0,ishape[2]-1);
			// second, third axes not split, so we have both bounds in that direction.
			np.addBoundary(pde::BoundPos_LOW1); 
			np.addBoundary(pde::BoundPos_HIGH1);
			np.addBoundary(pde::BoundPos_LOW2); 
			np.addBoundary(pde::BoundPos_HIGH2);
			break;
		default:
			return 1; // unsupported as yet.
		}

		int64_t left = nid-1;
		int64_t right = nid+1;
		// patches don't know about periodicity
		if (i == (npatches-1)) {
			right = -1;
		}
		if (i == 0) {
			left = -1;
		}
		np.addNeighbor(pde::BoundPos_LOW0, left);
		np.addNeighbor(pde::BoundPos_HIGH0, right);
	}

	d_allpatches = tmp_allpatches;
	if (! commset) {
		d_localpatches = d_allpatches;
		for (int i = 0; i < npatches; i++) {
			d_allpatches[i].setProcId(d_procrank);
		}
	} else {
		for (int32_t j = 0 ; j < d_procsize; j++) {
			sidl::array< int32_t >  procDecomp = bsl::arr::decompose1dC(npatches, d_procsize, j);
			int offset = procDecomp[0];
			for (int i = 0; i < procDecomp[2]; i++)
			{
				d_allpatches[i+offset].setProcId(j);
			}
			if (d_procrank == j) {
				d_localpatches = sidl::array< pde::PatchCxx >::create1d(procDecomp[2]);
				for (int i = 0; i < procDecomp[2]; i++)
				{
					d_localpatches.set(i, d_allpatches[i+offset]);
				}
			}
		}
	}

	return 0;

    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.compose1)
}

/**
 *  Compose the data. This is called after configure.
 * Define the domain to be the global union of patches
 * defined by tiling the domain in chunks with dimensions
 * tileSize (or larger at the domain upper edges).
 * A Decomposition algorithm will try to even the number of
 * mesh cells on each processor if parallelism is in use.
 * @param tileSize an array of size getDimension. e.g.
 * for a 2d domain, tileSize={3,3} will yield nominally 3x3 patches.
 * Note: tileSize elements smaller than stencil_radius and tBoundaryWidthDefault
 * are probably a bad idea.
 * @return Error : return -1, else 0
 */
int32_t
pde::MeshCxx_impl::composeTile_impl (
  /* in array<int> */::sidl::array<int32_t> tileSize ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.composeTile)
	CONFIGURED("composeTile");
	// FIXME pde::MeshCxx_impl::composeTile_impl unimplemented
	return -1;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.composeTile)
}

/**
 *  @return list of all patch ids on this mesh. 
 */
::sidl::array<int64_t>
pde::MeshCxx_impl::getPatchIds_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.getPatchIds)
	COMPOSED("getPatchIds");
	int32_t len = d_allpatches.upper(0);
	::sidl::array<int64_t> result = ::sidl::array<int64_t>::create1d(len+1);
	for (int i=0; i <= len; i++) {
		int64_t gid = d_allpatches[i].getGlobalId();
		std::cout << "returning id " << gid << std::endl;
		result.set(i, gid );
	}
	return result;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.getPatchIds)
}

/**
 *  @return patch with the given globalid. 
 */
::pde::Patch
pde::MeshCxx_impl::getPatch_impl (
  /* in */int64_t globalid ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.getPatch)
	COMPOSED("getPatch");
	int32_t len = d_allpatches.upper(0);
	::pde::Patch result;
	for (int i=0; i <= len; i++) {
		if ( d_allpatches[i].getGlobalId() == globalid) {
			return d_allpatches[i];
		}
	}
	BOCCA_THROW_CXX(sidl::SIDLException, "unknown global id on this mesh");
	return result ; // notreached we hope.
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.getPatch)
}

/**
 *  fetch the shape, corners of the boundary cell region along the side given. 
 * @param windowlb windowub, shape should all be dim long 1d arrays.
 */
void
pde::MeshCxx_impl::getBoundaryWindow_impl (
  /* in */::pde::BoundPos side,
  /* inout array<int> */::sidl::array<int32_t>& windowlb,
  /* inout array<int> */::sidl::array<int32_t>& windowub,
  /* inout array<int> */::sidl::array<int32_t>& shape ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.getBoundaryWindow)
	CONFIGURED("getShape");
	if (bwd < 1) {
		return; // throw here?
	}
	int32_t lo[3], hi[3], delta[3], i;
	// set total volume as result
	for (i = 0; i < 3; i++) {
		lo[i] = -bwd;
		hi[i] = ishape[i] + bwd -1;
	}
	switch (side) {
	case pde::BoundPos_LOW0:
		hi[0] = -1;
		break;
	case pde::BoundPos_HIGH0:
		lo[0] = ishape[0];
		break;
	case pde::BoundPos_LOW1:
		hi[1] = -1;
		break;
	case pde::BoundPos_HIGH1:
		lo[1] = ishape[1];
		break;
	case pde::BoundPos_LOW2:
		hi[2] = -1;
		break;
	case pde::BoundPos_HIGH2:
		lo[2] = ishape[2];
		break;
	default:	
		BOCCA_THROW_CXX(sidl::SIDLException,"unexpected side given to pde::MeshCxx_impl::getBoundaryWindow");
	}
	// sidl::array<int32_t> result = sidl::array<int32_t>::create1d(dim);
	for (i = 0; i < dim; i++) {
		windowlb.set(i, lo[i]);
		windowub.set(i, hi[i]);
		shape.set(i, hi[i]-lo[i]+1);
	}
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.getBoundaryWindow)
}

/**
 *  Setup and return a FieldVar declared on this mesh.
 * Exactly One of the compose functions must be done before any
 * flavor fields are created.
 * @bug Only MeshColl_CENTERS is currently supported for coll.
 * @param name : Name of the FieldVar being formed
 * @param nvars : # of components making up a point in the field.
 * @param coll : Mesh collocation type.
 * @return Error : returns NULL
 */
::pde::FieldVar
pde::MeshCxx_impl::createFieldVar_impl (
  /* in */const ::std::string& name,
  /* in */int32_t nvars,
  /* in */::pde::MeshColl coll,
  /* in */::pde::BoundaryCondition bc ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.createFieldVar)
	CONFIGURED("createFieldVar");
	if (vars.find(name) != vars.end() ) { 
		std::string s = "pde.MeshCxx.createFieldVar called twice with same name: ";
		s += name;
		BOCCA_THROW_CXX(sidl::SIDLException, s);
	}
	::pde::FieldVarCxx iresult = pde::FieldVarCxx::_create();
	::pde::Mesh m = *this;
 	sidl::array< pde::Patch >patches = sidl::array< pde::Patch >::create1d(d_localpatches.length(0));
	for (int i=0, j=d_localpatches.lower(0); j <= d_localpatches.upper(0); j++,i++) {
		patches.set(i, d_localpatches[j]);
	}
	iresult.init(name, nvars, coll, bc, m, patches);
	::pde::FieldVar result = iresult;
	vars[name] = result;
	return result;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.createFieldVar)
}

/**
 *  return an existing field var, or an exception if name is unknown. 
 */
::pde::FieldVar
pde::MeshCxx_impl::getFieldVar_impl (
  /* in */const ::std::string& name ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.getFieldVar)
	
	if (vars.find(name) == vars.end() ) { 
		std::string s = "pde.MeshCxx.createFieldVar called with unknown name: ";
		s += name;
		BOCCA_THROW_CXX(sidl::SIDLException, s);
	}
	return vars[name];
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.getFieldVar)
}

/**
 *  return the names of all fieldvars.  
 */
::sidl::array< ::std::string>
pde::MeshCxx_impl::getFieldNames_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.getFieldNames)
	int32_t size = (int32_t) (vars.size());
	sidl::array< std::string > result = ::sidl::array< ::std::string>::create1d(size);
	int i = 0;
	
	std::map< std::string, pde::FieldVar >::iterator it;
	for( it = vars.begin(); it != vars.end(); it++ ) {
		result.set(i, it->first);
		i++;
	}
	return result;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.getFieldNames)
}

/**
 *  @name Time related methods
 */
int32_t
pde::MeshCxx_impl::currentTime_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.currentTime)
	CONFIGURED("currentTime");
	return tcur;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.currentTime)
}

/**
 * Method:  stepsCompleted[]
 */
int32_t
pde::MeshCxx_impl::stepsCompleted_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.stepsCompleted)
	CONFIGURED("stepsCompleted");
	return steps;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.stepsCompleted)
}

/**
 * Method:  incrementTime[]
 */
int32_t
pde::MeshCxx_impl::incrementTime_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.incrementTime)
	CONFIGURED("incrementTime");
	tcur++;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.incrementTime)
}

/**
 *  syncronise all FieldVars on this grid. i.e. ghost update.
 * @param timestep : an int showing which timestep to sync data at
 * @return Error returns -1 else 0
 */
int32_t
pde::MeshCxx_impl::sync_impl (
  /* in */int32_t timestep ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.sync)
	CONFIGURED("sync");
	std::map< std::string, pde::FieldVar >::iterator it;
	for( it = vars.begin(); it != vars.end(); it++ ) {
		it->second.synchronize(timestep);
	}
	return 0;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.sync)
}

/**
 * Method:  getProcCount[]
 */
int32_t
pde::MeshCxx_impl::getProcCount_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.getProcCount)
	return d_procsize;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.getProcCount)
}

/**
 * Method:  getCommunicator[]
 */
int64_t
pde::MeshCxx_impl::getCommunicator_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.getCommunicator)
	if (! commset) {
		BOCCA_THROW_CXX(sidl::SIDLException, "pde.MeshCxx.getCommunicator called without communicator set.");
	}
	return fcomm;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.getCommunicator)
}

/**
 * Method:  getProcId[]
 */
int32_t
pde::MeshCxx_impl::getProcId_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.getProcId)
	return d_procrank;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.getProcId)
}

/**
 * Method:  boxContains[]
 */
bool
pde::MeshCxx_impl::boxContains_impl (
  /* in array<int> */::sidl::array<int32_t> lowerCorner,
  /* in array<int> */::sidl::array<int32_t> upperCorner,
  /* in array<int> */::sidl::array<int32_t> point ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.boxContains)
        if (point._is_nil() || lowerCorner._is_nil() || upperCorner._is_nil()) {
                return false;
        }
        if (point.length(0) <  lowerCorner.length() || lowerCorner.length() != upperCorner.length()) {
                std::cout << "Dimension range error in boxContains." << std::endl;
                BOCCA_THROW_CXX(::sidl::SIDLException, "Dimension range error in boxContains.");
        }
        for (int32_t d = point.lower(0); d <= point.upper(0); d++) {
                if (point[d] > upperCorner[d] || point[d] < lowerCorner[d])
                {
                        return false;
                }
        }
        return true;

  // DO-NOT-DELETE splicer.end(pde.MeshCxx.boxContains)
}

/**
 * Method:  boxVolume[]
 */
int64_t
pde::MeshCxx_impl::boxVolume_impl (
  /* in array<int> */::sidl::array<int32_t> lowerCorner,
  /* in array<int> */::sidl::array<int32_t> upperCorner ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.boxVolume)
	int64_t volume = 1;
	int32_t pdim = lowerCorner.length();
        for (int i=0; i < pdim; i++) {
                int32_t si = upperCorner[i]-lowerCorner[i] + 1;
                volume *= si;
        }
	return volume;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.boxVolume)
}

/**
 * Method:  shapeVolume[]
 */
int64_t
pde::MeshCxx_impl::shapeVolume_impl (
  /* in array<int> */::sidl::array<int32_t> shape ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshCxx.shapeVolume)
	int64_t volume = 1;
	for (int32_t i = shape.lower(0); i <= shape.upper(0) ; i++) {
		volume *= shape[i];
	}
	return volume;
  // DO-NOT-DELETE splicer.end(pde.MeshCxx.shapeVolume)
}


// DO-NOT-DELETE splicer.begin(pde.MeshCxx._misc)
// Insert-Code-Here {pde.MeshCxx._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(pde.MeshCxx._misc)

