/*
 * File:          bsl_arr_Impl.h
 * Symbol:        bsl.arr-v0.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for bsl.arr
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_bsl_arr_Impl_h
#define included_bsl_arr_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_bsl_arr_h
#include "bsl_arr.h"
#endif
#ifndef included_bsl_arrx_h
#include "bsl_arrx.h"
#endif
#ifndef included_bsl_morph_h
#include "bsl_morph.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif

/* DO-NOT-DELETE splicer.begin(bsl.arr._hincludes) */
/* Insert-Code-Here {bsl.arr._hincludes} (include files) */
/* DO-NOT-DELETE splicer.end(bsl.arr._hincludes) */

/*
 * Private data for class bsl.arr
 */

struct bsl_arr__data {
  /* DO-NOT-DELETE splicer.begin(bsl.arr._data) */
  /* Insert-Code-Here {bsl.arr._data} (private data members) */
  int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(bsl.arr._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct bsl_arr__data*
bsl_arr__get_data(
  bsl_arr);

extern void
bsl_arr__set_data(
  bsl_arr,
  struct bsl_arr__data*);

extern
void
impl_bsl_arr__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr__ctor(
  /* in */ bsl_arr self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr__ctor2(
  /* in */ bsl_arr self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr__dtor(
  /* in */ bsl_arr self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern
char*
impl_bsl_arr_str(
  /* in array<> */ struct sidl__array* a,
  /* out */ sidl_BaseInterface *_ex);

extern
char*
impl_bsl_arr_toString(
  /* in array<> */ struct sidl__array* a,
  /* out */ sidl_BaseInterface *_ex);

extern
char*
impl_bsl_arr_toStringC(
  /* in */ void* dataPointer,
  /* in */ int32_t dataLen,
  /* in */ enum bsl_datatype__enum dt,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_fillBool(
  /* inout array<> */ struct sidl__array** a,
  /* in */ sidl_bool value,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_fillInt(
  /* inout array<> */ struct sidl__array** a,
  /* in */ int32_t value,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_fillLong(
  /* inout array<> */ struct sidl__array** a,
  /* in */ int64_t value,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_fillFloat(
  /* inout array<> */ struct sidl__array** a,
  /* in */ float value,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_fillDouble(
  /* inout array<> */ struct sidl__array** a,
  /* in */ double value,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_fillFcomplex(
  /* inout array<> */ struct sidl__array** a,
  /* in */ struct sidl_fcomplex value,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_fillDcomplex(
  /* inout array<> */ struct sidl__array** a,
  /* in */ struct sidl_dcomplex value,
  /* out */ sidl_BaseInterface *_ex);

extern
struct sidl__array*
impl_bsl_arr_clone(
  /* in array<> */ struct sidl__array* a,
  /* out */ sidl_BaseInterface *_ex);

extern
struct sidl_int__array*
impl_bsl_arr_cloneInt1(
  /* in array<int> */ struct sidl_int__array* a,
  /* out */ sidl_BaseInterface *_ex);

extern
struct sidl_double__array*
impl_bsl_arr_cloneDouble1(
  /* in array<double> */ struct sidl_double__array* a,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_loadC(
  /* inout array<> */ struct sidl__array** a,
  /* in */ void* dataPointer,
  /* in */ int32_t dataLen,
  /* in */ enum bsl_datatype__enum dt,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_load1Float(
  /* inout array<> */ struct sidl__array** a1,
  /* in rarray[m] */ float* values,
  /* in */ int32_t m,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_load2Float(
  /* inout array<> */ struct sidl__array** a2,
  /* in rarray[m,n] */ float* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_load3Float(
  /* inout array<> */ struct sidl__array** a3,
  /* in rarray[m,n,p] */ float* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* in */ int32_t p,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_load1Double(
  /* inout array<> */ struct sidl__array** a1,
  /* in rarray[m] */ double* values,
  /* in */ int32_t m,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_load2Double(
  /* inout array<> */ struct sidl__array** a2,
  /* in rarray[m,n] */ double* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_load3Double(
  /* inout array<> */ struct sidl__array** a3,
  /* in rarray[m,n,p] */ double* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* in */ int32_t p,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_load1Int(
  /* inout array<> */ struct sidl__array** a1,
  /* in rarray[m] */ int32_t* values,
  /* in */ int32_t m,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_load2Int(
  /* inout array<> */ struct sidl__array** a2,
  /* in rarray[m,n] */ int32_t* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_load3Int(
  /* inout array<> */ struct sidl__array** a3,
  /* in rarray[m,n,p] */ int32_t* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* in */ int32_t p,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_load1Long(
  /* inout array<> */ struct sidl__array** a1,
  /* in rarray[m] */ int64_t* values,
  /* in */ int32_t m,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_load2Long(
  /* inout array<> */ struct sidl__array** a2,
  /* in rarray[m,n] */ int64_t* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_load3Long(
  /* inout array<> */ struct sidl__array** a3,
  /* in rarray[m,n,p] */ int64_t* values,
  /* in */ int32_t m,
  /* in */ int32_t n,
  /* in */ int32_t p,
  /* out */ sidl_BaseInterface *_ex);

extern
struct sidl__array*
impl_bsl_arr_allocate1d(
  /* in */ enum bsl_datatype__enum dt,
  /* in */ int32_t size,
  /* out */ sidl_BaseInterface *_ex);

extern
struct sidl__array*
impl_bsl_arr_allocate2d(
  /* in */ enum bsl_datatype__enum dt,
  /* in */ int32_t sizex,
  /* in */ int32_t sizey,
  /* out */ sidl_BaseInterface *_ex);

extern
struct sidl__array*
impl_bsl_arr_allocate3d(
  /* in */ enum bsl_datatype__enum dt,
  /* in */ int32_t sizex,
  /* in */ int32_t sizey,
  /* in */ int32_t sizez,
  /* out */ sidl_BaseInterface *_ex);

extern
struct sidl_int__array*
impl_bsl_arr_decompose1dC(
  /* in */ int32_t n,
  /* in */ int32_t size,
  /* in */ int32_t rank,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_bsl_arr_computeIntersection(
  /* in array<int> */ struct sidl_int__array* low1,
  /* in array<int> */ struct sidl_int__array* high1,
  /* in array<int> */ struct sidl_int__array* low2,
  /* in array<int> */ struct sidl_int__array* high2,
  /* inout rarray[d] */ int32_t* low,
  /* inout rarray[d] */ int32_t* high,
  /* in */ int32_t d,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_bsl_arr_indexToCoord(
  /* in */ int32_t index,
  /* in array<int> */ struct sidl_int__array* lowerCorner,
  /* in array<int> */ struct sidl_int__array* upperCorner,
  /* out */ int32_t* i0,
  /* out */ int32_t* i1,
  /* out */ int32_t* i2,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_bsl_arr_coordToIndex(
  /* in */ int32_t varNumber,
  /* in array<int> */ struct sidl_int__array* lowerCorner,
  /* in array<int> */ struct sidl_int__array* upperCorner,
  /* in */ int32_t i0,
  /* in */ int32_t i1,
  /* in */ int32_t i2,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_bsl_arr_boxVolume(
  /* in array<int> */ struct sidl_int__array* lowerCorner,
  /* in array<int> */ struct sidl_int__array* upperCorner,
  /* out */ sidl_BaseInterface *_ex);

extern struct bsl_arr__object* impl_bsl_arr_fconnect_bsl_arr(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct bsl_arr__object* impl_bsl_arr_fcast_bsl_arr(void* bi, 
  sidl_BaseInterface* _ex);
extern struct bsl_arrx__object* impl_bsl_arr_fconnect_bsl_arrx(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct bsl_arrx__object* impl_bsl_arr_fcast_bsl_arrx(void* bi, 
  sidl_BaseInterface* _ex);
extern struct bsl_morph__object* impl_bsl_arr_fconnect_bsl_morph(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct bsl_morph__object* impl_bsl_arr_fcast_bsl_morph(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* impl_bsl_arr_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_bsl_arr_fcast_sidl_BaseClass(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_bsl_arr_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* impl_bsl_arr_fcast_sidl_BaseInterface(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_bsl_arr_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_bsl_arr_fcast_sidl_ClassInfo(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_bsl_arr_fconnect_sidl_RuntimeException(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_bsl_arr_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* _ex);
extern
void
impl_bsl_arr_boccaForceUsePortInclude(
  /* in */ bsl_arr self,
  /* in */ bsl_arrx dummy0,
  /* in */ enum bsl_datatype__enum dummy1,
  /* in */ bsl_morph dummy2,
  /* out */ sidl_BaseInterface *_ex);

extern struct bsl_arr__object* impl_bsl_arr_fconnect_bsl_arr(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct bsl_arr__object* impl_bsl_arr_fcast_bsl_arr(void* bi, 
  sidl_BaseInterface* _ex);
extern struct bsl_arrx__object* impl_bsl_arr_fconnect_bsl_arrx(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct bsl_arrx__object* impl_bsl_arr_fcast_bsl_arrx(void* bi, 
  sidl_BaseInterface* _ex);
extern struct bsl_morph__object* impl_bsl_arr_fconnect_bsl_morph(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct bsl_morph__object* impl_bsl_arr_fcast_bsl_morph(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* impl_bsl_arr_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_bsl_arr_fcast_sidl_BaseClass(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_bsl_arr_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* impl_bsl_arr_fcast_sidl_BaseInterface(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_bsl_arr_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_bsl_arr_fcast_sidl_ClassInfo(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_bsl_arr_fconnect_sidl_RuntimeException(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_bsl_arr_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* _ex);
#ifdef __cplusplus
}
#endif
#endif
