// 
// File:          pde_UtilC_Impl.cxx
// Symbol:        pde.UtilC-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.UtilC
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_UtilC_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_bsl_morph_hxx
#include "bsl_morph.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_ParameterPortFactory_hxx
#include "gov_cca_ports_ParameterPortFactory.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.UtilC._includes)

  // Insert-UserCode-Here {pde.UtilC._includes:prolog} (additional includes or code)
#include <unistd.h>
#include <stdlib.h>

  // Bocca generated code. bocca.protected.begin(pde.UtilC._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.UtilC._includes)

  // Insert-UserCode-Here {pde.UtilC._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.UtilC._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::UtilC_impl::UtilC_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::UtilC::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(pde.UtilC._ctor2)
  // Insert-Code-Here {pde.UtilC._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.UtilC._ctor2)
}

// user defined constructor
void pde::UtilC_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.UtilC._ctor)
    
	pid_t id = getpid();
	std::ostringstream ps;
	ps << id;
	subs["%U%"] = ps.str();

	char buffer[201];
	buffer[200] = '\0';
	gethostname(buffer,200);
	std::string hostname = buffer;
	subs["%H%"] = hostname;

  // bocca-default-code. User may edit or delete.begin(pde.UtilC._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.UtilC: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.UtilC._ctor)

  // Insert-UserCode-Here {pde.UtilC._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(pde.UtilC._ctor)
}

// user defined destructor
void pde::UtilC_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.UtilC._dtor)
  // Insert-UserCode-Here {pde.UtilC._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.UtilC._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.UtilC: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.UtilC._dtor) 

  // DO-NOT-DELETE splicer.end(pde.UtilC._dtor)
}

// static class initializer
void pde::UtilC_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.UtilC._load)
  // Insert-Code-Here {pde.UtilC._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.UtilC._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
pde::UtilC_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.UtilC.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.UtilC.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "pde.UtilC: Error casting self to gov::cca::Port");
  } 


  // Provide a gov.cca.ports.GoPort port with port name system 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "system", // port instance name
                   "gov.cca.ports.GoPort",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "pde.UtilC: Error calling addProvidesPort(port,"
        "\"system\", \"gov.cca.ports.GoPort\", typeMap) ", -2);
    throw;
  }    

  // Provide a pde.ShellPort port with port name ShellPort 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "ShellPort", // port instance name
                   "pde.ShellPort",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "pde.UtilC: Error calling addProvidesPort(port,"
        "\"ShellPort\", \"pde.ShellPort\", typeMap) ", -2);
    throw;
  }    

  // Use a gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    this->d_services.registerUsesPort(
                   "ppf", // port instance name
                   "gov.cca.ports.ParameterPortFactory",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.UtilC: Error calling registerUsesPort(\"ppf\", "
       "\"gov.cca.ports.ParameterPortFactory\", typeMap) ", -2);
    throw;
  }

  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(pde.UtilC.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(pde.UtilC.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
pde::UtilC_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.UtilC.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.UtilC.boccaReleaseServices)
  this->d_services=0;


  // Un-provide gov.cca.ports.GoPort port with port name system 
  try{
    services.removeProvidesPort("system");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.UtilC: Error calling removeProvidesPort("
              << "\"system\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Un-provide pde.ShellPort port with port name ShellPort 
  try{
    services.removeProvidesPort("ShellPort");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.UtilC: Error calling removeProvidesPort("
              << "\"ShellPort\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    services.unregisterUsesPort("ppf");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.UtilC: Error calling unregisterUsesPort("
              << "\"ppf\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(pde.UtilC.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.UtilC.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::UtilC_impl::boccaForceUsePortInclude_impl (
  /* in */::gov::cca::ports::ParameterPortFactory dummy0,
  /* in */::bsl::morph dummy1 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.UtilC.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.UtilC.boccaForceUsePortInclude)
    (void)dummy0;
    (void)dummy1;

  // Bocca generated code. bocca.protected.end(pde.UtilC.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.UtilC.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
pde::UtilC_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.UtilC.setServices)

  // Insert-UserCode-Here{pde.UtilC.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(pde.UtilC.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(pde.UtilC.setServices)
  
  // define our parameters and the
  userinput = services.createTypeMap();
  ::gov::cca::Port gcp = services.getPort("ppf");

  if (gcp._is_nil()) {
    BOCCA_THROW_CXX(sidl::SIDLException, "ParameterPortFactory not provided by framework");
  }
  ::gov::cca::ports::ParameterPortFactory ppf;
  ppf = ::babel_cast< gov::cca::ports::ParameterPortFactory >(gcp);
  if (ppf._is_nil()) {
    BOCCA_THROW_CXX(sidl::SIDLException, "Bogus ParameterPortFactory provided");
  }

  ppf.initParameterData(userinput, "userinput");
  ppf.setBatchTitle(userinput, "Shell invocation options");
  ppf.addRequestString(userinput, "base", "Template for argument to system() in C.", "system() argument", "echo 'hello world'");
  ppf.addRequestString(userinput, "source", "source name", "source name", "UtilC");
  ppf.addRequestString(userinput, "add", "new substitution pair", "match,replacement", "x,x");
  ppf.addParameterPort(userinput, services);
  services.releasePort("ppf");
 

  // DO-NOT-DELETE splicer.end(pde.UtilC.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
pde::UtilC_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.UtilC.releaseServices)

  // Insert-UserCode-Here {pde.UtilC.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(pde.UtilC.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(pde.UtilC.releaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.UtilC.releaseServices)
}

/**
 *  
 * Execute some encapsulated functionality on the component. 
 * Return 0 if ok, -1 if internal error but component may be 
 * used further, and -2 if error so severe that component cannot
 * be further used safely.
 */
int32_t
pde::UtilC_impl::go_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.UtilC.go)
// User editable portion is in the middle at the next Insert-UserCode-Here line.


// Bocca generated code. bocca.protected.begin(pde.UtilC.go:boccaGoProlog)
  int bocca_status = 0;
  // The user's code should set bocca_status 0 if computation proceeded ok.
  // The user's code should set bocca_status -1 if computation failed but might
  // succeed on another call to go(), e.g. when a required port is not yet 
  // connected.
  // The user's code should set bocca_status -2 if the computation failed and 
  // can never succeed in a future call.
  // The user's code should NOT use return in this function.
  // Exceptions that are not caught in user code will be converted to 
  // status -2.

  gov::cca::Port port;

  // nil if not fetched and cast successfully:
  gov::cca::ports::ParameterPortFactory ppf; 
  // True when releasePort is needed (even if cast fails):
  bool ppf_fetched = false; 
  // Use a gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    port = this->d_services.getPort("ppf");
  } catch ( ::gov::cca::CCAException ex )  {
    // we will continue with port nil (never successfully assigned) and 
    // set a flag.

#ifdef _BOCCA_STDERR
    std::cerr << "pde.UtilC: Error calling getPort(\"ppf\") "
              " at " << __FILE__ << ":" << __LINE__ -5 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }
  if ( port._not_nil() ) {
    // even if the next cast fails, must release.
    ppf_fetched = true; 
    ppf = ::babel_cast< gov::cca::ports::ParameterPortFactory >(port);
    if (ppf._is_nil()) {

#ifdef _BOCCA_STDERR
      std::cerr << "pde.UtilC: Error casting gov::cca::Port "
                << "ppf to type "
                << "gov::cca::ports::ParameterPortFactory" << std::endl;
#endif //_BOCCA_STDERR

      goto BOCCAEXIT; // we cannot correctly continue. clean up and leave.
    } 
  } 

// Bocca generated code. bocca.protected.end(pde.UtilC.go:boccaGoProlog)



  // When this try/catch block is rewritten by the user, we will not change it.
  try {

    // All port instances should be rechecked for ._not_nil before calling in 
    // user code. Not all ports need be connected in arbitrary use.
    // The uses ports appear as local variables here named exactly as on the 
    // bocca commandline.

	this->system();
  } 
  // If unknown exceptions in the user code are tolerable and restart is ok, 
  // return -1 instead. -2 means the component is so confused that it and 
  // probably the application should be destroyed.
  // babel requires exact exception catching due to c++ binding of interfaces.
  catch (gov::cca::CCAException ex) {
    bocca_status = -2;
    std::string enote = ex.getNote();

#ifdef _BOCCA_STDERR
    std::cerr << "CCAException in user go code: " << enote << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;;
#endif

  }
  catch (sidl::RuntimeException ex) {
    bocca_status = -2;
    std::string enote = ex.getNote();

#ifdef _BOCCA_STDERR
    std::cerr << "RuntimeException in user go code: " << enote << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;;
#endif

  }
  catch (sidl::SIDLException ex) {
    bocca_status = -2;
    std::string enote = ex.getNote();

#ifdef _BOCCA_STDERR
    std::cerr << "SIDLException in user go code: " << enote << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;;
#endif

  }
  catch (sidl::BaseException ex) {
    bocca_status = -2;
    std::string enote = ex.getNote();

#ifdef _BOCCA_STDERR
    std::cerr << "BaseException in user go code: " << enote << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;;
#endif

  }
  catch (std::exception ex) {
    bocca_status = -2;

#ifdef _BOCCA_STDERR
    std::cerr << "C++ exception in user go code: " << ex.what() << std::endl;
    std::cerr << "Returning -2 from go()"  << std::endl;
#endif

  }
  catch (...) {
    bocca_status = -2;

#ifdef _BOCCA_STDERR
    std::cerr << "Odd exception in user go code " << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;
#endif

  }


  BOCCAEXIT:; // target point for error and regular cleanup. do not delete.
// Bocca generated code. bocca.protected.begin(pde.UtilC.go:boccaGoEpilog)

  // release ppf 
  if (ppf_fetched) {
    ppf_fetched = false;
    try{
      this->d_services.releasePort("ppf");
    } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
      std::cerr << "pde.UtilC: Error calling releasePort("
                << "\"ppf\") at " 
                << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
                << std::endl;
#endif // _BOCCA_STDERR

    }
    // c++ port reference will be dropped when function exits, but we 
    // must tell framework.
  }

  return bocca_status;
// Bocca generated code. bocca.protected.end(pde.UtilC.go:boccaGoEpilog)

    
    
  // DO-NOT-DELETE splicer.end(pde.UtilC.go)
}

/**
 *  set a string that will be substituted and evaluated per:
 * %U% <-- unix proc id getpid result
 * %H% <-- hostname gethostname result
 * %C% <-- component instance name
 * %I% <-- iteration
 * %match% <-- where match comes from replacments added.
 */
void
pde::UtilC_impl::setCommandTemplate_impl (
  /* in */const ::std::string& shellCommand ) 
{
  // DO-NOT-DELETE splicer.begin(pde.UtilC.setCommandTemplate)
	userinput.putString("base",shellCommand);
  // DO-NOT-DELETE splicer.end(pde.UtilC.setCommandTemplate)
}

/**
 * Method:  setComponentName[]
 */
void
pde::UtilC_impl::setComponentName_impl (
  /* in */const ::std::string& sourceName ) 
{
  // DO-NOT-DELETE splicer.begin(pde.UtilC.setComponentName)
	userinput.putString("source", sourceName);
  // DO-NOT-DELETE splicer.end(pde.UtilC.setComponentName)
}

/**
 * Method:  setIteration[]
 */
void
pde::UtilC_impl::setIteration_impl (
  /* in */int32_t iteration ) 
{
  // DO-NOT-DELETE splicer.begin(pde.UtilC.setIteration)
  std::ostringstream ps;
  ps << iteration;
  std::string pid = ps.str();
  subs["%I%"] = pid;
  // DO-NOT-DELETE splicer.end(pde.UtilC.setIteration)
}

/**
 * Method:  setReplacement[]
 */
void
pde::UtilC_impl::setReplacement_impl (
  /* in */const ::std::string& match,
  /* in */const ::std::string& replacement ) 
{
  // DO-NOT-DELETE splicer.begin(pde.UtilC.setReplacement)
	subs[match] = replacement;
  // DO-NOT-DELETE splicer.end(pde.UtilC.setReplacement)
}

/**
 *  invoke the currently set command after substitution 
 */
int32_t
pde::UtilC_impl::system_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.UtilC.system)
	
	std::string call = userinput.getString("base", "echo undfined-command-template");
	subs["%C%"] = userinput.getString("source","no-source");
	for ( std::map< std::string, std::string >::iterator it=subs.begin(); it!=subs.end(); ++it) {
		call = bsl::morph::replaceAll(call, it->first, it->second);
	}
	int result = ::system( call.c_str());
	return result;
  // DO-NOT-DELETE splicer.end(pde.UtilC.system)
}


// DO-NOT-DELETE splicer.begin(pde.UtilC._misc)
// Insert-Code-Here {pde.UtilC._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(pde.UtilC._misc)

