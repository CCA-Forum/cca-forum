// 
// File:          bsl_morph_Impl.hxx
// Symbol:        bsl.morph-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for bsl.morph
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_bsl_morph_Impl_hxx
#define included_bsl_morph_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_bsl_morph_IOR_h
#include "bsl_morph_IOR.h"
#endif
#ifndef included_bsl_datatype_hxx
#include "bsl_datatype.hxx"
#endif
#ifndef included_bsl_morph_hxx
#include "bsl_morph.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif

// duplicate hinclude, include blocks. bocca splicer will ignore the unneeded one. babel cannot handle this file directly, but isn't asked to.
// DO-NOT-DELETE splicer.begin(bsl.morph._hincludes)

size_t bsl_morph_substitute(size_t m, std::string& line, std::string a, std::string b);

// DO-NOT-DELETE splicer.end(bsl.morph._hincludes)
// DO-NOT-DELETE splicer.begin(bsl.morph._includes)

size_t bsl_morph_substitute(size_t m, std::string& line, std::string a, std::string b);

// DO-NOT-DELETE splicer.end(bsl.morph._includes)

namespace bsl { 

  /**
   * Symbol "bsl.morph" (version 0.0)
   */
  class morph_impl : public virtual ::bsl::morph 
  // DO-NOT-DELETE splicer.begin(bsl.morph._inherits)
  // Insert-Code-Here {bsl.morph._inherits} (optional inheritance here)
  // DO-NOT-DELETE splicer.end(bsl.morph._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(bsl.morph._implementation)
    // Insert-Code-Here {bsl.morph._implementation} (additional details)
    // DO-NOT-DELETE splicer.end(bsl.morph._implementation)

  public:
    // default constructor, used for data wrapping(required)
    morph_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    morph_impl( struct bsl_morph__object * s ) : StubBase(s,true), _wrapped(
      false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~morph_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:
    /**
     * user defined static method
     */
    static ::std::string
    datatype2string_impl (
      /* in */::bsl::datatype dt
    )
    ;

    /**
     * user defined static method
     */
    static ::bsl::datatype
    string2datatype_impl (
      /* in */const ::std::string& s
    )
    ;


    /**
     *  replace all occurences of match in buffer with replacement and return a
     * result. buffer is not modified. match is a literal, not a regular expression.
     */
    static ::std::string
    replaceAll_impl (
      /* in */const ::std::string& buffer,
      /* in */const ::std::string& match,
      /* in */const ::std::string& replacement
    )
    ;



    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude_impl (
      /* in */::bsl::datatype dummy0
    )
    ;

  };  // end class morph_impl

} // end namespace bsl

// DO-NOT-DELETE splicer.begin(bsl.morph._misc)
// Insert-Code-Here {bsl.morph._misc} (miscellaneous things)
// DO-NOT-DELETE splicer.end(bsl.morph._misc)

#endif
