// 
// File:          pde_MeshFactory_Impl.cxx
// Symbol:        pde.MeshFactory-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.MeshFactory
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_MeshFactory_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_ccaffeine_ports_MPIService_hxx
#include "ccaffeine_ports_MPIService.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_pde_Mesh_hxx
#include "pde_Mesh.hxx"
#endif
#ifndef included_pde_MeshCxx_hxx
#include "pde_MeshCxx.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.MeshFactory._includes)

  // Insert-UserCode-Here {pde.MeshFactory._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(pde.MeshFactory._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.MeshFactory._includes)

  // Insert-UserCode-Here {pde.MeshFactory._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.MeshFactory._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::MeshFactory_impl::MeshFactory_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::MeshFactory::_wrapObj(reinterpret_cast< void*>(this))),false) , 
  _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(pde.MeshFactory._ctor2)
  // Insert-Code-Here {pde.MeshFactory._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.MeshFactory._ctor2)
}

// user defined constructor
void pde::MeshFactory_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.MeshFactory._ctor)
    
  // Insert-UserCode-Here {pde.MeshFactory._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(pde.MeshFactory._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.MeshFactory: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.MeshFactory._ctor)

  // Insert-UserCode-Here {pde.MeshFactory._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(pde.MeshFactory._ctor)
}

// user defined destructor
void pde::MeshFactory_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.MeshFactory._dtor)
  // Insert-UserCode-Here {pde.MeshFactory._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.MeshFactory._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.MeshFactory: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.MeshFactory._dtor) 

  // DO-NOT-DELETE splicer.end(pde.MeshFactory._dtor)
}

// static class initializer
void pde::MeshFactory_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.MeshFactory._load)
  // Insert-Code-Here {pde.MeshFactory._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.MeshFactory._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
pde::MeshFactory_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.MeshFactory.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.MeshFactory.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "pde.MeshFactory: Error casting self to gov::cca::Port");
  } 


  // Provide a pde.MeshSource port with port name MeshSource 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "MeshSource", // port instance name
                   "pde.MeshSource",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "pde.MeshFactory: Error calling addProvidesPort(port,"
        "\"MeshSource\", \"pde.MeshSource\", typeMap) ", -2);
    throw;
  }    

  // Use a ccaffeine.ports.MPIService port with port name MPIService 
  try{
    this->d_services.registerUsesPort(
                   "MPIService", // port instance name
                   "ccaffeine.ports.MPIService",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.MeshFactory: Error calling registerUsesPort(\"MPIService\", "
       "\"ccaffeine.ports.MPIService\", typeMap) ", -2);
    throw;
  }


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(pde.MeshFactory.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(pde.MeshFactory.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
pde::MeshFactory_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.MeshFactory.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.MeshFactory.boccaReleaseServices)
  this->d_services=0;


  // Un-provide pde.MeshSource port with port name MeshSource 
  try{
    services.removeProvidesPort("MeshSource");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.MeshFactory: Error calling removeProvidesPort("
              << "\"MeshSource\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release ccaffeine.ports.MPIService port with port name MPIService 
  try{
    services.unregisterUsesPort("MPIService");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.MeshFactory: Error calling unregisterUsesPort("
              << "\"MPIService\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(pde.MeshFactory.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.MeshFactory.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::MeshFactory_impl::boccaForceUsePortInclude_impl (
  /* in */::ccaffeine::ports::MPIService dummy0,
  /* in */::pde::MeshCxx dummy1 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.MeshFactory.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.MeshFactory.boccaForceUsePortInclude)
    (void)dummy0;
    (void)dummy1;

  // Bocca generated code. bocca.protected.end(pde.MeshFactory.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.MeshFactory.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
pde::MeshFactory_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.MeshFactory.setServices)

  // Insert-UserCode-Here{pde.MeshFactory.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(pde.MeshFactory.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(pde.MeshFactory.setServices)
  
  // Insert-UserCode-Here{pde.MeshFactory.setServices:epilog}

  // DO-NOT-DELETE splicer.end(pde.MeshFactory.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
pde::MeshFactory_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.MeshFactory.releaseServices)

#ifdef HAVE_MPI
	gov::cca::Port port;
	int k = fcommsForMeshes.size();
	if (k>0) {
		ccaffeine::ports::MPIService MPIService;
		try{
			port = this->d_services.getPort("MPIService");
		} catch ( ::gov::cca::CCAException ex )  {
#ifdef _BOCCA_STDERR
			std::cerr << "pde.MeshFactory: Error calling getPort(\"MPIService\") "
			      " at " << __FILE__ << ":" << __LINE__ -5 << ": " << ex.getNote()
			      << std::endl;
#endif // _BOCCA_STDERR
		}
		if ( port._not_nil() ) {
			MPIService = ::babel_cast< ccaffeine::ports::MPIService >(port);
			if (MPIService._is_nil() ) {
#ifdef _BOCCA_STDERR
				std::cerr << "pde.MeshFactory: Error casting gov::cca::Port "
					<< "MPIService to type "
					<< "ccaffeine::ports::MPIService" << std::endl;
#endif //_BOCCA_STDERR
			} else {
				while (k > 0) {
					int64_t fcomm = fcommsForMeshes[k-1];
					MPIService.releaseComm(fcomm);
					k--;
				}
			}
			
			this->d_services.releasePort("MPIService");
		}
	}
#endif // HAVE_MPI

  // bocca-default-code. User may edit or delete.begin(pde.MeshFactory.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(pde.MeshFactory.releaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.MeshFactory.releaseServices)
}

/**
 *  @return a mesh object for use as desired. For many physics
 * problems, only one mesh is needed.
 */
::pde::Mesh
pde::MeshFactory_impl::createMesh_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.MeshFactory.createMesh)

        ::pde::Mesh m;
        pde::MeshCxx mc;
        mc = pde::MeshCxx::_create();
#ifdef HAVE_MPI
	gov::cca::Port port;
	// nil if not fetched and cast successfully:
	ccaffeine::ports::MPIService MPIService;
	// True when releasePort is needed (even if cast fails):
	bool MPIService_fetched = false;
	try{
		port = this->d_services.getPort("MPIService");
	} catch ( ::gov::cca::CCAException ex )  {
#ifdef _BOCCA_STDERR
		std::cerr << "pde.MeshFactory: Error calling getPort(\"MPIService\") "
		      " at " << __FILE__ << ":" << __LINE__ -5 << ": " << ex.getNote()
		      << std::endl;
#endif // _BOCCA_STDERR
	}
	if ( port._not_nil() ) {
		// even if the next cast fails, must release.
		MPIService_fetched = true;
		MPIService = ::babel_cast< ccaffeine::ports::MPIService >(port);
		if (MPIService._is_nil()) {
#ifdef _BOCCA_STDERR
			std::cerr << "pde.MeshFactory: Error casting gov::cca::Port "
				<< "MPIService to type "
				<< "ccaffeine::ports::MPIService" << std::endl;
#endif //_BOCCA_STDERR
			goto BOCCAEXIT; // we cannot correctly continue. clean up and leave.
		}
	}

	if (MPIService._not_nil()) {
		int64_t fcomm = MPIService.getComm();
		fcommsForMeshes.push_back(fcomm);
		mc.setCommunicator(fcomm);
	}
#endif // HAVE_MPI
        m = mc;

BOCCAEXIT:
#ifdef HAVE_MPI
	if (MPIService_fetched) {
		this->d_services.releasePort("MPIService");
	}
#endif // HAVE_MPI
	return m;

  // DO-NOT-DELETE splicer.end(pde.MeshFactory.createMesh)
}


// DO-NOT-DELETE splicer.begin(pde.MeshFactory._misc)
// Insert-Code-Here {pde.MeshFactory._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(pde.MeshFactory._misc)

