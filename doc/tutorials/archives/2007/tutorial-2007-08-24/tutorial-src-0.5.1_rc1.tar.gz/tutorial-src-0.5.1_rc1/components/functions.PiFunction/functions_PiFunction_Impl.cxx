// 
// File:          functions_PiFunction_Impl.cxx
// Symbol:        functions.PiFunction-v0.0
// Symbol Type:   class
// Babel Version: 1.0.6
// Description:   Server-side implementation for functions.PiFunction
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "functions_PiFunction_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
   // DO-NOT-DELETE splicer.begin(functions.PiFunction._includes)
   // Bocca generated code. bocca.protected.begin(functions.PiFunction:_includes)
#include <iostream>
   // Bocca generated code. bocca.protected.end(functions.PiFunction:_includes)

// Insert-Code-Here {functions.PiFunction._includes} (additional includes or code)
   // DO-NOT-DELETE splicer.end(functions.PiFunction._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
functions::PiFunction_impl::PiFunction_impl() : StubBase(reinterpret_cast< 
  void*>(::functions::PiFunction::_wrapObj(reinterpret_cast< void*>(this))),
  false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(functions.PiFunction._ctor2)
  // Insert-Code-Here {functions.PiFunction._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(functions.PiFunction._ctor2)
}

// user defined constructor
void functions::PiFunction_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(functions.PiFunction._ctor)
  // Insert-Code-Here {functions.PiFunction._ctor} (constructor)
  // DO-NOT-DELETE splicer.end(functions.PiFunction._ctor)
}

// user defined destructor
void functions::PiFunction_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(functions.PiFunction._dtor)
  // Insert-Code-Here {functions.PiFunction._dtor} (destructor)
  // DO-NOT-DELETE splicer.end(functions.PiFunction._dtor)
}

// static class initializer
void functions::PiFunction_impl::_load() {
  // DO-NOT-DELETE splicer.begin(functions.PiFunction._load)
  // Insert-Code-Here {functions.PiFunction._load} (class initialization)
  // DO-NOT-DELETE splicer.end(functions.PiFunction._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  checkException[]
 */
void
functions::PiFunction_impl::checkException_impl (
  /* in */::sidl::BaseInterface excpt,
  /* in */const ::std::string& msg,
  /* in */bool fatal ) 
{
  // DO-NOT-DELETE splicer.begin(functions.PiFunction.checkException)
  // Insert-Code-Here {functions.PiFunction.checkException} (checkException method)
    
    // DO-DELETE-WHEN-IMPLEMENTING exception.begin()
    /*
     * This method has not been implemented
     */
    ::sidl::NotImplementedException ex = ::sidl::NotImplementedException::_create();
    ex.setNote("This method has not been implemented");
    ex.add(__FILE__, __LINE__, "checkException");
    throw ex;
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(functions.PiFunction.checkException)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument Svc will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
functions::PiFunction_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(functions.PiFunction.setServices)

  // Bocca generated code. bocca.protected.begin(functions.PiFunction:setServices) 
     boccaSetServices(services); 
  // Bocca generated code. bocca.protected.end(functions.PiFunction:setServices) 
  
  // DO-NOT-DELETE splicer.end(functions.PiFunction.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument Svc will never be nil/null.
 * The argument Svc will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to Svc.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
functions::PiFunction_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(functions.PiFunction.releaseServices)
  // Insert-Code-Here {functions.PiFunction.releaseServices} (releaseServices method)

  // Bocca generated code. bocca.protected.begin(functions.PiFunction:releaseServices)

   using namespace std;

  // Un-provide function.FunctionPort port with port name function 
   try{
      d_services.removeProvidesPort("function");
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "functions.PiFunction: Error calling removeProvidesPort for port instance function - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }

   d_services=0;
   return;
  // Bocca generated code. bocca.protected.end(functions.PiFunction:releaseServices)
    
  // DO-NOT-DELETE splicer.end(functions.PiFunction.releaseServices)
}

/**
 * Method:  init[]
 */
void
functions::PiFunction_impl::init_impl (
  /* in array<double> */::sidl::array<double> params ) 
{
  // DO-NOT-DELETE splicer.begin(functions.PiFunction.init)
    
    
  // Insert-Code-Here {functions.PiFunction.init} (init method)
  // DO-NOT-DELETE splicer.end(functions.PiFunction.init)
}

/**
 * Method:  evaluate[]
 */
double
functions::PiFunction_impl::evaluate_impl (
  /* in */double x ) 
{
  // DO-NOT-DELETE splicer.begin(functions.PiFunction.evaluate)
    
    
  // Insert-Code-Here {functions.PiFunction.evaluate} (evaluate method)

  return 4.0 / (1.0 + x * x);

  // DO-NOT-DELETE splicer.end(functions.PiFunction.evaluate)
}


// DO-NOT-DELETE splicer.begin(functions.PiFunction._misc)

// Bocca generated code. bocca.protected.begin(functions.PiFunction:boccaSetServices)
void
functions::PiFunction_impl::boccaSetServices (
  /* in */::gov::cca::Services& services )
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{

   using namespace std;

   gov::cca::TypeMap typeMap;
   gov::cca::Port    port;

   d_services = services;

   try {
      typeMap = d_services.createTypeMap();
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "functions.PiFunction: Error creating CCA TypeMap- File:" << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }

   port =  ::babel_cast<gov::cca::Port>(*this);
   if (port._is_nil()) {
      cerr << "functions.PiFunction: Error casting component to gov::cca::Port - File : " 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   } 


  // Provide a function.FunctionPort port with port name function 
   try{
      d_services.addProvidesPort(port,
                                        "function",
                                        "function.FunctionPort",
                                        typeMap);
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "functions.PiFunction: Error calling addProvidesPort for function.FunctionPort::function - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }    


   gov::cca::ComponentRelease cr = ::babel_cast<gov::cca::ComponentRelease>(*this);
   d_services.registerForRelease(cr);
   return;
}        
// Bocca generated code. bocca.protected.end(functions.PiFunction:boccaSetServices)
    
// Insert-Code-Here {functions.PiFunction._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(functions.PiFunction._misc)

