// 
// File:          drivers_CXXDriver_Impl.cxx
// Symbol:        drivers.CXXDriver-v0.0
// Symbol Type:   class
// Babel Version: 1.0.6
// Description:   Server-side implementation for drivers.CXXDriver
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "drivers_CXXDriver_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_integrator_IntegratorPort_hxx
#include "integrator_IntegratorPort.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
   // DO-NOT-DELETE splicer.begin(drivers.CXXDriver._includes)
   // Bocca generated code. bocca.protected.begin(drivers.CXXDriver:_includes)
#include <iostream>
   // Bocca generated code. bocca.protected.end(drivers.CXXDriver:_includes)

// Insert-Code-Here {drivers.CXXDriver._includes} (additional includes or code)
   // DO-NOT-DELETE splicer.end(drivers.CXXDriver._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
drivers::CXXDriver_impl::CXXDriver_impl() : StubBase(reinterpret_cast< void*>(
  ::drivers::CXXDriver::_wrapObj(reinterpret_cast< void*>(this))),false) , 
  _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(drivers.CXXDriver._ctor2)
  // Insert-Code-Here {drivers.CXXDriver._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(drivers.CXXDriver._ctor2)
}

// user defined constructor
void drivers::CXXDriver_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(drivers.CXXDriver._ctor)
  // Insert-Code-Here {drivers.CXXDriver._ctor} (constructor)
  // DO-NOT-DELETE splicer.end(drivers.CXXDriver._ctor)
}

// user defined destructor
void drivers::CXXDriver_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(drivers.CXXDriver._dtor)
  // Insert-Code-Here {drivers.CXXDriver._dtor} (destructor)
  // DO-NOT-DELETE splicer.end(drivers.CXXDriver._dtor)
}

// static class initializer
void drivers::CXXDriver_impl::_load() {
  // DO-NOT-DELETE splicer.begin(drivers.CXXDriver._load)
  // Insert-Code-Here {drivers.CXXDriver._load} (class initialization)
  // DO-NOT-DELETE splicer.end(drivers.CXXDriver._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  checkException[]
 */
void
drivers::CXXDriver_impl::checkException_impl (
  /* in */::sidl::BaseInterface excpt,
  /* in */const ::std::string& msg,
  /* in */bool fatal ) 
{
  // DO-NOT-DELETE splicer.begin(drivers.CXXDriver.checkException)
  // Insert-Code-Here {drivers.CXXDriver.checkException} (checkException method)
    
    // DO-DELETE-WHEN-IMPLEMENTING exception.begin()
    /*
     * This method has not been implemented
     */
    ::sidl::NotImplementedException ex = ::sidl::NotImplementedException::_create();
    ex.setNote("This method has not been implemented");
    ex.add(__FILE__, __LINE__, "checkException");
    throw ex;
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(drivers.CXXDriver.checkException)
}

/**
 * Method:  boccaForceUsePortInclude[]
 */
void
drivers::CXXDriver_impl::boccaForceUsePortInclude_impl (
  /* in */::integrator::IntegratorPort dummy0 ) 
{
  // DO-NOT-DELETE splicer.begin(drivers.CXXDriver.boccaForceUsePortInclude)
  // Insert-Code-Here {drivers.CXXDriver.boccaForceUsePortInclude} (boccaForceUsePortInclude method)
    
    // DO-DELETE-WHEN-IMPLEMENTING exception.begin()
    /*
     * This method has not been implemented
     */
    ::sidl::NotImplementedException ex = ::sidl::NotImplementedException::_create();
    ex.setNote("This method has not been implemented");
    ex.add(__FILE__, __LINE__, "boccaForceUsePortInclude");
    throw ex;
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(drivers.CXXDriver.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument Svc will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
drivers::CXXDriver_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(drivers.CXXDriver.setServices)

  // Bocca generated code. bocca.protected.begin(drivers.CXXDriver:setServices) 
     boccaSetServices(services); 
  // Bocca generated code. bocca.protected.end(drivers.CXXDriver:setServices) 
  
  // DO-NOT-DELETE splicer.end(drivers.CXXDriver.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument Svc will never be nil/null.
 * The argument Svc will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to Svc.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
drivers::CXXDriver_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(drivers.CXXDriver.releaseServices)
  // Insert-Code-Here {drivers.CXXDriver.releaseServices} (releaseServices method)

  // Bocca generated code. bocca.protected.begin(drivers.CXXDriver:releaseServices)

   using namespace std;

  // Un-provide gov.cca.ports.GoPort port with port name go 
   try{
      d_services.removeProvidesPort("go");
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "drivers.CXXDriver: Error calling removeProvidesPort for port instance go - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }

  // Release integrator.IntegratorPort port with port name integrate 
   try{
      d_services.releasePort("integrate");
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "drivers.CXXDriver: Error calling releasePort for port instance integrate - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }

   d_services=0;
   return;
  // Bocca generated code. bocca.protected.end(drivers.CXXDriver:releaseServices)
    
  // DO-NOT-DELETE splicer.end(drivers.CXXDriver.releaseServices)
}

/**
 *  
 * Execute some encapsulated functionality on the component. 
 * Return 0 if ok, -1 if internal error but component may be 
 * used further, and -2 if error so severe that component cannot
 * be further used safely.
 */
int32_t
drivers::CXXDriver_impl::go_impl () 

{
  // DO-NOT-DELETE splicer.begin(drivers.CXXDriver.go)
    
    
  // Insert-Code-Here {drivers.CXXDriver.go} (go method)

  double value;
  int count = 100000;
  double lowerBound = 0.0, upperBound = 1.0;

  ::integrator::IntegratorPort integrator;

  // get the port ...
  gov::cca::Port port = d_services.getPort("integrate");
  integrator = babel_cast< ::integrator::IntegratorPort >(port);

  if(integrator._is_nil()) {
    fprintf(stdout, "drivers.CXXDriver not connected\n");
    d_services.releasePort("integrate");
    return -1;    
  }
    // operate on the port
    value = integrator.integrate (lowerBound, upperBound, count);

    fprintf(stdout,"Value = %lf\n", value);
    fflush(stdout);
  
  // release the port.
  d_services.releasePort("integrate");
  return 0;

  // DO-NOT-DELETE splicer.end(drivers.CXXDriver.go)
}


// DO-NOT-DELETE splicer.begin(drivers.CXXDriver._misc)

// Bocca generated code. bocca.protected.begin(drivers.CXXDriver:boccaSetServices)
void
drivers::CXXDriver_impl::boccaSetServices (
  /* in */::gov::cca::Services& services )
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{

   using namespace std;

   gov::cca::TypeMap typeMap;
   gov::cca::Port    port;

   d_services = services;

   try {
      typeMap = d_services.createTypeMap();
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "drivers.CXXDriver: Error creating CCA TypeMap- File:" << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }

   port =  ::babel_cast<gov::cca::Port>(*this);
   if (port._is_nil()) {
      cerr << "drivers.CXXDriver: Error casting component to gov::cca::Port - File : " 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   } 


  // Provide a gov.cca.ports.GoPort port with port name go 
   try{
      d_services.addProvidesPort(port,
                                        "go",
                                        "gov.cca.ports.GoPort",
                                        typeMap);
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "drivers.CXXDriver: Error calling addProvidesPort for gov.cca.ports.GoPort::go - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }    

  // Use a integrator.IntegratorPort port with port name integrate 
   try{
      d_services.registerUsesPort("integrate",
                                         "integrator.IntegratorPort",
                                         typeMap);
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "drivers.CXXDriver: Error calling registerUsesPort for integrator.IntegratorPort::integrate - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }


   gov::cca::ComponentRelease cr = ::babel_cast<gov::cca::ComponentRelease>(*this);
   d_services.registerForRelease(cr);
   return;
}        
// Bocca generated code. bocca.protected.end(drivers.CXXDriver:boccaSetServices)
    
// Insert-Code-Here {drivers.CXXDriver._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(drivers.CXXDriver._misc)

