/*
 * File:          functions_LinearFunction_Impl.c
 * Symbol:        functions.LinearFunction-v0.0
 * Symbol Type:   class
 * Babel Version: 1.0.6
 * Description:   Server-side implementation for functions.LinearFunction
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "functions.LinearFunction" (version 0.0)
 */

#include "functions_LinearFunction_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"

/* DO-NOT-DELETE splicer.begin(functions.LinearFunction._includes) */

/* Bocca generated code. bocca.protected.begin(functions.LinearFunction:_includes) */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void
impl_functions_LinearFunction_boccaSetServices(
  /* in */ functions_LinearFunction self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

/* Bocca generated code. bocca.protected.end(functions.LinearFunction:_includes) */
        
/* Bocca generated code. bocca.protected.begin(functions.LinearFunction:boccaSetServices) */
void impl_functions_LinearFunction_boccaSetServices(
  /* in */ functions_LinearFunction self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex)
{

   struct functions_LinearFunction__data *pd;

   sidl_BaseInterface throwaway_excpt = NULL;

   gov_cca_TypeMap typeMap = NULL;
   gov_cca_Port port = NULL;

   pd = functions_LinearFunction__get_data(self);

   pd->d_services = services;

   gov_cca_Services_addRef(services, &throwaway_excpt);

  /* Create a typemap  */
   typeMap = gov_cca_Services_createTypeMap(pd->d_services, &throwaway_excpt);
   if (SIDL_CATCH(throwaway_excpt, "gov.cca.CCAException")) {
      fprintf(stderr, "Exception:: %s:%d: gov::cca::TypeMap was not created\n",
          __FILE__, __LINE__);
      SIDL_CLEAR(throwaway_excpt);
      exit(1);
   }

  /* Cast myself to gov.cca.Port */
   port = gov_cca_Port__cast(self, &throwaway_excpt);
   if (port == NULL) {
      fprintf(stderr, "Error:: %s:%d: Error casting self to gov::cca::Port \n",
        __FILE__, __LINE__);
      exit(1);
   } 

   /* Provide a function.FunctionPort port with port name function */
   gov_cca_Services_addProvidesPort(pd->d_services,   
                       port,
                       "function",
                       "function.FunctionPort",
                       typeMap,
                       &throwaway_excpt);
   if (SIDL_CATCH(throwaway_excpt, "gov.cca.CCAException")) {
      fprintf(stderr, "Exception:: %s:%d: Could not register function.FunctionPort:function provides port\n",
         __FILE__, __LINE__);
      SIDL_CLEAR(throwaway_excpt);
      exit(1);
   }


   return;
}
// Bocca generated code. bocca.protected.end(functions.LinearFunction:boccaSetServices)
        
/* Put additional includes or other arbitrary code here... */

#include <stdio.h>
#include <stdlib.h>
#include "sidl_Exception.h"

#if (!defined NULL)
#define NULL 0
#endif
/* DO-NOT-DELETE splicer.end(functions.LinearFunction._includes) */

#define SIDL_IOR_MAJOR_VERSION 1
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._load) */
    
    
  /* Insert-Code-Here {functions.LinearFunction._load} (static class initializer method) */
    /* DO-NOT-DELETE splicer.end(functions.LinearFunction._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction__ctor(
  /* in */ functions_LinearFunction self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._ctor) */
    
  /* Bocca generated code. bocca.protected.begin(functions.LinearFunction:_ctor) */
   struct functions_LinearFunction__data *dptr = 
                (struct functions_LinearFunction__data*)malloc(sizeof(struct functions_LinearFunction__data));
   if (dptr) {
      memset(dptr, 0, sizeof(struct functions_LinearFunction__data));
   }
   functions_LinearFunction__set_data(self, dptr);
  /* initialize elements of dptr here */
  /* Bocca generated code. bocca.protected.end(functions.LinearFunction:_ctor) */

  /* Insert the implementation of the constructor method here... */

  /* Allocate memory for the private data of this component */
  struct functions_LinearFunction__data *pdptr = (struct functions_LinearFunction__data*) 
    malloc(sizeof(struct functions_LinearFunction__data));
  if (pdptr) {
    /* Initialize the framework Services handle */
    pdptr->d_services = NULL;
  }
  functions_LinearFunction__set_data(self, pdptr);
  
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction__ctor2(
  /* in */ functions_LinearFunction self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._ctor2) */
    
    
    /* Insert-Code-Here {functions.LinearFunction._ctor2} (special constructor method) */
    /*
     * This method has not been implemented
     */

    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-NOT-DELETE splicer.end(functions.LinearFunction._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction__dtor(
  /* in */ functions_LinearFunction self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._dtor) */
    /*
     * // boilerplate destructor
     * struct functions_LinearFunction__data *dptr = functions_LinearFunction__get_data(self);
     * if (dptr) {
     *   // free contained in dtor before next line
     *   free(dptr);
     *   functions_LinearFunction__set_data(self, NULL);
     * }
     */

  /* Insert the implementation of the destructor method here... */
  
  struct functions_LinearFunction__data *pdptr;
  sidl_BaseInterface throwaway_excpt;

  /* Access private data structure */
  pdptr = functions_LinearFunction__get_data(self);
  if (pdptr) {
    if (pdptr->d_services) {
      gov_cca_Services_deleteRef(pdptr->d_services, &throwaway_excpt);
    }
    pdptr->d_services = NULL;
    free(pdptr); 
    functions_LinearFunction__set_data(self, NULL);
  }
    /* DO-NOT-DELETE splicer.end(functions.LinearFunction._dtor) */
  }
}

/*
 * Method:  checkException[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_checkException"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction_checkException(
  /* in */ functions_LinearFunction self,
  /* in */ sidl_BaseInterface excpt,
  /* in */ const char* msg,
  /* in */ sidl_bool fatal,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
/*  DO-NOT-DELETE splicer.begin(functions.LinearFunction.checkException) */
/*  Insert-Code-Here {functions.LinearFunction.checkException} (checkException method) */

/*  Bocca generated code. bocca.protected.begin(functions.LinearFunction:checkException) */

   if (SIDL_CATCH(excpt, "gov.cca.CCAException")) {
      fprintf(stderr, "functions.LinearFunction: %s \n", msg);
      SIDL_CLEAR(excpt);
      if (fatal)
         exit(1);
   }
   return;
   
/*  Bocca generated code. bocca.protected.end(functions.LinearFunction:checkException) */
    
/*  DO-NOT-DELETE splicer.end(functions.LinearFunction.checkException) */
  }
}

/*
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument Svc will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_setServices"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction_setServices(
  /* in */ functions_LinearFunction self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.setServices) */

  /* Bocca generated code. bocca.protected.begin(functions.LinearFunction:setServices) */
   impl_functions_LinearFunction_boccaSetServices(self, services, _ex);
  /* Bocca generated code. bocca.protected.end(functions.LinearFunction:setServices) */
  
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction.setServices) */
  }
}

/*
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument Svc will never be nil/null.
 * The argument Svc will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to Svc.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_releaseServices"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction_releaseServices(
  /* in */ functions_LinearFunction self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
/*  DO-NOT-DELETE splicer.begin(functions.LinearFunction.releaseServices) */
/*  Insert-Code-Here {functions.LinearFunction.releaseServices} (releaseServices method) */

/*  Bocca generated code. bocca.protected.begin(functions.LinearFunction:releaseServices) */

   struct functions_LinearFunction__data *pd;
   sidl_BaseInterface throwaway_excpt = NULL;
   sidl_BaseInterface dummy_excpt = NULL;
   char errMsg[256];

   pd = functions_LinearFunction__get_data(self);

   /* UN-Provide a function.FunctionPort port with port name function */
   gov_cca_Services_removeProvidesPort(pd->d_services,   
                       "function",
                       &throwaway_excpt);
   snprintf(errMsg, sizeof(errMsg), 
           "Error - %s:%d: Could not remove function.FunctionPort:function provides port",
           __FILE__, __LINE__);
   functions_LinearFunction_checkException(self, &throwaway_excpt, errMsg, TRUE, &dummy_excpt);

   gov_cca_Services_deleteRef(pd->d_services, &throwaway_excpt);
/*  Bocca generated code. bocca.protected.end(functions.LinearFunction:releaseServices) */
    
/*  DO-NOT-DELETE splicer.end(functions.LinearFunction.releaseServices) */
  }
}

/*
 * Method:  init[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_init"

#ifdef __cplusplus
extern "C"
#endif
void
impl_functions_LinearFunction_init(
  /* in */ functions_LinearFunction self,
  /* in array<double> */ struct sidl_double__array* params,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.init) */
    
    
  /* Insert the implementation of the init method here... */
    /* DO-NOT-DELETE splicer.end(functions.LinearFunction.init) */
  }
}

/*
 * Method:  evaluate[]
 */

#undef __FUNC__
#define __FUNC__ "impl_functions_LinearFunction_evaluate"

#ifdef __cplusplus
extern "C"
#endif
double
impl_functions_LinearFunction_evaluate(
  /* in */ functions_LinearFunction self,
  /* in */ double x,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(functions.LinearFunction.evaluate) */
    
    
  /* Insert the implementation of the evaluate method here... */

  return 12.0 * x + 3.2;

    /* DO-NOT-DELETE splicer.end(functions.LinearFunction.evaluate) */
  }
}
/* Babel internal methods, Users should not edit below this line. */
struct function_FunctionPort__object* 
  impl_functions_LinearFunction_fconnect_function_FunctionPort(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return function_FunctionPort__connectI(url, ar, _ex);
}
struct function_FunctionPort__object* 
  impl_functions_LinearFunction_fcast_function_FunctionPort(void* bi, 
  sidl_BaseInterface* _ex) {
  return function_FunctionPort__cast(bi, _ex);
}
struct functions_LinearFunction__object* 
  impl_functions_LinearFunction_fconnect_functions_LinearFunction(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return functions_LinearFunction__connectI(url, ar, _ex);
}
struct functions_LinearFunction__object* 
  impl_functions_LinearFunction_fcast_functions_LinearFunction(void* bi, 
  sidl_BaseInterface* _ex) {
  return functions_LinearFunction__cast(bi, _ex);
}
struct gov_cca_CCAException__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_CCAException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return gov_cca_CCAException__connectI(url, ar, _ex);
}
struct gov_cca_CCAException__object* 
  impl_functions_LinearFunction_fcast_gov_cca_CCAException(void* bi, 
  sidl_BaseInterface* _ex) {
  return gov_cca_CCAException__cast(bi, _ex);
}
struct gov_cca_Component__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Component(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return gov_cca_Component__connectI(url, ar, _ex);
}
struct gov_cca_Component__object* 
  impl_functions_LinearFunction_fcast_gov_cca_Component(void* bi, 
  sidl_BaseInterface* _ex) {
  return gov_cca_Component__cast(bi, _ex);
}
struct gov_cca_ComponentRelease__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_ComponentRelease(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return gov_cca_ComponentRelease__connectI(url, ar, _ex);
}
struct gov_cca_ComponentRelease__object* 
  impl_functions_LinearFunction_fcast_gov_cca_ComponentRelease(void* bi, 
  sidl_BaseInterface* _ex) {
  return gov_cca_ComponentRelease__cast(bi, _ex);
}
struct gov_cca_Port__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Port(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return gov_cca_Port__connectI(url, ar, _ex);
}
struct gov_cca_Port__object* impl_functions_LinearFunction_fcast_gov_cca_Port(
  void* bi, sidl_BaseInterface* _ex) {
  return gov_cca_Port__cast(bi, _ex);
}
struct gov_cca_Services__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Services(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return gov_cca_Services__connectI(url, ar, _ex);
}
struct gov_cca_Services__object* 
  impl_functions_LinearFunction_fcast_gov_cca_Services(void* bi, 
  sidl_BaseInterface* _ex) {
  return gov_cca_Services__cast(bi, _ex);
}
struct sidl_BaseClass__object* 
  impl_functions_LinearFunction_fconnect_sidl_BaseClass(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connectI(url, ar, _ex);
}
struct sidl_BaseClass__object* 
  impl_functions_LinearFunction_fcast_sidl_BaseClass(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_BaseClass__cast(bi, _ex);
}
struct sidl_BaseInterface__object* 
  impl_functions_LinearFunction_fconnect_sidl_BaseInterface(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connectI(url, ar, _ex);
}
struct sidl_BaseInterface__object* 
  impl_functions_LinearFunction_fcast_sidl_BaseInterface(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_BaseInterface__cast(bi, _ex);
}
struct sidl_ClassInfo__object* 
  impl_functions_LinearFunction_fconnect_sidl_ClassInfo(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connectI(url, ar, _ex);
}
struct sidl_ClassInfo__object* 
  impl_functions_LinearFunction_fcast_sidl_ClassInfo(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_ClassInfo__cast(bi, _ex);
}
struct sidl_RuntimeException__object* 
  impl_functions_LinearFunction_fconnect_sidl_RuntimeException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_RuntimeException__connectI(url, ar, _ex);
}
struct sidl_RuntimeException__object* 
  impl_functions_LinearFunction_fcast_sidl_RuntimeException(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_RuntimeException__cast(bi, _ex);
}
