// 
// File:          integrators_Trapezoid_Impl.cxx
// Symbol:        integrators.Trapezoid-v0.0
// Symbol Type:   class
// Babel Version: 1.0.6
// Description:   Server-side implementation for integrators.Trapezoid
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "integrators_Trapezoid_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_function_FunctionPort_hxx
#include "function_FunctionPort.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
   // DO-NOT-DELETE splicer.begin(integrators.Trapezoid._includes)
   // Bocca generated code. bocca.protected.begin(integrators.Trapezoid:_includes)
#include <iostream>
   // Bocca generated code. bocca.protected.end(integrators.Trapezoid:_includes)

// Insert-Code-Here {integrators.Trapezoid._includes} (additional includes or code)
#include "function_FunctionPort.hxx"
   // DO-NOT-DELETE splicer.end(integrators.Trapezoid._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
integrators::Trapezoid_impl::Trapezoid_impl() : StubBase(reinterpret_cast< 
  void*>(::integrators::Trapezoid::_wrapObj(reinterpret_cast< void*>(this))),
  false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid._ctor2)
  // Insert-Code-Here {integrators.Trapezoid._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid._ctor2)
}

// user defined constructor
void integrators::Trapezoid_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid._ctor)
  // Insert-Code-Here {integrators.Trapezoid._ctor} (constructor)
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid._ctor)
}

// user defined destructor
void integrators::Trapezoid_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid._dtor)
  // Insert-Code-Here {integrators.Trapezoid._dtor} (destructor)
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid._dtor)
}

// static class initializer
void integrators::Trapezoid_impl::_load() {
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid._load)
  // Insert-Code-Here {integrators.Trapezoid._load} (class initialization)
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  checkException[]
 */
void
integrators::Trapezoid_impl::checkException_impl (
  /* in */::sidl::BaseInterface excpt,
  /* in */const ::std::string& msg,
  /* in */bool fatal ) 
{
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid.checkException)
  // Insert-Code-Here {integrators.Trapezoid.checkException} (checkException method)
    
    // DO-DELETE-WHEN-IMPLEMENTING exception.begin()
    /*
     * This method has not been implemented
     */
    ::sidl::NotImplementedException ex = ::sidl::NotImplementedException::_create();
    ex.setNote("This method has not been implemented");
    ex.add(__FILE__, __LINE__, "checkException");
    throw ex;
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid.checkException)
}

/**
 * Method:  boccaForceUsePortInclude[]
 */
void
integrators::Trapezoid_impl::boccaForceUsePortInclude_impl (
  /* in */::function::FunctionPort dummy0 ) 
{
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid.boccaForceUsePortInclude)
  // Insert-Code-Here {integrators.Trapezoid.boccaForceUsePortInclude} (boccaForceUsePortInclude method)
    
    // DO-DELETE-WHEN-IMPLEMENTING exception.begin()
    /*
     * This method has not been implemented
     */
    ::sidl::NotImplementedException ex = ::sidl::NotImplementedException::_create();
    ex.setNote("This method has not been implemented");
    ex.add(__FILE__, __LINE__, "boccaForceUsePortInclude");
    throw ex;
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument Svc will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
integrators::Trapezoid_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid.setServices)

  // Bocca generated code. bocca.protected.begin(integrators.Trapezoid:setServices) 
     boccaSetServices(services); 
  // Bocca generated code. bocca.protected.end(integrators.Trapezoid:setServices) 
  
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument Svc will never be nil/null.
 * The argument Svc will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to Svc.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
integrators::Trapezoid_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid.releaseServices)
  // Insert-Code-Here {integrators.Trapezoid.releaseServices} (releaseServices method)

  // Bocca generated code. bocca.protected.begin(integrators.Trapezoid:releaseServices)

   using namespace std;

  // Un-provide integrator.IntegratorPort port with port name integrate 
   try{
      d_services.removeProvidesPort("integrate");
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "integrators.Trapezoid: Error calling removeProvidesPort for port instance integrate - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }

  // Release function.FunctionPort port with port name function 
   try{
      d_services.releasePort("function");
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "integrators.Trapezoid: Error calling releasePort for port instance function - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }

   d_services=0;
   return;
  // Bocca generated code. bocca.protected.end(integrators.Trapezoid:releaseServices)
    
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid.releaseServices)
}

/**
 * Method:  integrate[]
 */
double
integrators::Trapezoid_impl::integrate_impl (
  /* in */double lowBound,
  /* in */double upBound,
  /* in */int32_t count ) 
{
  // DO-NOT-DELETE splicer.begin(integrators.Trapezoid.integrate)
    
    
  // Insert-Code-Here {integrators.Trapezoid.integrate} (integrate method)
   function::FunctionPort  myFunPort;
   gov::cca::Port          generalPort;
   
   generalPort = d_services.getPort("function");
   if (generalPort._is_nil()){
       fprintf(stderr, "Error:: %s:%d: generalPort is nil - \
             maybe I'm not connected to any port!!\n",
             __FILE__, __LINE__);
       exit(1);  
    }
     
    myFunPort = ::babel_cast< function::FunctionPort >(generalPort);
    if (myFunPort._is_nil()){
       fprintf(stderr, "Error:: %s:%d: myFunPort is nil - \
             maybe I'm connected to the wrong \"Provides\" port!!\n",
             __FILE__, __LINE__);
       exit(1);  
    }
    
    double h = (upBound - lowBound) / count;
    double retval = 0.0;
    double sum = 0.0;
    for (int i = 1; i <= count; i++){
       sum += myFunPort.evaluate(lowBound + (i - 1) * h) +
              myFunPort.evaluate(lowBound + i * h);
    }
    retval = h/2.0 * sum;
    d_services.releasePort("function");
    return retval;
      
  // DO-NOT-DELETE splicer.end(integrators.Trapezoid.integrate)
}


// DO-NOT-DELETE splicer.begin(integrators.Trapezoid._misc)

// Bocca generated code. bocca.protected.begin(integrators.Trapezoid:boccaSetServices)
void
integrators::Trapezoid_impl::boccaSetServices (
  /* in */::gov::cca::Services& services )
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{

   using namespace std;

   gov::cca::TypeMap typeMap;
   gov::cca::Port    port;

   d_services = services;

   try {
      typeMap = d_services.createTypeMap();
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "integrators.Trapezoid: Error creating CCA TypeMap- File:" << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }

   port =  ::babel_cast<gov::cca::Port>(*this);
   if (port._is_nil()) {
      cerr << "integrators.Trapezoid: Error casting component to gov::cca::Port - File : " 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   } 


  // Provide a integrator.IntegratorPort port with port name integrate 
   try{
      d_services.addProvidesPort(port,
                                        "integrate",
                                        "integrator.IntegratorPort",
                                        typeMap);
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "integrators.Trapezoid: Error calling addProvidesPort for integrator.IntegratorPort::integrate - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }    

  // Use a function.FunctionPort port with port name function 
   try{
      d_services.registerUsesPort("function",
                                         "function.FunctionPort",
                                         typeMap);
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "integrators.Trapezoid: Error calling registerUsesPort for function.FunctionPort::function - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }


   gov::cca::ComponentRelease cr = ::babel_cast<gov::cca::ComponentRelease>(*this);
   d_services.registerForRelease(cr);
   return;
}        
// Bocca generated code. bocca.protected.end(integrators.Trapezoid:boccaSetServices)
    
// Insert-Code-Here {integrators.Trapezoid._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(integrators.Trapezoid._misc)

