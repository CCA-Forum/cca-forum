#!/bin/sh

BOCCA_HOME=/home/baallan/cca/build/bocca/trunk/install
CCAFE_CONFIG=/home/baallan/cca/install/dccafe-b104/bin/ccafe-config

BOCCA="$BOCCA_HOME/bin/bocca"

PROJECT_DIR=`$BOCCA display project|sed -n -e "s/^Project .*'projectDir': '\([^']*\)'.*/\1/p"`


KPATH="`$CCAFE_CONFIG --var CCAFE_bindir`"

$KPATH/gui-backend.sh --port 3467 --ccafe-rc $PROJECT_DIR/components/tests/test_gui_rc&

$KPATH/gui.sh --port 3467


