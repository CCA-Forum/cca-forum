#!/bin/sh

if test "x$QUIET" = "x" ; then
   echo $@;
fi
