#!/bin/sh

# bocca wrapper on gui-backend to supply the default rc file.
# if you specify another rc file, it will override the default.

BOCCA_HOME=/home/baallan/cca/build/bocca/trunk/install
CCAFE_CONFIG=/home/baallan/cca/install/dccafe-b104/bin/ccafe-config

BOCCA="$BOCCA_HOME/bin/bocca"

PROJECT_DIR=`$BOCCA display project|sed -n -e "s/^Project .*'projectDir': '\([^']*\)'.*/\1/p"`

KPATH="`$CCAFE_CONFIG --var CCAFE_bindir`"

$KPATH/gui-backend.sh  --ccafe-rc $PROJECT_DIR/components/tests/test_gui_rc $* &



