#!/bin/sh

function usage () {
	echo -e "\nUsage:\n\tsh $0 <rcfile> <lib_dir> <ccafe-config>\n\n"\
		"This script adds a small Ccaffeine resource control (rc) script fragment\n"\
		"that set the dynamic  library search path to <lib_dir>\n"\
		" Arguments (all are required): \n"\
		"            rcfile is the full path name of the target Ccaffeine RC file\n"\
		"	     lib_dir is the full path location of the dynamic libraries\n"\
		"            ccafe-config is the full path to the ccafe-config executable \n" > /dev/stderr
}

if [ $# -lt 2 ];  then
	usage
	exit 1;
fi

rcfilearg=$1
rcfiledir=`dirname $1`
lib=$2
ccafeconfig=$3
#pythondir=$5
#pythonver=$6

if [ ! -f "$rcfilearg" ] ; then 
    echo -e "*** Error: Could not run tests, didn't find $rcfilearg file."; 
    exit 0;
fi 
if [ "x`echo $rcfilearg | grep \.incl`" != "x" ]; then 
    rcfile="`echo $rcfilearg | sed -e 's|\.incl||'`";
    sed -e "/@CCA_COMPONENT_PATH@/ s|@CCA_COMPONENT_PATH@|${lib}|" $rcfilearg > $rcfile;
else
    rcfile=$rcfilearg
fi

# Get rid of quit
grep -v "^quit" $rcfile > $rcfile.tmp; mv $rcfile.tmp $rcfile

ccaspecconfig=`$ccafeconfig --var CCAFE_CCA_SPEC_BABEL_CONFIG`
guiprefix=`$ccafeconfig --var CCAFE_bindir`
CCASPEC_libdir=`$ccaspecconfig --var CCASPEC_libdir `
CCASPEC_pkglibdir=`$ccaspecconfig --var CCASPEC_pkglibdir `
CCASPEC_BABEL_libdir=`$ccaspecconfig --var CCASPEC_BABEL_libdir`
CCASPEC_BABEL_LANGUAGES=`$ccaspecconfig --var CCASPEC_BABEL_LANGUAGES`

# Env. variable settings
LD_RUN_PATH=$CCASPEC_libdir
if [ "x$LD_LIBRARY_PATH" == "x" ] ; then
  LD_LIBRARY_PATH=$LD_RUN_PATH:
else
  LD_LIBRARY_PATH=$CCASPEC_BABEL_libdir:$CCASPEC_libdir:$LD_LIBRARY_PATH
fi
export LD_RUN_PATH
export LD_LIBRARY_PATH

# Handle Macs
SYSTEM=`uname`
if [ "$SYSTEM" == "Darwin" ] ; then 
   DYLD_LIBRARY_PATH=$LD_LIBRARY_PATH
   export DYLD_LIBRARY_PATH
fi

if [ -n "`echo $CCASPEC_BABEL_LANGUAGES | grep python`" ] ; then
   PYTHON_VER="python`$ccaspecconfig --var CCASPEC_BABEL_PYTHON_VERSION`"
   PYTHONPATH=$rcfiledir/../../ports/lib/$PYTHON_VER/site-packages:$rcfiledir/../lib/$PYTHON_VER/site-packages:$CCASPEC_pkglibdir/$PYTHON_VER/site-packages:$PYTHONPATH

   if [ -d $CCASPEC_BABEL_libdir/../lib64 ] ; then
	  PYTHONPATH=$CCASPEC_BABEL_libdir/../lib64/$PYTHON_VER/site-packages:$PYTHONPATH ;
   else
	  PYTHONPATH=$CCASPEC_BABEL_libdir/$PYTHON_VER/site-packages:$PYTHONPATH: ;
   fi
   #echo PYTHONPATH=$PYTHONPATH
   export  PYTHONPATH
fi

if [ -n "`echo $CCASPEC_BABEL_LANGUAGES | grep java`" ] ; then 
   CCASPEC_BABEL_VERSION=`$ccaspecconfig --var CCASPEC_BABEL_VERSION`
   CLASSPATH=$CCASPEC_BABEL_libdir/sidl-$CCASPEC_BABEL_VERSION.jar:$CCASPEC_BABEL_libdir/sidlstub_$CCASPEC_BABEL_VERSION.jar:$CCASPEC_libdir/cca-spec.jar:$rcfiledir/../../ports/lib/java:$rcfiledir/../lib/java
   #echo CLASSPATH=$CLASSPATH
   export CLASSPATH
fi

# Need to set PYTHONPATH so python components can load (yucky temporary hardcoding)
# BEWARE: this is not operation yet since we are missing info from babel-config
# for example, whether lib or lib64 is in the path
#if [ -n $pythondir -a -n $pythonver ]; then 
    #export PYTHONPATH=$pythondir/lib/$pythonver/site-packages:$rcfiledir/../../ports/lib/$pythonver/site-packages:$rcfiledir/../lib/$pythonver/site-packages:$PYTHONPATH
    #echo -e "\n Setting PYTHONPATH to $PYTHONPATH\n";
#fi

#$ccafe --ccafe-rc $rcfile > $rcfile.log 2>&1 ; 
echo -e "Test script: $rcfile"; 
($guiprefix/gui-backend.sh --port 8080 --ccafe-rc $rcfile > $rcfile.log 2>&1) &
sleep 2; 
$guiprefix/gui.sh --port 8080
