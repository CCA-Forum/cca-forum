#!/bin/sh

TIMEOUT=30
echo -n Do you want to use fortran with this build (requires knowing the vendor, and where it is installed) [Ny]:
if read -t $TIMEOUT fortran ; then if $fortran = "y";then echo Fortran requested;fi
if [ $fortran = "y" ]
then
    echo "What is your Fortran vendor? Possibilities include:
       Absoft (Absoft)
       Alpha (Hp Compaq Fortran)
       Cray  (Cray Fortran)
       IBMXL (IBM XL Fortran)
       Intel (Intel v8)
       Intel (Intel v7)
       Lahey (Lahey)
       NAG   (NAG)
       MIPSpro (SGI MIPS Pro)
       SUNWspro (SUN Solaris)
What is your Fortran vendor? :"
if ! read -t $TIMEOUT fortran_arch ;then echo timout, exiting.; exit -1
echo -n What is the absolute path to your fortran compiler (i.e. executable that compiles Fortran source)? :
if ! read -t $TIMEOUT fortran_compiler
fi


