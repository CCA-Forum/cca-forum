from writers.sourceWriter import SourceWriter

def getWriterParameters():
     return (F77Writer.language, F77Writer.babelVersions)
 
class F77Writer(SourceWriter):
    language = 'f77'
    babelVersions = ['1.0.X', '1.1.X']
    commentLineStart = "C    "

    def __init__(self):
        pass
    
    def getConstructorCode(self, componentSymbol):
        cmpt_ubar = componentSymbol.replace('.', '_')
        buf = """
C       DO-NOT-DELETE splicer.begin(@CMPT_TYPE@._ctor)
C       Insert-Code-Here {@CMPT_TYPE@:_ctor} (_ctor method)

C       Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:ctor)

C
C       Will use a SIDL opaque array to store private data. Each entry
C       will coresspond to a one of the following
C       1- A SIDL reference to an object,
C       2- An array of SIDL objects, or
C       3- An array of basic SIDL array types. 
C       
C       The mapping between entries in those arrays and individual state 
C       fields needs to be maintaned by the developers (similar to the way 
C       common blocks are maintained across subroutines).
C
        integer*8  stateArray, intArray, tmp, texcpt
        integer*4  itmp
        integer*4  stateSize  
        
        tmp = 0
        itmp = 0
        stateSize = 1
        
        call sidl_opaque__array_create1d_f(stateSize, stateArray)
        if (stateArray .eq. 0) then
C          a real implementation would not leak memory like this one
           write(*,*) '@CMPT_TYPE@ 
     &     FATAL ERROR: creating state array.'
           stop
        endif
        call @CMPT_TYPE_UBAR@__set_data_f(self, stateArray)
        
C       Bocca generated code. bocca.protected.end(@CMPT_TYPE@:ctor)

C       DO-NOT-DELETE splicer.end(@CMPT_TYPE@._ctor)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@CMPT_TYPE_UBAR@', cmpt_ubar)
        return buf
            
    def getSetServicesCode(self, componentSymbol):
        cmpt_ubar = componentSymbol.replace('.', '_')
        methodName = cmpt_ubar + '_boccaSetServices_f'
        buf = """ 
C       DO-NOT-DELETE splicer.begin(@CMPT_TYPE@.setServices)

C       Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:setServices)
        call @METHOD_NAME@(
     &           self, services, exception)  
C       Bocca generated code. bocca.protected.end(@CMPT_TYPE@:setServices)

C       DO-NOT-DELETE splicer.end(@CMPT_TYPE@.setServices)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@METHOD_NAME@', methodName)
        return buf
   
    def getAuxiliarySetServicesMethod(self, componentSymbol, provideDict={}, useDict={}):
        cmpt_ubar = componentSymbol.replace('.', '_')
        methodName = cmpt_ubar + '_boccaSetServices_f'
        buf = """
C       DO-NOT-DELETE splicer.begin(_miscellaneous_code_end)
C       Insert extra code here...

C       Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:boccaSetServices)
        subroutine @METHOD_NAME@(
     &                self, 
     &                services, 
     &                exception)
        implicit none
C        in @CMPT_TYPE@ self
        integer*8 self
C        in gov.cca.Services services
        integer*8 services
C        out sidl.BaseInterface exception
        integer*8 exception

        integer *8  stateArray
        integer *8  """+self.servicesVariable+"""
        integer *8  compRelease
"""
# Add ports declarations (if needed)
        if (len(provideDict) + len(useDict) > 0):
            buf += """
        integer *8 typeMap
        integer *8 port
"""
# Component Registration code            
        buf +="""
        call @CMPT_TYPE_UBAR@__get_data_f(self, 
     &                                    stateArray)
        if (stateArray .eq. 0) then
           write(*,*) '@CMPT_TYPE@: 
     &  ERROR: Null stateArray in getServices'
           stop
        end if
        """+self.servicesVariable+""" = services
        call sidl_opaque__array_set1_f(stateArray, 
     &                                 0, """+self.servicesVariable+""")
        call gov_cca_Services_addRef_f("""+self.servicesVariable+""", exception)
"""
# Port and TypeMap declaration
        if (len(provideDict) + len(useDict) > 0):
            buf += """
        call gov_cca_Services_createTypeMap_f(
     &              """+self.servicesVariable+""", 
     &              typeMap,
     &              exception)
        if (exception .ne. 0) then 
           print *, '@CMPT_TYPE@: 
     &  Error creating type map'
           return
        endif
"""
            if (len(provideDict) > 0):
                buf +="""
        call @CMPT_TYPE_UBAR@__cast2_f(self,
     &                  'gov.cca.Port', 
     &                  port,
     &                  exception)
        if (exception .ne. 0) then
           print *, '@CMPT_TYPE@: 
     &  Error casting self to gov.cca.Port'
           call gov_cca_TypeMap_deleteRef_f(
     &            typeMap, 
     &            exception) 
           return
        end if
        """
# Provide port(s) code
            for pName in provideDict.keys():
                portBuf = """
C       Add @PORT_TYPE@:@PORT_INSTANCE@ provides port
        call gov_cca_Services_addProvidesPort_f(
     &       """+self.servicesVariable+""", 
     &       port, 
     &       '@PORT_INSTANCE@', 
     &       '@PORT_TYPE@', 
     &       typeMap, 
     &       exception)
        if (exception .ne. 0) then
           print *, '@CMPT_TYPE@: 
     &  Error in call to addProvidesPort()'
           call gov_cca_TypeMap_deleteRef_f(
     &            typeMap, 
     &            exception)
           return 
        end if
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                              replace('@PORT_TYPE@', provideDict[pName])
                buf += portBuf
            
# Use port(s) code
            for pName in useDict.keys():
                portBuf = """
C       Register @PORT_TYPE@:@PORT_INSTANCE@ uses port
        call gov_cca_Services_registerUsesPort_f(
     &       """+self.servicesVariable+""",
     &       '@PORT_INSTANCE@', 
     &       '@PORT_TYPE@', 
     &       typeMap, 
     &       exception)
        if (exception .ne. 0) then
           print *, '@CMPT_TYPE@: 
     &         Error in call to registerUsesPort()'
           call gov_cca_TypeMap_deleteRef_f(
     &            typeMap, 
     &            exception)
           return
        end if
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                              replace('@PORT_TYPE@', useDict[pName])
                buf += portBuf
            buf += """
        call gov_cca_TypeMap_deleteRef_f(
     &         typeMap, 
     &         exception)
"""   
# Finish up, and replace vars

        buf +="""
        call @CMPT_TYPE_UBAR@__cast2_f(self,
     &                  'gov.cca.ComponentRelease', 
     &                  compRelease,
     &                  exception)
        if (exception .ne. 0) then
           print *, '@CMPT_TYPE@: 
     &  Error casting self to gov.cca.ComponentRelease'
           stop
        end if
        call gov_cca_Services_registerForRelease_f("""+self.servicesVariable+""",
     &      compRelease,
     &      exception)
        if (exception .ne. 0) then
           print *, '@CMPT_TYPE@: 
     &  Error calling registerForRelease()'
        end if
        return
        end
C       Bocca generated code. bocca.protected.end(@CMPT_TYPE@:boccaSetServices)

C       DO-NOT-DELETE splicer.end(_miscellaneous_code_end)
"""
        buf = buf.replace('@CMPT_TYPE_UBAR@', cmpt_ubar).\
                  replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@METHOD_NAME@', methodName)
        return buf

#---------------------------------------------------------------------------------
    def getReleaseMethod(self, componentSymbol, provideDict={}, useDict={}):
        cmpt_ubar = componentSymbol.replace('.', '_')
        buf = """
C       DO-NOT-DELETE splicer.begin(@CMPT_TYPE@.releaseServices)
C       Insert-Code-Here {@CMPT_TYPE@.releaseServices} (releaseServices method)

C       Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:releaseServices)

        integer *8  stateArray
        integer *8  """+self.servicesVariable+"""
"""
# Access private data
        buf +="""
        call @CMPT_TYPE_UBAR@__get_data_f(self, 
     &                                    stateArray)
        if (stateArray .eq. 0) then
           write(*,*) '@CMPT_TYPE@: 
     &  ERROR: Null stateArray in releaseServices()'
           stop
        end if
        call sidl_opaque__array_get1_f(stateArray, 
     &                                 0, """+self.servicesVariable+""")
"""
# Unprovide provides port(s) code
        for pName in provideDict.keys():
            portBuf = """
C       Remove @PORT_TYPE@:@PORT_INSTANCE@ provides port
        call gov_cca_Services_removeProvidesPort_f(
     &       """+self.servicesVariable+""", 
     &       '@PORT_INSTANCE@', 
     &       exception)
        if (exception .ne. 0) then
           print *, '@CMPT_TYPE@: 
     &  Error in call to removeProvidesPort()'
           stop 
        end if
"""
            portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                              replace('@PORT_TYPE@', provideDict[pName])
            buf += portBuf
            
# Unregister use port(s) code
            for pName in useDict.keys():
                portBuf = """
C       UnRegister @PORT_TYPE@:@PORT_INSTANCE@ uses port
        call gov_cca_Services_unregisterUsesPort_f(
     &       """+self.servicesVariable+""",
     &       '@PORT_INSTANCE@',
     &       exception)
        if (exception .ne. 0) then
           print *, '@CMPT_TYPE@: 
     &         Error in call to unregisterUsesPort()'
           stop
        end if
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                              replace('@PORT_TYPE@', useDict[pName])
                buf += portBuf
                
# Finish up, and substitute values
        buf += """
        call gov_cca_Services_deleteRef_f("""+self.servicesVariable+""", exception)
        return
C       Bocca generated code. bocca.protected.end(@CMPT_TYPE@:releaseServices)
    
C       DO-NOT-DELETE splicer.end(@CMPT_TYPE@.releaseServices)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@CMPT_TYPE_UBAR@', cmpt_ubar)
        return buf
    

