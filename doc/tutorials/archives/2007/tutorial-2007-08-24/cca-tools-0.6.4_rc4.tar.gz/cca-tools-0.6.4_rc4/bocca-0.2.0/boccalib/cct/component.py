from cct._debug import DEBUGSTREAM, WARN
from cct._util import fileManager, mySplicer, lang_to_fileext, lang_to_headerext, Globals
from graph.boccagraph import BEdge, SymbolError
from cct._err import err, warn
#from cct._validate import language as validateLang
from cct.port import Port
from cct.sidlclass import Sidlclass 
import os
from writers.boccaWriterFactory import BoccaWriterFactory
from splicers import Source, Operations
from cct._component_callbacks import *
import sys

class Component(Sidlclass): 
    """Add new component to current project.
   
    """
    
    def __init__(self, action = '__init__', args = None, project = None, modulePath = None,
                 symbol=None, version='0.0', graph=None):
        '''bocca <verb> component [options] SIDL_SYMBOL
        
        <verb> is one of create, change, remove, rename, display. For documentation on
        specific verbs, use 'bocca help <verb> component'
        '''

        self.implImports = {}
        self.graph = graph
        self.displayAll = False        # Used in display
        self.newProvidesPorts = {}     # Used in create and change
        self.newProvidesLocations = {} # used in create and change
        self.newUsesPorts = {}         # Used in create and change
        self.newUsesLocations = {}     # Used in create and change
        self.new_extends = {}          # Used in create and change
        self.new_implements = {}       # Used in create and change
        
        if (symbol == 'temp'): 
            Sidlclass.__init__(self, action = action, 
                               args = args, modulePath = modulePath, 
                               project = project, kind = 'component', 
                               symbol = symbol, version = version, graph = graph)
            return
        self._b_providesPorts = {}     # Port name / port type mapping 
        self._b_providesLocations = {} # SIDL files corresponding to provides ports types
        self._b_usesPorts = {}         # Port name / port type mapping
        self._b_usesLocations = {}     # SIDL files corresponding to provides ports types
        self.allPortsTypes=[]
        Sidlclass.__init__(self, action = action, 
                         args = args, modulePath = modulePath, 
                         project = project, kind = 'component', 
                         symbol = symbol, version = version, graph=graph)
        pass
        
        
# ------------------------------------------------
    def defineArgs(self, action):
        '''Defines command line options and defaults for this command. This is 
           invoked in the constructor of the parent class Subcommand.
        '''
        if (action == 'create'):
            self.defineArgsCreate()
        elif action == 'rename':
            pass
        elif action == 'display':
            pass
        elif action == 'change':
            self.defineArgsChange()
        elif action == 'edit':
            Sidlclass.defineArgs(self, action)
        else:
            err('Component verb "' + action + '" NOT implemented yet.', 3)
        return
        
        
# ------------------------------------------------
    def defineCommonArgsCreateAndChange1(self):
        '''Defines options common to the create and change operations.'''
        self.parser.add_option("-p", "--provides", dest="providesPort", action="append",
                          help="ports PROVIDED by the component. A port is specified as "
                          + "PORT_TYPE:PORT_NAME, where PORT_TYPE is the fully qualified SIDL type of the provided port, "
                          + "and PORT_NAME is the name given to the provided port instance in the component code. "
                          + "Mutiple ports can be specified using multiple --provides options.")

        self.parser.add_option("-u", "--uses", dest="usesPort", action="append",
                          help="ports USED by the component. A port is specified as "                     
                          + "PORT_TYPE:PORT_NAME, where PORT_TYPE is the fully qualified SIDL type of the used port, "
                          + "and PORT_NAME is the name given to the used port instance in the component code. "
                          + "Mutiple ports can be specified using multiple --uses options.")
        
        self.parser.add_option("-g", "--go", action="callback", type="string", callback=go_option_callback,
                          help="port type gov.cca.ports.GoPort is provided by the component. "
                          + "PORT_NAME is optionally specified; if omitted, GO is the name.  PORT_TYPE is omitted. "
                          + "Multiple requests for a GoPort will be ignored, as this requires handling port delegation "
                          + "that bocca does not yet understand.") #FIXME that last bit of info is too cryptic for brief usage info
        

    def defineCommonArgsCreateAndChange2(self):
# Override help for -x option        
        self.parser.get_option('-x').help='path to external XML repositories containing ' \
        + 'specification of the ports (and/or interfaces) referenced  by the new component (or of ' \
        + 'symbols refrenced by those ports). Multiple repositories can be used (separated by commas). ' \
        + 'Alternatively, multiple instances of the -x option can be used to specify multiple repositories ' \
        + 'paths.'

# Override help for -s option 
        self.parser.get_option('-s').help='path to external SIDL files containing ' \
        + 'specification of the ports, interfaces and/or classes refrenced by the new component ' \
        + '(or of symbols refrenced by them). Multiple files can be used (separated by commas). ' \
        + 'Alternatively, multiple instances of the -I option can be used to specify multiple ' \
        + 'SIDL files.'

# Override help for -I option
        self.parser.get_option('-I').help='path to external ports, interfaces, ' \
        + 'and/or classes header files. Multiple paths can be used (separated by commas). ' \
        + 'Alternatively, multiple instances of the -I option can be used to specify multiple ' \
        + 'external directories.'

        self.parser.set_defaults(providesPorts=None,
                                 usesPorts=None,
                                 GoPortStatus=0)
        
    def defineArgsCreate(self):
        '''Defines command line options and defaults for the create action. 
        '''
        self.defineCommonArgsCreateAndChange1()
        Sidlclass.defineArgsCreate(self)
        self.defineCommonArgsCreateAndChange2()
        
        return
    
    def defineArgsChange(self):
        '''Defines command line options and defaults for the change action.
        '''
        # Support all the creation options:
        self.defineCommonArgsCreateAndChange1()
        Sidlclass.defineArgsChange(self)
        self.defineCommonArgsCreateAndChange2()
        # Additional arguments specific to change
        
        # remove a port from this component
        self.parser.add_option("-d", "--delete", dest="deletePortName", action="append",
                          help="remove ports used or provided by the component given the port name (not SIDL symbol)."
                          + "Mutiple ports can be specified using multiple --delete options.")
        return
        
    
# ------------------------------------------------
    def portArgsToDict(self, arg):
        """ Return dictionary of port arguments, where 
            Dictionary keys = Port Names
            Dictionry entries = Port Types
        """
        # Make sure we have a unified list of portType:portName pairs, possible
        # derived from multiple sub-lists on the command line
        # TODO: Check whether this way of specifying oprt arguments is too flexible.
        argList = ','.join(arg).split(',')
        d = {}
        for p in argList:
            l = p.split(':')
            if (len(l)!= 2):
                err("Invalid port specification : " + p +"\nPort specification of the form portType:portnAME", 2)
            if l[1] in d.keys():
                err("Duplicate specification of port name \"", p[1], "\"", 2)
            print >> DEBUGSTREAM, "port name = ", l[1]
            print >> DEBUGSTREAM, "port type = ", l[0]
            d[l[1]] = l[0]
        return d    
            
# ------------------------------------------------
    def processArgs(self, action):
        """ Dispatch argument processing based in required action
        """
        print >> DEBUGSTREAM, "Component called with options ", \
                              str(self.options) , " leaving args " , str(self.args)
        if (action == 'create'):
            self.processCreateArgs()
        elif (action == 'change'):
            self.processChangeArgs()
        elif (action == 'display'):
            Sidlclass.processDisplayArgs(self)
        elif (action == 'rename'):
            self.processRenameArgs()
        elif (action == 'edit'):
            Sidlclass.processArgs(self, action)
        else:
            err("Action "+ action + " NOT implemented yet", 3)
        return

# ------------------------------------------------
    def processCommonCreateAndChangeArgs(self):
        options, args = self.options, self.args

        if options.usesPort:
            self.newUsesPorts, self.newUsesLocations = self._processParentSymbolOptions(options.usesPort, '--uses/-u')
                
        if options.providesPort:
            self.newProvidesPorts, self.newProvidesLocations = self._processParentSymbolOptions(options.providesPort, '--provides/-p')
            
        print >>DEBUGSTREAM, "\nComponent: newProvidesPorts = ", self.newProvidesPorts, self.newProvidesLocations, \
                            "\nComponent: newUsesPorts = ", self.newUsesPorts, self.newUsesLocations 

        for i in self.newUsesPorts.keys() + self.newProvidesPorts.keys():
            if i in self._b_usesPorts.keys() + self._b_providesPorts.keys():
                self.usage(4,'This component already uses or provides a port of this name: ' + i 
                           + ' (port names must be unique within a component),')
        
        self._b_providesPorts.update(self.newProvidesPorts)
        self._b_providesLocations.update(self.newProvidesLocations)
        self._b_usesPorts.update(self.newUsesPorts)
        self._b_usesLocations.update(self.newUsesLocations)
                            
        Sidlclass.processCommonCreateAndChangeArgs(self)
        
        return
        
    def processCreateArgs(self):
        """ Process command line arguments passed to the "component create" command
        """
        Sidlclass.processCreateArgs(self)
        return
       
    def processChangeArgs(self):
        """Process command line arguments passed to the "component change" command
        """
        Sidlclass.processChangeArgs(self)

        return
    
    def processRenameArgs(self):
        """ Process command line arguments passed to the "component rename" command
        """
        Sidlclass.processRenameArgs(self)
        return    
# ------------------------------------------------

    def create(self):
        """create component [options] SIDL_SYMBOL
        """
        Sidlclass.create(self)
        return 0
    

    def change(self):
        """change component SIDL_SYMBOL options
        """
        # delete uses or provides port
        if self.options.deletePortName:
            allmyports = self._b_providesPorts.keys() + self._b_usesPorts.keys()
            for p in self.options.deletePortName:
                if p not in allmyports:
                    err('There is not port named ' + p + ' in this component.')
        
            for p in self.options.deletePortName:
                if p in self._b_usesPorts.keys():
                    #self._removeSymbolInFiles(p)   # TODO
                    if self._b_usesPorts.values().count(p) <= 1:
                        del self._b_usesLocations[self._b_usesLocations[p]]
                    del self._b_providesPorts[p]                   
                elif p in self._b_providesPorts.keys():
                    #self._removeSymbolInFiles(p)    # TODO
                    if self._b_providesPorts.values().count(p) <= 1:                    
                        del self._b_providesLocations[self._b_providesPorts[p]]
                    del self._b_providesPorts[p]
                           
            self.project.getBuilder().changed([self])
            self.project.getBuilder().update()
            self.saveProjectState(self.graph)
            
        # Let class handle everything it can
        Sidlclass.change(self)
        return 0
    
    def display(self):
        """display component SIDL_SYMBOL
        """
        return Sidlclass.display(self) 
    
# ------------------------------------------------
    def rename(self):
        """rename component OLD_SIDL_SYMBOL NEW_SIDL_SYMBOL
        """
        #return self.renameTarget._internalRename()
        Sidlclass.rename(self)
    
    def remove(self):
        """remove component SIDL_SYMBOL
        """
        return Sidlclass.remove(self)

    def edit(self):
        '''edit component SIDL_SYMBOL options
        '''
        return Sidlclass.edit(self)
    
    def prettystr(self):
        s =  self.kind + ' ' + self.symbol + ' ' + self.version
        
        if len(self._b_providesPorts) > 0:
            s+=  '\n\tprovides ports:\n'
            for i in self._b_providesPorts.keys(): s +=  '\t  ' + self._b_providesPorts[i] + ', port name: ' + i + ' ' + '\n'
        
        if len(self._b_usesPorts) > 0:
            s+=  '\n\tuses ports:\n'
            for i in self._b_usesPorts.keys(): s +=  '\t  ' + self._b_usesPorts[i]  + ', port name: ' + i + ' ' + '\n'
                        
        if len(self._b_implements) > 0:
            s+=  '\n\timplements interfaces:\n'
            for i in self._b_implements.keys(): s +=  '\t  ' + i + ' ' + '\n'

        if len(self._b_extends) > 0:
            s += '\n\textends class: ', self._b_extends.keys()[0] + '\n'
            
        s +=  '\n\timplementation is in: ' +  str(self._b_implSource) + '\n'
        return s

# ------------------------------------------------

    def updateGraph(self):

        # Component-specific code:
        #  Check existence of interface nodes in project graph and add edges
        self.newProvidesLocations, vertices = self._validateProjectSymbols(self.graph, self.newProvidesLocations, portnames=self.newProvidesPorts, kinds=['interface','port']) # should it be just 'port'?
        for ifaceNode in vertices:
            edge = BEdge(ifaceNode, self, graph=self.graph, action = 'provides')  # Connect with implemented interface
            # Add the new interfaces 
            self._b_providesPorts.update(self.newProvidesPorts)
            self._b_providesLocations.update(self.newProvidesLocations)
            
        print >>DEBUGSTREAM,'Provides ports: ', self._b_providesPorts, self._b_providesLocations
        
        # Check for existence of class/component nodes in project graph and add edges
        self.newUsesLocations, vertices = self._validateProjectSymbols(self.graph, self.newUsesLocations, portnames=self.newUsesPorts, kinds = ['interface', 'port']) # should it be just 'port'?
        for ifaceNode in vertices:
            edge = BEdge(ifaceNode, self, graph=self.graph, action = 'uses')  # Connect with implemented interface
            # Add the new interfaces 
            self._b_usesPorts.update(self.newUsesPorts)
            self._b_usesLocations.update(self.newUsesLocations)
        
        Sidlclass.updateGraph(self)
        pass

        
    def renameInternalSymbol(self, oldSymbol, newSymbol):
        Sidlclass.renameInternalSymbol(self, oldSymbol, newSymbol)
        
        for k in self._b_providesPorts.keys():
            if oldSymbol == self._b_providesPorts[k]:
                self._replaceSymbolInFiles(oldSymbol, newSymbol)
                self._b_providesPorts[k] = newSymbol
                self._b_providesLocations[newSymbol] = self._b_providesLocations[oldSymbol]
                del self._b_providesLocations[oldSymbol]
                
        for k in self._b_usesPorts.keys():
            if oldSymbol == self._b_usesPorts[k]:
                self._replaceSymbolInFiles(oldSymbol, newSymbol)
                self._b_usesPorts[k] = newSymbol
                self._b_usesLocations[newSymbol] = self._b_usesLocations[oldSymbol]
                del self._b_usesLocations[oldSymbol]
                
# FIXME: We're doing this to check that the sed approach actually works. 
        self.genClassImpl()
        return 0
    
    def removeInternalSymbol(self, oldSymbol):
        ''' Removes any internal references to symbol.'''
        Sidlclass.removeInternalSymbol(self,oldSymbol)
        
        for k in self._b_providesPorts.keys():
            if oldSymbol == self._b_providesPorts[k]:
                self._removeSymbolInFiles(oldSymbol)
                del self._b_providesLocations[oldSymbol]
                del self._b_providesPorts[k]

                
        for k in self._b_usesPorts.keys():
            if oldSymbol == self._b_usesPorts[k]:
                self._removeSymbolInFiles(oldSymbol)
                del self._b_usesLocations[oldSymbol]
                del self._b_usesPorts[k]
               
        self.genClassImpl()
        return 0
    
# ------------------------------------------------
    def genClassSidlFile2(self):        
        indent = '   '
        level = 0
        buf = ''
        pkglist = self._b_packageName.split('.')
        fullpkg = ''
        print >> DEBUGSTREAM, pkglist
        while(len(pkglist) > 0):
            pkg = pkglist.pop(0)
            fullpkg = (fullpkg + '.' + pkg).lstrip('.')
            nodeList = self.graph.findSymbol(fullpkg, kind='package')
            if (len(nodeList) == 0):
                err('Internal BOCCA error - missing package ' + fullpkg, 4)
            node = nodeList[0]
            buf += indent*level + 'package %s version %s {\n' % (pkg, node.version)
            level = level + 1
        
        buf += indent * level + 'class %s \n' %(self._b_className)
        if self._b_extends:
            buf += indent * level + 'extends %s \n' % (self._b_extends.keys()[0])
        
        all_impl = ['gov.cca.Component'] + ['gov.cca.ComponentRelease'] + \
                        self._b_implements.keys() + self._b_providesPorts.values()
        buf += indent * level + 'implements-all ' + ', '.join(all_impl) + '\n'
        buf += indent * level + '{\n\n'
        buf += indent * level + '// DO-NOT-DELETE bocca.splicer.begin(%s.methods)\n' % (self.symbol)
        buf += indent * level + '// Insert component-specific methods here\n\n'
        buf += indent * level + '// DO-NOT-DELETE bocca.splicer.end(%s.methods)\n' % (self.symbol)
        
        args = ''
        count = 0
        buf += indent * (level+1) + \
            '// DO-NOT-DELETE bocca.protected.begin(bocca:%s:boccaPrivateMethods)\n' % (self.symbol)
        buf += indent * (level+1) + \
            '/*\n'
        buf += indent * (level+1) + \
            '   Function to display a message if an exception occurs.\n'
        buf += indent * (level+1) + \
            '   @param excpt the exception to be checked.\n'
        buf += indent * (level+1) + \
            '   @param msg the message to be printed or added to the exception if fatal is true.\n'
        buf += indent * (level+1) + \
            '   @param fatal if an exception occured and fatal is false, msg is printed.\n'
        buf += indent * (level+1) + \
            '                If fatal is true, msg is printed and exit called.\n' 
        buf += indent * (level+1) + \
            '                For component programming, fatal==true is poor but common practice.\n'
        buf += indent * (level+1) + \
            '*/\n'
        buf += indent * (level+1) + \
            'void checkException(in sidl.BaseInterface excpt, in string msg, in bool fatal);\n'
        for uport in self._b_usesPorts.values():
            args += 'in ' + uport + ' ' + 'dummy'+str(count)+', '
            count+=1
        if (count > 0):
            args = args.rstrip(', ')
            buf += indent * (level+1) + '// method to make impl writing easier.\n'
            buf += indent * (level+1) + 'void boccaForceUsePortInclude(' + args + ');\n'
            
        buf += indent * (level+1) + \
            '// DO-NOT-DELETE bocca.protected.end(bocca:%s:boccaPrivateMethods)\n' % (self.symbol)
        while (level >= 0):
            buf += indent*level + '}\n'
            level = level - 1
            
        sidlDir = os.path.join(self._b_projectDir,"components", "sidl")
        try:
            os.makedirs(sidlDir)
        except:
            pass
        sidldir, sidlfiles = self.project.getLocationManager().getSIDLLoc()
        self._b_sidlFile = sidlfiles[0]
        fd = open(os.path.join(self._b_projectDir, self._b_sidlFile), "w")
        fd.write(buf)
        fd.close()
#        print >> DEBUGSTREAM , buf
        return
            
# ------------------------------------------------    
    def spliceBoccaBlocks(self):
        impldir, flist = self.project.getLocationManager().getImplLoc(self)
        print >> DEBUGSTREAM, '**** in COMPONENT spliceBoccaBlocks: ', self._b_projectDir, impldir, flist
        implSourceFile =  os.path.join(self._b_projectDir, self._b_implSource)
        writer = BoccaWriterFactory().getWriter(self._b_language)
        
# Splice code into impl source file
        prependBlockList = []
#        prependBlockList.append(writer.getImplHeaderCode(self.symbol))
        prependBlockList.append(writer.getAuxiliarySetServicesMethod(self.symbol, 
                                                              provideDict = self._b_providesPorts, 
                                                              useDict = self._b_usesPorts))
        replaceBlockList = []
        replaceBlockList.append(writer.getImplHeaderCode(self.symbol))
        replaceBlockList.append(writer.getConstructorCode(self.symbol))
        replaceBlockList.append(writer.getDestructorCode(self.symbol))
        replaceBlockList.append(writer.getSetServicesCode(self.symbol))
        replaceBlockList.append(writer.getReleaseMethod(self.symbol, 
                                                        provideDict = self._b_providesPorts, 
                                                        useDict = self._b_usesPorts))
        replaceBlockList.append(writer.getCheckExceptionMethod(self.symbol))
        
#        print >> DEBUGSTREAM, replaceBlockList
#        print >> DEBUGSTREAM, prependBlockList
        
        print >> DEBUGSTREAM, 'Splicing Impl file ', implSourceFile
        replaceGiantList = ''.join(replaceBlockList)
        print >> DEBUGSTREAM, replaceGiantList
        Operations.mergeFromString(implSourceFile, replaceGiantList, 'REPLACE_BLOCKS', 
                                   targetKey = 'DO-NOT-DELETE splicer', 
                                   sourceKey = 'DO-NOT-DELETE splicer', 
                                   insertFirst = True, 
                                   dbg = WARN, 
                                   verbose = WARN, 
                                   dryrun = False, 
                                   rejectSave= True, 
                                   warn= WARN)
        
        prependGiantList = ''.join(prependBlockList)
        print >> DEBUGSTREAM, "prependGiantList"
        print >> DEBUGSTREAM, prependGiantList
        Operations.mergeFromString(implSourceFile, prependGiantList, 'PREPEND_BLOCKS', 
                                   targetKey = 'DO-NOT-DELETE splicer', 
                                   sourceKey = 'DO-NOT-DELETE splicer', 
                                   insertFirst = True, 
                                   dbg = WARN, 
                                   verbose = WARN, 
                                   dryrun = False, 
                                   rejectSave= True, 
                                   warn= WARN)
        
        if (self._b_language == 'f77' or self._b_language == 'python'):
            return
        
# Splice code into impl header file
        implHeaderFile =  os.path.join(self._b_projectDir, self._b_implHeader)
        print >> DEBUGSTREAM, 'Splicing Impl header file ', implHeaderFile
        codeBlock = writer.getHeaderCode(self.symbol)
        print >> DEBUGSTREAM, codeBlock
        fd = open(implHeaderFile, "r")
        targetBuf  = fd.read()
        fd.close()
        Operations.mergeFromString(implHeaderFile, codeBlock, 'PREPEND_BLOCKS', 
                                   targetKey = 'DO-NOT-DELETE splicer', 
                                   sourceKey = 'DO-NOT-DELETE splicer', 
                                   insertFirst = True, 
                                   dbg = WARN, 
                                   verbose = WARN, 
                                   dryrun = False, 
                                   rejectSave= True, 
                                   warn= WARN)
#        newBuf = mySplicer(codeBlock,
#                            targetBuf,
#                            "DO-NOT-DELETE splicer.begin(",
#                            "DO-NOT-DELETE splicer.end(",
#                             mode = "REPLACE")
#        fd = open(implHeaderFile, "w")
#        fd.write(newBuf)
#        fd.close()
        return

# --------------------------------------------------------------------------

    def graphvizString(self): 
        return 'shape=doubleoctagon color=turquoise3 fontname="Palatino-Italic"'
            
# --------------------------------------------------------------------------
    def buildComponentCode(self):
        os.chdir(os.path.join(self._b_projectDir, 'components'))
        componentDescription = self._b_packageName+'.'+self._b_className+'-'+self._b_language
        buildCmd = 'make'
        buildTarget = '.'+componentDescription
        buildArgs = ' SIDL_FILES='+self._b_sidlFile + ' COMPONENTS='+componentDescription + buildTarget
        retcode = os.system(buildCmd + buildArgs)
        if (retcode != 0):
            err("Error Building component " +componentDescription, 3)
# TODO: Figure out interaction with th ebuild system
#        if not os.path.exists(os.path.join(self.classDir, "Makefile")):
#            makeFile = fileManager.open(os.path.join(self.classDir,"Makefile"), "w")
#            print >> makeFile, "# Common makefile fragment"
#        buildArgs = ['-C', os.path.join(self._b_projectDir, 'components', self._b_packageName, self._b_className)]
#        retcode = os.spawnvpe(os.P_WAIT, buildCmd, buildArgs, os.environ)
#        if (retcode != 0):
#           err("Error Building component " +componentDescription, 3)


# ------------------------------------------------
# ---------------- PRIVATE methods

    def _internalRename(self):
        return Sidlclass._internalRename(self)       
        

if __name__ == "__main__":
    Component().usage()
