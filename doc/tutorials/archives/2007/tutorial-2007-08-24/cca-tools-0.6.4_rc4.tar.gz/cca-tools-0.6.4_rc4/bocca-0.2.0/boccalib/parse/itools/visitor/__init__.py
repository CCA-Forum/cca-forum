'''
SIDL visitor support
'''
all = ['attribute', 'depthfirstvisitor', 'resolver', 'methodprocessor', 'depanalyzer', 'validator', 'printer', 'typefinder']
