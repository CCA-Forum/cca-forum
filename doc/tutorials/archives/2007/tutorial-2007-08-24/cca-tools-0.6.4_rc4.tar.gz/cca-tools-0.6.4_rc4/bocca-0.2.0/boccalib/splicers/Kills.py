
killBlockKeys=["DO-DELETE-WHEN-IMPLEMENTING exception"]

# Raw data section.
# To extend for application, copy one of these and extend the copy.
#
cxxKillKeys=[
"Insert-Code-Here"
]

javaKillKeys=[
"Insert-Code-Here"
]

f90KillKeys=[
"Insert-Code-Here"
]

f77KillKeys=[
"Insert-Code-Here"
]

pythonKillKeys=[
"Insert-Code-Here"
]

cKillKeys=[
"Insert-Code-Here"
]


# typically we would want to use killByLang if possible
killByLang = dict()
killByLang['f77'] = f77KillKeys
killByLang['f90'] = f90KillKeys
killByLang['python'] = pythonKillKeys
killByLang['c'] = cKillKeys
killByLang['cxx'] = cxxKillKeys
killByLang['java'] = javaKillKeys


