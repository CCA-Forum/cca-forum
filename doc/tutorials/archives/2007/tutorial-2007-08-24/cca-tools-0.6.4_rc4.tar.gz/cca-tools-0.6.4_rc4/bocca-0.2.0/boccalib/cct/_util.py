""" Various utilities that don't fit elsewhere
"""
import os, stat, shutil

from cct._debug import *
from cct._err import *

#---------------------------------------------------------------------------
# Global singleton variables:

# File manager (singleton) -- use this to open all files to make actions undoable
from cct._file import BFileManager
fileManager = BFileManager()

#----- end global singleton variables:

def Globals():
    '''Helper function to ensure exactly one instance of the Globals_singleton class exists'''
    myglobals = None
    try:
        myglobals = Globals_Singleton()
    except Globals_Singleton, s:
        myglobals = s
    return myglobals

class Globals_Singleton:
    '''A singleton class in which to stash various useful global variables for bocca.
    Do not instantiate this class directly, rather use the Globals helper function,
    e.g., myglobals = Globals().
    '''
    __single = None  # Used for ensuring singleton instance
    def __init__(self):
        if Globals_Singleton.__single:
            raise Globals_Singleton.__single 
        Globals_Singleton.__single = self
        self.projects = {}  # A dictionary with key = projectName, val = project
        self.graphs = {} # A dictionary of loaded graphs
        self.cca_vars = {} # a dictionary with key = projectName, val - CCA_SPEC_BABEL_CONFIG vars
        self.dirsToAvoid = ['CVS', '.svn', 'autom4te.cache', 'trash']
        pass
    
    def getProjectAndGraph(self, projectName = None, forceReload=False, modulePath=None):
        '''Returns a 2-tuple (project,graph) with the cached project and 
        corresponding graph. If the graph hasn't been loaded yet, it is loaded
        and cached and the values returned.
        '''
        if projectName in self.projects.keys() and projectName in self.graphs.keys() and not forceReload:
            # Return cached versions
            return self.projects[projectName], self.graphs[projectName]
        if not projectName:
            projectName,mydir = getProjectInfo()
            #print >>DEBUGSTREAM, 'after getProjectInfo: ', projectName, mydir
        # If the project is already loaded return it, otherwise load it
        if projectName not in self.projects.keys() or forceReload:
            proj, graph = getProject(projectName,modulePath=modulePath)
            if proj is not None: self.projects[projectName] = proj
            else: return None, None
            if graph is not None: self.graphs[projectName] = graph
            else: return None, None
        return self.projects[projectName], self.graphs[projectName]
    
    def renameProject(self, projectName, newProjectName):
        if newProjectName in self.projects.keys():
            err('cannot rename project to ' + newProjectName + ': project already exists')
        if projectName in self.projects.keys() and projectName in self.graphs.keys():
            del self.projects[projectName]
            del self.graphs[projectName]
        return self.getProjectAndGraph(newProjectName, forceReload=True)
    
    def getProject(self, projectName=None):
        '''Same as getProjectAndGraph except returns just the project.'''
        if projectName in self.projects.keys():
            return self.projects[projectName]
        return self.getProjectAndGraph(projectName)[0]
    
    def getGraph(self, projectName=None):
        '''Same as getProjectAndGraph except returns just the graph.'''
        if projectName in self.graphs.keys():
            return self.graphs[projectName]
        return self.getProjectAndGraph(projectName)[1]
    
    def getDefaults(self, projectName=None, forceReload=False):
        '''Returns the ConfigurationParser instance contaning project defaults settings.'''
        
        project, graph = self.getProjectAndGraph(projectName)
        if project is None or projectName not in self.projects.keys():
            return None
        mydir = project.getAttr('projectDir')
        
        if not forceReload:
            # Return cached version
            return self.projects[projectName].getDefaults()
        
        # Reload the defaults file
        return self.projects[projectName].loadDefaults()
        
    def saveState(self, projectName=None):
        r = 0
        if projectName is not None:
            if projectName in self.projects.keys():
                return self.graphs[projectName].save()
        else:
            for g in self.graphs:
                r = g.save()
                if r != 0: return r
        return r
    
    def getCCAVars(self, projectName='', forceReload=False):
        if projectName in self.cca_vars.keys() and not forceReload:
            return self.cca_vars[projectName]
        
        project,graph = Globals().getProjectAndGraph(projectName)
        defaults = project.getDefaults()
        
        #print >>DEBUGSTREAM, '[_util Globals.getCCAVars] loaded defaults:' + str(defaults)
        defaults.write(DEBUGSTREAM)

        cca_spec_bin = defaults.get('CCA', 'cca_spec_babel_config')
        if cca_spec_bin.count('"') == 2: 
            cca_spec_bin = cca_spec_bin[cca_spec_bin.find('"')+1:cca_spec_bin.rfind('"')]
        print >>DEBUGSTREAM, '[_util Global.getCCAVars] cca_spec_bin =', cca_spec_bin
        if os.path.exists(cca_spec_bin):
            mode = os.stat(cca_spec_bin)[stat.ST_MODE] 
            if os.path.isfile(cca_spec_bin):
                if not bool(mode & stat.S_IEXEC):
                    err('[_util: getCCAVars]: could not load CCA settings from ' + cca_spec_bin + ' (file not found or not executable).')
            else:
                 err('[_util: getCCAVars]: could not load CCA settings from ' + cca_spec_bin + ' (not a file).')
        else:
            err('[_util: getCCAVars]: could not load CCA settings from ' + cca_spec_bin + ' (file not found).')
        
        myvars={}
        f= os.popen(cca_spec_bin+' --dump')

        l = f.readline()
        while (l != ''):
            tokens = l.replace('\'', '').replace('"', '').strip().split('=', 1)
            if (len(tokens) == 2):
                myvars[tokens[0]] = tokens[1]
            elif (len(tokens) ==1):
                myvars[tokens[0]] = ''
            l = f.readline()
        f.close()
        
        # Add the cca.sidl file to the cca myvars (strangely enough, it's not available directly with cca-spec-babel-config
        myvars['CCA_sidl'] = os.path.join(myvars['CCASPEC_datadir'],'cca.sidl')
 
        self.cca_vars[projectName] = myvars
        return myvars
        
    def getDirsToAvoid(self):
        return self.dirsToAvoid
    
    def setDirsToAvoid(self,dirs):
        self.dirsToAvoid = dirs
        return self.dirsToAvoid

#---------------------- end class Globals_Singleton ------------------

#---------------------------------------------------------------------
#  Various helpful methods:

def deserializeASCII(thestring):
    '''A deserialization method for basic objects 
    (not as general or efficient as pickle, but portable).
    Returns a dictionary of objects of the appropriate types.
    
    @param thestring: a string containing a list, a dictionary, a number, or a string
    '''
    import re
    s = cleanString(thestring)
    if not s: return ''
    
    # Lists
    if s.startswith('[') and s.endswith(']'):
        newlist = []
        t = s[1:-1].strip()
        # Check for nested dictionaries or lists
        if t.startswith('{'):
            endindex = findClosingElement(t,openchar='{',closechar='}')
            element = deserializeASCII(t[:endindex])
        elif t.startswith('['):
            endindex = findClosingElement(t,openchar='[', closechar=']')
            element = deserializeASCII(t[:endindex])
        else:
            endindex = t.find(',')
            element = t[:endindex]
        element = cleanString(element).strip()
        if element: newlist.append(element)
        
        if endindex > 0: 
            element = deserializeASCII(cleanString(t[endindex+1:])).strip()
            if element: newlist.append(element)
        return newlist   
    
    # Dictionaries
    if s.startswith('{') and s.endswith('}'):
        t = s[1:-1].strip()
        #print 'deserializeASCII, found dictionary: \n\t%s\n\t%s' % (s,t)
        # Now check individual elements
        newdict = {}

        while t:
            i = t.find(':')
            key = cleanString(t[:i])
            therest = cleanString(t[i+1:])
            #print 'key = %s, therest = %s' %( key, therest)
            # Check for nested dictionaries or lists
            if therest.startswith('{'):
                endindex = findClosingElement(therest,openchar='{',closechar='}')
            elif therest.startswith('['):
                endindex = findClosingElement(therest,openchar='[', closechar=']')
            elif therest.find(',') > 0:
                endindex = therest.find(',')
            else:
                endindex = len(therest) + 1
            val = therest[:endindex]

            if endindex > 0: t = therest[endindex+1:]
            else: t = ''
            key = cleanString(key)
            key = deserializeASCII(key)
            val = cleanString(val)
            val = deserializeASCII(val)
            newdict[key] = val
            #print 'key = %s, val = %s'%(key,val)
        return newdict
     
    # Numbers
    intpattern = re.compile(r'[+-]?\d+')
    m = intpattern.match(s)
    if m: 
        (start, end) = m.span()
        if start == 0 and end == len(s):
            return int(s)
        
    # Bocca doesn't work with floats, but if at some point it does, make sure that version strings don't get converted to floats

    # Strings for everything else
    return cleanString(s)

def cleanString(s):
    newstr = s
    if s.__class__ == str:
        newstr = s.strip().strip("'").strip('"')
    return newstr

def findClosingElement(s, openchar='{', closechar='}'):
    newstr = s.strip()
    if s.startswith(openchar):
        rbindex = newstr.find(closechar)
        numnests = newstr[1:rbindex].count(openchar)
        n = 0
        curpos = rbindex +1
        while n < numnests:
            oldpos = curpos
            rbindex = newstr[curpos:].find(closechar)
            curpos += rbindex 
            n += 1
            numnests += newstr[oldpos:curpos+rbindex].count(openchar)
            #print 'numnests = ' + str(numnests), ', rbindex = ' + str(rbindex) + ', ' + newstr[:curpos+1]
 
        return curpos+1
    return -1
              
def getEditor():
    """ checks for:
env(BOCCA_EDITOR)
env(EDITOR)
# project default editor setting -- not implemented
vi
emacs
and then returns it if valid or None if a problem occurs.
"""
    args = []
    try:
      edit = os.environ["BOCCA_EDITOR"]
    except:
      try:
        edit = os.environ["EDITOR"]
      except:
        edit = "vi"
    args = edit.split()
    editor= args[0]
    return (editor, args)

def getEditorWaitFlag():
    """ We're not pychic, so if the user wants us not to wait (e.g. their
editor has an independent gui window), they can tell us not to with an
env var."""
    result=os.P_WAIT
    try: # if set, assume nowait
        dummy = os.environ["BOCCA_EDITOR_NOWAIT"]
        result = os.P_NOWAIT
    except:
        pass
 
    return result

def editFile(filename):
    print "Trying to edit file ", filename
    editor, userargs = getEditor()
    if editor == None:
        return # FIXME need to print "unable to find an editor for ", filename
    if filename == None or len(filename) <1:
        return
    userargs.append(filename)
    wait=getEditorWaitFlag()
    os.spawnvp(wait, editor, userargs) # py 2.3 and later.
    return
    

def getProject(projectName=None, modulePath=None):
    '''Returns a 2-tuple, (CCAProject,BGraph) containing the Project
    vertex for the named project and the graph that contains it. If a name 
    is not specified, the project info in the current directory is 
    used. If multiple projects are found, an error is printed. 
    If this method is executed outside of a valid
    project directory, it returns None.
    '''
    from graph.boccagraph import BGraph

    pgraph = None
    project = None
    name,mydir = getProjectInfo(projectName)
    if mydir is not None:
        pgraph = BGraph(name=name,path=mydir, modulePath=modulePath)
        try:
            retcode = pgraph.load(modulePath=modulePath)   
        except:
            retcode = 1
        if retcode != 0:       
            warn('Loading from pickle failed, loading ASCII representation of project.')
            pgraph = BGraph(name=name,path=mydir, modulePath=modulePath)
            pgraph.loadASCII(modulePath=modulePath)
              
        vlist = pgraph.findSymbol(name,kind='project')  # Project vertex 
        if not vlist:
            pgraph = BGraph(name=name,path=mydir, modulePath=modulePath)
            pgraph.loadASCII(modulePath=modulePath)
            vlist = pgraph.findSymbol(name,kind='project')  # Project vertex
        if vlist: project = vlist[0]
        else: err('could not load project')
        
        project.setAttr('projectDir', pgraph.path)

        if modulePath: project.modulePath = modulePath
       
    if project is not None:
        project.loadBuildTemplate()
        project.loadDefaults()
    return project,pgraph

def getProjectInfo(projectName=None):
    '''Returns a 2-tuple containing the project name and directory when executed 
    within a valid project subdirectory or (None, None) if this is not a valid 
    project directory or if the project found does not match projectName (when
    projectName is not None). Exits with an error if projectName is None and 
    multiple projects are found.
    '''
    currdir = os.getcwd()
    name = projectName
    metadir = os.path.join(currdir,'BOCCA')
    if not os.path.exists(metadir): return None, None
    try:
        files = os.listdir(metadir)  
    except:
        return None,None

    count = 0
    for f in files:
        if f.startswith('Dir-'):
            name = f.lstrip('Dir-')
            count = count + 1
            if projectName is None and count > 1:
                return err('Multiple projects found in this directory, a specific project name is required in order to load project information.')
            if projectName is not None and projectName != name:
                continue
            try:
                fin = open(os.path.join(currdir, 'BOCCA','Dir-' + name))
            except:
                return None,None
            relativePath = fin.readline()
            fin.close()
            relativePath.strip()
            mydir = currdir.rstrip(relativePath).rstrip('/')
            return name,mydir
    return None,None

def addSubdir(projectName, relativePath):
    '''Add a subdirectory to a given project, creating metadata in .bocca.
        This can be invoked in any project subdirectory. Project is a 
        CCAProject instance.
    '''
    # Create hidden metadata directories (.bocca) whose contents would
    # normally *not* be under revision control
    project, graph = getProject(projectName)
    name, projectDir = project.getInfo()
    if name is not projectName: return 1
    
    dirToAdd = os.path.abspath(os.path.join(projectDir,relativePath))
    try:
        if not os.path.exists(dirToAdd): fileManager.mkdir(dirToAdd)
    except:
        return err('Could not create subdirectory ' + str(dirToAdd) + ' in project ' + projectName)
        
    addProjectMetadirs(projectName,dirToAdd,rootDir=projectDir)
    return 0
    
def validSubdir(projectName, relativePath):
    
    visibleMetadir = 'BOCCA'
    n, projectDir = getProjectInfo(projectName)
    #project, graph = getProject(projectName)
    if projectName is not None and n != projectName:
        warn('Invalid project name, cannot validate subdirectory.')
        return False
    
    projectName = n
    if projectName is None:
        return False
    
    if projectDir is None:
        warn('Cannot find project directory for project ' +  projectName + '.')
        return False
    
    # First get project path from top-level metadir
    topdirfile = os.path.join(projectDir,visibleMetadir,'Dir-'+projectName)
    if not os.path.exists(topdirfile):
        warn('Cannot validate top-level project directory, project metadata is missing or corrupted.')
        return False
    
    fin = open(topdirfile,"r")
    pDir = fin.readline().strip()  # get the project directory from the top-level BOCCA/Dir-ProjName file
    fin.close()
    if str(os.path.abspath(os.path.join(projectDir,pDir))) != str(os.path.abspath(projectDir)):
        warn('Cannot validate top-level project directory, project metadata is missing or corrupted.')
        return False
    
    # Check if the .bocca directory in relativePath contains a correct Dir-ProjName entry
    metadir = os.path.abspath(os.path.join(projectDir,relativePath))
    if metadir == projectDir: return True
    else: metadir = os.path.join(metadir,visibleMetadir)
    if not os.path.isdir(metadir):
        warn('Subdirectory ' + str(metadir) + ' doesn''t exist or is not a directory.')
        return False
    
    dirfile = os.path.join(metadir,'Dir-'+projectName)
    if not os.path.isfile(dirfile):
        warn('Project metafile ' + str(dirfile) + ' not found or is not a file.')
        return False
    
    # Check contents of dirfile
    fin = open(dirfile,"r")
    rdir = fin.readline().strip()
    fin.close()
    if not os.path.isdir(os.path.abspath(os.path.join(projectDir,rdir))):
        warn('Cannot validate project subdirectory ' + str(rdir) + ': inconsistent metadata.')
        return False
    
    return True

def addProjectMetadirs(projectName, topDir, rootDir):
    '''Create hidden metadata directories (.bocca) whose contents would
    normally *not* be under revision control.'''
    os.path.walk(topDir,manageProjectMetadirsFunc,arg={'projectName':projectName,'rootDir':rootDir,'action':'add'})
    return
    
def removeProjectMetafiles(projectName, topDir, rootDir):
    os.path.walk(topDir,manageProjectMetadirsFunc,arg={'projectName':projectName,'rootDir':rootDir,'action':'rm'})
    return 

def manageProjectMetadirsFunc(arg,dirname,fnames):
    '''Visitor function to perform various file operations. Normally invoked by tree walkers,
    such as addProjectMetadirs and removeProjectMetafilles.
    '''
    dirsToAvoid = Globals().getDirsToAvoid()    
    dirs = dirname.split(os.path.sep)
    for d in dirsToAvoid:
        if d in dirs: return
    
    visibleMetadir=None
    hiddenMetadir=None
    action = arg['action']
    if action == 'add':
        if dirs[-1] == 'BOCCA' or dirs[-1] == '.bocca':
            return
        visibleMetadir = os.path.abspath(os.path.join(dirname,'BOCCA'))
        hiddenMetadir = os.path.abspath(os.path.join(dirname,'.bocca'))
    elif action == 'rm' or action == 'rmdir':
        if dirs[-1] == '.bocca': hiddenMetadir = dirname
        elif dirs[-1] == 'BOCCA': visibleMetadir = dirname
        else: return
 
    projName = arg['projectName']
    projDir = arg['rootDir']

    if dirname.startswith(projDir):
        relativePath = dirname.replace(projDir,'').lstrip(os.path.sep)
    else:
        relativePath = dirname

    if os.path.isabs(relativePath): 
        print 'Error: invalid relative path or absolute path outside project specified.'
        return
        
    if action == 'add':
        try: fileManager.mkdir(hiddenMetadir)
        except: print >> DEBUGSTREAM, ".bocca subdirectory found in " +  str(dirname) + " (that's ok)."
        try: fileManager.mkdir(visibleMetadir)
        except: print >> DEBUGSTREAM, "BOCCA subdirectory found in " + str(dirname) + " (that's ok)."
    elif action == 'rmdir':
        try: fileManager.rmdir(hiddenMetadir)
        except: print >> DEBUGSTREAM, "could not remove hidden metadir " + str(hiddenMetadir) + "(that's ok)."
        try: fileManager.rmdir(visibleMetadir)
        except: print >> DEBUGSTREAM, "could not remove visible metadir " + str(visibleMetadir) + "(that's ok)."
        return
        
    if relativePath.strip() is '': relativePath = '.'
    if visibleMetadir is not None:
        filename = os.path.join(visibleMetadir,'Dir-'+projName)
    else:
        return
    if action == 'add':
        try:
            fout = fileManager.open(filename, "w")
            fout.write(relativePath+'\n')
            fout.close()
        except IOError,e:
            err('could not create Bocca metafile ' + filename + ': ' + str(e))
    elif action == 'rm':
        try:
            fileManager.rm(filename, trash=False)
        except IOError,e:
            err('could not remove file ' + filename + ': ' + str(e))
    return

def mySplicer(source, destination, beginPat, endPat, mode='APPEND', arg=None):
    """ Splice blocks from source buffer to destination buffer. Blocks
        are matched based on the block beginning pattern (beginPat) and
        block termination pattern (endPat). 
        
        A none None value for arg restricts replacement to blocks bound by 
        beginPat(arg)
            
        endPat(arg)
        otherwise, all blocks matching any argument will be replaced.
    """
    
    s_begin = source.find(beginPat) # Example: bocca.protected.begin(
    d_text_begin = 0
    while (s_begin != -1):
        lpar = source.find('(', s_begin)
        rpar = source.find(')', lpar)
        splicerArg = source[lpar+1:rpar]
        s_text_begin = source.find('\n', rpar) +1
        endText = endPat.rstrip('(')+'(' + splicerArg + ')'
        s_end = source.find(endText, s_text_begin)
        s_text_end = source.rfind('\n', 0, s_end)
   
        beginText = beginPat.rstrip('(')+'(' + splicerArg +')'
        d_begin = destination.find(beginText, d_text_begin)
        d_text_begin = destination.find('\n', d_begin)+1
        d_end = destination.find(endText, d_begin)
        d_text_end = destination.rfind('\n', 0, d_end) 
   
        s_begin = source.find(beginPat, s_text_end)
        if (d_begin == -1):   # Target does not contain splicer block
            d_text_begin = 0
            continue
        
        if (arg != None and arg != splicerArg):
            continue
        
        if (mode == 'REPLACE')  :
            new_dest = destination[0:d_text_begin] + source[s_text_begin:s_text_end] + destination[d_text_end:]
        elif (mode == 'APPEND'):
            new_dest = destination[0:d_text_end] + source[s_text_begin:s_text_end] + destination[d_text_end:]
        elif (mode == 'PREPEND'):
            new_dest = destination[0:d_text_begin] + source[s_text_begin:s_text_end] + destination[d_text_begin:]
        elif (mode == 'DELETE'):
            new_dest = destination[0:d_text_begin] + destination[d_text_end:]
         
        destination = new_dest
      
    return destination

# TODO: the methods below are not needed -- equivalent functionality is available in _validate.py
def lang_to_fileext(lang):
    if lang == "cxx":
        return "cxx"
    elif lang == "java":
        return "java"
    elif lang == "c":
        return "c"
    elif lang == "f90":
        return "F90"
    elif lang == "f77":
        return "f"
    else:
        return None
    return

def lang_to_headerext(lang):
    if lang == "cxx":
        return "hxx"
    elif lang == "c":
        return "h"
    elif lang == "f90":
        return "F90"
    else:
        return None
    return

