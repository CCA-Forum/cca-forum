import os, sys, imp, re
from cct._util import *
from cct._examples import exdispatchArgv
from cct.project import Project

def dispatch(argv,projectName,modulePath,boccaprog):
    ''' The bocca dispatcher. It takes the command line options, which are of the 
    form "action object options", where "action" is one of create/remove/change/rename (etc), and 
    "object" is what the action is applied to, e.g., project, interface, class, port, 
    component, library. The "options" are passed unchanged to the subject being dispatched to.
    '''
    
    sys.path.append(modulePath)
    cctModulePath = os.path.join(modulePath,'cct')
    sys.path.append(cctModulePath)
    from _debug import DEBUGSTREAM
    
    verb = 'display'
    subject = 'help'
    helponly = True
    l = len(argv)
    if l < 1: verb = 'usage'
    if l == 1 and argv[0] == 'display': subject = 'project'  # just to be nice
    else: verb = 'usage'
    args = []
    
    # Get lists of known verbs and subjects
    (file,filename,description) = imp.find_module('cct',[modulePath])
    mod = imp.load_module('cct', file, filename, description)
    menu = getattr(mod, 'menu')
    action_menu = getattr(mod, 'action_menu')

    
    # Try to provide help with different combinations of arguments
    if 'help' in argv or '-h' in argv or '--help' in argv:
        # Begin internal option (Issue29)
        if l==2 and argv[0] == 'help' and argv[1] == '--keywords':
            buf = 'Bocca verbs:'
            for i in action_menu: buf += ' ' + i
            buf += '\nBocca subjects:'
            for i in menu: buf += ' ' + i            
            print buf
            sys.exit(0)
        # End internal option
        if l>=2 and argv[0] == 'help' and argv[1] == '--examples':
            sys.exit(exdispatchArgv(argv))
        # End internal option

        # Remove multiple 'help's
        tmpargv = []
        for a in argv:
            if a != 'help' and a != '-h' and a != '--help': tmpargv.append(a)
        if len(tmpargv) < 2:
            args += tmpargv
        else:
            verb = tmpargv[0]
            subject = tmpargv[1]
            args = ['--help']
    else:
        helponly = False
        verb = argv[0]
        if l > 1: subject = argv[1]
        if l > 2: args = argv[2:]

    subject = subject.strip()

    theproject = None
    graph = None
    vertex = None
    
    # Do some nice conversions to make the command-line more user-friendly
    if subject == 'class': subject = 'sidlclass'

    if verb not in ['usage','help']:
        graph, theproject = loadProject(projectName,theproject, modulePath)
        if theproject: 
            if not os.path.exists(theproject.modulePath):
                theproject.modulePath = modulePath
            projectName = theproject.symbol
        
    # Check whether action exists and pass the ball to help
    # Show some meaningful help when invalid verb or subject are given
    if verb != 'usage' and verb not in action_menu:
        args = [verb]
        verb = 'display'
        subject = 'help'
        helponly = True
    elif subject != 'help' and subject not in menu:
        # First, try to be smart and bring up an existing vertex of whatever kind
        # without requiring the subject to be explcitly specified
        # If the subject was not in the menu, assume it's a (partial) SIDL Symbol and 
        # look for it in the existing project.
        if theproject:
            if graph != None and vertex is None:
                sym = subject
                vlist = graph.findSymbol(sym, kind='any')
                if len(vlist) == 0:
                    # Try with the last argument
                    sym = argv[-1]
                    vlist = graph.findSymbol(sym, kind='any')
                if len(vlist) == 1: 
                    vertex = vlist[0]
                    argv.remove(sym)
                    subject = vertex.kind
                    args = [vertex.symbol] + argv[1:]
                elif len(vlist) > 1:
                    msg = 'Multiple matches for symbol ' + subject + ':\n'
                    i = 1
                    for v in vlist:
                        msg += '\t' + str(i) + ': ' + v.prettystr() + '\n'
                        i += 1
                    err(msg)
    
                    
        if not vertex:
            # Could not figure out the vertex kind, display help
            args = [subject]
            verb = 'display'
            subject = 'help'
            helponly = True



    if theproject: 
        print >> DEBUGSTREAM, 'dispatcher: project:', projectName, ',symbol=', str(theproject.symbol), ', verb: ', verb, ', subject: ', subject, ', args=', args, ',helponly=', helponly

    # Dispatch to the relevant command
    if len(subject) > 0:
        # The convention for subjects is that they are implemented in 
        # a file subcmd.py using a class Subcmd (same as the module name, but capitalized).
        subcmdModuleName = subject.strip()
        subcmdClassName = subcmdModuleName.capitalize()

        try:
            (file,filename,description) = imp.find_module(subcmdModuleName,[cctModulePath])
            mod = imp.load_module(subcmdModuleName, file, filename, description)
        except ImportError:
            helponly = error('Cannot find code for "' + subcmdModuleName + '" in ' + cctModulePath)
    
        subcmdClass = None
        try:
            subcmdClass = getattr(mod,subcmdClassName)
        except AttributeError:
            helponly = error('Cannot find code for class "' + subcmdClassName + '" in ' + cctModulePath)

        # The dispatcher always create an instance of the subcmdClass (i.e., specific BVertex subclass).
        # Once instantiated successfully, the dispatcher then checks for a vertex of the specified 
        # type and SIDL symbol in the graph. If such a vertex is successfully found, the method
        # specified in "verb" is executed on the existing vertex, and the new vertex is simply 
        # abandoned to the garbage collector. If the project or graph is not available or 
        # the vertex cannot be found, the method specified by "verb" is invoked on the newly
        # instance.
        subcmdInst = None
        symbol, kind, version = None, None, None
        if subcmdClass is not None:
            if subject != 'project' or theproject is None:
                subcmdInst = subcmdClass(action=verb,args=args,project=theproject,modulePath=modulePath)
                if subcmdInst is None:
                    fileManager.undo()
                    fileManager.close()
                    sys.exit(err('[displatcher] could not create an instance of ' + subcmdClassName))
                symbol = subcmdInst.symbol
                kind = subcmdInst.kind
                version = subcmdInst.version
            elif theproject is not None and subject=='project':
                # Work with loaded project
                theproject.setup(verb,args)
                vertex = theproject
            else:
                helponly = error('cannot instantiate class "' + subcmdClassName + '" or load existing project')

        else:
           helponly = error('cannot instantiate class "' + subcmdClassName + '"')
 
        if theproject is not None: 
            fileManager.setProjectName(theproject.symbol)
            fileManager.setProjectDir(theproject.getDir())

        # Check to see if vertex is already in graph and if found, invoke verb on existing instance
        vlist=[]
        if graph != None and vertex is None:
            vlist = graph.findSymbol(symbol, kind, version)
            if len(vlist) != 1: vertex = None
            else: vertex = vlist[0]
        if vertex is None:
            subcmdMethod = getattr(subcmdInst,verb)
            vertex = subcmdInst
        else: 
            # Make sure that the unpickled vertex is set up properly with the current
            # command-line options and arguments (those are not pickled).
            saveSymbol = vertex.symbol
            #print 'vertex.symbol before handleArgs ' + str(vertex.symbol)
            # Note that handleArgs invokes the methods defineArgs, and processArgs
            vertex.modulePath = modulePath
            if theproject is not None and vertex.kind != 'project': vertex.project = theproject
            vertex.handleArgs(args, action=verb)
            vertex.symbol = saveSymbol # prevent accidental (or intentional) overwrites of the SIDL symbol 
            #print 'vertex.symbol after handleArgs ' + str(vertex.symbol)
            subcmdMethod = getattr(vertex,verb)
            

        print >>DEBUGSTREAM, 'dispatcher: about to execute "' + subject + '.' + verb  + '()"'  

        result = subcmdMethod()   # Run the method on the subject, return value is 0 upon success, non-zero otherwise
        
        # Save defaults (some commands modify them)
        if vertex.project is not None:
            print >>DEBUGSTREAM, 'dispatcher: saving project defaults in ' + vertex.project.getAttr('defaultsFile')
            theproject.defaults.write(fileManager.open(os.path.join(theproject.getAttr('projectDir'),theproject.getAttr('defaultsFile')),'w'))
        
        # Note fileManager.undo() has been moved to the err() method in _err.py
        try:
            fileManager.close()     # close all files and clean backups if needed
        except IOError,e:
            error('failed to close files and/or clean up backups: ' + str(e))
            result = 1

        sys.exit(result) # This should never be reached if there was an error


def error(msg=''):
    print >> sys.stderr, 'Bocca ERROR: ' + msg
    return True

def loadProject(projectName, theproject, modulePath=None):
    if theproject: return theproject.getGraph(), theproject
    # Get project name and dir from .bocca dir (if any)
    if not projectName:
        theproject, graph = Globals().getProjectAndGraph(modulePath=modulePath)
        if theproject: theproject.loadDefaults()
    elif validSubdir(projectName, os.getcwd()):
        theproject, graph = Globals().getProjectAndGraph(projectName)
        if theproject: theproject.loadDefaults()
    else:
        return None, None
    return graph, theproject

