#!/usr/bin/env python
""" A container of several higher-level splicing operations with policy
choices embedded.
   Author: Benjamin Allan
   Org:	Sandia National Laboratories, Livermore
   Date: 5/2006.
   License: GPLv2. Of course this doesn't affect the files that
	are processed by this utility.
"""
import sys
import os.path
from splicers import Source, Data, Misc, Block


def warnMessage(message, fatal=False):
    print "Warning: " , message
    if fatal:
        sys.exit(3)

def getSourceString(inputName, sourceKey, src, fatal=True, dontwarn=False):
    sf = Source.Source()
    status, msg  = sf.loadString(inputName, sourceKey, src, dontwarn)
    if status:
        warnMessage(msg, fatal)
    return sf
# end getSourceString

def getSource(srcName, sourceKey, fatal=True):
    sf = Source.Source()
    status, msg  = sf.loadFile(srcName, sourceKey)
    if status:
        warnMessage(msg, fatal)
    return sf
# end getSource

def findSplices(symbols, insertions, sf, verbose, methodMatch=False, oldtype="", newtype="", matchSyms=[], excludeSyms=[]):
    """ find blocks from prepared src matching symbols
given and add them to the symbol keyed insertions list.
@param sf Source from which to splice.
@param methodMatch if True, then rename matches from sf are done for symbols,
       taking symbol $oldtype.$method to match $newtype.$method. To insure
       correct operation, oldtype, newtype should be fully qualified sidl names.
@param matchSyms if given is a list of symbols to match in target and ignore all others.
"""

    checkMatchSym = (len(matchSyms) > 0)
    if verbose:
        print "findSplices: user match list=" , matchSyms
        print "findSplices: user exclude list=", excludeSyms
        if methodMatch:
            print "fromType = ", oldtype, "toType = ", newtype

    for j in symbols:

        if excludeSyms and Misc.symbolContainsListItem(j, excludeSyms):
            if verbose: print 'Matched excluded symbol, skipping: ' , j
            continue

        if checkMatchSym:
            if not Misc.symbolContainsListItem(j, matchSyms):
                if verbose:
                    print "No Match of " , j 
                continue
            else:
                if verbose:
                    print "Match of " , j 

        p = insertions.get(j, None)
        if methodMatch:
            jold = j.replace(newtype, oldtype)
        else:
            jold = j
        ins = sf.getBlock(jold)
        if ins != None:
            if verbose:
                print "found an insertion for " , j
            if p != None:
                # FIXME whine about duplicate.
                pass
            else:
                if methodMatch:
# this is cleaner in some sense (readonly treatment) but messes up warning management
                    if False:
                        # make a new block from body of old and symbol of new.
                        insfixed = Block.Block()
                        oldlines = ins.getLines()
                        newbegin=oldlines[0].replace(oldtype, newtype)
                        newend=oldlines[len(oldlines)-1].replace(oldtype, newtype)
                        newlines = [newbegin] + oldlines[1:len(oldlines)-2] + [newend ]
                        insfixed.init(ins.key(), newlines, ins.source(), ins.start() )
                        insertions[j] = insfixed
                        if verbose:
                            print "it is len " , len(newlines)
                    else:
                        # modify in place
                        oldlines = ins.getLines()
                        newbegin=oldlines[0].replace(oldtype, newtype)
                        newend=oldlines[len(oldlines)-1].replace(oldtype, newtype)
                        oldlines[0] = newbegin
                        oldlines[len(oldlines)-1] = newend
                        insertions[j] = ins
                else:
                    # transfer from sf to insertions
                    insertions[j] = ins
#end findSplices


def warnMissing( symbols, insertions, warn, warnCommon, commonSuppressions, fatal, matchSyms=[], excludeSyms=[]):
    if warn:
        for i in symbols:
            if not Misc.symbolContainsListItem(i, matchSyms+excludeSyms):
                continue
            p = insertions.get(i, None)
            if  p == None and \
                (warnCommon or not Misc.isCommon(i, commonSuppressions)):
                msg = "No block or splice found for output symbol " + i
                warnMessage(msg,fatal)
# end warnMissing

class Usage(Exception):
    def __init__(self, msg):
        self.msg = msg

def mergeMain(argv=None):
    if argv is None:
        argv = sys.argv
    try:
        opts, args = Data.parseargs(argv)

        if not Data.validateOpts(opts) or not opts.robMode :
            print "Got invalid options somehow or not simple merge usage"
            return 1

        if opts.dbg :
            Data.printopts(opts)
    
        mergeFiles(opts.outputFile, opts.inputFile, opts.targetKey, opts.sourceKey, opts.insertFirst, opts.dbg, opts.verbose, 
                   opts.dryrun, opts.rejectSave, opts.warn, opts.fatal, opts.warnCommon, opts.commonSuppressions, opts.matchSyms)

    except Usage, err:
        print >>sys.stderr, err.msg
        print >>sys.stderr, "for help use --help"
        return 2

# end mergeMain

def mergeFileIntoString(targetName, targetString, srcName, targetKey="DO-NOT-DELETE splicer", sourceKey="DO-NOT-DELETE splicer" , 
                        insertFirst=True, dbg=False , verbose=False, rejectSave=True, warn=True, fatal=True,  warnCommon=False, 
                        commonSuppressions=[], replaceIdentical=False):
    """ merge, a function for merging blocks from a named file into a string, overwriting the target string's blocks if appropriate.
@param targetName a name for error reporting purposes to describe the target string identity.
@param targetString the string to be spliced into from the blocks in the file.
@param srcName the filename to be read.
@param targetKey the splicer tag by which blocks are identified in the string.
@param sourceKey the splicer tag by which blocks are identified in the file.
@param insertFirst where splicing results in nested tags (srcKey != targetKey), blocks from the
       file are inserted ahead of existing block contents, else appended if false.
@param dbg emit various debugging info.
@param verbose narrate the process a bit.
@param rejectSave if true, create a $targetName.rej file of splices removed from string.
@param warn display complaints if appropriate.
@param fatal warnings should be treated as fatal, causing exit.
@param warnCommon if true, warn about unsupplied blocks in the commonSuppressions list.
@param commonSuppressions list of block names which normal people don't want to hear complaints for.
@return string with merged blocks from file, or the input string if something is amiss.
"""

    source = Source.Source()
    if dbg:
        print "loading file " , srcName
    source.loadFile(srcName, sourceKey)

    spliceTo = getSourceString(targetName, targetKey, targetString, fatal)
        
    (status, result) = mergeSourceToString(spliceTo, source, targetName, insertFirst, dbg, verbose, 
                                           rejectSave, warn, fatal,  warnCommon, commonSuppressions, replaceIdentical=replaceIdentical)
    if status:
        return result
    else: 
        return targetString

# end mergeFileIntoString


def mergeFiles(targetName, srcName, targetKey="DO-NOT-DELETE splicer", sourceKey="DO-NOT-DELETE splicer" , 
               insertFirst=True, dbg=False , verbose=False, dryrun=False, rejectSave=True, warn=True, fatal=True,  
               warnCommon=False, commonSuppressions=[], matchSyms=[], excludeSyms=[], methodMatch=False, oldtype="", newtype="", replaceIdentical=True, killSubstrings=None, killBlockKeys=None ):
    """ merge, a function for merging two files, the splices from one into the other, overwriting the target file's blocks and leaving the rubble in a .rej
file.
The splice algorithm is:
	Load outputfile, inputFile
	Identify input sections matching sourceKey and extract symbols
		from sourcekey.begin(symbol)/sourcekey.end(symbol) pairs.
		Errors if sections are not well-formed.
	Warn about multiple matches in blocks/splices.
	Warn about non-matches.
	Foreach matching section:
		Scan for targetKey splice, and if present replace it.
		If not found, insert block or splice first or last as given.
                Before scanning target, delete lines in it per killSubstrings and
		killBlockKeys. Default lists are available in Kills.py.
	Write output file if not dryrun.
"""
    source = Source.Source()
    if dbg:
        print "loading file " , targetName
    source.loadFile(targetName, targetKey)

    spliceFrom = getSource(srcName, sourceKey)
        
    return mergeSources(source, spliceFrom, targetName, insertFirst, dbg,
                        verbose, dryrun, rejectSave, warn, 
                        fatal, warnCommon, commonSuppressions, 
                        methodMatch=methodMatch, oldtype=oldtype, newtype=newtype, 
                        matchSyms=matchSyms, excludeSyms=excludeSyms, replaceIdentical=replaceIdentical,
                        killSubstrings=killSubstrings, killBlockKeys=killBlockKeys)

# end mergeFiles

# might better have been called mergeStringIntoFile.
#
def mergeFromString(targetName, srcString, srcName, targetKey="DO-NOT-DELETE splicer", sourceKey="DO-NOT-DELETE splicer" , 
                    insertFirst=True, dbg=False , verbose=False, dryrun=False, rejectSave=True, warn=True, fatal=True,  warnCommon=False, 
                    commonSuppressions=[], methodMatch=False, oldtype="", newtype="", replaceIdentical=True ):
    """ a function for merging srcString into target file, overwriting or inserting to the target 
file's blocks and leaving the rubble in a .rej file.
The splice algorithm is as mergeFiles.
"""
    source = Source.Source()
    if dbg:
        print "loading file " , targetName
    source.loadFile(targetName, targetKey)

    spliceFrom = getSourceString(srcName, sourceKey, srcString, fatal)
        
    return mergeSources(source, spliceFrom, targetName, insertFirst, dbg, verbose, dryrun, rejectSave, warn, fatal,  
                        warnCommon, commonSuppressions, replaceIdentical=replaceIdentical)

# end mergeFromString


def mergeSources(source, spliceFrom, targetName, insertFirst=True, dbg=False , verbose=False, dryrun=False, rejectSave=True, 
                 warn=True, fatal=True, warnCommon=False, commonSuppressions=[], methodMatch=False, oldtype="", newtype="", 
                 matchSyms=[], excludeSyms=[], replaceIdentical=True, killSubstrings=None, killBlockKeys=None):
    """As mergeFiles, less the file-opening policies."""

    if verbose:
        print "processing insertions"
    symbols = source.getSymbols()
    result = 0

    insertions = {}
    spliceFrom.tagSymbols(1)
    findSplices( symbols, insertions, spliceFrom, verbose, methodMatch, oldtype, newtype, matchSyms, excludeSyms)
    # we can generate insertions in other ways; needn't be file readers.
    # see Source.loadList

    warnMissing(symbols, insertions, warn, warnCommon, commonSuppressions, False, matchSyms, excludeSyms)

    rejects=[]
    for first, second in insertions.iteritems():
        source.insert(first, second, insertFirst, rejects, verbose, replaceIdentical=replaceIdentical, killMatches=killSubstrings, killBlockKeys=killBlockKeys)
        second.setTag(0)
    
    warnExtra(warn, spliceFrom, matchSyms)

    if not source.write(outFileName=targetName, verbose=verbose, dryrun=dryrun, rejectSave=rejectSave, rejectLines=rejects):
        result = 1
    
    return result

# end mergeSources

def mergeSourceToString(source, spliceFrom, targetName, insertFirst=True, dbg=False , verbose=False, rejectSave=False, 
                        warn=True, fatal=True, warnCommon=False, commonSuppressions=[], replaceIdentical=False):
    """As mergeFiles, less the file-opening policies and the file writing policies.
@param source a Source object to be modified.
@param spliceFrom a Source object to be searched for splices to apply.
@param targetName name for error message and .rej file purposes of the string.
@param insertFirst append/prepend for nested blocks.
@return (status, string) a string of the resulting source if status true."""

    if verbose:
        print "processing insertions"
    symbols = source.getSymbols()

    insertions = {}
    spliceFrom.tagSymbols(1)
    findSplices( symbols, insertions, spliceFrom, verbose)

    warnMissing(symbols, insertions, warn, warnCommon, commonSuppressions, False)

    rejects=[]
    for first, second in insertions.iteritems():
        source.insert(first, second, insertFirst, rejects, verbose, replaceIdentical=replaceIdentical)
        second.setTag(0)
    
    warnExtra(warn, spliceFrom)

    return source.writeString(outFileName=targetName, verbose=verbose, rejectSave=rejectSave, rejectLines=rejects)

# end mergeSourceToString

def warnExtra(warn, src, matchSyms=[]):
    if warn:
        extras = src.getTaggedSymbols(1)
        for i in extras:
            if not Misc.symbolContainsListItem(i, matchSyms):
                continue
            warnMessage("Unused splice from input: "+i, False)

def renameInFiles(targetName, srcName, targetKey="DO-NOT-DELETE splicer", sourceKey="DO-NOT-DELETE splicer", 
                  insertFirst=True, dbg=False , verbose=False, dryrun=False, rejectSave=True, 
                  warn=True, fatal=True,  warnCommon=False, commonSuppressions=[], oldtype="", newtype="" ):
    """ rename, a function for overwriting the target file's blocks with a set of blocks from
the source file that should have a matching set of symbols differing by a prefix  (sidl class).
oldtype and newtype are fully qualified, not partial names.
The targetfile contains blocks (most probably unpopulated, and to be replaced) tagged
with symbols derived from newtype.
The source file contains blocks tagged with symbols derived from oldtype.
"""

    source = Source.Source()
    if dbg:
        print "loading file " , targetName
    source.loadFile(targetName, targetKey)
        
    if verbose:
        print "processing renames"
    symbols = source.getSymbols()
    result = 0

    insertions = {}
    spliceFrom = getSource(srcName, sourceKey, warn)
    findSplices( symbols, insertions, spliceFrom, verbose, True, oldtype, newtype)
    spliceFrom.tagSymbols(1)
    # we can generate insertions in other ways; needn't be file readers.
    # see Source.loadList

    warnMissing(symbols, insertions, warn, warnCommon, commonSuppressions, False)

    rejects=[]
    for first, second in insertions.iteritems():
        source.replace(first, second, rejects, verbose)
        second.setTag(0)
    
    warnExtra(warn, spliceFrom)

    if not source.write(outFileName=targetName, verbose=verbose, dryrun=dryrun, rejectSave=rejectSave, rejectLines=rejects):
        result = 1
    
    return result
# end renameInFiles

def renameFromFile(targetName, srcName, targetBuffer, targetKey="DO-NOT-DELETE splicer", sourceKey="DO-NOT-DELETE splicer", 
                   insertFirst=True, dbg=False , verbose=False, dryrun=False, rejectSave=True, 
                   warn=True, fatal=True,  warnCommon=False, commonSuppressions=[], oldtype="", newtype="" ):
    """  a function for creating the target file from a target buffer with blocks from
the source file that should have a matching set of symbols differing by a prefix  (sidl class).
oldtype and newtype are fully qualified, not partial names.
The targetBuffer contains blocks (most probably unpopulated, and to be replaced) tagged
with symbols derived from newtype.
The source file contains blocks tagged with symbols derived from oldtype.
"""

    if dbg:
        print "loading file " , targetName
    source = getSourceString(targetName, targetKey, targetBuffer)
        
    if verbose:
        print "processing renames"
    symbols = source.getSymbols()
    result = 0

    insertions = {}
    spliceFrom = getSource(srcName, sourceKey, warn)
    findSplices( symbols, insertions, spliceFrom, verbose, True, oldtype, newtype)
    spliceFrom.tagSymbols(1)
    # we can generate insertions in other ways; needn't be file readers.
    # see Source.loadList

    warnMissing(symbols, insertions, warn, warnCommon, commonSuppressions, False)

    rejects=[]
    for first, second in insertions.iteritems():
        source.replace(first, second, rejects, verbose)
        second.setTag(0)
    
    warnExtra(warn, spliceFrom)

    if not source.write(outFileName=targetName, verbose=verbose, dryrun=dryrun, rejectSave=rejectSave, rejectLines=rejects):
        result = 1
    
    return result
# end renameFromFile

def doBlockReplacements(targetName, replacementData, targetKey, sourceKey, methodMatch=False, oldtype="", newtype="", 
                        verbose=False, dryrun=False, rejectSave=True, insertFirst=True, dbg=False, warn=True, warnCommon=True, 
                        commonSuppressions=[]):
    """ Overwrite blocks with matching symbols in the target Source object.
replacementData is a multiline string.
If methodMatch is true, ignores, matches occurrences of 
symbol oldtype.$method to newtype.$method, for example in
renaming an impl from oldtype to newtype.
"""
    if dbg:
        print "loading file " , targetName
    source = getSource(targetName, targetKey, True)
        
    if verbose:
        print "processing insertions"
    symbols = source.getSymbols()
    result = 0

    insertions = {}
    spliceFrom = getSourceString("doBlockReplacements.spliceFrom", sourceKey, replacementData, True)
    findSplices( symbols, insertions, spliceFrom, verbose, methodMatch, oldtype, newtype)

    warnMissing(symbols, insertions, warn, warnCommon, commonSuppressions, False)

    rejects=[]
    for first, second in insertions.iteritems():
        source.insert(first, second, insertFirst, rejects, verbose)
    
    print targetName
    if not source.write(outFileName=targetName, verbose=verbose, dryrun=dryrun, rejectSave=rejectSave, rejectLines=rejects):
        result = 1
    
    return result

# doBlockReplacements


def doBlockInsertions(target, insertionData, insertFirst=True):
    """ Insert lines with matching symbols in the target Source object.
If insertFirst is true, existing code is prepended, else appended.
insertionData is a multiline string.
"""
    pass

if __name__ == "__main__":
    print >>sys.stderr, "Operations class has no main yet"
    sys.exit(1)
