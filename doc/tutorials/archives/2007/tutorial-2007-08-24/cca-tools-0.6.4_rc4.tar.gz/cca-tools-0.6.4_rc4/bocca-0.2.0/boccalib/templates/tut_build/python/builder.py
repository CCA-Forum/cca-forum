import os, re
import builders.builder as builderTemplate
from cct._err import *
from cct._file import *
from cct._debug import DEBUGSTREAM, WARN
from cct._util import fileManager, Globals
from cct.project import Project
from splicers.Operations import mergeFileIntoString

class Builder(builderTemplate.BuilderInterface):
    def __init__(self, modulePath, project):
        '''Constructor
        @param modulePath the directory containing the implementation of the BuilderInterface
        '''
        # The parent constructor sets the self.locationManager variable
        builderTemplate.BuilderInterface.__init__(self,modulePath, project)
        pass
   
    def update(self, buildFilesOnly=False, quiet=False):
        '''Given a new project graph, update build information. 
        @param buildFilesOnly: Only update files contaning component and port info.
        '''

        status = 0
        if self.changedList or buildFilesOnly:
            if not quiet: print "Please wait while the project build system is being updated..."
            # Update component and port list files
        
            # Update port information
            portMakeFile = os.path.join(self.project.getDir(), self.locationManager.getPortLoc()[0], 'ports.make')
            
            #for i in self.project.getVertexList(kinds=['port','interface']): print '\t' + str(i) 
            result = self._createPortsMakeString(self.project.getVertexList(kinds=['port','interface']))
            #print '\n\nports.make: \n' + result
            try:
                BFileManager().writeStringToFile(portMakeFile,result)
            except IOError,e:
                err('Could not write to file ' + portMakeFile + ': ' + str(e))
            #print >>DEBUGSTREAM, result
            
            # Update component information
            compMakeFile = os.path.join(self.project.getDir(), self.locationManager.getComponentLoc()[0], "components.make")
            
            result = self._createComponentsMakeString(self.project.getVertexList(kinds=["component"])) + '\n' + \
                 self._createComponentsMakeDependsString(self.project.getVertexList(kinds=["component"]))
            # TODO: Classes!
            # Merge the original file with the current project component info
            result = mergeFileIntoString(targetName=compMakeFile, 
                                     targetString=result,
                                     srcName=compMakeFile,
                                     targetKey="DO-NOT-DELETE bocca.splicer",
                                     sourceKey="DO-NOT-DELETE bocca.splicer",
                                     rejectSave=False,
                                     replaceIdentical=False,
                                     dbg=WARN,
                                     verbose=WARN,
                                     warn=WARN)
            try:
                BFileManager().writeStringToFile(compMakeFile,result)
            except IOError,e:
                err('Could not write to file ' + compMakeFile + ': ' + str(e))
                
        for vertex in self.changedList:
            status = self.genXML(vertex)
            if status != 0: err('Builder could not generate XML with Babel for ' + vertex.kind + ' ' + vertex.symbol)
            status = self.genImpls(vertex)
            if status != 0: err('Builder could not generate code with Babel for ' + vertex.kind + ' ' + vertex.symbol)
        
        self.changedList = []
        return status
    
    def genSIDL(self, vertex):
        return builderTemplate.BuilderInterface.genSIDL(self, vertex)

    def genXML(self, vertex):
        retcode = 0
        command = ''
        if vertex.kind in ['class', 'component']:
            print >> DEBUGSTREAM, "Builder chdir to: " + os.path.join(self.project.getAttr('projectDir'),self.locationManager.getComponentLoc()[0])
            os.chdir(os.path.join(self.project.getAttr('projectDir'),self.locationManager.getComponentLoc()[0]))
            try: fileManager.rm(os.path.join(vertex.symbol, '.repository'), trash = False, nobackup = True)
            except: pass
            command = 'make COMPONENT_TARGET=.repository QUIET=1 %s ' % (vertex.symbol) 
            print >> DEBUGSTREAM, "Builder executing ", command
        elif vertex.kind in ['interface', 'port']:
            if vertex.getAttr('removed'): return 0
            xmlfile = os.path.join('..', self.locationManager.getXMLLoc()[0], vertex.symbol + '-v' + vertex.version + '.xml')
            print >> DEBUGSTREAM, "Builder chdir to: " + os.path.join(self.project.getAttr('projectDir'),self.locationManager.getPortLoc()[0])
            os.chdir(os.path.join(self.project.getAttr('projectDir'),self.locationManager.getPortLoc()[0]))
            try: fileManager.rm('.repository', trash = False, nobackup = True)
            except: pass
            command = 'make .repository QUIET=1 SIDL_FILES=%s ' % (os.path.join(self.project.getDir(),vertex._b_sidlFile))
            print >> DEBUGSTREAM, "Builder executing ", command
        if command: retcode = os.system(command)
        return retcode


    def genImpls(self, vertex):
        retcode = 0
        command = ''
        if vertex.kind in ['class', 'component']:
            #print >> DEBUGSTREAM, "Builder chdir to: " + os.path.join(self.project.getAttr('projectDir'),self.locationManager.getComponentLoc()[0])
            #os.chdir(os.path.join(self.project.getAttr('projectDir'),self.locationManager.getComponentLoc()[0]))
            #try: fileManager.rm(os.path.join(vertex.symbol, '.gencode'), trash = False, nobackup = True)
            #except: pass
            #command = 'make QUIET=1 COMPONENT_TARGET=.gencode %s ' % (vertex.symbol)
            #print >> DEBUGSTREAM, "Builder executing ", command
            self._genClassImpl(vertex)
        elif vertex.kind in ['interface', 'port']:
            if vertex.getAttr('removed'): return 0
            xmlfile = os.path.join('..', self.locationManager.getXMLLoc()[0], vertex.symbol + '-v' + vertex.version + '.xml')
            print >> DEBUGSTREAM, "Builder chdir to: " + os.path.join(self.project.getAttr('projectDir'),self.locationManager.getPortLoc()[0])
            os.chdir(os.path.join(self.project.getAttr('projectDir'),self.locationManager.getPortLoc()[0]))
            try: fileManager.rm('.' + vertex.symbol, trash = False, nobackup = True)
            except: pass
            command = 'make %s QUIET=1 ' % ('.' + vertex.symbol)
            print >> DEBUGSTREAM, "Builder executing ", command
        if command: retcode = os.system(command)
        return retcode


    def genObjects(self, vertex):
        return builderTemplate.BuilderInterface.genObjects(self, vertex)


    def genLibs(self, vertexList):
        return builderTemplate.BuilderInterface.genLibs(self, vertexList)


    def genTests(self, vertexList):
        return builderTemplate.BuilderInterface.genTests(self, vertexList)

    def changed(self, vertexList):
        '''This is how the builder is notified of changes to a list of vertices.
        The build system will perform whatever actions are necessary on these
        vertices during a subsequent update call.
        '''
        self.changedList.extend(vertexList)
        return self.changedList
    
    def remove(self, vertexList):
        ''' Removes build-relevant information associated with vertices in vertexList.
        Returns 0 upon success, 1 otherwise.
        '''
        import glob
        xmldir = self.locationManager.getXMLLoc()[0]
        for vertex in vertexList:
            print >>DEBUGSTREAM, 'removing build system artifacts for ' + vertex.symbol
            projectDir = self.project.getAttr('projectDir')
            if vertex.kind in ['interface','port']:
                mydir = os.path.join(projectDir,self.locationManager.getPortLoc()[0])   
                try: 
                    fileManager.rm(os.path.join(mydir,'.' + vertex.symbol), trash=False, nobackup=True)
                    os.system('touch ' + os.path.join(mydir,'.repository'))
                except: 
                    pass
                libs = glob.glob(os.path.join(mydir, 'lib', 'lib' + vertex.symbol + 'Port-*.la'))
                libs += glob.glob(os.path.join(mydir, 'lib', '*', 'lib' + vertex.symbol + 'Port-*.*'))
                for lib in libs:
                    try: fileManager.rmdir(lib,trash=False,nobackup=True)
                    except: pass
            elif vertex.kind in ['class','component']:
                mydir = os.path.join(projectDir,self.locationManager.getComponentLoc()[0])
                libs = glob.glob(os.path.join(mydir, 'lib', 'lib' + vertex.symbol + '.*'))
                for lib in libs:
                    try: fileManager.rmdir(lib,trash=False,nobackup=True)
                    except: pass
            else: return 0
            
            
            xmlfiles = os.path.join(projectDir,xmldir,vertex.symbol + '*-v' + vertex.version + '.xml')
            xmlfiles = glob.glob(xmlfiles)
            for xmlfile in xmlfiles:
                try: fileManager.rm(xmlfile,trash=False,nobackup=True)
                except: pass
            try: fileManager.rmdir(os.path.join(mydir,vertex.symbol),trash=True)
            except: pass
        return 0
    

    def install(self, vertex=None):
        return builderTemplate.BuilderInterface.install(self, vertex)

#-------- Private methods

    def _createComponentsMakeString(self, vertexlist):
        locManager = self.project.getLocationManager()
        result = '# DO-NOT-DELETE bocca.splicer.begin(components)\n\n'
        result += '# DO-NOT-DELETE bocca.splicer.end(components)\n\n'        
        for vertex in vertexlist:
            libname = locManager.getBuildLibs(vertex,vertex._b_language)[0]
            result += 'COMPONENTS \t\t+= ' + vertex.symbol+'-'+vertex._b_language + '\n'
        result += '\n'
        return result
    
    def _createComponentsMakeDependsString(self, vertexlist):
        # Dependencies on sidl within this project (TODO: dependencies on other things)
        result = ''
        for vertex in vertexlist:
            deps = ''
            mysidl = os.path.join('$(PROJECT_TOP_DIR)',vertex._b_sidlFile)   
            for v in vertex.dependencies():
                if v.kind not in ['port', 'interface', 'component', 'class']: continue
                if vertex.symbol.startswith('sidl.') or vertex.symbol.startswith('gov.cca.') or vertex.symbol.startswith('ccaffeine.'): continue
                deps += ' ' + os.path.join('$(PROJECT_TOP_DIR)', v._b_sidlFile)
            if deps: result += 'PORT_SIDL_' + vertex.symbol + ' = ' + deps + '\n'
        return result

    def _createPortsMakeString(self, vertexlist):
        xmldir = self.locationManager.getXMLLoc()[0]
        result = ''     
        portsdir = self.locationManager.getPortLoc()[0] + os.sep
        for vertex in vertexlist:
            if vertex.getAttr('removed'): continue
            if vertex.symbol.startswith('sidl.') or vertex.symbol.startswith('gov.cca.') or vertex.symbol.startswith('ccaffeine.'): continue
            if vertex.kind == 'port':
                result += 'PORTS \t\t+= ' + vertex.symbol+'\n'
            else:
                result += 'INTERFACES \t+= ' + vertex.symbol +'\n'
            result += 'SIDLFILES \t+= ' + os.path.join('$(PROJECT_TOP_DIR)',vertex._b_sidlFile) + '\n'
            xmlfile = os.path.join('..',xmldir, vertex.symbol + '-v' + vertex.version + '.xml')
            result += 'XMLFILES \t+= ' + xmlfile + '\n'
            
            # Now do dependencies on other interfaces/ports

            for lang in self.locationManager.getLanguages():
                deps = ''
                for v in vertex.dependencies():
                    if v.kind not in ['port','interface']: continue
                    if v.symbol.startswith('sidl.') or v.symbol.startswith('gov.cca.') or v.symbol.startswith('ccaffeine.'): continue
                    deps += ' ' + self.locationManager.getBuildLibs(v,lang=lang)[0].lstrip(portsdir)                
                if deps:
                    mylib = self.locationManager.getBuildLibs(vertex,lang=lang)[0].lstrip(portsdir)
                    result += mylib + ' : ' + deps + '\n'

        return result    
    
    def _getSources(self, vertex):
        sources = '$(IORSRCS) $(IMPLSRCS) $(STUBSRCS) $(SKELSRCS) '
        if vertex._b_language is 'f90':
            sources += '$(ARRAYMODULESRCS) $(IMPLMODULESRCS) $(TYPEMODULESRCS) $(STUBMODULESRCS)'
        return sources
    
    def _genClassImpl(self, vertex):
        import glob
        if vertex.kind not in ['class', 'component']: return 0
        ccaVars = Globals().getCCAVars(projectName = vertex.projectName)
        if len(ccaVars) == 0:
            err('[sidlclass] could not load CCA settings from defaults file')

        cca_repo = '-R' + ccaVars['CCASPEC_BABEL_XML_REPOSITORY']
        if (len(vertex._b_xmlRepos) > 0):
            otherRepos = ' -R'.join([' '] + vertex._b_xmlRepos)
        else:
            otherRepos = ''
        
        if (len(vertex._b_externalSidlFiles) > 0):
            otherSidlInclude = ' -I'.join([' '] + vertex._b_externalSidlFiles)
        else:
            otherSidlInclude = ''
        
        sidlIncludes = ''
        for v in vertex.dependencies():
            if v.kind not in ['port', 'interface', 'component','class']: continue
            if not v._b_sidlFile.startswith(os.sep):
                sidlIncludes += ' -I' + os.path.join(self.project.getDir(), v._b_sidlFile)
            else:
                sidlIncludes += ' -I' + v._b_sidlFile
	print >>DEBUGSTREAM, 'SIDL files this class depends on: ' + str(sidlIncludes)
        
        babelcmd = '%s -p %s %s %s %s %s' % (ccaVars['CCASPEC_BABEL_BABEL'], \
                   otherSidlInclude, sidlIncludes, cca_repo, otherRepos,
                   os.path.join(self.project.getDir(), vertex._b_sidlFile))

        print >> DEBUGSTREAM, 'Builder executing ' + babelcmd
        retcode = os.system(babelcmd)
        
        if (retcode != 0):
            err('Error validating component symbol, check output from call to babel for clues', 4)
            
# Generate Impl files
        bebelOptions = '-s %s -u -m .%s. -o %s' % \
               (vertex._b_language, vertex.symbol, os.path.join(vertex._b_projectDir, 'components',  
                                                              vertex.symbol))
        babelcmd = '%s %s %s %s %s %s %s' % (ccaVars['CCASPEC_BABEL_BABEL'], bebelOptions, 
                         otherSidlInclude, sidlIncludes,
                         cca_repo, otherRepos,  os.path.join(vertex._b_projectDir, vertex._b_sidlFile))
        print >> DEBUGSTREAM, 'Builder executing: ' + babelcmd
        retcode = os.system(babelcmd)
        if (retcode != 0):
            err('Error generating component Impl files, check output from call to babel for clues', 4) 
        return 0
