# Code taken from optik (optparse) example
# "Required options" with optparse, version 2:
# extend Option and add a 'required' attribute;
# extend OptionParser to ensure that required options
# are present after parsing.

import optparse, re

class Option (optparse.Option):
    ATTRS = optparse.Option.ATTRS + ['required']

    def _check_required (self):
        if self.required and not self.takes_value():
            raise OptionError(
                "required flag set for option that doesn't take a value",
                 self)

    # Make sure _check_required() is called from the constructor!
    CHECK_METHODS = optparse.Option.CHECK_METHODS + [_check_required]

    def process (self, opt, value, values, parser):
        optparse.Option.process(self, opt, value, values, parser)
        parser.option_seen[self] = 1


class OptionParser (optparse.OptionParser):



    def _init_parsing_state (self):
        optparse.OptionParser._init_parsing_state(self)
        self.option_seen = {}

    def check_values (self, values, args):
        for option in self.option_list:
            if (isinstance(option, Option) and
                option.required and
                not self.option_seen.has_key(option)):
                self.error("%s not supplied" % option)
        return (values, args)
    
    def add_option(self, *args, **keywords):
        if (len(args) == 1 and str(args[0].__class__).endswith('Option')):
            o = args[0]
        else:
            o = Option(*args, **keywords)
        return optparse.OptionParser.add_option(self, o)

    def parse_args(self, args=None, values=None):
        newargs = []
        for arg in args:
            if len(arg) > 2 and (arg[0] == '-' and arg[2] == '='):
                newarg = arg[:2] + arg[3:] 
            else:
                newarg = arg
            newargs.append(newarg) 
        return optparse.OptionParser.parse_args(self, newargs, values)


if __name__ == '__main__':
    parser = OptionParser(option_list=[
       Option("-v", action="count", dest="verbose"),
       Option("-f", "--file", required=1)])
    parser.add_option("-k", "--WAWAWA", required=1)
    (options, args) = parser.parse_args()

    print "verbose:", options.verbose
    print "file:", options.file

