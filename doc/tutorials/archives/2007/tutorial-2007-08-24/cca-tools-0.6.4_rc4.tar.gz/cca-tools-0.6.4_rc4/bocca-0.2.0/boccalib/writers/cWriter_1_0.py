from writers.cWriter import CWriter

def getWriterParameters():
    return (CWriter_1_0.language, CWriter_1_0.babelVersions)
 
class CWriter_1_0(CWriter):
    language = 'c'
    babelVersions = ['1.0.X']

    def __init__(self):
        pass
    
    def getImplHeaderCode(self, componentSymbol):
        return ''
        
    def getAuxiliarySetServicesMethod(self, componentSymbol, provideDict={}, useDict={}):
        cmpt_ubar = componentSymbol.replace('.', '_')
        methodName = 'impl_' + cmpt_ubar + '_boccaSetServices' 
        buf = """
/* DO-NOT-DELETE splicer.begin(@CMPT_TYPE@._includes) */

/* Insert-Code-Here {@CMPT_TYPE@._includes} (includes and arbitrary code) */
/* Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:_includes) */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void
@METHOD_NAME@(
  /* in */ @CMPT_TYPE_UBAR@ self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

/* Bocca generated code. bocca.protected.end(@CMPT_TYPE@:_includes) */
        
/* Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:boccaSetServices) */
void @METHOD_NAME@(
  /* in */ @CMPT_TYPE_UBAR@ self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex)
{

   struct @CMPT_TYPE_UBAR@__data *pd;

   sidl_BaseInterface throwaway_excpt = NULL;
"""
# Add ports declarations (if needed)
        if (len(provideDict) + len(useDict) > 0):
            buf += """
   gov_cca_TypeMap typeMap = NULL;
   gov_cca_Port port = NULL;
"""
# Component Registration code            
        buf +="""
   pd = @CMPT_TYPE_UBAR@__get_data(self);

   pd->"""+self.servicesVariable+""" = services;

   gov_cca_Services_addRef(services, &throwaway_excpt);
"""
        if (len(provideDict) + len(useDict) > 0):
            buf += """
  /* Create a typemap  */
   typeMap = gov_cca_Services_createTypeMap(pd->"""+self.servicesVariable+""", &throwaway_excpt);
   if (SIDL_CATCH(throwaway_excpt, "gov.cca.CCAException")) {
      fprintf(stderr, "Exception:: %s:%d: gov::cca::TypeMap was not created\\n",
          __FILE__, __LINE__);
      SIDL_CLEAR(throwaway_excpt);
      exit(1);
   }
"""
            if (len(provideDict) > 0):
                buf +="""
  /* Cast myself to gov.cca.Port */
   port = gov_cca_Port__cast(self, &throwaway_excpt);
   if (port == NULL) {
      fprintf(stderr, "Error:: %s:%d: Error casting self to gov::cca::Port \\n",
        __FILE__, __LINE__);
      exit(1);
   } 
"""
# Provide port(s) code
            for pName in provideDict.keys():
                portBuf = """
   /* Provide a @PORT_TYPE@ port with port name @PORT_INSTANCE@ */
   gov_cca_Services_addProvidesPort(pd->"""+self.servicesVariable+""",   
                       port,
                       "@PORT_INSTANCE@",
                       "@PORT_TYPE@",
                       typeMap,
                       &throwaway_excpt);
   if (SIDL_CATCH(throwaway_excpt, "gov.cca.CCAException")) {
      fprintf(stderr, "Exception:: %s:%d: Could not register @PORT_TYPE@:@PORT_INSTANCE@ provides port\\n",
         __FILE__, __LINE__);
      SIDL_CLEAR(throwaway_excpt);
      exit(1);
   }
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                                  replace('@PORT_TYPE@', provideDict[pName])
                buf += portBuf
            
# Use port(s) code
            for pName in useDict.keys():
                portBuf = """
  /* Register a use port of type @PORT_TYPE@ with port name @PORT_INSTANCE@ */  
   gov_cca_Services_registerUsesPort(pd->"""+self.servicesVariable+""",   
                   "@PORT_INSTANCE@",
                   "@PORT_TYPE@",
                   typeMap,
                   &throwaway_excpt);
   if (SIDL_CATCH(throwaway_excpt, "gov.cca.CCAException")) {
      fprintf(stderr, "Exception:: %s:%d: Could not register @PORT_TYPE@:@PORT_INSTANCE@ uses port\\n",
         __FILE__, __LINE__);
      SIDL_CLEAR(throwaway_excpt);
      exit(1);
   }
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                              replace('@PORT_TYPE@', useDict[pName])
                buf += portBuf
            buf += """
"""   
# Finish up, and replace vars

        buf +="""
   return;
}
// Bocca generated code. bocca.protected.end(@CMPT_TYPE@:boccaSetServices)
        
/* DO-NOT-DELETE splicer.end(@CMPT_TYPE@._includes) */
"""
        buf = buf.replace('@CMPT_TYPE_UBAR@', cmpt_ubar).\
                  replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@METHOD_NAME@', methodName)
        return buf
