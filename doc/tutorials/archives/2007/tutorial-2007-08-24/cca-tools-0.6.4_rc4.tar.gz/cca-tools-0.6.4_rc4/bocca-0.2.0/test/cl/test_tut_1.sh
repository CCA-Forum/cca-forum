#!/bin/sh
# test tutorial transfer old to new literal version
# CCA_TUTORIAL_ROOT needs to point to a directory containing
#  misc-handouts  ppt-template  src           for the tutorial
# and BOCCA needs to point to the bocca executable if not in 
# path by default.
# it's likely the makfile doesn't report error correctly on this one.
echo "PASS This test is no longer relevant. It does nothing."
if test "x$CCA_TUTORIAL_ROOT" = "x"; then
  echo "XFAIL: no CCA_TUTORIAL_ROOT defined."
  exit 1
fi
cd $2
if ! test $? ; then
	echo "changing to scratch directory $2 failed"	
	echo "BROKEN"
	exit 1
fi
TDIR=tut1
rm -rf $TDIR
mkdir $TDIR
cd $TDIR
if ! test $? ; then
	echo "changing to scratch directory $TDIR failed"	
	echo "BROKEN"
	exit 1
fi

export BOCCA=$1
export TUTORIAL_HOME=$CCA_TUTORIAL_ROOT
msg=`$CCA_TUTORIAL_ROOT/hands-on/bocca/do-bocca-hog-baa cxx`
echo "PENDING"
exit 1
# put tests here.
if ! test -d "src-bocca"; then
	echo "missing src-bocca"
	echo "FAIL"
	exit 1
fi
cd src-bocca
make
x=$?
if ! test "x$x" = "x0"; then
	echo "make failed for tutorial"
	echo "FAIL"
	out=1
fi
if test "x$out" = "x0"; then
	echo "PASS"
fi
exit $out
