#!/bin/sh
# test --go on component
cd $2
if ! test $? ; then
	echo "changing to scratch directory $2 failed"	
	echo "BROKEN"
	exit 1
fi
rm -rf gp1
mkdir gp1
cd gp1

echo "creating project"
msg=`$1 create project myproj`
if ! test -d "$2/gp1/myproj/.bocca"; then
	echo "missing myproj/.bocca"
	echo "FAIL"
	exit 1
fi
cd myproj

echo "creating port"
msg=`$1 create port myproj.IntegratorPort`
if ! test -f ports/sidl/myproj.IntegratorPort.sidl; then
	echo "missing myproj/ports/sidl/myproj.IntegratorPort.sidl"
	echo "FAIL"
	exit 1
fi
make
echo "TRYING"
echo "$1 create component Driver --provides=myproj.IntegratorPort:myfoo --uses=myproj.IntegratorPort:integrate"
$1 create component Driver --provides=myproj.IntegratorPort:myfoo --uses=myproj.IntegratorPort:integrate --go=run
if ! test -f components/sidl/myproj.Driver.sidl; then
	echo "missing components/sidl/myproj.Driver.sidl"
	echo "FAIL"
	exit 1
fi
echo "COMPILING Component"
make 
x=$?
if  test "x$x" = "x0" ; then
	echo "problem compiling "
	echo "FAIL"
	exit 1
fi
echo "CHECKING Component"
make check
x=$?
if test "x$x" = "x0" ; then
	echo "PASS"
else
	echo "problem with make check"
	echo "FAIL"
	exit 1
fi
exit 0
