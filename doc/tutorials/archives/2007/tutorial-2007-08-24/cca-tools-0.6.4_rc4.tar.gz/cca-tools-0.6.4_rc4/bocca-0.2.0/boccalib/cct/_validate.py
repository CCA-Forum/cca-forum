""" A file full of misc checking routines.
Typically each returns a status (0=ok) and a string or object.
"""
from cct._err import *

def language(n):
    """returns (int status, string canonicalLanguageName)
"""
#    validlangs = ['c', 'cxx', 'f77', 'f90', 'java', 'python']
    validlangs = ['c', 'cxx', 'f77', 'f90', 'python']
    if n in validlangs:
        return (0,n)
    if n in ['C', 'cc']:
        return (0,'c')
    if n in ['c++', 'C++', 'CXX', 'cpp']:
        return (0,'cxx')
# TODO: Java not supported by bocca yet
#    if n in ['Java', 'JAVA', 'jdk', 'JDK']:
#        return (0,'java')
    if n in ['Python', 'PYTHON']:
        return (0,'python')
    if n in ['fortran77', 'F77']:
        return (0,'f77')
    if n in ['fortran90', 'F90', 'FORTRAN']:
        return (0,'f90')
    err(str(n) + " is an unknown Bocca language. Valid languages are " + ', '.join(validlangs) + '.' )

def sidlType(symbol, defaultPackage, kind='any', graph=None, sidlFile=None):
    '''Returns (int status, string fullyQualifiedType).
    Checks whether specified type is in this project and if not, 
    returns the fully qualified symbol using the default package.'''
    status = 0
    fqsymbol = symbol
    if symbol.count('.') == 0:
        # Short type specified
        #warn('Adding non-fully qualified ' + symbol + ' to package ' + defaultPackage + '.')
        status = 1
        fqsymbol = defaultPackage + '.' + symbol
    # TODO: move the filename checks here, too.
    return (status,fqsymbol)
    