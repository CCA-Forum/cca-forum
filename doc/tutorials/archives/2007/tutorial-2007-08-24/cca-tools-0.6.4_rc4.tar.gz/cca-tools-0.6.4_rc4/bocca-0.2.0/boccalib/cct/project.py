""" This script handles project functions, such as creation,
removal, renaming, and other project-wide modifications.
This script must not be called directly from a command line; it
must be dispatched through dispatcher.py
bocca help project for usage.
"""

import os, sys, stat, shutil
from parse.boccaParse import OptionParser
from ConfigParser import ConfigParser

import cct._validate
from cct._debug import DEBUGSTREAM
from cct._util import *
from cct._err import err
from graph.boccagraph import *
import builders

class Project(BVertex):
    '''bocca <verb> project [options] [arguments]
    
    Perform the action specified by <verb> on the project. Example verbs include
    create, remove, rename, display. For a complete list of verbs, see
    bocca help.
    '''
    def __init__(self, action = '__init__', args = None, project = None, modulePath = None,
                 symbol=None, version='0.0', graph=None):
        '''bocca <verb> project [options] [arguments]
        
        <verb> is one of create, change, remove, rename, display. For documentation on
        specific verbs, use 'bocca help <verb> project'
        '''
        # The self.defaults variable stores default values read from BOCCA/projName.defaults
        self.defaults = None
	self.projectName = symbol
        BVertex.__init__(self, action= action, 
                         args = args, 
                         modulePath = modulePath, 
                         project = project,
                         kind = 'project',
                         symbol = symbol,
                         version = version,
                         graph = graph)
        self.setAttr('projectDir',None)
        self.setAttr('defaultPackage',None)
        self.newname = None
        self.builder = None
        self.locationManager = None
        return
    

    def serialize(self, filedesc):
        '''Writes a complete ASCII representation of current object which 
        can be used to reconstruct the object by calling deserialize.'''
        #TODO
        return

    def deserialize(self, sstr):
        '''Returns an instance of a CCAProject configured with
        the information resulting from deserializing the sstr string.'''
        #TODO
        return
    
    def defineArgs(self,action):
        '''Defines command line options and defaults for this command. This is 
        invoked in the constructor of the parent class Subcommand.
        '''
        BVertex.defineArgs(self,action)
        if action == 'create':
            self.parser.set_defaults(language='cxx', 
                                     clonelib=True, outdir=".", 
                                     package="_unset", maketemplate="tut_build")

            self.parser.add_option("-o", "--output-dir", dest="outdir", 
                                   help="directory in which to create the new project [default is .]")

            self.parser.add_option("-p", "--package", dest="package", 
                                   help="package name [default is to use the project name as the package]")

            self.parser.add_option("-l", "--language", dest="language", 
                                   help="default language for project impls unless overridden [default is cxx]")

            self.parser.add_option("-m", "--make-template", dest="maketemplate", 
                                   help="project build system template to use [default is make-tut-0.5]")
        #elif action == 'change':
        elif action == 'display':
            pass
        #elif action == 'remove':
        elif action == 'rename':
            pass
        elif action == 'save':
            pass
        else:
            err('Project verb "' + action + '" NOT implemented yet.', 3)

        return

    #------------------------------------------------
    def processArgs(self, action):
        """ Validates and if necessary canonicalizes the command line arguments for
        this subject, which are parsed into self.options.
        Exits nonzero if user gives bad input.
        """
        BVertex.processArgs(self,action)
        if action == 'create':
            if len(self.args) < 1:
                self.usage(exitcode=2,errmsg='[create project]: A project name is required for create project\nbocca help create project')
            
            self.symbol = self.args[-1]  # project name
            self.projectName = self.symbol
            if self.options.package == "_unset":
                self.options.package = self.args[0].replace('-','').replace('_','')
                
            status, self.options.language = cct._validate.language(self.options.language)
            if status:
                self.usage()
        elif action == 'rename':
            if len(self.args) != 1:
                self.usage(exitcode=2,errmsg='[rename project] the new project name was not specified')
            self.newname = self.args[0]
        elif action == 'display':
            if len(self.args) > 0 and self.symbol is None:
                self.symbol = self.args[-1]   # project name
            elif self.projectName is not None:
                self.symbol = self.projectName # which is set earlier in the BVertex constructor
        elif action == 'save':
            pass
        return
        
    #------------------------------------------------
    def create(self):
        """create project [options] projectName

        Creates a project with the specified name.
        """

        print >> DEBUGSTREAM, "Project.create called with options ", str(self.options) , " leaving args " , str(self.args)
    
        projectName = self.symbol
        

        # In init only, get the configuration from the template directory, for
        # all other subjects, the project's copy will be used
        templateConfigFile = os.path.abspath(os.path.join(self.modulePath, 'templates', 'project.defaults'))
        self.defaults = ConfigParser()
        self.defaults.readfp(open(templateConfigFile,'r'))
        
# TODO: document (non-standard) exit codes for Bocca

        # Check if outdir exists and is writable, if not create it.
        if os.path.exists(self.options.outdir):
            mode = os.stat(self.options.outdir)[stat.ST_MODE] 
            if stat.S_ISDIR(mode):
                if not bool(mode & stat.S_IWRITE):
                    err('[create project]: specified output directory name, ' + self.options.outdir + ', is not writable.')
            else:
                err('[create project]: specified output directory name, ' + self.options.outdir + ', is not a directory.')
     
        projectDir = os.path.abspath(os.path.join(self.options.outdir,projectName))
        fileManager.setProjectName(projectName)
        fileManager.setProjectDir(projectDir)
        
        # Check if proj already exists in outdir and exit w/error if so, otherwise create it
        if os.path.exists(projectDir):
            err('[create project]: cannot create project in ' + projectDir + ': path already exists.',2)
            
        self.setAttr('projectDir',projectDir)
        
        # The following doesn't create outdir if it already exists, only projectDir.
        # It does create a .bocca subdirectory in the outdir above projectDir.
        dirToAdd = os.path.abspath(os.path.join(os.getcwd(),self.options.outdir))
        try: 
            if not os.path.exists(dirToAdd): os.mkdir(dirToAdd)
        except: print >>DEBUGSTREAM, '[create project] specified output directory ', dirToAdd, ' already exists (that''ok)'
        
        print >> DEBUGSTREAM, '[create project] creating project in directory ', projectDir
    
        # Create project directory
        try:
            fileManager.mkdir(projectDir)
        except IOError,e:
            err('could not create project directory ' + projectDir + ': ' + str(e))

        # Copy directory structure (build) template to new project
        templateDir = os.path.join(self.modulePath, 'templates', self.options.maketemplate)
        os.path.walk(templateDir,_copyBuildTemplateFunc,arg={'projectDir':projectDir,'templateDir':templateDir,
                                                             'skip':['python']})
        # Load the build template python module and instantiate the builder and location manager classes
        self.loadBuildTemplate(os.path.join('templates', self.options.maketemplate))
        print >>DEBUGSTREAM, '[create project] loaded the build template from ', templateDir
               
        # Set PROJECT_TOP_DIR in project.make file
        try: os.system("sed -i1 -e 's|@PROJECT_TOP_DIR@|" + projectDir + "|' " + os.path.join(projectDir,'project.make'))
        except: pass 
        try: os.unlink(os.path.join(projectDir,'project.make1'))
        except: pass
        
        # 1) Create visible BOCCA directories for project metadata that would normally 
        # be under revision control.         
        # 2) Create hidden metadata directories (.bocca) whose contents would
        # normally *not* be under revision control
        addProjectMetadirs(projectName,topDir=projectDir,rootDir=projectDir)
        self.setAttr('parentDir',os.path.abspath(os.path.join(projectDir,'..')))
        
        # Put the bocca configuration file in the top-level BOCCA subdir
        defaultsFile = os.path.join('BOCCA',projectName + '.defaults')
        projectConfigFile = os.path.abspath(os.path.join(projectDir,defaultsFile))
        self.setAttr('defaultsFile', defaultsFile)
        try: 
            fileManager.copyfile(templateConfigFile,projectConfigFile)
        except IOError,e: 
            err('could not create project configuration file ' + projectConfigFile + ': ' + str(e))
        
        # Load the defaults file and set the default language for the project
        if projectConfigFile is not None and os.path.exists(projectConfigFile):
             configfp = open(projectConfigFile,'r')
             if configfp is not None: 
                     self.defaults.readfp(configfp)
                     configfp.close()
        self.defaults.set('Babel','default_language',self.options.language)
        self.defaults.write(fileManager.open(projectConfigFile,'w'))
        self.setDefaultLanguage(self.options.language)
        
        # Create project graph and add self to it
        graph = BGraph(name = projectName, path = projectDir, modulePath = self.modulePath)
        graph.add_v(self)
        print >> DEBUGSTREAM, '[create project] Project graph created successfully'
        globals = Globals()
        print >> DEBUGSTREAM, '[create project] Globals created'
        globals.graphs[self.symbol] = graph
        globals.projects[self.symbol] = self
   
        self.addNestedPackages(self.options.package)
        print >> DEBUGSTREAM, '[create project] Added packages successfully: ', self.options.package
        self.setAttr('defaultPackage', self.options.package)
          
        # Pickle project graph in default location, i.e., projectDir/.bocca/projectName.pickle
        # This is only necessary in the project create method, all other commands don't need 
        # to save the graph explicitly since it's done in the dispatcher upon successful command completion.
        graph.save()
        
        print >> DEBUGSTREAM, '[craete project] graph name = ', graph.name, ', path=', graph.path, ', contents:', graph
        print 'The project was created successfully in ' + projectDir
        return 0

    def change(self):
        """change project [options] projectName

        """

        return 1
    
    def remove(self):
        """remove project [options] projectName

        """

        return 1
    
    def rename(self):
        """rename project [options] newProjectName
    
        Renames the project in the current directory. If multiple 
        projects are present in the same directory, use 
           'bocca -p <projName> rename project <newProjectName>' 
        to disambiguate.
        """
        
        if self.newname is None:
            self.usage(2,"[rename project] the new project name was not specified.")
            
        project,pgraph = Globals().getProjectAndGraph(self.projectName)
        # Save the old name
        if not self.options.force:
            # Ask for confirmation
            response = raw_input('Are you sure you want to change the name of this project "' + self.symbol + '" to "' + self.newname + '" (y/n) ? [n] ')
            if not str(response).lower() in ['yes', 'y']:
                return 0
        # Now change the name in the various files that refer to it
        # First, save current path
        curdir = os.path.realpath(os.path.curdir).replace(self.symbol,self.newname)
        oldProjectDir = self.getAttr('projectDir')
        oldProjectName = self.symbol
        projectParentDir = self.getAttr('parentDir')
        projectDir = os.path.join(projectParentDir,self.newname)
                        
        # Remove metafiles
        removeProjectMetafiles(self.symbol,topDir=oldProjectDir,rootDir=oldProjectDir)
        
        # Rename the project defaults file
        try:
            oldProjDefaults = os.path.join(oldProjectDir,'BOCCA',oldProjectName+'.defaults')
            newProjDefaults = os.path.join(oldProjectDir,'BOCCA', self.newname+'.defaults')
            fileManager.rename(oldProjDefaults, newProjDefaults)
            self.setAttr('defaultsFile', os.path.join(projectDir, 'BOCCA', self.newname + '.defaults'))
        except IOError,e:
            err('could not rename project defaults file ' + oldProjDefaults + ': ' + str(e))        
        
        # Remove pickle file if any
        try:
            fileManager.rm(os.path.join(oldProjectDir,'.bocca', oldProjectName+'.pickle'))
        except IOError,e:
            warn('could not remove pickle file for project ' + oldProjectName + ': ' + str(e))
        # Remove ASCII serialization file if any
        try:
            fileManager.rm(os.path.join(oldProjectDir,'BOCCA', oldProjectName+'.ascii'))
        except IOError,e:
            warn('could not remove ASCII serialization file for project ' + oldProjectName + ': ' + str(e))

        self.setAttr('oldName', self.symbol)
        pgraph.renameVertex(self,self.newname)
        
        slist = pgraph.findSymbol(self.newname,kind='package')
        if len(slist) == 0: self.addNestedPackages(self.newname,g=pgraph)
            
        # Change default package name to match new project name
        self.setAttr('defaultPackage', self.newname)

        # Rename top-level directory
        os.chdir(projectParentDir)
        print >>DEBUGSTREAM, 'Changed working directory to ' + projectParentDir
        
        if os.path.exists(projectDir):
            err('could not rename project, directory exists: ' + projectDir)
        try:
            # TODO: need to make this undoable, too
            shutil.move(oldProjectDir,projectDir)
        except OSError,e:
            err('could not rename the top-level project directory: ' + str(e))
        fileManager.setProjectDir(os.path.join(projectParentDir,self.newname))
                                  
        # Go back to the same relative location in the new project directory
        os.chdir(curdir)
        print >>DEBUGSTREAM, 'Changed working directory to ' + curdir

        # Add new metafiles
        self.setAttr('projectDir', projectDir)
        addProjectMetadirs(self.symbol,topDir=projectDir,rootDir=projectDir)
            
        # Change the name of this graph and save it
        pgraph.name = self.newname
        pgraph.path = projectDir
        pgraph.save()
        project,graph = Globals().renameProject(oldProjectName,self.symbol)   
        return 0
    
    def display(self):
        """display project [projectName]
        
        """
        if not validSubdir(self.symbol,os.path.abspath(os.getcwd())):
            err('Specified project, ' + self.symbol + ', not found in this directory.')
        print >>DEBUGSTREAM,'Loaded project', self.symbol, 'in directory', self.getAttr('projectDir')
        pgraph = Globals().getGraph(self.symbol)
        print 'Project', self.symbol, self.data, ':', pgraph
        
        # Dot file:
        pgraph.saveGraphvizFile()
        #r = addSubdir(name,'boyana')
        #print 'Is components subdir valid? ', validSubdir(name,'components')
        #print 'Is boyana subdir valid? ', validSubdir(p,'boyana')
        #print 'Is invaliddir subdir valid? ', validSubdir(p,'invaliddir')

        return 0

    def save(self):
        ''' Save the project state in a portable ASCII format. 
        This should normally be done before exporting the project to 
        a new platform, or when using a version control system for 
        the project.
        '''
        project, graph = Globals().getProjectAndGraph(self.projectName)
        # Save pickle
        graph.save()
        # Save ASCII
        graph.saveASCII()
        # Save GraphViz
        graph.saveGraphvizFile()
        return 0

    def __str__(self): return 'project: ' + self.symbol + ' ' + self.version

#----- End BVertex interface
#------------------------------------------------------------------------------------------

    # The following methods are specific to Project (not part of the BVertex interface)
    def addNestedPackages(self, symbol, version='0.0', g=None):
        '''Adds several nested packages simulaneously in project and return the innermost one.'''

        from cct.package import Package
        
        if g is None: g = Globals().getGraph(self.symbol)
        packages = symbol.split('.')
        fullsymbol = packages[0]
        pkg = g.findSymbol(symbol=fullsymbol,kind='package')
        if len(pkg) == 0: 
            top = Package(symbol=fullsymbol, project=self, version=version)
        elif len(pkg) > 1:
            err('ambiguous package name encountered: ' + fullsymbol + '(possibilities are ' + str(pkg) + ')')
        else:
            top = pkg[0]
        
        edge = BEdge(self, top, g)

        parent = top
        if len(packages) > 1:
            for i in range(1,len(packages)):
                fullsymbol = fullsymbol + '.' + packages[i]
                pkgs = g.findSymbol(symbol=fullsymbol,kind='package')
                
                if len(pkgs) == 0:
                    pkg = Package(symbol=fullsymbol, project=self, version=version)
                    edge = BEdge(parent, pkg, g)
                elif len(pkgs) == 1:
                    pkg = pkgs[0]
                else:
                    err('ambiguous package name encountered: ' + pkg + '(possibilities are ' + str(pkgs) + ')')
                parent = pkg
        else: pkg = top
        return pkg

    def getName(self): return self.symbol
    
    def getDir(self): return self.getAttr('projectDir')
    
    def getDefaults(self): 
        '''Returns an instance of ConfigParser contaning project defaults settings.'''
        if self.defaults is None: self.loadDefaults()
        elif len(self.defaults.sections()) is 0: self.loadDefaults()
            
        return self.defaults
    
    def getVertexList(self, kinds=['component']):
        '''Returns a list of all vertices of the specified kind in the project'''
        vlist =  []
        graph = Globals().getGraph(self.symbol)
        for vname in graph.v.keys():
            if graph.v[vname].kind in kinds:
                vlist.append(graph.v[vname])
        return vlist
    
    def setup(self,action,args):
        self.parser = OptionParser(getattr(self, action).__doc__) 
        self.defineArgs(action)
        self.options, self.args = self.parser.parse_args(args)
        self.processArgs(action)
        return
    
    def loadDefaults(self):
        self.defaults = ConfigParser()
        mydir = self.getAttr('projectDir')
        
        if mydir is not None:
            defaultsFile = os.path.abspath(os.path.join(mydir, self.getAttr('defaultsFile')))
            print >>DEBUGSTREAM, 'Project: Loading defaults from ', defaultsFile
            if defaultsFile is not None and os.path.exists(defaultsFile):
                 configfp = open(defaultsFile,'r')
                 if configfp is not None: 
                     self.defaults.readfp(configfp)
                     print >>DEBUGSTREAM, 'Project: Successfully loaded defaults from ', defaultsFile, '. Contents:'
                     self.defaults.write(DEBUGSTREAM)
            else:
                print >>sys.stderr, 'Bocca ERROR: could not load project defaults file: ' + defaultsFile 
                if 'BOCCA_DEBUG' in os.environ.keys() and os.environ['BOCCA_DEBUG'] == '1': 
                    traceback.print_stack()
                    sys.exit(errcode)
               
        return self.defaults 

    def loadBuildTemplate(self,buildTemplateDir=None):
        '''Load the python modules that specify the directory structure and build interface for 
        the build template used in this project.
        '''
        if buildTemplateDir is not None:
            self.setAttr('buildTemplateDir', buildTemplateDir)
        modulePath = os.path.abspath(os.path.join(self.modulePath, self.getAttr('buildTemplateDir'),'python'))
        
        # Load the LocationManagerInterface implementation
        try:
            (file,filename,description) = imp.find_module('locations',[modulePath])
            locations = imp.load_module('locations', file, filename, description)
        except ImportError,e:
            err('Could not import locations module from ' + modulePath + ': ' + str(e))
        try:
            LocationManagerClass = getattr(locations,'LocationManager')
        except AttributeError,e:
            err('Could not find LocationManager class for current build template in ' + modulePath+ ': ' + str(e))
            
        locationManager = LocationManagerClass(self)
        self.locationManager = locationManager

    
        # Load the builder interface implementation
        try:
            (file,filename,description) = imp.find_module('builder',[modulePath])
            builder = imp.load_module('builder', file, filename, description)
        except ImportError,e:
            err('Could not import builder module from ' + modulePath+ ': ' + str(e))
        try:
            BuilderClass = getattr(builder,'Builder')
        except AttributeError,e:
            err('Could not find Builder class for current build template in ' + modulePath+ ': ' + str(e))
            
        builder = BuilderClass(modulePath, self)
        self.builder = builder
        return 0

    def setDefaultLanguage(self, lang):
        status, l = cct._validate.language(lang)
        if status:
            err('Specified default language is not supported in this project: ' + \
                lang + '. Valid languages are: ' + ','.join(self.locationManager.getLanguages()))
        self.defaults.set('Babel','default_language',l)
        return
        
    def getDefaultLanguage(self):
        return self.defaults.get('Babel','default_language')
    
    def getDefaultValue(self, option, section='Project'):
        '''Returns the project.defaults value corresponding to this key or None otherwise'''
        try:
            optstr = self.defaults.get(section,option)
            if optstr.find('#') >= 0:
                optstr = re.split('#', optstr)[0]  # get rid of comments
        except:
            warn('Option "%s" not found in section "%s" of the project.defaults file' % (option, section))
            return None
        return optstr
    
    def setDefaultValue(self, option, val, section='Project'):
        '''Sets the default value for the given option''' 
        try:
            self.defaults.set(section,option,val)
        except:
            warn('Could not find section "%s" in project.defaults file. Option "%s" not set.' % (section,option))
            return 1
        return 0
    
    def getBuilder(self):
        return self.builder
    
    def getLocationManager(self):
        return self.locationManager
    
#------------- Methods private to Project (should not be called by other classes)
        
def _copyBuildTemplateFunc(arg,dirname,fnames):
    '''Copy files from project template to project.'''
    dirsToAvoid = Globals().getDirsToAvoid()
    projDir = arg['projectDir']
    templateDir = arg['templateDir']
    skip = arg['skip']  # list of relative paths (to proj. root) to skip
    
    dirs = dirname.split(os.path.sep)
    for d in dirsToAvoid: 
        if d in dirs: return
        
    prefix = os.path.commonprefix([templateDir, dirname])
    relativePath = dirname
    if prefix != '': relativePath = dirname.replace(prefix,'').lstrip(os.path.sep)
    else: err('invalid template path encountered: ' + dirname)
    if relativePath in skip:
        print >>DEBUGSTREAM, 'project copy template, skipping directory: ' + relativePath
        return
    
    targetDir = os.path.join(projDir,relativePath)
    if not os.path.exists(targetDir):
        try:
            fileManager.mkdir(targetDir)
        except:
            err('could not copy build template, error creating directory ' + targetDir)
    flist = os.listdir(dirname)
    for f in flist:
        ff = os.path.join(dirname,f)
        if os.path.isfile(ff):
            targetFile = os.path.join(targetDir,f)
            try:
                shutil.copy(ff,os.path.join(targetDir,f))
            except:
                err('could not copy build template, error copying file ' + ff + ' to ' + targetFile)
    pass

if __name__ == "__main__":
    project, pgraph = getProject()
    if project is not None:
        pname = project.getName()
        pdir = project.getDir()
#        name,dir = project.getInfo()
        Project(args=sys.argv,project=project,symbol=pname).usage()
    else:
      sys.exit(err('No project found in current directory'))
