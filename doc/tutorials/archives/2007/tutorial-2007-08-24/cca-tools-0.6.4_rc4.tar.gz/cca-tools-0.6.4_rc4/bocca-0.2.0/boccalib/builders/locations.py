import sys, os
import cct._debug
from graph.boccagraph import *

class LocationManagerInterface:
    '''An interface for querying locations of sources, objects, and libraries.'''
    def __init__(self, project):
        self.project = project
        if self.__class__ is LocationManagerInterface: raise NotImplementedError
        pass
    
    def getLanguages(self):
        '''Returns the list of languages with which the project has been configured.
        '''
        langs = []
        if self.__class__ is LocationManagerInterface: raise NotImplementedError
        return langs
    
    def getXMLLoc(self):
        '''Returns a list of directories containing valid Babel XML repositories for 
        this project using relative paths (w.r.t. project).
        '''
        dirlist = []
        if self.__class__ is LocationManagerInterface: raise NotImplementedError
        return dirlist
    
    def getComponentLoc(self):
        ''' Returns a list of directories containing source code for components
        in this project  (relative to top-level project directory)
        '''
        dirlist = []
        if self.__class__ is LocationManagerInterface: raise NotImplementedError
        return dirlist

    def getPortLoc(self):
        ''' Returns a list of directories containing source code for ports
        in this project  (relative to top-level project directory)
        '''
        dirlist = []
        if self.__class__ is LocationManagerInterface: raise NotImplementedError
        return dirlist        
    def getSIDLLoc(self, vertex):
        '''Returns a 2-tuple (dir, [filelist]) containing the relative path (w.r.t. project) 
        and names of SIDL files.'''    
        mydir = None
        flist = []
        if self.__class__ is LocationManagerInterface: raise NotImplementedError        
        return mydir, flist
    
    def getImplLoc(self, vertex):
        '''Returns a 2-tuple (dir, [filelist]) containing the relative path (w.r.t. project)
         of impl files.
        '''
        mydir = None
        flist = []
        if self.__class__ is LocationManagerInterface: raise NotImplementedError        
        return mydir, flist
    
    def getGlueLoc(self, vertex):
        '''Returns a list of directories where glue code is generated
        using relative paths from top project directory.'''
        dirs = []
        if self.__class__ is LocationManagerInterface: raise NotImplementedError        
        return dirs

    def getBuildLibLoc(self,vertex, lang=None):
        '''Returns a list of directories containing libraries correponding to a vertex in the build tree.'''
        dirs = []
        if self.__class__ is LocationManagerInterface: raise NotImplementedError        
        return dirs
    
    def getBuildLibs(self,vertex, lang=None):
        '''Returs a [filelist] containing the relative path (w.r.t. project)
        of library names in the build tree.
        '''
        mydir = None
        flist = []
        if self.__class__ is LocationManagerInterface: raise NotImplementedError
        return flist
    
    def getInstallLibLoc(self,vertex):
        '''Returns the location of the library correponding to vertex in the installation location.'''
        mydir = None
        if self.__class__ is LocationManagerInterface: raise NotImplementedError        
        return mydir
    
    def getInstallIncludeLoc(self,vertex):
        '''Returns the include path correponding to vertex in the installation location.'''
        mydir = None
        if self.__class__ is LocationManagerInterface: raise NotImplementedError        
        return mydir    
    
    def getInstallXMLLoc(self, project):
        '''Returns a list of directories in the project's installation location (not source or build),
        containing valid Babel XML repositories for this project.
        '''
        dirlist = []
        if self.__class__ is LocationManagerInterface: raise NotImplementedError
        return dirlist