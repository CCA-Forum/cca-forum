import writers
from writers import *
from cct._util import DEBUGSTREAM, err, Globals

def BoccaWriterFactory():
    '''Helper function to ensure exactly one instance of the BoccaWriterFactory_Singleton class exists'''
    factory = None
    try:
        factory = BoccaWriterFactory_Singleton()
    except BoccaWriterFactory_Singleton, s:
        factory = s
    return factory

class BoccaWriterFactory_Singleton (object):
    def __init__(self):
        self.writers = {}
        for modName in writerModules:
            writerClassName = modName[0].upper()+modName[1:]
            mod = getattr(writers, modName)
            writerClass = getattr(mod, writerClassName)
            (lang, versionList) = mod.getWriterParameters()
            key = lang + ':' + '|'.join(versionList)
            self.writers[key] = (writerClass, None)
        
    def getWriter (self, language, babelVersion=''):
        ccaVars = Globals().getCCAVars()
        if len(ccaVars) == 0:
            err('[BoccaWriterFactory] could not load CCA settings from defaults file')
        if babelVersion is '': babelVersion = ccaVars['CCASPEC_BABEL_VERSION']
        print >> DEBUGSTREAM, '[BoccaWriterFactory] Babel version is ' + str(babelVersion)
        
        # Handle nightly Babel tarballs, which don't have a regular version number
        if babelVersion.count('.') is 0:
            if 'CCASPEC_BABEL_SNAPSHOT' in ccaVars.keys():
                if ccaVars['CCASPEC_BABEL_SNAPSHOT'] is '1':
                    babelVersion = ccaVars['CCASPEC_BABEL_BRANCH']
        
        if babelVersion.count('.') is 0:
            err('[BoccaWriterFactory] Invalid Babel version encountered')

        for key in self.writers.keys():
            (lang, versionList) = key.split(':')
            versionList = versionList.split('|')
            if (lang != language):
                continue
            (major, minor, patch) = babelVersion.upper().split('.')
            matchingVer = ''
            for v in versionList:
                v_elements = v.upper().split('.')
                v_major = v_elements[0]
                v_minor='X'
                v_patch='X'
                if (len(v_elements) > 3):
                    err('Invalid supported Babel version number ' + 
                        v + ' in class ' + str(self.writers[key][0]), 2)
                if(len(v_elements) == 2):
                    v_minor = v_elements[1]
                elif (len(v_elements) == 3):
                    v_minor = v_elements[1]
                    v_patch = v_elements[2]
                match = False
                if (v_major == 'X'):
                    match = True
                    matchingVer = v
                    break
                if (v_major != major):
                    continue
                if (v_minor == 'X'):
                    match = True
                    matchingVer = v
                    break
                if (v_minor != minor):
                    continue
                if (v_patch == 'X'):
                    match = True
                    matchingVer = v
                    break
                if (v_patch != patch):
                    continue
            if (match != True):
                print >> DEBUGSTREAM, 'Babel version', babelVersion , 'NOT matched by writer versions', versionList
                continue
            print >> DEBUGSTREAM, 'Babel version', babelVersion , 'is matched by writer version', matchingVer
            (classRef, classInstance) = self.writers[key]
            if (classInstance == None):
                classInstance = classRef()
                self.writers[key] = (classRef, classInstance)
            return classInstance
        err('No writer supports ' + language + ' for Babel version ' + babelVersion, 1)
                        