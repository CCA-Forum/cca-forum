#!/bin/sh
# in-project help test
cd $2
mkdir help2
cd help2
if ! test $? ; then
        echo "changing to scratch directory $2 failed"
        echo "BROKEN"
        exit 1
fi
rm -rf myproj
msg=`$1 create project myproj`
if ! test -d "$2/help2/myproj/.bocca"; then
        echo "missing myproj/.bocca"
        echo "FAIL"
        exit 1
fi
cd myproj
$1 help
if test $? ; then
	echo PASS
	exit 0
else
	echo "help in project reported error???"
	echo "FAIL"
	exit 1
fi
