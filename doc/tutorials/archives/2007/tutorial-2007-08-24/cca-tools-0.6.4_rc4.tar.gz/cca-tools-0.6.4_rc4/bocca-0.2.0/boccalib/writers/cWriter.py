from writers.sourceWriter import SourceWriter

def getWriterParameters():
    return (CWriter.language, CWriter.babelVersions)
 
class CWriter(SourceWriter):
    language = 'c'
    babelVersions = ['1.1.X']
    commentLineStart = "/* "
    commentLineEnd = "*/"

    def __init__(self):
        pass
    
    def getImplHeaderCode(self, componentSymbol):
        cmpt_ubar = componentSymbol.replace('.', '_')
        methodName = 'impl_' + cmpt_ubar + '_boccaSetServices' 
        buf ="""
/* DO-NOT-DELETE splicer.begin(@CMPT_TYPE@._includes) */
/* Insert-Code-Here {@CMPT_TYPE@._includes} (includes and arbitrary code) */
/* Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:_includes) */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void
@METHOD_NAME@(
  /* in */ @CMPT_TYPE_UBAR@ self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

/* Bocca generated code. bocca.protected.end(@CMPT_TYPE@:_includes) */

/* DO-NOT-DELETE splicer.end(@CMPT_TYPE@._includes) */
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@CMPT_TYPE_UBAR@', cmpt_ubar).\
                  replace('@METHOD_NAME@', methodName)
        return buf

    def getHeaderCode(self, componentSymbol):
        buf = """
  /* DO-NOT-DELETE splicer.begin(@CMPT_TYPE@._data) */

  /* Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:_data) */
  /* Handle to framework services object */
  gov_cca_Services """+self.servicesVariable+""";
  /* Bocca generated code. bocca.protected.end(@CMPT_TYPE@:_data) */

  /* Put other private data members here... */

  /* DO-NOT-DELETE splicer.end(@CMPT_TYPE@._data) */
"""    
        buf = buf.replace('@CMPT_TYPE@', componentSymbol)
        return buf
        
    def getConstructorCode(self, componentSymbol):
        cmpt_ubar = componentSymbol.replace('.', '_')
        buf = """
  /* DO-NOT-DELETE splicer.begin(@CMPT_TYPE@._ctor) */
  /* Insert-Code-Here {@CMPT_TYPE@._ctor} (constructor method) */
    
  /* Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:_ctor) */
   struct @CMPT_TYPE_UBAR@__data *dptr = 
                (struct @CMPT_TYPE_UBAR@__data*)malloc(sizeof(struct @CMPT_TYPE_UBAR@__data));
   if (dptr) {
      memset(dptr, 0, sizeof(struct @CMPT_TYPE_UBAR@__data));
   }
   @CMPT_TYPE_UBAR@__set_data(self, dptr);
  /* initialize elements of dptr here */
  /* Bocca generated code. bocca.protected.end(@CMPT_TYPE@:_ctor) */

  /* DO-NOT-DELETE splicer.end(@CMPT_TYPE@._ctor) */
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@CMPT_TYPE_UBAR@', cmpt_ubar)
        return buf
            
    def getSetServicesCode(self, componentSymbol):
        cmpt_ubar = componentSymbol.replace('.', '_')
        methodName = 'impl_'+(cmpt_ubar + '_boccaSetServices')
        buf = """ 
  /* DO-NOT-DELETE splicer.begin(@CMPT_TYPE@.setServices) */

  /* Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:setServices) */
   @METHOD_NAME@(self, services, _ex);
  /* Bocca generated code. bocca.protected.end(@CMPT_TYPE@:setServices) */
  
  /* DO-NOT-DELETE splicer.end(@CMPT_TYPE@.setServices) */
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol). \
                  replace('@METHOD_NAME@', methodName)
        return buf

    def getAuxiliarySetServicesMethod(self, componentSymbol, provideDict={}, useDict={}):
        cmpt_ubar = componentSymbol.replace('.', '_')
        methodName = 'impl_' + cmpt_ubar + '_boccaSetServices' 
        buf = """
/* DO-NOT-DELETE splicer.begin(_misc) */
/* Insert-Code-Here {@CMPT_TYPE@._misc} (miscellaneous code) */

/* Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:boccaSetServices) */
void @METHOD_NAME@(
  /* in */ @CMPT_TYPE_UBAR@ self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex)
{

   struct @CMPT_TYPE_UBAR@__data *pd;
   gov_cca_ComponentRelease   compRelease = NULL;
   sidl_BaseInterface throwaway_excpt = NULL;
   char errMsg[256];
   
"""
# Add ports declarations (if needed)
        if (len(provideDict) + len(useDict) > 0):
            buf += """
   gov_cca_TypeMap typeMap = NULL;
   gov_cca_Port port = NULL;
"""
# Component Registration code            
        buf +="""
   pd = @CMPT_TYPE_UBAR@__get_data(self);

   pd->"""+self.servicesVariable+""" = services;

   gov_cca_Services_addRef(services, &throwaway_excpt);
"""
        if (len(provideDict) + len(useDict) > 0):
            buf += """
  /* Create a typemap  */
   typeMap = gov_cca_Services_createTypeMap(pd->"""+self.servicesVariable+""", &throwaway_excpt);
   sprintf(errMsg, sizeof(errMsg), 
           "%s:%d: Error creating gov::cca::TypeMap",__FILE__, __LINE__);
   @CMPT_TYPE_UBAR@_checkException(self, &throwaway_excpt, errMsg, TRUE, &dummy_excpt);
"""
            if (len(provideDict) > 0):
                buf +="""
  /* Cast myself to gov.cca.Port */
   port = gov_cca_Port__cast(self, &throwaway_excpt);
   sprintf(errMsg, sizeof(errMsg), 
           "%s:%d: Error casting self to gov::cca::Port ", 
           __FILE__, __LINE__);
   @CMPT_TYPE_UBAR@_checkException(self, &throwaway_excpt, errMsg, TRUE, &dummy_excpt);
"""
# Provide port(s) code
            for pName in provideDict.keys():
                portBuf = """
   /* Provide a @PORT_TYPE@ port with port name @PORT_INSTANCE@ */
   gov_cca_Services_addProvidesPort(pd->"""+self.servicesVariable+""",   
                       port,
                       "@PORT_INSTANCE@",
                       "@PORT_TYPE@",
                       typeMap,
                       &throwaway_excpt);
   sprintf(errMsg, sizeof(errMsg), 
           "%s:%d: Error registering  @PORT_TYPE@:@PORT_INSTANCE@ provides port", 
           __FILE__, __LINE__);
   @CMPT_TYPE_UBAR@_checkException(self, &throwaway_excpt, errMsg, TRUE, &dummy_excpt);
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                                  replace('@PORT_TYPE@', provideDict[pName])
                buf += portBuf
            
# Use port(s) code
            for pName in useDict.keys():
                portBuf = """
  /* Register a use port of type @PORT_TYPE@ with port name @PORT_INSTANCE@ */  
   gov_cca_Services_registerUsesPort(pd->"""+self.servicesVariable+""",   
                   "@PORT_INSTANCE@",
                   "@PORT_TYPE@",
                   typeMap,
                   &throwaway_excpt);
   sprintf(errMsg, sizeof(errMsg), 
           "%s:%d: Error registering @PORT_TYPE@:@PORT_INSTANCE@ uses port.",
           __FILE__, __LINE__);
   @CMPT_TYPE_UBAR@_checkException(self, &throwaway_excpt, errMsg, TRUE, &dummy_excpt);
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                              replace('@PORT_TYPE@', useDict[pName])
                buf += portBuf
            buf += """
"""   
# Finish up, and replace vars

        buf +="""
  /* Cast myself to gov.cca.ComponentRelease */
   compRelease = gov_cca_ComponentRelease__cast(self, &throwaway_excpt);
   sprintf(errMsg, sizeof(errMsg), 
           "%s:%d: Error casting self to gov.cca.ComponentRelease ",
          __FILE__, __LINE__);
   @CMPT_TYPE_UBAR@_checkException(self, &throwaway_excpt, errMsg, TRUE, &dummy_excpt);
   gov_cca_Services_registerForRelease(pd->"""+self.servicesVariable+""", compRelease, &throwaway_excpt);
   sprintf(errMsg, sizeof(errMsg), 
           "%s:%d: Error registering for releaseService callback.",
          __FILE__, __LINE__);
   @CMPT_TYPE_UBAR@_checkException(self, &throwaway_excpt, errMsg, TRUE, &dummy_excpt);
   return;
}
/* Bocca generated code. bocca.protected.end(@CMPT_TYPE@:boccaSetServices) */
        
/* DO-NOT-DELETE splicer.end(_misc) */
"""
        buf = buf.replace('@CMPT_TYPE_UBAR@', cmpt_ubar).\
                  replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@METHOD_NAME@', methodName)
        return buf

#---------------------------------------------------------------------------------
    def getReleaseMethod(self, componentSymbol, provideDict={}, useDict={}):
        cmpt_ubar = componentSymbol.replace('.', '_')
        buf = """
/*  DO-NOT-DELETE splicer.begin(@CMPT_TYPE@.releaseServices) */
/*  Insert-Code-Here {@CMPT_TYPE@.releaseServices} (releaseServices method) */

/*  Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:releaseServices) */

   struct @CMPT_TYPE_UBAR@__data *pd;
   sidl_BaseInterface throwaway_excpt = NULL;
   sidl_BaseInterface dummy_excpt = NULL;
   char errMsg[256];

   pd = @CMPT_TYPE_UBAR@__get_data(self);
"""
# Un-provide Provide port(s) code
        for pName in provideDict.keys():
            portBuf = """
   /* UN-Provide a @PORT_TYPE@ port with port name @PORT_INSTANCE@ */
   gov_cca_Services_removeProvidesPort(pd->"""+self.servicesVariable+""",   
                       "@PORT_INSTANCE@",
                       &throwaway_excpt);
   snprintf(errMsg, sizeof(errMsg), 
           "Error - %s:%d: Could not remove @PORT_TYPE@:@PORT_INSTANCE@ provides port",
           __FILE__, __LINE__);
   @CMPT_TYPE_UBAR@_checkException(self, &throwaway_excpt, errMsg, TRUE, &dummy_excpt);
"""
            portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                              replace('@PORT_TYPE@', provideDict[pName])
            buf += portBuf

# Unregister uses port(s) code
        for pName in useDict.keys():
            portBuf = """
  /* Un-Register a use port of type @PORT_TYPE@ with port name @PORT_INSTANCE@ */  
   gov_cca_Services_releasePort(pd->"""+self.servicesVariable+""",   
                   "@PORT_INSTANCE@",
                   &throwaway_excpt);
   snprintf(errMsg, sizeof(errMsg), 
         "Error - %s:%d: Could not un-register @PORT_TYPE@:@PORT_INSTANCE@ uses port",
         __FILE__, __LINE__);
   @CMPT_TYPE_UBAR@_checkException(self, &throwaway_excpt, errMsg, TRUE, &dummy_excpt);
"""
            portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                              replace('@PORT_TYPE@', useDict[pName])
            buf += portBuf
# Finish up, and substitute values
        buf += """
   gov_cca_Services_deleteRef(pd->"""+self.servicesVariable+""", &throwaway_excpt);
/*  Bocca generated code. bocca.protected.end(@CMPT_TYPE@:releaseServices) */
    
/*  DO-NOT-DELETE splicer.end(@CMPT_TYPE@.releaseServices) */
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@CMPT_TYPE_UBAR@', cmpt_ubar)
        return buf
    
#---------------------------------------------------------------------------------
    def getCheckExceptionMethod(self, componentSymbol):
        cmpt_ubar = componentSymbol.replace('.', '_')
        buf = """
/*  DO-NOT-DELETE splicer.begin(@CMPT_TYPE@.checkException) */
/*  Insert-Code-Here {@CMPT_TYPE@.checkException} (checkException method) */

/*  Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:checkException) */

   if (SIDL_CATCH(excpt, "gov.cca.CCAException")) {
      fprintf(stderr, "@CMPT_TYPE@: %s \\n", msg);
      SIDL_CLEAR(excpt);
      if (fatal)
         exit(1);
   }
   return;
   
/*  Bocca generated code. bocca.protected.end(@CMPT_TYPE@:checkException) */
    
/*  DO-NOT-DELETE splicer.end(@CMPT_TYPE@.checkException) */
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@CMPT_TYPE_UBAR@', cmpt_ubar)
        return buf
