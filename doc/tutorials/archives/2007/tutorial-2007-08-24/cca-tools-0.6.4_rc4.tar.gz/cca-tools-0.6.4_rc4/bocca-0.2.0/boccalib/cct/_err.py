""" Various err-handling related miscellanea
"""
import sys, os
import traceback
from cct._file import BFileManager

#--------------------------

def err(errmsg='',errcode=1):
    print >>sys.stderr, 'Bocca ERROR: ' + errmsg
    if 'BOCCA_DEBUG' in os.environ.keys() and os.environ['BOCCA_DEBUG'] == '1': 
        traceback.print_stack()
    fm = BFileManager()
    fm.undo()   # Restore files to original state (created files deleted, modified files restored from backups
    fm.close()  # Just in case
    sys.exit(errcode)

def warn(errmsg='',errcode=1):
    print >>sys.stderr, 'Bocca WARNING: ' + errmsg

def exit(msg=''): 
    if msg != '': print >>sys.stdout, msg  
    fm = BFileManager()
    fm.close()
    sys.exit(0)