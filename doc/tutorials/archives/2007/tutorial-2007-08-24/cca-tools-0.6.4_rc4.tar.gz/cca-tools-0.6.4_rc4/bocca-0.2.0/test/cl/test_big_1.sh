#!/bin/sh
# derive from boyana's test script.
# TODO: add checks for expected outputs, currently only return values checked.
cd $2
if [ ! -d big1 ]; then mkdir big1; fi

export BOCCA=$1
export BOCCATEST=`pwd`/big1

function checkCmd() {
    # The first (required) argument is the type of failure, e.g., "FAIL", "XFAIL", "BROKEN"
    # The second (required) argument is the command
    # The third (optional) argument is the error message in case of failure
    # The fourth (optional) argument is a list of files which should exist upon successful completion of command.
    fail=$1
    cmd=$2
    if [ "x$3" != "x" ]; then
        msg=": $3"
    else
        msg=""
    fi
    files=""
    if [ "x$4" != "x" ]; then 
        files=$4
    fi
    echo "CHECKING $cmd"
    msg=`$cmd`
    errcode=$?
    if [ "$errcode" != "0" ]; then
        echo "$fail($errcode)$msg."
	if [ "$fail" == "XFAIL" ]; then return 0; fi
        exit 1
    else
        for f in $files; do
        	# When a file path begins with "!", check for non-existence, otherwise check for existence
        	if test "${f:0:1}" = "!" ; then 
        		if test -e "${f:1}" ; then 
        			echo "$fail($errcode): file ${f:1} not renamed/removed."
 	        		if test "$fail" = "XFAIL" ; then return 0; fi
                	exit 1
        		fi
            elif ! test -e "$f" ; then 
                echo "$fail($errcode): file $f not created."
	        	if test "$fail" = "XFAIL" ; then return 0; fi
                exit 1
            fi
        done
        echo "successful."
        return 0
    fi
}

# First project
cd $BOCCATEST && /bin/rm -rf *
checkCmd "FAIL" "$BOCCA create project testproj1" "could not create a project" "testproj1/project.make"

checkCmd "BROKEN" "cd $BOCCATEST/testproj1" "could not cd to $BOCCATEST/testproj1"
cd $BOCCATEST/testproj1
checkCmd "FAIL" "$BOCCA create interface mypkg.test.SomeInterface" "could not create an interface" "ports/sidl/mypkg.test.SomeInterface.sidl"

checkCmd "FAIL" "$BOCCA create interface -e mypkg.test.SomeInterface mypkg.test.SomeOtherInterface" "could not create an interfaace extending another interface" "ports/sidl/mypkg.test.SomeOtherInterface.sidl"

checkCmd "FAIL" "$BOCCA create port MyPort" "could not create a port using short symbol name" "ports/sidl/testproj1.MyPort.sidl"

checkCmd "FAIL" "$BOCCA create port mypkg.test.APort" "could not create a port" "ports/sidl/mypkg.test.APort.sidl"

checkCmd "FAIL" "$BOCCA create port -e mypkg.test.SomeInterface -e mypkg.test.APort mypkg.test.AnotherPort" "could not create a port that extends an interface and a port" "ports/sidl/mypkg.test.AnotherPort.sidl"

checkCmd "FAIL" "$BOCCA create port -e mypkg.test.SomeOtherInterface -e mypkg.test.APort mypkg.test.ThirdPort" "could not create a port that extends an interface and a port" "ports/sidl/mypkg.test.ThirdPort.sidl"

checkCmd "FAIL" "$BOCCA remove interface SomeInterface" "could not remove interface" "!ports/sidl/mypkg.test.SomeInterface.sidl"

checkCmd "FAIL" "$BOCCA rename interface SomeOtherInterface NewInterface" "could not rename interface" "!ports/sidl/mypkg.test.SomeOtherInterface.sidl ports/sidl/mypkg.test.NewInterface.sidl"

checkCmd "FAIL" "$BOCCA create component -p mypkg.test.AnotherPort:AnotherPort -lcxx mypkg.test.AComponent" "could not create a component that provides a port" "components/sidl/mypkg.test.AComponent.sidl"

checkCmd "FAIL" "$BOCCA create component -u mypkg.test.APort:APort  -lc mypkg.test.AnotherComponent" "could not create a component that uses a port"  "components/sidl/mypkg.test.AnotherComponent.sidl"

checkCmd "FAIL" "$BOCCA create component -p mypkg.test.ThirdPort:ThirdPort -u mypkg.test.APort:APort mypkg.test.ThirdComponent" "could not create a component that uses and provides ports" "components/sidl/mypkg.test.ThirdComponent.sidl"

checkCmd "FAIL" "$BOCCA create component TransientComp" "components/sidl/testproj1.TransientComp.sidl"

checkCmd "FAIL" "$BOCCA rename component TransientComp PermanentComp" "could not rename component" "!components/sidl/testproj1.TransientComp.sidl components/sidl/testproj1.PermanentComp.sidl"

checkCmd "FAIL" "$BOCCA display project" "could not display project"

checkCmd "FAIL" "make" "could not build project" "components/lib/mypkg_test_AComponent.cca components/lib/mypkg_test_ThirdComponent.cca components/lib/mypkg_test_AnotherComponent.cca  components/lib/testproj1_PermanentComp.cca"

checkCmd "FAIL" "make check" "could not instantiate components" 

# Second project
checkCmd "BROKEN" "cd $BOCCATEST" "could not cd to $BOCCATEST"
cd $BOCCATEST
checkCmd "FAIL" "$BOCCA create project -p mypkg.test testproj2" "could not create a project with specified package" "testproj2/project.make"

checkCmd "BROKEN" "cd $BOCCATEST/testproj2" "could not cd to $BOCCATEST/testproj2"
cd $BOCCATEST/testproj2
checkCmd "FAIL" "$BOCCA display project testproj2" "could not display specified project"

checkCmd "FAIL" "$BOCCA create port -lc++,c,python mypkg.test.SolverPort" "could not add a port with languages specified" "ports/sidl/mypkg.test.SolverPort.sidl"

echo "PASS"
exit 0
