from writers.sourceWriter import SourceWriter

def getWriterParameters():
    return (PythonWriter.language, PythonWriter.babelVersions)
 
class PythonWriter(SourceWriter):
    language = 'python'
    babelVersions = ['1.0.X', '1.1.X']

# -------------------------------
    def __init__(self):
        pass
    
# -------------------------------
    def getConstructorCode(self, componentSymbol):
        buf = """
# DO-NOT-DELETE splicer.begin(_before_type)
import sys
# DO-NOT-DELETE splicer.end(_before_type)

# DO-NOT-DELETE splicer.begin(__init__)
    # Put your code here...
    # Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:_init) 
    self."""+self.servicesVariable+""" = None
    # Bocca generated code. bocca.protected.end(@CMPT_TYPE@:_init) 
# DO-NOT-DELETE splicer.end(__init__)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol)
        return buf

# -------------------------------
    def getSetServicesCode(self, componentSymbol):
        methodName = '_boccaSetServices'
        buf = """ 
    # DO-NOT-DELETE splicer.begin(setServices)
    # Put your code here...

    # Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:setServices) 
    self.@METHOD_NAME@(services)
    # Bocca generated code. bocca.protected.end(@CMPT_TYPE@:setServices) 
  
    # DO-NOT-DELETE splicer.end(setServices)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol). \
                  replace('@METHOD_NAME@', methodName)
        return buf
    
# -------------------------------
    def getAuxiliarySetServicesMethod(self, componentSymbol, provideDict={}, useDict={}):
        methodName = '_boccaSetServices'
        buf = """
# DO-NOT-DELETE splicer.begin(_final)

# Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:boccaSetServices) 
  def @METHOD_NAME@(self, services):
  
    self."""+self.servicesVariable+""" = services
"""
# Add ports declarations (if needed)
        if (len(provideDict) + len(useDict) > 0):
            buf += """
    # Create a typemap
    try:
      mymap = self."""+self.servicesVariable+""".createTypeMap()
    except gov.cca.CCAException, e:
      self.checkException(sidl.BaseInterface.BaseInterface(e), \\
                'Error creating Typemap', True)
    
"""
            if (len(provideDict) > 0):
                buf +="""
    try:
      port = gov.cca.Port.Port(self.__IORself)  # Casting !!!!
    except gov.cca.CCAException, e:
      self.checkException(sidl.BaseInterface.BaseInterface(e), \\
                'Error casting @CMPT_TYPE@ to to gov.cca.Port', True)
"""
# Provide port(s) code
            for pName in provideDict.keys():
                portBuf = """
    # Provide a @PORT_TYPE@ port with port name @PORT_INSTANCE@ 
    try:
      self."""+self.servicesVariable+""".addProvidesPort(port,
                              '@PORT_INSTANCE@',
                              '@PORT_TYPE@',
                              mymap);
    except gov.cca.CCAException, e:
      self.checkException(sidl.BaseInterface.BaseInterface(e), \\
           'Error - could not provide @PORT_TYPE@:@PORT_INSTANCE@ provides port', True)
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                                  replace('@PORT_TYPE@', provideDict[pName])
                buf += portBuf
            
# Use port(s) code
            for pName in useDict.keys():
                portBuf = """
    # Register a use port of type @PORT_TYPE@ with port name @PORT_INSTANCE@
    try:
      self."""+self.servicesVariable+""".registerUsesPort('@PORT_INSTANCE@',
                                '@PORT_TYPE@',
                                mymap);
    except gov.cca.CCAException, e:
      self.checkException(sidl.BaseInterface.BaseInterface(e), \\
           'Error - could not register @PORT_TYPE@:@PORT_INSTANCE@ uses port', True)
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                              replace('@PORT_TYPE@', useDict[pName])
                buf += portBuf
# Finish up, and replace vars

        buf +="""
    compRelease = gov.cca.ComponentRelease.ComponentRelease(self.__IORself)
    try:
      self."""+self.servicesVariable+""".registerForRelease(compRelease)
    except gov.cca.CCAException, e:
      self.checkException(sidl.BaseInterface.BaseInterface(e), \\
           'Error - could not register @CMPT_TYPE@ for release', True)
    return
# Bocca generated code. bocca.protected.end(@CMPT_TYPE@:boccaSetServices) 

# DO-NOT-DELETE splicer.end(_final)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@METHOD_NAME@', methodName)
        return buf
    
# -------------------------------
    def getReleaseMethod(self, componentSymbol, provideDict={}, useDict={}):
        buf = """
    # DO-NOT-DELETE splicer.begin(releaseServices)

    # Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:releaseServices) 
"""
# Un-provide Provide port(s) code
        for pName in provideDict.keys():
            portBuf = """
    # UN-Provide a @PORT_TYPE@ port with port name @PORT_INSTANCE@ 
    try:
      self."""+self.servicesVariable+""".removeProvidesPort('@PORT_INSTANCE@')
    except gov.cca.CCAException, e:
      self.checkException(sidl.BaseInterface.BaseInterface(e), \\
           'Error - could not remove provided port @PORT_TYPE@:@PORT_INSTANCE@', True)
"""
            portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                              replace('@PORT_TYPE@', provideDict[pName])
            buf += portBuf
            
# Use port(s) code
        for pName in useDict.keys():
            portBuf = """
    # Un-Register a use port of type @PORT_TYPE@ with port name @PORT_INSTANCE@
    try:
      self."""+self.servicesVariable+""".releasePort('@PORT_INSTANCE@')
    except gov.cca.CCAException, e:
      self.checkException(sidl.BaseInterface.BaseInterface(e), \\
           'Error - could not release port @PORT_TYPE@:@PORT_INSTANCE@', True)
"""
            portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                              replace('@PORT_TYPE@', useDict[pName])
            buf += portBuf
# Finish up, and replace vars

        buf +="""
    self."""+self.servicesVariable+""" = None
    return
    # Bocca generated code. bocca.protected.end(@CMPT_TYPE@:releaseServices) 

    # DO-NOT-DELETE splicer.end(releaseServices)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol)
        return buf

# -------------------------------
    def getCheckExceptionMethod(self, componentSymbol):
        buf = """
    # DO-NOT-DELETE splicer.begin(checkException)

    # Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:checkException)
     
      import sys
      print >>sys.stderr,'Exception in @CMPT_TYPE@:', msg
      if (fatal):
        raise gov.cca.CCAException.CCAException(excpt)
        
      return
     
    # Bocca generated code. bocca.protected.end(@CMPT_TYPE@:checkException) 

    # DO-NOT-DELETE splicer.end(checkException)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol)
        return buf

# -------------------------------
    def getGoCode(self, componentSymbol, useDict={}):
        buf = """
    # DO-NOT-DELETE splicer.begin(@CMPT_TYPE@.go)
@BOCCA_GO_PROLOG@

    # If this try/catch block is rewritten by the user, we will not change it.
    try:
        # All port instances should be rechecked for ._not_nil before calling in user code.
        # The user might not require all ports to be connected in all configurations.

        # Insert-Code-Here {@CMPT_TYPE@.go} 

        return 0;
    except:
        return 2; 
        # if specific exceptions in the user code are tolerable 
        # and restart is ok, return 1 instead.
        # 2 means the component is so confused that it and probably 
	# the application should be destroyed.

@BOCCA_GO_EPILOG@
    # DO-NOT-DELETE splicer.end(@CMPT_TYPE@.go)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol)
        prolog = self.getGoPrologCode(componentSymbol, useDict)
        epilog = self.getGoEpilogCode(componentSymbol, useDict)
        buf=buf.replace("@BOCCA_GO_PROLOG@", prolog)
        buf=buf.replace("@BOCCA_GO_EPILOG@", epilog)
        return buf

# -------------------------------
    def getGoPrologCode(self, componentSymbol, useDict={}):
        cmpt_ubar = componentSymbol
        buf = """

# Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:boccaGoProlog)
"""
# Add local uses ports variables:
        if len(useDict) > 0:
            # Use port(s) code
            for uName in useDict.keys():
                portnativetype = useDict[uName]
                nlist = portnativetype.split(".")
                portLeaf = nlist[len(nlist)-1]
                portBuf = """
    # Use a @PORT_TYPE@ port with port name @PORT_INSTANCE@ 
    try:
        port = self."""+self.servicesVariable+""".getPort("@PORT_INSTANCE@")
    except: gov.cca.CCAException, e:
        self.checkException(sidl.BaseInterface.BaseInterface(e), "@CMPT_TYPE@: Error calling getPort for @PORT_TYPE@:@PORT_INSTANCE@" , False)
   
    @PORT_INSTANCE@_fetched = False;
    if port == None:
        print '@CMPT_TYPE@: getPort("@PORT_INSTANCE@") returned nil."
    else:
        @PORT_INSTANCE@_fetched = True # even if the next cast fails, must release.
        @PORT_INSTANCE@ = @NATIVE_PORT_TYPE@.@NATIVE_PORT_LEAF@(port);
        if @PORT_INSTANCE@ == None:
            print "@CMPT_TYPE@: Error casting component to gov.cca.Port to @PORT_INSTANCE@ type @NATIVE_PORT_TYPE@"
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', uName).\
                              replace('@PORT_TYPE@', useDict[uName]).\
                              replace('@NATIVE_PORT_TYPE@', portnativetype).\
                              replace('@NATIVE_PORT_LEAF@', portLeaf)
                buf += portBuf
            # end for uName
            buf += """
"""   
        # Finish up, and replace class vars
        buf +="""
# Bocca generated code. bocca.protected.end(@CMPT_TYPE@:boccaGoProlog)

"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol)
        return buf
    
# -------------------------------
    def getGoEpilogCode(self, componentSymbol, useDict={}):

        cmpt_ubar = componentSymbol.replace('.', '_')
        methodName = componentSymbol.replace('.', '::') +'_impl::boccaGoProlog'
        buf = """
# Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:boccaGoEpilog)
"""
# release local uses ports variables:
        if len(useDict) > 0:
            # release port(s) code
            for uName in useDict.keys():
                portBuf = """
   # release @PORT_INSTANCE@ 
    if @PORT_INSTANCE@_fetched:
        @PORT_INSTANCE@_fetched = False
        try:
            self."""+self.servicesVariable+""".releasePort("@PORT_INSTANCE@")
        except gov.cca.CCAException, e:
            self.checkException(sidl.BaseInterface.BaseInterface(e), "@CMPT_TYPE@: Error calling releasePort for @PORT_INSTANCE@" , False)
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', uName)
                buf += portBuf
            # end for uName
            buf += """
"""   
        # Finish up, and replace class vars
        buf +="""
# Bocca generated code. bocca.protected.end(@CMPT_TYPE@:boccaGoEpilog)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol)
        return buf

