action_menu = [
        'help',
        'create', 
        'change',
        'display',
        'edit', 
        'remove',
        'rename',
        'save'
        ]

menu = [
        'project',
        'package',
        'interface',
        'port',
        'sidlclass',
        'component',
        'application',
	    'example'
        ]

