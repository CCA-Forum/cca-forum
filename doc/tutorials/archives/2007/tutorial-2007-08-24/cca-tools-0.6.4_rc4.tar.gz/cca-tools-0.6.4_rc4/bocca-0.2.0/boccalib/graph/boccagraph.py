#!/usr/bin/env python

# Bocca project internal representation graph datastructure
# Copyright (c) 2007, UChicago, LLC
# Operator of Argonne National Laboratory
#
# Authors: Boyana Norris

"""A graph representation of SIDL-based CCA projects.

Each CCA project can be represented by using a graph data structure.
Nodes represent code entities (projects, libraries, interfaces, 
classes, ports, components), and edges represent dependencies
between them. Dependence is defined as follows: node B 
depends on node A if a modification of node A requires an 
action on node B. In the graph representation, a directed
edge A -> B means that B depends on A. The action on B after
modification of A is stored as an edge attribute on the edge A -> B.
Actions are generally code transformations, such as generating code 
from SIDL files or compiling sources into a library. Some edges resulting
from non-transformation dependencies e.g., including a header 
(represented by vertex A) without having to link to a corresponding 
library, do not have specific actions associated with them, but 
a change in the header will result in triggering all actions 
(if any) in the subgraph rooted at the header vertex A.

"""

import os, re, sys, imp, stat, random, graphlib.delegate
#import pickle
import cPickle as pickle
from bz2 import BZ2File
from parse.boccaParse import OptionParser
from graphlib.graph import *
from cct._err import * 
from cct._debug import *
from cct._util import *

class BVertex(Vertex):
    def __init__(self,  action='__init__', args = None, project = None, modulePath = None,
                 kind=None, symbol=None, version='0.0', graph = None):
        '''bocca help <verb> <subject>   lists the help on a topic 
        bocca help                    lists the available verbs and subjects
        '''

        '''Create a BVertex given its kind (package, class, interface, port, component, etc.), 
        SIDL symbol (if the vertex corresponds to a SIDL type, otherwise this is some sort of 
        identifying name), a string representing the version number, and a BGraph. 
        All arguments are optional.
        
        Note that the vertex is *not* added to the graph in this method. However, when a BEdge is
        created, all vertices are automatically added to the graph, if they are not already in it, 
        so it's rarely necessary to explicitly insert a vertex into the graph. 
        '''
        # Ths constructor should be invoked from subclasses, but it is strongly advised
        # that subclass constructors do not change the semantics.

        # This abstract superclass should never be instantiated, self should be a subclass instance

        self.modulePath = modulePath
	self.sidlobjectregex=re.compile('\A[A-Za-z][A-Za-z0-9\.]*[A-Za-z0-9]\Z')

        if self.modulePath is not None: sys.path.append(self.modulePath)
        
        # The default action is '__init__' and is used only to obtain the 
        # general documentation for this class (the doc string immediately
        # after the __init__ method header. This documentation will be displayed when 
        # a user invokes 'bocca help subject' where subject is one 
        # of the BVertex subclasses. 
        if action is None: action = '__init__'
        self.parser = OptionParser(getattr(self, action).__doc__) 
                     
        self.symbol = symbol 
        self.kind = kind
        if self.kind is None: self.kind = self.__class__.__name__.lower()
        self.version = version
        self.data = {}
        self.options = None
        self.args = None
        self.sidlImports = {}
        self.action = action
        
        # The following three data fields are used for imported SIDL
        self.astNode = None
        self.startComment = ''
        self.endComment = '' 

        if project is None and action == 'create' and self.kind == 'project':
            self.projectName = self.symbol
        elif project is not None:
            self.projectName = project.symbol
            # Load project bocca configuration from BOCCA/bocca.config
            project.defaults = cct._util.Globals().getDefaults(project.symbol, forceReload=True)

        self.project = project
        
        self.handleArgs(args,action)

        if self.symbol is None:
            # Try to get symbol from args (assuming it's the first argument)
            if len(self.args) > 0:
                self.symbol = self.args[0]
            else:
                err('[BVertex] Missing symbol name, make sure it is set from the command''s options.')
        if project != None:
            defaultPackage = None
            if project is not None: defaultPackage = project.getAttr('defaultPackage')
            if defaultPackage == None or defaultPackage == '': defaultPackage = self.projectName

            if self.symbol.count('.') == 0 and self.kind not in ['project', 'package']:
                pgraph = Globals().getGraph(project.symbol)
                # First try to find the fully qualified symbol
                if pgraph is not None:
                    slist = pgraph.findSymbol(self.symbol,kind=self.kind,version=self.version)    
                    if len(slist) > 1:
                        err('Multiple matches for ' + self.kind + ' ' + self.symbol + ' found in this project. Please use a fully qualified SIDL symbol.')
                    elif len(slist) == 1:
                        self.symbol = slist[0].symbol
                    else:
                        self.symbol = defaultPackage + '.' + self.symbol
                else:
                    # If no symbol found, use default package
                    self.symbol = defaultPackage + '.' + self.symbol

        # A dictionary of code blocks associated with a specific vertex type
        self.code = {}
        
        Vertex.__init__(self, name=self.kind + '@' + self.symbol + '@' + self.version)
    
    def changeSymbol(self, newSymbol):
        p,g = cct._util.Globals().getProjectAndGraph(self.projectName)
        oldsymbol = self.symbol
        self.symbol = newSymbol
        oldname = self.name
        self.name = self.kind + '@' + self.symbol + '@' + self.version
        self.project = p
        
        if g != None:
            if not oldname in g.v.keys():
                raise SymbolError(oldsymbol, 'Symbol not found: ')
            # change vertex
            g.v.deleteItem(oldname)
            g.add_v(self)
        # change edges
        for e in self.in_e:
            if g != None: g.e.deleteItem(e.name)
            e.name = e.v[0].name + ':' + self.name
            e.v[1] = self
            if g != None: g.add_e(e)
        for e in self.out_e:
            if g != None: g.e.deleteItem(e.name)
            e.name = self.name + ':' + e.v[1].name
            e.v[0] = self
            if g != None: g.add_e(e)
        return 
    
    def handleArgs(self, args, action):
        # Define and process command line arguments -- the defineArgs and processArgs
        # are virtual methods that must be implemented by subclasses.
        if action is not None and args is not None:
            self.defineArgs(action)
            self.options, self.args = self.parser.parse_args(args)
            self.processArgs(action)    # This is where we should set self.symbol from the args
# FIXME: Need a better way to handle (buildTemplate/codeTemplate) pair configuration
            self.templatePath = os.path.abspath(os.path.join(self.modulePath, 'templates', 'babel-1.0'))

    #----------------------------------------------------------------------------------
    # Begin methods that can be overridden by subclasses

    #------------- Methods for defining and validation of command line arguments
    def defineArgs(self, action):
        """ Defines all command-line arguments for a subject.
        This is normally called by __init__ 
        """
        if self.__class__ is BVertex: raise NotImplementedError
        if not self.parser.has_option('--help'):
            self.parser.add_option("-h", "--help", dest="help", action="store_true",
                                   help="show the help message for this command and exit")
            self.parser.set_defaults(help=False)
        if (action == 'remove' or action == 'rename') and not self.parser.has_option("--force"):
            self.parser.add_option("-f", "--force", dest="force", action="store_true",
                   help="Force the change without prompting for confirmation.")
        return

    def processArgs(self, action):
        """ Validates and if necessary canonicalizes the command line arguments for
        this subject, which are parsed into self.options.
        It is very important to set self.symbol to the appropriate SIDL symbol or name.
        Exits nonzero if user gives bad input.
        """
        if self.__class__ is BVertex: raise NotImplementedError

        if hasattr(self.options,'help') and self.options.help:
            print getattr(self, action).__doc__
        if action == 'remove' or action == 'rename' and self.parser.has_option("--force"):
            self.parser.set_defaults(force=False)
        return
       
    # ---------- Methods corresponding to bocca actions given on the command line
    def create(self):
        ''' create SUBJECT [options] [arguments]
        
        Creates a new bocca entity based on the SUBJECT. Some SUBJECT examples 
        are project, package, interface, class, port, component.
        
        For more details on the creation of specific bocca entities, 
        try "bocca create SUBJECT --help" where SUBJECT is a specific bocca 
        entity name.
        '''
        if self.__class__ is BVertex: raise NotImplementedError
        return
    
    def change(self):
        ''' Changes some existing project element(s). 
        Whatever you put in this triple-quote block is the
        help given when you ask bocca help $subcommand
        This must be the first thing in the function.
        '''
        if self.__class__ is BVertex: raise NotImplementedError
        return
    
    def remove(self):
        ''' Removes some existing project element(s).       
        Whatever you put in this triple-quote block is the
        help given when you ask bocca help $subcommand
        This must be the first thing in the function.
        '''
        if self.__class__ is BVertex: raise NotImplementedError
        return
    
    def rename(self):
        ''' Renames some existing project element(s).
        Whatever you put in this triple-quote block is the
        help given when you ask bocca help $subcommand
        This must be the first thing in the function.
        '''
        if self.__class__ is BVertex: raise NotImplementedError
        return
            
    def display(self):
        ''' Displays some existing project element(s).
        Whatever you put in this triple-quote block is the
        help given when you ask bocca help $subcommand
        This must be the first thing in the function.
        '''
        if self.__class__ is BVertex: raise NotImplementedError
        retcode = 0
        project,pgraph = cct._util.Globals().getProjectAndGraph(self.projectName)
        v = pgraph.findSymbol(self.symbol,self.kind) 
        if len(v) > 0:
            for i in v: 
                print i.prettystr()
        else:
            err('[display ' + self.kind +  '] ' + self.kind + ' not found in current project.')
        return retcode
        
    def edit(self):
        ''' Open an editor for an editaable SIDL entity.
        '''
        if self.__class__ is BVertex: raise NotImplementedError
        return 
    
    def save(self):
        ''' Save the project state in a portable ASCII format. 
        This should normally be done before exporting the project to 
        a new platform, or when using a version control system for 
        the project.
        '''
        if self.__class__ is not cct.Project:
            err('The save command can only be used on a project, e.g., "bocca project save"')
        return
    
    #------------------- End of actions interface
    
    # -------------- Various I/O methods which can be implemented by subclasses

    def _graphviz(self): return '"' + self.name + '"' + '[label="' + self.shortstr() + '",' + self.graphvizString() + '];\n'
    
    def graphvizString(self): return 'color=white'

    def __str__(self):
        ''' Default conversion to a string.'''
        (kind, symbol, version) = self.name.split('@')
        return '%s: %s %s' % (kind, symbol, self.data)  

    def prettystr(self):
        buf = self.kind + ' ' + self.symbol + ' version ' + self.version
        for j in self.data.keys():
            if j not in ['methodsIndent']:
                buf += '\n\t' + str(j) + ': ' + str(self.data[j])
        return buf
    
    def shortstr(self):
        '''Shorter string representation'''
        (kind, symbol, version) = self.name.split('@')
        return '%s: %s %s' % (kind, symbol, version)  
 
    def usage(self, exitcode=0, errmsg=None):
        if errmsg is not None:
            print >>sys.stderr, 'Bocca ERROR: ', errmsg
        self.parser.print_help()
        sys.exit(exitcode)
        return
    
    # ============ ASCII serialization and deserialization routines
    
    def serializeASCII(self, filedesc = None):
        '''Writes a complete ASCII representation of current object which 
        can be used to reconstruct the object by calling deserialize.
        Note that pickle is used during development for maintaining the 
        state of a project; this serialization will be used only rarely, i.e.,
        when migrating a project to a new environment or when merging projects. 
        '''
        classname = str(self.__class__)
        # Get rid of leading cct., just save pkgname.classname
        # Also add package if classname doesn't already contain it
        if classname.count('.') == 0:
            classname = classname.lower() + '.' + classname
        elif classname.count('cct.') > 0:
            classname = classname[classname.find('cct.')+4:len(classname)]
        itemlist = self._getSerializableFields()
        count = 0
        buf = ''
        for item in itemlist:
            buf += '%s=%s|' % (item,str(self.__dict__[item]))  # the separator is '|'
            count += 1
        # Now fields that start with _b_
        blist = []
        for member in self.__dict__.keys():
            if  member.startswith('_b_'):
                blist.append(member)

        for item in blist:
            buf += '%s=%s|' % (item, str(self.__dict__[item])) # the separator is '|'
            count += 1
        if buf.endswith('|'): buf = buf[:-1]   # For some reason rstrip wasn't working!
        buf  = '!vertex=' + classname + '\n' + 'count=' + str(count) + '|' + buf + '\n' 
        if filedesc: filedesc.write(buf)
        return buf

    def deserializeASCII(self, thestring):
        '''Returns an instance of a specific vertex type configured with
        the information resulting from deserializing the sstr string. 
        The first line in the string contains "!vertex=NUMBER" where
        NUMBER is the number of subsequent entries corresponding to this vertex.
        '''
        namevalpairs = thestring.strip().split('|')
        count = int(namevalpairs[0].split('=')[1])
        if len(namevalpairs) != count + 1:
            err('BVertex: the string does not contain the expected number of entries for deserialization')
        for i in range(1,count+1):
            item, val = namevalpairs[i].strip().split('=')
            self.__dict__[item] = deserializeASCII(val)   # the deserialize val is implemented in utils.py
        return self.__dict__[item]


################################################################################# 
# ---- The following methods should in general not be overloaded by child classes
    
    def clone(self):
        '''This is not a full clone, just some of the basics for use in rename.'''
	newvertex = self.__class__(symbol=self.symbol,version=self.version,project=self.project)
        newvertex._b_sidlFile = self._b_sidlFile
        if self.kind in ['class','component']:
            newvertex._b_implements = self._b_implements
            newvertex._b_extends = self._b_extends
        if self.kind == 'component':
            newvertex._b_providesPorts = self._b_providesPorts
            newvertex._b_usesPorts = self._b_usesPorts
            newvertex._b_providesLocations = self._b_providesLocations
            newvertex._b_usesLocations = self._b_usesLocations
        return newvertex
        
    def renameInternalSymbol(self, oldsymbol, newsymbol):
        '''Replaces any internal references to oldsymbol with newsymbol.'''
        if self.__class__ is BVertex: raise NotImplementedError
        return 1

    def removeInternalSymbol(self, symbol):
        ''' Removes any internal references to symbol.'''
        if self.__class__ is BVertex: raise NotImplementedError
        return 1
   
    def validateNewSymbol(self, graph):
        '''Ensures that the current symbol is not already in the graph.
        '''
        if self.sidlobjectregex.match(self.symbol) == None:
            err('[create ' + self.kind + '] the specified symbol is not legal SIDL: ' + self.symbol, 4) 
        if graph and graph.containsSIDLSymbol(self.symbol):
            s = graph.findSymbol(self.symbol)[0]
            err('[create ' + self.kind + '] the specified SIDL symbol already exists in project:\n\n' + s.prettystr(), 4) 
        return
    
    def validateExistingSymbol(self, graph):
        '''Returns a fully qualified name and sets self.symbol to it if a unique match is found in the graph.
        '''
        if not self.symbol: self.symbol = self.args[0]
        slist = graph.findSymbol(self.symbol, self.kind, self.version)
        if len(slist) is 0:
            err(self.kind + "symbol " + self.symbol + " version "+ self.version + " not found in project.", 3)
        elif len(slist) > 1:
            err('specified ' + self.kind + ', ' + self.symbol + ', is ambiguous, please use a fully qualified SIDL symbol.',3)
        else:
            self.symbol = slist[0].symbol
            print >>DEBUGSTREAM, 'validated symbol: ' + self.symbol
        return self.symbol
    
    def dependents(self):
        ''' Return all vertices that depend on this vertex (overridden just to 
        give it a more intuitive name'''
	graph = Globals().getGraph(self.projectName)
        return graph.breadth_first_search(self)[1:]
    
    def dependencies(self):
        ''' Return all vertices that depend on this vertex (overridden just to 
        give it a more intuitive name'''
	graph = Globals().getGraph(self.projectName)
        return graph.breadth_first_search(self,reverse=True)[1:]

    def getAttr(self, key):
        if key in self.data.keys():
            return self.data[key]
        else:
            return None
        
    def setAttr(self, key, val):
        self.data[key] = val
        return self.data[key]
    
    def delAttr(self,key):
        if key in self.data.keys():
            del self.data[key]
        return
    
    def saveProjectState(self, graph, graphviz=True):
        '''Saves the project's graph in a pickle file. If graphviz is True, it also saves a dot file
        containing the GraphViz representation of the project graph. 
        '''
        if self.project:
            graph.saveGraphvizFile(os.path.join(self.project.getDir(),'.bocca',self.projectName+'.dot'))
            graph.save()        
        return
    
    def getSIDLSplicerKey(self):
        return 'DO-NOT-DELETE bocca.splicer'
    
    def getSIDLSplicerBeginString(self, indentstr='', tag = None, extraSplicerComment = False, insertComment=''):
        if tag is None: tag = self.symbol
        thestring =  indentstr + '// ' + self.getSIDLSplicerKey() + '.begin(' + tag + ')\n' 
        if extraSplicerComment:
            thestring += indentstr + '// Insert-code-here {' + tag + '}'
            if insertComment: 
                thestring += ' (' + insertComment + ')'
            thestring += '\n'
        thestring += '\n'
        return thestring
            
    def getSIDLSplicerEndString(self, indentstr='', tag = None): 
        if tag is None: tag = self.symbol
        return indentstr  + '// ' + self.getSIDLSplicerKey() + '.end(' + tag + ')\n' 
        
    def getSIDLImports(self):
        return self.sidlImports
    
    def setSIDLImports(self, imports):
        self.sidlImports = imports

    def handleSIDLImports(self):
        '''
        Import methods specified with the --import-sidl option into this interface.
        '''
        from parse.itools.parser import Parser
        from parse.itools.visitor.printer import Printer
        from parse.itools.visitor.subtree import SubtreeImporter
        from splicers.Operations import mergeFromString
        
        print >> DEBUGSTREAM, self.kind + ', handleSIDLImports: about to import from ' + str(self.getSIDLImports())
        
        retcode = 0
        project, pgraph = Globals().getProjectAndGraph(self.project.symbol)
        
        # Load some defaults
        # Create the beginning of the splicer block for the methods
        tabsize = self.project.getDefaultValue('tab_size', section='SIDL') 
        if tabsize: tab = int(tabsize)
        else: tab = '    '

        
        # Parse the SIDL files specified using the --import-sidl option and 
        # construct the strings containing methods declarations for each 
        # specified interface.
        parser = Parser()
    
        sidlimports = self.getSIDLImports()
        for fileName in sidlimports.keys():
            ast = parser.parseFile(fileName)
            #parser.printAST()
            
            # Import the various graph elements (subtreeVisitor creates the BVertex subclasses and appropriate edges)
            subtreeVisitor = SubtreeImporter(sidlimports[fileName], parentVertex=self, projectName = self.projectName)
            ast.accept(subtreeVisitor)
            packages = subtreeVisitor.getPackages()  
            interfaces = subtreeVisitor.getInterfaces()
            classes = subtreeVisitor.getClasses()
            methods = subtreeVisitor.getMethods()
                
            try: from cStringIO import StringIO
            except: from StringIO import StringIO
     
            for sym in methods.keys():
                # Get the BVertex
                v = pgraph.findSymbol(sym)[0]
                if v.kind not in ['interface', 'port', 'class', 'component']:
                    err('trying to import SIDL methods into ' + v.kind + '; methods can only be imported into interfaces, ports, classes, or components')
                    
                if not v._b_sidlFile:
                    v._b_sidlFile = os.path.join(self.project.getLocationManager().getSIDLLoc(v)[0], v.symbol + '.sidl')
                

                print >> DEBUGSTREAM, self.symbol + ' importing methods into %s: '%v._b_sidlFile +  str(methods[sym])

                # Configure the printer for the methods
                indentSize = v.getAttr('methodsIndent')
                if indentSize is None: indentSize = v.symbol.count('.') + 1
                
                printer = Printer(outstream = StringIO(), tab = tab*' ', initialIndent = indentSize, 
                                  commentExcludeList=['bocca\.splicer','Insert your\s*\w* methods here'])
                indentstr = indentSize*tab*' '
                
                # Generate comment splicers for the enclosing content
                commentsplicer =''
                if self.kind != 'package' and v.getComment():
                    commentsplicer = v.getCommentSplicerString(indentstr=(indentSize-1)*tab*' ')
                
                methodstr = commentsplicer
                
                # The methods string
                methodstr += self.getSIDLSplicerBeginString(indentstr, tag=sym + '.methods',  insertComment='Insert your ' + self.kind + ' methods here')                 
                for method in methods[sym]:
                    method.accept(printer)
                methodstr += printer.getOutStream().getvalue()
                methodstr += '\n' + self.getSIDLSplicerEndString(indentstr, tag=sym + '.methods') 

                print >> DEBUGSTREAM, '--import-sidl, about to import methods into ' + sym +': \n' + methodstr + '\n'
                sidlfile = os.path.join(self.project.getDir(),v._b_sidlFile)
                # Now import the methods                 
                retcode = mergeFromString(targetName=sidlfile, srcString=methodstr, srcName=sidlfile, 
                                  targetKey=self.getSIDLSplicerKey(), sourceKey=self.getSIDLSplicerKey(), 
                                  insertFirst=False, warn=WARN, replaceIdentical=False)
        
        # TODO: check this with babel (using builder plugin)
    
        return retcode

    def getASTNode(self):
        return self.astNode
    
    def setASTNode(self, astNode):
        import parse.itools.elements as ast
        self.astNode = astNode
        self.setComment(astNode.getStartComment())
        self.endComment = astNode.getEndComment()
        pass 
    
    def setComment(self, comment):
        self.startComment = comment
        pass
    
    def getComment(self):
        return self.startComment
    
    def getCommentSplicerString(self, indentstr='', extraSplicerComment=False, initialNewline=True):
        buf =''
        if initialNewline: buf += '\n'
        buf += self.getSIDLSplicerBeginString(indentstr, tag = self.symbol + '.comment', 
                                              extraSplicerComment=extraSplicerComment, 
                                              insertComment='Insert your ' + self.kind + ' comments here') 
        if self.startComment: buf += self._indentComment(indentstr, self.startComment, prependNewline=False) +'\n'
        buf += self.getSIDLSplicerEndString(indentstr, tag = self.symbol + '.comment')
        return buf
        
    #------------------------- PRIVATE Methods ------------------------
    
    def _getSerializableFields(self):
        '''Return a list of field names (strings) that will be serialized with pickle 
        and with the portable serializer. In addtion to those, the class name is serialized
        and any field whose identifier starts with _b_.
        '''
        return ['name', 'symbol', 'kind', 'version', 'modulePath', 'projectName', 'data', 'code']
    
    def _savePickle(self,filedesc,protocol=2):
        '''Given a filed escriptor of an open pickle file, 
        save everything necessary to recreate this vertex, omitting
        the edge list to avoid recursion.'''
        classname = str(self.__class__)
        # Get rid of leading cct., just save pkgname.classname
        # Also add package if classname doesn't already contain it
        if classname.count('.') == 0:
            classname = classname.lower() + '.' + classname
        elif classname.count('cct.') > 0:
            classname = classname[classname.find('cct.')+4:len(classname)]

        pickle.dump(classname, filedesc, protocol)   # Specific vertex class module name
        pickle.dump(self.name, filedesc, protocol)
        pickle.dump(self.symbol, filedesc, protocol)
        pickle.dump(self.kind, filedesc, protocol)
        pickle.dump(self.version, filedesc, protocol)
        #pickle.dump(self.options, filedesc, protocol)
        pickle.dump(self.args, filedesc, protocol)
        pickle.dump(self.modulePath, filedesc, protocol)
        pickle.dump(self.projectName, filedesc, protocol)
        pickle.dump(self.data, filedesc, protocol)
        pickle.dump(self.code, filedesc, protocol)
        # Now pickle any fields starting with _b_ :
        picklelist = []
        for member in self.__dict__.keys():
            if type(member) is str and member.startswith('_b_'):
                picklelist.append(member)
        pickle.dump(len(picklelist), filedesc, protocol)
        for item in picklelist:
            pickle.dump(item, filedesc, protocol)
            pickle.dump(self.__dict__[item], filedesc, protocol)
        #pickle.dump(self.defaults, filedesc, protocol)
        #pickle.dump(self.parser, filedesc, protocol)
        # Edges are deliberately omitted to avoid recursion
        return

    def _loadPickle(self,filedesc):
        '''Given a file descriptor of an open pickle file, recover 
        all fields of this vertex except for the edge list (which 
        is reconstructed when the edges are unpickled.'''
        self.name = pickle.load(filedesc)
        self.symbol = pickle.load(filedesc)
        self.kind = pickle.load(filedesc)
        self.version = pickle.load(filedesc)
        #self.options = pickle.load(filedesc)
        self.args = pickle.load(filedesc)
        self.modulePath = pickle.load(filedesc)
        self.projectName = pickle.load(filedesc)
        self.data = pickle.load(filedesc)
        self.code = pickle.load(filedesc)
        # Now load any fields starting with _b_ : 
        numberOfItems = pickle.load(filedesc)
        for i in range(0,numberOfItems):
            item = pickle.load(filedesc)
            self.__dict__[item] = pickle.load(filedesc)
        #self.defaults= pickle.load(filedesc)
        #self.parser= pickle.load(filedesc)
        # Edges are deliberately omitted to avoid recursion
        return self

    # End methods that can be overridden by subclasses
    #----------------------------------------------------------------------------------
              
    def _processParentSymbolOptions(self, optionval, optionstr='--extends/-e'):
        # --extends and --implements options
        parentSymbols = {}
        parentLocations = {}

        if len(optionval) > 0:
            # Populate a dictionary of type names and optionally locations of extended types.
            for val in optionval:
                parentSymbolInfo = val.strip('"').strip()
                portname = ''
                filepath = '%local%'
                
                colons = parentSymbolInfo.count(':')
                if (colons > 1 and self.kind != 'component') or (colons > 2 and self.kind == 'component'):
                    self.usage(2,'invalid argument syntax in ' + optionstr + ' option: %s' % parentSymbolInfo)
            
                if colons == 2 and self.kind == 'component':
                    sidlname, portname, filepath = parentSymbolInfo.split(':')
                elif colons == 1:
                    if self.kind == 'component':
                        # could be porttype:sidlfile or porttype:portname
                        sidlname, t2 = parentSymbolInfo.split(':')
                        if t2.lower().endswith('.sidl') or t2.lower().endswith('.xml') or t2.count(os.sep)>0:
                            filepath = t2
                        else:
                            portname = t2
                    else:
                        # sidl type and path to sidl or xml file
                        sidlname, filepath = parentSymbolInfo.split(':')
                elif colons == 0:
                    sidlname = parentSymbolInfo
                elif parentSymbolInfo.startswith('gov.cca'):
                    parentSymbols[parentSymbolInfo] = Globals().getCCAVars(projectName=self.projectName)['CCA_sidl']
                elif parentSymbolInfo.startswith('sidl.'):
                    # FIXME : when babel has a _sidl babel-config variable, use that
                    parentSymbols[parentSymbolInfo] = os.path.join(Globals().getCCAVars(projectName=self.projectName)['CCASPEC_BABEL_jardir'],'sidl.sidl')
                   
                # Check whether specified file exists
                # TODO: generalize this to handle URLs in addition to local files
                if filepath != '%local%':
                    if (not os.path.exists(filepath) or not os.path.isfile(filepath)):
                        self.usage(2,'Invalid path in ' + optionstr + ' option argument: ' + filepath)
                    elif not (filepath.lower().endswith('.sidl') or filepath.lower().endswith('.xml')):
                        # TODO: some more intelligent check (rather than just suffixes)    
                        # this should go in _utils.py, e.g., as a validateSIDLFile, validateXMLFile
                        self.usage(2,'File specified with ' + optionstr + ' option argument must be a valid SIDL or XML file: %s'%filepath)
                    
                if self.kind == 'component':
                    if not portname: portname = sidlname.split('.')[-1]
                    parentSymbols[portname] = sidlname
                    parentLocations[sidlname] = filepath
                else:
                    #parentSymbols[sidlname] = filepath
                    parentLocations[sidlname] = filepath

        if self.kind == 'component' and optionstr!='--extends/-e':
            return parentSymbols, parentLocations
        else:
            return parentLocations
    
    def _validateProjectSymbols(self, graph, symbols, portnames={}, kinds=['interface','port']):
        '''Private method: look for a list of symbols in a graph and return a list with their fully qualified SIDL symbols.
        @param symbols a dictionary whose keys are the sidl symbols to search for '''
        newdict = {}
        vertexlist = []
        for i in symbols.keys():

            # Check whether this interface is in the current project and if not, 
            # require the filename defining it (except for things in gov.cca namespace).
            ilist = []
            for kind in kinds:
                ilist += graph.findSymbol(i,kind) 
                
            if i.startswith('gov.cca.') or i.startswith('sidl.'):
                print >> DEBUGSTREAM, 'Extending a standard interface: ' + str(i)
                newdict[i] = symbols[i]
                continue

            if len(ilist) > 1:
                err('Multiple matching symbols found, please use a fully qualified SIDL symbol in the --extends  or --implements options')
            elif len(ilist) == 1:
                newdict[ilist[0].symbol] = symbols[i]
                for portname, porttype in portnames.iteritems():
                    if porttype == i: portnames[portname] = ilist[0].symbol
                vertexlist.append(ilist[0])
            else:
                err('The SIDL symbol ' + i + ' was not found in the current project.\n\
It must be added to the project before it can be extended or implemented, or the location of the external SIDL or XML file \
defining it must be specified, e.g. --extends sidltype:/path/to/file.sidl.')
                

        return newdict, vertexlist
    
    def _processImportArgs(self):
        sidlimports = {}
        for val in self.options.sidlimports:
            f = val.strip('"').strip()
            symbolList = []
            if f.count(':') == 1:
                symbols, fname = f.split(':')
                if symbols:
                    symbolList = []
                    for s in symbols.split(','):
                        symbolList.append(s.strip())
            elif f.count(':') > 1:
                err('incorrect syntax in --import-impl option, see "bocca help %s %s"' % (self.action,self.kind))
            else:
                fname = f
                symbolList = ['%all']
            if not os.path.exists(fname):
                err('could not find SIDL import file: ' + fname)
            
            sidlimports[fname] = symbolList
        self.setSIDLImports(sidlimports)
        pass
    
    def _indentComment(self,indentstr, comment,prependNewline=False):
        lst = comment.strip().split('\n')
        lst[0] = indentstr + lst[0] + '\n'
        if prependNewline: lst[0] = '\n' + lst[0]
        if len(lst) == 1: return lst[0]
        newcomment = lst[0]
        for l in lst[1:]:
            newcomment += indentstr + l + '\n'
        return newcomment
    
    def __getstate__(self):
        '''Need to break cycles to prevent recursion blowup in pickle.
        
        Dump everything except for edges.'''
        dcp = self.__dict__
        dcp['e'] = [] 
        #print 'BVertex __getstate__ called', dcp
        return dcp
    
    pass
    
        
    # ------------------ End of BVertex class ---------------------------
    
class BEdge(DirEdge):

    def __init__(self, v1, v2, graph=None, action='', name=None):
        if name is None:
            # generate as unique a name as possible
            name = v1.name + ':' + v2.name
        self.name = name
        DirEdge.__init__(self, name, v1, v2)
        self.action = action
        if graph != None:
            if v1.name not in graph.v.keys(): graph.add_v(v1)
            if v2.name not in graph.v.keys(): graph.add_v(v2)
            if self.name not in graph.e.keys(): graph.add_e(self)
            
    def __str__(self):
        return '%s -> %s [%s]' % (str(self.v[0]), str(self.v[1]), self.action)

    def _savePickle(self,filedesc,protocol=2):
        '''Given a filed escriptor of an open pickle file, 
        save everything necessary to recreate this vertex, omitting
        the edge list to avoid recursion.'''
        pickle.dump(self.v[0].name, filedesc, protocol)
        pickle.dump(self.v[1].name, filedesc, protocol)
        pickle.dump(self.name, filedesc, protocol)
        pickle.dump(self.action, filedesc, protocol)
        # Only save the unique vertex names to avoid saving the same vertex multiple times
        return
    
    def serializeASCII(self):
        '''Serialize the edge in a portable ASCII way.
        '''
        buf = '!edge\n'
        buf += 'name=%s|srcvertex=%s|destvertex=%s|action=%s\n' % (self.name, self.v[0].name, self.v[1].name, self.action)
        return buf
    
    def deserializeASCII(self, thestring):
        namevalpairs = thestring.strip().split('|')
        if len(namevalpairs) != 4:
            err('BEdge: the serialized string contains fewer items than expected.')
        for v in namevalpairs:
            key,val = v.split('=')
            if key == 'name': name = val
            if key == 'srcvertex': self.v[0].name = val
            if key == 'destvertex': self.v[1].name = val
            if key == 'action': self.action = val
        return 0
    deserializeASCII = staticmethod(deserializeASCII)
    
    pass
    # ---------------------- end of class BEdge ----------------------
   
class BGraph(Graph):
    '''This class is for directed graphs with vertices of arbitrary type'''
    def __init__(self, name = None, path = None, modulePath = None):
        '''Create a graph'''
        Graph.__init__(self, name)
        self.path = path
        self.modulePath = modulePath
        self.defaults = None
        return

    def _loadVertexClass(self, vclassName, modulePath):
        vclassModuleName = vclassName[0:vclassName.rfind('.')]
        vclassName = vclassName[vclassName.rfind('.') + 1:len(vclassName)]
        (file, filename, description) = imp.find_module(vclassModuleName, [modulePath])
        mod = imp.load_module(vclassModuleName, file, filename, description)
        vclass = getattr(mod, vclassName)
        v = vclass(symbol='temp')
        return v


#    def __str__(self):
#        return 'DirectedGraph with '+str(len(self.vertices))+' vertices and '+str(reduce(lambda k,l: k+l, [len(edgeList) for edgeList in self.inEdges.values()], 0))+' edges'

    def save(self, saveASCII=True, filename=None, startvertex=None, compressed=False):
        '''Save graph to a binary file, optionally in BZ2 compressed format'''
        
        if saveASCII: self.saveASCII(filename)
        
        # Note [TODO] perhaps we should disable the pickle if the ASCII save is good enough
        if filename is None: 
            filename = os.path.join(self.path, '.bocca', self.name+'.pickle')
        try:    
            if compressed:
                fout = BZ2File(filename, "w", copresslevel=3)
            else:
                fout = BFileManager().open(filename, "wb")
        except IOError, e:
            err('Could not save project state. Failed to open file ' + filename + '; ' + str(e))
        try:
            pickle.dump(self.name, fout, 2)
            #pickle.dump(self.path, fout, 2)
            pickle.dump(self.modulePath, fout, 2)
            pickle.dump(len(self.v), fout, 2)   # number of vertices
            for v in self.v.values():
                v._savePickle(fout,2)
            pickle.dump(len(self.e), fout, 2)   # number of edges
            for e in self.e.values():
                e._savePickle(fout,2)

            # Pickling the vertex and edge dictionaries caused very strange pickle behavior, so it is no longer done
            #pickle.dump(self.v, fout,2)
            #pickle.dump(self.e, fout,2)
            fout.close()
        except:
            raise
            err('Could not write out pickle file with project state.')
            
        # Also save in portable ASCII format
        return 0
    
    def load(self, filename=None, compressed=False, modulePath=None):
        '''Load graph from a binary file, optionally in BZ2 compressed format'''
        if modulePath: self.modulePath = modulePath
        if filename is None: 
            filename = os.path.join(self.path, '.bocca', self.name+'.pickle')
        try:
            fileSize = os.stat(filename)[stat.ST_SIZE]
        except os.error:
            fileSize=0
            return 1
        self.clear()
        if fileSize > 0:
            if compressed:
                fin = BZ2File(filename, "r")
            else:
                fin = open(filename, "r")
            self.name = pickle.load(fin)
            projname, mypath = getProjectInfo(self.name)
            if mypath: self.path = mypath
            else: print >>sys.stderr, 'Bocca ERROR: invalid project path'
            #self.path = pickle.load(fin)
            mPath = pickle.load(fin)
            if not self.modulePath: self.modulePath = mPath
            modulePath = os.path.join(self.modulePath,'cct')
            nv = pickle.load(fin)
            # Unpickle and recreate all vertices, instantiating the appropriate vertex class
            for i in range(0,nv):
                # This entire nastiness is needed because pickle chokes when dumping vertex subclasses
                vclassName = pickle.load(fin)
                #v = self._loadVertexClass(filename, vclassName, modulePath)
                vclassModuleName = vclassName[0:vclassName.rfind('.')]
                vclassName = vclassName[vclassName.rfind('.')+1:len(vclassName)]
                (file,filename,description) = imp.find_module(vclassModuleName,[modulePath])
                mod = imp.load_module(vclassModuleName, file, filename, description)
                vclass = getattr(mod, vclassName)
                v = vclass(symbol='temp')
                v = v._loadPickle(fin)
                # print 'Loaded vertex', v
                try:
                    self.add_v(v)
                except:
                    #warn('vertex already exists: ' + str(v))
                    pass
            # Now unpickle the edges. Currently only BEdge type is supported, but if eventual
            # subclasses need to be pickled, the same approach as for the vertices can be used
            ne = pickle.load(fin)
            for i in range(0,ne):
                v1name = pickle.load(fin)
                v2name = pickle.load(fin)
                edgeName = pickle.load(fin)
                edgeAction = pickle.load(fin)
                self.add_e(BEdge(v1=self.v[v1name], v2=self.v[v2name], action=edgeAction, name=edgeName))
            fin.close()
        return 0
    
    def saveASCII(self, filename = None):
        '''Save project state using an ASCII representation that is suitable for
        including in Makefiles and shell scripts'''
        if filename is None: 
            filename = os.path.join(self.path, 'BOCCA', self.name+'.ascii')
        fout = fileManager.open(filename, "w")
        buf = '!graph=' + str(self.name) + '|' + self.modulePath + '\n'
        for v in self.v.values():
            buf += v.serializeASCII()
        for e in self.e.values():
            buf += e.serializeASCII()
        buf += '\n'
        #print buf
        fout.write(buf)
        fout.close()
        return
    
    def loadASCII(self, filename=None, modulePath=None):
        if filename is None: 
            filename = os.path.join(self.path, 'BOCCA', self.name+'.ascii')
        try:
            fileSize = os.stat(filename)[stat.ST_SIZE]
        except os.error:
            fileSize=0
            return 1
        
        self.clear()
        
        if fileSize <= 0: 
            err('Could not load ASCII project information, file was empty: ' + filename)
        
        try:
            fin = open(filename, "r")
        except:
            return 1
        lines = fin.readlines()
        numlines = len(lines)
        modulePath = modulePath
        i = 0
        while i < numlines:
            val = ''
            if lines[i].startswith('!graph'):
                section, val = lines[i].split('=')
                self.name, self.modulePath = val.split('|')
                projname, mypath = getProjectInfo(self.name)
                if mypath: self.path = mypath
                else: print >>sys.stderr, 'Bocca ERROR: invalid project path'
                self.modulePath = self.modulePath.strip()
                if not os.path.exists(self.modulePath) and modulePath:
                    self.modulePath = modulePath
                modulePath = os.path.join(self.modulePath,'cct')
            elif lines[i].startswith('!vertex'):
                vclassName = lines[i].split('=')[1].strip()
                v = self._loadVertexClass(vclassName, modulePath)
                i += 1
                v.deserializeASCII(lines[i])
                print >>DEBUGSTREAM,'Deserialized vertex %s: '%v.symbol, v.serializeASCII()
                try:
                    self.add_v(v)
                except:
                    #warn('vertex already exists: ' + str(v))
                    pass
            elif lines[i].startswith('!edge'):
                i += 1
                namevalpairs = lines[i].strip().split('|')
                if len(namevalpairs) != 4:
                    err('BEdge: the serialized string contains fewer items than expected.')
                for v in namevalpairs:
                    key,val = v.split('=')
                    if key == 'name': edgeName = val
                    if key == 'srcvertex': v1name = val
                    if key == 'destvertex': v2name = val
                    if key == 'action': edgeAction = val
                self.add_e(BEdge(v1=self.v[v1name], v2=self.v[v2name], action=edgeAction, name=edgeName))

            i+= 1

        return 0
    
    def saveGraphvizFile(self, filename=None):
#        if filename is None: filename = str(self.name) + '.dot'
        pname, pdir = getProjectInfo(self.name)
        if filename is None :filename = os.path.join(pdir, '.bocca', pname+'.dot')
        fout = open(str(filename), "w")
        fout.write("digraph " + str(self.name) + " {")
        fout.write('node [ color=black\n style=filled\n fontname="Palatino"\n fontsize=12\n' +
                'shape = box\n color=lightgrey];\n')
        fout.write('edge [color=black, style=solid];\n')
        # TODO: makes this use one of the spanning tree algs instead of listing everything
        from graphlib.graph import bn_sorted
        for v in bn_sorted(self.v):
            fout.write(v._graphviz())
        for e in bn_sorted(self.e):
            fout.write('"' + e.v[0].name + '" -> "' + e.v[1].name + '"' + ' [color=cornflowerblue, label="' + str(e.action) + '", font="Palatino" fontsize=10, fontcolor=navyblue];\n')
        fout.write('label = "\\n\\nProject ' + str(self.name) + ' Diagram\\n";\n')
        fout.write('label = "Created with GraphViz by Bocca";\n')
        fout.write('fontsize=14;\n')            
        fout.write("}\n")
        fout.close()
        return
    
    def removeVertex(self, vertex):
        '''Delete all edges connected to the vertex, along with the vertex.'''
        for edge in vertex.all_e:
            del self.e[edge.name]
        del self.v[vertex.name]
        return
    
    def removeEdge(self, edge):
        '''Remove edge from vertices to which it is attached.'''
        del self.e[edge.name]
        
    def addSubgraph(self, graph):
        '''Add the vertices and edges of another graph into this one'''
        map(self.add_v, graph.v)
        map(lambda v: apply(self.add_e, (v,) + v.all_e()), graph.v)
        return

    def removeSubgraph(self, graph):
        '''Remove the vertices and edges of a subgraph, and all the edges connected to it'''
        map(self.removeVertex, graph.v)
        return

    # Query interface
    def containsSIDLSymbol(self, symbol, version='0.0'):
        ''' Returns True if the fully qualified SIDL symbol name is present in the graph (regardless
        of the kind of vertex), False otherwise. At present the version argument is not considered 
        in the comparisons.'''
        for key in self.v.keys():
            (k,sym,ver) = key.split('@')
            if sym == symbol:
                return True
        return False
        
    def findSymbol(self, symbol, kind='any', version='0.0'):
        '''Returns a list containing exactly one vertex if the fully qualified SIDL symbol 
        is in the graph, or a list of vertices that are partial matches to a non-fully
        qualified SIDL symbol, otherwise returns None. If a short (not fully qualified) 
        symbol name is given, returns the corresponding vertex if no ambiguity is found, 
        and raises a SymbolError otherwise.
        '''
        found = []            
        if version is None: version = '0.0'
        key = kind + '@' + symbol + '@' + version    
        if key in self.v.keys():         # fully-qualified symbol given
            return [self.v[key]]
        else:
            # This may be a partly qualified or a short symbol name
            for key in self.v.keys():
                (k, sym, ver) = key.split('@')

                if sym.endswith(symbol) and (k == kind or kind == 'any') and version == ver:
                    found.append(self.v[key])
        return found
        
    def renameVertex(self, vertex, newname):
        '''Rename a vertex and update all edges.'''
        
        if not vertex.name in self.v.keys():
            raise SymbolError(vertex.symbol, 'Symbol not found: ')
        # change vertex
        vertex.changeSymbol(newname)
        return
    
    # ------------- End of class BoccaGraph ----------------

#-------------------- Exception classes ---------------------------------
class SymbolError(Exception):
    '''Error to use when symbol cannot be found or is ambiguous'''
    def __init__(self, symbol=None, msg=''):
        self.symbol = symbol
        self.msg = msg
            
    def __str__(self):
        return self.msg + repr(self.symbol)
        
    
#################################################################################
if __name__ == '__main__':
    from cct.project import Project
    from cct.package import Package

    currdir = os.getcwd()
    sys.path.append(os.path.abspath(os.path.join(currdir, '..')))

    # These tests are temporarily broken while the needed types are all implemented
    G = BGraph(name='G')
    proj = Project(currdir, symbol='MyProject', graph=G)
    proj.data['default_language'] = 'cxx'
    pkg = G.addNestedPackages(symbol='anl.test', parentVertex=proj)
    i1 = Interface(symbol='anl.test.Solver', graph=G)
    e1 = BEdge(pkg, i1, G)
    i2 = Interface(symbol='anl.test.Printer', graph=G)
    e2 = BEdge(pkg, i2, G)
    c1 = Class(symbol='anl.test.MySolver', graph=G)
    e3 = BEdge(i2, c1, G)
    p1 = Port(symbol='anl.test.SolverPort', graph=G)
    ep1 = BEdge(i1, p1, G)
    pkg2 = G.addNestedPackages(symbol='cca', parentVertex=proj)
    p2 = Port(symbol='cca.SolverPort', graph=G)
    ep2 = BEdge(pkg2, p2, G)
    c2 = Component(symbol='anl.test.MySolverComponent', graph=G)
    e4 = BEdge(c1, c2, G)
    e5 = BEdge(p1, c2, action='provides', graph=G)
    l1 = Library(symbol="libMySolverComponent-f90.so", graph=G)
    e6 = BEdge(c2, l1, G)
    l2 = Library(symbol="libblas.a", graph=G)
    e7 = BEdge(l2, l1, G)
    
    #G.save('G.pickle')
    #G.clear()
    #G.load('G.pickle')
    # Graphs can also be loaded with _util.getProject(projName) which returns a Project vertex
    print G
    print 'DFS:', map(str, G.depth_first_search(pkg))
    print 'BFS:', map(str, G.breadth_first_search(pkg))
    print 'top sort:', map(str, G.topological_sort(pkg))
    
    dotfile = os.path.join(os.path.dirname(os.path.realpath(sys.argv[0])), str(G.name) + '.dot')
    print 'Saving to dot file ', str(dotfile), ' for visualization with GraphViz.'
    G.saveGraphvizFile(filename=dotfile);
    
    try:
        print 'Graph hasSymbol anl.test.SolverPort = ', G.hasSymbol('anl.test.SolverPort', 'port')
        print 'Graph hasSymbol SolverPort = ', G.hasSymbol('SolverPort', 'port')
    except SymbolError, e:
        print 'Caught a symbol error: ', e
    print 'Graph hasSymbol anl.test = ', G.hasSymbol('test', 'package')

