'''
The parameter passing modes
'''
IN = 0
OUT = 1
INOUT = 2
RETURN = 3
