from writers.sourceWriter import SourceWriter

def getWriterParameters():
    return (CxxWriter.language, CxxWriter.babelVersions)
 
class CxxWriter(SourceWriter):
    language = 'cxx'
    commentLineStart = "// "
    babelVersions = ['1.0.X', '1.1.X']

    def __init__(self):
        pass

#---------------------------------------------------------------------------------
    def getImplHeaderCode(self, componentSymbol):
        cmpt_ubar = componentSymbol.replace('.', '_')
        buf ="""
   // DO-NOT-DELETE splicer.begin(@CMPT_TYPE@._includes)
   // Insert-Code-Here {@CMPT_TYPE@._includes} (additional includes or code)
   // Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:_includes)
#include <iostream>
   // Bocca generated code. bocca.protected.end(@CMPT_TYPE@:_includes)

   // DO-NOT-DELETE splicer.end(@CMPT_TYPE@._includes)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@CMPT_TYPE_UBAR@', cmpt_ubar)
        return buf

#---------------------------------------------------------------------------------
    def getHeaderCode(self, componentSymbol):
        buf = """
   // DO-NOT-DELETE splicer.begin(@CMPT_TYPE@._implementation)

   // Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:_implementation)
    gov::cca::Services    """+self.servicesVariable+""";
    void boccaSetServices(gov::cca::Services& services); 
   // Bocca generated code. bocca.protected.end(@CMPT_TYPE@:_implementation)

    // DO-NOT-DELETE splicer.end(@CMPT_TYPE@._implementation)
"""    
        buf = buf.replace('@CMPT_TYPE@', componentSymbol)
        return buf
        
#---------------------------------------------------------------------------------
    def getSetServicesCode(self, componentSymbol):
        cmpt_ubar = componentSymbol.replace('.', '_')
        methodName = 'boccaSetServices'
        buf = """ 
  // DO-NOT-DELETE splicer.begin(@CMPT_TYPE@.setServices)

  // Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:setServices) 
     @METHOD_NAME@(services); 
  // Bocca generated code. bocca.protected.end(@CMPT_TYPE@:setServices) 
  
  // DO-NOT-DELETE splicer.end(@CMPT_TYPE@.setServices)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol). \
                  replace('@METHOD_NAME@', methodName)
        return buf

#---------------------------------------------------------------------------------
    def getAuxiliarySetServicesMethod(self, componentSymbol, provideDict={}, useDict={}):
        cmpt_ubar = componentSymbol.replace('.', '_')
        methodName = componentSymbol.replace('.', '::') +'_impl::boccaSetServices'
        buf = """
// DO-NOT-DELETE splicer.begin(@CMPT_TYPE@._misc)
// Insert-Code-Here {@CMPT_TYPE@._misc} (miscellaneous code)

// Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:boccaSetServices)
void
@METHOD_NAME@ (
  /* in */::gov::cca::Services& services )
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{

   using namespace std;
"""
# Add ports declarations (if needed)
        if (len(provideDict) + len(useDict) > 0):
            buf += """
   gov::cca::TypeMap typeMap;
   gov::cca::Port    port;
"""
# Component Registration code            
        buf +="""
   """+self.servicesVariable+""" = services;
"""
        if (len(provideDict) + len(useDict) > 0):
            buf += """
   try {
      typeMap = """+self.servicesVariable+""".createTypeMap();
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "@CMPT_TYPE@: Error creating CCA TypeMap- File:" << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }
"""
            if (len(provideDict) > 0):
                buf +="""
   port =  ::babel_cast<gov::cca::Port>(*this);
   if (port._is_nil()) {
      cerr << "@CMPT_TYPE@: Error casting component to gov::cca::Port - File : " 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   } 

"""
# Provide port(s) code
            for pName in provideDict.keys():
                portBuf = """
  // Provide a @PORT_TYPE@ port with port name @PORT_INSTANCE@ 
   try{
      """+self.servicesVariable+""".addProvidesPort(port,
                                        "@PORT_INSTANCE@",
                                        "@PORT_TYPE@",
                                        typeMap);
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "@CMPT_TYPE@: Error calling addProvidesPort for @PORT_TYPE@::@PORT_INSTANCE@ - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }    
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                                  replace('@PORT_TYPE@', provideDict[pName])
                buf += portBuf
            
# Use port(s) code
            for pName in useDict.keys():
                portBuf = """
  // Use a @PORT_TYPE@ port with port name @PORT_INSTANCE@ 
   try{
      """+self.servicesVariable+""".registerUsesPort("@PORT_INSTANCE@",
                                         "@PORT_TYPE@",
                                         typeMap);
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "@CMPT_TYPE@: Error calling registerUsesPort for @PORT_TYPE@::@PORT_INSTANCE@ - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                              replace('@PORT_TYPE@', useDict[pName])
                buf += portBuf
            buf += """
"""   
# Finish up, register for component release, and replace vars

        buf +="""
   gov::cca::ComponentRelease cr = ::babel_cast<gov::cca::ComponentRelease>(*this);
   """+self.servicesVariable+""".registerForRelease(cr);
   return;
}        
// Bocca generated code. bocca.protected.end(@CMPT_TYPE@:boccaSetServices)
    
// DO-NOT-DELETE splicer.end(@CMPT_TYPE@._misc)
"""
        buf = buf.replace('@CMPT_TYPE_UBAR@', cmpt_ubar).\
                  replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@METHOD_NAME@', methodName)
        return buf

#---------------------------------------------------------------------------------
    def getGoCode(self, componentSymbol, useDict={}):
        cmpt_ubar = componentSymbol.replace('.', '_')
        methodName = componentSymbol.replace('.', '::') +'_impl::boccaGoProlog'
        buf = """
// DO-NOT-DELETE splicer.begin(@CMPT_TYPE@.go)
@BOCCA_GO_PROLOG@

    // If this try/catch block is rewritten by the user, we will not change it.
    try {
      // All port instances should be rechecked for ._not_nil before calling in user code.
      // The user may not require all ports to be connected in all configurations.

      // Insert-Code-Here {@CMPT_TYPE@.go} 

      return 0;
   } catch (...) {
      return 2; 
      // if exceptions in the user code are tolerable and restart is ok, return 1 instead.
      // 2 means the component is so confused that it and probably the application should be
      // destroyed.
   }

@BOCCA_GO_EPILOG@
// DO-NOT-DELETE splicer.end(@CMPT_TYPE@.go)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol)
        prolog = self.getGoPrologCode(componentSymbol, useDict)
        epilog = self.getGoEpilogCode(componentSymbol, useDict)
        buf=buf.replace("@BOCCA_GO_PROLOG@", prolog)
        buf=buf.replace("@BOCCA_GO_EPILOG@", epilog)
        return buf
#---------------------------------------------------------------------------------
    def getGoPrologCode(self, componentSymbol, useDict={}):
        cmpt_ubar = componentSymbol.replace('.', '_')
        methodName = componentSymbol.replace('.', '::') +'_impl::boccaGoProlog'
        buf = """

// Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:boccaGoProlog)
"""
# Add local uses ports variables:
        if len(useDict) > 0:
            buf += """
   gov::cca::Port    port;
"""
            # Use port(s) code
            for uName in useDict.keys():
                portnativetype = useDict[uName].replace('.', '::')
                portBuf = """
  // Use a @PORT_TYPE@ port with port name @PORT_INSTANCE@ 
   try{
      port = """+self.servicesVariable+""".getPort("@PORT_INSTANCE@");
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "@CMPT_TYPE@: Error calling getPort for @PORT_TYPE@::@PORT_INSTANCE@ - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
   }
   @NATIVE_PORT_TYPE@ @PORT_INSTANCE@;
   bool @PORT_INSTANCE@_fetched = false;
   if ( port._is_nil() ) {
      cerr << "@CMPT_TYPE@: getPort(\\"@PORT_INSTANCE@\\") returned nil - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
   } else {
      @PORT_INSTANCE@_fetched = true; // even if the next cast fails, must release.
      @PORT_INSTANCE@ = ::babel_cast<@NATIVE_PORT_TYPE@>(port);
      if (@PORT_INSTANCE@._is_nil()) {
         cerr << "@CMPT_TYPE@: Error casting component to gov::cca::Port to @PORT_INSTANCE@ type @NATIVE_PORT_TYPE@ - File : " 
              << __FILE__ << " Line: " << __LINE__ << endl;
   } 
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', uName).\
                              replace('@PORT_TYPE@', useDict[uName]).\
                              replace('@NATIVE_PORT_TYPE@', portnativetype)
                buf += portBuf
            # end for uName
            buf += """
"""   
        # Finish up, and replace class vars
        buf +="""
// Bocca generated code. bocca.protected.end(@CMPT_TYPE@:boccaGoProlog)

"""
        buf = buf.replace('@CMPT_TYPE_UBAR@', cmpt_ubar).\
                  replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@METHOD_NAME@', methodName)
        return buf
    
#---------------------------------------------------------------------------------
    def getGoEpilogCode(self, componentSymbol, useDict={}):

        cmpt_ubar = componentSymbol.replace('.', '_')
        methodName = componentSymbol.replace('.', '::') +'_impl::boccaGoProlog'
        buf = """
// Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:boccaGoEpilog)
"""
# release local uses ports variables:
        if len(useDict) > 0:
            # release port(s) code
            for uName in useDict.keys():
                portBuf = """
   // release @PORT_INSTANCE@ 
   if (@PORT_INSTANCE@_fetched) {
      @PORT_INSTANCE@_fetched = false;
      try{
         """+self.servicesVariable+""".releasePort("@PORT_INSTANCE@");
      } catch ( ::gov::cca::CCAException ex )  {
         cerr << "@CMPT_TYPE@: Error calling releasePort for @PORT_INSTANCE@ - File:" 
              << __FILE__ << " Line: " << __LINE__ << endl;
      }
      // c++ port reference will be dropped when function exits.
   }
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', uName)
                buf += portBuf
            # end for uName
            buf += """
"""   
        # Finish up, and replace class vars
        buf +="""
// Bocca generated code. bocca.protected.end(@CMPT_TYPE@:boccaGoEpilog)
"""
        buf = buf.replace('@CMPT_TYPE_UBAR@', cmpt_ubar).\
                  replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@METHOD_NAME@', methodName)
        return buf
    
#---------------------------------------------------------------------------------
    def getReleaseMethod(self, componentSymbol, provideDict={}, useDict={}):
        buf = """
  // DO-NOT-DELETE splicer.begin(@CMPT_TYPE@.releaseServices)
  // Insert-Code-Here {@CMPT_TYPE@.releaseServices} (releaseServices method)

  // Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:releaseServices)

   using namespace std;
"""
# Un-provide provides ports
        for pName in provideDict.keys():
           portBuf = """
  // Un-provide @PORT_TYPE@ port with port name @PORT_INSTANCE@ 
   try{
      """+self.servicesVariable+""".removeProvidesPort("@PORT_INSTANCE@");
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "@CMPT_TYPE@: Error calling removeProvidesPort for port instance @PORT_INSTANCE@ - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }
"""
           portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                             replace('@PORT_TYPE@', provideDict[pName])
           buf += portBuf
           
# Use port(s) code
        for pName in useDict.keys():
           portBuf = """
  // Release @PORT_TYPE@ port with port name @PORT_INSTANCE@ 
   try{
      """+self.servicesVariable+""".releasePort("@PORT_INSTANCE@");
   } catch ( ::gov::cca::CCAException ex )  {
      cerr << "@CMPT_TYPE@: Error calling releasePort for port instance @PORT_INSTANCE@ - File:" 
           << __FILE__ << " Line: " << __LINE__ << endl;
      exit(1);
   }
"""
           portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                             replace('@PORT_TYPE@', useDict[pName])
           buf += portBuf
           
# Finish up, and substitute values
        buf += """
   """+self.servicesVariable+"""=0;
   return;
  // Bocca generated code. bocca.protected.end(@CMPT_TYPE@:releaseServices)
    
  // DO-NOT-DELETE splicer.end(@CMPT_TYPE@.releaseServices)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol)
        return buf
    
