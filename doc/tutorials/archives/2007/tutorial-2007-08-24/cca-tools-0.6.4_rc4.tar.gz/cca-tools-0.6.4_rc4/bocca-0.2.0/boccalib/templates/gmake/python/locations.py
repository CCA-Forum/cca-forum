import sys, os, re
import cct._debug

import builders.locations as locationTemplate
from graph.boccagraph import *
from cct import *
from cct._util import *

class LocationManager(locationTemplate.LocationManagerInterface):
    '''An interface for querying locations of sources, objects, and libraries.'''
    def __init__(self, project):
        self.project = project
        pass
    
    def getLanguages(self):
        '''Returns the list of languages with which the project has been configured.
        '''
        from fileinput import FileInput
        langs = []
        projectConfigFile = os.path.join(self.project.getDir(),'project.make')
        langline = ''
        for line in FileInput(projectConfigFile):
            m = re.match("USER_LANGUAGES =", line)
            if m:
                langline = line
        if langline is not '':
            langs = langline.split('=')[1].strip().split()
        #print >>DEBUGSTREAM, 'LocationManager: langugages = ' + str(langs)
        return langs

    def getXMLLoc(self):
        '''Returns a list of directories containing valid Babel XML repositories for 
        this project using relative paths (w.r.t. project).
        '''
        dirlist = []
        dirlist.append('xml_repository')
        return dirlist
    
    def getComponentLoc(self):
        ''' Returns a list of directories containing source code for components
        in this project (relative to top-level project directory)
        '''
        dirlist = ['components']
        return dirlist
    
    def getPortLoc(self):
        ''' Returns a list of directories containing source code for ports
        in this project (relative to top-level project directory)
        '''
        dirlist = ['ports']
        return dirlist
    
    def getSIDLLoc(self, vertex):
        '''Returns a 2-tuple (dir, [filelist]) containing the relative path (w.r.t. project) 
        and names of SIDL files.'''    
        dir = None
        flist = []
        if vertex.kind in ['interface','port']:
            dir = os.path.join('ports','sidl')
            flist = [vertex._b_sidlFile]
        elif vertex.kind in ['class', 'component']:
            dir = os.path.join('components','sidl')
            flist = [vertex._b_sidlFile]    
        return dir, flist
    
    def getImplLoc(self, vertex):
        '''Returns a 2-tuple (dir, [filelist]) containing the relative path (w.r.t. project)
         of impl files.
        '''
        mydir = None
        flist = []
        if vertex.kind == 'class' or vertex.kind == 'component':
            mydir = os.path.join('components', vertex.symbol)
            if vertex._b_language in ['python', 'java']:                
                packages = vertex.symbol.split('.')[:-1]
                for p in packages: mydir = os.path.join(mydir,p)
            if vertex._b_implHeader is not '': flist.append(vertex._b_implHeader)
            if vertex._b_implSource is not '': flist.append(vertex._b_implSource)
        return mydir, flist
    
    def getGlueLoc(self, vertex):
        '''Returns a list of directories where glue code is generated
        using relative paths from top project directory.'''
        dirs = []
        if vertex.kind == 'port' or vertex.kind == 'interface':
            for lang in self.getLanguages():
                dirs.append(os.path.join('ports',vertex.symbol,lang))
        elif vertex.kind == 'class' or vertex.kind == 'component':
            dirs.append(os.path.join('components',vertex.symbol,'glue'))
        return dirs

    def getBuildLibLoc(self,vertex,lang=None):
        '''Returns a list of directories containing libraries correponding to a vertex in the build tree.'''
        dirs = []
        if vertex.kind == 'port' or vertex.kind == 'interface':
            if not lang:
                for lang in self.getLanguages():
                    dirs.append(os.path.join('ports',vertex.symbol,lang))
            else:
                dirs.append(os.path.join('ports',vertex.symbol,lang))
        elif vertex.kind == 'class' or vertex.kind == 'component':
            dirs.append(os.path.join('components',vertex.symbol))
        return dirs
    
    def getBuildLibs(self, vertex, lang = None):
        '''Returs a [filelist] containing the relative path (w.r.t. project)
        of library names in the build tree.
        '''
        flist = []
        if vertex.kind in ['interface', 'port']:
            if not lang:
                for lang in self.getLanguages():
                    flist.append(os.path.join('ports',vertex.symbol, lang,'lib' + vertex.symbol + '-' + lang + '.la'))
            else:
                flist.append(os.path.join('ports',vertex.symbol, lang,'lib' + vertex.symbol + '-' + lang + '.la'))
        elif vertex.kind in ['class', 'component']:
            flist.append(os.path.join('components',vertex.symbol,'lib' + vertex.symbol.replace('.','_') + '.la'))
            
        #print >>DEBUGSTREAM, 'LocationManager: buildlibs = ' + str(flist)
        return flist

    def getInstallLibLoc(self,vertex):
        '''Returns the location of the library correponding to vertex in the installation location.'''
        mydir = None
        raise NotImplementedError        
        return mydir
    
    def getInstallIncludeLoc(self,vertex):
        '''Returns the include path correponding to vertex in the installation location.'''
        dir = None
        raise NotImplementedError        
        return dir    
    
    #=============== Private methods
    def _convert_template(self, template, opener='[', closer=']'):
        opener = re.escape(opener)
        closer = re.escape(closer)
        pattern = re.compile(opener + '([_A-Za-z.][_A-Za-z0-9.]*)' + closer)
        return re.sub(pattern, r'%(\1)s', template.replace('%','%%'))
    
    def _getProjectDir(self):
        return self.project.getAttr('projectDir')
