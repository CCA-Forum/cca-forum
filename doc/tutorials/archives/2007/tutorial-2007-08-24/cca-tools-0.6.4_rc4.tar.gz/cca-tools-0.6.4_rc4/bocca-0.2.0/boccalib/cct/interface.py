import os, sys, re
import cct._err, cct._debug, cct._validate
import splicers.Source
from splicers.Operations import renameFromFile, mergeFileIntoString, mergeFromString
from cct._util import *
from cct._file import *
from graph.boccagraph import *

class Interface(BVertex):
    def __init__(self, action = '__init__', args = None, project = None, modulePath = None,
                 symbol=None, version='0.0', graph=None, kind='interface'):
        '''bocca <verb> interface [options] SIDL_SYMBOL
        
        <verb> is one of create, change, remove, rename, display. For documentation on
        specific verbs, use 'bocca help <verb> interface'
        '''
        self.extends = {}
        self.newsymbol = None # For rename
        self._b_sidlFile=''
        self.tab = '    '
        self.displayAll = False
        BVertex.__init__(self,action,args,project,modulePath,kind,symbol,version,graph)
        # Use self.setAttr(key,value) to set various interface attributes 
        return 
        
    def defineArgs(self,action):
        if action == 'create' or action == 'change':
            self._defineImportArgs()
        if action == 'create':
            defaultLanguage = 'cxx'
            if self.project is not None:
                defaults = self.project.getDefaults()
                if defaults is not None: 
                    if 'Babel' in defaults.sections(): defaultLanguage = defaults.get('Babel','default_language')
                
            self.parser.set_defaults(languages=[defaultLanguage],sidlsymbol_and_location=[])
 
            self.parser.add_option('-l', '--languages', dest='languages', action='store',
                                   help='comma-separated list of languages in which to generate clients for this interface (default is all Babel-supported languages)')
            self.parser.add_option('-e', '--extends', dest='sidlsymbol_and_location', action='append',
                                   help='a SIDL interface that the ' + self.kind + ' being created extends (optional). ' 
                                   + 'Multiple --extends options can be specified. '
                                   + 'If SIDL_SYMBOL is an existing external interface, the file containing its definition must be '
                                   + 'specified immediately following the the SIDL_SYMBOL, ' 
                                   + 'e.g., --extends pkg.SomeInterface:/path/to/somefile.sidl (Babel-generated XML files are allowed, as well).'
                                   + 'To change the location of the SIDL file associated with an interface, use'
                                   + 'the "change ' + self.kind + ' +  SIDL_SYMBOL --sourcefile/-s FILENAME" command')
        elif action == 'edit':
            self.parser.add_option('-s', '--sidl', dest='editsidl', action='store_true',
                                   help="Edit the sidl file (the default)")
            self.parser.set_defaults(editsidl=True)            
        elif action == 'change':
            pass
        elif action == 'display':
            pass
        elif action == 'rename':
            pass
        elif action == 'remove':
            pass
        else:
            err('Interface verb "' + action + '" NOT implemented yet.', 3)

        return

    def processArgs(self, action):
        """ Validates and if necessary canonicalizes the command line arguments for
        this subject, which are parsed into self.options.
        Exits nonzero if user gives bad input.
        """
        if action == 'create':
            self._processCreateArgs()
        elif action == 'change':
            self._processChangeArgs()
        elif action == 'edit':
            self._processEditArgs()
        elif action == 'rename':
            self._processRenameArgs()
        elif action == 'remove':
            self._processRemoveArgs()
        elif action == 'display': 
            self._processDisplayArgs()
        return 
    
    
    
    def graphvizString(self): return 'shape=hexagon color=lightyellow1 fontname="Palatino-Italic"'

    def create(self):
        """ create interface INTERFACE [--extends/-e SIDL_SYMBOL{FILE}]
        
        Creates an interface with the name INTERFACE, optionally extending SIDL_SYMBOL.
        INTERFACE and SIDL_SYMBOL are both SIDL types. If INTERFACE is not fully 
        qualified, e.g., MyPort instead of somepackage.MyPort, the port will be added 
        to the default package for the project, usually the same as the project name.        
        """
        
        project,pgraph = Globals().getProjectAndGraph(self.projectName)
        
        self.validateNewSymbol(pgraph)  # From BVertex
 
        print >>DEBUGSTREAM,'create ' + self.kind + ', name = ', self.symbol, ' with languages: ', self.options.languages

        self.updateProjectState(project, pgraph)
        self.createSIDLFile(project, pgraph)
        #pgraph.saveGraphvizFile()
        
        if self.sidlImports: self.handleSIDLImports()

        self.project.getBuilder().changed([self])
        self.project.getBuilder().update()
        
        pgraph.save()
            
        print >>DEBUGSTREAM, 'create ' + self.kind + ' returning with code 0'
        return 0
    
 
        
    def change(self):
        """change interface [options] SIDL_SYMBOL

        """
            
        project, pgraph = Globals().getProjectAndGraph(self.project.symbol)
        self.validateExistingSymbol(pgraph)
        
        # Import operation
        if self.getSIDLImports(): 
            retcode = self.handleSIDLImports()
            if retcode != 0: err('could not import SIDL')

        self.project.getBuilder().changed([self] + list(self.dependents()))
        self.project.getBuilder().update()
        
        return 0

    def display(self):
        """display interface SIDL_SYMBOL
        
        """
        if self.displayAll:
            project, graph = Globals().getProjectAndGraph(projectName=self.projectName)
            if project:
                for v in project.getVertexList(kinds=[self.kind]):
                    print v.prettystr()
                    #v._b_sidlFile = os.path.join('ports','sidl',v.symbol+'.sidl')
            graph.save()
        else:
            return BVertex.display(self)
    
    def edit(self):
        '''edit interface SIDL_SYMBOL options
        '''     
        project,pgraph = Globals().getProjectAndGraph(self.projectName)
        self.validateExistingSymbol(pgraph)
                
        print >>DEBUGSTREAM,'edit ' + self.kind + ', name = ', self.symbol
        
        if self.options.editsidl:
            sidlfile = os.path.join(project.getDir(), self._b_sidlFile)
            if not sidlfile:
                err('Cannot find SIDL file : ' + str(sidlfile))
            print >>DEBUGSTREAM, 'editing ' + sidlfile
            try:
                editFile(sidlfile)
            except:
                err('Could not edit the file %s' % sidlfile)
        
        # TODO: check if the file really changed
        self.project.getBuilder().changed([self] + list(self.dependents()))
        self.project.getBuilder().update()
        
        return 0
    
    def remove(self):
        """remove interface [options] SIDL_SYMBOL
        
        Remove the specified interface from the project.
        """
        
        if len(self.args) != 1:
            self.usage(exitcode=4,errmsg='[remove ' + self.kind + '] The SIDL interface symbol must be specified.')
           
        project,pgraph = Globals().getProjectAndGraph(self.projectName)
        self.validateExistingSymbol(pgraph)

        print >>DEBUGSTREAM,'remove ' + self.kind + ', name = ', self.symbol
        
        dependents = list(self.dependents())
        
        # Remove vertex from project graph, including all connected edges 
        pgraph.removeVertex(self)
        # Remove build artifacts
        self.project.getBuilder().remove([self])

        # Remove the old SIDL file
        fileManager.rm(os.path.join(self.project.getDir(),self._b_sidlFile))
        
        # Now change all references in dependent vertices
        for v in dependents:
            v.removeInternalSymbol(self.symbol)

        self.setAttr('removed',True)
        self.project.getBuilder().changed([self] + dependents)
        self.project.getBuilder().update()
        
        # Save project graph
        retcode = pgraph.save()
        print >>DEBUGSTREAM, 'remove ' + self.kind + ' returning with code', retcode
        return retcode
    
    def rename(self):
        """rename interface [options] SIDL_SYMBOL NEWSIDL_SYMBOL
        
        Rename the interface specified with the SIDL symbol SIDL_SYMBOL to NEWSIDL_SYMBOL.
        The SIDL file containing the interface definition is also renamed.
        """
        if len(self.args) != 2:
            self.usage(exitcode=4,errmsg='[rename ' + self.kind + '] The old and new SIDL interface names must be specified.')
            self.newsymbol = self.args[1]
           
        project,pgraph = Globals().getProjectAndGraph(self.projectName)
        
        self.validateExistingSymbol(pgraph)
        
        if self.newsymbol is None:
            # TODO: Also add actual check for valid SIDL symbol names
            err('invalid SIDL symbol name: ' + str(self.newsymbol))
            
        status,self.newsymbol = cct._validate.sidlType(self.newsymbol,defaultPackage=self.symbol[0:self.symbol.rfind('.')], kind=self.kind, graph=pgraph)
        if pgraph.containsSIDLSymbol(self.newsymbol):
            err('[rename ' + self.kind + '] the specified SIDL symbol already exists: ' + str(pgraph.findSymbol(self.newsymbol, kind='any')[0]), 4)
 
        print >>DEBUGSTREAM,'rename ' + self.kind + ', name = ', self.symbol, ' to ', self.newsymbol
        
        # Read in current code
        oldFileName = os.path.join(self.project.getDir(), self._b_sidlFile)
        oldPkg = self.symbol[0:self.symbol.rfind('.')]
        newPkg = self.newsymbol[0:self.symbol.rfind('.')]
    
        # Remove buld artifacts
        self.project.getBuilder().remove([self])
            
        # Update the graph
        oldsymbol = self.symbol
        self.changeSymbol(self.newsymbol)
        
        if oldPkg != newPkg:
            pkg = project.addNestedPackages(symbol=self.symbol[0:self.symbol.rfind('.')])
            edge = BEdge(pkg, self, pgraph, action='contains')  # Connect with parent package, this adds self to graph

        newFileName = os.path.join(project.getAttr('projectDir'),self.project.getLocationManager().getSIDLLoc(self)[0],self.newsymbol+'.sidl')        
        #self.setAttr('sidlFileName', newFileName)
        self._b_sidlFile = os.path.join(self.project.getLocationManager().getSIDLLoc(self)[0], self.newsymbol+'.sidl')
        print >>DEBUGSTREAM, '[rename interface] vertex changed to: ' + str(self)
        
        # Do the actual rename
        result = renameFromFile(targetName=newFileName, srcName=oldFileName, 
                                targetBuffer=self.createSIDLString(newFileName,project,pgraph),
                                targetKey=self.getSIDLSplicerKey(), 
                                sourceKey=self.getSIDLSplicerKey(), 
                                oldtype=oldsymbol, newtype=self.newsymbol,
                                warn=False)
        if result != 0 or not os.path.exists(newFileName):
            err('rename ' + self.kind + ' failed to create a new SIDL file: ' + newFileName)

        # Remove the old file
        fileManager.rm(oldFileName)
        
        # Now change all references in dependent vertices
        for v in self.dependents():
            v.renameInternalSymbol(oldsymbol, self.symbol)

        self.project.getBuilder().changed([self] + list(self.dependents()))
        self.project.getBuilder().update()
        
        # Save project graph
        self.saveProjectState(pgraph, graphviz=True)
        print >>DEBUGSTREAM, 'rename ' + self.kind + ' returning with code 0'
        return 0

    
   
# -------------- Inherited "protected" methods
    def renameInternalSymbol(self, oldsymbol, newsymbol):
        '''Replaces any internal references to oldsymbol with newsymbol.'''
        extends = self.getAttr('extends')  # dictionary of extended symbol and their locations
        if oldsymbol not in extends.keys():
            return 0

        project,pgraph = Globals().getProjectAndGraph(self.projectName)
	if not self.project: self.project = project
        slist = pgraph.findSymbol(newsymbol)
        newvertex = slist[0]

        # Update the symbol in the list of symbols extended by this vertex
        extends[newvertex.symbol] = newvertex._b_sidlFile
        del extends[oldsymbol]
        self.setAttr('extends',extends)
        self.extends = extends
                
        # Merge the original file with the SIDL (string) with the renamed symbol
        retcode = self._mergeSIDLFileWithNewString(replaceIdentical=False)
        if retcode != 0:
            err('could not rename symbol ' + oldsymbol + ' to ' + newsymbol + ' in ' + self.symbol)
        if self.project is None: self.project = project

        return retcode
    
    def removeInternalSymbol(self, symbol):
        ''' Removes any internal references to symbol.'''
        project,pgraph = Globals().getProjectAndGraph(self.projectName)
	if not self.project: self.project = project
        extends = self.getAttr('extends')  # dictionary of extended symbol and their locations
        if symbol not in extends.keys():
            return 0

        # Remove the symbol from the list of symbols this vertex extends
        del extends[symbol]
        self.setAttr('extends',extends)
        self.extends = extends
                
        print >>DEBUGSTREAM, 'removeInternalSymbol: new extends =' + str(self.extends)
        # Merge the original SIDL file with the SIDL (stirng) with the symbol removed
        retcode = self._mergeSIDLFileWithNewString(replaceIdentical=False)
        if retcode != 0:
            err('could not remove symbol ' + symbol + ' from ' + self.symbol)

        return retcode
        
        
# ---------------------------------------------------
# -------------------- Private methods --------------

    def createSIDLString(self, sidlFileName, project, pgraph, extraSplicerComment=False):
        '''Create a list of lines that will go in the SIDL file.'''
        symbols = self.symbol.split('.')
        nsyms = len(symbols)
        shortInterfaceName = symbols[-1]
        extends = self.getAttr('extends')

        pkg = pgraph.findSymbol(symbol=symbols[0],kind='package')
        if len(pkg) != 1:
            errmsg = 'missing or ambiguous package name encountered: ' + symbols[0] 
            if len(pkg) > 1: errmsg += '(possibilties are ' + str(pkg) + ')'
            err(errmsg)
            
        defaults = project.getDefaults()
        topPackage = pkg[0]
        topVersion = topPackage.version
        pkgsymbol = topPackage.symbol
        buf = ''
        
        buf += topPackage.getCommentSplicerString(extraSplicerComment=extraSplicerComment)
        buf += 'package ' + symbols[0] + ' version ' + topVersion + ' {\n' 
        tab = int(re.split('\W+', defaults.get('SIDL','tab_size'))[0])*' '  # get rid of comments
        indent = 0
        # Handle nested packages
        for shortPkg in symbols[1:nsyms-1]:
            indent += 1
            pkgsymbol = pkgsymbol + '.' + shortPkg
            pkgs = pgraph.findSymbol(symbol=pkgsymbol, kind='package')
            if len(pkgs) != 1:
                errmsg = 'missing or ambiguous package name encountered: ' + pkgsymbol 
                if len(pkg) > 1: errmsg += '(possibilties are ' + str(pkg) + ')'
                err(errmsg)
            pkg = pkgs[0]
            if pkg is None: err('[create ' + self.kind + '] Package not properly added to graph, could not create sidl file.')
            buf += pkg.getCommentSplicerString(indentstr=indent*tab, extraSplicerComment=extraSplicerComment)
            if pkg.version != topVersion and pkg.version != '0.0':
                buf += indent*tab + 'package ' + shortPkg + ' version ' + pkg.version + ' {\n' 
            else:
                buf += indent*tab + 'package ' + shortPkg + ' {\n' 
               
        indent += 1
        save_indent = indent
        # Handle interfaces being extended if any specified with --extends/-e
        if len(extends) == 0:
            buf += self.getCommentSplicerString(indentstr=indent*tab, extraSplicerComment=extraSplicerComment)
            buf += indent*tab + 'interface ' + shortInterfaceName + '\n'     
        else:
            # Interfaces being extended (if any). TODO: should we check whether these exist?
            interfaces = extends.keys()
            buf += self.getCommentSplicerString(indentstr=indent*tab, extraSplicerComment=extraSplicerComment)
            firstline = indent*tab + 'interface ' + shortInterfaceName + ' extends ' + interfaces[0]
            buf += firstline
            if len(interfaces)>1: buf += ',\n'
            else: buf += '\n'
            indentstr = firstline.find(interfaces[0])*' '
            for i in range(1,len(interfaces)-1):
                buf += indentstr + interfaces[i] + ',\n' 
            if len(interfaces) > 1: buf += indentstr + interfaces[-1] + '\n'
            
        indent = save_indent

        buf += indent*tab + '{\n'
        indent += 1
        indentstr = indent*tab
        self.setAttr('methodsIndent', indent)
        buf += self.getSIDLSplicerBeginString(indentstr, tag = self.symbol + '.methods', 
                                              extraSplicerComment=extraSplicerComment, 
                                              insertComment='Insert your ' + self.kind + ' methods here') 
        buf += self.getSIDLSplicerEndString(indentstr, tag = self.symbol + '.methods') 
            
        indent -= 1
        buf += indent * tab + '};\n'
        
        for i in range(1,nsyms-1):
            indent -= 1
            buf += indent*tab + '}\n'
        indent = 0
        buf += '}\n'
        
        print >>DEBUGSTREAM, buf
               
        return buf
    
    def createSIDLFile(self, project, pgraph):
        # TODO: should interfaces go in ports/sidl?
        sidlFileName = os.path.join(self.project.getLocationManager().getSIDLLoc(self)[0],self.symbol+'.sidl')
        if os.path.exists(os.path.join(self.project.getDir(),sidlFileName)):
            err('[create ' + self.kind + '] ' + self.kind + ' SIDL file already exists: ' + sidlFileName,3)
        
        #self.setAttr('sidlFileName',sidlFileName)    
        self._b_sidlFile = sidlFileName

        sidlFileName = os.path.join(self.project.getDir(),sidlFileName)
        sidlSrc = splicers.Source.Source()
        status, msg = sidlSrc.loadString(input=sidlFileName, key='bocca.splicer', 
                                         linebuf=self.createSIDLString(sidlFileName, project, pgraph, extraSplicerComment=True), 
                                         warn=False)
        
        if status != 0:
            err(msg,status)
        print >>DEBUGSTREAM, '['+self.kind+'] loaded sidl file: ' + self._b_sidlFile

        sidlSrc.write(sidlFileName, rejectSave=False)
        print >>DEBUGSTREAM, '[create ' + self.kind + '] Interface sidl file was created:', sidlFileName

        return 
        
    def updateProjectState(self, project, pgraph):
        # Add packages if not already in the graph
        
        pkg = project.addNestedPackages(symbol=self.symbol[0:self.symbol.rfind('.')])
        edge = BEdge(pkg, self, pgraph, action='contains')  # Connect with parent package, this adds self to graph
        
        # Add edges to interfaces being extended (if any)
        if len(self.extends) > 0:
            self.extends, syms = self._validateProjectSymbols(pgraph, self.extends)
            for i in self.extends.keys():
                vlist = pgraph.findSymbol(i,kind='interface')
                
                if len(vlist) == 0: 
                    # Try a port
                    vlist = pgraph.findSymbol(i,kind='port')
                else:
                    v = vlist[0]
                if len(vlist) == 0:
                    # Create an interface vertex
                    v = Interface(symbol=i, project=self, version=self.version)
                else:
                    v = vlist[0]
                edge = BEdge(v, self, pgraph,action='extends')
        self.setAttr('extends',self.extends)
        
        
    ##---------------------------------------------------------------------------------------------------
    ##                        ------------- Private methods -----------------------
    ##---------------------------------------------------------------------------------------------------
    
    def _processCreateArgs(self):

        if len(self.args) < 1:
            self.usage(exitcode=4,errmsg='[create ' + self.kind + '] A SIDL interface name (e.g. packagename.InterfaceName) is required for interface creation.')

        self.symbol = self.args[0]
        
        # Canonicalize language names for interface clients
        canonicalLangs = []
        languages = []
        if self.options.languages.count(',') > 0: languages = self.options.languages.split(',')
        for l in languages:
            status, language = cct._validate.language(l)
            if status:
                self.usage(exitcode=2,errmsg='invalid language specified.')
            canonicalLangs.append(cct._validate.language(l)[1])
        
        self.options.languages = canonicalLangs   
            
        # --extends option
        if len(self.options.sidlsymbol_and_location) > 0:
            self.extends = self._processParentSymbolOptions(self.options.sidlsymbol_and_location, '--extends/-e')
            self.setAttr('extends',self.extends)
                    
        self._processImportArgs()
        pass
    
    def _processChangeArgs(self):
        if len(self.args) < 1:
            self.usage(exitcode=4,errmsg='[change ' + self.kind + '] The SIDL ' + self.kind + ' symbol must be specified.')
            
        if len(self.options.sidlsymbol_and_location) > 0:
            self.extends = self._processParentSymbolOptions(self.options.sidlsymbol_and_location, '--extends/-e')
            self.setAttr('extends',self.extends)
            
        # --extends option
        if len(self.options.sidlsymbol_and_location) > 0:
            self.extends = self._processParentSymbolOptions(self.options.sidlsymbol_and_location, '--extends/-e')
            self.setAttr('extends',self.extends)

        if self.options.sidlimports:
            self._processImportArgs()
        self.symbol = self.args[-1]
        pass
    
    def _processEditArgs(self):
        if len(self.args) != 1:
            self.usage(exitocode=4,errmsg='[edit ' + self.kind + '] Exactly one SIDL symbol must be specified.')
        self.symbol = self.args[0]
        pass

    def _processRenameArgs(self):
        if len(self.args) != 2:
            self.usage(exitcode=4,errmsg='[rename ' + self.kind + '] The old and new SIDL interface types must be specified.')

        if self.symbol is None:
            self.symbol = self.args[0]
        self.newsymbol = self.args[1]
        pass

    def _processRemoveArgs(self):
        if len(self.args) != 1:
            self.usage(exitcode=4, errmsg='[remove ' + self.kind + '] The SIDL interface type must be specified.')
            
        if self.symbol is None:
            self.symbol = self.args[0] 
        pass
    
    def _processDisplayArgs(self):
        if len(self.args) < 1:
            # display all
            self.displayAll = True
            if not self.symbol: self.symbol = 'temp'
        pass

    def _defineImportArgs(self):
        self.parser.set_defaults(sidlimports=[])
        self.parser.add_option('--import-sidl', dest='sidlimports', action='append', 
                               help='A SIDL file from which to import a specified interface or several interfaces, ' 
                               + 'e.g., --import-sidl="pkg.MySolverInterface,pkg.MyMatrixInterface:/path/to/file.sidl". ' 
                               + 'If no interface is specified (only the SIDL filename is given), all methods from '
                               + 'interfaces in the SIDL file are imported into the specified project ' + self.kind + '.')
        pass
    
    def _mergeSIDLFileWithNewString(self, replaceIdentical=False, targetFile=None):
        # Merge the original file with the newly generated SIDL (string) incorporating changes to parent interfaces   
        warn = False
        if 'BOCCA_DEBUG' in os.environ.keys():
            if os.environ['BOCCA_DEBUG'] == "1":
                warn = True    
                
        project,pgraph = Globals().getProjectAndGraph(self.projectName)    
        if targetFile is None: targetFile = os.path.join(project.getDir(),self._b_sidlFile)
                
        sidlFile = os.path.join(project.getDir(),self._b_sidlFile)    
        result = mergeFileIntoString(targetName=targetFile, 
                                 targetString=self.createSIDLString(sidlFile,project,pgraph),
                                 srcName=sidlFile,
                                 targetKey=self.getSIDLSplicerKey(), 
                                 sourceKey=self.getSIDLSplicerKey(), 
                                 insertFirst=False, warn=warn, verbose=False, 
                                 replaceIdentical=replaceIdentical)

        try:
            fileManager.writeStringToFile(sidlFile,result)
        except IOError,e:
            err('Could not write to file ' + sidlFile + ': ' + str(e))
        return 0
