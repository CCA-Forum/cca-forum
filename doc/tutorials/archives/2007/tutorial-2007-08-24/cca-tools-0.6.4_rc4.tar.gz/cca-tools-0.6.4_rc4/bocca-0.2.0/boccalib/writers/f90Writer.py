from writers.sourceWriter import SourceWriter

def getWriterParameters():
     return (F90Writer.language, F90Writer.babelVersions)
 
class F90Writer(SourceWriter):
    language = 'f90'
    commentLineStart = "C    "
    babelVersions = ['1.0.X', '1.1.X']

    def __init__(self):
        pass
    
    def getConstructorCode(self, componentSymbol):
        cmpt_ubar = componentSymbol.replace('.', '_')
        buf = """ 
! DO-NOT-DELETE splicer.begin(@CMPT_TYPE@._ctor)
! Insert the implementation here...
! Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:ctor)
  ! Access private data
  type(@CMPT_TYPE_UBAR@_wrap) :: dp
  ! Allocate memory and initialize
  allocate(dp%d_private_data)
  call set_null(dp%d_private_data%"""+self.servicesVariable+""")
  call @CMPT_TYPE_UBAR@__set_data_m(self, dp)
! Bocca generated code. bocca.protected.end(@CMPT_TYPE@:ctor)
! DO-NOT-DELETE splicer.end(@CMPT_TYPE@._ctor)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@CMPT_TYPE_UBAR@', cmpt_ubar)
        return buf
    
    def getHeaderCode(self, componentSymbol):
        cmpt_ubar = componentSymbol.replace('.', '_')
        buf = """
! DO-NOT-DELETE splicer.begin(@CMPT_TYPE@.use)
! Insert use statements here...

! Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:use)
! CCA framework services module
use gov_cca_Services
! Bocca generated code. bocca.protected.end(@CMPT_TYPE@:use)

! DO-NOT-DELETE splicer.end(@CMPT_TYPE@.use)

! DO-NOT-DELETE splicer.begin(@CMPT_TYPE@.private_data)

! Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:private_data)
  ! Handle to framework Services object
  type(gov_cca_Services_t) :: """+self.servicesVariable+"""
! Bocca generated code. bocca.protected.end(@CMPT_TYPE@:private_data)

! DO-NOT-DELETE splicer.end(@CMPT_TYPE@.private_data)
"""    
        buf = buf.replace('@CMPT_TYPE@', componentSymbol)
        return buf
        
    def getSetServicesCode(self, componentSymbol):
        className = componentSymbol.split('.')[-1]
        methodName = (className + '_boccaSetServices')[0:32]
        buf = """ 
! DO-NOT-DELETE splicer.begin(@CMPT_TYPE@.setServices)

! Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:setServices)
    call @METHOD_NAME@(self, services, exception)
! Bocca generated code. bocca.protected.end(@CMPT_TYPE@:setServices)
! DO-NOT-DELETE splicer.end(@CMPT_TYPE@.setServices)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@METHOD_NAME@', methodName)
        return buf
   
    def getAuxiliarySetServicesMethod(self, componentSymbol, provideDict={}, useDict={}):
        cmpt_ubar = componentSymbol.replace('.', '_')
        className = componentSymbol.split('.')[-1]
        methodName = (className + '_boccaSetServices')[0:32]
        buf = """
! DO-NOT-DELETE splicer.begin(_miscellaneous_code_end)
! Insert extra code here...

! Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:boccaSetServices)
subroutine @METHOD_NAME@(self, services, exception)
  use sidl
  use sidl_NotImplementedException
  use gov_cca_CCAException
  use gov_cca_Services
  use gov_cca_ComponentRelease
  use sidl_BaseInterface
  use sidl_RuntimeException
  use gov_cca_TypeMap
  use gov_cca_Port
  use @CMPT_TYPE_UBAR@
  use @CMPT_TYPE_UBAR@_impl

  type(@CMPT_TYPE_UBAR@_t) :: self ! in
  type(gov_cca_Services_t) :: services ! in
  type(sidl_BaseInterface_t) :: exception ! out
  
  type(@CMPT_TYPE_UBAR@_wrap) :: dp
  type(SIDL_BaseInterface_t) :: excpt, throwaway
  type(gov_cca_ComponentRelease_t) :: cr
"""
# Add ports declarations (if needed)
        if (len(provideDict) + len(useDict) > 0):
            buf += """
   type(gov_cca_TypeMap_t)    :: typeMap
   type(gov_cca_Port_t)       :: port
"""
# Component Registration code            
        buf +="""
   ! Access private data
   call @CMPT_TYPE_UBAR@__get_data_m(self, dp)

   ! Set my reference to the services handle
   dp%d_private_data%"""+self.servicesVariable+""" = services
   ! Increment reference count for the services subroutine parameter
   call addRef(services, throwaway)
"""
        if (len(provideDict) + len(useDict) > 0):
        
            buf += """
   call createTypeMap(dp%d_private_data%"""+self.servicesVariable+""", typeMap, excpt)
   call checkException(self, excpt,  &
        'Error creating typeMap', &
        .TRUE., throwaway)
"""
            if (len(provideDict) > 0):
                buf +="""
   call cast(self, port, excpt)
   call checkException(self, excpt,  &
        'Error casting component @CMPT_TYPE@ to gov.cca.Port', &
        .TRUE., throwaway)
"""
# Provide port(s) code
            for pName in provideDict.keys():
                portBuf = """
! Add @PORT_TYPE@:@PORT_INSTANCE@ provides port
   call addProvidesPort(dp%d_private_data%"""+self.servicesVariable+""", port, &
                       '@PORT_INSTANCE@', '@PORT_TYPE@', &
                       typeMap, excpt)
   call checkException(self, excpt,  &
        'Error calling addProvidesPort for port @PORT_TYPE@:@PORT_INSTANCE@:', &
        .TRUE., throwaway)
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                              replace('@PORT_TYPE@', provideDict[pName])
                buf += portBuf
            
# Use port(s) code
            for pName in useDict.keys():
                portBuf = """
! Register @PORT_TYPE@:@PORT_INSTANCE@ uses port
   call registerUsesPort(dp%d_private_data%"""+self.servicesVariable+""", &
                          '@PORT_INSTANCE@', '@PORT_TYPE@', &
                          typeMap, excpt)
   call checkException(self, excpt,  &
        'Error calling  registerUsesPort for port @PORT_TYPE@:@PORT_INSTANCE@:', &
        .TRUE., throwaway)
"""
                portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                              replace('@PORT_TYPE@', useDict[pName])
                buf += portBuf
                
# Finish up, register for release, and replace vars
        buf +="""
! Register component @CMPT_TYPE@ for release by the framework 
   call cast(self, cr, excpt)
   call checkException(self, excpt,  &
        'Error casting component @CMPT_TYPE@ to gov.cca.ComponentRelease', &
        .TRUE., throwaway)
   call registerForRelease(dp%d_private_data%"""+self.servicesVariable+""", cr, excpt)
   call checkException(self, excpt,  &
        'Error calling registerForRelease() for component @CMPT_TYPE@', &
        .TRUE., throwaway)
   
end subroutine @METHOD_NAME@   
! Bocca generated code. bocca.protected.end(@CMPT_TYPE@:boccaSetServices)
        
! DO-NOT-DELETE splicer.end(_miscellaneous_code_end)"""
        buf = buf.replace('@CMPT_TYPE_UBAR@', cmpt_ubar).\
                  replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@METHOD_NAME@', methodName)
        return buf
    
#---------------------------------------------------------------------------------
    def getReleaseMethod(self, componentSymbol, provideDict={}, useDict={}):
        cmpt_ubar = componentSymbol.replace('.', '_')
        buf = """
! DO-NOT-DELETE splicer.begin(@CMPT_TYPE@.releaseServices)
! Insert-Code-Here {@CMPT_TYPE@.releaseServices} (releaseServices method)

! Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:releaseServices)

  type(@CMPT_TYPE_UBAR@_wrap) :: dp
  type(SIDL_BaseInterface_t) :: excpt, throwaway
"""
# Component Registration code            
        buf +="""
! Access private data
   call @CMPT_TYPE_UBAR@__get_data_m(self, dp)
"""

# Un-provide provides ports
        for pName in provideDict.keys():
           portBuf = """
! Un-provide @PORT_TYPE@ port with port name @PORT_INSTANCE@ 
   call removeProvidesPort(dp%d_private_data%"""+self.servicesVariable+""", &
                          '@PORT_INSTANCE@', excpt)
   call checkException(self, excpt,  &
        'Error calling removeProvidesPort for port @PORT_TYPE@:@PORT_INSTANCE@:', &
        .TRUE., throwaway)
"""
           portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                             replace('@PORT_TYPE@', provideDict[pName])
           buf += portBuf
           
# Use port(s) release code
        for pName in useDict.keys():
           portBuf = """
! Release @PORT_TYPE@ port with port name @PORT_INSTANCE@ 
   call releasePort(dp%d_private_data%"""+self.servicesVariable+""", &
                          '@PORT_INSTANCE@', excpt)
   call checkException(self, excpt,  &
        'Error calling releasePort for port @PORT_TYPE@:@PORT_INSTANCE@:', &
        .TRUE., throwaway)
"""
           portBuf = portBuf.replace('@PORT_INSTANCE@', pName).\
                             replace('@PORT_TYPE@', useDict[pName])
           buf += portBuf
           
# Finish up, and substitute values
        buf += """
   call deleteRef(dp%d_private_data%"""+self.servicesVariable+""", throwaway)
   return;
! Bocca generated code. bocca.protected.end(@CMPT_TYPE@:releaseServices)
    
! DO-NOT-DELETE splicer.end(@CMPT_TYPE@.releaseServices)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol).\
                  replace('@CMPT_TYPE_UBAR@', cmpt_ubar)
        return buf
    
#---------------------------------------------------------------------------------
    def getCheckExceptionMethod(self, componentSymbol, provideDict={}, useDict={}):
        buf = """
! DO-NOT-DELETE splicer.begin(@CMPT_TYPE@.checkException)
! Insert-Code-Here {@CMPT_TYPE@.checkException} (checkException method)

! Bocca generated code. bocca.protected.begin(@CMPT_TYPE@:checkException)

  type(sidl_BaseInterface_t) :: throwaway  ! unused exception

  if (not_null(excpt)) then
      write(*, *) '@CMPT_TYPE@: ', msg
      call deleteRef(excpt, throwaway)
      if (fatal) stop
  end if
  return
! Bocca generated code. bocca.protected.end(@CMPT_TYPE@:checkException)
    
! DO-NOT-DELETE splicer.end(@CMPT_TYPE@.checkException)
"""
        buf = buf.replace('@CMPT_TYPE@', componentSymbol)
        return buf
    


