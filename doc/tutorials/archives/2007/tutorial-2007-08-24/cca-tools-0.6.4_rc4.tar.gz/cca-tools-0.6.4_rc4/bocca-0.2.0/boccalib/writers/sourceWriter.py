# We do not force overriding to be done for splices that may reasonably
# be empty in some languages.

class SourceWriter(object):
    language = "unknown"
    commentLineStart = "#error"
    commentLineEnd = ""
    servicesVariable = 'd_services' # from the sidl spec, 'services' is the only bad choice here.

    def __init__(self):
        pass

    def getImplHeaderCode(self, componentSymbol):
        return ''
    
    def getConstructorCode(self, componentSymbol):
        return ''
    
    def getHeaderCode(self, componentSymbol):
        return ''
    
    def getDestructorCode(self, componentSymbol):
        return ''

    def getSetServicesCode(self, componentSymbol):
        return self.commentLineStart + 'ERROR: FIXME getSetServicesCode in language writer ' + self.language + self.commentLineEnd

    def getAuxiliarySetServicesMethod(self, componentSymbol, provideDict={}, useDict={}):
        return self.commentLineStart + 'ERROR: FIXME getAuxiliarySetServicesMethod in language writer ' + self.language + self.commentLineEnd
    
    # used on initial generation of a component
    def getGoCode(self, componentSymbol, useDict={}):
        return self.commentLineStart + 'ERROR: FIXME getGoCode in language writer ' + self.language + self.commentLineEnd

    # used to regenerate go prolog block if uses list changes.
    def getGoPrologCode(self, componentSymbol, useDict={}):
        return self.commentLineStart + 'ERROR: FIXME getGoPrologCode in language writer ' + self.language + self.commentLineEnd
    
    # used to regenerate go epilog block if uses list changes.
    def getGoEpilogCode(self, componentSymbol, useDict={}):
        return self.commentLineStart + 'ERROR: FIXME getGoEpilogCode in language writer ' + self.language + self.commentLineEnd

    def getReleaseMethod(self, componentSymbol, provideDict={}, useDict={}):
        return ''
    
    def getCheckExceptionMethod(self, componentSymbol):
        return ''
