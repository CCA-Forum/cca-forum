""" Setting up a new project is the job of this script. Anything which
is also done by other cct commands is delegated to those.
This script must not be called directly from a command line; it
must be dispatched through bocca.
bocca init -h for usage.
"""

from cct._debug import DEBUGSTREAM, WARN
from cct._util import Globals, fileManager, mySplicer, lang_to_fileext, lang_to_headerext, editFile
from graph.boccagraph import BEdge, BVertex, SymbolError
from cct._err import err, warn
from cct._validate import language as validateLang
from cct.interface import Interface
import os, re
import glob
  
class Sidlclass(BVertex): 
    """Add new SIDL class to current project.
    """
    
    def __init__(self, action = '__init__', args = None, project = None, modulePath = None,
                 symbol=None, kind = 'class', version='0.0', graph=None):
        '''bocca <verb> class [options] SIDL_SYMBOL
        
        <verb> is one of create, change, remove, rename, display. For documentation on
        specific verbs, use 'bocca help <verb> sidlclass'
        '''

        self.implImports = {}
        if (symbol == 'temp'): 
            BVertex.__init__(self, action = action, 
                               args = args, modulePath = modulePath, 
                               project = project,
                               symbol = symbol, version = version, graph = graph)
            return
        
        self.project = project

        if self.project is not None:
            # Note that project can be None if we ended up here by way 
            # of 'bocca help', which is allowed outside of a project
            self.projectName =self.project.getName()
            self._b_projectDir = self.project.getDir()
            info = Globals().getProjectAndGraph(self.projectName)
            self.projectNode = info[0]
            self.graph = info[1]
            self._b_className = None
            self._b_packageName = None
            self.version = None

        self.action = action
        self._b_language = ''
        self._b_xmlRepos = []
        self._b_sidlFile=''
        self._b_implSource=''
        self._b_implHeader=''
        self.symbol=symbol
        self._b_externalSidlFiles=[]
        self._b_extends={}
        self._b_implements={}
        self.newSymbol = ''          # Only used during rename
        self.new_extends = {}        # Used in create and change
        self.new_implements = {}     # Used in create and change
        self.displayAll = False      # Used in display
        BVertex.__init__(self, action = action, 
                             args = args, modulePath = modulePath, 
                             project = project, kind = kind, 
                             symbol = symbol, version = version, graph=graph)
        pass

        
# ------------------------------------------------
    def defineArgs(self, action):
        '''Defines command line options and defaults for this command. This is 
           invoked in the constructor of the parent class Subcommand.
        '''
        if (action == 'create'):
            self.defineArgsCreate()
        elif (action == 'change'):
            self.defineArgsChange()
        elif (action == 'rename'):
            pass
        elif action == 'display':
            pass
        elif action == 'edit':
            self.defineArgsEdit()
        else:
            err('Sidlclass verb "' + action + '" NOT implemented yet.', 3)

        return
        
        
# ------------------------------------------------
    def defineCommonArgsCreateAndChange(self):
        '''Defines options common to the create and change operations.'''
        
        self.parser.add_option("-i", "--implements", dest="implemented_symbol", action="append",
                               help='a SIDL interface that the ' + self.kind + ' being created implements ' 
                               + '(optional, can be repeated). Multiple --extends options can be specified. '
                               + 'If IMPLEMENTED_SYMBOL is an existing external interface, the file containing its definition must be '
                               + 'specified immediately following the the IMPLEMENTED_SYMBOL, ' 
                               + 'e.g., --implements pkg.SomeInterface:/path/to/somefile.sidl (Babel-generated XML files are allowed, as well).'
                               + 'To change the location of the SIDL file associated with an interface, use'
                               + 'the "change ' + self.kind + ' +  SIDL_SYMBOL --sourcefile/-s FILENAME" command.')
        self.parser.add_option("-e", "--extends", dest="extended_symbol", action="store",
                               help='a SIDL class that the ' + self.kind + ' being created or modified extends (optional). ' 
                               + 'Only one --extends option can be specified. '
                               + 'If EXTENDED_SYMBOL is an existing external class, the file containing its definition must be '
                               + 'specified immediately following the the EXTENDED_SYMBOL, ' 
                               + 'e.g., --extends pkg.SomeClass:/path/to/somefile.sidl (Babel-generated XML files are allowed, as well).'
                               + 'To change the location of the SIDL file associated with a class, use'
                               + 'the "change ' + self.kind + ' +  SIDL_SYMBOL --sourcefile/-s FILENAME" command.')
        
        self._defineImportArgs()
        
        self.parser.add_option("-v", "--version", dest="version",
                          help="SIDL version of the " + self.kind+ " in the form X.Y. \
If no version specification is given, version '0.0' is used.")
        
        self.parser.add_option("-x", "--xml", dest="xmlRepos", action="append",
                          help="path to external XML repositories containing specification of the interfaces \
and/or classes implemented and/or extended by the new class (or of symbols refrenced by those interfaces). \
Multiple repositories can be used (separated by commas). Alternatively, multiple instances of the -x option \
can be used to specify multiple repositories paths.")
        
        self.parser.add_option("-s", "--sidl", dest="sidlFiles", action="append",
                          help="path to external SIDL files containing specification of the interfaces \
(class) implemented (extended) by the new class (or of symbols refrenced by those ports). Multiple files \
can be used (separated by commas). Alternatively, multiple instances of the -I option can be used to \
specify multiple SIDL files.")
        
        self.parser.add_option("-I", "--include", dest="includeDirs", action="append",
                          help="path to external interfaces (class) header files. Multiple paths \
can be used (separated by commas). Alternatively, multiple instances of the -I option can be used to \
specify multiple external directories.")

        self.parser.add_option("-L", "--library", dest="libraries", action="append",
                          help="FULL path to external libraries needed to build the " + self.kind + ". \
Multiple libraries can be used (separated by commas). Alternatively, multiple instances of the -L \
option can be used to specify multiple external libraries.")
        
    def defineArgsCreate(self):
        '''Defines command line options and defaults for the create action. 
        '''
        # Note that this method must work even when we are outside a project (for displaying help)
        defaultLanguage = 'cxx'
        if self.project is not None:
            defaults = self.project.getDefaults()
            if defaults is not None: 
                if 'Babel' in defaults.sections(): 
                    defaultLanguage = defaults.get('Babel','default_language')
            self._b_language = defaultLanguage
            
        print >> DEBUGSTREAM, "self.__class__.__name__ = ", self.__class__.__name__
        
        self.parser.add_option("-l", "--language", dest="language",
                          help="language for " + self.kind +" [project default is %s]"%defaultLanguage)
        
        self.defineCommonArgsCreateAndChange()
        
        self.parser.set_defaults(language=self._b_language,
                                 version = '0.0',
                                 xmlRepos=None,
                                 sidlFiles=None,
                                 implements = None,
                                 extends = None)
        return
    
    def defineArgsChange(self):
        self.defineCommonArgsCreateAndChange()
        self.parser.set_defaults(version = self.version,
                                 xmlRepos=None,
                                 sidlFiles=None,
                                 implements = None,
                                 extends = None)
        return
    
    def defineArgsEdit(self):
        self.parser.add_option('-H', '--header', dest='editheader', action='store_true',
                               help="Edit the header (or module in F90) file")
        self.parser.add_option('-m', '--module', dest='editheader', action='store_true',
                               help="Edit the header (or module in F90) file")
        self.parser.add_option('-i', '--implementation', dest='editimpl', action='store_true',
                               help="Edit the implementation file")
        self.parser.add_option('-s', '--sidl', dest='editsidl', action='store_true',
                               help="Edit the sidl file (the default)")
        self.parser.set_defaults(editheader=False, editimpl=False, editsidl=True)
        return
        
   
# ------------------------------------------------
    def processArgs(self, action):
        """ Dispatch argument processing based in required action
        """
        print >> DEBUGSTREAM, "Sidlclass called with options ", \
                              str(self.options) , " leaving args " , str(self.args)
        # Make sure we have handle to project and graph                              
        info = Globals().getProjectAndGraph(self.projectName)
        self.projectNode = info[0]
        self.graph = info[1]
        if (action == 'create'):
            self.processCreateArgs()
        elif (action == 'display'):
            self.processDisplayArgs()
        elif (action == 'rename'):
            self.processRenameArgs()
        elif (action == 'edit'):
            self.processEditArgs()
        else:
            err("Action "+ action + " NOT implemented yet", 3)
            
        return
    
    def processCommonCreateAndChangeArgs(self):
        options = self.options
        args = self.args

        if len(args) == 0: 
            self.usage(exitcode=4,errmsg='[' + self.action + ' ' + self.kind + '] The SIDL symbol argument on which to perform this command is missing.')
        if len(args) > 1:
            self.usage(exitcode=4,errmsg='[' + self.action + ' ' + self.kind + '] Only one SIDL symbol argument on which to perform this command must be given.')
            
        self.symbol = self.args[-1]   # BVertex takes care of prepending default package if necessary
        
# Extract and check external XML repos and SIDL files
        if (options.xmlRepos != None):
            self._b_xmlRepos = ','.join(options.xmlRepos).split(',')
            
        if (options.sidlFiles != None):
            self._b_externalSidlFiles = ','.join(options.sidlFiles).split(',')
            
        for r in self._b_xmlRepos:
            if not os.path.exists(r):
                err("XML repository " + r + " does not exist", 3)
                
        for f in self._b_externalSidlFiles:
            if not os.path.exists(f):
                err("SIDL File " + f + " does not exist", 3)
                
        if options.extended_symbol:
            self.new_extends = self._processParentSymbolOptions([options.extended_symbol], '--extends/-e')
            self._b_extends.update(self.new_extends)
                
        if options.implemented_symbol:
            self.new_implements = self._processParentSymbolOptions(options.implemented_symbol, '--implements/-i')
            self._b_implements.update(self.new_implements)
            
        if options.sidlimports or options.implimports:
            self._processImportArgs()
                    
        self._b_className = self.symbol.split('.')[-1]
        self._b_packageName = '.'.join(self.symbol.split('.')[:-1])
        
        print >> DEBUGSTREAM, "Sidlclass: className = ", self._b_className, \
            "\nSidlclass: packageName = ", self._b_packageName, \
            "\nSidlclass: implements = ", self._b_implements, \
            "\nSidlclass: extends = ", self._b_extends, \
            "\nSidlclass: new_implements = ", self.new_implements, \
            "\nSidlclass: new_extends = ", self.new_extends, \
            "\nSidlclass: symbol = ", self.symbol, \
            "\nSidlclass: language = ", self._b_language, \
            "\nSidlclass: xmlRepos = ", self._b_xmlRepos, \
            "\nSidlclass: sidlFiles = ", self._b_externalSidlFiles, \
            "\nSidlclass: sidlImports = ", self.getSIDLImports(), \
            "\nSidlclass: implImports = ", self.implImports
        
        return

    def processCreateArgs(self):
        """ Process command line arguments passed to the "sidlclass create" command
        """
        options = self.options
        args = self.args
        # Check for valid impl language
        status, self._b_language = validateLang(options.language)
        print >> DEBUGSTREAM, 'Language after validation: status = ', status, ', language = ', self._b_language
    

        self.processCommonCreateAndChangeArgs()
    
        self.version = options.version   
        
        print >> DEBUGSTREAM, "\nSidlclass: version = ", self.version 
        
        return 
   
    def processChangeArgs(self):
        if len(self.args) < 1:
            self.usage(exitcode=4,errmsg='[change ' + self.kind + '] The SIDL interface symbol must be specified.')
        
        if not self.graph: self.graph = Globals().getGraph(self.projectName)
        # Check whether component already exists in project
        self.symbol = self.args[-1]
        project,pgraph = Globals().getProjectAndGraph(self.projectName)
        self.validateExistingSymbol(self.graph)
        
        self.processCommonCreateAndChangeArgs()
        
        return 
    
    
    def processRenameArgs(self):
        """ Process command line arguments passed to the "class rename" command
        """
        from cct._validate import sidlType as validateSIDLType
        options = self.options
        args = self.args
        if len(self.args) != 2:
            self.usage(exitcode=4,errmsg='[rename ' + self.kind + \
                       '] The old and new SIDL types names must be specified.')
# Figure out old class name and package name
        if not self.graph: self.graph = Globals().getGraph(self.projectName)
        if not self.symbol: self.symbol = args[0]
        self.validateExistingSymbol(self.graph)
        self.newSymbol = args[1]
        
        status,self.newSymbol = validateSIDLType(self.newSymbol,defaultPackage=self.symbol[0:self.symbol.rfind('.')], kind=self.kind, graph=self.graph)
        if self.graph.containsSIDLSymbol(self.newSymbol):
            err('[rename ' + self.kind + '] the specified SIDL symbol already exists: ' + str(self.graph.findSymbol(self.newSymbol, kind='any')[0]), 4)
        
        print >> DEBUGSTREAM, 'Sidlclass: Renaming ', self.symbol , 'to ', self.newSymbol
        #self.symbol = self.newSymbol
        return

    def processRemoveArgs(self):
        """ Process command line arguments passed to the "class rename" command
        """
        options = self.options
        args = self.args
        if len(self.args) != 1:
            self.usage(exitcode=4,errmsg='[remove ' + self.kind + \
                       '] The SIDL symbol must be specified.')
        if self.symbol is None:
                self.symbol = self.args[0] 
                
        project,pgraph = Globals().getProjectAndGraph(self.projectName)
        self.validateExistingSymbol(self.graph)
             
        print >>DEBUGSTREAM,'remove ' + self.kind + ', name = ', self.symbol
        return 
    
    def processEditArgs(self):
        """ Process edit command line arguments passed to the "class edit" command
        """
        options = self.options
        args = self.args
        if len(self.args) != 1:
            self.usage(exitcode=4,errmsg='[edit ' + self.kind + \
                       '] Excactly one SIDL symbol must be specified.')
        if self.symbol is None:
                self.symbol = self.args[0] 
                
        slist = self.graph.findSymbol(self.symbol,self.kind, self.version)
        if len(slist) != 1:
            err('specified ' + self.kind + ' not found in this project and thus cannot be edited: ' + self.symbol)
             
        print >>DEBUGSTREAM,'edit ' + self.kind + ', name = ', self.symbol
        return 
    
    def processDisplayArgs(self):
        if len(self.args) < 1:
            # display all
            self.displayAll = True
            if not self.symbol: self.symbol = 'temp'
        pass

    
# ------------------- Begin BVertex command interface --------------------------

    def create(self):
        """create class SIDL_SYMBOL [options] 
        """
        # Validate vertex and update the project graph
        self.validateNewSymbol(self.graph)   # From BVertex  
        sidldir, sidlfiles = self.project.getLocationManager().getSIDLLoc(self)
        self._b_sidlFile = os.path.join(sidldir, self.symbol + '.sidl') # Relative to project root
        
        return self._createOrChange()
    
    def change(self):
        """change class SIDL_SYMBOL [options] 

        """
        # Any new change-specific handling goes here or after the call to _createOrChange
        retcode = self._createOrChange()
        self.display()
        return retcode

    def display(self):
        """display class SIDL_SYMBOL
        """
        
        if self.displayAll:
            project, graph = Globals().getProjectAndGraph(projectName=self.projectName)
            if project:
                for v in project.getVertexList(kinds=[self.kind]):
                    print v.prettystr()
        else:
            return BVertex.display(self)

        return 0

    def edit(self):
        '''edit class SIDL_SYMBOL options
        '''     
        print >>DEBUGSTREAM,'edit ' + self.kind + ', name = ', self.symbol
        header = None
        source = None
        sidlfile = None
        # My header and source filenames
        if self.options.editheader or self.options.editimpl:
            self._b_implHeader, self._b_implSource = self.getClassImplFilenames(self.symbol)
        if self._b_implHeader: header = os.path.join(self.project.getDir(),self._b_implHeader)
        if self._b_implSource: source = os.path.join(self.project.getDir(),self._b_implSource)
            
        if self.options.editheader:
            if self._b_language.lower() in ['java', 'python', 'f77']:
                err('Classes implemented in %s do not have a header or module file.'%self._b_language)
            if not header:
                err('Cannot find header or module file : ' + str(header))
            print >>DEBUGSTREAM, 'editing ' + header
            try:
                editFile(header)
            except:
                err('Could not edit the file %s' % header)
        elif self.options.editimpl:
            if not source:
                err('Cannot find header or module file : ' + str(source))
            print >>DEBUGSTREAM, 'editing ' + source
            try:
                editFile(source)
                pass
            except:
                err('Could not edit the file %s' % source)
        else:
            sidlfile = os.path.join(self.project.getDir(),self._b_sidlFile)
            if not sidlfile:
                err('Cannot find SIDL file : ' + str(sidlfile))
            print >>DEBUGSTREAM, 'editing ' + sidlfile
            try:
                editFile(sidlfile)
            except:
                err('Could not edit the file %s' % sidlfile)

        return 0
   
# ------------------------------------------------
    def rename(self):
        """rename class OLD_SIDL_SYMBOL NEW_SIDL_SYMBOL
        """
        self._internalRename()
        self.saveProjectState(self.graph, graphviz=True)
        self.display()
        return 0
    
    def remove(self):
        """remove class SIDL_SYMBOL
        """
        # STATUS: not finished yet!
        # Remove the old SIDL file
        fileManager.rm(self._b_sidlFile)

        # Remove the impls
        fileManager.rm(self._b_implHeader)
        fileManager.rm(self._b_implSource)
        # TODO: remove glue code (get location from LocationManager)
        
        # Now change all references in dependent vertices
        for v in self.dependents():
            v.removeInternalSymbol(self.symbol)

        # Remove vertex from project graph, including all connected edges 
        pgraph.removeVertex(self)
        
        # TODO: remove any libraries generated (must interact with Builder plugin)
        
        # Save project graph
        retcode = pgraph.save()
        print >>DEBUGSTREAM, 'remove ' + self.kind + ' returning with code', retcode
        return retcode       
    
    def prettystr(self):
        s =  self.kind + ' ' + self.symbol + ' ' + self.version
        
        if len(self._b_implements) > 0:
            s+=  '\n\timplements interfaces:\n'
            for i in self._b_implements.keys(): s +=  '\t  ' + i + ' ' + '\n'

        if len(self._b_extends) > 0:
            s += '\n\textends class: ', self._b_extends.keys()[0] + '\n'
            
        s +=  '\n\timplementation is in: ' +  str(self._b_implSource) + '\n'
        return s

    
    # ---------------- end of BVertex command interface implementations --------------------------
   
    def getClassImplFilenames(self, symbol, impldir=None):
        """ Set names of source and header impl files for this class based on
            the given symbol. All file names are relative to self.projectDir
        """
        implHeader=''
        myimpldir, impls = self.project.getLocationManager().getImplLoc(self)
        if impldir is None: impldir = myimpldir
        if (self._b_language == 'python'):
            implSource = os.path.join(impldir, symbol.split('.')[-1] + '_Impl.py')
            return None, implSource

        if (self._b_language == 'java'):
            implSource = os.path.join(impldir, symbol.split('.')[-1] + '_Impl.java')
            return None, implSource
               
        implSource = symbol.replace('.','_') + '_Impl.' + \
                           lang_to_fileext(self._b_language)
        implSource = os.path.join(impldir, implSource)

        if (self._b_language.upper() =='F77'):
            return None, implSource
        
        hext = lang_to_headerext(self._b_language)
        if (self._b_language.upper() == 'F90'):
            newImplHeaderFile = symbol.replace('.','_') + '_Mod.F90'
        else: 
            newImplHeaderFile = symbol.replace('.','_') + '_Impl.' + hext
            
        implHeader = os.path.join(impldir, newImplHeaderFile)
        return implHeader, implSource
        

    def genClassSidlString(self, extraSplicerComment=False):
        
        extendedClass = ''
        implementedInterfaces = []
        if self._b_extends: extendedClass = self._b_extends.keys()[0]
        if self._b_implements: implementedInterfaces = self._b_implements.keys()
        if self.kind == 'component':
            implementedInterfaces.insert(0,'gov.cca.Component')
            implementedInterfaces.insert(1,'gov.cca.ComponentRelease')
            implementedInterfaces.extend(self._b_providesPorts.values())
        
        indent = int(re.split('\W+', self.project.getDefaults().get('SIDL','tab_size'))[0])*' '
        level = 0
        buf = ''
        pkglist = self.symbol.split('.')[:-1]
        fullpkg = ''
        while(len(pkglist) > 0):
            pkg = pkglist.pop(0)
            fullpkg = (fullpkg + '.' + pkg).lstrip('.')
            nodeList = self.graph.findSymbol(fullpkg, kind='package')
            if (len(nodeList) == 0):
                err('Internal BOCCA error - missing package ' + fullpkg, 4)
            node = nodeList[0]
            buf += node.getCommentSplicerString(indentstr=indent*level, extraSplicerComment=extraSplicerComment)
            buf += indent*level + 'package %s version %s {\n' % (pkg, node.version)
            pkg = pkg + '.'
            level = level + 1

        buf += self.getCommentSplicerString(indentstr=indent*level, extraSplicerComment=extraSplicerComment)
        buf += indent * level + 'class %s ' %(self._b_className)
        if extendedClass:
            buf += ' extends %s \n' % (extendedClass)
        
        if len(implementedInterfaces) > 0 :
            if extendedClass: buf += indent * (level+2) 
            buf += 'implements-all ' + ', '.join(implementedInterfaces) 
            
        buf += '\n' + indent * level +'{\n'
        level += 1
        self.setAttr('methodsIndent',level)
        buf += self.getSIDLSplicerBeginString(indent * level, tag = self.symbol + '.methods',
                                              extraSplicerComment=extraSplicerComment, 
                                              insertComment='Insert your ' + self.kind + ' methods here') 
        buf += self.getSIDLSplicerEndString(indent * level, tag = self.symbol + '.methods')
            
        if self.kind == 'component':
            indentstr = indent * level
            count = 0
            args = ''
            buf += '\n\n' + indentstr + \
                '//-----------------------------------------------------------------------------\n' + \
                 indentstr + \
                '// DO-NOT-DELETE bocca.protected.begin(bocca:%s:boccaPrivateMethods)\n' % (self.symbol)
            buf += indentstr + \
                '/*\n'
            buf += indentstr + \
                '   Function to display a message if an exception occurs.\n'
            buf += indentstr + \
                '   @param excpt the exception to be checked.\n'
            buf += indentstr + \
                '   @param msg the message to be printed or added to the exception if fatal is true.\n'
            buf += indentstr + \
                '   @param fatal if an exception occured and fatal is false, msg is printed.\n'
            buf += indentstr + \
                '                If fatal is true, msg is printed and exit called.\n' 
            buf += indentstr + \
                '*/\n'
            buf += indentstr + \
                'void checkException(in sidl.BaseInterface excpt, in string msg, in bool fatal);\n'
            for uport in self._b_usesPorts.values():
                args += 'in ' + uport + ' ' + 'dummy'+str(count)+', '
                count+=1
            if (count > 0):
                args = args.rstrip(', ')
                buf += indentstr + 'void boccaForceUsePortInclude(' + args + ');\n'
                
            buf += indentstr + \
                '// DO-NOT-DELETE bocca.protected.end(bocca:%s:boccaPrivateMethods)\n' % (self.symbol)
            # ---------- end component-specific code -------------   
        level -= 1
        while (level >= 0):
            buf += indent*level + '}\n'
            level = level - 1
            
        buf += '\n'
        print >> DEBUGSTREAM , buf
        return buf
    
    def genClassSidlFile(self):
        buf = self.genClassSidlString(extraSplicerComment=True)
        fd = fileManager.open(os.path.join(self._b_projectDir, self._b_sidlFile), "w")
        fd.write(buf)
        fd.close()
        return 0

    def genClassImpl(self):
        if not self.project: self.project,graph=Globals().getProjectAndGraph()
        return self.project.getBuilder().genImpls(self)

    def spliceBoccaBlocks(self):
        return 
    
# -----------------------------------------------------------------------------    
    def updateGraph(self):
        
        if self.action == 'create':
            self._b_packageName = self.symbol[0:self.symbol.rfind('.')]
            pkg = self.project.addNestedPackages(symbol=self._b_packageName)
            edge = BEdge(pkg, self, self.graph, action='contains')  # Connect with parent package, this adds self to graph
            self._b_implHeader, self._b_implSource = self.getClassImplFilenames(self.symbol)
        
        #  Check existence of interface nodes in project graph and add edges
        self.new_implements, vertices = self._validateProjectSymbols(self.graph, self.new_implements, kinds=['interface','port'])
        for ifaceNode in vertices:
            edge = BEdge(ifaceNode, self, graph=self.graph, action = 'implements')  # Connect with implemented interface
            # Add the new interfaces 
            self._b_implements.update(self.new_implements)
        
        # Check for existence of class/component nodes in project graph and add edges
        self.new_extends, vertices = self._validateProjectSymbols(self.graph, self.new_extends, kinds = ['class','component'])
        if vertices:
            edge = BEdge(vertices[0], self, graph = self.graph, action='extends')  # Connect with extended class
            if self._b_extends:
                self._b_extends.clear()   # Only one class can be extended
                self._b_extends = self.new_extends
                
        return
    
    def handleImports(self):
        self._b_implHeader, self._b_implSource = self.getClassImplFilenames(self.symbol)
        if self.getSIDLImports():
            retcode = self.handleSIDLImports()
            if retcode is not 0:
                err('could not import one or more SIDL files')        
        
            self.genClassImpl()
                    
        if self.implImports:
            retcode = self._handleImplImports()
            if retcode is not 0:
                err('could not import one or more implementation files')
        return

    def graphvizString(self): return 'shape=doubleoctagon color=firebrick1 fontname="Palatino-Italic"'

# -------------- Inherited "protected" methods

    def renameInternalSymbol(self, oldSymbol, newSymbol):
        '''Replaces any internal references to oldSymbol with newSymbol.'''
        
        project,graph = Globals().getProjectAndGraph(self.projectName)
        slist = graph.findSymbol(newSymbol)
        newvertex = slist[0] 
        
        if self._b_extends and oldSymbol in self._b_extends.keys():
            self._b_extends.clear()
            self._b_extends = newvertex
        elif self._b_implements and oldSymbol in self._b_implements.keys():
            self._b_implements[newSymbol] = newvertex._b_sidlFile
            del self._b_implements[oldSymbol]
        else:
            return
        
        self._replaceSymbolInFiles(oldSymbol, newSymbol)

        return 0


    def removeInternalSymbol(self, symbol):
        ''' Removes any internal references to symbol.'''
        self.project,self.graph = Globals().getProjectAndGraph(self.projectName)
        
        if self._b_extends == symbol:
            self._b_extends = ''
        elif symbol in self._b_implements:
            self._b_implements.remove(symbol)
        else:
            return 0
        
        self._removeSymbolInFiles(symbol)
# FIXME: We're doin this to check that the sed approach actually work.            
        self.genClassImpl()
        return 0
    
    def setASTNode(self, astNode):
        import parse.itools.elements as ast
        self.astNode = astNode
    
    #---------------------------------------------------------------------------------------
    # ------------------------- Private methods --------------------------------------------
    

    def _createOrChange(self):
              
        self.updateGraph()
        
        # Generate code
        self.genClassSidlFile()
        self.genClassImpl()

        self.project.getBuilder().update(buildFilesOnly=True)
        
        self.spliceBoccaBlocks()
        self.handleImports()
        
        # Update List of project classes and SIDL files in the build system
        self.project.getBuilder().changed([self])
        self.project.getBuilder().update(quiet=True)
        
        # Save the graph (including dot visualization)
        self.saveProjectState(self.graph, graphviz=True)
        return 0        
        
    
    def _defineImportArgs(self):
        self.parser.set_defaults(sidlimports=[], implimports=[])
        self.parser.add_option('--import-sidl', dest='sidlimports', action='append', 
                               help='A SIDL file from which to import a specified class or several classes, '
                               + 'e.g., --import-sidl="/path/to/file.sidl:pkg.MySolverClass,pkg.MyMatrixClass". '
                               + 'If no class is specified (only the SIDL filename is given), all methods from '
                               + 'interfaces and classes in the SIDL file are imported into the specified '
                               + 'project ' + self.kind + '.')
        self.parser.add_option('--import-impl', dest='implimports', action='append', 
                               help='A Babel-generated Impl file from which to import method implementations ' 
                               + ' from the specified class or several classes (with multiple --import-impl options), '
                               + 'e.g., --import-impl="pkg.MyClass:/path/to/pkg_MyClass/". ')

        pass
    
    def _processImportArgs(self):

        BVertex._processImportArgs(self)
            
        for sym in self.options.implimports:
            
            if sym.count(':') is 0:
                err('the --import-impl option requires a SIDL symbol and path to its implementation, e.g., --import-impl="pkg.MyClass:/path/to/pkg_MyClass/"')
            symbol, implpath = sym.strip('"').split(':')
            if not os.path.exists(implpath) or not os.path.isdir(implpath):
                err('the path specified in the --import-impl option does not exist or is not a directory: ' + implpath)
            
            self.implImports[symbol] = implpath

        pass
        
    def _handleImplImports(self):
        from splicers.Operations import mergeFiles
        for sym in self.implImports.keys():
            impldir = self.implImports[sym]
            # Assume that all impls (headers, modules, sources) are in the same directory (impldir)
            # The header and source filenames of the files to be imported
            saveimpldir = impldir
            if self._b_language in ['python', 'java']:                
                packages = sym.split('.')[:-1]
                for p in packages: impldir = os.path.join(impldir,p)
                 
            implHeader, implSource = self.getClassImplFilenames(sym,impldir=impldir)
            
            if not os.path.exists(implSource) and self._b_language in ['python', 'java']:
                # Perhaps the user gave a full path to the impls
                implHeader, implSource = self.getClassImplFilenames(sym,impldir=saveimpldir)
                impldir = saveimpldir

            # My header and source filenames
            self._b_implHeader, self._b_implSource = self.getClassImplFilenames(self.symbol)
            projDir = self.project.getAttr('projectDir')
            if self._b_implHeader: os.path.join(projDir,self._b_implHeader)
            if self._b_implSource: os.path.join(projDir,self._b_implSource)
            print >>DEBUGSTREAM,'--------------> importing from : ' + str(implHeader), str(implSource)
            
            if not os.path.exists(implSource):
                err('could not find implementation source file to import: ' + implSource)
            
                print " test drive merge unnested " # merge(append) source into target blocks of same name

            # Get list of exclude symbols from defaults file
            excludeSyms = []
            excludestr = self.project.getDefaultValue('exclude_from_import', section='Project')
            if excludestr: 
                for e in excludestr.split(','): excludeSyms.append(e.strip())

            # Merge the implementation into this class's implementation
            retcode = mergeFiles(srcName=implSource,
                                 targetName=self._b_implSource, 
                                 sourceKey='DO-NOT-DELETE splicer', 
                                 targetKey='DO-NOT-DELETE splicer',
                                 insertFirst=False, replaceIdentical=False,
                                 oldtype=sym, newtype=self.symbol, methodMatch=True,
                                 excludeSyms = excludeSyms,
                                 dryrun=False, dbg=WARN, verbose=WARN, warn=WARN)
            if retcode is not 0:
                err('could not import implementation source: ' + implSource)
            
            # Splice the header, if any
            if not (implHeader is None or self._b_implHeader is None):
                if not os.path.exists(implHeader):
                    err('could not find implementation header or module file to import: ' + implHeader)
                            # Merge the implementation into this class's implementation
                retcode = mergeFiles(srcName=implHeader, 
                                     targetName=self._b_implHeader, 
                                     sourceKey='DO-NOT-DELETE splicer', 
                                     targetKey='DO-NOT-DELETE splicer', 
                                     insertFirst=False, replaceIdentical=False,
                                     oldtype=sym, newtype=self.symbol, methodMatch=True,
                                     dryrun=False, dbg=WARN, verbose=WARN, warn=WARN)
                if retcode is not 0:
                    err('could not import implementation header or module: ' + implSource)  
                 
        return 0

    def _replaceSymbolInFiles(self, oldSymbol, newSymbol):
        
# Rename symbol in sidl file
# TODO: regenerate the SIDL
# FIXME : Is a simple sed approach enough?. or do we want to re-generate?
        fd = fileManager.open(os.path.join(self._b_projectDir, self._b_sidlFile), "r")
        newBuf = fd.read()
        fd.close()
        newBuf = newBuf.replace(oldSymbol, newSymbol)
        fd = fileManager.open(os.path.join(self._b_projectDir, self._b_sidlFile), "w")
        fd.write(newBuf)
        fd.close()
        
# TODO: update the impls
# FIXME: Is a simple sed approach enough?. or do we want to re-generate?
        replaceList = [(oldSymbol, newSymbol)]
        replaceList.append((oldSymbol.replace('.', '_'), newSymbol.replace('.', '_')))
        replaceList.append((oldSymbol.replace('.', '::'), newSymbol.replace('.', '::')))

        fileList = [self._b_implSource]
        if (self._b_language != 'f77' and self._b_language != 'python'):
            fileList.append(self._b_implHeader)
        for f in fileList:
            print >> DEBUGSTREAM, 'Replacing %s with %s in %s' %(oldSymbol, newSymbol, f)
            fd = fileManager.open(os.path.join(self._b_projectDir, f), "r")
            oldBuf = fd.read()
            fd.close()
            for (old, new) in replaceList:
                oldBuf = oldBuf.replace(old, new)
            fd = fileManager.open(os.path.join(self._b_projectDir, f), "w")
            fd.write(oldBuf)
            fd.close()
        return 0
    
    def _internalRename(self):
        from copy import deepcopy
        oldSidlFile = self._b_sidlFile
        oldSymbol= self.symbol
        oldPackageName = self._b_packageName
        oldClassName = self._b_className
        oldImplSource = self._b_implSource
        oldImplHeader = self._b_implHeader
        oldCompDir = self.project.getLocationManager().getImplLoc(self)[0]
	oldself = self.clone()
        
        print >> DEBUGSTREAM, 'sidlclass::_internalRename() oldSidlFile = ', oldSidlFile, \
            '\nsidlclass::_internalRename() oldSymbol = ', oldSymbol, \
            '\nsidlclass::_internalRename() oldPackageName = ', oldPackageName, \
            '\nsidlclass::_internalRename() oldClassName = ', oldClassName, \
            '\nsidlclass::_internalRename() oldImplSource = ', oldImplSource, \
            '\nsidlclass::_internalRename() oldImplHeader = ', oldImplHeader
        
        self._b_packageName = self.newSymbol[0:self.newSymbol.rfind('.')]
        self._b_className = self.newSymbol.split('.')[-1]
        self._b_sidlFile = os.path.join("components", "sidl", self.newSymbol+'.sidl')
        
        print >> DEBUGSTREAM, "", \
            '\nsidlclass::_internalRename() self._b_packageName = ', self._b_packageName, \
            '\nsidlclass::_internalRename() self._b_className = ', self._b_className, \
            '\nsidlclass::_internalRename() self._b_sidlFile = ', self._b_sidlFile, \
            '\nsidlclass::_internalRename() self._b_implSource = ', self._b_implSource, \
            '\nsidlclass::_internalRename() self._b_implHeader = ', self._b_implHeader, \
            '\nsidlclass::_internalRename() self.newSymbol = ', self.newSymbol, \
            '\nsidlclass::_internalRename() self._b_projectDir = ', self._b_projectDir

        
        # Update the symbol in the vertex (updating all edges)    
        self.changeSymbol(self.newSymbol)
        self._b_implHeader, self._b_implSource = self.getClassImplFilenames(self.newSymbol)
        self.genClassSidlFile()        # Generate empty new class sidl file
        
        # Splice method declarations (if any) from old sidl file to new one
        fd = fileManager.open(os.path.join(self._b_projectDir, self._b_sidlFile), "r")
        newBuf = fd.read()
        
        fd = fileManager.open(os.path.join(self._b_projectDir, oldSidlFile), "r")
        oldBuf = fd.read()
        
        # Temporary cludge until Ben's splicer is more user friendly
        newString = 'bocca.splicer.begin(%s.methods)' % (self.newSymbol)
        oldString = 'bocca.splicer.begin(%s.methods)' % (oldSymbol)
        oldBuf = oldBuf.replace(oldString, newString)
        newString = 'bocca.splicer.end(%s.methods)' % (self.newSymbol)
        oldString = 'bocca.splicer.end(%s.methods)' % (oldSymbol)
        oldBuf = oldBuf.replace(oldString, newString)
# FIXME: Do we replace symbols in user code?        
        oldBuf = oldBuf.replace(oldSymbol, self.newSymbol)
        newBuf = mySplicer(oldBuf, newBuf, 'bocca.splicer.begin(', 
                           'bocca.splicer.end(', mode='REPLACE')
        fd = fileManager.open(os.path.join(self._b_projectDir, self._b_sidlFile), "w")
        fd.write(newBuf)
        fd.close()
        
        # Generate new impls
        self.genClassImpl()
        
        # Splice old impls into new impls
        # Splice method implementation (if any) from old sidl file to new one
        fd = fileManager.open(os.path.join(self._b_projectDir, self._b_implSource), "r")
        newBuf = fd.read()
        print>> DEBUGSTREAM, self._b_projectDir, oldImplSource
        fd = fileManager.open(os.path.join(self._b_projectDir, oldImplSource), "r")
        oldBuf = fd.read()
        
        replaceList = [(oldSymbol, self.newSymbol)]
        replaceList.append((oldSymbol.replace('.', '_'), self.newSymbol.replace('.', '_')))
        replaceList.append((oldSymbol.replace('.', '::'), self.newSymbol.replace('.', '::')))

        for (old, new) in replaceList:
            oldBuf = oldBuf.replace(old, new)
        
        # Temporary cludge until Ben's splicer is more user friendly
        newBuf = mySplicer(oldBuf, newBuf, 'splicer.begin(', 
                           'splicer.end(', mode='REPLACE')
        fd = fileManager.open(os.path.join(self._b_projectDir, self._b_implSource), "w")
        fd.write(newBuf)
        fd.close()
        
        if (self._b_language.upper() != 'F77'):
# Splice code into impl header file
            fd = fileManager.open(os.path.join(self._b_projectDir, self._b_implHeader), "r")
            newBuf = fd.read()
            
            fd = fileManager.open(os.path.join(self._b_projectDir, oldImplHeader), "r")
            oldBuf = fd.read()
            
            for (old, new) in replaceList:
                oldBuf = oldBuf.replace(old, new)
        
# Temporary cludge until Ben's splicer is more user friendly
            newBuf = mySplicer(oldBuf, newBuf, 'splicer.begin(', 
                               'splicer.end(', mode='REPLACE')
            print >> DEBUGSTREAM, newBuf
            fd = fileManager.open(os.path.join(self._b_projectDir, self._b_implHeader), "w")
            fd.write(newBuf)
        
# Update my dependents' internal symbols
        for node in self.dependents():
            node.renameInternalSymbol(oldSymbol, self.newSymbol)


        # Remove old sidl file
        fileManager.rm(oldSidlFile)
        
        self.project.getBuilder().remove([oldself])
                
        self.project.getBuilder().changed([self] + list(self.dependents()))
        self.project.getBuilder().update(quiet=True)
        return

    def _removeSymbolInFiles(self, symbol):
# TODO: update the impls
# FIXME: Is a simple sed approach enough?. or do we want to re-generate?
        removeList = [symbol]
        removeList.extend([symbol.replace('.', '_'), symbol.replace('.','::')])

        fileList = [self._b_implSource]
        if self._b_language.upper() not in ['F77', 'python', 'java']:
            fileList.append(self._b_implHeader)
            
        # First, regenerate all generated code with the symbol removed
        
        # TODO: how should removal in user code be really handled???
        # below is the rename logic
        #for f in fileList:
        #    print >> DEBUGSTREAM, 'Removing %s in %s' %(symbol, f)
        #    fd = fileManager.open(os.path.join(self._b_projectDir, f), "r")
        #    oldBuf = fd.read()
        #    fd.close()
        #    for (old, new) in replaceList:
        #        oldBuf = oldBuf.replace(old, new)
        #    fd = fileManager.open(os.path.join(self._b_projectDir, f), "w")
        #    fd.write(oldBuf)
        #    fd.close()
        return 0

        
if __name__ == "__main__":
    Sidlclass().usage()
