import sys, os
from cct._err import err
from graph.boccagraph import *

class BuilderInterface:
    '''An interface to different build system implementations.'''
    
    def __init__(self, modulePath, project):
        '''Constructor
        @param modulePath the directory containing the implementation of the BuilderInterface
        '''
        if self.__class__ is BuilderInterface: raise NotImplementedError   
        if str(project.__class__) != 'project.Project':
            err("Builder plugin: invoking update on a vertex that is not a Project: " + str(project.__class__))

        self.project = project      
        # Load the local LocationManagerInterface implementation
        try:
            (file,filename,description) = imp.find_module('locations',[modulePath])
            locations = imp.load_module('locations', file, filename, description)
        except ImportError,e:
            err('Builder: Could not import locations module from ' + modulePath + ': ' + str(e))
        try:
            LocationManagerClass = getattr(locations,'LocationManager')
        except AttributeError,e:
            err('Builder: Could not find LocationManager class for current build template in ' + modulePath+ ': ' + str(e))
            
        self.locationManager =self.project.getLocationManager()
        self.changedList = []

        pass
    
    def update(self, buildFilesOnly=False, quiet=False):
        '''Given a new project graph, update build information. 
        @param buildFilesOnly: Only update files contaning component and port info.
        '''
        status = 0
        if self.__class__ is BuilderInterface: raise NotImplementedError        
        return status
    
    def genSIDL(self, vertex):
        '''Generates SIDL files correposnding to the vertex argument.
        
        Returns a 2-tuple with the status code (Unix-like) and 
        a list of newly created files.'''
        status = 0
        files = []
        if self.__class__ is BuilderInterface: raise NotImplementedError
        return status, files

    def genXML(self, vertex):
        '''Generates XML corresponding to the vertex argument.
        
        Returns a 2-tuple with the status code (Unix-like) and 
        a list of newly created files.'''
        status = 0
        files = []
        if self.__class__ is BuilderInterface: raise NotImplementedError
        return status, files
    
    def genImpls(self, vertex):
        '''Generates Impls corresponding to the vertex argument.
        
        Returns a 2-tuple with the status code (Unix-like) and 
        a list of newly created files.'''
        status = 0
        files = []
        if self.__class__ is BuilderInterface: raise NotImplementedError
        return status, files
    
    def genObjects(self, vertex):
        '''Generates object files corresponding to the vertex argument.
        
        Returns a 2-tuple with the status code (Unix-like) and 
        a list of newly created files.'''
        status = 0
        files = []
        if self.__class__ is BuilderInterface: raise NotImplementedError
        return status, files    
    
    def genLibs(self, vertexList):
        '''Generates libraries for all the vertices in vertexList.
        
        Returns a 2-tuple with the status code (Unix-like) and 
        a list of newly created files.'''
        status = 0
        files = []
        if self.__class__ is BuilderInterface: raise NotImplementedError
        return status, files    

    def genTests(self, vertexList):
        '''Generates libraries for all the vertices in vertexList.
        
        Returns a 2-tuple with the status code (Unix-like) and 
        a list of newly created files.'''
        status = 0
        files = []
        if self.__class__ is BuilderInterface: raise NotImplementedError
        return status, files    
    
    def changed(self, vertexList):
        '''This is how the builder is notified of changes to a list of vertices.
        The build system will perform whatever actions are necessary on these
        vertices during a subsequent update call.
        '''
        if self.__class__ is BuilderInterface: raise NotImplementedError
        return self.changedList
    
    def remove(self, vertexList):
        ''' Removes build-relevant information associated with vertices in vertexList.
        Returns 0 upon success, 1 otherwise.
        '''
        if self.__class__ is BuilderInterface: raise NotImplementedError
        return 1
    
    def install(self, vertex=None):
        '''Install the specified vertex, if None, install the whole project.'''
        status = 0
        if self.__class__ is BuilderInterface: raise NotImplementedError
        return status


        
        
