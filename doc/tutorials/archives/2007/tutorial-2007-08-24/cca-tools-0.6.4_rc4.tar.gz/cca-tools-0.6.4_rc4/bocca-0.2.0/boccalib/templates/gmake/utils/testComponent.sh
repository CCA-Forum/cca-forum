#!/bin/sh

function usage () {
	echo -e "\nUsage:\n\tsh $0 <rcfile> <lib_dir> <ccaffeine_executable> <ccafe-config>\n\n"\
		"This script adds a small Ccaffeine resource control (rc) script fragment\n"\
		"that set the dynamic  library search path to <lib_dir>\n"\
		" Arguments (all are required): \n"\
		"            rcfile is the full path name of the target Ccaffeine RC file\n"\
		"	     lib_dir is the full path location of the dynamic libraries\n"\
		"            ccaffeine_executable is the full path to the ccaffeine executable\n"\
		"            ccafe-config is the full path to the ccafe-config executable \n" > /dev/stderr
}

if [ $# -lt 2 ];  then
	usage
	exit 1;
fi

rcfilearg=$1
rcfiledir=`dirname $1`
lib=$2
ccafe=$3
ccafeconfig=$4
#pythondir=$5
#pythonver=$6
instantiate_only="0"

if [ ! -f "$rcfilearg" ] ; then 
    echo -e "*** Error: Could not run tests, didn't find $rcfilearg file."; 
    exit 0;
fi 
if [ "x`grep \"^go \" $rcfilearg`" == "x" ] ; then
  if [ "x`grep \"^connect \" $rcfilearg`" == "x" ] ; then
    echo "Running instantiation tests only";
    instantiate_only="1";
  fi 
fi
if [ "x`echo $rcfilearg | grep \.incl`" != "x" ]; then 
    rcfile="`echo $rcfilearg | sed -e 's|\.incl||'`";
    sed -e "/@CCA_COMPONENT_PATH@/ s|@CCA_COMPONENT_PATH@|${lib}|" $rcfilearg > $rcfile;
else
    rcfile=$rcfilearg
fi

ccaspecconfig=`$ccafeconfig --var CCAFE_CCA_SPEC_BABEL_CONFIG`
CCASPEC_libdir=`$ccaspecconfig --var CCASPEC_libdir `
CCASPEC_pkglibdir=`$ccaspecconfig --var CCASPEC_pkglibdir `
CCASPEC_BABEL_libdir=`$ccaspecconfig --var CCASPEC_BABEL_libdir`
CCASPEC_BABEL_LANGUAGES=`$ccaspecconfig --var CCASPEC_BABEL_LANGUAGES`

# Env. variable settings
LD_RUN_PATH=$CCASPEC_libdir
if [ "x$LD_LIBRARY_PATH" == "x" ] ; then
  LD_LIBRARY_PATH=$LD_RUN_PATH:
else
  LD_LIBRARY_PATH=$CCASPEC_BABEL_libdir:$CCASPEC_libdir:$LD_LIBRARY_PATH
fi
export LD_RUN_PATH
export LD_LIBRARY_PATH

# Handle Macs
SYSTEM=`uname`
if [ "$SYSTEM" == "Darwin" ] ; then 
   DYLD_LIBRARY_PATH=$LD_LIBRARY_PATH
   export DYLD_LIBRARY_PATH
fi

if [ -n "`echo $CCASPEC_BABEL_LANGUAGES | grep python`" ] ; then
   PYTHON_VER="python`$ccaspecconfig --var CCASPEC_BABEL_PYTHON_VERSION`"
   PYTHONPATH=$rcfiledir/../../ports/lib/$PYTHON_VER/site-packages:$rcfiledir/../lib/$PYTHON_VER/site-packages:$CCASPEC_pkglibdir/$PYTHON_VER/site-packages:$PYTHONPATH

   if [ -d $CCASPEC_BABEL_libdir/../lib64 ] ; then
	  PYTHONPATH=$CCASPEC_BABEL_libdir/../lib64/$PYTHON_VER/site-packages:$PYTHONPATH ;
   else
	  PYTHONPATH=$CCASPEC_BABEL_libdir/$PYTHON_VER/site-packages:$PYTHONPATH: ;
   fi
   #echo PYTHONPATH=$PYTHONPATH
   export  PYTHONPATH
fi

if [ -n "`echo $CCASPEC_BABEL_LANGUAGES | grep java`" ] ; then 
   CCASPEC_BABEL_VERSION=`$ccaspecconfig --var CCASPEC_BABEL_VERSION`
   CLASSPATH=$CCASPEC_BABEL_libdir/sidl-$CCASPEC_BABEL_VERSION.jar:$CCASPEC_BABEL_libdir/sidlstub_$CCASPEC_BABEL_VERSION.jar:$CCASPEC_libdir/cca-spec.jar:$rcfiledir/../../ports/lib/java:$rcfiledir/../lib/java
   #echo CLASSPATH=$CLASSPATH
   export CLASSPATH
fi

if [ "x`grep quit $rcfile`" == "x" ]; then echo "quit" >> $rcfile; fi; 
$ccafe --ccafe-rc $rcfile > $rcfile.log 2>&1 ; 
echo -e "Test script: $rcfile"; 
if [ "$instantiate_only" != "1" ] ; then
	successful=`grep "specific go command successful" $rcfile.log | wc -l`
	expected=`egrep "^go " $rcfile | wc -l`
	if [  "$successful" != "0" -a "x$successful" == "x$expected" ]; then 
	    echo -e "==> Test passed, go command(s) executed successfully (see $rcfile.log)."; 
	    exit 0;
	else 
	    echo -e "*** Error: Some run tests did NOT succeed, go command failed (see $rcfile.log)."; 
	    exit 1;
	fi 
else # Instantiation test only
	successful=`grep "instantiate" $rcfile | wc -l`;
	expected=`grep "successfully instantiated" $rcfile.log | wc -l`;
	if [ "$successful" != "0" -a "x$successful" == "x$expected" ]; then 
	    echo -e "==> Instantiation tests passed for all built components (see $rcfile.log)."; 
	    exit 0;
	else 
	    echo -e "*** Error: Instantiation failed for some built components (see $rcfile.log)."; 
	    grep "instantiation failed" $rcfile.log; 
	    exit 1;
	fi 
fi
