#!/bin/sh

function usage () {
	echo -e "\nUsage:\n  sh testComponent.sh --gui --ccafe-rc <rcfile> --cca-dir <cca_dir> --lib-dir <lib_dir> --ccafe-config <ccafe-config>\n\n"\
		"This script adds a small Ccaffeine resource control (rc) script fragment\n"\
		"that set the dynamic  library search path to <lib_dir>\n"\
		" Arguments: \n"\
		"	--help 	: display this help and exit.\n"\
		"	--gui	: if this option is given, run the ccaffeine gui, otherwise use command-line interface.\n"\
		"   --gui-backend: if this option is given, run the framework in a mode appropriate for use with a remote GUI.\n"\
		"   --port <portnum>: port number if running in client/server mode, e.g., with --gui or --gui-backend; default is 8082.\n"\
		"	--ccafe-rc <rcfile>: rcfile is the full path name of the target Ccaffeine RC file\n"\
		"	--cca-dir <cca_dir>: cca_dir is the full path to the directory containing .cca and .scl files.\n"\
		"	--lib-dir <lib_dir>: lib_dir is the full path location of the dynamic libraries\n"\
		"	--ccafe-config <ccafe-config>: ccafe-config is the full path to the ccafe-config executable \n" > /dev/stderr
}

if [ $# -lt 6 ];  then
	usage
	exit 1;
fi

# Process command-line options
gui="0"
guibackend="0"
port="8082"
ccafeconfig=""
ccafe=""
ccadir=""
libdir=""
rcfilearg=""

while [ $# -gt 0 ]; do
	case "$1" in
		--help)
			usage;
			exit 0;
			;;
		--ccafe-rc)
			if [ $# -lt 2 ]; then usage; exit 1; fi;
			rcfilearg=$2;
			shift; shift;
			;;
		--cca-dir)
			if [ $# -lt 2 ]; then usage; exit 1; fi;
			ccadir=$2;
			shift; shift;
			;;
		--lib-dir)
			if [ $# -lt 2 ]; then usage; exit 1; fi;
			libdir=$2;
			shift; shift;
			;;
		--ccafe-config)
			if [ $# -lt 2 ]; then usage; exit 1; fi;
			ccafeconfig=$2; 
			shift; shift;
			;;
		--gui)
			gui="1"; 
			shift;
			;;
		--gui-backend)
		    guibackend="1";
		    shift;
		    ;;
		--port)
			port=$2;
			shift; shift;
			;;
		*)
			usage;
			exit 1;
			;;
	esac
done


if [ "x$rcfilearg" = "x" ] || [ ! -f "$rcfilearg" ]; then
	echo "Missing ccaffeine script: $rcfilearg"; 
	usage; 
	exit 1;
fi

if [ "x$ccafeconfig" = "x" ]; then 
	norun="1";
else
	norun="0";
	if [ ! -f "$ccafeconfig" ] || [ ! -x "$ccafeconfig" ]; then 
		echo "Specified value for ccafe-config does not exist or is not executable: $ccafeconfig";
		exit 1;
	fi
	ccafe=`$ccafeconfig --var CCAFE_SINGLE`
	if [ ! -f "$ccafe" ] || [ ! -x "$ccafe" ]; then 
		echo "Cannot find ccafe-single executable using $ccafeconfig --var CCAFE_SINGLE";
		exit 1;
	fi
fi

if [ "x$ccadir" = "x" ] || [ ! -d "$ccadir" ]; then echo "Specified .cca and .scl directory does not exist: $ccadir"; fi
if [ "x$libdir" = "x" ] || [ ! -d "$libdir" ]; then echo "Specified component library directory does not exist: $libdir"; fi


# End of command-line argument processing
#-----------------------------------------

instantiate_only="0"

if [ ! -f "$rcfilearg" ] ; then 
    echo -e "*** Error: Could not run tests, didn't find $rcfilearg file."; 
    exit 1;
fi 
rcfiledir=`dirname $rcfilearg`

if [ "x`grep \"^go \" $rcfilearg`" = "x" ] ; then
  if [ "x`grep \"^connect \" $rcfilearg`" = "x" ] ; then
    echo "Running instantiation tests only";
    instantiate_only="1";
  fi 
fi

if [ "x`echo $rcfilearg | grep \.incl`" != "x" ]; then 
    rcfile="`echo $rcfilearg | sed -e 's|\.incl||'`";
    sed -e "/@CCA_COMPONENT_PATH@/ s|@CCA_COMPONENT_PATH@|${ccadir}|" $rcfilearg > $rcfile;
else
    rcfile=$rcfilearg
    # If rcfile contains a full path, replace it with the libpath given to 
    # this script.
    sed -i".bk" -e "s|^path set /.*$|path set ${ccadir}|" $rcfile;
    /bin/rm -f "$rcfile.bk" 
fi

if [ "$norun" == "1" ]; then
	exit 0;
fi

ccaspecconfig=`$ccafeconfig --var CCAFE_CCA_SPEC_BABEL_CONFIG`
guiprefix=`$ccafeconfig --var CCAFE_bindir`
CCASPEC_libdir=`$ccaspecconfig --var CCASPEC_libdir `
CCASPEC_pkglibdir=`$ccaspecconfig --var CCASPEC_pkglibdir `
CCASPEC_BABEL_libdir=`$ccaspecconfig --var CCASPEC_BABEL_libdir`
CCASPEC_BABEL_LANGUAGES=`$ccaspecconfig --var CCASPEC_BABEL_LANGUAGES`

babelconfig=`$ccaspecconfig --var CCASPEC_BABEL_BABEL_CONFIG`
jvmlib=`$babelconfig --query-var=JVM_LIBDIR`
if test "x$jvmlib" = "x"; then
  # not tolerant of whitespace in lib dir names. may create
  # redundant path elements.
  jnihack=`$babelconfig --query-var=JNI_LDFLAGS| sed -e 's%^-L%%g' -e 's% -L% %g' -e 's% -R% %g' -e 's%^-R%%g' -e 's% %:%g'`
  JVMPATH=$jnihack
else
  # the right way, but fails under b1.0.x
  javalib=`$babelconfig --query-var=JAVA_LIBDIR`
  JVMPATH=$jvmlib:$javalib
fi

# Env. variable settings
LD_RUN_PATH=$libdir:$CCASPEC_BABEL_libdir:$CCASPEC_libdir:$JVMPATH
if [ "x$LD_LIBRARY_PATH" = "x" ] ; then
  LD_LIBRARY_PATH=$LD_RUN_PATH:
else
  LD_LIBRARY_PATH=$libdir:$CCASPEC_BABEL_libdir:$CCASPEC_libdir:$JVMPATH:$LD_LIBRARY_PATH
fi
export LD_RUN_PATH
export LD_LIBRARY_PATH

# Handle Macs
SYSTEM=`uname`
if [ "x$SYSTEM" = "xDarwin" ] ; then 
   DYLD_LIBRARY_PATH=$LD_LIBRARY_PATH
   export DYLD_LIBRARY_PATH
fi

if [ -n "`echo $CCASPEC_BABEL_LANGUAGES | grep python`" ] ; then
   PYTHON_VER="python`$ccaspecconfig --var CCASPEC_BABEL_PYTHON_VERSION`"
   PYTHONPATH=$libdir/$PYTHON_VER/site-packages:$CCASPEC_pkglibdir/$PYTHON_VER/site-packages:$PYTHONPATH

   if [ -d $CCASPEC_BABEL_libdir/../lib64 ] ; then
	  PYTHONPATH=$CCASPEC_BABEL_libdir/../lib64/$PYTHON_VER/site-packages:$PYTHONPATH ;
   else
	  PYTHONPATH=$CCASPEC_BABEL_libdir/$PYTHON_VER/site-packages:$PYTHONPATH: ;
   fi
   #echo PYTHONPATH=$PYTHONPATH
   export  PYTHONPATH
fi

if [ -n "`echo $CCASPEC_BABEL_LANGUAGES | grep java`" ] ; then 
   CCASPEC_BABEL_VERSION=`$ccaspecconfig --var CCASPEC_BABEL_VERSION`
   CLASSPATH=$CCASPEC_BABEL_libdir/sidl-$CCASPEC_BABEL_VERSION.jar:$CCASPEC_BABEL_libdir/sidlstub_$CCASPEC_BABEL_VERSION.jar:$CCASPEC_libdir/cca-spec.jar:$libdir/java
   echo "###"
   echo LDPATH=$LD_LIBRARY_PATH
   echo "###"
   echo CLASSPATH=$CLASSPATH
   echo "###"
   export CLASSPATH
fi

if [ "x$gui" = "x1" ]; then 
	echo -e "Test script: $rcfile"; 
	($guiprefix/gui-backend.sh --port $port --ccafe-rc $rcfile > $rcfile.log 2>&1) &
	sleep 5; 
	$guiprefix/gui.sh --port $port
	exit 0;
else
    if [ "x$guibackend" = "x1" ]; then 
		echo -e "Test script: $rcfile"; 
		$guiprefix/gui-backend.sh --port $port --ccafe-rc $rcfile
		exit 0;
    fi
fi

if [ "x`grep quit $rcfile`" = "x" ] && [ "x$gui" = "x0" ] && [ "x$guibackend" = "x0" ]; then echo "quit" >> $rcfile; fi; 
$ccafe --ccafe-rc $rcfile > $rcfile.log 2>&1 ; 
echo -e "Test script: $rcfile"; 
if [ "$instantiate_only" != "1" ] ; then
	successful=`grep "specific go command successful" $rcfile.log | wc -l`
	expected=`egrep "^go " $rcfile | wc -l`
	if [  "x$successful" != "x0" -a "x$successful" = "x$expected" ]; then 
	    echo -e "SUCCESS:"
	    echo -e "==> Test passed, go command(s) executed successfully (see $rcfile.log)."; 
	    exit 0;
	else 
	    echo -e "*** Error: Some run tests did NOT succeed, go command failed (see $rcfile.log)."; 
	    exit 1;
	fi 
else # Instantiation test only
	successful=`grep "instantiate" $rcfile | wc -l`;
	expected=`grep "successfully instantiated" $rcfile.log | wc -l`;
	if [ "x$successful" != "x0" -a "x$successful" = "x$expected" ]; then 
	    echo -e "SUCCESS:"
	    echo -e "==> Instantiation tests passed for all built components (see $rcfile.log)."; 
	    exit 0;
	else 
	    echo -e "*** Error: Instantiation failed for some built components (see $rcfile.log)."; 
	    grep "instantiation failed" $rcfile.log; 
	    exit 1;
	fi 
fi
