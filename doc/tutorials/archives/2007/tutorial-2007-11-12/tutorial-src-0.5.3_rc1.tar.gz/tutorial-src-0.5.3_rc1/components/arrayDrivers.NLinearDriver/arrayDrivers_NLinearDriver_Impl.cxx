// 
// File:          arrayDrivers_NLinearDriver_Impl.cxx
// Symbol:        arrayDrivers.NLinearDriver-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for arrayDrivers.NLinearDriver
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "arrayDrivers_NLinearDriver_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_arrayop_NonLinearOp_hxx
#include "arrayop_NonLinearOp.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver._includes)
  // Insert-UserCode-Here {arrayDrivers.NLinearDriver._includes:prolog} (additional includes or code)
  // Bocca generated code. bocca.protected.begin(arrayDrivers.NLinearDriver._includes)
#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR
#include <iostream>
#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR
#endif // _BOCCA_STDERR
  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics will
  // include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif
  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}
  // This simplifies exception extending and rethrowing in c++, like SIDL_CHECK in C.
  // EX_OBJ must be the caught exception and is extended with msg and file/line/func added.
  // Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}
  // Bocca generated code. bocca.protected.end(arrayDrivers.NLinearDriver._includes)
  // Insert-UserCode-Here {arrayDrivers.NLinearDriver._includes:epilog} (additional includes or code)
  // DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
arrayDrivers::NLinearDriver_impl::NLinearDriver_impl() : StubBase(
  reinterpret_cast< void*>(::arrayDrivers::NLinearDriver::_wrapObj(
  reinterpret_cast< void*>(this))),false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver._ctor2)
  // Insert-Code-Here {arrayDrivers.NLinearDriver._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver._ctor2)
}

// user defined constructor
void arrayDrivers::NLinearDriver_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver._ctor)
    
  // Insert-UserCode-Here {arrayDrivers.NLinearDriver._ctor:prolog} (constructor method) 
  // bocca-default-code. User may edit or delete.begin(arrayDrivers.NLinearDriver._ctor)
   #if _BOCCA_CTOR_MESSAGES
     std::cerr << "CTOR arrayDrivers.NLinearDriver: " << BOOST_CURRENT_FUNCTION << " constructing " << this << std::endl;
   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(arrayDrivers.NLinearDriver._ctor)
  // Insert-UserCode-Here {arrayDrivers.NLinearDriver._ctor:epilog} (constructor method)
  // DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver._ctor)
}

// user defined destructor
void arrayDrivers::NLinearDriver_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver._dtor)
  // Insert-UserCode-Here {arrayDrivers.NLinearDriver._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(arrayDrivers.NLinearDriver._dtor) */
   #if _BOCCA_CTOR_MESSAGES
     std::cerr << "DTOR arrayDrivers.NLinearDriver: " << BOOST_CURRENT_FUNCTION << " destructing " << this << std::endl;
   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(arrayDrivers.NLinearDriver._dtor) 
  // DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver._dtor)
}

// static class initializer
void arrayDrivers::NLinearDriver_impl::_load() {
  // DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver._load)
  // Insert-Code-Here {arrayDrivers.NLinearDriver._load} (class initialization)
  // DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
arrayDrivers::NLinearDriver_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(arrayDrivers.NLinearDriver.boccaSetServices)
  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;
  this->d_services = services;
  typeMap = this->d_services.createTypeMap();
  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , "arrayDrivers.NLinearDriver: Error casting self to gov::cca::Port");
  } 
  // Provide a gov.cca.ports.GoPort port with port name Go 
  try{
    this->d_services.addProvidesPort(port, // implementing object
                                     "Go", // port instance name
                                     "gov.cca.ports.GoPort", // full sidl type of port
                                     typeMap); // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, "arrayDrivers.NLinearDriver: Error calling addProvidesPort(port,\"Go\", \"gov.cca.ports.GoPort\", typeMap) ", -2);
    throw;
  }    
  // Use a arrayop.NonLinearOp port with port name NonLinearPort 
  try{
    this->d_services.registerUsesPort("NonLinearPort", // port instance name
                                         "arrayop.NonLinearOp", // full sidl type of port
                                         typeMap); // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,"arrayDrivers.NLinearDriver: Error calling registerUsesPort(\"NonLinearPort\", \"arrayop.NonLinearOp\", typeMap) ", -2);
    throw;
  }
  gov::cca::ComponentRelease cr = ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(arrayDrivers.NLinearDriver.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
arrayDrivers::NLinearDriver_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(arrayDrivers.NLinearDriver.boccaReleaseServices)
  this->d_services=0;
  // Un-provide gov.cca.ports.GoPort port with port name Go 
  try{
    services.removeProvidesPort("Go");
  } catch ( ::gov::cca::CCAException ex )  {
#ifdef _BOCCA_STDERR
    std::cerr << "arrayDrivers.NLinearDriver: Error calling removeProvidesPort(\"Go\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() << std::endl;
#endif // _BOCCA_STDERR
  }
  // Release arrayop.NonLinearOp port with port name NonLinearPort 
  try{
    services.unregisterUsesPort("NonLinearPort");
  } catch ( ::gov::cca::CCAException ex )  {
#ifdef _BOCCA_STDERR
    std::cerr << "arrayDrivers.NLinearDriver: Error calling unregisterUsesPort(\"NonLinearPort\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() << std::endl;
#endif // _BOCCA_STDERR
  }
  return;
  // Bocca generated code. bocca.protected.end(arrayDrivers.NLinearDriver.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
arrayDrivers::NLinearDriver_impl::boccaForceUsePortInclude_impl (
  /* in */::arrayop::NonLinearOp dummy0 ) 
{
  // DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(arrayDrivers.NLinearDriver.boccaForceUsePortInclude)
    (void)dummy0;
  // Bocca generated code. bocca.protected.end(arrayDrivers.NLinearDriver.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument Svc will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
arrayDrivers::NLinearDriver_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver.setServices)
  // Insert-UserCode-Here{arrayDrivers.NLinearDriver.setServices:prolog}
  // bocca-default-code. User may edit or delete.begin(arrayDrivers.NLinearDriver.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(arrayDrivers.NLinearDriver.setServices)
  
  // Insert-UserCode-Here{arrayDrivers.NLinearDriver.setServices:epilog}
  // DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument Svc will never be nil/null.
 * The argument Svc will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to Svc.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
arrayDrivers::NLinearDriver_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver.releaseServices)
  // Insert-UserCode-Here {arrayDrivers.NLinearDriver.releaseServices} 
  // bocca-default-code. User may edit or delete.begin(arrayDrivers.NLinearDriver.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(arrayDrivers.NLinearDriver.releaseServices)
    
  // DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver.releaseServices)
}

/**
 *  
 * Execute some encapsulated functionality on the component. 
 * Return 0 if ok, -1 if internal error but component may be 
 * used further, and -2 if error so severe that component cannot
 * be further used safely.
 */
int32_t
arrayDrivers::NLinearDriver_impl::go_impl () 

{
  // DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver.go)
  // Insert-Code-Here {arrayDrivers.NLinearDriver.go} (go method)
    
  int m = 3;
  int n = 2;
  int i , j;
  double *A;
  double *M1;
  double *M2;
  double *R;
  double alpha = 1.0;
  double beta  = 2.0;
  double value;
  int    retval;
  ::sidl::array<double> sda1, sda2, sda_R;
  double *sda1_data, *sda2_data;
  arrayop::NonLinearOp  nLinPort;
  gov::cca::Port      port;
  try{
     port = d_services.getPort("NonLinearPort");
   } catch ( ::gov::cca::CCAException ex )  {
      BOCCA_EXTEND_THROW_CXX(ex, "arrayDrivers.NLinearDriver: Error calling getPort(\"NonLinearPort\") ", -2);
      throw;
   }
  nLinPort = ::babel_cast<arrayop::NonLinearOp>(port);
  if (nLinPort._is_nil()) {
    // we cannot go on. toss an exception.
    try {
      d_services.releasePort("NonLinearPort");
    } catch (...) { // suppress framework complaints; we're already handling an exception.
    }
    ::sidl::SIDLException ex = ::sidl::SIDLException::_create();
    ex.setNote( "Error: NonLinearOp port is nil; someone lied to the framework about its type.");
    ex.add(__FILE__, __LINE__, "arrayDrivers::NLinearDriver_impl::go_impl");
    throw ex;
  }
  nLinPort.init();
  A = (double *) malloc (m * n * sizeof(double));
  M1 = (double *) malloc (m * n * sizeof(double));
  M2 = (double *) malloc (m * n * sizeof(double));
  R = (double *) malloc (m * n * sizeof(double));
  if(!A || !M1  || !M2 || !R){
    fprintf(stderr, "Error:: %s:%d: Failed to allocate data for arrays.\n",
       __FILE__, __LINE__);
    return(-1);
  }
  // sda1 sda2, and sda_R  are row major arrays
  sda1 = sidl::array<double>::create2dRow(m,  n);
  sda2 = sidl::array<double>::create2dRow(m,  n);
  sda_R = sidl::array<double>::create2dRow(m,  n);
  if (sda1._is_nil() || sda2._is_nil()){
    fprintf(stderr, "Error:: %s:%d: Error creating sidl arrays sda1 or sda2.\n",
      __FILE__, __LINE__);
    return(-1);
  }
  /*      _        _          _        _         _        _
   *     | 1.0  4.0 |        | 1.0  2.0 |       | 2.0  8.0 |
   * A = | 2.0  5.0 |   M1 = | 3.0  4.0 |  M2 = | 4.0 10.0 |
   *     |_3.0  6.0_|        |_5.0  6.0_|       |_6.0 12.0_|
   *
   *                _        _
   *               | 3.0  6.0 |
   * sda1 = sda2 = | 4.0  7.0 |
   *               |_5.0  8.0_|
   *
   * Note that A needs to be stored in column major order to make
   * the call using SIDL raw arrays
   */
  sda1_data = sda1.first();
  sda2_data = sda2.first();
  value = 1.0;
  for (i = 0; i < m; i++){
    for (j = 0; j < n; j++){
      A[i*n+j] = value ;
      M1[i+j*m] = value ;
      M2[i*n+j] = 2.0 * value;
      value++;
    }
  }
  value = 1.0;
  for (j = 0; j < n; j++){
    for (i = 0; i < m; i++){
      sda1_data[i*n+j] = value + 2 ;
      sda2_data[i*n+j] = value + 2 ;
      value++;
    }
  }
  printf("A = \n");
  for ( i = 0; i < m; i++){
    for (j = 0; j < n; j++){
      printf("%.2f  ", A[i+j*m]);
    }
    printf("\n");
  }
  printf("\n");
  fflush(stdout);
  retval = nLinPort.logMat(alpha, A, R, m , n);
  if (retval != 0){
    fprintf(stderr, "Error:: %s:%d: Error in call to logMat() \n",
            __FILE__, __LINE__);
    return(-1);
  }
  printf("Result1 = \n");
  for ( i = 0; i < m; i++){
    for (j = 0; j < n; j++){
      printf("%.2f  ", R[i+j*m]);
    }
    printf("\n");
  }
  printf("\n");
  fflush(stdout);
  retval = nLinPort.logMat(alpha, M1, R, m, n);
  if (retval != 0){
    fprintf(stderr, "Error:: %s:%d: Error in call to logMat() \n",
            __FILE__, __LINE__);
    return(-1);
  }
  printf("Result2 = \n");
  for ( i = 0; i < m; i++){
    for (j = 0; j < n; j++){
      printf("%.2f  ", R[i+j*m]);
    }
    printf("\n");
  }
  printf("\n");
  fflush(stdout);
  retval = nLinPort.mulMatMat(beta, sda1, sda2, sda_R);
  /* Print result obtained through sda_R */
  printf("Result3 = \n");
  for ( i = sda_R.lower(0); i <= sda_R.upper(0); i++){
     for ( j = sda_R.lower(1); j <= sda_R.upper(1); j++){
        printf("%.2f  ", sda_R.get(i, j));
     }
     printf("\n");
  }
  printf("\n");
  fflush(stdout);
  /*
   * Get results through  nLinPort.getResult()
   */
  retval =  nLinPort.getResult(R, m, n);
  if (retval != 0){
    fprintf(stderr, "Error:: %s:%d: Error in call to getResult() \n",
            __FILE__, __LINE__);
    return(-1);
  }
  printf("Result4 = \n");
  for ( i = 0; i < m; i++){
    for (j = 0; j < n; j++){
      printf("%.2f  ", R[i+j*m]);
    }
    printf("\n");
  }
  printf("\n");
  fflush(stdout);
  free(A);
  free(M1);
  free(M2);
  free(R);
  try {
    d_services.releasePort("NonLinearPort");
   } catch ( ::gov::cca::CCAException ex )  {
      BOCCA_EXTEND_THROW_CXX(ex, "arrayDrivers.NLinearDriver: Error calling releasePort(\"NonLinearPort\") ", -2);
      throw;
   }
  return(0);
    
  // DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver.go)
}


// DO-NOT-DELETE splicer.begin(arrayDrivers.NLinearDriver._misc)
// Insert-Code-Here {arrayDrivers.NLinearDriver._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(arrayDrivers.NLinearDriver._misc)

