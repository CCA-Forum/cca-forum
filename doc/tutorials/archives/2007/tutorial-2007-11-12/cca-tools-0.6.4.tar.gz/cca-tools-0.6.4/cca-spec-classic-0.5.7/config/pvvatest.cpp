/**  a file to test whether a compiler will handle
 * defaultprintfport. (some gcc don't).
 */
static char id[] = 
"$Id: pvvatest.cpp,v 1.1 2002/08/19 22:53:05 baallan Exp $";


#include <cstdarg>
#include <cstdio>

/* an interface*/
class PrintfPort {

public:

  /** obligatory vdtor */
  virtual ~PrintfPort(){}

  /** Output a string on out device ... ala printf */
  virtual void p(char* fmt, ...) =0;

};



/** A just-print-it port implementation. 
*/
class DefaultPrintfPort : public virtual PrintfPort {

public:

  DefaultPrintfPort();
  virtual ~DefaultPrintfPort(){}

  /** Output a string on out device ... ala printf */
  virtual void p(char* fmt, ...) ;

};



DefaultPrintfPort::DefaultPrintfPort() {}

void DefaultPrintfPort::p(char* fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  vfprintf(stdout, fmt, ap);
  va_end(ap);
}

