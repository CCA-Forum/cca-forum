package gov.cca.eg.port;
import java.util.Date;

/** Produces the current time in the form of a String. */
public interface TimeProducerPort extends gov.cca.Port {
  /** Fetch the time. */
  public Date getTime();
}
