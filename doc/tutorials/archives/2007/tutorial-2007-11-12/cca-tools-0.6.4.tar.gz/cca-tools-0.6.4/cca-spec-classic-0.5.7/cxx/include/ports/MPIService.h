#ifndef MPIService_h_seen
#define MPIService_h_seen

//requires:
//#include <cca.h>
//#include <mpi.h>


namespace classic {

namespace gov {
  namespace cca {

/** UNADOPTED standard service. Port string name "gov.cca.MPIService". */
class MPIService : public virtual Port {

public:

  /** obligatory vdtor */
  virtual ~MPIService() {}

  /** Get an mpi communicator with the same scope as the component instance.
   Won't be mpi_comm_null. */
  virtual MPI_Comm getComm() CLASSIC_CCA_PURE;
  /** Let go the communicator. previously fetched with getComm. */
  virtual void releaseComm(MPI_Comm m) CLASSIC_CCA_PURE;

};

} ENDSEMI // cca
} ENDSEMI // gov
} ENDSEMI //CLASSIC


#endif // MPIService_h_seen
