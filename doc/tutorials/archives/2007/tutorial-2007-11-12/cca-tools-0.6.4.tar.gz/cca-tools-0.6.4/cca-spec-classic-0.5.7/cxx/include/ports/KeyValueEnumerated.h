#ifndef KeyValueEnumerated_h_seen
#define KeyValueEnumerated_h_seen


namespace classic {

namespace gov {
namespace cca {
//! Abstract algorithm control parameters and string named data io interface.
/** DEPRECATED. SEVERELY DEPRECATED.
 * This is a generic properties input/output interface which may 
    be supported at the discretion of the concrete class implementer.

    This is a Closed hash -- one value (and value type) per key.
    Setting a new value and type
    for a key which has a value of another type already is an error.

    The usual esi_msg error buffer is omitted from the functions in
    this interface, as it is particularly simple.

    Some properties/control parameters (such as iterationLimit
    which must be present in all ESI_Solvers) may be represented
    redundantly in this <em>optional<\em>Properties itnerface.


  As an example:
  If you have a solver that cares about the properties of
  a Matrix or Operator, simply :
      esi::Properties *p;
      err = mtx->getInterface("esi::Properties", (void *)p,msg);
      bool is_psym = false;
      if (err >= 0) {  // <0 means no properties interface p.
        err2 = p->getBool("esi.P-Symmetric",psym); // ignore err2 is ok
        // if esi.P-Symmetric unknown, nothing psym is returned unchanged.
      }

  Implementation notes:

    Since this depends on Int and Float, it
    cannot be in the Object interface.  Since some
    operators/matrices/solvers/vectors/pcs may have no special
    properties, the interface is not required (by inheritance)
    into those classes.

    We will create a reference implementation of this interface which
    can be inherited or used as an internal data member (delegated to)
    to provide this interface. 

    Probably most implementers will support it by delegation
    or inheritance of the reference-- no bonus points in the math
    world for implementing hashes. Those implementers that want to
    back this interface by an existing resource mechanism
    are of course free to do so.

*/
class KeyValueEnumerated : public virtual Port {
public:
  /** Defines a new string property or changes the value of an existing one.
      Because the string arguments are copied, it is okay to call this
      with string literal arguments.
      @param key The property name, which will be copied.
      @param value The property value, which will be copied.
                   A 0 value will cause the key to remain
		   with a NULL value. Use 'unset' to delete keys.
      @return 0 if ok, -2 if not ok due to a type conflict,
      and -1 for all other reason.
   */
  virtual int setString(const char *key, const char *value) CLASSIC_CCA_PURE;

  /** Defines a new Float property or changes its value.
      @param key The property name, which will be copied.
      @param value The property value to be set.
      @return 0 if ok, -2 if not ok due to a type conflict,
      and -1 for all other reason.
   */
  virtual int setFloat(const char *key, float value) CLASSIC_CCA_PURE;
  /** like setFloat. */
  virtual int setDouble(const char *key, double value) CLASSIC_CCA_PURE;
  /** like setFloat. */
  virtual int setLongDouble(const char *key, long double value) CLASSIC_CCA_PURE;

  /** Defines a new integral property or changes its value.
      @param key The property name, which will be copied.
      @param value The property value to be set.
      @return 0 if ok, -2 if not ok due to a type conflict,
      and -1 for all other reason.
   */
  virtual int setChar(const char *key, char value) CLASSIC_CCA_PURE;
  /** like setShort. */
  virtual int setShort(const char *key, short value) CLASSIC_CCA_PURE;
  /** like setShort. */
  virtual int setInt(const char *key, int value) CLASSIC_CCA_PURE;
  /** like setShort. */
  virtual int setLong(const char *key, long int value) CLASSIC_CCA_PURE;
  /** like setShort. */
  virtual int setLongLong(const char *key, long long int value) CLASSIC_CCA_PURE;
  /** like setShort. */
  virtual int setUnsignedChar(const char *key, unsigned char value) CLASSIC_CCA_PURE;
  /** like setShort. */
  virtual int setUnsignedShort(const char *key, unsigned short value) CLASSIC_CCA_PURE;
  /** like setShort. */
  virtual int setUnsignedInt(const char *key, unsigned int value) CLASSIC_CCA_PURE;
  /** like setShort. */
  virtual int setUnsignedLong(const char *key, unsigned long int value) CLASSIC_CCA_PURE;
  /** like setShort. */
  virtual int setUnsignedLongLong(const char *key, unsigned long long int value) CLASSIC_CCA_PURE;

  /** Defines a new boolean property or changes its value.
      @param key The property name, which will be copied.
      @param boolProp The property value to be set.
      @return 0 if ok, -2 if not ok due to a type conflict,
      and -1 for all other reason.
   */
  virtual int setBool(const char *key, bool boolProp) CLASSIC_CCA_PURE;

  /** Defines a new arbitrary object property, or substitutes
     a new object for the currently stored one.
     @param key The property name, which will be copied.
     @param objProp If the void pointer given should be reference counted, that
       is the caller's responsibility.  The pointer will be stored
       until the next set or unset on the same key.
       The void pointer may be to an object, an array, or anything else.
      @return 0 if ok, -2 if not ok due to a type conflict,
      and -1 for all other reasons.
   */
  virtual int setPointer(const char *key, void *objProp) CLASSIC_CCA_PURE;

  /**  Get a C string property value by C string name.
    @param propName The name of the property desired.
    @param value output of the value requested.
    @return 0 if value exists. -2 if it exists and is of the wrong type.
            -1 does not exist or any other error.
   */
  virtual int getString(const char * propName, const char *& value) CLASSIC_CCA_PURE;

  /**  Get a Float property value by C string name.
    @param propName The string name of the property desired.
    @param value output of the value requested.
    @return 0 if value exists. -2 if it exists and is of the wrong type.
            -1 does not exist or any other error.
   */
  virtual int getFloat(const char * propName, Float & value) CLASSIC_CCA_PURE;

  /**  Get an Int property value by C string name.
    @param propName The string name of the property desired.
    @param value output of the value requested.
    @return 0 if value exists. -2 if it exists and is of the wrong type.
            -1 does not exist or any other error.
   */
  virtual int getInt(const char * propName, Int & value) CLASSIC_CCA_PURE;

  /**  Get a bool property value by C string name.
    @param propName The string name of the property desired.
    @param value output of the value requested.
    @return 0 if value exists. -2 if it exists and is of the wrong type.
            -1 does not exist or any other error.
   */
  virtual int getBool(const char * propName, bool & value) CLASSIC_CCA_PURE;

  /**  Get a pointer property value by C string name.
    @param propName The string name of the property desired.
    @param value output of the value requested.
    @return 0 if value exists. -2 if it exists and is of the wrong type.
            -1 does not exist or any other error.
   */
  virtual int getPointer(const char * propName, void * & value) CLASSIC_CCA_PURE;

  /** Remove a key from the properties. All errors are silently ignored.
      @param propName key.
      @param pointerOut If the key corresponds to
      a void pointer property, the pointer is returned in pointerOut,
      otherwise pointerOut is 0.
   */
  virtual void unset(const char *propName, void * & pointerOut) CLASSIC_CCA_PURE;

  /** Produce a list of all the keys in an abstract container.
   * @param keylist input/output Argv that should be supplied empty
   * (containing no keys). The names of keys in the Properties are appended.
   */
  virtual void getKeys(Argv * keylist) CLASSIC_CCA_PURE;

  /** Produce a list of the keys in the main underlying object
   * that the object "supports", i.e. sets or reads during computations.
   * Other keys may be present for use by third parties that have
   * nothing to do with "the algorithm", but these keys will not appear
   * in the getKeysSupported list.
   * @param keylist input/output Argv that should be supplied empty
   * (containing no keys). The names of supported keys in the Properties 
   * are appended.
   */
  virtual void getKeysSupported(Argv * keylist) CLASSIC_CCA_PURE;

  }; //  KeyValueEnumerated
} ENDSEMI // cca
} ENDSEMI // gov
 } ENDSEMI // end namespace classic

#endif // KeyValueEnumerated_h_seen

