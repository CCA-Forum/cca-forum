#ifndef eg_h_seen
#define eg_h_seen
#include "StringConsumerPort.h"
#include "TimeProducerPort.h"
/** define a macro to get in our namespace. */
#define EGNS(x) classic::gov::cca::eg::x
#endif // eg_h_seen
