package gov.cca.ports;
import gov.cca.*;


/** A do-it port.  Tremendously useful. */
public interface GoPort extends Port {  
/** Make the component do its thing. */
  public void go();
}
