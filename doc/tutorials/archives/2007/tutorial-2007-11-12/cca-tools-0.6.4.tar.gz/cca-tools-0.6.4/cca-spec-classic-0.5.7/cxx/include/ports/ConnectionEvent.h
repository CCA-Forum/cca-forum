#ifndef __ConnectionEvent_H__
#define __ConnectionEvent_H__


namespace classic {

namespace gov {
  namespace cca {

/** UNADOPTED standard: ConnectionEvent event interface. */
class ConnectionEvent {
 public:
  /** obligatory vdtor */
  virtual ~ConnectionEvent() {}

  /** True if the event informs a connection. */
  virtual int connected() CLASSIC_CCA_PURE;
  /** True if the event informs a disconnection */
  virtual int disconnected() CLASSIC_CCA_PURE;
  /** Get the PortInfo of the affected Port. */
  virtual PortInfo* getPortInfo() CLASSIC_CCA_PURE;

  /** Close your eyes and don't read further.
   * Returns the address of a ccafeopq::typemap
   * which will exist for the duration of the
   * ConnectionEvent object under it.
   * This is ugly, but temporary. we will 
   * define a full ccafeopq event model soon enough.
   */
  virtual void * getOpqTypeMapSharedPtrAddress() CLASSIC_CCA_PURE;
};

  } ENDSEMI
} ENDSEMI

 } ENDSEMI // end namespace classic
#endif // __ConnectionEvent_H__
