#ifndef __TIMEPRODUCERPORT_H__
#define __TIMEPRODUCERPORT_H__


namespace classic {

namespace gov {
  namespace cca {


/** An example port for an interface for providing a time service. */
class TimeProducerPort : public virtual Port {
 public:
  /** obligatory vdtor */
  virtual ~TimeProducerPort(){}
  /** Produce the time as a string. */
  virtual CFREE char* getTime() = 0;
};

  } ENDSEMI // cca
} ENDSEMI //gov
} ENDSEMI //CLASSIC


#endif //__TIMEPRODUCERPORT_H__
