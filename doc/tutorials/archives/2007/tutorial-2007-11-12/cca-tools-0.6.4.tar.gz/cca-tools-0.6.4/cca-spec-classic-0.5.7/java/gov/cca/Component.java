package gov.cca;

import java.lang.Object;

/** The CCA object model: the interface that all CCA components must implement. */
public interface Component {
  /** Obtain Services handle, through which the component and framework communicate.  
      This is the one method that every CCA Component must implement. 
      Every component must also implement a NULL constructor. */
  void setServices(Services svc);
}
