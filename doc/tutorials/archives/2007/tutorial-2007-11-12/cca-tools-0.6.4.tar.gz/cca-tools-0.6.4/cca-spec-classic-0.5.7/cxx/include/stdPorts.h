#ifndef __portInterfaces_h_seen
#define __portInterfaces_h_seen

/** component kickstart */
#include "ports/GoPort.h"

/** Connection notification. */
#include "ports/ConnectionEvent.h"
#include "ports/ConnectionEventListener.h"
#include "ports/ConnectionEventService.h"

/** Used for component properties or other property implementations. */
#include "ports/KeyValuePort.h"

/** Used for framework/external-component directed output. */
#include "ports/PrintfPort.h"
#include "ports/JPrintfPort.h"

#endif // __portInterfaces_h_seen
