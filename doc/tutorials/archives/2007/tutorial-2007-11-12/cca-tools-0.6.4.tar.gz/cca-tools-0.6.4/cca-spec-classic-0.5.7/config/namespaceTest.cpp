namespace cca {
  class NSTest {
  public:
    NSTest() {}
    ~NSTest() {}
  private:
    int y;
  };
}
#ifdef NAMESPACE_NEEDS_ENDSEMI
;
#endif // NAMESPACE_NEEDS_ENDSEMI

class NoNSTest {
  public:
    NoNSTest() {}
    ~NoNSTest() {}
  private:
    int y;
};

int main() {
  ::cca::NSTest foo1;
  NoNSTest foo2;
  return 0;
}
