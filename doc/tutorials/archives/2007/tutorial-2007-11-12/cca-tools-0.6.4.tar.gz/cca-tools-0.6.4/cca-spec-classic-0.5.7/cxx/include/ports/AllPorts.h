#ifndef __ALLPORTS_H__
#define __ALLPORTS_H__

#include "ArgvInterface.h"
#include "ConnectionEvent.h"
#include "ConnectionEventListener.h"
#include "ConnectionEventService.h"
#include "GoPort.h"
#include "JPrintfPort.h"
#include "KeyValueEnumerated.h"
#include "KeyValuePort.h"
#include "KeyValueTyped.h"
#include "MPIBorrow.h"
#include "MPIService.h"
#include "PrintfPort.h"
#include "RawData.h"
#include "StringConsumerPort.h"
#include "TimeProducerPort.h"


#endif // __ALLPORTS_H__
