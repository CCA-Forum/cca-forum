package gov.cca.ports;
import gov.cca.*;

/** This is the interface that a component must provide
in order to be notified of ConnectionEvents. */
public interface ConnectionEventListener {
  /** Delivered to listeners when a connection is made or broken. */
  public void connectionActivity(ConnectionEvent evt);
}

