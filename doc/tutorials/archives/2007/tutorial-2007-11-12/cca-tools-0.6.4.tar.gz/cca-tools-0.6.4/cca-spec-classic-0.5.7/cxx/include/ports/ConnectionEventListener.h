#ifndef __ConnectionEventListener_H__
#define __ConnectionEventListener_H__


namespace classic {

namespace gov {
  namespace cca {

/** UNADOPTED standard: The interface listeners must implement 
  to receive ConnectionEvents. */
class ConnectionEventListener {
 public:
  /** obligatory vdtor */
  virtual ~ConnectionEventListener() {}
  /** Connection event hook a component may supply.
      Any action by the component on its Services is
      allowed during the connection activity, including
      getting, using, releasing, and unregistering a uses port. */
  virtual void connectionActivity(ConnectionEvent* evt) CLASSIC_CCA_PURE;
};


  } ENDSEMI
} ENDSEMI
 } ENDSEMI // end namespace classic

#endif // __ConnectionEventListener_H__
