#ifndef __STRINGCONSUMERPORT_H__
#define __STRINGCONSUMERPORT_H__


namespace classic {

namespace gov {
  namespace cca {

/** An example port for a standard interface for passing a string 
    to a component. The canonical string name of this port is 
    "StringConsumerPort". 
    The canonical name should probably be gov.cca.eg.StringConsumerPort
    or gov.cca.StringConsumerPort.
*/
class StringConsumerPort : public virtual ::classic::gov::cca::Port {
 public:
  /** obligatory vdtor */
  virtual ~StringConsumerPort(){}

  /** Pass a string to the component. */
  virtual void setString(const char* s) CLASSIC_CCA_PURE;
};


  } ENDSEMI // cca
} ENDSEMI //gov
} ENDSEMI //CLASSIC


#endif // __STRINGCONSUMERPORT_H__
