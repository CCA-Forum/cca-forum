package gov.cca;

/** A tag interface to identify an interface capable of being exported to
    or imported from a CCA component.
@see Services
 */
public interface Port {
}
