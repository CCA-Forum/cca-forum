#ifndef __SIMPLESTAMPSTRING_H__
#define __SIMPLESTAMPSTRING_H__

/** To deal with babel taking over this same namespace we name this
one "classic. */

namespace classic {

namespace gov {
  namespace cca {
    namespace eg {


/** An example component that takes an input string and stamps it with
    a time string, then puts it on output. */
class SimpleStamper: public virtual ::classic::gov::cca::Component, 
		   public virtual ::classic::gov::cca::StringConsumerPort {
		   
public:

  /** Spec required null constructor. */
  SimpleStamper();

  /** required virtualness on destructor. */
  virtual ~SimpleStamper();

  /** Implements classic::gov::cca::Component. */
  virtual void setServices( ::classic::gov::cca::Services *svc);

  /** Implements StringConsumerPort */
  virtual void setString(const char* s);

private:
  /** holding on to the svc from setServices, to answer setSTring with. */
  ::classic::gov::cca::Services* svc;
};

    } ENDSEMI // eg
  } ENDSEMI // cca
} ENDSEMI //gov
} ENDSEMI //CLASSIC

#endif // __SIMPLESTAMPSTRING_H__
