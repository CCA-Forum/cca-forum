package gov.cca;

/** An interface that describes a Port. */
public interface PortInfo{

  /** Returns the type of the Port referred to by this PortInfo: corresponds to the 
      class name for this Port.*/
  public String getType();
  /** Returns the instance name for this Port.  This name must be unique within the 
      scope of the CCA component which creates this port. */
  public String getName();
  /** Fetch the value corresponding to propertyKey.
      @return The string value for this property, or null if it is undefined. */
  public String getProperty(String propertyKey);
}
