package gov.cca.eg.port;

/** A generic interface for handing off a String. */
public interface StringConsumerPort extends gov.cca.Port {
    /** Set a String.*/
    public void setString(String s) throws Exception;
}

