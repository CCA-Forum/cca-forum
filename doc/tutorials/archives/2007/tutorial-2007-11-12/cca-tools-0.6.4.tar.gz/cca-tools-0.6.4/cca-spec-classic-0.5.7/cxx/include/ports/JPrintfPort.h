#ifndef __JPRINTFPORT_H__
#define __JPRINTFPORT_H__


namespace classic {

namespace gov {
  namespace cca {

/** UNADOPTED Standard:
<p>Looks exactly like the java version of printfport, 
instead of using stdarg which doesn't work in g++ 3.[0 <= x <= 1].
</p>
*/
class JPrintfPort : public virtual Port {

public:

  /** obligatory vdtor */
  virtual ~JPrintfPort(){}

  /** Output a string on out device  */
  virtual void p(char* msg) CLASSIC_CCA_PURE;
  /** Output a string on out device  */
  virtual void p(char const* msg) CLASSIC_CCA_PURE;
  /** Output a string on out device with added \n  */
  virtual void pn(char * msg) CLASSIC_CCA_PURE;
  /** Output a string on out device with added \n  */
  virtual void pn(const char * msg) CLASSIC_CCA_PURE;

  /** Output a string on err device  */
  virtual void e(char* msg) CLASSIC_CCA_PURE;
  /** Output a string on err device  */
  virtual void e(const char* msg) CLASSIC_CCA_PURE;
  /** Output a string on err device with added \n  */
  virtual void en(char* msg) CLASSIC_CCA_PURE;
  /** Output a string on err device with added \n  */
  virtual void en(const char* msg) CLASSIC_CCA_PURE;

  /** Output a string on log device  */
  virtual void l(char* msg) CLASSIC_CCA_PURE;
  /** Output a string on log device  */
  virtual void l(const char* msg) CLASSIC_CCA_PURE;
  /** Output a string on log device with added \n  */
  virtual void ln(char* msg) CLASSIC_CCA_PURE;
  /** Output a string on log device with added \n  */
  virtual void ln(const char* msg) CLASSIC_CCA_PURE;

};


  } ENDSEMI //cca
} ENDSEMI //gov
} ENDSEMI //CLASSIC


#endif //__JPRINTFPORT_H__
