#
# File:          SortingAlgorithm_Impl.py
# Symbol:        sort.SortingAlgorithm-v0.1
# Symbol Type:   class
# Babel Version: 1.0.8
# Description:   Implementation of sidl class sort.SortingAlgorithm in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
#


"""An abstract sorting algorithm.
"""

# DO-NOT-DELETE splicer.begin(_initial)
# Put your code here...
# DO-NOT-DELETE splicer.end(_initial)

import sidl.BaseClass
import sidl.BaseInterface
import sidl.ClassInfo
import sidl.RuntimeException
import sort.Comparator
import sort.Container
import sort.Counter
import sort.SortingAlgorithm
import sidl.NotImplementedException

# DO-NOT-DELETE splicer.begin(_before_type)
import sort.SimpleCounter
# DO-NOT-DELETE splicer.end(_before_type)

class SortingAlgorithm:
  """\
An abstract sorting algorithm.
"""

# All calls to sidl methods should use __IORself

# Normal Babel creation pases in an IORself. If IORself == None
# that means this Impl class is being constructed for native delegation
  def __init__(self, IORself = None):
    if (IORself == None):
      self.__IORself = sort.SortingAlgorithm.SortingAlgorithm(impl = self)
    else:
      self.__IORself = IORself
    # DO-NOT-DELETE splicer.begin(__init__)
    self.d_swp = sort.SimpleCounter.SimpleCounter()
    self.d_cmp = sort.SimpleCounter.SimpleCounter()
    # DO-NOT-DELETE splicer.end(__init__)

# Returns the IORself (client stub) of the Impl, mainly for use
# with native delegation
  def _getStub(self):
    return self.__IORself

  def getCompareCounter(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # sort.Counter _return
    #

    """\
Return the comparison counter.
"""
    # DO-NOT-DELETE splicer.begin(getCompareCounter)
    return self.d_cmp
    # DO-NOT-DELETE splicer.end(getCompareCounter)

  def getSwapCounter(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # sort.Counter _return
    #

    """\
Return the swap counter.
"""
    # DO-NOT-DELETE splicer.begin(getSwapCounter)
    return self.d_swp
    # DO-NOT-DELETE splicer.end(getSwapCounter)

  def reset(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

    """\
Reset the comparison and swap counter.
"""
    # DO-NOT-DELETE splicer.begin(reset)
    self.d_swp.reset()
    self.d_cmp.reset()
    # DO-NOT-DELETE splicer.end(reset)

# DO-NOT-DELETE splicer.begin(_final)
# Put your code here...
# DO-NOT-DELETE splicer.end(_final)
