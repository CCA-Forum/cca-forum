/*
 * File:          Args_Cdouble_Impl.c
 * Symbol:        Args.Cdouble-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cdouble
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "Args.Cdouble" (version 1.0)
 */

#include "Args_Cdouble_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"

/* DO-NOT-DELETE splicer.begin(Args.Cdouble._includes) */
/* Put additional includes or other arbitrary code here... */
/* DO-NOT-DELETE splicer.end(Args.Cdouble._includes) */

#define SIDL_IOR_MAJOR_VERSION 1
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdouble__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cdouble__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdouble._load) */
  /* Insert the implementation of the static class initializer method here... */
  /* DO-NOT-DELETE splicer.end(Args.Cdouble._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdouble__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cdouble__ctor(
  /* in */ Args_Cdouble self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdouble._ctor) */
  /* Insert the implementation of the constructor method here... */
  /* DO-NOT-DELETE splicer.end(Args.Cdouble._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdouble__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cdouble__ctor2(
  /* in */ Args_Cdouble self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdouble._ctor2) */
  /* Insert-Code-Here {Args.Cdouble._ctor2} (special constructor method) */
  /* DO-NOT-DELETE splicer.end(Args.Cdouble._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdouble__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cdouble__dtor(
  /* in */ Args_Cdouble self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdouble._dtor) */
  /* Insert the implementation of the constructor method here... */
  /* DO-NOT-DELETE splicer.end(Args.Cdouble._dtor) */
  }
}

/*
 * Method:  returnback[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdouble_returnback"

#ifdef __cplusplus
extern "C"
#endif
double
impl_Args_Cdouble_returnback(
  /* in */ Args_Cdouble self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdouble.returnback) */
  return 3.14;
  /* DO-NOT-DELETE splicer.end(Args.Cdouble.returnback) */
  }
}

/*
 * Method:  passin[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdouble_passin"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cdouble_passin(
  /* in */ Args_Cdouble self,
  /* in */ double d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdouble.passin) */
  return (d == 3.14);
  /* DO-NOT-DELETE splicer.end(Args.Cdouble.passin) */
  }
}

/*
 * Method:  passout[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdouble_passout"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cdouble_passout(
  /* in */ Args_Cdouble self,
  /* out */ double* d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdouble.passout) */
  *d = 3.14;
  return TRUE;
  /* DO-NOT-DELETE splicer.end(Args.Cdouble.passout) */
  }
}

/*
 * Method:  passinout[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdouble_passinout"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cdouble_passinout(
  /* in */ Args_Cdouble self,
  /* inout */ double* d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdouble.passinout) */
  *d = - (*d);
  return TRUE;
  /* DO-NOT-DELETE splicer.end(Args.Cdouble.passinout) */
  }
}

/*
 * Method:  passeverywhere[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdouble_passeverywhere"

#ifdef __cplusplus
extern "C"
#endif
double
impl_Args_Cdouble_passeverywhere(
  /* in */ Args_Cdouble self,
  /* in */ double d1,
  /* out */ double* d2,
  /* inout */ double* d3,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdouble.passeverywhere) */
  *d2 = 3.14;
  *d3 = - (*d3);
  return (d1 == 3.14) ? 3.14 : 0.0;
  /* DO-NOT-DELETE splicer.end(Args.Cdouble.passeverywhere) */
  }
}
/* Babel internal methods, Users should not edit below this line. */
struct Args_Cdouble__object* impl_Args_Cdouble_fconnect_Args_Cdouble(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return Args_Cdouble__connectI(url, ar, _ex);
}
struct Args_Cdouble__object* impl_Args_Cdouble_fcast_Args_Cdouble(void* bi, 
  sidl_BaseInterface* _ex) {
  return Args_Cdouble__cast(bi, _ex);
}
struct sidl_BaseClass__object* impl_Args_Cdouble_fconnect_sidl_BaseClass(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connectI(url, ar, _ex);
}
struct sidl_BaseClass__object* impl_Args_Cdouble_fcast_sidl_BaseClass(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_BaseClass__cast(bi, _ex);
}
struct sidl_BaseInterface__object* 
  impl_Args_Cdouble_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connectI(url, ar, _ex);
}
struct sidl_BaseInterface__object* impl_Args_Cdouble_fcast_sidl_BaseInterface(
  void* bi, sidl_BaseInterface* _ex) {
  return sidl_BaseInterface__cast(bi, _ex);
}
struct sidl_ClassInfo__object* impl_Args_Cdouble_fconnect_sidl_ClassInfo(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connectI(url, ar, _ex);
}
struct sidl_ClassInfo__object* impl_Args_Cdouble_fcast_sidl_ClassInfo(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_ClassInfo__cast(bi, _ex);
}
struct sidl_RuntimeException__object* 
  impl_Args_Cdouble_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex) {
  return sidl_RuntimeException__connectI(url, ar, _ex);
}
struct sidl_RuntimeException__object* 
  impl_Args_Cdouble_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex) {
  return sidl_RuntimeException__cast(bi, _ex);
}
