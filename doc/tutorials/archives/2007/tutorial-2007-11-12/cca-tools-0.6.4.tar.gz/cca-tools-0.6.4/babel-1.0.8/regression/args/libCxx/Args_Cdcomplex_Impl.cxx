// 
// File:          Args_Cdcomplex_Impl.cxx
// Symbol:        Args.Cdcomplex-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Cdcomplex
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "Args_Cdcomplex_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(Args.Cdcomplex._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Cdcomplex._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
Args::Cdcomplex_impl::Cdcomplex_impl() : StubBase(reinterpret_cast< void*>(
  ::Args::Cdcomplex::_wrapObj(reinterpret_cast< void*>(this))),false) , 
  _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(Args.Cdcomplex._ctor2)
  // Insert-Code-Here {Args.Cdcomplex._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(Args.Cdcomplex._ctor2)
}

// user defined constructor
void Args::Cdcomplex_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(Args.Cdcomplex._ctor)
  // add construction details here
  // DO-NOT-DELETE splicer.end(Args.Cdcomplex._ctor)
}

// user defined destructor
void Args::Cdcomplex_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(Args.Cdcomplex._dtor)
  // add destruction details here
  // DO-NOT-DELETE splicer.end(Args.Cdcomplex._dtor)
}

// static class initializer
void Args::Cdcomplex_impl::_load() {
  // DO-NOT-DELETE splicer.begin(Args.Cdcomplex._load)
  // guaranteed to be called at most once before any other method in this class
  // DO-NOT-DELETE splicer.end(Args.Cdcomplex._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  returnback[]
 */
::std::complex<double>
Args::Cdcomplex_impl::returnback_impl () 

{
  // DO-NOT-DELETE splicer.begin(Args.Cdcomplex.returnback)
  return std::complex<double>(3.14, 3.14);
  // DO-NOT-DELETE splicer.end(Args.Cdcomplex.returnback)
}

/**
 * Method:  passin[]
 */
bool
Args::Cdcomplex_impl::passin_impl (
  /* in */const ::std::complex<double>& c ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cdcomplex.passin)
  return ( c.real() == 3.14 && c.imag() == 3.14 );
  // DO-NOT-DELETE splicer.end(Args.Cdcomplex.passin)
}

/**
 * Method:  passout[]
 */
bool
Args::Cdcomplex_impl::passout_impl (
  /* out */::std::complex<double>& c ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cdcomplex.passout)
  c = std::complex<double>(3.14,3.14);
  return true;
  // DO-NOT-DELETE splicer.end(Args.Cdcomplex.passout)
}

/**
 * Method:  passinout[]
 */
bool
Args::Cdcomplex_impl::passinout_impl (
  /* inout */::std::complex<double>& c ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cdcomplex.passinout)
  c = std::complex<double>(c.real(), -c.imag() );
  // was 'c=conj(c);' but I've had too many compilers complain for no reason.  :[
  return true;
  // DO-NOT-DELETE splicer.end(Args.Cdcomplex.passinout)
}

/**
 * Method:  passeverywhere[]
 */
::std::complex<double>
Args::Cdcomplex_impl::passeverywhere_impl (
  /* in */const ::std::complex<double>& c1,
  /* out */::std::complex<double>& c2,
  /* inout */::std::complex<double>& c3 ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cdcomplex.passeverywhere)
  std::complex<double> temp( 3.14, 3.14 );
  std::complex<double> error(0.0,0.0);
  c2 = temp;
  c3 = std::complex<double>(c3.real(),-c3.imag()); 
  // was 'c3=conj(c3);' but I've had too many compilers complain for no reason.  :[
  return ( c1 == temp ) ? temp : error;
  // DO-NOT-DELETE splicer.end(Args.Cdcomplex.passeverywhere)
}


// DO-NOT-DELETE splicer.begin(Args.Cdcomplex._misc)
// Put miscellaneous code here
// DO-NOT-DELETE splicer.end(Args.Cdcomplex._misc)

