#!/bin/sh
# 
# setup the general Linux flags

export MAIL_SERVER=smtp.llnl.gov
export SH=bash
export PACKAGE=babel
export SNAPSHOT_NUMBER=`date '+%Y%m%d'`
export PATH=/usr/casc/babel/apps/linux/bin:/usr/casc/babel/apps/linux/java/bin:/usr/bin:/bin:/usr/X11R6/bin
export LD_LIBRARY_PATH=/usr/casc/babel/apps/linux/lib
export JNI_INCLUDES='/usr/casc/babel/apps/linux/java/include /usr/casc/babel/apps/linux/java/include/linux'
host=`hostname`
if ( uname -r | grep EL 2>&1 > /dev/null ) then
  export PATH=/usr/casc/babel/apps/linux_el/bin:${PATH}
  export LD_LIBRARY_PATH=/usr/casc/babel/apps/linux_el/lib:${LD_LIBRARY_PATH}
fi
. /usr/apps/subversion/new/setup.sh
export SVN=svn
if test `whoami` == "epperly2"; then
 SVNUSER=epperly@
else
 SVNUSER=
fi
export SVNROOT=svn+ssh://${SVNUSER}cca-forum.org/home/svn/babel/trunk
export MAKE=make
export MAIL=mail
export PERL=perl
export ACLOCAL=aclocal
export AUTOMAKE=automake
export AUTOCONF=autoconf
export CD=cd
export MKDIR=mkdir
export RM=rm
export MV=mv
export CHMOD=chmod
export CHGRP=chgrp
export FIND=find
# export PACKAGING_BUILDDIR=/export/0/babel_test
# export PACKAGING_BUILDDIR=${HOME}/babel_scratch
export PACKAGING_BUILDDIR=/usr/casc_scratch/babel
mkdir -p ${PACKAGING_BUILDDIR}
