// 
// File:          Args_Cbool_Impl.hxx
// Symbol:        Args.Cbool-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Cbool
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_Args_Cbool_Impl_hxx
#define included_Args_Cbool_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_Args_Cbool_IOR_h
#include "Args_Cbool_IOR.h"
#endif
#ifndef included_Args_Cbool_hxx
#include "Args_Cbool.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(Args.Cbool._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Cbool._includes)

namespace Args { 

  /**
   * Symbol "Args.Cbool" (version 1.0)
   */
  class Cbool_impl : public virtual ::Args::Cbool 
  // DO-NOT-DELETE splicer.begin(Args.Cbool._inherits)
  // Put additional inheritance here...
  // DO-NOT-DELETE splicer.end(Args.Cbool._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(Args.Cbool._implementation)
    // Put additional implementation details here...
    // DO-NOT-DELETE splicer.end(Args.Cbool._implementation)

  public:
    // default constructor, used for data wrapping(required)
    Cbool_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    Cbool_impl( struct Args_Cbool__object * s ) : StubBase(s,true), _wrapped(
      false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~Cbool_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    bool
    returnback_impl() ;
    /**
     * user defined non-static method.
     */
    bool
    passin_impl (
      /* in */bool b
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passout_impl (
      /* out */bool& b
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passinout_impl (
      /* inout */bool& b
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passeverywhere_impl (
      /* in */bool b1,
      /* out */bool& b2,
      /* inout */bool& b3
    )
    ;

  };  // end class Cbool_impl

} // end namespace Args

// DO-NOT-DELETE splicer.begin(Args.Cbool._misc)
// Put miscellaneous things here...
// DO-NOT-DELETE splicer.end(Args.Cbool._misc)

#endif
