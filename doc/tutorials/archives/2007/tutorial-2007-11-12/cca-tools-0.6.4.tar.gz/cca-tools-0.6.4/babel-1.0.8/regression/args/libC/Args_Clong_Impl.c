/*
 * File:          Args_Clong_Impl.c
 * Symbol:        Args.Clong-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Clong
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "Args.Clong" (version 1.0)
 */

#include "Args_Clong_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"

/* DO-NOT-DELETE splicer.begin(Args.Clong._includes) */
/* Put additional includes or other arbitrary code here... */
/* DO-NOT-DELETE splicer.end(Args.Clong._includes) */

#define SIDL_IOR_MAJOR_VERSION 1
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Clong__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Clong__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Clong._load) */
  /* Insert the implementation of the static class initializer method here... */
  /* DO-NOT-DELETE splicer.end(Args.Clong._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Clong__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Clong__ctor(
  /* in */ Args_Clong self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Clong._ctor) */
  /* Insert the implementation of the constructor method here... */
  /* DO-NOT-DELETE splicer.end(Args.Clong._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Clong__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Clong__ctor2(
  /* in */ Args_Clong self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Clong._ctor2) */
  /* Insert-Code-Here {Args.Clong._ctor2} (special constructor method) */
  /* DO-NOT-DELETE splicer.end(Args.Clong._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Clong__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Clong__dtor(
  /* in */ Args_Clong self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Clong._dtor) */
  /* Insert the implementation of the constructor method here... */
  /* DO-NOT-DELETE splicer.end(Args.Clong._dtor) */
  }
}

/*
 * Method:  returnback[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Clong_returnback"

#ifdef __cplusplus
extern "C"
#endif
int64_t
impl_Args_Clong_returnback(
  /* in */ Args_Clong self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Clong.returnback) */
  return 3L;
  /* DO-NOT-DELETE splicer.end(Args.Clong.returnback) */
  }
}

/*
 * Method:  passin[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Clong_passin"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Clong_passin(
  /* in */ Args_Clong self,
  /* in */ int64_t l,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Clong.passin) */
  return ( l == 3L );
  /* DO-NOT-DELETE splicer.end(Args.Clong.passin) */
  }
}

/*
 * Method:  passout[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Clong_passout"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Clong_passout(
  /* in */ Args_Clong self,
  /* out */ int64_t* l,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Clong.passout) */
  *l = 3L;
  return TRUE;
  /* DO-NOT-DELETE splicer.end(Args.Clong.passout) */
  }
}

/*
 * Method:  passinout[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Clong_passinout"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Clong_passinout(
  /* in */ Args_Clong self,
  /* inout */ int64_t* l,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Clong.passinout) */
  *l = -(*l);
  return TRUE;
  /* DO-NOT-DELETE splicer.end(Args.Clong.passinout) */
  }
}

/*
 * Method:  passeverywhere[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Clong_passeverywhere"

#ifdef __cplusplus
extern "C"
#endif
int64_t
impl_Args_Clong_passeverywhere(
  /* in */ Args_Clong self,
  /* in */ int64_t l1,
  /* out */ int64_t* l2,
  /* inout */ int64_t* l3,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Clong.passeverywhere) */
  *l2 = 3L;
  *l3 = -(*l3);
  return (l1 == 3L) ? 3L : 0L;
  /* DO-NOT-DELETE splicer.end(Args.Clong.passeverywhere) */
  }
}
/* Babel internal methods, Users should not edit below this line. */
struct Args_Clong__object* impl_Args_Clong_fconnect_Args_Clong(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return Args_Clong__connectI(url, ar, _ex);
}
struct Args_Clong__object* impl_Args_Clong_fcast_Args_Clong(void* bi, 
  sidl_BaseInterface* _ex) {
  return Args_Clong__cast(bi, _ex);
}
struct sidl_BaseClass__object* impl_Args_Clong_fconnect_sidl_BaseClass(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connectI(url, ar, _ex);
}
struct sidl_BaseClass__object* impl_Args_Clong_fcast_sidl_BaseClass(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_BaseClass__cast(bi, _ex);
}
struct sidl_BaseInterface__object* impl_Args_Clong_fconnect_sidl_BaseInterface(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connectI(url, ar, _ex);
}
struct sidl_BaseInterface__object* impl_Args_Clong_fcast_sidl_BaseInterface(
  void* bi, sidl_BaseInterface* _ex) {
  return sidl_BaseInterface__cast(bi, _ex);
}
struct sidl_ClassInfo__object* impl_Args_Clong_fconnect_sidl_ClassInfo(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connectI(url, ar, _ex);
}
struct sidl_ClassInfo__object* impl_Args_Clong_fcast_sidl_ClassInfo(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_ClassInfo__cast(bi, _ex);
}
struct sidl_RuntimeException__object* 
  impl_Args_Clong_fconnect_sidl_RuntimeException(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex) {
  return sidl_RuntimeException__connectI(url, ar, _ex);
}
struct sidl_RuntimeException__object* 
  impl_Args_Clong_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex) {
  return sidl_RuntimeException__cast(bi, _ex);
}
