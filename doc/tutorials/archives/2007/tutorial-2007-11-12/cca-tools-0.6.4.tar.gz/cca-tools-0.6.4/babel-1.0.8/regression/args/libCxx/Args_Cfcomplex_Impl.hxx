// 
// File:          Args_Cfcomplex_Impl.hxx
// Symbol:        Args.Cfcomplex-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Cfcomplex
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_Args_Cfcomplex_Impl_hxx
#define included_Args_Cfcomplex_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_Args_Cfcomplex_IOR_h
#include "Args_Cfcomplex_IOR.h"
#endif
#ifndef included_Args_Cfcomplex_hxx
#include "Args_Cfcomplex.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(Args.Cfcomplex._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Cfcomplex._includes)

namespace Args { 

  /**
   * Symbol "Args.Cfcomplex" (version 1.0)
   */
  class Cfcomplex_impl : public virtual ::Args::Cfcomplex 
  // DO-NOT-DELETE splicer.begin(Args.Cfcomplex._inherits)
  // Put additional inheritance here...
  // DO-NOT-DELETE splicer.end(Args.Cfcomplex._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(Args.Cfcomplex._implementation)
    // Put additional implementation details here...
    // DO-NOT-DELETE splicer.end(Args.Cfcomplex._implementation)

  public:
    // default constructor, used for data wrapping(required)
    Cfcomplex_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    Cfcomplex_impl( struct Args_Cfcomplex__object * s ) : StubBase(s,true), 
      _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~Cfcomplex_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    ::std::complex<float>
    returnback_impl() ;
    /**
     * user defined non-static method.
     */
    bool
    passin_impl (
      /* in */const ::std::complex<float>& c
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passout_impl (
      /* out */::std::complex<float>& c
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passinout_impl (
      /* inout */::std::complex<float>& c
    )
    ;

    /**
     * user defined non-static method.
     */
    ::std::complex<float>
    passeverywhere_impl (
      /* in */const ::std::complex<float>& c1,
      /* out */::std::complex<float>& c2,
      /* inout */::std::complex<float>& c3
    )
    ;

  };  // end class Cfcomplex_impl

} // end namespace Args

// DO-NOT-DELETE splicer.begin(Args.Cfcomplex._misc)
// Put miscellaneous things here...
// DO-NOT-DELETE splicer.end(Args.Cfcomplex._misc)

#endif
