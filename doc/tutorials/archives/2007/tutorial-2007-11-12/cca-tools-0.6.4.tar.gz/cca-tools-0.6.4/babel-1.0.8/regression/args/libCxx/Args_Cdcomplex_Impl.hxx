// 
// File:          Args_Cdcomplex_Impl.hxx
// Symbol:        Args.Cdcomplex-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Cdcomplex
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_Args_Cdcomplex_Impl_hxx
#define included_Args_Cdcomplex_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_Args_Cdcomplex_IOR_h
#include "Args_Cdcomplex_IOR.h"
#endif
#ifndef included_Args_Cdcomplex_hxx
#include "Args_Cdcomplex.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(Args.Cdcomplex._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Cdcomplex._includes)

namespace Args { 

  /**
   * Symbol "Args.Cdcomplex" (version 1.0)
   */
  class Cdcomplex_impl : public virtual ::Args::Cdcomplex 
  // DO-NOT-DELETE splicer.begin(Args.Cdcomplex._inherits)
  // Put additional inheritance here...
  // DO-NOT-DELETE splicer.end(Args.Cdcomplex._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(Args.Cdcomplex._implementation)
    // Put additional implementation details here...
    // DO-NOT-DELETE splicer.end(Args.Cdcomplex._implementation)

  public:
    // default constructor, used for data wrapping(required)
    Cdcomplex_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    Cdcomplex_impl( struct Args_Cdcomplex__object * s ) : StubBase(s,true), 
      _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~Cdcomplex_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    ::std::complex<double>
    returnback_impl() ;
    /**
     * user defined non-static method.
     */
    bool
    passin_impl (
      /* in */const ::std::complex<double>& c
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passout_impl (
      /* out */::std::complex<double>& c
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passinout_impl (
      /* inout */::std::complex<double>& c
    )
    ;

    /**
     * user defined non-static method.
     */
    ::std::complex<double>
    passeverywhere_impl (
      /* in */const ::std::complex<double>& c1,
      /* out */::std::complex<double>& c2,
      /* inout */::std::complex<double>& c3
    )
    ;

  };  // end class Cdcomplex_impl

} // end namespace Args

// DO-NOT-DELETE splicer.begin(Args.Cdcomplex._misc)
// Put miscellaneous things here...
// DO-NOT-DELETE splicer.end(Args.Cdcomplex._misc)

#endif
