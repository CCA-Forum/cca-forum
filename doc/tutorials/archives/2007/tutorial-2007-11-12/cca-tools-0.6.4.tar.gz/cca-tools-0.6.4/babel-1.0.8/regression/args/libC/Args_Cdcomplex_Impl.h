/*
 * File:          Args_Cdcomplex_Impl.h
 * Symbol:        Args.Cdcomplex-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cdcomplex
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_Args_Cdcomplex_Impl_h
#define included_Args_Cdcomplex_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_Args_Cdcomplex_h
#include "Args_Cdcomplex.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif

/* DO-NOT-DELETE splicer.begin(Args.Cdcomplex._includes) */
/* Put additional include files here... */
/* DO-NOT-DELETE splicer.end(Args.Cdcomplex._includes) */

/*
 * Private data for class Args.Cdcomplex
 */

struct Args_Cdcomplex__data {
  /* DO-NOT-DELETE splicer.begin(Args.Cdcomplex._data) */
  /* Put private data members here... */
  int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(Args.Cdcomplex._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct Args_Cdcomplex__data*
Args_Cdcomplex__get_data(
  Args_Cdcomplex);

extern void
Args_Cdcomplex__set_data(
  Args_Cdcomplex,
  struct Args_Cdcomplex__data*);

extern
void
impl_Args_Cdcomplex__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cdcomplex__ctor(
  /* in */ Args_Cdcomplex self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cdcomplex__ctor2(
  /* in */ Args_Cdcomplex self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cdcomplex__dtor(
  /* in */ Args_Cdcomplex self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct Args_Cdcomplex__object* 
  impl_Args_Cdcomplex_fconnect_Args_Cdcomplex(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct Args_Cdcomplex__object* impl_Args_Cdcomplex_fcast_Args_Cdcomplex(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_Args_Cdcomplex_fconnect_sidl_BaseClass(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_Args_Cdcomplex_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cdcomplex_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cdcomplex_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_ClassInfo__object* 
  impl_Args_Cdcomplex_fconnect_sidl_ClassInfo(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_Args_Cdcomplex_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cdcomplex_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cdcomplex_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
extern
struct sidl_dcomplex
impl_Args_Cdcomplex_returnback(
  /* in */ Args_Cdcomplex self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cdcomplex_passin(
  /* in */ Args_Cdcomplex self,
  /* in */ struct sidl_dcomplex c,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cdcomplex_passout(
  /* in */ Args_Cdcomplex self,
  /* out */ struct sidl_dcomplex* c,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cdcomplex_passinout(
  /* in */ Args_Cdcomplex self,
  /* inout */ struct sidl_dcomplex* c,
  /* out */ sidl_BaseInterface *_ex);

extern
struct sidl_dcomplex
impl_Args_Cdcomplex_passeverywhere(
  /* in */ Args_Cdcomplex self,
  /* in */ struct sidl_dcomplex c1,
  /* out */ struct sidl_dcomplex* c2,
  /* inout */ struct sidl_dcomplex* c3,
  /* out */ sidl_BaseInterface *_ex);

extern struct Args_Cdcomplex__object* 
  impl_Args_Cdcomplex_fconnect_Args_Cdcomplex(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct Args_Cdcomplex__object* impl_Args_Cdcomplex_fcast_Args_Cdcomplex(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_Args_Cdcomplex_fconnect_sidl_BaseClass(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_Args_Cdcomplex_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cdcomplex_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cdcomplex_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_ClassInfo__object* 
  impl_Args_Cdcomplex_fconnect_sidl_ClassInfo(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_Args_Cdcomplex_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cdcomplex_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cdcomplex_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
#ifdef __cplusplus
}
#endif
#endif
