/*
 * File:          Args_Cfcomplex_Impl.h
 * Symbol:        Args.Cfcomplex-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cfcomplex
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_Args_Cfcomplex_Impl_h
#define included_Args_Cfcomplex_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_Args_Cfcomplex_h
#include "Args_Cfcomplex.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif

/* DO-NOT-DELETE splicer.begin(Args.Cfcomplex._includes) */
/* Put additional include files here... */
/* DO-NOT-DELETE splicer.end(Args.Cfcomplex._includes) */

/*
 * Private data for class Args.Cfcomplex
 */

struct Args_Cfcomplex__data {
  /* DO-NOT-DELETE splicer.begin(Args.Cfcomplex._data) */
  /* Put private data members here... */
  int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(Args.Cfcomplex._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct Args_Cfcomplex__data*
Args_Cfcomplex__get_data(
  Args_Cfcomplex);

extern void
Args_Cfcomplex__set_data(
  Args_Cfcomplex,
  struct Args_Cfcomplex__data*);

extern
void
impl_Args_Cfcomplex__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cfcomplex__ctor(
  /* in */ Args_Cfcomplex self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cfcomplex__ctor2(
  /* in */ Args_Cfcomplex self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cfcomplex__dtor(
  /* in */ Args_Cfcomplex self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct Args_Cfcomplex__object* 
  impl_Args_Cfcomplex_fconnect_Args_Cfcomplex(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct Args_Cfcomplex__object* impl_Args_Cfcomplex_fcast_Args_Cfcomplex(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_Args_Cfcomplex_fconnect_sidl_BaseClass(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_Args_Cfcomplex_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cfcomplex_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cfcomplex_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_ClassInfo__object* 
  impl_Args_Cfcomplex_fconnect_sidl_ClassInfo(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_Args_Cfcomplex_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cfcomplex_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cfcomplex_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
extern
struct sidl_fcomplex
impl_Args_Cfcomplex_returnback(
  /* in */ Args_Cfcomplex self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cfcomplex_passin(
  /* in */ Args_Cfcomplex self,
  /* in */ struct sidl_fcomplex c,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cfcomplex_passout(
  /* in */ Args_Cfcomplex self,
  /* out */ struct sidl_fcomplex* c,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cfcomplex_passinout(
  /* in */ Args_Cfcomplex self,
  /* inout */ struct sidl_fcomplex* c,
  /* out */ sidl_BaseInterface *_ex);

extern
struct sidl_fcomplex
impl_Args_Cfcomplex_passeverywhere(
  /* in */ Args_Cfcomplex self,
  /* in */ struct sidl_fcomplex c1,
  /* out */ struct sidl_fcomplex* c2,
  /* inout */ struct sidl_fcomplex* c3,
  /* out */ sidl_BaseInterface *_ex);

extern struct Args_Cfcomplex__object* 
  impl_Args_Cfcomplex_fconnect_Args_Cfcomplex(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct Args_Cfcomplex__object* impl_Args_Cfcomplex_fcast_Args_Cfcomplex(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_Args_Cfcomplex_fconnect_sidl_BaseClass(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_Args_Cfcomplex_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cfcomplex_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cfcomplex_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_ClassInfo__object* 
  impl_Args_Cfcomplex_fconnect_sidl_ClassInfo(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_Args_Cfcomplex_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cfcomplex_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cfcomplex_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
#ifdef __cplusplus
}
#endif
#endif
