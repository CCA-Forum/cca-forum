/*
 * File:          vector_Utils_Impl.c
 * Symbol:        vector.Utils-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for vector.Utils
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "vector.Utils" (version 1.0)
 */

#include "vector_Utils_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"

/* DO-NOT-DELETE splicer.begin(vector.Utils._includes) */
/************************** Includes **************************/
#include <stdio.h>
#include <math.h>
#include <time.h>
#include "sidlArray.h"
#include "sidl_Exception.h"
#include "vector_Exception.h"
#include "vector_ExceptionHelpers.h"
#include "vector_DivideByZeroException.h"
#include "vector_NegativeValueException.h"

/******************* Additional routine(s)  *******************/
static FILE* s_fptr     = NULL;
static char* s_filename = "VUUtils.excepts";

static void
printMessage(const char* msg){
  time_t currTime;
  if (s_fptr == NULL) {
    if ((s_fptr=fopen(s_filename,"w")) == NULL) {
      printf("Cannot open file %s to dump messages\n", s_filename);
      return;
    }
  }
  currTime = time(NULL);
  fprintf(s_fptr, "\nVECTORUTILS.OPS MESSAGE AT %s", ctime(&currTime));
  fprintf(s_fptr, "  %s\n", msg);
}
/* DO-NOT-DELETE splicer.end(vector.Utils._includes) */

#define SIDL_IOR_MAJOR_VERSION 1
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_vector_Utils__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils._load) */
  /* Insert-Code-Here {vector.Utils._load} (static class initializer method) */
  /* DO-NOT-DELETE splicer.end(vector.Utils._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_vector_Utils__ctor(
  /* in */ vector_Utils self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils._ctor) */
  /* Nothing to do here */
  /* DO-NOT-DELETE splicer.end(vector.Utils._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_vector_Utils__ctor2(
  /* in */ vector_Utils self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils._ctor2) */
  /* Insert-Code-Here {vector.Utils._ctor2} (special constructor method) */
  /* DO-NOT-DELETE splicer.end(vector.Utils._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_vector_Utils__dtor(
  /* in */ vector_Utils self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils._dtor) */
  /* Nothing to do here */
  /* DO-NOT-DELETE splicer.end(vector.Utils._dtor) */
  }
}

/*
 * Static Method to handle assertion violations.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils__check_error_static"

#ifdef __cplusplus
extern "C"
#endif
void
impl_vector_Utils__check_error_static(
  /* in */ const char* msg,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils._check_error_static) */
  printMessage(msg);
  /* DO-NOT-DELETE splicer.end(vector.Utils._check_error_static) */
  }
}

/*
 * Method to handle assertion violations.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils__check_error"

#ifdef __cplusplus
extern "C"
#endif
void
impl_vector_Utils__check_error(
  /* in */ vector_Utils self,
  /* in */ const char* msg,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils._check_error) */
  printMessage(msg);
  /* DO-NOT-DELETE splicer.end(vector.Utils._check_error) */
  }
}

/*
 * boolean result operations 
 * Return TRUE if the specified vector is the zero vector, within the
 * given tolerance level; otherwise, return FALSE.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils_isZero"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_vector_Utils_isZero(
  /* in array<double> */ struct sidl_double__array* u,
  /* in */ double tol,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils.isZero) */
  sidl_bool is   = TRUE;
  int       i;
  int       maxI = sidl_double__array_upper(u, 0);
  for (i=sidl_double__array_lower(u, 0); (i<=maxI) && is; i++) {
    double absDiff = fabs(sidl_double__array_get1(u, i));
    if ( absDiff > tol ) {
       is = FALSE;
    } 
  }
  return is;
  /* DO-NOT-DELETE splicer.end(vector.Utils.isZero) */
  }
}

/*
 * Return TRUE if the specified vector is the unit vector, within the
 * given tolerance level; otherwise, return FALSE.
 * 
 * Note that the PostViolation can arise since the implementation
 * invokes norm through the stub.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils_isUnit"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_vector_Utils_isUnit(
  /* in array<double> */ struct sidl_double__array* u,
  /* in */ double tol,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils.isUnit) */
  sidl_bool is      = FALSE;
  double    absDiff = fabs(vector_Utils_norm(u, tol, 0, _ex) 
                          - 1.0); VU_CHECK(*_ex)
  if ( absDiff <= tol ) {
    is = TRUE;
  } else {
    is = FALSE;
  }

  EXIT:;
  return is;
  /* DO-NOT-DELETE splicer.end(vector.Utils.isUnit) */
  }
}

/*
 * Return TRUE if the specified vectors are equal, within the given
 * tolerance level; otherwise, return FALSE.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils_areEqual"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_vector_Utils_areEqual(
  /* in array<double> */ struct sidl_double__array* u,
  /* in array<double> */ struct sidl_double__array* v,
  /* in */ double tol,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils.areEqual) */
  int       sizeU = sidlLength(u, 0);
  sidl_bool are   = TRUE;
  int       i;
  for (i=0; (i<sizeU) && are; i++) {
    double absDiff = fabs(sidl_double__array_get1(u, i) 
                         - sidl_double__array_get1(v, i));
    if ( absDiff > tol ) {
      are = FALSE;
    } 
  } 

  return are;
  /* DO-NOT-DELETE splicer.end(vector.Utils.areEqual) */
  }
}

/*
 * Return TRUE if the specified vectors are orthogonal, within the given
 * tolerance; otherwise, return FALSE.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils_areOrthogonal"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_vector_Utils_areOrthogonal(
  /* in array<double> */ struct sidl_double__array* u,
  /* in array<double> */ struct sidl_double__array* v,
  /* in */ double tol,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils.areOrthogonal) */
  sidl_bool are  = FALSE;

  double absVal = fabs(vector_Utils_dot(u, v, tol, 0, _ex)); VU_CHECK(*_ex)
  if ( absVal <= tol ) {
    are = TRUE;
  } else {
    are = FALSE;
  }

  EXIT:;
  return are;
  /* DO-NOT-DELETE splicer.end(vector.Utils.areOrthogonal) */
  }
}

/*
 * Return TRUE if the Schwarz (or Cauchy-Schwarz) inequality holds, within
 * the given tolerance; otherwise, return FALSE.
 * 
 * Note that the PostViolation can arise since the implementation
 * invokes norm through the stub.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils_schwarzHolds"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_vector_Utils_schwarzHolds(
  /* in array<double> */ struct sidl_double__array* u,
  /* in array<double> */ struct sidl_double__array* v,
  /* in */ double tol,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils.schwarzHolds) */
  sidl_bool holds = FALSE;

  double absDot;
  double absNorms;
  absDot = fabs(vector_Utils_dot(u, v, tol, 0, _ex)); VU_CHECK(*_ex)

  absNorms = fabs(vector_Utils_norm(u, tol, 0, _ex) 
             * vector_Utils_norm(v, tol, 0, _ex)); VU_CHECK(*_ex)
  if ( absDot <= absNorms ) {
    holds = TRUE;
  } else {
    holds = FALSE;
  }

  EXIT:;
  return holds;
  /* DO-NOT-DELETE splicer.end(vector.Utils.schwarzHolds) */
  }
}

/*
 * Return TRUE if the Minkowski (or triangle) inequality holds, within the
 * given tolerance; otherwise, return FALSE.
 * 
 * Note that the PostViolation can arise since the implementation
 * invokes norm through the stub.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils_triangleInequalityHolds"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_vector_Utils_triangleInequalityHolds(
  /* in array<double> */ struct sidl_double__array* u,
  /* in array<double> */ struct sidl_double__array* v,
  /* in */ double tol,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils.triangleInequalityHolds) */
  sidl_bool holds = FALSE;

  struct sidl_double__array* sum = NULL;
  double absNormSum;
  double normU;
  double normV;
  double absSumNorms;
  sum = vector_Utils_sum(u,v,0,_ex); VU_CHECK(*_ex)
  absNormSum = fabs(vector_Utils_norm(sum, tol, 0, _ex)); VU_CHECK(*_ex)
  normU = vector_Utils_norm(u, tol, 0, _ex); VU_CHECK(*_ex)
  normV = vector_Utils_norm(v, tol, 0, _ex); VU_CHECK(*_ex)
  absSumNorms = fabs(normU + normV);
  if ( absNormSum <= absSumNorms ) {
    holds = TRUE;
  } else {
    holds = FALSE;
  }

  EXIT:;
  if (sum != NULL) sidl_double__array_deleteRef(sum);
  return holds;
  /* DO-NOT-DELETE splicer.end(vector.Utils.triangleInequalityHolds) */
  }
}

/*
 * double result operations 
 * Return the norm (or length) of the specified vector.
 * 
 * Note that the size exception is given here simply because the 
 * implementation is leveraging the dot method.  Also the tolerance
 * is included to enable the caller to specify the tolerance
 * used in assertion checking.
 * 
 * Also note that badLevel has been added only to facilitate regression
 * testing of postconditions.  The levels are:
 * 0 = NONE  (i.e., no deliberate postcondition violation)
 * 1 = Return a negative result (regardless of input)
 * 2 = Return a positive result not near zero (regardless of input), 
 * which means a violation will occur only if u is the zero
 * vector
 * 3 = Return a zero result (regardless of input), which means a
 * violation will occur only if u is not the zero vector.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils_norm"

#ifdef __cplusplus
extern "C"
#endif
double
impl_vector_Utils_norm(
  /* in array<double> */ struct sidl_double__array* u,
  /* in */ double tol,
  /* in */ int32_t badLevel,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils.norm) */
  vector_NegativeValueException err = NULL;
  double                        res = 0.0;

  char* msg = 
    "NegativeValue_Exception: Cannot take the square root of a negative value";

  if (badLevel == 0) {
    double dot = vector_Utils_dot(u, u, tol, 0, _ex); VU_CHECK(*_ex)
    if (dot > 0.0) {
      res = (double) sqrt(dot);
    } else if (dot < 0.0) {
      /* Note that this should NEVER happen! */
      VU_THROW(err, vector_NegativeValueException, msg);
    }
  } else if (badLevel == 1) {
    res = -5.0;
  } else if (badLevel == 2) {
    res = 5.0;
  } else if (badLevel == 3) {
    res = 0.0;
  } else {
    res = -5.0;
  }

  EXIT:;
  if (err != NULL) {
    sidl_BaseInterface throwaway_exception;
    (*_ex) = sidl_BaseInterface__cast(err, &throwaway_exception);
    vector_NegativeValueException_deleteRef(err, &throwaway_exception);
  }
  return res;
  /* DO-NOT-DELETE splicer.end(vector.Utils.norm) */
  }
}

/*
 * Return the dot (, inner, or scalar) product of the specified vectors.
 * 
 * Note that badLevel has been added only to facilitate regression
 * testing of postconditions.  The levels are:
 * 0 = NONE  (i.e., no deliberate postcondition violation)
 * 1 = Return a negative result (regardless of input)
 * 2 = Return a positive result not near zero (regardless of input), 
 * which means a violation will occur only if u and v are the zero
 * vector
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils_dot"

#ifdef __cplusplus
extern "C"
#endif
double
impl_vector_Utils_dot(
  /* in array<double> */ struct sidl_double__array* u,
  /* in array<double> */ struct sidl_double__array* v,
  /* in */ double tol,
  /* in */ int32_t badLevel,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils.dot) */
  int    sizeU = sidlLength(u, 0);
  double dot   = 0.0;
  if (badLevel == 0) {
    int    i;
    for (i=0; i<sizeU; i++) {
      dot += sidl_double__array_get1(u,i) * sidl_double__array_get1(v,i);
    }
  } else if (badLevel == 1) {
    dot = -5.0;
  } else if (badLevel == 2) {
    dot = 5.0;
  } else {
    dot = -1.0;
  }
  return dot;
  /* DO-NOT-DELETE splicer.end(vector.Utils.dot) */
  }
}

/*
 * vector result operations 
 * Return the (scalar) product of the specified vector.
 * 
 * Note that badLevel has been added only to facilitate regression
 * testing of postconditions.  The levels are:
 * 0 = NONE  (i.e., no deliberate postcondition violation)
 * 1 = Return a null result (regardless of input)
 * 2 = Return a 2D array result (regardless of input)
 * 3 = Return an array of different size (regardless of input)
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils_product"

#ifdef __cplusplus
extern "C"
#endif
struct sidl_double__array*
impl_vector_Utils_product(
  /* in */ double a,
  /* in array<double> */ struct sidl_double__array* u,
  /* in */ int32_t badLevel,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils.product) */
  int sizeU = sidlLength(u, 0);
  struct sidl_double__array* prod = sidl_double__array_create1d(sizeU);
  struct sidl_double__array* bad2D = sidl_double__array_create2dCol(sizeU,
                                                                    sizeU);
  struct sidl_double__array* badSize = sidl_double__array_create1d(sizeU+5);

  if (badLevel == 0) {
    int i;
    for (i=0; i<sizeU; i++) {
      sidl_double__array_set1(prod, i, a * sidl_double__array_get1(u,i));
    }
    sidl_double__array_deleteRef(bad2D);
    sidl_double__array_deleteRef(badSize);
  } else if (badLevel == 1) {
    sidl_double__array_deleteRef(prod);
    sidl_double__array_deleteRef(bad2D);
    sidl_double__array_deleteRef(badSize);
    prod = NULL;
  } else if (badLevel == 2) {
    sidl_double__array_deleteRef(prod);
    sidl_double__array_deleteRef(badSize);
    prod = bad2D;
  } else if (badLevel == 3) {
    sidl_double__array_deleteRef(prod);
    sidl_double__array_deleteRef(bad2D);
    prod = badSize;
  } else {
    sidl_double__array_deleteRef(prod);
    sidl_double__array_deleteRef(bad2D);
    sidl_double__array_deleteRef(badSize);
    prod = NULL;
  }
  return prod;
  /* DO-NOT-DELETE splicer.end(vector.Utils.product) */
  }
}

/*
 * Return the negation of the specified vector.
 * 
 * Note that badLevel has been added only to facilitate regression
 * testing of postconditions.  The levels are:
 * 0 = NONE  (i.e., no deliberate postcondition violation)
 * 1 = Return a null result (regardless of input)
 * 2 = Return a 2D array result (regardless of input)
 * 3 = Return an array of different size (regardless of input)
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils_negate"

#ifdef __cplusplus
extern "C"
#endif
struct sidl_double__array*
impl_vector_Utils_negate(
  /* in array<double> */ struct sidl_double__array* u,
  /* in */ int32_t badLevel,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils.negate) */
  int sizeU = sidlLength(u, 0);
  struct sidl_double__array* negU = NULL;
  struct sidl_double__array* bad2D = sidl_double__array_create2dCol(sizeU,
                                                                    sizeU);
  struct sidl_double__array* badSize = sidl_double__array_create1d(sizeU+5);

  if (badLevel == 0) {
    sidl_double__array_deleteRef(bad2D);
    sidl_double__array_deleteRef(badSize);
    negU = vector_Utils_product(-1.0, u, 0, _ex);
  } else if (badLevel == 1) {
    sidl_double__array_deleteRef(bad2D);
    sidl_double__array_deleteRef(badSize);
    negU = NULL;
  } else if (badLevel == 2) {
    sidl_double__array_deleteRef(badSize);
    negU = bad2D;
  } else if (badLevel == 3) {
    sidl_double__array_deleteRef(bad2D);
    negU = badSize;
  } else {
    sidl_double__array_deleteRef(bad2D);
    sidl_double__array_deleteRef(badSize);
    negU = NULL;
  }
  return negU;
  /* DO-NOT-DELETE splicer.end(vector.Utils.negate) */
  }
}

/*
 * Return the normalization of the specified vector.
 * 
 * Note that the PostViolation can arise since the implementation
 * invokes norm through the stub.  Also, the tolerance is included because
 * the implementation invokes dot through the stub.
 * 
 * Note that badLevel has been added only to facilitate regression
 * testing of postconditions.  The levels are:
 * 0 = NONE  (i.e., no deliberate postcondition violation)
 * 1 = Return a null result (regardless of input)
 * 2 = Return a 2D array result (regardless of input)
 * 3 = Return an array of different size (regardless of input)
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils_normalize"

#ifdef __cplusplus
extern "C"
#endif
struct sidl_double__array*
impl_vector_Utils_normalize(
  /* in array<double> */ struct sidl_double__array* u,
  /* in */ double tol,
  /* in */ int32_t badLevel,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils.normalize) */
  vector_DivideByZeroException err  = NULL;
  struct sidl_double__array*   prod = NULL;

  int sizeU = sidlLength(u, 0);
  struct sidl_double__array* bad2D = sidl_double__array_create2dCol(sizeU,
                                                                    sizeU);
  struct sidl_double__array* badSize = sidl_double__array_create1d(sizeU+5);

  if (badLevel == 0) {
    double val =  vector_Utils_norm(u, tol, 0, _ex); VU_CHECK(*_ex)
    sidl_double__array_deleteRef(bad2D); 
    sidl_double__array_deleteRef(badSize);
    if (val != 0.0) {
      prod = vector_Utils_product(1.0 / val, u, 0, _ex); VU_CHECK(*_ex)
    } else {
      VU_THROW(err, vector_DivideByZeroException, 
        "DivideByZeroException: Divide by zero attempted in normalize");
    }
  } else if (badLevel == 1) {
    sidl_double__array_deleteRef(bad2D); 
    sidl_double__array_deleteRef(badSize);
    prod = NULL;
  } else if (badLevel == 2) {
    sidl_double__array_deleteRef(badSize);
    prod = bad2D;
  } else if (badLevel == 3) {
    sidl_double__array_deleteRef(bad2D); 
    prod = badSize;
  } else {
    sidl_double__array_deleteRef(bad2D); 
    sidl_double__array_deleteRef(badSize);
    prod = NULL;
  }

  EXIT:;
  if (err != NULL) {
    sidl_BaseInterface throwaway_exception;
    (*_ex) = sidl_BaseInterface__cast(err, &throwaway_exception);
    vector_DivideByZeroException_deleteRef(err, &throwaway_exception);
  }
  return prod;
  /* DO-NOT-DELETE splicer.end(vector.Utils.normalize) */
  }
}

/*
 * Return the sum of the specified vectors.
 * 
 * Note that badLevel has been added only to facilitate regression
 * testing of postconditions.  The levels are:
 * 0 = NONE  (i.e., no deliberate postcondition violation)
 * 1 = Return a null result (regardless of input)
 * 2 = Return a 2D array result (regardless of input)
 * 3 = Return an array of different size (regardless of input)
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils_sum"

#ifdef __cplusplus
extern "C"
#endif
struct sidl_double__array*
impl_vector_Utils_sum(
  /* in array<double> */ struct sidl_double__array* u,
  /* in array<double> */ struct sidl_double__array* v,
  /* in */ int32_t badLevel,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils.sum) */
  int                        sizeU = sidlLength(u, 0);
  struct sidl_double__array* sum   = sidl_double__array_create1d(sizeU);

  struct sidl_double__array* bad2D = sidl_double__array_create2dCol(sizeU,
                                                                    sizeU);
  struct sidl_double__array* badSize = sidl_double__array_create1d(sizeU+5);

  if (badLevel == 0) {
    int i;
    for (i=0; i<sizeU; i++) {
      sidl_double__array_set1(sum, i, 
        sidl_double__array_get1(u,i) + sidl_double__array_get1(v,i));
    }
    sidl_double__array_deleteRef(bad2D);
    sidl_double__array_deleteRef(badSize);
  } else if (badLevel == 1) {
    sidl_double__array_deleteRef(sum);
    sidl_double__array_deleteRef(bad2D);
    sidl_double__array_deleteRef(badSize);
    sum = NULL;
  } else if (badLevel == 2) {
    sidl_double__array_deleteRef(sum);
    sidl_double__array_deleteRef(badSize);
    sum = bad2D;
  } else if (badLevel == 3) {
    sidl_double__array_deleteRef(sum);
    sidl_double__array_deleteRef(bad2D);
    sum = badSize;
  } else {
    sidl_double__array_deleteRef(sum);
    sidl_double__array_deleteRef(bad2D);
    sidl_double__array_deleteRef(badSize);
    sum = NULL;
  }
  return sum;
  /* DO-NOT-DELETE splicer.end(vector.Utils.sum) */
  }
}

/*
 * Return the difference of the specified vectors.
 * 
 * Note that badLevel has been added only to facilitate regression
 * testing of postconditions.  The levels are:
 * 0 = NONE  (i.e., no deliberate postcondition violation)
 * 1 = Return a null result (regardless of input)
 * 2 = Return a 2D array result (regardless of input)
 * 3 = Return an array of different size (regardless of input)
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_Utils_diff"

#ifdef __cplusplus
extern "C"
#endif
struct sidl_double__array*
impl_vector_Utils_diff(
  /* in array<double> */ struct sidl_double__array* u,
  /* in array<double> */ struct sidl_double__array* v,
  /* in */ int32_t badLevel,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.Utils.diff) */
  int                        sizeU = sidlLength(u, 0);
  struct sidl_double__array* diff  = sidl_double__array_create1d(sizeU);

  struct sidl_double__array* bad2D = sidl_double__array_create2dCol(sizeU,
                                                                    sizeU);
  struct sidl_double__array* badSize = sidl_double__array_create1d(sizeU+5);

  if (badLevel == 0) {
    int i;
    for (i=0; i<sizeU; i++) {
      sidl_double__array_set1(diff, i, 
        sidl_double__array_get1(u,i) - sidl_double__array_get1(v,i));
    }
    sidl_double__array_deleteRef(bad2D);
    sidl_double__array_deleteRef(badSize);
  } else if (badLevel == 1) {
    sidl_double__array_deleteRef(diff);
    sidl_double__array_deleteRef(bad2D);
    sidl_double__array_deleteRef(badSize);
    diff = NULL;
  } else if (badLevel == 2) {
    sidl_double__array_deleteRef(diff);
    sidl_double__array_deleteRef(badSize);
    diff = bad2D;
  } else if (badLevel == 3) {
    sidl_double__array_deleteRef(diff);
    sidl_double__array_deleteRef(bad2D);
    diff = badSize;
  } else {
    sidl_double__array_deleteRef(diff);
    sidl_double__array_deleteRef(bad2D);
    sidl_double__array_deleteRef(badSize);
    diff = NULL;
  }
  return diff;
  /* DO-NOT-DELETE splicer.end(vector.Utils.diff) */
  }
}
/* Babel internal methods, Users should not edit below this line. */
struct sidl_BaseClass__object* impl_vector_Utils_fconnect_sidl_BaseClass(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connectI(url, ar, _ex);
}
struct sidl_BaseClass__object* impl_vector_Utils_fcast_sidl_BaseClass(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_BaseClass__cast(bi, _ex);
}
struct sidl_BaseInterface__object* 
  impl_vector_Utils_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connectI(url, ar, _ex);
}
struct sidl_BaseInterface__object* impl_vector_Utils_fcast_sidl_BaseInterface(
  void* bi, sidl_BaseInterface* _ex) {
  return sidl_BaseInterface__cast(bi, _ex);
}
struct sidl_ClassInfo__object* impl_vector_Utils_fconnect_sidl_ClassInfo(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connectI(url, ar, _ex);
}
struct sidl_ClassInfo__object* impl_vector_Utils_fcast_sidl_ClassInfo(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_ClassInfo__cast(bi, _ex);
}
struct sidl_PostViolation__object* 
  impl_vector_Utils_fconnect_sidl_PostViolation(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex) {
  return sidl_PostViolation__connectI(url, ar, _ex);
}
struct sidl_PostViolation__object* impl_vector_Utils_fcast_sidl_PostViolation(
  void* bi, sidl_BaseInterface* _ex) {
  return sidl_PostViolation__cast(bi, _ex);
}
struct sidl_PreViolation__object* impl_vector_Utils_fconnect_sidl_PreViolation(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_PreViolation__connectI(url, ar, _ex);
}
struct sidl_PreViolation__object* impl_vector_Utils_fcast_sidl_PreViolation(
  void* bi, sidl_BaseInterface* _ex) {
  return sidl_PreViolation__cast(bi, _ex);
}
struct sidl_RuntimeException__object* 
  impl_vector_Utils_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex) {
  return sidl_RuntimeException__connectI(url, ar, _ex);
}
struct sidl_RuntimeException__object* 
  impl_vector_Utils_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex) {
  return sidl_RuntimeException__cast(bi, _ex);
}
struct vector_DivideByZeroException__object* 
  impl_vector_Utils_fconnect_vector_DivideByZeroException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return vector_DivideByZeroException__connectI(url, ar, _ex);
}
struct vector_DivideByZeroException__object* 
  impl_vector_Utils_fcast_vector_DivideByZeroException(void* bi, 
  sidl_BaseInterface* _ex) {
  return vector_DivideByZeroException__cast(bi, _ex);
}
struct vector_NegativeValueException__object* 
  impl_vector_Utils_fconnect_vector_NegativeValueException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return vector_NegativeValueException__connectI(url, ar, _ex);
}
struct vector_NegativeValueException__object* 
  impl_vector_Utils_fcast_vector_NegativeValueException(void* bi, 
  sidl_BaseInterface* _ex) {
  return vector_NegativeValueException__cast(bi, _ex);
}
struct vector_Utils__object* impl_vector_Utils_fconnect_vector_Utils(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return vector_Utils__connectI(url, ar, _ex);
}
struct vector_Utils__object* impl_vector_Utils_fcast_vector_Utils(void* bi, 
  sidl_BaseInterface* _ex) {
  return vector_Utils__cast(bi, _ex);
}
