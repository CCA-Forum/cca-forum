#
# File:          Cdouble_Impl.py
# Symbol:        Args.Cdouble-v1.0
# Symbol Type:   class
# Babel Version: 1.0.8
# Description:   Implementation of sidl class Args.Cdouble in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
#


# DO-NOT-DELETE splicer.begin(_initial)
# Put your code here...
# DO-NOT-DELETE splicer.end(_initial)

import Args.Cdouble
import sidl.BaseClass
import sidl.BaseInterface
import sidl.ClassInfo
import sidl.RuntimeException
import sidl.NotImplementedException

# DO-NOT-DELETE splicer.begin(_before_type)
# Put your code here...
# DO-NOT-DELETE splicer.end(_before_type)

class Cdouble:

# All calls to sidl methods should use __IORself

# Normal Babel creation pases in an IORself. If IORself == None
# that means this Impl class is being constructed for native delegation
  def __init__(self, IORself = None):
    if (IORself == None):
      self.__IORself = Args.Cdouble.Cdouble(impl = self)
    else:
      self.__IORself = IORself
    # DO-NOT-DELETE splicer.begin(__init__)
    # Put your code here...
    # DO-NOT-DELETE splicer.end(__init__)

# Returns the IORself (client stub) of the Impl, mainly for use
# with native delegation
  def _getStub(self):
    return self.__IORself

  def returnback(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # double _return
    #

    # DO-NOT-DELETE splicer.begin(returnback)
    return 3.14
    # DO-NOT-DELETE splicer.end(returnback)

  def passin(self, d):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # double d
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # bool _return
    #

    # DO-NOT-DELETE splicer.begin(passin)
    return d == 3.14
    # DO-NOT-DELETE splicer.end(passin)

  def passout(self):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # (_return, d)
    # bool _return
    # double d
    #

    # DO-NOT-DELETE splicer.begin(passout)
    return (1, 3.14)
    # DO-NOT-DELETE splicer.end(passout)

  def passinout(self, d):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # double d
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # (_return, d)
    # bool _return
    # double d
    #

    # DO-NOT-DELETE splicer.begin(passinout)
    return (1, -d)
    # DO-NOT-DELETE splicer.end(passinout)

  def passeverywhere(self, d1, d3):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # double d1
    # double d3
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # (_return, d2, d3)
    # double _return
    # double d2
    # double d3
    #

    # DO-NOT-DELETE splicer.begin(passeverywhere)
    if (d1 == 3.14):
      retval = 3.14
    else:
      retval = 0
    return (retval, 3.14, -d3)
    # DO-NOT-DELETE splicer.end(passeverywhere)

# DO-NOT-DELETE splicer.begin(_final)
# Put your code here...
# DO-NOT-DELETE splicer.end(_final)
