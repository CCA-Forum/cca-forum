#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Args.h"
#include "synch.h"
#include "sidl_Exception.h"

/* #define RMI 0 */

#ifdef RMI
#include "sidl_rmi_ProtocolFactory.h"
#endif

void declare_part( synch_RegOut tracker, int *part_no );
void end_part( synch_RegOut tracker, int part_no, 
               enum synch_ResultType__enum result);

/**
 * Fill the stack with random junk.
 */
int clearstack(int magicNumber) {
  int chunk[2048], i;
  for(i = 0; i < 2048; i++){
    chunk[i] = rand() + magicNumber;
  }
  for(i = 0; i < 16; i++){
    magicNumber += chunk[rand() & 2047];
  }
  return magicNumber;
}

#define MYASSERT( AAA ) \
  declare_part( tracker, &part_no ); \
  magicNumber = clearstack(magicNumber); \
  synch_RegOut_writeComment(tracker, #AAA, &exception); SIDL_CHECK(exception); \
  { \
     int _result = AAA; SIDL_CHECK(exception); \
     if ( _result ) result = synch_ResultType_PASS; \
     else result = synch_ResultType_FAIL;  \
  } \
  end_part( tracker, part_no, result);

#define MYXFAIL( AAA ) \
  declare_part( tracker, &part_no ); \
  magicNumber = clearstack(magicNumber); \
  synch_RegOut_writeComment(tracker, #AAA, &exception); SIDL_CHECK(exception); \
  { \
     int _result = AAA; SIDL_CHECK(exception); \
     if ( _result ) result = synch_ResultType_XPASS; \
     else result = synch_ResultType_XFAIL;  \
  } \
  end_part( tracker, part_no, result);

#define MYBROKEN( AAA ) \
  declare_part( tracker,  &part_no ); \
  synch_RegOut_writeComment(tracker, #AAA, &exception); SIDL_CHECK(exception); \
  end_part( tracker, part_no, synch_ResultType_FAIL);

int main(int argc, char** argv) { 
  sidl_BaseInterface exception = NULL;
  enum synch_ResultType__enum result = synch_ResultType_PASS;
  synch_RegOut tracker = synch_RegOut__create(&exception); 
  SIDL_CHECK(exception);
  int magicNumber = 1;
  int part_no = 0;
  const char *language = "";

#ifdef RMI
  sidl_rmi_ProtocolFactory_addProtocol("simhandle","sidlx.rmi.SimHandle",&exception); SIDL_CHECK(exception);
#endif 

  synch_RegOut_setExpectations(tracker, -1, &exception); SIDL_CHECK(exception);
  if (argc == 2){
    language = argv[1];
  }
  
  { /* bool */
    int out;
    int inout = TRUE;
#ifdef RMI
    Args_Cbool obj = Args_Cbool__createRemote("simhandle://localhost:9999", &exception); SIDL_CHECK(exception);
#else
    Args_Cbool obj = Args_Cbool__create(&exception); SIDL_CHECK(exception);
#endif
    MYASSERT( Args_Cbool_returnback( obj, &exception ) == TRUE );
    MYASSERT( Args_Cbool_passin( obj, TRUE, &exception ) == TRUE );
    MYASSERT( Args_Cbool_passout( obj, &out, &exception ) == TRUE && out == TRUE );
    MYASSERT( Args_Cbool_passinout( obj, &inout, &exception ) == TRUE && inout == FALSE );
    MYASSERT( Args_Cbool_passeverywhere( obj, TRUE, &out, &inout, &exception ) == TRUE &&
	      out == TRUE && inout == TRUE );
    
    Args_Cbool_deleteRef( obj, &exception); SIDL_CHECK(exception);
  } 

  { /* char */
    char out;
    char inout = 'A';
    Args_Cchar obj = Args_Cchar__create(&exception); SIDL_CHECK(exception);
 
    MYASSERT( Args_Cchar_returnback( obj, &exception ) == '3' );
    MYASSERT( Args_Cchar_passin( obj, '3', &exception ) == TRUE );
    MYASSERT( Args_Cchar_passout( obj, &out, &exception ) == TRUE && out == '3' );
    MYASSERT( Args_Cchar_passinout( obj, &inout, &exception ) == TRUE && inout == 'a' );
    MYASSERT( Args_Cchar_passeverywhere( obj, '3', &out, &inout, &exception ) == '3' &&
	     out == '3' && inout == 'A' );

    Args_Cchar_deleteRef( obj , &exception); SIDL_CHECK(exception);
  }


  { /* int */
    int32_t out;
    int32_t inout = 3;
    Args_Cint obj = Args_Cint__create(&exception); SIDL_CHECK(exception);
 
    MYASSERT( Args_Cint_returnback( obj, &exception ) == 3 );
    MYASSERT( Args_Cint_passin( obj, 3, &exception ) == TRUE );
    MYASSERT( Args_Cint_passout( obj, &out, &exception ) == TRUE && out == 3 );
    MYASSERT( Args_Cint_passinout( obj, &inout, &exception ) == TRUE && inout == -3 );
    MYASSERT( Args_Cint_passeverywhere( obj, 3, &out, &inout, &exception ) == 3 &&
	      out == 3 && inout == 3 );
    
    Args_Cint_deleteRef( obj , &exception); SIDL_CHECK(exception);
  }

  { /* long */
    int64_t out;
    int64_t inout = 3;
    Args_Clong obj = Args_Clong__create(&exception); SIDL_CHECK(exception);
 
    MYASSERT( Args_Clong_returnback( obj, &exception ) == 3 );
    MYASSERT( Args_Clong_passin( obj, 3,  &exception ) == TRUE );
    MYASSERT( Args_Clong_passout( obj, &out, &exception ) == TRUE && out == 3 );
    MYASSERT( Args_Clong_passinout( obj, &inout, &exception ) == TRUE && inout == -3 );
    MYASSERT( Args_Clong_passeverywhere( obj, 3, &out, &inout, &exception ) == 3 &&
	      out == 3 && inout == 3 );
    
    Args_Clong_deleteRef( obj , &exception); SIDL_CHECK(exception);
  }

  { /* float */
    float out;
    float inout = 3.1F;
    Args_Cfloat obj = Args_Cfloat__create(&exception); SIDL_CHECK(exception);
 
    MYASSERT( Args_Cfloat_returnback( obj, &exception ) == 3.1F );
    MYASSERT( Args_Cfloat_passin( obj, 3.1F, &exception ) == TRUE );
    MYASSERT( Args_Cfloat_passout( obj, &out, &exception ) == TRUE && out == 3.1F );
    MYASSERT( Args_Cfloat_passinout( obj, &inout, &exception ) == TRUE && inout == -3.1F
              );
    MYASSERT( Args_Cfloat_passeverywhere( obj, 3.1F, &out, &inout, &exception ) ==
              3.1F && out == 3.1F && inout == 3.1F );
    
    Args_Cfloat_deleteRef( obj, &exception ); SIDL_CHECK(exception);
  }


  { /* double */
    double out;
    double inout = 3.14;
    Args_Cdouble obj = Args_Cdouble__create(&exception); SIDL_CHECK(exception);
 
    MYASSERT( Args_Cdouble_returnback( obj, &exception ) == 3.14 );
    MYASSERT( Args_Cdouble_passin( obj, 3.14, &exception ) == TRUE );
    MYASSERT( Args_Cdouble_passout( obj, &out, &exception ) == TRUE && out == 3.14 );
    MYASSERT( Args_Cdouble_passinout( obj, &inout, &exception ) == TRUE && inout == -3.14 );
    MYASSERT( Args_Cdouble_passeverywhere( obj, 3.14, &out, &inout, &exception ) == 3.14 &&
	      out == 3.14 && inout == 3.14 );
    
    Args_Cdouble_deleteRef( obj, &exception ); SIDL_CHECK(exception);
  }


  { /* fcomplex */
    struct sidl_fcomplex retval;
    struct sidl_fcomplex in = { 3.1F, 3.1F };
    struct sidl_fcomplex out;
    struct sidl_fcomplex inout = { 3.1F, 3.1F };
    Args_Cfcomplex obj = Args_Cfcomplex__create(&exception); SIDL_CHECK(exception);
 
    printf("COMMENT: retval = Args_Cfcomplex_returnback( obj );\n");
    retval = Args_Cfcomplex_returnback( obj, &exception );
    MYASSERT( retval.real == 3.1F && retval.imaginary == 3.1F);
    MYASSERT( Args_Cfcomplex_passin( obj, in, &exception ) == TRUE );
    
    MYASSERT( Args_Cfcomplex_passout( obj, &out, &exception ) == TRUE && 
	      out.real == 3.1F && out.imaginary == 3.1F );
    MYASSERT( Args_Cfcomplex_passinout( obj, &inout, &exception ) == TRUE && 
	      inout.real == 3.1F && inout.imaginary == -3.1F );
    printf("COMMENT: retval = Args_Cfcomplex_passeverywhere( obj, in, &out, &inout );\n");
    retval = Args_Cfcomplex_passeverywhere( obj, in, &out, &inout, &exception);
    MYASSERT( retval.real == 3.1F && retval.imaginary == 3.1F &&
              out.real == 3.1F && out.imaginary == 3.1F && 
              inout.real == 3.1F && inout.imaginary == 3.1F );
    
    Args_Cfcomplex_deleteRef( obj, &exception ); SIDL_CHECK(exception);
  }

  
  { /* dcomplex */
    struct sidl_dcomplex retval;
    struct sidl_dcomplex in = { 3.14, 3.14 };
    struct sidl_dcomplex out;
    struct sidl_dcomplex inout = { 3.14, 3.14 };
    Args_Cdcomplex obj = Args_Cdcomplex__create(&exception);

    printf("COMMENT: retval = Args_Cdcomplex_returnback( obj );\n");
    retval = Args_Cdcomplex_returnback( obj, &exception ); 
    MYASSERT( retval.real == 3.14 && retval.imaginary == 3.14);
    MYASSERT( Args_Cdcomplex_passin( obj, in, &exception ) == TRUE );
    MYASSERT( Args_Cdcomplex_passout( obj, &out, &exception ) == TRUE && 
	      out.real == 3.14 && out.imaginary == 3.14 );
    MYASSERT( Args_Cdcomplex_passinout( obj, &inout, &exception ) == TRUE && 
	      inout.real == 3.14 && inout.imaginary == -3.14 );
    printf("COMMENT: retval = Args_Cdcomplex_passeverywhere( obj, in, &out, &inout );\n");
    retval = Args_Cdcomplex_passeverywhere( obj, in, &out, &inout, &exception ); 
    MYASSERT( retval.real == 3.14 && retval.imaginary == 3.14 &&
	      out.real == 3.14 && out.imaginary == 3.14 && 
	      inout.real == 3.14 && inout.imaginary == 3.14 );
    
    Args_Cdcomplex_deleteRef( obj, &exception ); SIDL_CHECK(exception);
  }

  synch_RegOut_close(tracker, &exception); SIDL_CHECK(exception);
  synch_RegOut_deleteRef(tracker, &exception); SIDL_CHECK(exception);
  return 0;
 EXIT:
  {
    sidl_BaseInterface throwaway_exception = NULL;
    if (tracker) {
      sidl_BaseInterface exception2 = NULL;
      synch_RegOut_forceFailure(tracker, &exception2);
      if (exception2) {
        puts("TEST_RESULT FAIL\n");
        sidl_BaseInterface_deleteRef(exception2, &throwaway_exception);
      }
      synch_RegOut_deleteRef(tracker, &throwaway_exception);
    }
    sidl_BaseInterface_deleteRef(exception, &throwaway_exception);
    return -1;
  }
}

void declare_part( synch_RegOut tracker, int * part_no ) {
  sidl_BaseInterface exception = NULL;
  synch_RegOut_startPart(tracker, ++(*part_no), &exception);
  if (exception) {
    sidl_BaseInterface throwaway_exception;
    sidl_BaseInterface exception2 = NULL;
    synch_RegOut_forceFailure(tracker, &exception2);
    if (exception2) {
      puts("TEST_RESULT FAIL\n");
      sidl_BaseInterface_deleteRef(exception2, &throwaway_exception);
    }
    sidl_BaseInterface_deleteRef(exception, &throwaway_exception);
  }
}

void end_part( synch_RegOut tracker, int part_no, 
               enum synch_ResultType__enum result) {
  sidl_BaseInterface exception = NULL;
  synch_RegOut_endPart(tracker, part_no, result, &exception);
  if (exception) {
    sidl_BaseInterface throwaway_exception;
    sidl_BaseInterface exception2 = NULL;
    synch_RegOut_forceFailure(tracker, &exception2);
    if (exception2) {
      puts("TEST_RESULT FAIL\n");
      sidl_BaseInterface_deleteRef(exception2, &throwaway_exception);
    }
    sidl_BaseInterface_deleteRef(exception, &throwaway_exception);
  }
}

