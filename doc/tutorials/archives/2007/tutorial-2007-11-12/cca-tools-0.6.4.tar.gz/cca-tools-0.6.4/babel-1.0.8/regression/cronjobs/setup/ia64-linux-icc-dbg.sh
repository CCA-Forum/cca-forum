#!/bin/sh
#
# This shell script sets up Intel C/C++ with debugging
# for the Thunder

export PATH=/usr/apps/babel/icc/bin:/usr/local/intel/compiler90_new/bin:${PATH}
export LD_LIBRARY_PATH=/usr/apps/babel/icc/lib:/usr/local/intel/compiler90_new/lib:${LD_LIBRARY_PATH}
export CC='icc -c99'
export CFLAGS='-g'
export CXX='icpc'
export CXXFLAGS='-g'
export CPP='gcc -E'
