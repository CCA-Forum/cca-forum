/*
 * File:          hooks_Basics_Impl.h
 * Symbol:        hooks.Basics-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for hooks.Basics
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_hooks_Basics_Impl_h
#define included_hooks_Basics_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_hooks_Basics_h
#include "hooks_Basics.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif

/* DO-NOT-DELETE splicer.begin(hooks.Basics._includes) */
/* DO-NOT-DELETE splicer.end(hooks.Basics._includes) */

/*
 * Private data for class hooks.Basics
 */

struct hooks_Basics__data {
  /* DO-NOT-DELETE splicer.begin(hooks.Basics._data) */
  /* Put private data members here... */
  int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(hooks.Basics._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct hooks_Basics__data*
hooks_Basics__get_data(
  hooks_Basics);

extern void
hooks_Basics__set_data(
  hooks_Basics,
  struct hooks_Basics__data*);

extern
void
impl_hooks_Basics__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_hooks_Basics__ctor(
  /* in */ hooks_Basics self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_hooks_Basics__ctor2(
  /* in */ hooks_Basics self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_hooks_Basics__dtor(
  /* in */ hooks_Basics self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern
void
impl_hooks_Basics_aStaticMeth_pre(
  /* in */ int32_t i,
  /* in */ int32_t io,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_hooks_Basics_aStaticMeth(
  /* in */ int32_t i,
  /* out */ int32_t* o,
  /* inout */ int32_t* io,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_hooks_Basics_aStaticMeth_post(
  /* in */ int32_t i,
  /* in */ int32_t o,
  /* in */ int32_t io,
  /* in */ int32_t _retval,
  /* out */ sidl_BaseInterface *_ex);

extern struct hooks_Basics__object* impl_hooks_Basics_fconnect_hooks_Basics(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct hooks_Basics__object* impl_hooks_Basics_fcast_hooks_Basics(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* impl_hooks_Basics_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_hooks_Basics_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_hooks_Basics_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_hooks_Basics_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_hooks_Basics_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_hooks_Basics_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_hooks_Basics_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_hooks_Basics_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
extern
void
impl_hooks_Basics_aNonStaticMeth_pre(
  /* in */ hooks_Basics self,
  /* in */ int32_t i,
  /* in */ int32_t io,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_hooks_Basics_aNonStaticMeth(
  /* in */ hooks_Basics self,
  /* in */ int32_t i,
  /* out */ int32_t* o,
  /* inout */ int32_t* io,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_hooks_Basics_aNonStaticMeth_post(
  /* in */ hooks_Basics self,
  /* in */ int32_t i,
  /* in */ int32_t o,
  /* in */ int32_t io,
  /* in */ int32_t _retval,
  /* out */ sidl_BaseInterface *_ex);

extern struct hooks_Basics__object* impl_hooks_Basics_fconnect_hooks_Basics(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct hooks_Basics__object* impl_hooks_Basics_fcast_hooks_Basics(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* impl_hooks_Basics_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_hooks_Basics_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_hooks_Basics_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_hooks_Basics_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_hooks_Basics_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_hooks_Basics_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_hooks_Basics_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_hooks_Basics_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
#ifdef __cplusplus
}
#endif
#endif
