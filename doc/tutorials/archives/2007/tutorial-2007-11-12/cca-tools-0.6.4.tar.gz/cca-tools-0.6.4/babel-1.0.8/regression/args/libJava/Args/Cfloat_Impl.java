/*
 * File:          Cfloat_Impl.java
 * Symbol:        Args.Cfloat-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cfloat
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package Args;

import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;

// DO-NOT-DELETE splicer.begin(Args.Cfloat._imports)
// Put additional imports here...
// DO-NOT-DELETE splicer.end(Args.Cfloat._imports)

/**
 * Symbol "Args.Cfloat" (version 1.0)
 */
public class Cfloat_Impl extends Cfloat
{

  // DO-NOT-DELETE splicer.begin(Args.Cfloat._data)
  // Put additional private data here...
  // DO-NOT-DELETE splicer.end(Args.Cfloat._data)

  static { 
  // DO-NOT-DELETE splicer.begin(Args.Cfloat._load)
  // Put load function implementation here...
  // DO-NOT-DELETE splicer.end(Args.Cfloat._load)
  }

  /**
   * User defined constructor
   */
  public Cfloat_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(Args.Cfloat.Cfloat)
    // add construction details here
    // DO-NOT-DELETE splicer.end(Args.Cfloat.Cfloat)
  }

  /**
   * Back door constructor
   */
  public Cfloat_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(Args.Cfloat._wrap)
    // Insert-Code-Here {Args.Cfloat._wrap} (_wrap)
    // DO-NOT-DELETE splicer.end(Args.Cfloat._wrap)
  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Cfloat._dtor)
    // add destruction details here
    // DO-NOT-DELETE splicer.end(Args.Cfloat._dtor)
  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Cfloat.finalize)
    // Insert-Code-Here {Args.Cfloat.finalize} (finalize)
    // DO-NOT-DELETE splicer.end(Args.Cfloat.finalize)
  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  returnback[]
   */
  public float returnback_Impl () 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cfloat.returnback)
    // insert implementation here
    return 3.1f;

    // DO-NOT-DELETE splicer.end(Args.Cfloat.returnback)
  }

  /**
   * Method:  passin[]
   */
  public boolean passin_Impl (
    /*in*/ float f ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cfloat.passin)
    // insert implementation here
      if (f == 3.1f)
	  return true;
      else 
	  return false;

    // DO-NOT-DELETE splicer.end(Args.Cfloat.passin)
  }

  /**
   * Method:  passout[]
   */
  public boolean passout_Impl (
    /*out*/ sidl.Float.Holder f ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cfloat.passout)
    // insert implementation here
      if (f != null) {
	  f.set(3.1f);
	  return true;
      }
      else {
	  return false;
      }

    // DO-NOT-DELETE splicer.end(Args.Cfloat.passout)
  }

  /**
   * Method:  passinout[]
   */
  public boolean passinout_Impl (
    /*inout*/ sidl.Float.Holder f ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cfloat.passinout)
    // insert implementation here
      if (f != null){
	  f.set(-f.get());
	  return true;
      }
      else {
	  return false;
      }

    // DO-NOT-DELETE splicer.end(Args.Cfloat.passinout)
  }

  /**
   * Method:  passeverywhere[]
   */
  public float passeverywhere_Impl (
    /*in*/ float f1,
    /*out*/ sidl.Float.Holder f2,
    /*inout*/ sidl.Float.Holder f3 ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cfloat.passeverywhere)
    // insert implementation here
      f2.set(0);
      if(f3 == null)
	  return 0;
      f3.set(-f3.get());
      f2.set(3.1f);
      if(f1 == 3.1f)
	  return 3.1f;
      else
	  return 0;
    // DO-NOT-DELETE splicer.end(Args.Cfloat.passeverywhere)
  }


  // DO-NOT-DELETE splicer.begin(Args.Cfloat._misc)
  // Put miscellaneous code here
  // DO-NOT-DELETE splicer.end(Args.Cfloat._misc)

} // end class Cfloat

/**
 * ================= BEGIN UNREFERENCED METHOD(S) ================
 * The following code segment(s) belong to unreferenced method(s).
 * This can result from a method rename/removal in the sidl file.
 * Move or remove the code in order to compile cleanly.
 */
// DO-NOT-DELETE splicer.begin(Args.Cfloat._inherits)
// Put additional inheritance here...
// DO-NOT-DELETE splicer.end(Args.Cfloat._inherits)
// ================== END UNREFERENCED METHOD(S) =================
