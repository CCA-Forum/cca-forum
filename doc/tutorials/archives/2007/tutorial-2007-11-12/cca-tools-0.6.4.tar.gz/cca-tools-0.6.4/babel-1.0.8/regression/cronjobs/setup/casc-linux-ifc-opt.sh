#!/bin/sh
#
# This shell script sets up Intel Fortran 90 with optimization
# for the CASC Linux cluster.

. /usr/apps/intel/fc_8.1.021/setup.sh
export FC='ifort -Vaxlib'
if ( uname -r | grep EL 2>&1 > /dev/null ) then
  export CHASMPREFIX=/usr/casc/babel/apps/linux_el/chasm_13rc2_Intel
else
  export CHASMPREFIX=/usr/casc/babel/apps/linux/chasm_101_Intel
fi
export FCFLAGS=-O
