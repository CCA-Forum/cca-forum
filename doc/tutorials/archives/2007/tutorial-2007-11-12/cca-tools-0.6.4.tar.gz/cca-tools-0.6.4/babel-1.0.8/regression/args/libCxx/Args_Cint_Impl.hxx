// 
// File:          Args_Cint_Impl.hxx
// Symbol:        Args.Cint-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Cint
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_Args_Cint_Impl_hxx
#define included_Args_Cint_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_Args_Cint_IOR_h
#include "Args_Cint_IOR.h"
#endif
#ifndef included_Args_Cint_hxx
#include "Args_Cint.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(Args.Cint._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Cint._includes)

namespace Args { 

  /**
   * Symbol "Args.Cint" (version 1.0)
   */
  class Cint_impl : public virtual ::Args::Cint 
  // DO-NOT-DELETE splicer.begin(Args.Cint._inherits)
  // Put additional inheritance here...
  // DO-NOT-DELETE splicer.end(Args.Cint._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(Args.Cint._implementation)
    // Put additional implementation details here...
    // DO-NOT-DELETE splicer.end(Args.Cint._implementation)

  public:
    // default constructor, used for data wrapping(required)
    Cint_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    Cint_impl( struct Args_Cint__object * s ) : StubBase(s,true), _wrapped(
      false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~Cint_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    int32_t
    returnback_impl() ;
    /**
     * user defined non-static method.
     */
    bool
    passin_impl (
      /* in */int32_t i
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passout_impl (
      /* out */int32_t& i
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passinout_impl (
      /* inout */int32_t& i
    )
    ;

    /**
     * user defined non-static method.
     */
    int32_t
    passeverywhere_impl (
      /* in */int32_t i1,
      /* out */int32_t& i2,
      /* inout */int32_t& i3
    )
    ;

  };  // end class Cint_impl

} // end namespace Args

// DO-NOT-DELETE splicer.begin(Args.Cint._misc)
// Put miscellaneous things here...
// DO-NOT-DELETE splicer.end(Args.Cint._misc)

#endif
