// 
// File:          Args_Cchar_Impl.cxx
// Symbol:        Args.Cchar-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Cchar
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "Args_Cchar_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(Args.Cchar._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Cchar._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
Args::Cchar_impl::Cchar_impl() : StubBase(reinterpret_cast< void*>(
  ::Args::Cchar::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(Args.Cchar._ctor2)
  // Insert-Code-Here {Args.Cchar._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(Args.Cchar._ctor2)
}

// user defined constructor
void Args::Cchar_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(Args.Cchar._ctor)
  // add construction details here
  // DO-NOT-DELETE splicer.end(Args.Cchar._ctor)
}

// user defined destructor
void Args::Cchar_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(Args.Cchar._dtor)
  // add destruction details here
  // DO-NOT-DELETE splicer.end(Args.Cchar._dtor)
}

// static class initializer
void Args::Cchar_impl::_load() {
  // DO-NOT-DELETE splicer.begin(Args.Cchar._load)
  // guaranteed to be called at most once before any other method in this class
  // DO-NOT-DELETE splicer.end(Args.Cchar._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  returnback[]
 */
char
Args::Cchar_impl::returnback_impl () 

{
  // DO-NOT-DELETE splicer.begin(Args.Cchar.returnback)
  return '3';
  // DO-NOT-DELETE splicer.end(Args.Cchar.returnback)
}

/**
 * Method:  passin[]
 */
bool
Args::Cchar_impl::passin_impl (
  /* in */char c ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cchar.passin)
    return ( c == '3');
  // DO-NOT-DELETE splicer.end(Args.Cchar.passin)
}

/**
 * Method:  passout[]
 */
bool
Args::Cchar_impl::passout_impl (
  /* out */char& c ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cchar.passout)
  c = '3';
  return true;
  // DO-NOT-DELETE splicer.end(Args.Cchar.passout)
}

/**
 * Method:  passinout[]
 */
bool
Args::Cchar_impl::passinout_impl (
  /* inout */char& c ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cchar.passinout)
  if ( c >= 'a' && c <= 'z' ) { 
    c += 'A' - 'a';
  } else if ( c >= 'A' && c <= 'Z' ) { 
    c += 'a' - 'A';
  }
  return true;  
  // DO-NOT-DELETE splicer.end(Args.Cchar.passinout)
}

/**
 * Method:  passeverywhere[]
 */
char
Args::Cchar_impl::passeverywhere_impl (
  /* in */char c1,
  /* out */char& c2,
  /* inout */char& c3 ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cchar.passeverywhere)
  c2 = '3';
  if ( c3 >= 'a' && c3 <= 'z' ) { 
    c3 += 'A' - 'a';
  } else if ( c3 >= 'A' && c3 <= 'Z' ) { 
    c3 += 'a' - 'A';
  }
  return ( c1 == '3') ? '3' : '\0' ;
  // DO-NOT-DELETE splicer.end(Args.Cchar.passeverywhere)
}


// DO-NOT-DELETE splicer.begin(Args.Cchar._misc)
// Put miscellaneous code here
// DO-NOT-DELETE splicer.end(Args.Cchar._misc)

