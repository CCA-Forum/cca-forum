#!/bin/sh
#
# This shell script sets up Absoft Fortran 90 with optimization
# for the CASC Linux cluster.

. /usr/apps/Absoft/pro8.0/setup.sh
export FC=f90
export CHASMPREFIX=/usr/casc/babel/apps/linux/chasm_101_Absoft
export FCFLAGS=-O
