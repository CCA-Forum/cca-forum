#!/bin/sh
#
# This shell script sets up Intel Fortran 90 with debugging
# for Thunder
export FC='ifort -Vaxlib'
export FCFLAGS=-g
export CHASMPREFIX=/usr/gapps/babel/thunder/icc

