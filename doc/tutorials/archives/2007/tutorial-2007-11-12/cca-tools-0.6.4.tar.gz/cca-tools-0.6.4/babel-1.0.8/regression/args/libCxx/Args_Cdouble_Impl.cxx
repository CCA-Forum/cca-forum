// 
// File:          Args_Cdouble_Impl.cxx
// Symbol:        Args.Cdouble-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Cdouble
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "Args_Cdouble_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(Args.Cdouble._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Cdouble._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
Args::Cdouble_impl::Cdouble_impl() : StubBase(reinterpret_cast< void*>(
  ::Args::Cdouble::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(Args.Cdouble._ctor2)
  // Insert-Code-Here {Args.Cdouble._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(Args.Cdouble._ctor2)
}

// user defined constructor
void Args::Cdouble_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(Args.Cdouble._ctor)
  // add construction details here
  // DO-NOT-DELETE splicer.end(Args.Cdouble._ctor)
}

// user defined destructor
void Args::Cdouble_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(Args.Cdouble._dtor)
  // add destruction details here
  // DO-NOT-DELETE splicer.end(Args.Cdouble._dtor)
}

// static class initializer
void Args::Cdouble_impl::_load() {
  // DO-NOT-DELETE splicer.begin(Args.Cdouble._load)
  // guaranteed to be called at most once before any other method in this class
  // DO-NOT-DELETE splicer.end(Args.Cdouble._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  returnback[]
 */
double
Args::Cdouble_impl::returnback_impl () 

{
  // DO-NOT-DELETE splicer.begin(Args.Cdouble.returnback)
  return 3.14;
  // DO-NOT-DELETE splicer.end(Args.Cdouble.returnback)
}

/**
 * Method:  passin[]
 */
bool
Args::Cdouble_impl::passin_impl (
  /* in */double d ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cdouble.passin)
  return ( d == 3.14 );
  // DO-NOT-DELETE splicer.end(Args.Cdouble.passin)
}

/**
 * Method:  passout[]
 */
bool
Args::Cdouble_impl::passout_impl (
  /* out */double& d ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cdouble.passout)
  d = 3.14;
  return true;
  // DO-NOT-DELETE splicer.end(Args.Cdouble.passout)
}

/**
 * Method:  passinout[]
 */
bool
Args::Cdouble_impl::passinout_impl (
  /* inout */double& d ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cdouble.passinout)
  d = -d;
  return true;
  // DO-NOT-DELETE splicer.end(Args.Cdouble.passinout)
}

/**
 * Method:  passeverywhere[]
 */
double
Args::Cdouble_impl::passeverywhere_impl (
  /* in */double d1,
  /* out */double& d2,
  /* inout */double& d3 ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cdouble.passeverywhere)
  d2 = 3.14;
  d3 = -d3;
  return ( d1 == 3.14 ) ? 3.14 : 0.0 ;
  // DO-NOT-DELETE splicer.end(Args.Cdouble.passeverywhere)
}


// DO-NOT-DELETE splicer.begin(Args.Cdouble._misc)
// Put miscellaneous code here
// DO-NOT-DELETE splicer.end(Args.Cdouble._misc)

