/*
 * File:          vector_NegativeValueException_Impl.c
 * Symbol:        vector.NegativeValueException-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for vector.NegativeValueException
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "vector.NegativeValueException" (version 1.0)
 */

#include "vector_NegativeValueException_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"

/* DO-NOT-DELETE splicer.begin(vector.NegativeValueException._includes) */
/* Nothing to add. */
/* DO-NOT-DELETE splicer.end(vector.NegativeValueException._includes) */

#define SIDL_IOR_MAJOR_VERSION 1
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_NegativeValueException__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_vector_NegativeValueException__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.NegativeValueException._load) */
  /* Insert-Code-Here {vector.NegativeValueException._load} (static class initializer method) */
  /* DO-NOT-DELETE splicer.end(vector.NegativeValueException._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_NegativeValueException__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_vector_NegativeValueException__ctor(
  /* in */ vector_NegativeValueException self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.NegativeValueException._ctor) */
  /* Nothing to add. */
  /* DO-NOT-DELETE splicer.end(vector.NegativeValueException._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_NegativeValueException__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_vector_NegativeValueException__ctor2(
  /* in */ vector_NegativeValueException self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.NegativeValueException._ctor2) */
  /* Insert-Code-Here {vector.NegativeValueException._ctor2} (special constructor method) */
  /* DO-NOT-DELETE splicer.end(vector.NegativeValueException._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_vector_NegativeValueException__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_vector_NegativeValueException__dtor(
  /* in */ vector_NegativeValueException self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(vector.NegativeValueException._dtor) */
  /* Nothing to add. */
  /* DO-NOT-DELETE splicer.end(vector.NegativeValueException._dtor) */
  }
}
/* Babel internal methods, Users should not edit below this line. */
struct sidl_BaseClass__object* 
  impl_vector_NegativeValueException_fconnect_sidl_BaseClass(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connectI(url, ar, _ex);
}
struct sidl_BaseClass__object* 
  impl_vector_NegativeValueException_fcast_sidl_BaseClass(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_BaseClass__cast(bi, _ex);
}
struct sidl_BaseException__object* 
  impl_vector_NegativeValueException_fconnect_sidl_BaseException(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseException__connectI(url, ar, _ex);
}
struct sidl_BaseException__object* 
  impl_vector_NegativeValueException_fcast_sidl_BaseException(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_BaseException__cast(bi, _ex);
}
struct sidl_BaseInterface__object* 
  impl_vector_NegativeValueException_fconnect_sidl_BaseInterface(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connectI(url, ar, _ex);
}
struct sidl_BaseInterface__object* 
  impl_vector_NegativeValueException_fcast_sidl_BaseInterface(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_BaseInterface__cast(bi, _ex);
}
struct sidl_ClassInfo__object* 
  impl_vector_NegativeValueException_fconnect_sidl_ClassInfo(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connectI(url, ar, _ex);
}
struct sidl_ClassInfo__object* 
  impl_vector_NegativeValueException_fcast_sidl_ClassInfo(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_ClassInfo__cast(bi, _ex);
}
struct sidl_RuntimeException__object* 
  impl_vector_NegativeValueException_fconnect_sidl_RuntimeException(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_RuntimeException__connectI(url, ar, _ex);
}
struct sidl_RuntimeException__object* 
  impl_vector_NegativeValueException_fcast_sidl_RuntimeException(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_RuntimeException__cast(bi, _ex);
}
struct sidl_SIDLException__object* 
  impl_vector_NegativeValueException_fconnect_sidl_SIDLException(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_SIDLException__connectI(url, ar, _ex);
}
struct sidl_SIDLException__object* 
  impl_vector_NegativeValueException_fcast_sidl_SIDLException(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_SIDLException__cast(bi, _ex);
}
struct sidl_io_Deserializer__object* 
  impl_vector_NegativeValueException_fconnect_sidl_io_Deserializer(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_io_Deserializer__connectI(url, ar, _ex);
}
struct sidl_io_Deserializer__object* 
  impl_vector_NegativeValueException_fcast_sidl_io_Deserializer(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_io_Deserializer__cast(bi, _ex);
}
struct sidl_io_Serializable__object* 
  impl_vector_NegativeValueException_fconnect_sidl_io_Serializable(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_io_Serializable__connectI(url, ar, _ex);
}
struct sidl_io_Serializable__object* 
  impl_vector_NegativeValueException_fcast_sidl_io_Serializable(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_io_Serializable__cast(bi, _ex);
}
struct sidl_io_Serializer__object* 
  impl_vector_NegativeValueException_fconnect_sidl_io_Serializer(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_io_Serializer__connectI(url, ar, _ex);
}
struct sidl_io_Serializer__object* 
  impl_vector_NegativeValueException_fcast_sidl_io_Serializer(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_io_Serializer__cast(bi, _ex);
}
struct vector_Exception__object* 
  impl_vector_NegativeValueException_fconnect_vector_Exception(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return vector_Exception__connectI(url, ar, _ex);
}
struct vector_Exception__object* 
  impl_vector_NegativeValueException_fcast_vector_Exception(void* bi, 
  sidl_BaseInterface* _ex) {
  return vector_Exception__cast(bi, _ex);
}
struct vector_NegativeValueException__object* 
  impl_vector_NegativeValueException_fconnect_vector_NegativeValueException(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return vector_NegativeValueException__connectI(url, ar, _ex);
}
struct vector_NegativeValueException__object* 
  impl_vector_NegativeValueException_fcast_vector_NegativeValueException(void* 
  bi, sidl_BaseInterface* _ex) {
  return vector_NegativeValueException__cast(bi, _ex);
}
