/*
 * VectorUtils_ExceptionHelpers.h
 *
 * The following macros were cloned (and tweaked) from sidl_Exception.h to
 * facilitate handling of VectorUtils exceptions.
 */
#ifndef included_VectorUtils_ExceptionHelpers_h
#define included_VectorUtils_ExceptionHelpers_h

#ifndef included_sidl_SIDLException_h
#include "sidl_SIDLException.h"
#endif
#ifndef included_sidlAsserts_h
#include "sidlAsserts.h"
#endif

#ifndef NULL
#define NULL 0
#endif

#define VU_CREATE_EXCEPT(EX_VAR,EX_CLS,MSG) {\
  sidl_BaseInterface _throwaway_exception = NULL; \
  (EX_VAR) = EX_CLS##__create(&_throwaway_exception); \
  if ((EX_VAR) != NULL) EX_CLS##_setNote((EX_VAR), MSG, &_throwaway_exception); \
}

#define VU_THROW(EX_VAR,EX_CLS,MSG) { \
  VU_CREATE_EXCEPT(EX_VAR,EX_CLS,MSG)\
  goto EXIT; \
}

#define VU_CHECK(EX_VAR)   { if ((EX_VAR) != NULL) goto EXIT; }

#define VU_CLEAR(EX_VAR) { \
  if ((EX_VAR) != NULL) { \
    sidl_BaseInterface _throwaway_exception = NULL; \
    sidl_BaseInterface_deleteRef((sidl_BaseInterface)(EX_VAR, &_throwaway_exception)); \
    (EX_VAR) = NULL; \
  }  \
}

#endif
