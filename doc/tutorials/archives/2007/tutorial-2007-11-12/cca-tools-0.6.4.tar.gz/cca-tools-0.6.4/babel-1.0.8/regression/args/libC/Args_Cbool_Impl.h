/*
 * File:          Args_Cbool_Impl.h
 * Symbol:        Args.Cbool-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cbool
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_Args_Cbool_Impl_h
#define included_Args_Cbool_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_Args_Cbool_h
#include "Args_Cbool.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif

/* DO-NOT-DELETE splicer.begin(Args.Cbool._includes) */
/* Put additional include files here... */
/* DO-NOT-DELETE splicer.end(Args.Cbool._includes) */

/*
 * Private data for class Args.Cbool
 */

struct Args_Cbool__data {
  /* DO-NOT-DELETE splicer.begin(Args.Cbool._data) */
  /* Put private data members here... */
  int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(Args.Cbool._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct Args_Cbool__data*
Args_Cbool__get_data(
  Args_Cbool);

extern void
Args_Cbool__set_data(
  Args_Cbool,
  struct Args_Cbool__data*);

extern
void
impl_Args_Cbool__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cbool__ctor(
  /* in */ Args_Cbool self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cbool__ctor2(
  /* in */ Args_Cbool self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cbool__dtor(
  /* in */ Args_Cbool self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct Args_Cbool__object* impl_Args_Cbool_fconnect_Args_Cbool(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct Args_Cbool__object* impl_Args_Cbool_fcast_Args_Cbool(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* impl_Args_Cbool_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_Args_Cbool_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cbool_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cbool_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_Args_Cbool_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_Args_Cbool_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cbool_fconnect_sidl_RuntimeException(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cbool_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
extern
sidl_bool
impl_Args_Cbool_returnback(
  /* in */ Args_Cbool self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cbool_passin(
  /* in */ Args_Cbool self,
  /* in */ sidl_bool b,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cbool_passout(
  /* in */ Args_Cbool self,
  /* out */ sidl_bool* b,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cbool_passinout(
  /* in */ Args_Cbool self,
  /* inout */ sidl_bool* b,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cbool_passeverywhere(
  /* in */ Args_Cbool self,
  /* in */ sidl_bool b1,
  /* out */ sidl_bool* b2,
  /* inout */ sidl_bool* b3,
  /* out */ sidl_BaseInterface *_ex);

extern struct Args_Cbool__object* impl_Args_Cbool_fconnect_Args_Cbool(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct Args_Cbool__object* impl_Args_Cbool_fcast_Args_Cbool(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* impl_Args_Cbool_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_Args_Cbool_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cbool_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cbool_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_Args_Cbool_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_Args_Cbool_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cbool_fconnect_sidl_RuntimeException(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cbool_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
#ifdef __cplusplus
}
#endif
#endif
