#!/bin/sh
#
# This shell script sets up Lahey Fortran 90 with debugging
# for the CASC Linux cluster.

. /usr/apps/Lahey/lf9562/setup.sh
export FC=lf95
export CHASMPREFIX=/usr/casc/babel/apps/linux/chasm_101_Lahey
export FCFLAGS=-g
