/*
 * File:          Cdouble_Impl.java
 * Symbol:        Args.Cdouble-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cdouble
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package Args;

import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;

// DO-NOT-DELETE splicer.begin(Args.Cdouble._imports)
// Put additional imports here...
// DO-NOT-DELETE splicer.end(Args.Cdouble._imports)

/**
 * Symbol "Args.Cdouble" (version 1.0)
 */
public class Cdouble_Impl extends Cdouble
{

  // DO-NOT-DELETE splicer.begin(Args.Cdouble._data)
  // Put additional private data here...
  // DO-NOT-DELETE splicer.end(Args.Cdouble._data)

  static { 
  // DO-NOT-DELETE splicer.begin(Args.Cdouble._load)
  // Put load function implementation here...
  // DO-NOT-DELETE splicer.end(Args.Cdouble._load)
  }

  /**
   * User defined constructor
   */
  public Cdouble_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(Args.Cdouble.Cdouble)
    // add construction details here
    // DO-NOT-DELETE splicer.end(Args.Cdouble.Cdouble)
  }

  /**
   * Back door constructor
   */
  public Cdouble_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(Args.Cdouble._wrap)
    // Insert-Code-Here {Args.Cdouble._wrap} (_wrap)
    // DO-NOT-DELETE splicer.end(Args.Cdouble._wrap)
  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Cdouble._dtor)
    // add destruction details here
    // DO-NOT-DELETE splicer.end(Args.Cdouble._dtor)
  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Cdouble.finalize)
    // Insert-Code-Here {Args.Cdouble.finalize} (finalize)
    // DO-NOT-DELETE splicer.end(Args.Cdouble.finalize)
  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  returnback[]
   */
  public double returnback_Impl () 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cdouble.returnback)
    // insert implementation here
    return 3.14;
    // DO-NOT-DELETE splicer.end(Args.Cdouble.returnback)
  }

  /**
   * Method:  passin[]
   */
  public boolean passin_Impl (
    /*in*/ double d ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cdouble.passin)
    // insert implementation here
      if (d == 3.14)
	  return true;
      else 
	  return false;
    // DO-NOT-DELETE splicer.end(Args.Cdouble.passin)
  }

  /**
   * Method:  passout[]
   */
  public boolean passout_Impl (
    /*out*/ sidl.Double.Holder d ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cdouble.passout)
    // insert implementation here
       if (d != null) {
	  d.set(3.14);
	  return true;
      }
      else {
	  return false;
      }
    // DO-NOT-DELETE splicer.end(Args.Cdouble.passout)
  }

  /**
   * Method:  passinout[]
   */
  public boolean passinout_Impl (
    /*inout*/ sidl.Double.Holder d ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cdouble.passinout)
    // insert implementation here
      if (d != null){
	  d.set(-d.get());
	  return true;
      }
      else {
	  return false;
      }
    // DO-NOT-DELETE splicer.end(Args.Cdouble.passinout)
  }

  /**
   * Method:  passeverywhere[]
   */
  public double passeverywhere_Impl (
    /*in*/ double d1,
    /*out*/ sidl.Double.Holder d2,
    /*inout*/ sidl.Double.Holder d3 ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cdouble.passeverywhere)
    // insert implementation here
      d2.set(0);
      if(d3 == null)
	  return 0;
      d3.set(-d3.get());
      d2.set(3.14);
      if(d1 == 3.14)
	  return 3.14;
      else
	  return 0;
    // DO-NOT-DELETE splicer.end(Args.Cdouble.passeverywhere)
  }


  // DO-NOT-DELETE splicer.begin(Args.Cdouble._misc)
  // Put miscellaneous code here
  // DO-NOT-DELETE splicer.end(Args.Cdouble._misc)

} // end class Cdouble

/**
 * ================= BEGIN UNREFERENCED METHOD(S) ================
 * The following code segment(s) belong to unreferenced method(s).
 * This can result from a method rename/removal in the sidl file.
 * Move or remove the code in order to compile cleanly.
 */
// DO-NOT-DELETE splicer.begin(Args.Cdouble._inherits)
// Put additional inheritance here...
// DO-NOT-DELETE splicer.end(Args.Cdouble._inherits)
// ================== END UNREFERENCED METHOD(S) =================
