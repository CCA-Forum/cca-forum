#
# File:          Cfloat_Impl.py
# Symbol:        Args.Cfloat-v1.0
# Symbol Type:   class
# Babel Version: 1.0.8
# Description:   Implementation of sidl class Args.Cfloat in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
#


# DO-NOT-DELETE splicer.begin(_initial)
# Put your code here...
# DO-NOT-DELETE splicer.end(_initial)

import Args.Cfloat
import sidl.BaseClass
import sidl.BaseInterface
import sidl.ClassInfo
import sidl.RuntimeException
import sidl.NotImplementedException

# DO-NOT-DELETE splicer.begin(_before_type)
import Numeric
def toFloat(d):
  tmp = Numeric.zeros((1,), Numeric.Float32)
  try:
    tmp[0] = d
  except AttributeError:
    # don't die!
    tmp[0] = d
  result = tmp[0]
  if type(result) == Numeric.arraytype:
    result = result.toscalar()
  return result
# DO-NOT-DELETE splicer.end(_before_type)

class Cfloat:

# All calls to sidl methods should use __IORself

# Normal Babel creation pases in an IORself. If IORself == None
# that means this Impl class is being constructed for native delegation
  def __init__(self, IORself = None):
    if (IORself == None):
      self.__IORself = Args.Cfloat.Cfloat(impl = self)
    else:
      self.__IORself = IORself
    # DO-NOT-DELETE splicer.begin(__init__)
    # Put your code here...
    # DO-NOT-DELETE splicer.end(__init__)

# Returns the IORself (client stub) of the Impl, mainly for use
# with native delegation
  def _getStub(self):
    return self.__IORself

  def returnback(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # float _return
    #

    # DO-NOT-DELETE splicer.begin(returnback)
    return 3.1
    # DO-NOT-DELETE splicer.end(returnback)

  def passin(self, f):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # float f
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # bool _return
    #

    # DO-NOT-DELETE splicer.begin(passin)
    return f == toFloat(3.1)
    # DO-NOT-DELETE splicer.end(passin)

  def passout(self):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # (_return, f)
    # bool _return
    # float f
    #

    # DO-NOT-DELETE splicer.begin(passout)
    return (1, 3.1)
    # DO-NOT-DELETE splicer.end(passout)

  def passinout(self, f):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # float f
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # (_return, f)
    # bool _return
    # float f
    #

    # DO-NOT-DELETE splicer.begin(passinout)
    return (1, -f)
    # DO-NOT-DELETE splicer.end(passinout)

  def passeverywhere(self, f1, f3):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # float f1
    # float f3
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # (_return, f2, f3)
    # float _return
    # float f2
    # float f3
    #

    # DO-NOT-DELETE splicer.begin(passeverywhere)
    if (f1 == toFloat(3.1)):
      retval = toFloat(3.1)
    else:
      retval = 0
    return (retval, 3.1, -f3)
    # DO-NOT-DELETE splicer.end(passeverywhere)

# DO-NOT-DELETE splicer.begin(_final)
# Put your code here...
# DO-NOT-DELETE splicer.end(_final)
