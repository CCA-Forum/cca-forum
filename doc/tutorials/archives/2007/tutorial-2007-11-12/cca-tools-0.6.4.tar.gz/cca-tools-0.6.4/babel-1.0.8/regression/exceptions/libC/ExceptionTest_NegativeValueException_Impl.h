/*
 * File:          ExceptionTest_NegativeValueException_Impl.h
 * Symbol:        ExceptionTest.NegativeValueException-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for ExceptionTest.NegativeValueException
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_ExceptionTest_NegativeValueException_Impl_h
#define included_ExceptionTest_NegativeValueException_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_ExceptionTest_NegativeValueException_h
#include "ExceptionTest_NegativeValueException.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseException_h
#include "sidl_BaseException.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
#ifndef included_sidl_SIDLException_h
#include "sidl_SIDLException.h"
#endif
#ifndef included_sidl_io_Deserializer_h
#include "sidl_io_Deserializer.h"
#endif
#ifndef included_sidl_io_Serializable_h
#include "sidl_io_Serializable.h"
#endif
#ifndef included_sidl_io_Serializer_h
#include "sidl_io_Serializer.h"
#endif

/* DO-NOT-DELETE splicer.begin(ExceptionTest.NegativeValueException._includes) 
  */
/* Put additional include files here... */
/* DO-NOT-DELETE splicer.end(ExceptionTest.NegativeValueException._includes) */

/*
 * Private data for class ExceptionTest.NegativeValueException
 */

struct ExceptionTest_NegativeValueException__data {
  /* DO-NOT-DELETE splicer.begin(ExceptionTest.NegativeValueException._data) */
  /* Put private data members here... */
  int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(ExceptionTest.NegativeValueException._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct ExceptionTest_NegativeValueException__data*
ExceptionTest_NegativeValueException__get_data(
  ExceptionTest_NegativeValueException);

extern void
ExceptionTest_NegativeValueException__set_data(
  ExceptionTest_NegativeValueException,
  struct ExceptionTest_NegativeValueException__data*);

extern
void
impl_ExceptionTest_NegativeValueException__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ExceptionTest_NegativeValueException__ctor(
  /* in */ ExceptionTest_NegativeValueException self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ExceptionTest_NegativeValueException__ctor2(
  /* in */ ExceptionTest_NegativeValueException self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ExceptionTest_NegativeValueException__dtor(
  /* in */ ExceptionTest_NegativeValueException self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct ExceptionTest_NegativeValueException__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_ExceptionTest_NegativeValueException
  (const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ExceptionTest_NegativeValueException__object* 
  impl_ExceptionTest_NegativeValueException_fcast_ExceptionTest_NegativeValueException
  (void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_BaseClass(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_BaseClass(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseException__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_BaseException(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseException__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_BaseException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_BaseInterface(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_BaseInterface(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_ClassInfo(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_ClassInfo(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_RuntimeException(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_RuntimeException(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_SIDLException__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_SIDLException(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_SIDLException__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_SIDLException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_io_Deserializer__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_io_Deserializer(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_io_Deserializer__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_io_Deserializer(void* bi,
  sidl_BaseInterface* _ex);
extern struct sidl_io_Serializable__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_io_Serializable(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_io_Serializable__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_io_Serializable(void* bi,
  sidl_BaseInterface* _ex);
extern struct sidl_io_Serializer__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_io_Serializer(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_io_Serializer__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_io_Serializer(void* bi, 
  sidl_BaseInterface* _ex);
extern struct ExceptionTest_NegativeValueException__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_ExceptionTest_NegativeValueException
  (const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ExceptionTest_NegativeValueException__object* 
  impl_ExceptionTest_NegativeValueException_fcast_ExceptionTest_NegativeValueException
  (void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_BaseClass(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_BaseClass(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseException__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_BaseException(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseException__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_BaseException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_BaseInterface(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_BaseInterface(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_ClassInfo(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_ClassInfo(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_RuntimeException(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_RuntimeException(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_SIDLException__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_SIDLException(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_SIDLException__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_SIDLException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_io_Deserializer__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_io_Deserializer(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_io_Deserializer__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_io_Deserializer(void* bi,
  sidl_BaseInterface* _ex);
extern struct sidl_io_Serializable__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_io_Serializable(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_io_Serializable__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_io_Serializable(void* bi,
  sidl_BaseInterface* _ex);
extern struct sidl_io_Serializer__object* 
  impl_ExceptionTest_NegativeValueException_fconnect_sidl_io_Serializer(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_io_Serializer__object* 
  impl_ExceptionTest_NegativeValueException_fcast_sidl_io_Serializer(void* bi, 
  sidl_BaseInterface* _ex);
#ifdef __cplusplus
}
#endif
#endif
