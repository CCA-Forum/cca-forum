#!/bin/sh
#
# Settings that should be at the end of the setup
