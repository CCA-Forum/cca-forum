#
# File:          MergeSort_Impl.py
# Symbol:        sort.MergeSort-v0.1
# Symbol Type:   class
# Babel Version: 1.0.8
# Description:   Implementation of sidl class sort.MergeSort in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
#


"""Merge sort
"""

# DO-NOT-DELETE splicer.begin(_initial)
# Put your code here...
# DO-NOT-DELETE splicer.end(_initial)

import sidl.BaseClass
import sidl.BaseInterface
import sidl.ClassInfo
import sidl.RuntimeException
import sort.Comparator
import sort.Container
import sort.Counter
import sort.MergeSort
import sort.SortingAlgorithm
import sidl.NotImplementedException

# DO-NOT-DELETE splicer.begin(_before_type)
def mergeLists(elems, comp, cmp, swp, start, mid, end):
  while ((start < mid) and (mid < end)):
    cmp.inc()
    if (elems.compare(start, mid, comp) > 0):
      for j in xrange(mid, start, -1):
        swp.inc()
        elems.swap(j, j - 1)
      mid = mid + 1
    start = start + 1

def mergeSort(elems, comp, cmp, swp, start, end):
  if ((end - start) > 1):
    mid = (start + end) >> 1
    mergeSort(elems, comp, cmp, swp, start, mid)
    mergeSort(elems, comp, cmp, swp, mid, end)
    mergeLists(elems, comp, cmp, swp, start, mid, end)
    
# DO-NOT-DELETE splicer.end(_before_type)

class MergeSort:
  """\
Merge sort
"""

# All calls to sidl methods should use __IORself

# Normal Babel creation pases in an IORself. If IORself == None
# that means this Impl class is being constructed for native delegation
  def __init__(self, IORself = None):
    if (IORself == None):
      self.__IORself = sort.MergeSort.MergeSort(impl = self)
    else:
      self.__IORself = IORself
    # DO-NOT-DELETE splicer.begin(__init__)
    # Put your code here...
    # DO-NOT-DELETE splicer.end(__init__)

# Returns the IORself (client stub) of the Impl, mainly for use
# with native delegation
  def _getStub(self):
    return self.__IORself

  def sort(self, elems, comp):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # sort.Container elems
    # sort.Comparator comp
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
# None
    #

    """\
Sort elements using Merge Sort.
"""
    # DO-NOT-DELETE splicer.begin(sort)
    size = elems.getLength()
    cmp = self.__IORself.getCompareCounter()
    swp = self.__IORself.getSwapCounter()
    mergeSort(elems, comp, cmp, swp, 0, size)
    # DO-NOT-DELETE splicer.end(sort)

  def getName(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # string _return
    #

    """\
Return merge sort.
"""
    # DO-NOT-DELETE splicer.begin(getName)
    return "Merge sort"
    # DO-NOT-DELETE splicer.end(getName)

# DO-NOT-DELETE splicer.begin(_final)
# Put your code here...
# DO-NOT-DELETE splicer.end(_final)
