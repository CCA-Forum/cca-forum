/*
 * File:          Args_Cdcomplex_Impl.c
 * Symbol:        Args.Cdcomplex-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cdcomplex
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "Args.Cdcomplex" (version 1.0)
 */

#include "Args_Cdcomplex_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"

/* DO-NOT-DELETE splicer.begin(Args.Cdcomplex._includes) */
/* Put additional includes or other arbitrary code here... */
/* DO-NOT-DELETE splicer.end(Args.Cdcomplex._includes) */

#define SIDL_IOR_MAJOR_VERSION 1
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdcomplex__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cdcomplex__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdcomplex._load) */
  /* Insert the implementation of the static class initializer method here... */
  /* DO-NOT-DELETE splicer.end(Args.Cdcomplex._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdcomplex__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cdcomplex__ctor(
  /* in */ Args_Cdcomplex self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdcomplex._ctor) */
  /* Insert the implementation of the constructor method here... */
  /* DO-NOT-DELETE splicer.end(Args.Cdcomplex._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdcomplex__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cdcomplex__ctor2(
  /* in */ Args_Cdcomplex self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdcomplex._ctor2) */
  /* Insert-Code-Here {Args.Cdcomplex._ctor2} (special constructor method) */
  /* DO-NOT-DELETE splicer.end(Args.Cdcomplex._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdcomplex__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cdcomplex__dtor(
  /* in */ Args_Cdcomplex self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdcomplex._dtor) */
  /* Insert the implementation of the constructor method here... */
  /* DO-NOT-DELETE splicer.end(Args.Cdcomplex._dtor) */
  }
}

/*
 * Method:  returnback[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdcomplex_returnback"

#ifdef __cplusplus
extern "C"
#endif
struct sidl_dcomplex
impl_Args_Cdcomplex_returnback(
  /* in */ Args_Cdcomplex self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdcomplex.returnback) */
  struct sidl_dcomplex c = {3.14, 3.14};
  return c;
  /* DO-NOT-DELETE splicer.end(Args.Cdcomplex.returnback) */
  }
}

/*
 * Method:  passin[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdcomplex_passin"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cdcomplex_passin(
  /* in */ Args_Cdcomplex self,
  /* in */ struct sidl_dcomplex c,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdcomplex.passin) */
  if (3.14 == c.real && 3.14 == c.imaginary) {
    return TRUE;
  }
  else {
    return FALSE;
  }
  /* DO-NOT-DELETE splicer.end(Args.Cdcomplex.passin) */
  }
}

/*
 * Method:  passout[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdcomplex_passout"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cdcomplex_passout(
  /* in */ Args_Cdcomplex self,
  /* out */ struct sidl_dcomplex* c,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdcomplex.passout) */
  c->imaginary = c->real = 3.14;
  return TRUE;
  /* DO-NOT-DELETE splicer.end(Args.Cdcomplex.passout) */
  }
}

/*
 * Method:  passinout[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdcomplex_passinout"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cdcomplex_passinout(
  /* in */ Args_Cdcomplex self,
  /* inout */ struct sidl_dcomplex* c,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdcomplex.passinout) */
  c->imaginary = - c->imaginary;
  return TRUE;
  /* DO-NOT-DELETE splicer.end(Args.Cdcomplex.passinout) */
  }
}

/*
 * Method:  passeverywhere[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cdcomplex_passeverywhere"

#ifdef __cplusplus
extern "C"
#endif
struct sidl_dcomplex
impl_Args_Cdcomplex_passeverywhere(
  /* in */ Args_Cdcomplex self,
  /* in */ struct sidl_dcomplex c1,
  /* out */ struct sidl_dcomplex* c2,
  /* inout */ struct sidl_dcomplex* c3,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cdcomplex.passeverywhere) */
  struct sidl_dcomplex c4 = {3.14, 3.14};
  struct sidl_dcomplex c5 = {0.0, 0.0};
  c2->real = 3.14;
  c2->imaginary = 3.14;
  c3->imaginary = -c3->imaginary;
  if (3.14 == c1.real && 3.14 == c1.imaginary) {
    return c4;
  }
  else {
    return c5;
  }
  /* DO-NOT-DELETE splicer.end(Args.Cdcomplex.passeverywhere) */
  }
}
/* Babel internal methods, Users should not edit below this line. */
struct Args_Cdcomplex__object* impl_Args_Cdcomplex_fconnect_Args_Cdcomplex(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return Args_Cdcomplex__connectI(url, ar, _ex);
}
struct Args_Cdcomplex__object* impl_Args_Cdcomplex_fcast_Args_Cdcomplex(void* 
  bi, sidl_BaseInterface* _ex) {
  return Args_Cdcomplex__cast(bi, _ex);
}
struct sidl_BaseClass__object* impl_Args_Cdcomplex_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connectI(url, ar, _ex);
}
struct sidl_BaseClass__object* impl_Args_Cdcomplex_fcast_sidl_BaseClass(void* 
  bi, sidl_BaseInterface* _ex) {
  return sidl_BaseClass__cast(bi, _ex);
}
struct sidl_BaseInterface__object* 
  impl_Args_Cdcomplex_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connectI(url, ar, _ex);
}
struct sidl_BaseInterface__object* impl_Args_Cdcomplex_fcast_sidl_BaseInterface(
  void* bi, sidl_BaseInterface* _ex) {
  return sidl_BaseInterface__cast(bi, _ex);
}
struct sidl_ClassInfo__object* impl_Args_Cdcomplex_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connectI(url, ar, _ex);
}
struct sidl_ClassInfo__object* impl_Args_Cdcomplex_fcast_sidl_ClassInfo(void* 
  bi, sidl_BaseInterface* _ex) {
  return sidl_ClassInfo__cast(bi, _ex);
}
struct sidl_RuntimeException__object* 
  impl_Args_Cdcomplex_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex) {
  return sidl_RuntimeException__connectI(url, ar, _ex);
}
struct sidl_RuntimeException__object* 
  impl_Args_Cdcomplex_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex) {
  return sidl_RuntimeException__cast(bi, _ex);
}
