/*
 * File:          wrapper_User_Impl.h
 * Symbol:        wrapper.User-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for wrapper.User
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_wrapper_User_Impl_h
#define included_wrapper_User_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
#ifndef included_wrapper_Data_h
#include "wrapper_Data.h"
#endif
#ifndef included_wrapper_User_h
#include "wrapper_User.h"
#endif

/* DO-NOT-DELETE splicer.begin(wrapper.User._includes) */
/* Insert-Code-Here {wrapper.User._includes} (include files) */
/* DO-NOT-DELETE splicer.end(wrapper.User._includes) */

/*
 * Private data for class wrapper.User
 */

struct wrapper_User__data {
  /* DO-NOT-DELETE splicer.begin(wrapper.User._data) */
  /* Insert-Code-Here {wrapper.User._data} (private data members) */
  int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(wrapper.User._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct wrapper_User__data*
wrapper_User__get_data(
  wrapper_User);

extern void
wrapper_User__set_data(
  wrapper_User,
  struct wrapper_User__data*);

extern
void
impl_wrapper_User__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_wrapper_User__ctor(
  /* in */ wrapper_User self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_wrapper_User__ctor2(
  /* in */ wrapper_User self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_wrapper_User__dtor(
  /* in */ wrapper_User self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct sidl_BaseClass__object* impl_wrapper_User_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_wrapper_User_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_wrapper_User_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_wrapper_User_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_wrapper_User_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_wrapper_User_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_wrapper_User_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_wrapper_User_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
extern struct wrapper_Data__object* impl_wrapper_User_fconnect_wrapper_Data(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct wrapper_Data__object* impl_wrapper_User_fcast_wrapper_Data(void* 
  bi, sidl_BaseInterface* _ex);
extern struct wrapper_User__object* impl_wrapper_User_fconnect_wrapper_User(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct wrapper_User__object* impl_wrapper_User_fcast_wrapper_User(void* 
  bi, sidl_BaseInterface* _ex);
extern
void
impl_wrapper_User_accept(
  /* in */ wrapper_User self,
  /* in */ wrapper_Data data,
  /* out */ sidl_BaseInterface *_ex);

extern struct sidl_BaseClass__object* impl_wrapper_User_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_wrapper_User_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_wrapper_User_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_wrapper_User_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_wrapper_User_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_wrapper_User_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_wrapper_User_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_wrapper_User_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
extern struct wrapper_Data__object* impl_wrapper_User_fconnect_wrapper_Data(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct wrapper_Data__object* impl_wrapper_User_fcast_wrapper_Data(void* 
  bi, sidl_BaseInterface* _ex);
extern struct wrapper_User__object* impl_wrapper_User_fconnect_wrapper_User(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct wrapper_User__object* impl_wrapper_User_fcast_wrapper_User(void* 
  bi, sidl_BaseInterface* _ex);
#ifdef __cplusplus
}
#endif
#endif
