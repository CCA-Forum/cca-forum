/*
 * File:          vector_DivideByZeroException_Impl.h
 * Symbol:        vector.DivideByZeroException-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for vector.DivideByZeroException
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_vector_DivideByZeroException_Impl_h
#define included_vector_DivideByZeroException_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseException_h
#include "sidl_BaseException.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
#ifndef included_sidl_SIDLException_h
#include "sidl_SIDLException.h"
#endif
#ifndef included_sidl_io_Deserializer_h
#include "sidl_io_Deserializer.h"
#endif
#ifndef included_sidl_io_Serializable_h
#include "sidl_io_Serializable.h"
#endif
#ifndef included_sidl_io_Serializer_h
#include "sidl_io_Serializer.h"
#endif
#ifndef included_vector_DivideByZeroException_h
#include "vector_DivideByZeroException.h"
#endif
#ifndef included_vector_Exception_h
#include "vector_Exception.h"
#endif

/* DO-NOT-DELETE splicer.begin(vector.DivideByZeroException._includes) */
/* Put additional include files here... */
/* DO-NOT-DELETE splicer.end(vector.DivideByZeroException._includes) */

/*
 * Private data for class vector.DivideByZeroException
 */

struct vector_DivideByZeroException__data {
  /* DO-NOT-DELETE splicer.begin(vector.DivideByZeroException._data) */
  /* Put private data members here... */
  int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(vector.DivideByZeroException._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct vector_DivideByZeroException__data*
vector_DivideByZeroException__get_data(
  vector_DivideByZeroException);

extern void
vector_DivideByZeroException__set_data(
  vector_DivideByZeroException,
  struct vector_DivideByZeroException__data*);

extern
void
impl_vector_DivideByZeroException__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_vector_DivideByZeroException__ctor(
  /* in */ vector_DivideByZeroException self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_vector_DivideByZeroException__ctor2(
  /* in */ vector_DivideByZeroException self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_vector_DivideByZeroException__dtor(
  /* in */ vector_DivideByZeroException self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct sidl_BaseClass__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_BaseClass(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* 
  impl_vector_DivideByZeroException_fcast_sidl_BaseClass(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseException__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_BaseException(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseException__object* 
  impl_vector_DivideByZeroException_fcast_sidl_BaseException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_BaseInterface(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_vector_DivideByZeroException_fcast_sidl_BaseInterface(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_ClassInfo(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* 
  impl_vector_DivideByZeroException_fcast_sidl_ClassInfo(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_RuntimeException(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_vector_DivideByZeroException_fcast_sidl_RuntimeException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_SIDLException__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_SIDLException(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_SIDLException__object* 
  impl_vector_DivideByZeroException_fcast_sidl_SIDLException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_io_Deserializer__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_io_Deserializer(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_io_Deserializer__object* 
  impl_vector_DivideByZeroException_fcast_sidl_io_Deserializer(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_io_Serializable__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_io_Serializable(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_io_Serializable__object* 
  impl_vector_DivideByZeroException_fcast_sidl_io_Serializable(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_io_Serializer__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_io_Serializer(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_io_Serializer__object* 
  impl_vector_DivideByZeroException_fcast_sidl_io_Serializer(void* bi, 
  sidl_BaseInterface* _ex);
extern struct vector_DivideByZeroException__object* 
  impl_vector_DivideByZeroException_fconnect_vector_DivideByZeroException(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct vector_DivideByZeroException__object* 
  impl_vector_DivideByZeroException_fcast_vector_DivideByZeroException(void* bi,
  sidl_BaseInterface* _ex);
extern struct vector_Exception__object* 
  impl_vector_DivideByZeroException_fconnect_vector_Exception(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct vector_Exception__object* 
  impl_vector_DivideByZeroException_fcast_vector_Exception(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_BaseClass(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* 
  impl_vector_DivideByZeroException_fcast_sidl_BaseClass(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseException__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_BaseException(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseException__object* 
  impl_vector_DivideByZeroException_fcast_sidl_BaseException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_BaseInterface(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_vector_DivideByZeroException_fcast_sidl_BaseInterface(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_ClassInfo(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* 
  impl_vector_DivideByZeroException_fcast_sidl_ClassInfo(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_RuntimeException(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_vector_DivideByZeroException_fcast_sidl_RuntimeException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_SIDLException__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_SIDLException(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_SIDLException__object* 
  impl_vector_DivideByZeroException_fcast_sidl_SIDLException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_io_Deserializer__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_io_Deserializer(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_io_Deserializer__object* 
  impl_vector_DivideByZeroException_fcast_sidl_io_Deserializer(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_io_Serializable__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_io_Serializable(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_io_Serializable__object* 
  impl_vector_DivideByZeroException_fcast_sidl_io_Serializable(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_io_Serializer__object* 
  impl_vector_DivideByZeroException_fconnect_sidl_io_Serializer(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_io_Serializer__object* 
  impl_vector_DivideByZeroException_fcast_sidl_io_Serializer(void* bi, 
  sidl_BaseInterface* _ex);
extern struct vector_DivideByZeroException__object* 
  impl_vector_DivideByZeroException_fconnect_vector_DivideByZeroException(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct vector_DivideByZeroException__object* 
  impl_vector_DivideByZeroException_fcast_vector_DivideByZeroException(void* bi,
  sidl_BaseInterface* _ex);
extern struct vector_Exception__object* 
  impl_vector_DivideByZeroException_fconnect_vector_Exception(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct vector_Exception__object* 
  impl_vector_DivideByZeroException_fcast_vector_Exception(void* bi, 
  sidl_BaseInterface* _ex);
#ifdef __cplusplus
}
#endif
#endif
