// 
// File:          Args_Cfloat_Impl.hxx
// Symbol:        Args.Cfloat-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Cfloat
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_Args_Cfloat_Impl_hxx
#define included_Args_Cfloat_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_Args_Cfloat_IOR_h
#include "Args_Cfloat_IOR.h"
#endif
#ifndef included_Args_Cfloat_hxx
#include "Args_Cfloat.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(Args.Cfloat._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Cfloat._includes)

namespace Args { 

  /**
   * Symbol "Args.Cfloat" (version 1.0)
   */
  class Cfloat_impl : public virtual ::Args::Cfloat 
  // DO-NOT-DELETE splicer.begin(Args.Cfloat._inherits)
  // Put additional inheritance here...
  // DO-NOT-DELETE splicer.end(Args.Cfloat._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(Args.Cfloat._implementation)
    // Put additional implementation details here...
    // DO-NOT-DELETE splicer.end(Args.Cfloat._implementation)

  public:
    // default constructor, used for data wrapping(required)
    Cfloat_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    Cfloat_impl( struct Args_Cfloat__object * s ) : StubBase(s,true), _wrapped(
      false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~Cfloat_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    float
    returnback_impl() ;
    /**
     * user defined non-static method.
     */
    bool
    passin_impl (
      /* in */float f
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passout_impl (
      /* out */float& f
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passinout_impl (
      /* inout */float& f
    )
    ;

    /**
     * user defined non-static method.
     */
    float
    passeverywhere_impl (
      /* in */float f1,
      /* out */float& f2,
      /* inout */float& f3
    )
    ;

  };  // end class Cfloat_impl

} // end namespace Args

// DO-NOT-DELETE splicer.begin(Args.Cfloat._misc)
// Put miscellaneous things here...
// DO-NOT-DELETE splicer.end(Args.Cfloat._misc)

#endif
