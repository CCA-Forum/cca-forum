// 
// File:          Args_Cbool_Impl.cxx
// Symbol:        Args.Cbool-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Cbool
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "Args_Cbool_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(Args.Cbool._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Cbool._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
Args::Cbool_impl::Cbool_impl() : StubBase(reinterpret_cast< void*>(
  ::Args::Cbool::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(Args.Cbool._ctor2)
  // Insert-Code-Here {Args.Cbool._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(Args.Cbool._ctor2)
}

// user defined constructor
void Args::Cbool_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(Args.Cbool._ctor)
  // add construction details here
  // DO-NOT-DELETE splicer.end(Args.Cbool._ctor)
}

// user defined destructor
void Args::Cbool_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(Args.Cbool._dtor)
  // add destruction details here
  // DO-NOT-DELETE splicer.end(Args.Cbool._dtor)
}

// static class initializer
void Args::Cbool_impl::_load() {
  // DO-NOT-DELETE splicer.begin(Args.Cbool._load)
  // guaranteed to be called at most once before any other method in this class
  // DO-NOT-DELETE splicer.end(Args.Cbool._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  returnback[]
 */
bool
Args::Cbool_impl::returnback_impl () 

{
  // DO-NOT-DELETE splicer.begin(Args.Cbool.returnback)
  return true;
  // DO-NOT-DELETE splicer.end(Args.Cbool.returnback)
}

/**
 * Method:  passin[]
 */
bool
Args::Cbool_impl::passin_impl (
  /* in */bool b ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cbool.passin)
  return b;
  // DO-NOT-DELETE splicer.end(Args.Cbool.passin)
}

/**
 * Method:  passout[]
 */
bool
Args::Cbool_impl::passout_impl (
  /* out */bool& b ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cbool.passout)
  b = true;
  return true;
  // DO-NOT-DELETE splicer.end(Args.Cbool.passout)
}

/**
 * Method:  passinout[]
 */
bool
Args::Cbool_impl::passinout_impl (
  /* inout */bool& b ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cbool.passinout)
  b = !b;
  return true;
  // DO-NOT-DELETE splicer.end(Args.Cbool.passinout)
}

/**
 * Method:  passeverywhere[]
 */
bool
Args::Cbool_impl::passeverywhere_impl (
  /* in */bool b1,
  /* out */bool& b2,
  /* inout */bool& b3 ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cbool.passeverywhere)
  b2 = true;
  b3 = !b3;
  return b1;
  // DO-NOT-DELETE splicer.end(Args.Cbool.passeverywhere)
}


// DO-NOT-DELETE splicer.begin(Args.Cbool._misc)
// Put miscellaneous code here
// DO-NOT-DELETE splicer.end(Args.Cbool._misc)

