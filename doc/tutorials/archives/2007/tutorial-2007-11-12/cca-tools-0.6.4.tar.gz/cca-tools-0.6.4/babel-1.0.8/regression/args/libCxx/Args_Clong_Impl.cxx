// 
// File:          Args_Clong_Impl.cxx
// Symbol:        Args.Clong-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Clong
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "Args_Clong_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(Args.Clong._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Clong._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
Args::Clong_impl::Clong_impl() : StubBase(reinterpret_cast< void*>(
  ::Args::Clong::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(Args.Clong._ctor2)
  // Insert-Code-Here {Args.Clong._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(Args.Clong._ctor2)
}

// user defined constructor
void Args::Clong_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(Args.Clong._ctor)
  // add construction details here
  // DO-NOT-DELETE splicer.end(Args.Clong._ctor)
}

// user defined destructor
void Args::Clong_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(Args.Clong._dtor)
  // add destruction details here
  // DO-NOT-DELETE splicer.end(Args.Clong._dtor)
}

// static class initializer
void Args::Clong_impl::_load() {
  // DO-NOT-DELETE splicer.begin(Args.Clong._load)
  // guaranteed to be called at most once before any other method in this class
  // DO-NOT-DELETE splicer.end(Args.Clong._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  returnback[]
 */
int64_t
Args::Clong_impl::returnback_impl () 

{
  // DO-NOT-DELETE splicer.begin(Args.Clong.returnback)
  return 3L;
  // DO-NOT-DELETE splicer.end(Args.Clong.returnback)
}

/**
 * Method:  passin[]
 */
bool
Args::Clong_impl::passin_impl (
  /* in */int64_t l ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Clong.passin)
  return ( l == 3L );
  // DO-NOT-DELETE splicer.end(Args.Clong.passin)
}

/**
 * Method:  passout[]
 */
bool
Args::Clong_impl::passout_impl (
  /* out */int64_t& l ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Clong.passout)
  l = 3L;
  return true;
  // DO-NOT-DELETE splicer.end(Args.Clong.passout)
}

/**
 * Method:  passinout[]
 */
bool
Args::Clong_impl::passinout_impl (
  /* inout */int64_t& l ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Clong.passinout)
  l = -l;
  return true;
  // DO-NOT-DELETE splicer.end(Args.Clong.passinout)
}

/**
 * Method:  passeverywhere[]
 */
int64_t
Args::Clong_impl::passeverywhere_impl (
  /* in */int64_t l1,
  /* out */int64_t& l2,
  /* inout */int64_t& l3 ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Clong.passeverywhere)
  l2 = 3L;
  l3 = -l3;
  return ( l1 == 3L ) ? 3L : 0L;
  // DO-NOT-DELETE splicer.end(Args.Clong.passeverywhere)
}


// DO-NOT-DELETE splicer.begin(Args.Clong._misc)
// Put miscellaneous code here
// DO-NOT-DELETE splicer.end(Args.Clong._misc)

