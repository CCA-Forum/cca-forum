/*
 * File:          Args_Cfcomplex_Impl.c
 * Symbol:        Args.Cfcomplex-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cfcomplex
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "Args.Cfcomplex" (version 1.0)
 */

#include "Args_Cfcomplex_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"

/* DO-NOT-DELETE splicer.begin(Args.Cfcomplex._includes) */
/* Put additional includes or other arbitrary code here... */
/* DO-NOT-DELETE splicer.end(Args.Cfcomplex._includes) */

#define SIDL_IOR_MAJOR_VERSION 1
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfcomplex__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cfcomplex__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfcomplex._load) */
  /* Insert the implementation of the static class initializer method here... */
  /* DO-NOT-DELETE splicer.end(Args.Cfcomplex._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfcomplex__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cfcomplex__ctor(
  /* in */ Args_Cfcomplex self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfcomplex._ctor) */
  /* DO-NOT-DELETE splicer.end(Args.Cfcomplex._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfcomplex__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cfcomplex__ctor2(
  /* in */ Args_Cfcomplex self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfcomplex._ctor2) */
  /* Insert-Code-Here {Args.Cfcomplex._ctor2} (special constructor method) */
  /* DO-NOT-DELETE splicer.end(Args.Cfcomplex._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfcomplex__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cfcomplex__dtor(
  /* in */ Args_Cfcomplex self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfcomplex._dtor) */
  /* DO-NOT-DELETE splicer.end(Args.Cfcomplex._dtor) */
  }
}

/*
 * Method:  returnback[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfcomplex_returnback"

#ifdef __cplusplus
extern "C"
#endif
struct sidl_fcomplex
impl_Args_Cfcomplex_returnback(
  /* in */ Args_Cfcomplex self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfcomplex.returnback) */
  struct sidl_fcomplex c = {3.1F, 3.1F};
  return c;
  /* DO-NOT-DELETE splicer.end(Args.Cfcomplex.returnback) */
  }
}

/*
 * Method:  passin[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfcomplex_passin"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cfcomplex_passin(
  /* in */ Args_Cfcomplex self,
  /* in */ struct sidl_fcomplex c,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfcomplex.passin) */
  return (3.1F == c.real && 3.1F == c.imaginary);
  /* DO-NOT-DELETE splicer.end(Args.Cfcomplex.passin) */
  }
}

/*
 * Method:  passout[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfcomplex_passout"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cfcomplex_passout(
  /* in */ Args_Cfcomplex self,
  /* out */ struct sidl_fcomplex* c,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfcomplex.passout) */
  c->real = c->imaginary = 3.1F;
  return TRUE;
  /* DO-NOT-DELETE splicer.end(Args.Cfcomplex.passout) */
  }
}

/*
 * Method:  passinout[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfcomplex_passinout"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cfcomplex_passinout(
  /* in */ Args_Cfcomplex self,
  /* inout */ struct sidl_fcomplex* c,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfcomplex.passinout) */
  c->imaginary = - c->imaginary;
  return TRUE;
  /* DO-NOT-DELETE splicer.end(Args.Cfcomplex.passinout) */
  }
}

/*
 * Method:  passeverywhere[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfcomplex_passeverywhere"

#ifdef __cplusplus
extern "C"
#endif
struct sidl_fcomplex
impl_Args_Cfcomplex_passeverywhere(
  /* in */ Args_Cfcomplex self,
  /* in */ struct sidl_fcomplex c1,
  /* out */ struct sidl_fcomplex* c2,
  /* inout */ struct sidl_fcomplex* c3,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfcomplex.passeverywhere) */
  struct sidl_fcomplex c4 = {3.1F, 3.1F};
  struct sidl_fcomplex c5 = {0.0F, 0.0F};
  c2->imaginary = c2->real = 3.1F;
  c3->imaginary = - c3->imaginary;
  if (3.1F == c1.real && 3.1F == c1.imaginary) {
    return c4;
  }
  else {
    return c5;
  }
  /* DO-NOT-DELETE splicer.end(Args.Cfcomplex.passeverywhere) */
  }
}
/* Babel internal methods, Users should not edit below this line. */
struct Args_Cfcomplex__object* impl_Args_Cfcomplex_fconnect_Args_Cfcomplex(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return Args_Cfcomplex__connectI(url, ar, _ex);
}
struct Args_Cfcomplex__object* impl_Args_Cfcomplex_fcast_Args_Cfcomplex(void* 
  bi, sidl_BaseInterface* _ex) {
  return Args_Cfcomplex__cast(bi, _ex);
}
struct sidl_BaseClass__object* impl_Args_Cfcomplex_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connectI(url, ar, _ex);
}
struct sidl_BaseClass__object* impl_Args_Cfcomplex_fcast_sidl_BaseClass(void* 
  bi, sidl_BaseInterface* _ex) {
  return sidl_BaseClass__cast(bi, _ex);
}
struct sidl_BaseInterface__object* 
  impl_Args_Cfcomplex_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connectI(url, ar, _ex);
}
struct sidl_BaseInterface__object* impl_Args_Cfcomplex_fcast_sidl_BaseInterface(
  void* bi, sidl_BaseInterface* _ex) {
  return sidl_BaseInterface__cast(bi, _ex);
}
struct sidl_ClassInfo__object* impl_Args_Cfcomplex_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connectI(url, ar, _ex);
}
struct sidl_ClassInfo__object* impl_Args_Cfcomplex_fcast_sidl_ClassInfo(void* 
  bi, sidl_BaseInterface* _ex) {
  return sidl_ClassInfo__cast(bi, _ex);
}
struct sidl_RuntimeException__object* 
  impl_Args_Cfcomplex_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex) {
  return sidl_RuntimeException__connectI(url, ar, _ex);
}
struct sidl_RuntimeException__object* 
  impl_Args_Cfcomplex_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex) {
  return sidl_RuntimeException__cast(bi, _ex);
}
