/*
 * File:          sort_SimpleCounter_Impl.h
 * Symbol:        sort.SimpleCounter-v0.1
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for sort.SimpleCounter
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_sort_SimpleCounter_Impl_h
#define included_sort_SimpleCounter_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
#ifndef included_sort_Counter_h
#include "sort_Counter.h"
#endif
#ifndef included_sort_SimpleCounter_h
#include "sort_SimpleCounter.h"
#endif

/* DO-NOT-DELETE splicer.begin(sort.SimpleCounter._includes) */
/* Put additional include files here... */
/* DO-NOT-DELETE splicer.end(sort.SimpleCounter._includes) */

/*
 * Private data for class sort.SimpleCounter
 */

struct sort_SimpleCounter__data {
  /* DO-NOT-DELETE splicer.begin(sort.SimpleCounter._data) */
  int32_t d_count;
  /* DO-NOT-DELETE splicer.end(sort.SimpleCounter._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct sort_SimpleCounter__data*
sort_SimpleCounter__get_data(
  sort_SimpleCounter);

extern void
sort_SimpleCounter__set_data(
  sort_SimpleCounter,
  struct sort_SimpleCounter__data*);

extern
void
impl_sort_SimpleCounter__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_sort_SimpleCounter__ctor(
  /* in */ sort_SimpleCounter self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_sort_SimpleCounter__ctor2(
  /* in */ sort_SimpleCounter self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_sort_SimpleCounter__dtor(
  /* in */ sort_SimpleCounter self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct sidl_BaseClass__object* 
  impl_sort_SimpleCounter_fconnect_sidl_BaseClass(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* 
  impl_sort_SimpleCounter_fcast_sidl_BaseClass(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_BaseInterface__object* 
  impl_sort_SimpleCounter_fconnect_sidl_BaseInterface(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_sort_SimpleCounter_fcast_sidl_BaseInterface(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* 
  impl_sort_SimpleCounter_fconnect_sidl_ClassInfo(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* 
  impl_sort_SimpleCounter_fcast_sidl_ClassInfo(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_RuntimeException__object* 
  impl_sort_SimpleCounter_fconnect_sidl_RuntimeException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_sort_SimpleCounter_fcast_sidl_RuntimeException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sort_Counter__object* 
  impl_sort_SimpleCounter_fconnect_sort_Counter(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sort_Counter__object* impl_sort_SimpleCounter_fcast_sort_Counter(
  void* bi, sidl_BaseInterface* _ex);
extern struct sort_SimpleCounter__object* 
  impl_sort_SimpleCounter_fconnect_sort_SimpleCounter(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sort_SimpleCounter__object* 
  impl_sort_SimpleCounter_fcast_sort_SimpleCounter(void* bi, 
  sidl_BaseInterface* _ex);
extern
void
impl_sort_SimpleCounter_reset(
  /* in */ sort_SimpleCounter self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_sort_SimpleCounter_getCount(
  /* in */ sort_SimpleCounter self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_sort_SimpleCounter_inc(
  /* in */ sort_SimpleCounter self,
  /* out */ sidl_BaseInterface *_ex);

extern struct sidl_BaseClass__object* 
  impl_sort_SimpleCounter_fconnect_sidl_BaseClass(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* 
  impl_sort_SimpleCounter_fcast_sidl_BaseClass(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_BaseInterface__object* 
  impl_sort_SimpleCounter_fconnect_sidl_BaseInterface(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_sort_SimpleCounter_fcast_sidl_BaseInterface(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* 
  impl_sort_SimpleCounter_fconnect_sidl_ClassInfo(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* 
  impl_sort_SimpleCounter_fcast_sidl_ClassInfo(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_RuntimeException__object* 
  impl_sort_SimpleCounter_fconnect_sidl_RuntimeException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_sort_SimpleCounter_fcast_sidl_RuntimeException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sort_Counter__object* 
  impl_sort_SimpleCounter_fconnect_sort_Counter(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sort_Counter__object* impl_sort_SimpleCounter_fcast_sort_Counter(
  void* bi, sidl_BaseInterface* _ex);
extern struct sort_SimpleCounter__object* 
  impl_sort_SimpleCounter_fconnect_sort_SimpleCounter(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sort_SimpleCounter__object* 
  impl_sort_SimpleCounter_fcast_sort_SimpleCounter(void* bi, 
  sidl_BaseInterface* _ex);
#ifdef __cplusplus
}
#endif
#endif
