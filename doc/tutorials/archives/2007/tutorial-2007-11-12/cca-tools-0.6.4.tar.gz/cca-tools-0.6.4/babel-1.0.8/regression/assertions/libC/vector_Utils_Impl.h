/*
 * File:          vector_Utils_Impl.h
 * Symbol:        vector.Utils-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for vector.Utils
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_vector_Utils_Impl_h
#define included_vector_Utils_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_PostViolation_h
#include "sidl_PostViolation.h"
#endif
#ifndef included_sidl_PreViolation_h
#include "sidl_PreViolation.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
#ifndef included_vector_DivideByZeroException_h
#include "vector_DivideByZeroException.h"
#endif
#ifndef included_vector_NegativeValueException_h
#include "vector_NegativeValueException.h"
#endif
#ifndef included_vector_Utils_h
#include "vector_Utils.h"
#endif

/* DO-NOT-DELETE splicer.begin(vector.Utils._includes) */
/* Put additional include files here... */
/* DO-NOT-DELETE splicer.end(vector.Utils._includes) */

/*
 * Private data for class vector.Utils
 */

struct vector_Utils__data {
  /* DO-NOT-DELETE splicer.begin(vector.Utils._data) */
  /* Put private data members here... */
  int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(vector.Utils._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct vector_Utils__data*
vector_Utils__get_data(
  vector_Utils);

extern void
vector_Utils__set_data(
  vector_Utils,
  struct vector_Utils__data*);

extern
void
impl_vector_Utils__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_vector_Utils__ctor(
  /* in */ vector_Utils self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_vector_Utils__ctor2(
  /* in */ vector_Utils self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_vector_Utils__dtor(
  /* in */ vector_Utils self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_vector_Utils__check_error_static(
  /* in */ const char* msg,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_vector_Utils__check_error(
  /* in */ vector_Utils self,
  /* in */ const char* msg,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern
sidl_bool
impl_vector_Utils_isZero(
  /* in array<double> */ struct sidl_double__array* u,
  /* in */ double tol,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_vector_Utils_isUnit(
  /* in array<double> */ struct sidl_double__array* u,
  /* in */ double tol,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_vector_Utils_areEqual(
  /* in array<double> */ struct sidl_double__array* u,
  /* in array<double> */ struct sidl_double__array* v,
  /* in */ double tol,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_vector_Utils_areOrthogonal(
  /* in array<double> */ struct sidl_double__array* u,
  /* in array<double> */ struct sidl_double__array* v,
  /* in */ double tol,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_vector_Utils_schwarzHolds(
  /* in array<double> */ struct sidl_double__array* u,
  /* in array<double> */ struct sidl_double__array* v,
  /* in */ double tol,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_vector_Utils_triangleInequalityHolds(
  /* in array<double> */ struct sidl_double__array* u,
  /* in array<double> */ struct sidl_double__array* v,
  /* in */ double tol,
  /* out */ sidl_BaseInterface *_ex);

extern
double
impl_vector_Utils_norm(
  /* in array<double> */ struct sidl_double__array* u,
  /* in */ double tol,
  /* in */ int32_t badLevel,
  /* out */ sidl_BaseInterface *_ex);

extern
double
impl_vector_Utils_dot(
  /* in array<double> */ struct sidl_double__array* u,
  /* in array<double> */ struct sidl_double__array* v,
  /* in */ double tol,
  /* in */ int32_t badLevel,
  /* out */ sidl_BaseInterface *_ex);

extern
struct sidl_double__array*
impl_vector_Utils_product(
  /* in */ double a,
  /* in array<double> */ struct sidl_double__array* u,
  /* in */ int32_t badLevel,
  /* out */ sidl_BaseInterface *_ex);

extern
struct sidl_double__array*
impl_vector_Utils_negate(
  /* in array<double> */ struct sidl_double__array* u,
  /* in */ int32_t badLevel,
  /* out */ sidl_BaseInterface *_ex);

extern
struct sidl_double__array*
impl_vector_Utils_normalize(
  /* in array<double> */ struct sidl_double__array* u,
  /* in */ double tol,
  /* in */ int32_t badLevel,
  /* out */ sidl_BaseInterface *_ex);

extern
struct sidl_double__array*
impl_vector_Utils_sum(
  /* in array<double> */ struct sidl_double__array* u,
  /* in array<double> */ struct sidl_double__array* v,
  /* in */ int32_t badLevel,
  /* out */ sidl_BaseInterface *_ex);

extern
struct sidl_double__array*
impl_vector_Utils_diff(
  /* in array<double> */ struct sidl_double__array* u,
  /* in array<double> */ struct sidl_double__array* v,
  /* in */ int32_t badLevel,
  /* out */ sidl_BaseInterface *_ex);

extern struct sidl_BaseClass__object* impl_vector_Utils_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_vector_Utils_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_vector_Utils_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_vector_Utils_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_vector_Utils_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_vector_Utils_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_PostViolation__object* 
  impl_vector_Utils_fconnect_sidl_PostViolation(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_PostViolation__object* 
  impl_vector_Utils_fcast_sidl_PostViolation(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_PreViolation__object* 
  impl_vector_Utils_fconnect_sidl_PreViolation(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_PreViolation__object* 
  impl_vector_Utils_fcast_sidl_PreViolation(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_vector_Utils_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_vector_Utils_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
extern struct vector_DivideByZeroException__object* 
  impl_vector_Utils_fconnect_vector_DivideByZeroException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct vector_DivideByZeroException__object* 
  impl_vector_Utils_fcast_vector_DivideByZeroException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct vector_NegativeValueException__object* 
  impl_vector_Utils_fconnect_vector_NegativeValueException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct vector_NegativeValueException__object* 
  impl_vector_Utils_fcast_vector_NegativeValueException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct vector_Utils__object* impl_vector_Utils_fconnect_vector_Utils(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct vector_Utils__object* impl_vector_Utils_fcast_vector_Utils(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* impl_vector_Utils_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_vector_Utils_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_vector_Utils_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_vector_Utils_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_vector_Utils_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_vector_Utils_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_PostViolation__object* 
  impl_vector_Utils_fconnect_sidl_PostViolation(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_PostViolation__object* 
  impl_vector_Utils_fcast_sidl_PostViolation(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_PreViolation__object* 
  impl_vector_Utils_fconnect_sidl_PreViolation(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_PreViolation__object* 
  impl_vector_Utils_fcast_sidl_PreViolation(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_vector_Utils_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_vector_Utils_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
extern struct vector_DivideByZeroException__object* 
  impl_vector_Utils_fconnect_vector_DivideByZeroException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct vector_DivideByZeroException__object* 
  impl_vector_Utils_fcast_vector_DivideByZeroException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct vector_NegativeValueException__object* 
  impl_vector_Utils_fconnect_vector_NegativeValueException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct vector_NegativeValueException__object* 
  impl_vector_Utils_fcast_vector_NegativeValueException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct vector_Utils__object* impl_vector_Utils_fconnect_vector_Utils(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct vector_Utils__object* impl_vector_Utils_fcast_vector_Utils(void* 
  bi, sidl_BaseInterface* _ex);
#ifdef __cplusplus
}
#endif
#endif
