/*
 * File:          Args_Cint_Impl.h
 * Symbol:        Args.Cint-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cint
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_Args_Cint_Impl_h
#define included_Args_Cint_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_Args_Cint_h
#include "Args_Cint.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif

/* DO-NOT-DELETE splicer.begin(Args.Cint._includes) */
/* Put additional include files here... */
/* DO-NOT-DELETE splicer.end(Args.Cint._includes) */

/*
 * Private data for class Args.Cint
 */

struct Args_Cint__data {
  /* DO-NOT-DELETE splicer.begin(Args.Cint._data) */
  /* Put private data members here... */
  int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(Args.Cint._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct Args_Cint__data*
Args_Cint__get_data(
  Args_Cint);

extern void
Args_Cint__set_data(
  Args_Cint,
  struct Args_Cint__data*);

extern
void
impl_Args_Cint__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cint__ctor(
  /* in */ Args_Cint self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cint__ctor2(
  /* in */ Args_Cint self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cint__dtor(
  /* in */ Args_Cint self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct Args_Cint__object* impl_Args_Cint_fconnect_Args_Cint(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct Args_Cint__object* impl_Args_Cint_fcast_Args_Cint(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* impl_Args_Cint_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_Args_Cint_fcast_sidl_BaseClass(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cint_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cint_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_Args_Cint_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_Args_Cint_fcast_sidl_ClassInfo(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cint_fconnect_sidl_RuntimeException(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cint_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* _ex);
extern
int32_t
impl_Args_Cint_returnback(
  /* in */ Args_Cint self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cint_passin(
  /* in */ Args_Cint self,
  /* in */ int32_t i,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cint_passout(
  /* in */ Args_Cint self,
  /* out */ int32_t* i,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cint_passinout(
  /* in */ Args_Cint self,
  /* inout */ int32_t* i,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_Args_Cint_passeverywhere(
  /* in */ Args_Cint self,
  /* in */ int32_t i1,
  /* out */ int32_t* i2,
  /* inout */ int32_t* i3,
  /* out */ sidl_BaseInterface *_ex);

extern struct Args_Cint__object* impl_Args_Cint_fconnect_Args_Cint(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct Args_Cint__object* impl_Args_Cint_fcast_Args_Cint(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* impl_Args_Cint_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_Args_Cint_fcast_sidl_BaseClass(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cint_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cint_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_Args_Cint_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_Args_Cint_fcast_sidl_ClassInfo(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cint_fconnect_sidl_RuntimeException(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cint_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* _ex);
#ifdef __cplusplus
}
#endif
#endif
