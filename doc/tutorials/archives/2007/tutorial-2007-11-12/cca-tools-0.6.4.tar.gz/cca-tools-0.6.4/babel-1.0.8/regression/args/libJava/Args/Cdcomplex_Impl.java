/*
 * File:          Cdcomplex_Impl.java
 * Symbol:        Args.Cdcomplex-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cdcomplex
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package Args;

import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;

// DO-NOT-DELETE splicer.begin(Args.Cdcomplex._imports)
// Put additional imports here...
// DO-NOT-DELETE splicer.end(Args.Cdcomplex._imports)

/**
 * Symbol "Args.Cdcomplex" (version 1.0)
 */
public class Cdcomplex_Impl extends Cdcomplex
{

  // DO-NOT-DELETE splicer.begin(Args.Cdcomplex._data)
  // Put additional private data here...
  // DO-NOT-DELETE splicer.end(Args.Cdcomplex._data)

  static { 
  // DO-NOT-DELETE splicer.begin(Args.Cdcomplex._load)
  // Put load function implementation here...
  // DO-NOT-DELETE splicer.end(Args.Cdcomplex._load)
  }

  /**
   * User defined constructor
   */
  public Cdcomplex_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(Args.Cdcomplex.Cdcomplex)
    // add construction details here
    // DO-NOT-DELETE splicer.end(Args.Cdcomplex.Cdcomplex)
  }

  /**
   * Back door constructor
   */
  public Cdcomplex_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(Args.Cdcomplex._wrap)
    // Insert-Code-Here {Args.Cdcomplex._wrap} (_wrap)
    // DO-NOT-DELETE splicer.end(Args.Cdcomplex._wrap)
  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Cdcomplex._dtor)
    // add destruction details here
    // DO-NOT-DELETE splicer.end(Args.Cdcomplex._dtor)
  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Cdcomplex.finalize)
    // Insert-Code-Here {Args.Cdcomplex.finalize} (finalize)
    // DO-NOT-DELETE splicer.end(Args.Cdcomplex.finalize)
  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  returnback[]
   */
  public sidl.DoubleComplex returnback_Impl () 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cdcomplex.returnback)
    // insert implementation here
      return new sidl.DoubleComplex(3.14,3.14);
    // DO-NOT-DELETE splicer.end(Args.Cdcomplex.returnback)
  }

  /**
   * Method:  passin[]
   */
  public boolean passin_Impl (
    /*in*/ sidl.DoubleComplex c ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cdcomplex.passin)
    // insert implementation here
      double real = sidl.DoubleComplex.real(c);
      double imag = sidl.DoubleComplex.imag(c);
      System.out.println("Number is: " +real + " + " + imag + "i");
      if(real == 3.14 && imag == 3.14) {
	  return true;
      }
      else 
	  return false;
    // DO-NOT-DELETE splicer.end(Args.Cdcomplex.passin)
  }

  /**
   * Method:  passout[]
   */
  public boolean passout_Impl (
    /*out*/ sidl.DoubleComplex.Holder c ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cdcomplex.passout)
    // insert implementation here
    
      if(c != null){
        c.set(new sidl.DoubleComplex(3.14,3.14));
        return true;
      }
      else
        return false;
    // DO-NOT-DELETE splicer.end(Args.Cdcomplex.passout)
  }

  /**
   * Method:  passinout[]
   */
  public boolean passinout_Impl (
    /*inout*/ sidl.DoubleComplex.Holder c ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cdcomplex.passinout)
    // insert implementation here
      if(c != null){
	  c.get().set(c.get().real(),-c.get().imag());
	  return true;
      }
      else
	  return false;
    // DO-NOT-DELETE splicer.end(Args.Cdcomplex.passinout)
  }

  /**
   * Method:  passeverywhere[]
   */
  public sidl.DoubleComplex passeverywhere_Impl (
    /*in*/ sidl.DoubleComplex c1,
    /*out*/ sidl.DoubleComplex.Holder c2,
    /*inout*/ sidl.DoubleComplex.Holder c3 ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cdcomplex.passeverywhere)
    // insert implementation here
    
       c2.set(new sidl.DoubleComplex(0.0, 0.0));
       if(c3 == null)
         return null;
       c3.get().set(c3.get().real(),-c3.get().imag());
       c2.get().set(3.14,3.14); 
       
       if(c1.real() == 3.14 && c1.imag() == 3.14)
         return new sidl.DoubleComplex(3.14,3.14);
       else 
         return null;
    // DO-NOT-DELETE splicer.end(Args.Cdcomplex.passeverywhere)
  }


  // DO-NOT-DELETE splicer.begin(Args.Cdcomplex._misc)
  // Put miscellaneous code here
  // DO-NOT-DELETE splicer.end(Args.Cdcomplex._misc)

} // end class Cdcomplex

/**
 * ================= BEGIN UNREFERENCED METHOD(S) ================
 * The following code segment(s) belong to unreferenced method(s).
 * This can result from a method rename/removal in the sidl file.
 * Move or remove the code in order to compile cleanly.
 */
// DO-NOT-DELETE splicer.begin(Args.Cdcomplex._inherits)
// Put additional inheritance here...
// DO-NOT-DELETE splicer.end(Args.Cdcomplex._inherits)
// ================== END UNREFERENCED METHOD(S) =================
