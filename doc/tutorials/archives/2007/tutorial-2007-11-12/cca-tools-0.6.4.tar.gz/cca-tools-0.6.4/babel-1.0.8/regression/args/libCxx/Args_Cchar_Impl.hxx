// 
// File:          Args_Cchar_Impl.hxx
// Symbol:        Args.Cchar-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Cchar
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_Args_Cchar_Impl_hxx
#define included_Args_Cchar_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_Args_Cchar_IOR_h
#include "Args_Cchar_IOR.h"
#endif
#ifndef included_Args_Cchar_hxx
#include "Args_Cchar.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(Args.Cchar._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Cchar._includes)

namespace Args { 

  /**
   * Symbol "Args.Cchar" (version 1.0)
   */
  class Cchar_impl : public virtual ::Args::Cchar 
  // DO-NOT-DELETE splicer.begin(Args.Cchar._inherits)
  // Put additional inheritance here...
  // DO-NOT-DELETE splicer.end(Args.Cchar._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(Args.Cchar._implementation)
    // Put additional implementation details here...
    // DO-NOT-DELETE splicer.end(Args.Cchar._implementation)

  public:
    // default constructor, used for data wrapping(required)
    Cchar_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    Cchar_impl( struct Args_Cchar__object * s ) : StubBase(s,true), _wrapped(
      false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~Cchar_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    char
    returnback_impl() ;
    /**
     * user defined non-static method.
     */
    bool
    passin_impl (
      /* in */char c
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passout_impl (
      /* out */char& c
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passinout_impl (
      /* inout */char& c
    )
    ;

    /**
     * user defined non-static method.
     */
    char
    passeverywhere_impl (
      /* in */char c1,
      /* out */char& c2,
      /* inout */char& c3
    )
    ;

  };  // end class Cchar_impl

} // end namespace Args

// DO-NOT-DELETE splicer.begin(Args.Cchar._misc)
// Put miscellaneous things here...
// DO-NOT-DELETE splicer.end(Args.Cchar._misc)

#endif
