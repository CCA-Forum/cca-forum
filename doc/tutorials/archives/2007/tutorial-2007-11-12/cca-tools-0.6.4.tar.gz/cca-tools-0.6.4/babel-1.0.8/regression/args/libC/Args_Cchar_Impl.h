/*
 * File:          Args_Cchar_Impl.h
 * Symbol:        Args.Cchar-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cchar
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_Args_Cchar_Impl_h
#define included_Args_Cchar_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_Args_Cchar_h
#include "Args_Cchar.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif

/* DO-NOT-DELETE splicer.begin(Args.Cchar._includes) */
/* Put additional include files here... */
/* DO-NOT-DELETE splicer.end(Args.Cchar._includes) */

/*
 * Private data for class Args.Cchar
 */

struct Args_Cchar__data {
  /* DO-NOT-DELETE splicer.begin(Args.Cchar._data) */
  /* Put private data members here... */
  int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(Args.Cchar._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct Args_Cchar__data*
Args_Cchar__get_data(
  Args_Cchar);

extern void
Args_Cchar__set_data(
  Args_Cchar,
  struct Args_Cchar__data*);

extern
void
impl_Args_Cchar__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cchar__ctor(
  /* in */ Args_Cchar self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cchar__ctor2(
  /* in */ Args_Cchar self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cchar__dtor(
  /* in */ Args_Cchar self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct Args_Cchar__object* impl_Args_Cchar_fconnect_Args_Cchar(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct Args_Cchar__object* impl_Args_Cchar_fcast_Args_Cchar(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* impl_Args_Cchar_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_Args_Cchar_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cchar_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cchar_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_Args_Cchar_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_Args_Cchar_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cchar_fconnect_sidl_RuntimeException(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cchar_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
extern
char
impl_Args_Cchar_returnback(
  /* in */ Args_Cchar self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cchar_passin(
  /* in */ Args_Cchar self,
  /* in */ char c,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cchar_passout(
  /* in */ Args_Cchar self,
  /* out */ char* c,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cchar_passinout(
  /* in */ Args_Cchar self,
  /* inout */ char* c,
  /* out */ sidl_BaseInterface *_ex);

extern
char
impl_Args_Cchar_passeverywhere(
  /* in */ Args_Cchar self,
  /* in */ char c1,
  /* out */ char* c2,
  /* inout */ char* c3,
  /* out */ sidl_BaseInterface *_ex);

extern struct Args_Cchar__object* impl_Args_Cchar_fconnect_Args_Cchar(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct Args_Cchar__object* impl_Args_Cchar_fcast_Args_Cchar(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* impl_Args_Cchar_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_Args_Cchar_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cchar_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cchar_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_Args_Cchar_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_Args_Cchar_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cchar_fconnect_sidl_RuntimeException(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cchar_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
#ifdef __cplusplus
}
#endif
#endif
