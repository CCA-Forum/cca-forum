/*
 * File:          Cchar_Impl.java
 * Symbol:        Args.Cchar-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cchar
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package Args;

import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;

// DO-NOT-DELETE splicer.begin(Args.Cchar._imports)
// Put additional imports here...
// DO-NOT-DELETE splicer.end(Args.Cchar._imports)

/**
 * Symbol "Args.Cchar" (version 1.0)
 */
public class Cchar_Impl extends Cchar
{

  // DO-NOT-DELETE splicer.begin(Args.Cchar._data)
  // Put additional private data here...
  // DO-NOT-DELETE splicer.end(Args.Cchar._data)

  static { 
  // DO-NOT-DELETE splicer.begin(Args.Cchar._load)
  // Put load function implementation here...
  // DO-NOT-DELETE splicer.end(Args.Cchar._load)
  }

  /**
   * User defined constructor
   */
  public Cchar_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(Args.Cchar.Cchar)
    // add construction details here
    // DO-NOT-DELETE splicer.end(Args.Cchar.Cchar)
  }

  /**
   * Back door constructor
   */
  public Cchar_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(Args.Cchar._wrap)
    // Insert-Code-Here {Args.Cchar._wrap} (_wrap)
    // DO-NOT-DELETE splicer.end(Args.Cchar._wrap)
  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Cchar._dtor)
    // add destruction details here
    // DO-NOT-DELETE splicer.end(Args.Cchar._dtor)
  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Cchar.finalize)
    // Insert-Code-Here {Args.Cchar.finalize} (finalize)
    // DO-NOT-DELETE splicer.end(Args.Cchar.finalize)
  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  returnback[]
   */
  public char returnback_Impl () 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cchar.returnback)
    // insert implementation here
    return '3';
    // DO-NOT-DELETE splicer.end(Args.Cchar.returnback)
  }

  /**
   * Method:  passin[]
   */
  public boolean passin_Impl (
    /*in*/ char c ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cchar.passin)
    // insert implementation here
      if(c == '3')
	  return true;
      else
	  return false;
    // DO-NOT-DELETE splicer.end(Args.Cchar.passin)
  }

  /**
   * Method:  passout[]
   */
  public boolean passout_Impl (
    /*out*/ sidl.Character.Holder c ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cchar.passout)
    // insert implementation here
      if(c != null){
	  c.set('3');
	  return true;
      }
      else{
	  c.set('\0');
	  return false;
      }
    // DO-NOT-DELETE splicer.end(Args.Cchar.passout)
  }

  /**
   * Method:  passinout[]
   */
  public boolean passinout_Impl (
    /*inout*/ sidl.Character.Holder c ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cchar.passinout)
    // insert implementation here
      if(c == null)
	  return false;

      // Uppercase
      if(c.get() < 97) {
	  c.set((char)(c.get() + 32));
	  return true;
      }
      else { // Lowercase
	  c.set((char)(c.get() - 32));
	  return true;
      }
    // DO-NOT-DELETE splicer.end(Args.Cchar.passinout)
  }

  /**
   * Method:  passeverywhere[]
   */
  public char passeverywhere_Impl (
    /*in*/ char c1,
    /*out*/ sidl.Character.Holder c2,
    /*inout*/ sidl.Character.Holder c3 ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cchar.passeverywhere)
    // insert implementation here
      c2.set('\0');
      if(c3 == null)
	  return '\0';
      c3.set('A');
      c2.set('3');
      if(c1 == '3')
	  return '3';
      else
	  return '\0';
    // DO-NOT-DELETE splicer.end(Args.Cchar.passeverywhere)
  }


  // DO-NOT-DELETE splicer.begin(Args.Cchar._misc)
  // Put miscellaneous code here
  // DO-NOT-DELETE splicer.end(Args.Cchar._misc)

} // end class Cchar

/**
 * ================= BEGIN UNREFERENCED METHOD(S) ================
 * The following code segment(s) belong to unreferenced method(s).
 * This can result from a method rename/removal in the sidl file.
 * Move or remove the code in order to compile cleanly.
 */
// DO-NOT-DELETE splicer.begin(Args.Cchar._inherits)
// Put additional inheritance here...
// DO-NOT-DELETE splicer.end(Args.Cchar._inherits)
// ================== END UNREFERENCED METHOD(S) =================
