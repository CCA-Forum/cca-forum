#!/bin/sh
#
# This shell script sets up Intel C/C++ with debugging
# for the CASC Linux cluster.

if ( uname -r | grep EL 2>&1 > /dev/null ) then
  export PATH=`echo "$PATH" | sed -e 's,/usr/casc/babel/apps/linux_el/bin,/usr/casc/babel/apps/linux_el_intel/bin:/usr/casc/babel/apps/linux_el/bin,g'`
  export LD_LIBRARY_PATH=`echo "$LD_LIBRARY_PATH" | sed -e 's,/usr/casc/babel/apps/linux_el/lib,/usr/casc/babel/apps/linux_el_intel/lib:/usr/casc/babel/apps/linux_el/lib,g'`
else
  export PATH=`echo "$PATH" | sed -e 's,/usr/casc/babel/apps/linux/bin,/usr/casc/babel/apps/linux_intel_compiler/bin:/usr/casc/babel/apps/linux/bin,g'`
  export LD_LIBRARY_PATH=`echo "$LD_LIBRARY_PATH" | sed -e 's,/usr/casc/babel/apps/linux/lib,/usr/casc/babel/apps/linux_intel_compiler/lib:/usr/casc/babel/apps/linux/lib,g'`
fi
. /usr/apps/intel/cc_8.1.022/setup.sh
export CC='icc -c99'
export CFLAGS='-g -Wall -wd869,1419'
export CXX='icpc'
export CXXFLAGS='-g -Wall'
export CPP='gcc -E'
