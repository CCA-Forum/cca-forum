/*
 * File:          Cbool_Impl.java
 * Symbol:        Args.Cbool-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cbool
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package Args;

import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;

// DO-NOT-DELETE splicer.begin(Args.Cbool._imports)
// Put additional imports here...
// DO-NOT-DELETE splicer.end(Args.Cbool._imports)

/**
 * Symbol "Args.Cbool" (version 1.0)
 */
public class Cbool_Impl extends Cbool
{

  // DO-NOT-DELETE splicer.begin(Args.Cbool._data)
  // Put additional private data here...
  // DO-NOT-DELETE splicer.end(Args.Cbool._data)

  static { 
  // DO-NOT-DELETE splicer.begin(Args.Cbool._load)
  // Put load function implementation here...
  // DO-NOT-DELETE splicer.end(Args.Cbool._load)
  }

  /**
   * User defined constructor
   */
  public Cbool_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(Args.Cbool.Cbool)
    // add construction details here
    // DO-NOT-DELETE splicer.end(Args.Cbool.Cbool)
  }

  /**
   * Back door constructor
   */
  public Cbool_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(Args.Cbool._wrap)
    // Insert-Code-Here {Args.Cbool._wrap} (_wrap)
    // DO-NOT-DELETE splicer.end(Args.Cbool._wrap)
  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Cbool._dtor)
    // add destruction details here
    // DO-NOT-DELETE splicer.end(Args.Cbool._dtor)
  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Cbool.finalize)
    // Insert-Code-Here {Args.Cbool.finalize} (finalize)
    // DO-NOT-DELETE splicer.end(Args.Cbool.finalize)
  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  returnback[]
   */
  public boolean returnback_Impl () 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cbool.returnback)
    // insert implementation here
    return true;
    // DO-NOT-DELETE splicer.end(Args.Cbool.returnback)
  }

  /**
   * Method:  passin[]
   */
  public boolean passin_Impl (
    /*in*/ boolean b ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cbool.passin)
    // insert implementation here
    return b;
    // DO-NOT-DELETE splicer.end(Args.Cbool.passin)
  }

  /**
   * Method:  passout[]
   */
  public boolean passout_Impl (
    /*out*/ sidl.Boolean.Holder b ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cbool.passout)
    // insert implementation here
      b.set(true);
      return b.get();
    // DO-NOT-DELETE splicer.end(Args.Cbool.passout)
  }

  /**
   * Method:  passinout[]
   */
  public boolean passinout_Impl (
    /*inout*/ sidl.Boolean.Holder b ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cbool.passinout)
    // insert implementation here
      b.set(false);
      return !b.get();
    // DO-NOT-DELETE splicer.end(Args.Cbool.passinout)
  }

  /**
   * Method:  passeverywhere[]
   */
  public boolean passeverywhere_Impl (
    /*in*/ boolean b1,
    /*out*/ sidl.Boolean.Holder b2,
    /*inout*/ sidl.Boolean.Holder b3 ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cbool.passeverywhere)
    // insert implementation here
      b2.set(true);
      b3.set(true);
    return b1;
    // DO-NOT-DELETE splicer.end(Args.Cbool.passeverywhere)
  }


  // DO-NOT-DELETE splicer.begin(Args.Cbool._misc)
  // Put miscellaneous code here
  // DO-NOT-DELETE splicer.end(Args.Cbool._misc)

} // end class Cbool

/**
 * ================= BEGIN UNREFERENCED METHOD(S) ================
 * The following code segment(s) belong to unreferenced method(s).
 * This can result from a method rename/removal in the sidl file.
 * Move or remove the code in order to compile cleanly.
 */
// DO-NOT-DELETE splicer.begin(Args.Cbool._inherits)
// Put additional inheritance here...
// DO-NOT-DELETE splicer.end(Args.Cbool._inherits)
// ================== END UNREFERENCED METHOD(S) =================
