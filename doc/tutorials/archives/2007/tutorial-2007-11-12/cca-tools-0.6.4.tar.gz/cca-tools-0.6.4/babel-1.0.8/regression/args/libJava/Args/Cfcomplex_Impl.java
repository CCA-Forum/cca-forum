/*
 * File:          Cfcomplex_Impl.java
 * Symbol:        Args.Cfcomplex-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cfcomplex
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package Args;

import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;

// DO-NOT-DELETE splicer.begin(Args.Cfcomplex._imports)
// Put additional imports here...
// DO-NOT-DELETE splicer.end(Args.Cfcomplex._imports)

/**
 * Symbol "Args.Cfcomplex" (version 1.0)
 */
public class Cfcomplex_Impl extends Cfcomplex
{

  // DO-NOT-DELETE splicer.begin(Args.Cfcomplex._data)
  // Put additional private data here...
  // DO-NOT-DELETE splicer.end(Args.Cfcomplex._data)

  static { 
  // DO-NOT-DELETE splicer.begin(Args.Cfcomplex._load)
  // Put load function implementation here...
  // DO-NOT-DELETE splicer.end(Args.Cfcomplex._load)
  }

  /**
   * User defined constructor
   */
  public Cfcomplex_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(Args.Cfcomplex.Cfcomplex)
    // add construction details here
    // DO-NOT-DELETE splicer.end(Args.Cfcomplex.Cfcomplex)
  }

  /**
   * Back door constructor
   */
  public Cfcomplex_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(Args.Cfcomplex._wrap)
    // Insert-Code-Here {Args.Cfcomplex._wrap} (_wrap)
    // DO-NOT-DELETE splicer.end(Args.Cfcomplex._wrap)
  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Cfcomplex._dtor)
    // add destruction details here
    // DO-NOT-DELETE splicer.end(Args.Cfcomplex._dtor)
  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Cfcomplex.finalize)
    // Insert-Code-Here {Args.Cfcomplex.finalize} (finalize)
    // DO-NOT-DELETE splicer.end(Args.Cfcomplex.finalize)
  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  returnback[]
   */
  public sidl.FloatComplex returnback_Impl () 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cfcomplex.returnback)
    // insert implementation here
    return new sidl.FloatComplex(3.1f,3.1f);
    // DO-NOT-DELETE splicer.end(Args.Cfcomplex.returnback)
  }

  /**
   * Method:  passin[]
   */
  public boolean passin_Impl (
    /*in*/ sidl.FloatComplex c ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cfcomplex.passin)
    // insert implementation here
      float real = sidl.FloatComplex.real(c);
      float imag = sidl.FloatComplex.imag(c);
      System.out.println("Number is: " +real + " + " + imag + "i");
      if(real == 3.1f && imag == 3.1f) {
	  return true;
      }
      else 
	  return false;
    // DO-NOT-DELETE splicer.end(Args.Cfcomplex.passin)
  }

  /**
   * Method:  passout[]
   */
  public boolean passout_Impl (
    /*out*/ sidl.FloatComplex.Holder c ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cfcomplex.passout)
    // insert implementation here
      if(c != null){
        c.set(new sidl.FloatComplex(3.1f,3.1f));
        c.get().set(3.1f,3.1f);
        return true;
      
      }
      else
	  return false;
    // DO-NOT-DELETE splicer.end(Args.Cfcomplex.passout)
  }

  /**
   * Method:  passinout[]
   */
  public boolean passinout_Impl (
    /*inout*/ sidl.FloatComplex.Holder c ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cfcomplex.passinout)
    // insert implementation here
      if(c != null){
	  c.get().set(c.get().real(),-c.get().imag());
	  return true;
      }
      else
	  return false;
    // DO-NOT-DELETE splicer.end(Args.Cfcomplex.passinout)
  }

  /**
   * Method:  passeverywhere[]
   */
  public sidl.FloatComplex passeverywhere_Impl (
    /*in*/ sidl.FloatComplex c1,
    /*out*/ sidl.FloatComplex.Holder c2,
    /*inout*/ sidl.FloatComplex.Holder c3 ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cfcomplex.passeverywhere)
    // insert implementation here
    
    c2.set(new sidl.FloatComplex(0.0f, 0.0f));
    if(c3 == null)
      return null;
    c3.get().set(c3.get().real(),-c3.get().imag());
    c2.get().set(3.1f,3.1f); 
    
    if(c1.real() == 3.1f && c1.imag() == 3.1f)
      return new sidl.FloatComplex(3.1f,3.1f);
    else 
      return null;
    // DO-NOT-DELETE splicer.end(Args.Cfcomplex.passeverywhere)
  }


  // DO-NOT-DELETE splicer.begin(Args.Cfcomplex._misc)
  // Put miscellaneous code here
  // DO-NOT-DELETE splicer.end(Args.Cfcomplex._misc)

} // end class Cfcomplex

/**
 * ================= BEGIN UNREFERENCED METHOD(S) ================
 * The following code segment(s) belong to unreferenced method(s).
 * This can result from a method rename/removal in the sidl file.
 * Move or remove the code in order to compile cleanly.
 */
// DO-NOT-DELETE splicer.begin(Args.Cfcomplex._inherits)
// Put additional inheritance here...
// DO-NOT-DELETE splicer.end(Args.Cfcomplex._inherits)
// ================== END UNREFERENCED METHOD(S) =================
