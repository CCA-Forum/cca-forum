#
# File:          Cint_Impl.py
# Symbol:        Args.Cint-v1.0
# Symbol Type:   class
# Babel Version: 1.0.8
# Description:   Implementation of sidl class Args.Cint in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
#


# DO-NOT-DELETE splicer.begin(_initial)
# Put your code here...
# DO-NOT-DELETE splicer.end(_initial)

import Args.Cint
import sidl.BaseClass
import sidl.BaseInterface
import sidl.ClassInfo
import sidl.RuntimeException
import sidl.NotImplementedException

# DO-NOT-DELETE splicer.begin(_before_type)
# Put your code here...
# DO-NOT-DELETE splicer.end(_before_type)

class Cint:

# All calls to sidl methods should use __IORself

# Normal Babel creation pases in an IORself. If IORself == None
# that means this Impl class is being constructed for native delegation
  def __init__(self, IORself = None):
    if (IORself == None):
      self.__IORself = Args.Cint.Cint(impl = self)
    else:
      self.__IORself = IORself
    # DO-NOT-DELETE splicer.begin(__init__)
    # Put your code here...
    # DO-NOT-DELETE splicer.end(__init__)

# Returns the IORself (client stub) of the Impl, mainly for use
# with native delegation
  def _getStub(self):
    return self.__IORself

  def returnback(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # int _return
    #

    # DO-NOT-DELETE splicer.begin(returnback)
    return 3
    # DO-NOT-DELETE splicer.end(returnback)

  def passin(self, i):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # int i
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # bool _return
    #

    # DO-NOT-DELETE splicer.begin(passin)
    return i == 3
    # DO-NOT-DELETE splicer.end(passin)

  def passout(self):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # (_return, i)
    # bool _return
    # int i
    #

    # DO-NOT-DELETE splicer.begin(passout)
    return (1, 3)
    # DO-NOT-DELETE splicer.end(passout)

  def passinout(self, i):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # int i
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # (_return, i)
    # bool _return
    # int i
    #

    # DO-NOT-DELETE splicer.begin(passinout)
    return (1, -i)
    # DO-NOT-DELETE splicer.end(passinout)

  def passeverywhere(self, i1, i3):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # int i1
    # int i3
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # (_return, i2, i3)
    # int _return
    # int i2
    # int i3
    #

    # DO-NOT-DELETE splicer.begin(passeverywhere)
    if (i1 == 3):
      retval = 3
    else:
      retval = 0
    return (retval, 3, -i3)
    # DO-NOT-DELETE splicer.end(passeverywhere)

# DO-NOT-DELETE splicer.begin(_final)
# Put your code here...
# DO-NOT-DELETE splicer.end(_final)
