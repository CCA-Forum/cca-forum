// 
// File:          Args_Clong_Impl.hxx
// Symbol:        Args.Clong-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Clong
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_Args_Clong_Impl_hxx
#define included_Args_Clong_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_Args_Clong_IOR_h
#include "Args_Clong_IOR.h"
#endif
#ifndef included_Args_Clong_hxx
#include "Args_Clong.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(Args.Clong._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Clong._includes)

namespace Args { 

  /**
   * Symbol "Args.Clong" (version 1.0)
   */
  class Clong_impl : public virtual ::Args::Clong 
  // DO-NOT-DELETE splicer.begin(Args.Clong._inherits)
  // Put additional inheritance here...
  // DO-NOT-DELETE splicer.end(Args.Clong._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(Args.Clong._implementation)
    // Put additional implementation details here...
    // DO-NOT-DELETE splicer.end(Args.Clong._implementation)

  public:
    // default constructor, used for data wrapping(required)
    Clong_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    Clong_impl( struct Args_Clong__object * s ) : StubBase(s,true), _wrapped(
      false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~Clong_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    int64_t
    returnback_impl() ;
    /**
     * user defined non-static method.
     */
    bool
    passin_impl (
      /* in */int64_t l
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passout_impl (
      /* out */int64_t& l
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passinout_impl (
      /* inout */int64_t& l
    )
    ;

    /**
     * user defined non-static method.
     */
    int64_t
    passeverywhere_impl (
      /* in */int64_t l1,
      /* out */int64_t& l2,
      /* inout */int64_t& l3
    )
    ;

  };  // end class Clong_impl

} // end namespace Args

// DO-NOT-DELETE splicer.begin(Args.Clong._misc)
// Put miscellaneous things here...
// DO-NOT-DELETE splicer.end(Args.Clong._misc)

#endif
