/*
 * File:          Args_Cfloat_Impl.c
 * Symbol:        Args.Cfloat-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cfloat
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "Args.Cfloat" (version 1.0)
 */

#include "Args_Cfloat_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"

/* DO-NOT-DELETE splicer.begin(Args.Cfloat._includes) */
/* Put additional includes or other arbitrary code here... */
/* DO-NOT-DELETE splicer.end(Args.Cfloat._includes) */

#define SIDL_IOR_MAJOR_VERSION 1
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfloat__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cfloat__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfloat._load) */
  /* Insert the implementation of the static class initializer method here... */
  /* DO-NOT-DELETE splicer.end(Args.Cfloat._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfloat__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cfloat__ctor(
  /* in */ Args_Cfloat self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfloat._ctor) */
  /* Insert the implementation of the constructor method here... */
  /* DO-NOT-DELETE splicer.end(Args.Cfloat._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfloat__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cfloat__ctor2(
  /* in */ Args_Cfloat self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfloat._ctor2) */
  /* Insert-Code-Here {Args.Cfloat._ctor2} (special constructor method) */
  /* DO-NOT-DELETE splicer.end(Args.Cfloat._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfloat__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cfloat__dtor(
  /* in */ Args_Cfloat self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfloat._dtor) */
  /* Insert the implementation of the constructor method here... */
  /* DO-NOT-DELETE splicer.end(Args.Cfloat._dtor) */
  }
}

/*
 * Method:  returnback[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfloat_returnback"

#ifdef __cplusplus
extern "C"
#endif
float
impl_Args_Cfloat_returnback(
  /* in */ Args_Cfloat self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfloat.returnback) */
  return 3.1F;
  /* DO-NOT-DELETE splicer.end(Args.Cfloat.returnback) */
  }
}

/*
 * Method:  passin[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfloat_passin"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cfloat_passin(
  /* in */ Args_Cfloat self,
  /* in */ float f,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfloat.passin) */
  return (3.1F == f);
  /* DO-NOT-DELETE splicer.end(Args.Cfloat.passin) */
  }
}

/*
 * Method:  passout[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfloat_passout"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cfloat_passout(
  /* in */ Args_Cfloat self,
  /* out */ float* f,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfloat.passout) */
  *f = 3.1F;
  return TRUE;
  /* DO-NOT-DELETE splicer.end(Args.Cfloat.passout) */
  }
}

/*
 * Method:  passinout[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfloat_passinout"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cfloat_passinout(
  /* in */ Args_Cfloat self,
  /* inout */ float* f,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfloat.passinout) */
  *f = - (*f);
  return TRUE;
  /* DO-NOT-DELETE splicer.end(Args.Cfloat.passinout) */
  }
}

/*
 * Method:  passeverywhere[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cfloat_passeverywhere"

#ifdef __cplusplus
extern "C"
#endif
float
impl_Args_Cfloat_passeverywhere(
  /* in */ Args_Cfloat self,
  /* in */ float f1,
  /* out */ float* f2,
  /* inout */ float* f3,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cfloat.passeverywhere) */
  *f2 = 3.1F;
  *f3 = -(*f3);
  return (3.1F == f1) ? 3.1F : 0.0F;
  /* DO-NOT-DELETE splicer.end(Args.Cfloat.passeverywhere) */
  }
}
/* Babel internal methods, Users should not edit below this line. */
struct Args_Cfloat__object* impl_Args_Cfloat_fconnect_Args_Cfloat(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return Args_Cfloat__connectI(url, ar, _ex);
}
struct Args_Cfloat__object* impl_Args_Cfloat_fcast_Args_Cfloat(void* bi, 
  sidl_BaseInterface* _ex) {
  return Args_Cfloat__cast(bi, _ex);
}
struct sidl_BaseClass__object* impl_Args_Cfloat_fconnect_sidl_BaseClass(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connectI(url, ar, _ex);
}
struct sidl_BaseClass__object* impl_Args_Cfloat_fcast_sidl_BaseClass(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_BaseClass__cast(bi, _ex);
}
struct sidl_BaseInterface__object* impl_Args_Cfloat_fconnect_sidl_BaseInterface(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connectI(url, ar, _ex);
}
struct sidl_BaseInterface__object* impl_Args_Cfloat_fcast_sidl_BaseInterface(
  void* bi, sidl_BaseInterface* _ex) {
  return sidl_BaseInterface__cast(bi, _ex);
}
struct sidl_ClassInfo__object* impl_Args_Cfloat_fconnect_sidl_ClassInfo(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connectI(url, ar, _ex);
}
struct sidl_ClassInfo__object* impl_Args_Cfloat_fcast_sidl_ClassInfo(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_ClassInfo__cast(bi, _ex);
}
struct sidl_RuntimeException__object* 
  impl_Args_Cfloat_fconnect_sidl_RuntimeException(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex) {
  return sidl_RuntimeException__connectI(url, ar, _ex);
}
struct sidl_RuntimeException__object* 
  impl_Args_Cfloat_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex) {
  return sidl_RuntimeException__cast(bi, _ex);
}
