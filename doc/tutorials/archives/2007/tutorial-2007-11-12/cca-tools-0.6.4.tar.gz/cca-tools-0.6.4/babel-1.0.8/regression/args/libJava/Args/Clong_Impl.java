/*
 * File:          Clong_Impl.java
 * Symbol:        Args.Clong-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Clong
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package Args;

import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;

// DO-NOT-DELETE splicer.begin(Args.Clong._imports)
// Put additional imports here...
// DO-NOT-DELETE splicer.end(Args.Clong._imports)

/**
 * Symbol "Args.Clong" (version 1.0)
 */
public class Clong_Impl extends Clong
{

  // DO-NOT-DELETE splicer.begin(Args.Clong._data)
  // Put additional private data here...
  // DO-NOT-DELETE splicer.end(Args.Clong._data)

  static { 
  // DO-NOT-DELETE splicer.begin(Args.Clong._load)
  // Put load function implementation here...
  // DO-NOT-DELETE splicer.end(Args.Clong._load)
  }

  /**
   * User defined constructor
   */
  public Clong_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(Args.Clong.Clong)
    // add construction details here
    // DO-NOT-DELETE splicer.end(Args.Clong.Clong)
  }

  /**
   * Back door constructor
   */
  public Clong_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(Args.Clong._wrap)
    // Insert-Code-Here {Args.Clong._wrap} (_wrap)
    // DO-NOT-DELETE splicer.end(Args.Clong._wrap)
  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Clong._dtor)
    // add destruction details here
    // DO-NOT-DELETE splicer.end(Args.Clong._dtor)
  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Clong.finalize)
    // Insert-Code-Here {Args.Clong.finalize} (finalize)
    // DO-NOT-DELETE splicer.end(Args.Clong.finalize)
  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  returnback[]
   */
  public long returnback_Impl () 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Clong.returnback)
    // insert implementation here
    return 3;
    // DO-NOT-DELETE splicer.end(Args.Clong.returnback)
  }

  /**
   * Method:  passin[]
   */
  public boolean passin_Impl (
    /*in*/ long l ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Clong.passin)
    // insert implementation here
      if (l == 3)
	  return true;
      else 
	  return false;
    // DO-NOT-DELETE splicer.end(Args.Clong.passin)
  }

  /**
   * Method:  passout[]
   */
  public boolean passout_Impl (
    /*out*/ sidl.Long.Holder l ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Clong.passout)
    // insert implementation here
       if (l != null) {
	  l.set(3);
	  return true;
      }
      else {
	  return false;
      }

    // DO-NOT-DELETE splicer.end(Args.Clong.passout)
  }

  /**
   * Method:  passinout[]
   */
  public boolean passinout_Impl (
    /*inout*/ sidl.Long.Holder l ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Clong.passinout)
    // insert implementation here
       if (l != null){
	  l.set(-l.get());
	  return true;
      }
      else {
	  return false;
      }
    // DO-NOT-DELETE splicer.end(Args.Clong.passinout)
  }

  /**
   * Method:  passeverywhere[]
   */
  public long passeverywhere_Impl (
    /*in*/ long l1,
    /*out*/ sidl.Long.Holder l2,
    /*inout*/ sidl.Long.Holder l3 ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Clong.passeverywhere)
    // insert implementation here
       l2.set(0);
      if(l3 == null)
	  return 0;
      l3.set(-l3.get());
      l2.set(3);
      if(l1 == 3)
	  return 3;
      else
	  return 0;
 
    // DO-NOT-DELETE splicer.end(Args.Clong.passeverywhere)
  }


  // DO-NOT-DELETE splicer.begin(Args.Clong._misc)
  // Put miscellaneous code here
  // DO-NOT-DELETE splicer.end(Args.Clong._misc)

} // end class Clong

/**
 * ================= BEGIN UNREFERENCED METHOD(S) ================
 * The following code segment(s) belong to unreferenced method(s).
 * This can result from a method rename/removal in the sidl file.
 * Move or remove the code in order to compile cleanly.
 */
// DO-NOT-DELETE splicer.begin(Args.Clong._inherits)
// Put additional inheritance here...
// DO-NOT-DELETE splicer.end(Args.Clong._inherits)
// ================== END UNREFERENCED METHOD(S) =================
