/*
 * File:          Cint_Impl.java
 * Symbol:        Args.Cint-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cint
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package Args;

import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;

// DO-NOT-DELETE splicer.begin(Args.Cint._imports)
// Put additional imports here...
// DO-NOT-DELETE splicer.end(Args.Cint._imports)

/**
 * Symbol "Args.Cint" (version 1.0)
 */
public class Cint_Impl extends Cint
{

  // DO-NOT-DELETE splicer.begin(Args.Cint._data)
  // Put additional private data here...
  // DO-NOT-DELETE splicer.end(Args.Cint._data)

  static { 
  // DO-NOT-DELETE splicer.begin(Args.Cint._load)
  // Put load function implementation here...
  // DO-NOT-DELETE splicer.end(Args.Cint._load)
  }

  /**
   * User defined constructor
   */
  public Cint_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(Args.Cint.Cint)
    // add construction details here
    // DO-NOT-DELETE splicer.end(Args.Cint.Cint)
  }

  /**
   * Back door constructor
   */
  public Cint_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(Args.Cint._wrap)
    // Insert-Code-Here {Args.Cint._wrap} (_wrap)
    // DO-NOT-DELETE splicer.end(Args.Cint._wrap)
  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Cint._dtor)
    // add destruction details here
    // DO-NOT-DELETE splicer.end(Args.Cint._dtor)
  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(Args.Cint.finalize)
    // Insert-Code-Here {Args.Cint.finalize} (finalize)
    // DO-NOT-DELETE splicer.end(Args.Cint.finalize)
  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  returnback[]
   */
  public int returnback_Impl () 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cint.returnback)
    // insert implementation here
    return 3;
    // DO-NOT-DELETE splicer.end(Args.Cint.returnback)
  }

  /**
   * Method:  passin[]
   */
  public boolean passin_Impl (
    /*in*/ int i ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cint.passin)
    // insert implementation here
      if (i == 3)
	  return true;
      else 
	  return false;
    // DO-NOT-DELETE splicer.end(Args.Cint.passin)
  }

  /**
   * Method:  passout[]
   */
  public boolean passout_Impl (
    /*out*/ sidl.Integer.Holder i ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cint.passout)
    // insert implementation here
      if (i != null) {
	  i.set(3);
	  return true;
      }
      else {
	  return false;
      }
    // DO-NOT-DELETE splicer.end(Args.Cint.passout)
  }

  /**
   * Method:  passinout[]
   */
  public boolean passinout_Impl (
    /*inout*/ sidl.Integer.Holder i ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cint.passinout)
    // insert implementation here
      if (i != null){
	  i.set(-i.get());
	  return true;
      }
      else {
	  return false;
      }
    // DO-NOT-DELETE splicer.end(Args.Cint.passinout)
  }

  /**
   * Method:  passeverywhere[]
   */
  public int passeverywhere_Impl (
    /*in*/ int i1,
    /*out*/ sidl.Integer.Holder i2,
    /*inout*/ sidl.Integer.Holder i3 ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(Args.Cint.passeverywhere)
    // insert implementation here
      i2.set(0);
      if(i3 == null)
	  return 0;
      i3.set(-i3.get());
      i2.set(3);
      if(i1 == 3)
	  return 3;
      else
	  return 0;
    // DO-NOT-DELETE splicer.end(Args.Cint.passeverywhere)
  }


  // DO-NOT-DELETE splicer.begin(Args.Cint._misc)
  // Put miscellaneous code here
  // DO-NOT-DELETE splicer.end(Args.Cint._misc)

} // end class Cint

/**
 * ================= BEGIN UNREFERENCED METHOD(S) ================
 * The following code segment(s) belong to unreferenced method(s).
 * This can result from a method rename/removal in the sidl file.
 * Move or remove the code in order to compile cleanly.
 */
// DO-NOT-DELETE splicer.begin(Args.Cint._inherits)
// Put additional inheritance here...
// DO-NOT-DELETE splicer.end(Args.Cint._inherits)
// ================== END UNREFERENCED METHOD(S) =================
