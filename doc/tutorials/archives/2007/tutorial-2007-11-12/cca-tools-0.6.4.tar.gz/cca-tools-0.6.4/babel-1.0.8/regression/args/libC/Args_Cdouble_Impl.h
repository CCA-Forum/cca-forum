/*
 * File:          Args_Cdouble_Impl.h
 * Symbol:        Args.Cdouble-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cdouble
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_Args_Cdouble_Impl_h
#define included_Args_Cdouble_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_Args_Cdouble_h
#include "Args_Cdouble.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif

/* DO-NOT-DELETE splicer.begin(Args.Cdouble._includes) */
/* Put additional include files here... */
/* DO-NOT-DELETE splicer.end(Args.Cdouble._includes) */

/*
 * Private data for class Args.Cdouble
 */

struct Args_Cdouble__data {
  /* DO-NOT-DELETE splicer.begin(Args.Cdouble._data) */
  /* Put private data members here... */
  int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(Args.Cdouble._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct Args_Cdouble__data*
Args_Cdouble__get_data(
  Args_Cdouble);

extern void
Args_Cdouble__set_data(
  Args_Cdouble,
  struct Args_Cdouble__data*);

extern
void
impl_Args_Cdouble__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cdouble__ctor(
  /* in */ Args_Cdouble self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cdouble__ctor2(
  /* in */ Args_Cdouble self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_Args_Cdouble__dtor(
  /* in */ Args_Cdouble self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct Args_Cdouble__object* impl_Args_Cdouble_fconnect_Args_Cdouble(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct Args_Cdouble__object* impl_Args_Cdouble_fcast_Args_Cdouble(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* impl_Args_Cdouble_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_Args_Cdouble_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cdouble_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cdouble_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_Args_Cdouble_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_Args_Cdouble_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cdouble_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cdouble_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
extern
double
impl_Args_Cdouble_returnback(
  /* in */ Args_Cdouble self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cdouble_passin(
  /* in */ Args_Cdouble self,
  /* in */ double d,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cdouble_passout(
  /* in */ Args_Cdouble self,
  /* out */ double* d,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_Args_Cdouble_passinout(
  /* in */ Args_Cdouble self,
  /* inout */ double* d,
  /* out */ sidl_BaseInterface *_ex);

extern
double
impl_Args_Cdouble_passeverywhere(
  /* in */ Args_Cdouble self,
  /* in */ double d1,
  /* out */ double* d2,
  /* inout */ double* d3,
  /* out */ sidl_BaseInterface *_ex);

extern struct Args_Cdouble__object* impl_Args_Cdouble_fconnect_Args_Cdouble(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct Args_Cdouble__object* impl_Args_Cdouble_fcast_Args_Cdouble(void* 
  bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* impl_Args_Cdouble_fconnect_sidl_BaseClass(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_Args_Cdouble_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cdouble_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_Args_Cdouble_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* impl_Args_Cdouble_fconnect_sidl_ClassInfo(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_Args_Cdouble_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cdouble_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_Args_Cdouble_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
#ifdef __cplusplus
}
#endif
#endif
