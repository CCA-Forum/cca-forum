// 
// File:          Args_Cfloat_Impl.cxx
// Symbol:        Args.Cfloat-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Cfloat
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "Args_Cfloat_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(Args.Cfloat._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Cfloat._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
Args::Cfloat_impl::Cfloat_impl() : StubBase(reinterpret_cast< void*>(
  ::Args::Cfloat::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(Args.Cfloat._ctor2)
  // Insert-Code-Here {Args.Cfloat._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(Args.Cfloat._ctor2)
}

// user defined constructor
void Args::Cfloat_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(Args.Cfloat._ctor)
  // add construction details here
  // DO-NOT-DELETE splicer.end(Args.Cfloat._ctor)
}

// user defined destructor
void Args::Cfloat_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(Args.Cfloat._dtor)
  // add destruction details here
  // DO-NOT-DELETE splicer.end(Args.Cfloat._dtor)
}

// static class initializer
void Args::Cfloat_impl::_load() {
  // DO-NOT-DELETE splicer.begin(Args.Cfloat._load)
  // guaranteed to be called at most once before any other method in this class
  // DO-NOT-DELETE splicer.end(Args.Cfloat._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  returnback[]
 */
float
Args::Cfloat_impl::returnback_impl () 

{
  // DO-NOT-DELETE splicer.begin(Args.Cfloat.returnback)
  return 3.1F;
  // DO-NOT-DELETE splicer.end(Args.Cfloat.returnback)
}

/**
 * Method:  passin[]
 */
bool
Args::Cfloat_impl::passin_impl (
  /* in */float f ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cfloat.passin)
   return ( f == 3.1F );
  // DO-NOT-DELETE splicer.end(Args.Cfloat.passin)
}

/**
 * Method:  passout[]
 */
bool
Args::Cfloat_impl::passout_impl (
  /* out */float& f ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cfloat.passout)
  f = 3.1F;
  return true;
  // DO-NOT-DELETE splicer.end(Args.Cfloat.passout)
}

/**
 * Method:  passinout[]
 */
bool
Args::Cfloat_impl::passinout_impl (
  /* inout */float& f ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cfloat.passinout)
  f = -f;
  return true;
  // DO-NOT-DELETE splicer.end(Args.Cfloat.passinout)
}

/**
 * Method:  passeverywhere[]
 */
float
Args::Cfloat_impl::passeverywhere_impl (
  /* in */float f1,
  /* out */float& f2,
  /* inout */float& f3 ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cfloat.passeverywhere)
  f2 = 3.1F;
  f3 = -f3;
  return ( f1 == 3.1F ) ? 3.1F : 0.0;
  // DO-NOT-DELETE splicer.end(Args.Cfloat.passeverywhere)
}


// DO-NOT-DELETE splicer.begin(Args.Cfloat._misc)
// Put miscellaneous code here
// DO-NOT-DELETE splicer.end(Args.Cfloat._misc)

