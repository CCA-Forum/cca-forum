// 
// File:          Args_Cdouble_Impl.hxx
// Symbol:        Args.Cdouble-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Cdouble
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_Args_Cdouble_Impl_hxx
#define included_Args_Cdouble_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_Args_Cdouble_IOR_h
#include "Args_Cdouble_IOR.h"
#endif
#ifndef included_Args_Cdouble_hxx
#include "Args_Cdouble.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(Args.Cdouble._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Cdouble._includes)

namespace Args { 

  /**
   * Symbol "Args.Cdouble" (version 1.0)
   */
  class Cdouble_impl : public virtual ::Args::Cdouble 
  // DO-NOT-DELETE splicer.begin(Args.Cdouble._inherits)
  // Put additional inheritance here...
  // DO-NOT-DELETE splicer.end(Args.Cdouble._inherits)
  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(Args.Cdouble._implementation)
    // Put additional implementation details here...
    // DO-NOT-DELETE splicer.end(Args.Cdouble._implementation)

  public:
    // default constructor, used for data wrapping(required)
    Cdouble_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    Cdouble_impl( struct Args_Cdouble__object * s ) : StubBase(s,true), 
      _wrapped(false) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~Cdouble_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    double
    returnback_impl() ;
    /**
     * user defined non-static method.
     */
    bool
    passin_impl (
      /* in */double d
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passout_impl (
      /* out */double& d
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    passinout_impl (
      /* inout */double& d
    )
    ;

    /**
     * user defined non-static method.
     */
    double
    passeverywhere_impl (
      /* in */double d1,
      /* out */double& d2,
      /* inout */double& d3
    )
    ;

  };  // end class Cdouble_impl

} // end namespace Args

// DO-NOT-DELETE splicer.begin(Args.Cdouble._misc)
// Put miscellaneous things here...
// DO-NOT-DELETE splicer.end(Args.Cdouble._misc)

#endif
