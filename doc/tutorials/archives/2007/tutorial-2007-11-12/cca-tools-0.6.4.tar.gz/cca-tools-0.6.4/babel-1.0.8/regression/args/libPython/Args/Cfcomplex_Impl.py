#
# File:          Cfcomplex_Impl.py
# Symbol:        Args.Cfcomplex-v1.0
# Symbol Type:   class
# Babel Version: 1.0.8
# Description:   Implementation of sidl class Args.Cfcomplex in Python.
# 
# WARNING: Automatically generated; changes will be lost
# 
#


# DO-NOT-DELETE splicer.begin(_initial)
# Put your code here...
# DO-NOT-DELETE splicer.end(_initial)

import Args.Cfcomplex
import sidl.BaseClass
import sidl.BaseInterface
import sidl.ClassInfo
import sidl.RuntimeException
import sidl.NotImplementedException

# DO-NOT-DELETE splicer.begin(_before_type)
import Numeric
def toFloat(d):
  tmp = Numeric.zeros((1,), Numeric.Float32)
  try:
    tmp.savespace(1)
    tmp[0] = d
  except AttributeError:
    # don't die!
    tmp[0] = d
  result = tmp[0]
  if type(result) == Numeric.arraytype:
    result = result.toscalar()
  return result
# DO-NOT-DELETE splicer.end(_before_type)

class Cfcomplex:

# All calls to sidl methods should use __IORself

# Normal Babel creation pases in an IORself. If IORself == None
# that means this Impl class is being constructed for native delegation
  def __init__(self, IORself = None):
    if (IORself == None):
      self.__IORself = Args.Cfcomplex.Cfcomplex(impl = self)
    else:
      self.__IORself = IORself
    # DO-NOT-DELETE splicer.begin(__init__)
    # Put your code here...
    # DO-NOT-DELETE splicer.end(__init__)

# Returns the IORself (client stub) of the Impl, mainly for use
# with native delegation
  def _getStub(self):
    return self.__IORself

  def returnback(self):
    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # fcomplex _return
    #

    # DO-NOT-DELETE splicer.begin(returnback)
    return 3.1 + 3.1j
    # DO-NOT-DELETE splicer.end(returnback)

  def passin(self, c):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # fcomplex c
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # bool _return
    #

    # DO-NOT-DELETE splicer.begin(passin)
    return c == (toFloat(3.1) + toFloat(3.1) * 1j)
    # DO-NOT-DELETE splicer.end(passin)

  def passout(self):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # (_return, c)
    # bool _return
    # fcomplex c
    #

    # DO-NOT-DELETE splicer.begin(passout)
    return (1, 3.1 + 3.1j)
    # DO-NOT-DELETE splicer.end(passout)

  def passinout(self, c):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # fcomplex c
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # (_return, c)
    # bool _return
    # fcomplex c
    #

    # DO-NOT-DELETE splicer.begin(passinout)
    c = c.real - 1j*c.imag
    return (1, c)
    # DO-NOT-DELETE splicer.end(passinout)

  def passeverywhere(self, c1, c3):
    #
    # sidl EXPECTED INCOMING TYPES
    # ============================
    # fcomplex c1
    # fcomplex c3
    #

    #
    # sidl EXPECTED RETURN VALUE(s)
    # =============================
    # (_return, c2, c3)
    # fcomplex _return
    # fcomplex c2
    # fcomplex c3
    #

    # DO-NOT-DELETE splicer.begin(passeverywhere)
    c3 = c3.real - 1j*c3.imag
    if (c1 == (toFloat(3.1) + toFloat(3.1) * 1j)):
      return (c1, (3.1 + 3.1j), c3)
    else:
      return (0+0j, (3.1 + 3.1j), c3)
    # DO-NOT-DELETE splicer.end(passeverywhere)

# DO-NOT-DELETE splicer.begin(_final)
# Put your code here...
# DO-NOT-DELETE splicer.end(_final)
