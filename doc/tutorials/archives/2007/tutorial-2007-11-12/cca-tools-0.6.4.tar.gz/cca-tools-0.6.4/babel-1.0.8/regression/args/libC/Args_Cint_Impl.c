/*
 * File:          Args_Cint_Impl.c
 * Symbol:        Args.Cint-v1.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for Args.Cint
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "Args.Cint" (version 1.0)
 */

#include "Args_Cint_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"

/* DO-NOT-DELETE splicer.begin(Args.Cint._includes) */
/* Put additional includes or other arbitrary code here... */
/* DO-NOT-DELETE splicer.end(Args.Cint._includes) */

#define SIDL_IOR_MAJOR_VERSION 1
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cint__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cint__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cint._load) */
  /* Insert the implementation of the static class initializer method here... */
  /* DO-NOT-DELETE splicer.end(Args.Cint._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cint__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cint__ctor(
  /* in */ Args_Cint self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cint._ctor) */
  /* Insert the implementation of the constructor method here... */
  /* DO-NOT-DELETE splicer.end(Args.Cint._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cint__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cint__ctor2(
  /* in */ Args_Cint self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cint._ctor2) */
  /* Insert-Code-Here {Args.Cint._ctor2} (special constructor method) */
  /* DO-NOT-DELETE splicer.end(Args.Cint._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cint__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_Args_Cint__dtor(
  /* in */ Args_Cint self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cint._dtor) */
  /* Insert the implementation of the constructor method here... */
  /* DO-NOT-DELETE splicer.end(Args.Cint._dtor) */
  }
}

/*
 * Method:  returnback[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cint_returnback"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_Args_Cint_returnback(
  /* in */ Args_Cint self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cint.returnback) */
  return 3;
  /* DO-NOT-DELETE splicer.end(Args.Cint.returnback) */
  }
}

/*
 * Method:  passin[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cint_passin"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cint_passin(
  /* in */ Args_Cint self,
  /* in */ int32_t i,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cint.passin) */
  return (i == 3);
  /* DO-NOT-DELETE splicer.end(Args.Cint.passin) */
  }
}

/*
 * Method:  passout[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cint_passout"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cint_passout(
  /* in */ Args_Cint self,
  /* out */ int32_t* i,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cint.passout) */
  *i = 3;
  return TRUE;
  /* DO-NOT-DELETE splicer.end(Args.Cint.passout) */
  }
}

/*
 * Method:  passinout[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cint_passinout"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_Args_Cint_passinout(
  /* in */ Args_Cint self,
  /* inout */ int32_t* i,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cint.passinout) */
  *i = -(*i);
  return TRUE;
  /* DO-NOT-DELETE splicer.end(Args.Cint.passinout) */
  }
}

/*
 * Method:  passeverywhere[]
 */

#undef __FUNC__
#define __FUNC__ "impl_Args_Cint_passeverywhere"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_Args_Cint_passeverywhere(
  /* in */ Args_Cint self,
  /* in */ int32_t i1,
  /* out */ int32_t* i2,
  /* inout */ int32_t* i3,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(Args.Cint.passeverywhere) */
  *i2 = 3;
  *i3 = -(*i3);
  return (i1 == 3) ? 3 : 0;
  /* DO-NOT-DELETE splicer.end(Args.Cint.passeverywhere) */
  }
}
/* Babel internal methods, Users should not edit below this line. */
struct Args_Cint__object* impl_Args_Cint_fconnect_Args_Cint(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) {
  return Args_Cint__connectI(url, ar, _ex);
}
struct Args_Cint__object* impl_Args_Cint_fcast_Args_Cint(void* bi, 
  sidl_BaseInterface* _ex) {
  return Args_Cint__cast(bi, _ex);
}
struct sidl_BaseClass__object* impl_Args_Cint_fconnect_sidl_BaseClass(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseClass__connectI(url, ar, _ex);
}
struct sidl_BaseClass__object* impl_Args_Cint_fcast_sidl_BaseClass(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_BaseClass__cast(bi, _ex);
}
struct sidl_BaseInterface__object* impl_Args_Cint_fconnect_sidl_BaseInterface(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_BaseInterface__connectI(url, ar, _ex);
}
struct sidl_BaseInterface__object* impl_Args_Cint_fcast_sidl_BaseInterface(
  void* bi, sidl_BaseInterface* _ex) {
  return sidl_BaseInterface__cast(bi, _ex);
}
struct sidl_ClassInfo__object* impl_Args_Cint_fconnect_sidl_ClassInfo(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) {
  return sidl_ClassInfo__connectI(url, ar, _ex);
}
struct sidl_ClassInfo__object* impl_Args_Cint_fcast_sidl_ClassInfo(void* bi, 
  sidl_BaseInterface* _ex) {
  return sidl_ClassInfo__cast(bi, _ex);
}
struct sidl_RuntimeException__object* 
  impl_Args_Cint_fconnect_sidl_RuntimeException(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex) {
  return sidl_RuntimeException__connectI(url, ar, _ex);
}
struct sidl_RuntimeException__object* 
  impl_Args_Cint_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* _ex) 
  {
  return sidl_RuntimeException__cast(bi, _ex);
}
