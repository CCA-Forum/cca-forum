// 
// File:          Args_Cint_Impl.cxx
// Symbol:        Args.Cint-v1.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for Args.Cint
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "Args_Cint_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(Args.Cint._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(Args.Cint._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
Args::Cint_impl::Cint_impl() : StubBase(reinterpret_cast< void*>(
  ::Args::Cint::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(Args.Cint._ctor2)
  // Insert-Code-Here {Args.Cint._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(Args.Cint._ctor2)
}

// user defined constructor
void Args::Cint_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(Args.Cint._ctor)
  // add construction details here
  // DO-NOT-DELETE splicer.end(Args.Cint._ctor)
}

// user defined destructor
void Args::Cint_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(Args.Cint._dtor)
  // add destruction details here
  // DO-NOT-DELETE splicer.end(Args.Cint._dtor)
}

// static class initializer
void Args::Cint_impl::_load() {
  // DO-NOT-DELETE splicer.begin(Args.Cint._load)
  // guaranteed to be called at most once before any other method in this class
  // DO-NOT-DELETE splicer.end(Args.Cint._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  returnback[]
 */
int32_t
Args::Cint_impl::returnback_impl () 

{
  // DO-NOT-DELETE splicer.begin(Args.Cint.returnback)
  return 3;
  // DO-NOT-DELETE splicer.end(Args.Cint.returnback)
}

/**
 * Method:  passin[]
 */
bool
Args::Cint_impl::passin_impl (
  /* in */int32_t i ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cint.passin)
  return ( i == 3 );
  // DO-NOT-DELETE splicer.end(Args.Cint.passin)
}

/**
 * Method:  passout[]
 */
bool
Args::Cint_impl::passout_impl (
  /* out */int32_t& i ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cint.passout)
  i = 3;
  return true;
  // DO-NOT-DELETE splicer.end(Args.Cint.passout)
}

/**
 * Method:  passinout[]
 */
bool
Args::Cint_impl::passinout_impl (
  /* inout */int32_t& i ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cint.passinout)
  i = -i;
  return true;
  // DO-NOT-DELETE splicer.end(Args.Cint.passinout)
}

/**
 * Method:  passeverywhere[]
 */
int32_t
Args::Cint_impl::passeverywhere_impl (
  /* in */int32_t i1,
  /* out */int32_t& i2,
  /* inout */int32_t& i3 ) 
{
  // DO-NOT-DELETE splicer.begin(Args.Cint.passeverywhere)
  i2 = 3;
  i3 = -i3;
  return ( i1 == 3 ) ? 3 : 0 ;
  // DO-NOT-DELETE splicer.end(Args.Cint.passeverywhere)
}


// DO-NOT-DELETE splicer.begin(Args.Cint._misc)
// Put miscellaneous code here
// DO-NOT-DELETE splicer.end(Args.Cint._misc)

