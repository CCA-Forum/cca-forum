#include "receive_C.h"

int main(int argc, char* argv[])
{
  long err;
  long i = 33;

  CH_INIT_RECEIVE();

  RECEIVE_RECV_INT(&i, &err);
  if (err != 0) return err;

  return err;
}
