import CreationService

cs = CreationService.F90CompilerCreator('Absoft')
cs.cpp_header()

cs = CreationService.F90CompilerCreator('Alpha')
cs.cpp_header()

cs = CreationService.F90CompilerCreator('Cray')
cs.cpp_header()

cs = CreationService.F90CompilerCreator('GNU')
cs.cpp_header()

cs = CreationService.F90CompilerCreator('IBMXL')
cs.cpp_header()

cs = CreationService.F90CompilerCreator('Intel')
cs.cpp_header()

cs = CreationService.F90CompilerCreator('Intel_7')
cs.cpp_header()

cs = CreationService.F90CompilerCreator('Lahey')
cs.cpp_header()

cs = CreationService.F90CompilerCreator('MIPSpro')
cs.cpp_header()

cs = CreationService.F90CompilerCreator('NAG')
cs.cpp_header()

cs = CreationService.F90CompilerCreator('PGI')
cs.cpp_header()

cs = CreationService.F90CompilerCreator('SUNWspro')
cs.cpp_header()

cs = CreationService.F90CompilerCreator('F90Vendor')
cs.cpp_header()
