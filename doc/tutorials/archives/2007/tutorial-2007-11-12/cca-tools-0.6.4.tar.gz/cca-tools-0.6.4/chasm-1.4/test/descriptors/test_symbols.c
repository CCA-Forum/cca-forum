/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */

#include "CompilerCharacteristics.h"
#include <F90Compiler.h>
#include <string.h>
#include <stdio.h>

#ifdef F90_ABSOFT
# define Binky_AaZz BINKY_AAZZ
# define Binky_AaZz_in_Chasm __BINKY_AAZZ_in_CHASM
# define binkg "BINKY_AAZZ"
# define binkc "__BINKY_AAZZ_in_CHASM"
#endif

#ifdef F90_ALPHA
# define Binky_AaZz binky_aazz_
# define Binky_AaZz_in_Chasm _chasm_binky_aazz_
# define binkg "binky_aazz_"
# define binkc "$chasm$binky_aazz_"
#endif

#ifdef F90_CRAY
# define Binky_AaZz binky_aazz_
# define Binky_AaZz_in_Chasm binky_aazz_chasm_
# define binkg "binky_aazz_"
# define binkc "binky_aazz@chasm_"
#endif

#ifdef F90_GNU
# define Binky_AaZz F90_SYMBOL_COND( binky_aazz )
# define Binky_AaZz_in_Chasm __chasm__binky_aazz
# define binkg "binky_aazz_"
# define binkc "__chasm__binky_aazz"
#endif

#ifdef F90_G95
# define Binky_AaZz F90_SYMBOL_COND( binky_aazz )
# define Binky_AaZz_in_Chasm chasm_MP_binky_aazz
# define binkg "binky_aazz_"
# define binkc "chasm_MP_binky_aazz"
#endif

#ifdef F90_IBMXL
# define Binky_AaZz binky_aazz
# define Binky_AaZz_in_Chasm __chasm_NMOD_binky_aazz
# define binkg "binky_aazz"
# define binkc "__chasm_NMOD_binky_aazz"
#endif

#ifdef F90_INTEL
# define Binky_AaZz binky_aazz_
# define Binky_AaZz_in_Chasm chasm__binky_aazz_
# define binkg "binky_aazz_"
# define binkc "chasm..binky_aazz_"
#endif

#ifdef F90_INTEL_7
# define Binky_AaZz binky_aazz_
# define Binky_AaZz_in_Chasm chasm__binky_aazz_
# define binkg "binky_aazz_"
# define binkc "chasm..binky_aazz_"
#endif

#ifdef F90_LAHEY
# define Binky_AaZz binky_aazz_
# define Binky_AaZz_in_Chasm chasm_binky_aazz_
# define binkg "binky_aazz_"
# define binkc "chasm.binky_aazz_"
#endif

#ifdef F90_MIPSPRO
# define Binky_AaZz binky_aazz_
# define Binky_AaZz_in_Chasm BINKY_AAZZ_in_CHASM
# define binkg "binky_aazz_"
# define binkc "BINKY_AAZZ.in.CHASM"
#endif

#ifdef F90_NAG
# define Binky_AaZz binky_aazz_
# define Binky_AaZz_in_Chasm chasm_MP_binky_aazz
# define binkg "binky_aazz_"
# define binkc "chasm_MP_binky_aazz"
#endif

#ifdef F90_PGI
# define Binky_AaZz binky_aazz_
# define Binky_AaZz_in_Chasm chasm_binky_aazz_
# define binkg "binky_aazz_"
# define binkc "chasm_binky_aazz_"
#endif

#ifdef F90_SUNWSPRO
# define Binky_AaZz binky_aazz_
# define Binky_AaZz_in_Chasm chasm_binky_aazz_
# define binkg "binky_aazz_"
# define binkc "chasm.binky_aazz_"
#endif


void Binky_AaZz(void);
void Binky_AaZz_in_Chasm(void);


int F90_MAIN(int argc, char* argv[])
{
  F90_CompilerCharacteristics cc;
  char* sym;
  int rc = 0;

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  sym = cc.getMangledName("Binky_AaZz", 0);
  if (strcmp(sym, binkg)) {
    printf("Symbol for Binky_AaZz is          %s\n", sym);
    printf("  should be                       %s\n", binkg);
  }

  sym = cc.getMangledName("Binky_AaZz", "Chasm");
  if (strcmp(sym, binkc)) {
    printf("Symbol for Chasm::Binky_AaZz is   %s\n", sym);
    printf("  should be                       %s\n", binkc);
    rc += 1;
  }

  return rc;
}


void callBinkies()
{
  Binky_AaZz();
#ifndef F90_ALPHA
#ifndef F90_CRAY
#ifndef F90_INTEL
#ifndef F90_INTEL_7
#ifndef F90_LAHEY
#ifndef F90_MIPSPRO
#ifndef F90_SUNWSPRO
  Binky_AaZz_in_Chasm();
#endif
#endif
#endif
#endif
#endif
#endif
#endif
}
