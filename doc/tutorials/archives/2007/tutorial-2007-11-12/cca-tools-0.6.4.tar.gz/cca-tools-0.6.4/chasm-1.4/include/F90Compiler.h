/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */
#ifndef _F90_COMPILER_H_
#define _F90_COMPILER_H_

/* $Id: F90Compiler.h.in,v 1.13 2004/09/13 13:05:35 rasmussn Exp $ */

/*-----------------------------------------------------------------------------
 * This file sets the default Fortran compiler.
 *-----------------------------------------------------------------------------
 */
#define F90_PGI
#define FORTRAN_COMPILER "PGI"
#define F90_MAIN MAIN_

#define CHASM_ARCH_LINUX
#define CHASM_ARCH_64

#define F90_SYM_CASE_LOWER
#define F90_SYM_UNDERSCORE


#define F90_MIN_ELEMENT_SIZE 1

/*
 * Macros to add underscore to symbols (if needed)
 */

#if defined (F90_SYM_UNDERSCORE)
# define F90_SYMBOL(sym) sym ## _
#elif defined (F90_SYM_EXTRA_UNDERSCORE)
# define F90_SYMBOL(sym) sym ## __
#else
# define F90_SYMBOL(sym) sym
#endif

#if defined (F90_SYM_UNDERSCORE_COND)
# define F90_SYMBOL_COND(sym) F90_SYMBOL(sym ## _)
#else
# define F90_SYMBOL_COND(sym) F90_SYMBOL(sym)
#endif

#endif /* _F90_COMPILER_H_ */
