import Numeric
import FArray

''' create dictionary in which Fortran will store arrays '''

d = {}


''' call Fortran to get exported arrays '''

FArray.getArrays(d)


''' get arrays from d and print them '''

A = d['A']
B = d['B']
C = d['C']

print
print 'A =', A

print
print 'B ='
print B
print

print
print 'C ='
print C
print


