#include <stdio.h>
#include <F90CreateArray.h>


#if   defined (F90_SYM_CASE_LOWER)
#  define setArray1D_PAD F90_SYMBOL(setarray1d_pad)
#  define setArray1D F90_SYMBOL(setarray1d)
#  define setArray2D F90_SYMBOL(setarray2d)
#  define setArray3D F90_SYMBOL(setarray3d)
#  define setArray4D F90_SYMBOL(setarray4d)
#  define setArray5D F90_SYMBOL(setarray5d)
#  define setArray6D F90_SYMBOL(setarray6d)
#  define setArray7D F90_SYMBOL(setarray7d)
#elif defined (F90_SYM_CASE_UPPER)
#  define setArray1D_PAD F90_SYMBOL(SETARRAY1D_PAD)
#  define setArray1D F90_SYMBOL(SETARRAY1D)
#  define setArray2D F90_SYMBOL(SETARRAY2D)
#  define setArray3D F90_SYMBOL(SETARRAY3D)
#  define setArray4D F90_SYMBOL(SETARRAY4D)
#  define setArray5D F90_SYMBOL(SETARRAY5D)
#  define setArray6D F90_SYMBOL(SETARRAY6D)
#  define setArray7D F90_SYMBOL(SETARRAY7D)
#else
#  define setArray1D_PAD F90_SYMBOL(setArray1D_PAD)
#  define setArray1D F90_SYMBOL(setArray1D)
#  define setArray2D F90_SYMBOL(setArray2D)
#  define setArray3D F90_SYMBOL(setArray3D)
#  define setArray4D F90_SYMBOL(setArray4D)
#  define setArray5D F90_SYMBOL(setArray5D)
#  define setArray6D F90_SYMBOL(setArray6D)
#  define setArray7D F90_SYMBOL(setArray7D)
#endif


typedef struct wrapper_ {
  int a[512];
} wrapper;


void setArray1D_PAD(wrapper*);
void setArray1D(wrapper*);
void setArray2D(wrapper*);
void setArray3D(wrapper*);
void setArray4D(wrapper*);
void setArray5D(wrapper*);
void setArray6D(wrapper*);
void setArray7D(wrapper*);


int check_padding()
{
  wrapper w;
  int i, len, len_padded;
  int padding = 0;

  setArray1D(&w);  
  if (w.a[0] != 333332) {
    printf("FAILED, start flag for array1D is incorrect = %d\n", w.a[0]);
    return -1;
  }
  for (i = 0; i < 512; i++) {
    if (w.a[i] == 333333) {
      len = (i-1)*sizeof(int);
      break;
    }
  }

  setArray1D_PAD(&w);  
  if (w.a[0] != 333332) {
    printf("FAILED, start flag for array1D is incorrect = %d\n", w.a[0]);
    return 1;
  }
  for (i = 0; i < 512; i++) {
    if (w.a[i] == 333333) {
      len_padded = (i-1)*sizeof(int);
      break;
    }
  }

  if (len == len_padded) {
    padding = 1;
  }

  return padding;
}


int F90_MAIN(int argc, char* argv[])
{
  int i, len, padding;
  wrapper w;

  padding = check_padding();
  if (padding < 0) {
    printf("FAILED, couldn't find padding for array1D");
    return 1;
  }
  if (padding == 1) {
    printf(" WARNING, found extra padding in Fortran type array_1d,\n");
    printf("   tests for descriptor size will compensate for the extra padding.\n");
  }

  setArray1D(&w);  
  if (w.a[0] != 333332) {
    printf("FAILED, start flag for array1D is incorrect = %d\n", w.a[0]);
    return 1;
  }
  for (i = 0; i < 512; i++) {
    if (w.a[i] == 333333) {
      if (padding == 1) {
	len = (i-2)*sizeof(int);
      } else {
	len = (i-1)*sizeof(int);
      }
      if (len != getArrayDescSize(1)) {
	printf("FAILED, descriptor size for array1D is incorrect = %d %d\n", len, getArrayDescSize(1));
	return 1;
      }
      printf("SUCCESSFULLY found Fortran array1D pointer length of %d bytes\n",
	     len);
      break;
    }
  }
  if (i == 512) printf("FAILED to find end flag for array1D\n");

  setArray2D(&w);  
  if (w.a[0] != 333332) {
    printf("FAILED, start flag for array2D is incorrect = %d\n", w.a[0]);
    return 1;
  }
  for (i = 0; i < 512; i++) {
    if (w.a[i] == 333333) {
      if (padding == 1) {
	len = (i-2)*sizeof(int);
      } else {
	len = (i-1)*sizeof(int);
      }
      if (len != getArrayDescSize(2)) {
	printf("FAILED, descriptor size for array2D is incorrect = %d\n", len);
	return 1;
      }
      printf("SUCCESSFULLY found Fortran array2D pointer length of %d bytes\n",
	     len);
      break;
    }
  }
  if (i == 512) printf("FAILED to find end flag for array2D\n");

  setArray3D(&w);  
  if (w.a[0] != 333332) {
    printf("FAILED, start flag for array3D is incorrect = %d\n", w.a[0]);
    return 1;
  }
  for (i = 0; i < 512; i++) {
    if (w.a[i] == 333333) {
      if (padding == 1) {
	len = (i-2)*sizeof(int);
      } else {
	len = (i-1)*sizeof(int);
      }
      if (len != getArrayDescSize(3)) {
	printf("FAILED, descriptor size for array3D is incorrect = %d\n", len);
	return 1;
      }
      printf("SUCCESSFULLY found Fortran array3D pointer length of %d bytes\n",
	     len);
      break;
    }
  }
  if (i == 512) printf("FAILED to find end flag for array3D\n");

  setArray4D(&w);  
  if (w.a[0] != 333332) {
    printf("FAILED, start flag for array4D is incorrect = %d\n", w.a[0]);
    return 1;
  }
  for (i = 0; i < 512; i++) {
    if (w.a[i] == 333333) {
      if (padding == 1) {
	len = (i-2)*sizeof(int);
      } else {
	len = (i-1)*sizeof(int);
      }
      if (len != getArrayDescSize(4)) {
	printf("FAILED, descriptor size for array4D is incorrect = %d\n", len);
	return 1;
      }
      printf("SUCCESSFULLY found Fortran array4D pointer length of %d bytes\n",
	     len);
      break;
    }
  }
  if (i == 512) printf("FAILED to find end flag for array4D\n");

  setArray5D(&w);  
  if (w.a[0] != 333332) {
    printf("FAILED, start flag for array5D is incorrect = %d\n", w.a[0]);
    return 1;
  }
  for (i = 0; i < 512; i++) {
    if (w.a[i] == 333333) {
      if (padding == 1) {
	len = (i-2)*sizeof(int);
      } else {
	len = (i-1)*sizeof(int);
      }
      if (len != getArrayDescSize(5)) {
	printf("FAILED, descriptor size for array5D is incorrect = %d\n", len);
	return 1;
      }
      printf("SUCCESSFULLY found Fortran array5D pointer length of %d bytes\n",
	     len);
      break;
    }
  }
  if (i == 512) printf("FAILED to find end flag for array5D\n");

  setArray6D(&w);  
  if (w.a[0] != 333332) {
    printf("FAILED, start flag for array6D is incorrect = %d\n", w.a[0]);
    return 1;
  }
  for (i = 0; i < 512; i++) {
    if (w.a[i] == 333333) {
      if (padding == 1) {
	len = (i-2)*sizeof(int);
      } else {
	len = (i-1)*sizeof(int);
      }
      if (len != getArrayDescSize(6)) {
	printf("FAILED, descriptor size for array6D is incorrect = %d\n", len);
	return 1;
      }
      printf("SUCCESSFULLY found Fortran array6D pointer length of %d bytes\n",
	     len);
      break;
    }
  }
  if (i == 512) printf("FAILED to find end flag for array6D\n");

  setArray7D(&w);  
  if (w.a[0] != 333332) {
    printf("FAILED, start flag for array7D is incorrect = %d\n", w.a[0]);
    return 1;
  }
  for (i = 0; i < 512; i++) {
    if (w.a[i] == 333333) {
      if (padding == 1) {
	len = (i-2)*sizeof(int);
      } else {
	len = (i-1)*sizeof(int);
      }
      if (len != getArrayDescSize(7)) {
	printf("FAILED, descriptor size for array7D is incorrect = %d\n", len);
	return 1;
      }
      printf("SUCCESSFULLY found Fortran array7D pointer length of %d bytes\n",
	     len);
      break;
    }
  }
  if (i == 512) {
    printf("FAILED to find end flag for array7D\n");
    return 1;
  }

  return 0;
}
