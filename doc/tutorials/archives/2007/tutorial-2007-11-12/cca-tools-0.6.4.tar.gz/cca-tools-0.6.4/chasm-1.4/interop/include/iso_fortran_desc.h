#ifndef ISO_FORTRAN_DESC_H_
#define ISO_FORTRAN_DESC_H_

#include <stdio.h>
#include <compilers/GNU_dv.h>

typedef dope_vec_GNU * FDesc_Assumed_t;
typedef dope_vec_GNU * FDesc_Pointer_t;
typedef dope_vec_GNU * FDesc_Alloc_t;

typedef size_t F_stride_t;
typedef size_t F_extent_t;

int FDesc_Assumed_Create
                (
                 FDesc_Assumed_t * restrict fdesc,
                 size_t elem_size,
                 unsigned int rank
                );

     int FDesc_Pointer_Create
                (
                 FDesc_Pointer_t * restrict fdesc,
                 size_t elem_size,
                 unsigned int rank
                );

     int FDesc_Alloc_Create
                (
                 FDesc_Alloc_t * restrict fdesc,
                 size_t elem_size,
                 unsigned int rank
                );

     int FDesc_Assumed_Destroy ( FDesc_Assumed_t * restrict fdesc );

     int FDesc_Pointer_Destroy ( FDesc_Pointer_t * restrict fdesc );

     int FDesc_Alloc_Destroy ( FDesc_Alloc_t * restrict fdesc );

     int FDesc_Assumed_Set
                (
                 FDesc_Assumed_t fdesc,
                 void * restrict base_addr,
                 const F_extent_t shape[restrict],
                 const F_stride_t stride[restrict]
                );

     int FDesc_Pointer_Set
                (
                 FDesc_Pointer_t fdesc,
                 void * base_addr,
                 const F_extent_t shape[restrict],
                 const F_extent_t lbound[restrict],
                 const F_stride_t stride[restrict]
                );

     int FDesc_Assumed_Allocate
                (
                 FDesc_Assumed_t fdesc,
                 const F_extent_t shape[restrict]
                );

     int FDesc_Pointer_Allocate
                (
                 FDesc_Pointer_t fdesc,
                 const F_extent_t shape[restrict],
                 const F_extent_t lbound[restrict]
                );

     int FDesc_Alloc_Allocate
                (
                 FDesc_Alloc_t fdesc,
                 const F_extent_t shape[restrict],
                 const F_extent_t lbound[restrict]
                );

     int FDesc_Assumed_Deallocate ( FDesc_Assumed_t fdesc );

     int FDesc_Pointer_Deallocate ( FDesc_Pointer_t fdesc );

     int FDesc_Alloc_Deallocate ( FDesc_Alloc_t fdesc );

     _Bool FDesc_Associated ( FDesc_Pointer_t fdesc );

     _Bool FDesc_Allocated ( FDesc_Alloc_t fdesc );

     int FDesc_Assumed_Rank ( FDesc_Assumed_t fdesc );

     int FDesc_Pointer_Rank ( FDesc_Pointer_t fdesc );

     int FDesc_Alloc_Rank ( FDesc_Alloc_t fdesc );

     int FDesc_Assumed_Get
                (
                 FDesc_Assumed_t fdesc,
                 void ** base_addr,
                 size_t * elem_size,
                 F_extent_t shape[restrict],
                 F_extent_t lbound[restrict],
                 F_stride_t stride[restrict]
                );

     int FDesc_Pointer_Get
                (
                 FDesc_Pointer_t fdesc,
                 void ** base_addr,
                 size_t * elem_size,
                 F_extent_t shape[restrict],
                 F_extent_t lbound[restrict],
                 F_stride_t stride[restrict]
                );

     int FDesc_Alloc_Get
                (
                 FDesc_Alloc_t fdesc,
                 void ** restrict base_addr,
                 size_t * elem_size,
                 F_extent_t shape[restrict],
                 F_extent_t lbound[restrict]
                );

#endif /*ISO_FORTRAN_DESC_H_*/
