/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */
#include <compilers/Cray.h>
#include <compilers/Cray_dv.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define dope_vec dope_vec_Cray

#ifdef __cplusplus
extern "C"{
#endif


/**
 * Set CompilerCharacteristics function pointers for Cray.
 */
void F90_SetCCFunctions_Cray(F90_CompilerCharacteristics* cc)
{
  cc->setArrayDesc              = setArrayDesc_Cray;
  cc->resetArrayDesc            = resetArrayDesc_Cray;
  cc->createArrayDesc           = createArrayDesc_Cray;
  cc->createArrayDescAndHidden  = createArrayDescAndHidden_Cray;
  cc->freeArrayDescAndHidden    = freeArrayDescAndHidden_Cray;
  cc->copyToArrayDescAndHidden  = copyToArrayDescAndHidden_Cray;
  cc->getArrayBaseAddress       = getArrayBaseAddress_Cray;
  cc->getArraySize              = getArraySize_Cray;
  cc->getArrayLowerBound        = getArrayLowerBound_Cray;
  cc->getArrayExtent	        = getArrayExtent_Cray;
  cc->getArrayStrideMult        = getArrayStrideMult_Cray;
  cc->getArrayDescSize	        = getArrayDescSize_Cray;
  cc->nullifyArrayDesc          = nullifyArrayDesc_Cray;
  cc->verifyArrayDesc           = verifyArrayDesc_Cray;
  cc->hiddenArrayDescType       = hiddenArrayDescType_Cray;
  cc->getMangledName	        = getMangledName_Cray;
  cc->equalsArrayDesc	        = equalsArrayDesc_Cray;
  cc->printArrayDesc	        = printArrayDesc_Cray;
}


/**
 * Stage 1 of setting the elements of a preallocated array descriptor.
 *
 * NOTE, this function is static (private).
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param rank          the rank of the array
 * @param desc_type     type of the descriptor
 * @param data_type     data type of an array element
 * @param element_size  size of an array element
 * @return              0 if successful (nonzero on error)
 */
static int setArrayDescStage1_Cray(void* desc,
				   int rank,
				   F90_DescType desc_type,
				   F90_ArrayDataType data_type,
				   unsigned long element_size
				   )
{
  int rc = 0;

  dope_vec* dv = (dope_vec*) desc;

  dv->rank      = rank;

  dv->elem_size = 8 * element_size;
  if (dv->elem_size < 32) dv->elem_size = 32;
  dv->max_len   = dv->elem_size;

  dv->assoc     = 1;
  dv->ptr_alloc = 0;
  dv->p_or_a    = 1;

  if (rank == 0) dv->a_contig = 0;
  else           dv->a_contig = 1;

  dv->dp_flag    = 0;
  dv->star_type  = 0;
  dv->kind_value = 0;

  if (dv->elem_size < 64)  dv->unused_1   = 36;
  else                     dv->unused_1   = 40;

  dv->unused_2   = 0;
  dv->unused_3   = 0;
  dv->unused_4   = 0;
  dv->unused_5   = 0;

  switch (data_type) {
    case F90_Integer1:
      dv->type_code = 2; dv->star_type = 3; dv->kind_value = 1; break;
    case F90_Integer2:
      dv->type_code = 2; dv->star_type = 3; dv->kind_value = 2; break;
    case F90_Integer:
      dv->type_code = 2; dv->star_type = 0; dv->kind_value = 0; break;
    case F90_Integer4:
      dv->type_code = 2; dv->star_type = 3; dv->kind_value = 4; break;
    case F90_Integer8:
      dv->type_code = 2; dv->star_type = 3; dv->kind_value = 8; break;
    case F90_Logical1:
      dv->type_code = 5; dv->star_type = 3; dv->kind_value = 1; break;
    case F90_Logical2:
      dv->type_code = 5; dv->star_type = 3; dv->kind_value = 2; break;
    case F90_Logical:
      dv->type_code = 5; dv->star_type = 0; dv->kind_value = 0; break;
    case F90_Logical4:
      dv->type_code = 5; dv->star_type = 3; dv->kind_value = 4; break;
    case F90_Logical8:
      dv->type_code = 5; dv->star_type = 3; dv->kind_value = 8; break;
    case F90_Real:
      dv->type_code = 3; dv->star_type = 0; dv->kind_value = 0; break;
    case F90_Double:
      dv->type_code = 3; dv->star_type = 4; dv->kind_value = 8; break;
    case F90_QReal:
      dv->type_code = 3; dv->star_type = 3; dv->kind_value = 16; break;
    case F90_Complex:
      dv->type_code = 4; dv->star_type = 0; dv->kind_value = 0; break;
    case F90_DComplex:
      dv->type_code = 4; dv->star_type = 1; dv->kind_value = 8; break;
    case F90_QComplex:
      dv->type_code = 4; dv->star_type = 3; dv->kind_value = 32; break;
    case F90_Derived:
      dv->type_code = 8; dv->elem_size = 0; break;
    case F90_Unknown:
      dv->type_code = 1;  break;
    default:
      dv->type_code = 1;  break;
  }
  return rc;
}


/**
 * Sets the elements of a preallocated array descriptor.  This function is
 * used when passing a C array to Fortran.  NOTE, assumes that, at least,
 * ArrayDescSize bytes have been allocated in the desc pointer.
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param base_addr     the base address of the array
 * @param rank          the rank of the array
 * @param desc_type     type of the descriptor
 * @param data_type     data type of an array element
 * @param element_size  size of an array element
 * @param lowerBound    array[rank] of lower bounds for the array
 * @param extent        array[rank] of extents for the array (in elements)
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes)
 * @return              0 if successful (nonzero on error)
 */
int setArrayDesc_Cray(void* desc,
		      void* base_addr,
		      int rank,
		      F90_DescType desc_type,
		      F90_ArrayDataType data_type,
		      unsigned long element_size,
		      const long* lowerBound,
		      const unsigned long* extent,
		      const long* strideMult
		      )
{
  int rc = 0;

  if (rank < 0 || rank > 7) return 1;

  rc = setArrayDescStage1_Cray(desc, rank, desc_type, data_type, element_size);
  if (rc) return rc;
  return resetArrayDesc_Cray(desc, base_addr, rank,
			     lowerBound, extent, strideMult);
}


/**
 * Resets the elements of a preallocated array descriptor.  The descriptor
 * must have been previously initialized by either setArrayDesc() or
 * createArrayDesc().  The rank, data type and element size of the array
 * MUST NOT change.  NOTE, assumes that, at least, ArrayDescSize() bytes
 * have been allocated in the desc pointer.
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param base_addr     the base address of the array
 * @param rank          the rank of the array
 * @param lowerBound    array[rank] of lower bounds for the array
 * @param extent        array[rank] of extents for the array (in elements)
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes)
 * @return              0 if successful (nonzero on error)
 */
int resetArrayDesc_Cray(void* desc,
			void* base_addr,
			int rank,
			const long* lowerBound,
			const unsigned long* extent,
			const long* strideMult
			)
{
  int i;
  dope_vec* dv = (dope_vec*) desc;
  
  if (rank < 0 || rank > 7) return 1;

  dv->assoc = 1;
  if (rank == 0) dv->a_contig = 0;
  else           dv->a_contig = 1;

  dv->base_addr = (long) base_addr;
  for (i = 0; i < rank; i++) {
    dv->dim[i].lower_bound = lowerBound[i];
    dv->dim[i].extent      = extent[i];
    if (dv->max_len < 64) {
      dv->dim[i].stride_mult = strideMult[i]/4L;
    } else {
      dv->dim[i].stride_mult = strideMult[i]/8L;
    }
  }
  return 0;
}


/**
 * Returns an array descriptor by copying an existing descriptor.  This
 * function is used when passing an array from Fortran to C++.  NOTE,
 * it is the callers responsibility to free the returned descriptor.
 *
 * @param desc       the descriptor to copy
 * @param hidden     hidden descriptor parameter
 * @param rank       the rank of the array
 * @param desc_type  type of the source descriptor
 * @return           allocated array descriptor copy
 */
void* createArrayDesc_Cray(void* desc,
			   void* hidden,
			   int rank,
			   F90_DescType desc_type
			   )
{
  void* dv = (void*) calloc( 1, getArrayDescSize_Cray(rank) );
  assert(dv != 0);

  memcpy(dv, desc, getArrayDescSize_Cray(rank));

  return dv;
}


/**
 * Creates an array descriptor (with hidden portion) from an existing
 * descriptor in preparation for calling a Fortran function from C (with
 * an array valued parameter).
 *
 * IMPORTANT NOTES: The companion function freeArrayDescAndHidden must be
 * called to free the parameters desc and hidden after use (lifetime
 * must not exceed that of the source descriptor).
 *
 * @param src        the source descriptor
 * @param rank       the rank of the source and destination arrays
 * @param desc_type  type of the source and destination descriptors
 * @param desc       on return, contains address of created descriptor
 * @param hidden     on return, contains address of hidden form of the descriptor
 * @return           0 if successful (nonzero on error)
 */
int createArrayDescAndHidden_Cray(void* src,
				  int rank,
				  F90_DescType desc_type,
				  void** desc,
				  void** hidden
				  )
{
  *desc = src;
  *hidden = 0x0;
  return 0;
}


/**
 * Frees an array descriptor (with hidden portion) created by
 * a call to createArrayDescAndHidden().
 *
 * @param desc_type  type of the descriptor
 * @param desc       address of descriptor to be freed
 * @param hidden     address of hidden form of the descriptor to be freed
 * @return           0 if successful (nonzero on error)
 */
int freeArrayDescAndHidden_Cray(F90_DescType desc_type, void* desc, void* hidden)
{
  return 0;
}


/**
 * Copies one array descriptor to another.  This function is used
 * when passing an array from C++ to Fortran.
 *
 * @param src        the source descriptor
 * @param rank       the rank of the source and destination arrays
 * @param desc_type  type of the source and destination descriptors
 * @param dest       the destination descriptor
 * @param hidden     hidden form of the descriptor, after formal parameter list
 * @return           0 if successful (nonzero on error)
 */
int copyToArrayDescAndHidden_Cray(void* src,
				  int rank,
				  F90_DescType desc_type,
				  void* dest,
				  void* hidden
				  )
{
  memcpy(dest, src, getArrayDescSize_Cray(rank));
  return 0;
}


/** 
 * Returns a pointer to the base address of the array.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       base address of the array
 */
void* getArrayBaseAddress_Cray(const void* desc, int rank)
{
  if (rank < 0 || rank > 7) {
    return 0x0;
  } else {
    return (long*) ((dope_vec*) desc)->base_addr;
  }
}


/**
 * Returns the array size (in elements).
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       array size
 */
unsigned long getArraySize_Cray(const void* desc, int rank)
{
  int i;
  unsigned long size = 1L;

  dope_vec* dv = (dope_vec*) desc;
  if (rank < 1 || rank > dv->rank) return 0;

  for (i = 0; i < rank; i++) {
    size *= dv->dim[i].extent;
  }
  return size;
}


/**
 * Returns the lower bound for the given dimension.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       lower bound
 */
long getArrayLowerBound_Cray(const void* desc, int rank, int dim)
{
  dope_vec* dv = (dope_vec*) desc;
  if (rank < 1 || rank > dv->rank) return 0;

  return dv->dim[dim-1].lower_bound;
}


/**
 * Returns the extent of the array for the given dimension (in elements).
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       array extent (in elements)
 */
unsigned long getArrayExtent_Cray(const void* desc, int rank, int dim)
{
  dope_vec* dv = (dope_vec*) desc;
  if (rank < 1 || rank > dv->rank) return 0;

  return dv->dim[dim-1].extent;
}


/**
 * Returns the distance between successive elements (in bytes).
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       stride (in bytes)
 */
long getArrayStrideMult_Cray(const void* desc, int rank, int dim)
{
  dope_vec* dv = (dope_vec*) desc;
  if (rank < 1 || rank > dv->rank) return 0;

  if (dv->max_len < 64) {
    return dv->dim[dim-1].stride_mult * 4L;
  } else {
    return dv->dim[dim-1].stride_mult * 8L;
  }
}


/**
 * Returns the size of an array descriptor (in bytes).
 *
 * @param rank   the rank of the array
 * @return       descriptor size (in bytes)
 */
unsigned long getArrayDescSize_Cray(int rank)
{
  if (rank < 0 || rank > 7) return 0;

  return sizeof(dope_vec) - 3*(7-rank)*sizeof(long);
}


/**
 * Nullify an array descriptor (associated intrinsic will return false).
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @return       0 if successful (nonzero on error)
 */
int nullifyArrayDesc_Cray(void* desc, int rank)
{
  dope_vec* dv = (dope_vec*) desc;
  dv->assoc = 0;
  return 0;
}


/**
 * Verify an array descriptor.
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @return       0 if the descriptor is valid, nonzero otherwise
 */
int verifyArrayDesc_Cray(const void* desc, int rank)
{
  int i;
  dope_vec* dv = (dope_vec*) desc;

  if (dv->base_addr == 0x0)		return 1;
  if (dv->rank      != rank)		return 1;
  if (dv->elem_size <  8)		return 1;
  if (dv->max_len   != dv->elem_size)	return 1;

  if (dv->assoc != 1) return 1;

  if ( ! (dv->type_code == 2 || dv->type_code == 3 ||
          dv->type_code == 4 || dv->type_code == 5 || dv->type_code == 8)
     ) return 1;

  for (i = 0; i < rank; i++) {
    if (dv->dim[i].extent      < 1) return 1;
    if (dv->dim[i].stride_mult < 1) return 1;
  }
  return 0;
}


/**
 * Returns the type of hidden descriptors used by the compiler
 *
 * @param desc_type  type of the descriptor
 * @return          hidden descriptor type
 */
F90_HiddenDescType hiddenArrayDescType_Cray(F90_DescType desc_type)
{
  return F90_NoHidden;
}


/**
 * Returns the symbol name of a module procedure, if the module name
 * is not null, otherwise returns the name of the procedure.
 *
 * Note: static memory is used for the return value so it must be
 * copied if retained because the memory is overwritten at each call.
 *
 * @param fun_name   the name of the procedure
 * @param mod_name   the module name (NULL if a global procedure)
 * @return           symbol name
 */
char* getMangledName_Cray(const char* fun_name, const char* mod_name)
{   
  int i;
  static char name[512];
  size_t funsize, modsize, namesize;

  if (fun_name == NULL) return NULL;

  funsize = strlen(fun_name);
  if (mod_name == NULL) {
    modsize = 0L;
    namesize = funsize + 1;
  } else {
    modsize = strlen(mod_name);
    namesize = funsize + 1 + modsize + 1;
  }

  if (namesize > 511) return NULL;

  strcpy(name, fun_name);
  if (modsize > 0L) {
    strcpy(name + funsize, "@");
    strcpy(name + funsize + 1, mod_name);
    strcpy(name + funsize + 1 + modsize, "_");
  } else {
    strcpy(name + funsize, "_");
  }

  /* lower case -> the symbol name */

  for (i = 0; i < namesize; i++) {
    if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
  }

  return name;
}


/**
 * Prints all fields in the array descriptor.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       0 if successful (nonzero on error)
 */
int printArrayDesc_Cray(const void* desc, int rank)
{
  int i;
  dope_vec *dv = (dope_vec*) desc;

  printf("Cray array descriptor:\n");
  printf("  base_addr = %p\n" , (void*) dv->base_addr);
  printf("  max_len   = %ld\n", dv->max_len);
  printf("  assoc     = %d\n" , dv->assoc);
  printf("  ptr_alloc = %d\n" , dv->ptr_alloc);
  printf("  p_or_a    = %d\n" , dv->p_or_a);
  printf("  a_contig  = %d\n" , dv->a_contig);
  printf("  rank      = %d\n" , dv->rank);

  printf("  type_code = %d\n" , dv->type_code);
  printf("  dp_flag   = %d\n" , dv->dp_flag);
  printf("  star_type = %d\n" , dv->star_type);
  printf("  elem_size = %d\n" , dv->elem_size);
  printf("  kind_value= %d\n" , dv->kind_value);

  printf("  unused_1  = %d\n" , dv->unused_1);
  printf("  unused_2  = %ld\n", dv->unused_2);
  printf("  unused_3  = %ld\n", dv->unused_3);
  printf("  unused_4  = %d\n" , dv->unused_4);
  printf("  unused_5  = %ld\n", dv->unused_5);

  for (i = 0; i < dv->rank; i++) {
    printf("    dim[%d] = LB:%ld, Ex:%ld, SM:%ld\n" , i,
           dv->dim[i].lower_bound,
           dv->dim[i].extent, dv->dim[i].stride_mult);
  }
  return 0;
}


/**
 * Determines if two descriptors are equal (equivalent).
 *
 * WARNING, this function is deprecated.
 *
 * @param desc1   first descriptor
 * @param desc2   second descriptor
 * @param rank    the rank of the array
 * @return        1 if equal, 0 otherwise
 */
int equalsArrayDesc_Cray(const void* desc1, const void* desc2, int rank)
{
  int i;
  dope_vec* dv1 = (dope_vec*) desc1;
  dope_vec* dv2 = (dope_vec*) desc2;

  if (dv1->base_addr != dv2->base_addr) return 0;
  if (dv1->max_len   != dv2->max_len  ) return 0;

  /***** debugging code ******/

  i = 1;
  if (dv1->assoc     != dv2->assoc    ) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->assoc, dv2->assoc);
  }
  if (dv1->ptr_alloc != dv2->ptr_alloc) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->ptr_alloc, dv2->ptr_alloc);
  }
  if (dv1->p_or_a    != dv2->p_or_a   ) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->p_or_a, dv2->p_or_a);
  }
  if (dv1->a_contig  != dv2->a_contig ) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->a_contig, dv2->a_contig);
  }
  if (dv1->rank      != dv2->rank     ) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->rank, dv2->rank);
  }

  if (dv1->type_code  != dv2->type_code ) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->type_code, dv2->type_code);
  }
  if (dv1->dp_flag    != dv2->dp_flag   ) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->dp_flag, dv2->dp_flag);
  }
  if (dv1->star_type  != dv2->star_type ) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->star_type, dv2->star_type);
  }
  if (dv1->elem_size  != dv2->elem_size ) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->elem_size, dv2->elem_size);
  }
  if (dv1->kind_value != dv2->kind_value) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->kind_value, dv2->kind_value);
  }

  if (dv1->unused_1 != dv2->unused_1) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->unused_1, dv2->unused_1);
  }
  if (dv1->unused_2 != dv2->unused_2) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->unused_2, dv2->unused_2);
  }
  if (dv1->unused_3 != dv2->unused_3) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->unused_3, dv2->unused_3);
  }
  if (dv1->unused_4 != dv2->unused_4) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->unused_4, dv2->unused_4);
  }
  if (dv1->unused_5 != dv2->unused_5) {
    i = 0;
    printf("Descriptors NOT Equal %d, %d\n", dv1->unused_5, dv2->unused_5);
  }
  if (i == 0) return 0;

  /*******
  if (dv1->assoc     != dv2->assoc    ) return 0;
  if (dv1->ptr_alloc != dv2->ptr_alloc) return 0;
  if (dv1->p_or_a    != dv2->p_or_a   ) return 0;
  if (dv1->a_contig  != dv2->a_contig ) return 0;
  if (dv1->rank      != dv2->rank     ) return 0;

  if (dv1->type_code  != dv2->type_code ) return 0;
  if (dv1->dp_flag    != dv2->dp_flag   ) return 0;
  if (dv1->star_type  != dv2->star_type ) return 0;
  if (dv1->elem_size  != dv2->elem_size ) return 0;
  if (dv1->kind_value != dv2->kind_value) return 0;

  if (dv1->unused_1 != dv2->unused_1) return 0;
  if (dv1->unused_2 != dv2->unused_2) return 0;
  if (dv1->unused_3 != dv2->unused_3) return 0;
  if (dv1->unused_4 != dv2->unused_4) return 0;
  if (dv1->unused_5 != dv2->unused_5) return 0;
  ******/

  for (i = 0; i < rank; i++) {
    if (dv1->dim[i].lower_bound != dv2->dim[i].lower_bound) return 0;
    if (dv1->dim[i].extent      != dv2->dim[i].extent) return 0;
    if (dv1->dim[i].stride_mult != dv2->dim[i].stride_mult) return 0;
  }
  return 1;
}


#ifdef __cplusplus
}
#endif
