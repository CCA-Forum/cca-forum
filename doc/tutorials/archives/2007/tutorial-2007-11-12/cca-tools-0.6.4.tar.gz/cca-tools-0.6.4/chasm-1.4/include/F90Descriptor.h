/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */
#ifndef _DESCRIPTOR_H_
#define _DESCRIPTOR_H_

#include "F90ArrayDataType.h"

namespace F90 {

/**
 * The minimum interface for a descriptor.
 *
 * address() - returns a pointer to the base address of the array
 * rank() - returns the rank of the array
 * lowerBound(dim) - returns the lower bound for the given dimension
 * extent(dim) - returns the extent of the array for the given dimension (in elements)
 * stride(dim) - returns the distance between successive elements (in bytes)
 * arraySize() - returns the array size (in elements)
 * elementSize() - returns the size of an array element (in bytes)
 * elementType() - returns the element type of the array
 * descriptor() - returns a pointer to the base address of the descriptor
 */
class Descriptor {
  public:
    virtual ~Descriptor() {}
  
    virtual void*             address() = 0;
    virtual int               rank() = 0;
    virtual long              lowerBound(int dim) = 0;
    virtual unsigned long     extent(int dim) = 0;
    virtual long              stride(int dim) = 0;
    virtual unsigned long     arraySize() = 0;
    virtual unsigned long     elementSize() = 0;
    virtual void*             descriptor() = 0;
    virtual F90_ArrayDataType elementType() = 0;
};

}

#endif /* _DESCRIPTOR_H_ */
