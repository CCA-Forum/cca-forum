/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */
#ifndef __H_
#define __H_

#include <stdio.h>
#include <CompilerCharacteristics.h>

#ifdef __cplusplus
extern "C" {
#endif
 
/**
 * Sets the elements of a preallocated array descriptor.  This function is
 * used when passing a C array to Fortran.  NOTE, assumes that, at least,
 * ArrayDescSize bytes have been allocated in the desc pointer.
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param base_addr     the base address of the array
 * @param rank          the rank of the array
 * @param data_type     data type of an array element
 * @param element_size  size of an array element
 * @param lowerBound    array[rank] of lower bounds for the array
 * @param extent        array[rank] of extents for the array (in elements)
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes)
 * @return              0 if successful (nonzero on error)
 */
int setArrayDesc(void* desc,
			  void* base_addr,
			  int rank,
			  F90ArrayDataType data_type,
			  int element_size,
			  int* lowerBound,
			  int* extent,
			  int* strideMult
			  );


/**
 * Returns an array descriptor by copying an existing descriptor.  This
 * function is used when passing an array from Fortran to C++.  NOTE,
 * it is the callers responsibility to free the returned descriptor.
 *
 * @param desc     the descriptor to copy
 * @param hidden   hidden descriptor parameter
 * @param rank     the rank of the array
 * @param kind     kind (or type) of the source descriptor
 * @return         allocated array descriptor copy
 */
void* createArrayDescCopy(void* desc,
				  void* hidden,
				  int rank,
				  DescType kind
				  );


/**
 * Copies one array descriptor to another.  This function is used
 * when passing an array from C++ to Fortran.
 *
 * @param src     the source descriptor
 * @param rank    the rank of the source and destination arrays
 * @param kind    kind (or type) of the destination descriptor
 * @param dest    the destination descriptor
 * @param hidden  hidden form of the descriptor, after formal parameter list
 */
void copyArrayDesc(void* src,
			   int rank,
			   DescType kind,
			   void* dest,
			   void* hidden
			   );


/** 
 * Returns a pointer to the base address of the array.
 *
 * @param desc   array descriptor
 * @return       base address of the array
 */
void* getArrayBaseAddress(void* desc);


/**
 * Returns the array size (in elements).
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       array size
 */
int getArraySize(void* desc, int rank);


/**
 * Returns the lower bound for the given dimension.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       lower bound
 */
int getArrayLowerBound(void* desc, int rank, int dim);


/**
 * Returns the extent of the array for the given dimension (in elements).
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       array extent (in elements)
 */
int getArrayExtent(void* desc, int rank, int dim);


/**
 * Returns the distance between successive elements (in bytes).
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       stride (in bytes)
 */
int getArrayStrideMult(void* desc, int rank, int dim);


/**
 * Returns the size of an array descriptor (in bytes).
 *
 * @param rank   the rank of the array
 * @return       descriptor size (in bytes)
 */
int getArrayDescSize(int rank);


/**
 * Nullify an array descriptor (associated intrinsic will return false).
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 */
void nullifyArrayDesc(void* desc, int rank);


/**
 * Verify an array descriptor.
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @return       0 if the descriptor is valid, 1 otherwise
 */
int verifyArrayDesc(void* desc, int rank);


/**
 * Returns the type of hidden descriptors used by the compiler
 *
 * @return       hidden descriptor type
 */
HiddenDescType hiddenArrayDescType();


/**
 * Returns the symbol name of a module procedure, if the module name
 * is not null, otherwise returns the name of the procedure.
 *
 * Note: static memory is used for the return value so it must be
 * copied if retained because the memory is overwritten at each call.
 *
 * @param fun_name   the name of the procedure
 * @param mod_name   the module name (NULL if a global procedure)
 * @return           symbol name
 */
char* getMangledName(char* fun_name, char* mod_name);


/**
 * Prints all fields in the array descriptor.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 */
void printArrayDesc(void* desc, int rank);


#ifdef __cplusplus
}
#endif

#endif /*__H_*/
