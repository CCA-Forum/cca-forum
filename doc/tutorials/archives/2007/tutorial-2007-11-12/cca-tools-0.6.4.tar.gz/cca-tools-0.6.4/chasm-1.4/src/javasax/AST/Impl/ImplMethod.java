package AST.Impl;

import java.util.*;
import javax.swing.tree.*;

public class ImplMethod {
    String name;
    ImplArgument retArg;
    Vector arguments;

    public ImplMethod(String name) {
        this.name = name;
        retArg = null;
        arguments = new Vector();
    }

    public void setReturn(ImplArgument r) {
        retArg = r;
    }

    /**
     * Set the argument at the indicated 0-based position.
     */
    public void setArgument(ImplArgument a, int pos) {
        //
        // pad out vector with nulls up to the argument we want to add if
        // the vector isn't long enough.
        // 
        while (arguments.size() < pos) {
            arguments.addElement(null);
        }

        arguments.addElement(a);
    }

    public void addArgument(ImplArgument a) {
        arguments.addElement(a);
    }

    public String toString() {
        String s = "";
        ImplArgument arg;

        s += retArg.toString()+" "+name+"(";

        if (arguments.size() > 1) {
            for (int i = 0; i < arguments.size()-1; i++) {
                arg = (ImplArgument)arguments.elementAt(i);
                s += arg.toString()+", ";
            }
            arg = (ImplArgument)arguments.elementAt(arguments.size()-1);
            s += arg.toString()+")";
        } else {
            if (arguments.size() == 0) {
                s += ")";
            } else {
                arg = (ImplArgument)arguments.elementAt(0);
                s += arg.toString()+")";
            }
        }

        return s;
    }

    public void createJTree(DefaultMutableTreeNode n) {
        n.add(new DefaultMutableTreeNode("METHOD: "+this.toString()));
    }
}

