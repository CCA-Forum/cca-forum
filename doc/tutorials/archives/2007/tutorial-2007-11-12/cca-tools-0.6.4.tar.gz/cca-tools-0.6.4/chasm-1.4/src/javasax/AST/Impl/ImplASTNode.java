package AST.Impl;

import javax.swing.tree.*;

public interface ImplASTNode {
    public void createJTree(DefaultMutableTreeNode root);

    public String toString();
}
