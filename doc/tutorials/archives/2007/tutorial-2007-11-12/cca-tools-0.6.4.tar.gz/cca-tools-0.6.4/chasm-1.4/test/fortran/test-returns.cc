#include "chasm_call.h"
#include <string.h>
#include <stdio.h>


int main(int argc, char* argv[])
{
  bool flag;
  int nErrors = 0;

  F90Global::RTN_VOID();

  flag = F90Global::RTN_TRUE();
  if (flag != true) {
    printf("  ERROR calling RTN_TRUE(), rtn = %d\n", flag);
    nErrors += 1;
  }
    
  flag = F90Global::RTN_FALSE();
  if (flag != false) {
    printf("  ERROR calling RTN_FALSE(), rtn = %d\n", flag);
    nErrors += 1;
  }
    
  std::string str;
  F90Global::RTN_STRING(str);
  //  if (strcmp(str.c_str(), "Hello, world!") != 0) {
  if (str != "Hello, world!") {
    printf("  ERROR calling RTN_STRING(), rtn = %s\n", str.c_str());
    nErrors += 1;
  }


  short s = F90Global::RTN_SHORT();
  if (s != 33) {
    printf("  ERROR calling RTN_SHORT(), rtn = %d\n", s);
    nErrors += 1;
  }
    
  if (nErrors == 0) {
    printf("\n  SUCCESSFUL completion of test-returns\n\n");
  } else {
    printf("\n  %d FAILURES in test-returns\n\n", nErrors);
  }

  return 0;
}
