package ChasmXML;

import java.io.PrintStream;

/**
 * Class representing a field of a class.
 */
public class XMLField extends XMLTypedEntity {
    String name;
    
    public XMLField(String name) {
        this.name = name;
    }
    
    public void toXML(PrintStream ps, int depth) {
    }
}
