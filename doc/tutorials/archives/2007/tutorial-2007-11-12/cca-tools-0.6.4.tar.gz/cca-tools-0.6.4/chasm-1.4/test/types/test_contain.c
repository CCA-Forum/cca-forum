#include <stdio.h>
#include <F90Compiler.h>

#ifdef F90_ABSOFT
#  include <compilers/Absoft_dv.h>
#  define dope_vec dope_vec_Absoft
#  define dope_vec_hidden dope_vec
#  ifdef CHASM_ARCH_LINUX
#    define PARTICLE_ALL_DOUBLE_SIZE
#  endif
#  define DESC_SIZE_HEAD (6*sizeof(long))
#  define DESC_SIZE_DIM  (3*sizeof(long))
#  define DESC_SIZE_PAD  0
#endif

#ifdef F90_ALPHA
#  include <compilers/Alpha_dv.h>
#  define dope_vec dope_vec_Alpha
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_CRAY
#  include <compilers/Cray_dv.h>
#  define dope_vec dope_vec_Cray
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_IBMXL
#  include <compilers/IBMXL_dv.h>
#  define dope_vec dope_vec_IBMXL
#  define dope_vec_hidden dope_vec_hidden_IBMXL
#  define DESC_SIZE_HEAD (5*sizeof(long))
#  define DESC_SIZE_DIM  (3*sizeof(long))
#  define DESC_SIZE_PAD  0
#endif

#ifdef F90_INTEL
#  include <compilers/Intel_dv.h>
#  define dope_vec dope_vec_Intel
#  define dope_vec_hidden dope_vec
#  define PARTICLE_ALL_DOUBLE_SIZE
#  define DESC_SIZE_HEAD (6*sizeof(long))
#  define DESC_SIZE_DIM  (3*sizeof(long))
#  define DESC_SIZE_PAD  0
#endif

#ifdef F90_INTEL_7
#  include <compilers/Intel_7_dv.h>
#  define dope_vec dope_vec_Intel_7
#  define dope_vec_hidden dope_vec
#  define DESC_SIZE_HEAD (7*sizeof(long))
#  define DESC_SIZE_DIM  (3*sizeof(long))
#  define DESC_SIZE_PAD  (1*sizeof(long))
#endif

#ifdef F90_LAHEY
#  include <compilers/Lahey_dv.h>
#  define dope_vec dope_vec_Lahey
#  define desc_or_hidden hidden
#  undef dope_vec_hidden
#  define dope_vec_hidden dope_vec_hidden_Lahey
#  define USE_HIDDEN
#  define PARTICLE_ALL_DOUBLE_SIZE
#endif

#ifdef F90_MIPSPRO
#  include <compilers/MIPSpro_dv.h>
#  define dope_vec dope_vec_MIPSpro
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_NAG
#  include <compilers/NAG_dv.h>
#  define dope_vec dope_vec_NAG
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_PGI
#  include <compilers/PGI_dv.h>
#  define dope_vec dope_vec1d_PGI
#  define desc_or_hidden dope_vec
#  undef dope_vec_hidden
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_SUNWSPRO
#  include <compilers/SUNWspro_dv.h>
#  define dope_vec dope_vec1d_SUNWspro
#  define dope_vec_hidden dope_vec
#endif

#if   defined (F90_SYM_CASE_LOWER)
#  define recv_visc_type F90_SYMBOL(recv_visc_type)
#  define recv_block_type F90_SYMBOL(recv_block_type)
#elif defined (F90_SYM_CASE_UPPER)
#  define recv_visc_type F90_SYMBOL(RECV_VISC_TYPE)
#  define recv_block_type F90_SYMBOL(RECV_BLOCK_TYPE)
#else
#  define recv_visc_type F90_SYMBOL(recv_visc_type)
#  define recv_block_type F90_SYMBOL(recv_block_type)
#endif


typedef struct {
  char dv[DESC_SIZE_HEAD + DESC_SIZE_DIM + DESC_SIZE_PAD];
} F90ArrayDesc_1D;

typedef struct {
  char dv[DESC_SIZE_HEAD + 2*DESC_SIZE_DIM + DESC_SIZE_PAD];
} F90ArrayDesc_2D;


typedef struct {
  F90ArrayDesc_2D dv_t;
  int imax;
  int jmax;
} visc_type;

typedef struct {
  F90ArrayDesc_2D dv_a;
  F90ArrayDesc_1D dv_visc;
  float b[3];
  float c;
  float d;
  int imax;
  int jmax;
} block_type;


void recv_visc_type(visc_type* t)
{
  dope_vec* dv = (dope_vec*) &t->dv_t;
  printf(" imax = %d, jmax = %d\n", t->imax, t->jmax);
}

void recv_block_type(block_type* t)
{
  dope_vec* dv_a = (dope_vec*) &t->dv_a;
  dope_vec* dv_visc = (dope_vec*) &t->dv_visc;
  visc_type* v = (visc_type*) dv_visc->base_addr;
  printf(" imax = %d, jmax = %d\n", t->imax, t->jmax);
  printf(" imax = %d, jmax = %d\n", v->imax, v->jmax);
  printf(" b = %f %f %f\n", t->b[0], t->b[1], t->b[2]);
  printf(" c,d = %f %f\n", t->c, t->d);
}
