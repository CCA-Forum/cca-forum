#include "chasm_call.h"
#include <stdio.h>

int main(int argc, char* argv[])
{
  int i;
  double tstep = 1.0;
  PARTICLEMOD::PARTICLE particle;

  double position[] = {1.1, 1.2, 1.3};
  double velocity[] = {0.5, 0.0, 0.1};

  int rank = 1;
  unsigned long size[] = {3};

  F90::Array<double> pos(position, rank, size);
  F90::Array<double> vel(velocity, rank, size);

  CHASM_INIT_PARTICLEMOD();

  printf("Before particle move.....\n");

  PARTICLEMOD::PARTICLECREATE(particle, pos, vel);
  PARTICLEMOD::PARTICLEPRINT(particle);

  printf("After particle move.....\n");

  PARTICLEMOD::PARTICLEMOVE(particle, tstep);
  PARTICLEMOD::PARTICLEPRINT(particle);

  return 0;
}
