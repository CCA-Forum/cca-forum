package AST.Impl;

import java.util.*;
import javax.swing.tree.*;

/**
 * This file contains the 'abstract syntax' nodes for use by a SAX
 * parser of implementation files.
 */
public class ImplScope {
    Vector methods, scopes;
    String name;

    public ImplScope(String name) {
        this.name = name;
        methods = new Vector();
        scopes = new Vector();
    }

    public void addMethod(ImplMethod m) {
        methods.addElement(m);
    }

    public void addScope(ImplScope s) {
        scopes.addElement(s);
    }

    public void createJTree(DefaultMutableTreeNode n) {
        DefaultMutableTreeNode me = new DefaultMutableTreeNode("SCOPE:"+name);
        
        for (int i = 0; i < scopes.size(); i++) {
            ImplScope s = (ImplScope)scopes.elementAt(i);
            s.createJTree(me);
        }

        for (int i = 0; i < methods.size(); i++) {
            ImplMethod m = (ImplMethod)methods.elementAt(i);
            m.createJTree(me);
        }

        n.add(me);
    }
}
