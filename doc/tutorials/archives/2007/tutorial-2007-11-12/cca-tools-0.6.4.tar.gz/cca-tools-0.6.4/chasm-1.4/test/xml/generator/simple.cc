//
// simple.cc : a collection of simple classes for testing C++ features
//

//
// a forward declaration of a class
//
class i_am_forward;

//
// a simple class...
//
class simple {
private:
  int private_int;

protected:
  float protected_float;

public:
  simple(int i); // overload default constructor.  XML should just contain
                 // this

  //
  // make sure overloading stuff comes out right.
  //
  void blah(int i);
  void blah(float f);

  // 
  // normal method with pointers 
  //
  void foo(int *ip);

  // 
  // normal, overloaded in derived class
  //
  void bar(char *str, int i);

  //
  char public_char;

private:
  void naughtybits(); // tee hee hee
};

//
// test stuff that comes with derived classes
//
class less_simple : simple {
public:
  void blah(char c); // overloading in derived classes.

  void bar(char *str); // overloading in derived classes.
};

//
// namespace stuff
//

namespace space_of_names {

  class spaced {
  public:
    void boo();
  };

};
