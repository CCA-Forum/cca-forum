/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 *
 * F90CopyDesc.c - this file is automatically created
 *
 * The functions in this file make a copy of a Fortran array descriptor.
 * They are called by the corresponding F90_CreateArrayXXX procedure.
 *
 */

#include <CompilerCharacteristics.h>
#include <F90CreateArray.h>
#include <stdlib.h>

/*-----------------------------------------------------------------------*/
void F90_CopyDesc1DI1(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 1, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc1DI1(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc1DI2(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 1, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc1DI2(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc1DI(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 1, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc1DI(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc1DI4(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 1, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc1DI4(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc1DI8(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 1, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc1DI8(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc1DL1(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 1, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc1DL1(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc1DL2(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 1, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc1DL2(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc1DL(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 1, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc1DL(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc1DL4(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 1, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc1DL4(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc1DL8(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 1, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc1DL8(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc1DR(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 1, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc1DR(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc1DD(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 1, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc1DD(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc1DC(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 1, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc1DC(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc1DDC(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 1, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc1DDC(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc2DI1(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 2, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc2DI1(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc2DI2(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 2, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc2DI2(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc2DI(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 2, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc2DI(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc2DI4(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 2, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc2DI4(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc2DI8(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 2, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc2DI8(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc2DL1(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 2, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc2DL1(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc2DL2(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 2, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc2DL2(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc2DL(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 2, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc2DL(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc2DL4(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 2, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc2DL4(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc2DL8(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 2, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc2DL8(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc2DR(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 2, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc2DR(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc2DD(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 2, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc2DD(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc2DC(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 2, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc2DC(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc2DDC(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 2, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc2DDC(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc3DI1(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 3, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc3DI1(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc3DI2(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 3, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc3DI2(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc3DI(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 3, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc3DI(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc3DI4(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 3, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc3DI4(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc3DI8(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 3, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc3DI8(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc3DL1(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 3, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc3DL1(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc3DL2(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 3, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc3DL2(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc3DL(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 3, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc3DL(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc3DL4(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 3, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc3DL4(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc3DL8(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 3, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc3DL8(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc3DR(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 3, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc3DR(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc3DD(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 3, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc3DD(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc3DC(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 3, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc3DC(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc3DDC(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 3, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc3DDC(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc4DI1(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 4, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc4DI1(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc4DI2(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 4, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc4DI2(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc4DI(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 4, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc4DI(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc4DI4(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 4, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc4DI4(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc4DI8(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 4, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc4DI8(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc4DL1(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 4, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc4DL1(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc4DL2(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 4, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc4DL2(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc4DL(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 4, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc4DL(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc4DL4(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 4, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc4DL4(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc4DL8(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 4, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc4DL8(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc4DR(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 4, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc4DR(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc4DD(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 4, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc4DD(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc4DC(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 4, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc4DC(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc4DDC(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 4, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc4DDC(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc5DI1(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 5, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc5DI1(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc5DI2(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 5, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc5DI2(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc5DI(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 5, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc5DI(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc5DI4(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 5, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc5DI4(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc5DI8(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 5, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc5DI8(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc5DL1(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 5, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc5DL1(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc5DL2(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 5, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc5DL2(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc5DL(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 5, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc5DL(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc5DL4(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 5, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc5DL4(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc5DL8(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 5, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc5DL8(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc5DR(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 5, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc5DR(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc5DD(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 5, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc5DD(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc5DC(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 5, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc5DC(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc5DDC(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 5, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc5DDC(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc6DI1(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 6, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc6DI1(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc6DI2(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 6, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc6DI2(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc6DI(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 6, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc6DI(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc6DI4(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 6, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc6DI4(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc6DI8(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 6, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc6DI8(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc6DL1(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 6, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc6DL1(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc6DL2(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 6, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc6DL2(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc6DL(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 6, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc6DL(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc6DL4(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 6, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc6DL4(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc6DL8(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 6, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc6DL8(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc6DR(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 6, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc6DR(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc6DD(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 6, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc6DD(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc6DC(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 6, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc6DC(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc6DDC(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 6, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc6DDC(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc7DI1(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 7, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc7DI1(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc7DI2(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 7, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc7DI2(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc7DI(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 7, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc7DI(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc7DI4(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 7, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc7DI4(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc7DI8(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 7, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc7DI8(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc7DL1(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 7, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc7DL1(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc7DL2(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 7, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc7DL2(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc7DL(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 7, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc7DL(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc7DL4(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 7, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc7DL4(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc7DL8(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 7, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc7DL8(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc7DR(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 7, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc7DR(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc7DD(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 7, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc7DD(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc7DC(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 7, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc7DC(void* ptr) { free(ptr); }


/*-----------------------------------------------------------------------*/
void F90_CopyDesc7DDC(void** dest, void* src)
{
  *dest = createArrayDesc(src, 0, 7, F90_ArrayPointerInDerived);
}

/*-----------------------------------------------------------------------*/
void F90_Dealloc7DDC(void* ptr) { free(ptr); }


