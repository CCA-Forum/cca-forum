/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.jar.*;
import ChasmXML.*;

/****
     Reflection based Java->XML generator.  Using reflection, it traverses
     a hierarchy of directories and examines every class to see whether or
     not it belongs in the XML output and generates the proper markup.
     No PDT needed - Java Reflection is nice enough to let us do everything
     PDT does, but without the source code!  (Ultra cool).  So no source
     needed, just class files.
     
     Todo:
       - Output XML instead of the text we dump right now.  It proved that
         we have all of the info we need - now make it usable.
       - Possibly take a jar file and iterate over its contents.
       
     No guarantees or anything about this - it's a two-hour flight hack.

     -matt sottile / matt@lanl.gov
     8/15/02
 ****/

/**
 * Driver for XML generator based on reflection.  Decided to leave everything
 * as-is, hence the staticness.
 */
public class JavaXMLGen {
    //
    // data fields -- they were put out here instead of inside the methods
    // when examineDirectory went recursive.
    //
    static ClassInterrogator   ci;
    static ClassLoader         cl;
    static ClassFilenameFilter cff;

    /**
     * main entry point
     */
    public static void main(String args[]) {
	cl = ClassLoader.getSystemClassLoader();
	cff = new ClassFilenameFilter();
	ci = new ClassInterrogator();

	if (args.length != 1) {
	    System.err.println("Specify a directory or .jar file.");
	    System.exit(0);
	}

	try {
	    // assume arg 0 points at the root directory of the class
	    // hierarchy that is to be processed.
	    //
	    File rootDir = new File(args[0]);
	    
	    // must be a directory
	    //
	    if (rootDir.isDirectory()) {
		String libline = "<library name=\""+rootDir.getName()+"\" ";
		libline += "ver=\"1.0\" lang=\"java\">";
		
		System.out.println(libline);
		
		examineDirectory(rootDir,"");
		
		System.out.println("</library>");
	    } else {
		// ok - maybe it's a jar file
		JarFile jar = new JarFile(new File(args[0]));
		//
		// ************IMPORTANT*************
		// 
		// jar files don't let you get a File object from
		// an entry (or so it seems) -- so we need to take the input
		// stream, suck the class into memory and see what it looks
		// like to reflection.  Need to be intelligent about what
		// gets sucked in from the jarfile.  Also might require a
		// classloader based in InputStream->array of bytes->instance
		// type stuff.  (Look for old RMI trick - that had a class
		// loader I whipped up to do something like that.)
		//
		// --- mjs (8/15/02, somewhere over Washington)
		//
	    }	
	} catch (Exception e) {
	    System.err.println("JavaXMLGen :: "+e.toString());
	}

	ci.dumpXML(System.out);
    }
    
    /*
     * recursively descend through directories, using the
     * class interrogator to figure out the characteristics of each
     * class.  Use recursion and directory names to determine scoping.
     */
    public static void examineDirectory(File root,String name) 
	throws Exception {

	if (root.isDirectory() != true)
	    return;

	File contents[] = root.listFiles();
	for (int i = 0; i < contents.length; i++) {
	    if (contents[i].isDirectory()) {
		ci.enterScope(contents[i].getName());
		examineDirectory(contents[i],name+contents[i].getName()+".");
	    } else {
		if (cff.accept(null,contents[i].getName())) {
		    Class c = cl.loadClass(name+cff.lastClassName);
		    System.err.println();
		    System.err.println();
		    ci.addToScope(cff.lastClassName);
		    ci.examineClass(c);
		}
	    }
	}
	
	ci.exitScope();
    }
}

/**
 * originally wanted to use this to have listFiles in java.io.File do
 * the filtering for me, but that didn't work out.  Right now it makes
 * the task of finding if a filename is likely to be a class, and then
 * getting the name w/out '.class', pretty simple.
 */
class ClassFilenameFilter implements FilenameFilter {
    public String lastClassName = null;

    // Determine if the filename can possibly be a valid class.  Assuming
    // this means one dot, and a suffix '.class'.
    public boolean accept(File dir, String name) {
	StringTokenizer tok = new StringTokenizer(name,".");
	int count = 0;
	String last = null;
	String last2 = null;

	while (tok.hasMoreTokens()) {
	    count++;
	    last2 = last;
	    last = tok.nextToken();
	}

	if (count == 2 && last.equals("class")) {
	    lastClassName = last2;
	    return true;
	}

	return false;
    }
}

/**
 * Object that can look over a class and decide what to do with it.
 */
class ClassInterrogator {
    // scopes are necessary since we need to process everything and then
    // dump them out later.  we need to remember the scope information.
    XMLScope currentScope;

    public ClassInterrogator() {
	currentScope = new XMLScope();
    }

    public void dumpXML(PrintStream ps) {
	currentScope.toXML(ps,0);
    }

    public void addToScope(String cname) {
	currentScope.addMember(cname);
    }

    public void enterScope(String sname) {
	currentScope = new XMLScope(sname,currentScope);
    }

    public void exitScope() {
	dumpXML(System.out);
	currentScope = currentScope.getParent();
    }

    public XMLMethod examineMethod(Method m) {
	int mods = m.getModifiers();
	String line = "";

	XMLMethod meth = new XMLMethod(m.getName(),m.toString(),
				       Modifier.isAbstract(mods),
				       Modifier.isStatic(mods),
				       Modifier.isFinal(mods),
				       true);
	
        // iterate over method arguments
        //

        // get return value
        //

        return meth;
    }

    public void examineClass(Class c) {
	// this would be stupid, so exit if some moron sent null in.
	if (c == null) {
	    return;
	}
	
	// name
	String name = c.getName();
	
	// modifiers
	boolean isPublic, isAbstract, isFinal;
	int m = c.getModifiers();

	if (Modifier.isPublic(m)) isPublic = true;
	else isPublic = false;

	if (Modifier.isAbstract(m)) isAbstract = true;
	else isAbstract = false;

	if (Modifier.isFinal(m)) isFinal = true;
	else isFinal = false;

        //
        // create the XML entity
        //	
        XMLClass theClass = new XMLClass(name,isAbstract,isPublic,isFinal);
	
        //
	// class inheritance
	//
        Class parent = c.getSuperclass();
	if (parent != null) {
            theClass.setParent(parent.getName());
	}

	//
	// interface implementation
        //
	Class[] interfaces = c.getInterfaces();
	for (int i = 0; i < interfaces.length; i++) {
            theClass.addInterface(interfaces[i].getName());
	}
	
        //
	// look at methods
        //
	Method[] theMethods = c.getMethods();
	for (int i = 0; i < theMethods.length; i++) {
	    if (theMethods[i].getDeclaringClass() == c) {
		theClass.addMethod(examineMethod(theMethods[i]));
	    }
	}

        //
	// fields too
        //
	Field[] publicFields = c.getFields();
	for (int i = 0; i < publicFields.length; i++) {
	    String fieldName = publicFields[i].getName();
	    Class typeClass = publicFields[i].getType();
	    String fieldType = typeClass.getName();
	    System.out.println("Name: " + fieldName + 
			       ", Type: " + fieldType);
	}

        theClass.toXML(System.out,1);
    }
}

