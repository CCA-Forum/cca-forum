#include <CompilerCharacteristics.h>
#include <F90Compiler.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>


#if defined(F90_SYM_CASE_LOWER) || defined(F90_SYM_CASE_MIXED)
#  define test_reset F90_SYMBOL_COND( test_reset )
#endif /* F90_SYM_CASE_LOWER || F90_SYM_CASE_MIXED */

#ifdef F90_SYM_CASE_UPPER
#  define test_reset F90_SYMBOL_COND( TEST_RESET )
#endif /* F90_SYM_CASE_UPPER */



int test_reset(int* pRank, void* a, int* elem_size, void* s,
	       void* h1, void* h2, void* h3, void* h4)
{
  F90_CompilerCharacteristics cc;
  int i, rank, rc;
  unsigned long ex[7];
  long size, stride, lb[7], sm[7];
  void *dv_a, *dv_s;
  void *hid_a, *hid_s;
  int *shape, *base_addr;

  rank = *pRank;
  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  /* figure out which hidden parameters to use */

  hid_a = h1;
  hid_s = h2;

  dv_a = cc.createArrayDesc(a, hid_a, rank, F90_ArrayPointer);
  dv_s = cc.createArrayDesc(s, hid_s, 1, F90_Array);

  shape = cc.getArrayBaseAddress(dv_s, 1);

  /* create array layout */
  size = 1;
  stride = *elem_size;
  for (i = rank - 1; i >= 0 ; i--) {
    lb[i] = 1;
    ex[i] = shape[i];
    sm[i] = stride;
    size = size*shape[i];
    stride *= shape[i];
  }

  /*
   * create PyNum array here (base_addr is pointer to array base)
   */

  base_addr = (int*) malloc(size * (*elem_size));
  assert(base_addr);

  for (i = 0; i < size; i++) {
    base_addr[i] = i+1;
  }

  /* reset descriptor with new information */
  rc = cc.resetArrayDesc(dv_a, base_addr, rank, lb, ex, sm);
  if (rc) {
    fprintf(stderr, "ERROR in return value from resetArrayDesc\n");
  }

  /* copy desc info back to stack variables (this associates the array) */
  rc = cc.copyToArrayDescAndHidden(dv_a, rank, F90_ArrayPointer, a, hid_a);
  if (rc) {
    fprintf(stderr, "ERROR in return value from copyToArrayDescAndHidden\n");
  }

  free(dv_a);
  free(dv_s);

  return 0;
}
