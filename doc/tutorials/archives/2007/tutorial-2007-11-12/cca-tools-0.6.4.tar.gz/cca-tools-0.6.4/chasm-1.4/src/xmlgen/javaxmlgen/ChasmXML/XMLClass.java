package ChasmXML;

import java.util.Vector;
import java.io.PrintStream;

/**
 * Class representing a java class structure element in the XML
 * representation of the interface.
 */
public class XMLClass extends XMLEntity {
    private String name;
    private boolean isAbstract, isPublic, isFinal;
    private String parent;
    private Vector implementList;
    private Vector methods;
    private Vector fields;
    
    public XMLClass(String name, boolean isA, boolean isP, boolean isF) {
        this.name = name;
        isAbstract = isA;
        isPublic = isP;
        isFinal = isF;
        implementList = new Vector();
        fields = new Vector();
        methods = new Vector();
        parent = null;
    }
    
    public void addInterface(String i) {
        implementList.addElement(i);
    }
    
    public void addField(XMLField f) {
        fields.addElement(f);
    }
    
    public void addMethod(XMLMethod m) {
        methods.addElement(m);
    }
    
    public void setParent(String p) {
        parent = new String(p);
    }
    
    public void toXML(PrintStream ps, int depth) {
        String line = "<structure kind=\"jclass\" name=\""+name+"\" ";
        
        String implList = "";
        for (int i = 0; i < implementList.size(); i++) {
            String s = (String)implementList.elementAt(i);
            implList += " "+s;
        }
        
        // dump parent, implmements list
        if (parent != null) {
            line += "parent=\"" + parent + implList + "\" ";
        } else {
            if (!implList.equals("")) {
                line += "parent=\"" + implList+"\" ";
            }
        }
        
        if (isAbstract) line += "classkind=\"abstract\" ";
        else if (isFinal) line += "classkind=\"final\" ";
        
        line += ">";
        
        // dump methods and fields
        
        indent(ps,line,depth);
        
        for (int i = 0; i < methods.size(); i++) {
            Object o = methods.elementAt(i);
            if (o instanceof XMLMethod) {
                XMLMethod xmlm = (XMLMethod)o;
                xmlm.toXML(ps,depth++);
            } else {
                System.err.println("Non-XMLMethod object found in "+
                                   "methods for class: "+name);
            }
        }

        indent(ps,"</structure>",depth);
    }
}
