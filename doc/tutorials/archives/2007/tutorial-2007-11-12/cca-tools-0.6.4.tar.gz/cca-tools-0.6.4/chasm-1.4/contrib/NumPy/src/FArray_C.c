#include <Python.h>
#include <Numeric/arrayobject.h>
#include <F90Compiler.h>


#if   defined (F90_SYM_CASE_LOWER)
#  define put_array  F90_SYMBOL(put_array)
#elif defined (F90_SYM_CASE_UPPER)
#  define put_array  F90_SYMBOL(PUT_ARRAY)
#endif


/**
 * Creates a Python Numeric array and puts it in the provided dictionary.
 *
 * This function is assumed to be called by Fortran as the strides
 * are adjusted to represent a column-major array.
 * 
 * @param dict       the Python dictionary in which to put the array
 * @param name       the key to associate with the array
 * @param data       base address of the array
 * @param rank       the rank of the array
 * @param shape      the shape of the array (extent in each dimension)
 * @param data_type  the data type of the array
 *                   ('i' (105) for an int,
 *                    'l' (108) for a long,
 *                    'f' (102) for a float,
 *                    'd' (100) for a double)
 * @param len_name   length of the string name (Fortran compiler adds this
 *                   parameter automatically, location could be compiler
 *                   dependent, so must test on compiler)
 */
void put_array(PyObject* dict, char* name,
	       void* data, int* rank, int* shape, int* data_type, int len_name)
{
  PyObject *key, *array;
  int i, elsize;
  int* strides;
  char type = *data_type;
  static first = 1;

  if (first) {
    import_array();	/* Magic handshake for Numeric */
    first = 0;
  }

  switch(type) {
    case 'i':  elsize = sizeof(int);     break;
    case 'l':  elsize = sizeof(long);    break;
    case 'f':  elsize = sizeof(float);   break;
    case 'd':  elsize = sizeof(double);  break;
    default: {
      Py_FatalError("Unknown data type in put_array");
    }
  }

  key = PyString_FromStringAndSize(name, len_name);
  array = PyArray_FromDimsAndData(*rank, shape, type, (char*) data);

  if ( elsize != ((PyArrayObject*) array)->descr->elsize ) {
      Py_FatalError("Incorrect data element size in put_array");
  }

  PyDict_SetItem(dict, key, array);

  /* set strides to be row-major */

  strides = ((PyArrayObject*) array)->strides;
  strides[0] = elsize;
  for (i = 1; i < *rank; i++) strides[i] = strides[i-1] * shape[i-1];
}
