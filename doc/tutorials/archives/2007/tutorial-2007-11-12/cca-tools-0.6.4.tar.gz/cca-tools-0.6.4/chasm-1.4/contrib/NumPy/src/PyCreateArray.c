#include <CompilerCharacteristics.h>
#include <F90Compiler.h>



/* NOTE, need to add element size as input */


int PyCreateArray(int* pRank, void* a, void* s, void* hid_a, void* hid_s)
{
  CompilerCharacteristics cc;
  int i, rank, rc;
  unsigned long ex[7];
  long lb[7], sm[7];
  dope_vec *dv_a, *dv_s;
  int* shape;

  rank = *pRank;
  setCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  dv_a = cc.createArrayDesc(a, hidden_a, rank, ArrayPointer);
  dv_s = cc.createArrayDesc(s, hidden_s, 1, Array);

  shape = cc.getArrayBaseAddress(s);

  /* create array layout */
  for (i = 0; i < rank; i++) {
    lb[i] = 1;
    ex[i] = shape[i];
    sm[i] = FIXME; /* need to work this out */
  }

  /*
   * create PyNum array here (base_addr is pointer to array base)
   */


  /* reset descriptor with new information */
  rc = resetArrayDesc(dv_a, base_addr, rank, lb, ex, sm);

  /* copy desc info back to stack variables (this associates the array) */
  rc = copyToArrayDescAndHidden(dv_a, rank, ArrayPointer, a, hid_a);

  free(dv_a);
  free(dv_s);

  return 0;
}
