package ChasmXML;

import java.io.PrintStream;

/**
 * XML objects extend this
 */
public abstract class XMLEntity {
    public abstract void toXML(PrintStream ps, int depth);

    protected void indent(PrintStream ps, String l, int depth) {
        String os = "";
        for (int i = 0; i < depth; i++) os += "  ";
        ps.println(os+l);
    }
}
