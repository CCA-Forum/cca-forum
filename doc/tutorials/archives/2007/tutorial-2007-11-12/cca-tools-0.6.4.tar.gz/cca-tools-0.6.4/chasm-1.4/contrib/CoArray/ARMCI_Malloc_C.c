/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 *
 * ARMCI_Malloc_C.c - this file is automatically created
 *
 * The C procedures in this file allocate and free ARMCI based arrays and
 * are designed to be called from Fortran.
 *
 * -------------------------------------------------------------------------
 */

#include "CompilerCharacteristics.h"
#include <F90Compiler.h>
#include <armci.h>
#include <arraydesc.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

typedef struct {
  float real;
  float imag;
} complex_t;

typedef struct {
  double real;
  double imag;
} dcomplex_t;

int armci_init_loc = 0;

#if defined(F90_SYM_CASE_LOWER)
#  define ARMCI_Malloc_I1 F90_SYMBOL( armci_malloc_i1 )
#  define ARMCI_Free_I1 F90_SYMBOL( armci_free_i1 )
#  define ARMCI_Malloc_I2 F90_SYMBOL( armci_malloc_i2 )
#  define ARMCI_Free_I2 F90_SYMBOL( armci_free_i2 )
#  define ARMCI_Malloc_I F90_SYMBOL( armci_malloc_i )
#  define ARMCI_Free_I F90_SYMBOL( armci_free_i )
#  define ARMCI_Malloc_I8 F90_SYMBOL( armci_malloc_i8 )
#  define ARMCI_Free_I8 F90_SYMBOL( armci_free_i8 )
#  define ARMCI_Malloc_R F90_SYMBOL( armci_malloc_r )
#  define ARMCI_Free_R F90_SYMBOL( armci_free_r )
#  define ARMCI_Malloc_D F90_SYMBOL( armci_malloc_d )
#  define ARMCI_Free_D F90_SYMBOL( armci_free_d )
#  define ARMCI_Malloc_C F90_SYMBOL( armci_malloc_c )
#  define ARMCI_Free_C F90_SYMBOL( armci_free_c )
#  define ARMCI_Malloc_DC F90_SYMBOL( armci_malloc_dc )
#  define ARMCI_Free_DC F90_SYMBOL( armci_free_dc )
#endif /* F90_SYM_CASE_LOWER */

#if defined(F90_SYM_CASE_MIXED)
#  define ARMCI_Malloc_I1 F90_SYMBOL( ARMCI_Malloc_I1 )
#  define ARMCI_Free_I1 F90_SYMBOL( ARMCI_Free_I1 )
#  define ARMCI_Malloc_I2 F90_SYMBOL( ARMCI_Malloc_I2 )
#  define ARMCI_Free_I2 F90_SYMBOL( ARMCI_Free_I2 )
#  define ARMCI_Malloc_I F90_SYMBOL( ARMCI_Malloc_I )
#  define ARMCI_Free_I F90_SYMBOL( ARMCI_Free_I )
#  define ARMCI_Malloc_I8 F90_SYMBOL( ARMCI_Malloc_I8 )
#  define ARMCI_Free_I8 F90_SYMBOL( ARMCI_Free_I8 )
#  define ARMCI_Malloc_R F90_SYMBOL( ARMCI_Malloc_R )
#  define ARMCI_Free_R F90_SYMBOL( ARMCI_Free_R )
#  define ARMCI_Malloc_D F90_SYMBOL( ARMCI_Malloc_D )
#  define ARMCI_Free_D F90_SYMBOL( ARMCI_Free_D )
#  define ARMCI_Malloc_C F90_SYMBOL( ARMCI_Malloc_C )
#  define ARMCI_Free_C F90_SYMBOL( ARMCI_Free_C )
#  define ARMCI_Malloc_DC F90_SYMBOL( ARMCI_Malloc_DC )
#  define ARMCI_Free_DC F90_SYMBOL( ARMCI_Free_DC )
#endif /* F90_SYM_CASE_MIXED */

#if defined(F90_SYM_CASE_UPPER)
#  define ARMCI_Malloc_I1 F90_SYMBOL( ARMCI_MALLOC_I1 )
#  define ARMCI_Free_I1 F90_SYMBOL( ARMCI_FREE_I1 )
#  define ARMCI_Malloc_I2 F90_SYMBOL( ARMCI_MALLOC_I2 )
#  define ARMCI_Free_I2 F90_SYMBOL( ARMCI_FREE_I2 )
#  define ARMCI_Malloc_I F90_SYMBOL( ARMCI_MALLOC_I )
#  define ARMCI_Free_I F90_SYMBOL( ARMCI_FREE_I )
#  define ARMCI_Malloc_I8 F90_SYMBOL( ARMCI_MALLOC_I8 )
#  define ARMCI_Free_I8 F90_SYMBOL( ARMCI_FREE_I8 )
#  define ARMCI_Malloc_R F90_SYMBOL( ARMCI_MALLOC_R )
#  define ARMCI_Free_R F90_SYMBOL( ARMCI_FREE_R )
#  define ARMCI_Malloc_D F90_SYMBOL( ARMCI_MALLOC_D )
#  define ARMCI_Free_D F90_SYMBOL( ARMCI_FREE_D )
#  define ARMCI_Malloc_C F90_SYMBOL( ARMCI_MALLOC_C )
#  define ARMCI_Free_C F90_SYMBOL( ARMCI_FREE_C )
#  define ARMCI_Malloc_DC F90_SYMBOL( ARMCI_MALLOC_DC )
#  define ARMCI_Free_DC F90_SYMBOL( ARMCI_FREE_DC )
#endif /* F90_SYM_CASE_UPPER */


/** ------------------------------------------------------------------- */
void ARMCI_Malloc_I1(void* dv, int* rank, int lb_in[], int ub_in[], int* rc)
{
  F90_CompilerCharacteristics cc;
  int i;
  void* data;

  long lb[7], stride[7];
  unsigned long extent[7];
  index_size_t lb_armci[7], ub_armci[7];
  unsigned long elem_size = sizeof(char);

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  lb[0] = lb_in[0];
  extent[0] = 1 + ub_in[0] - lb_in[0];
  stride[0] = elem_size;
  lb_armci[0] = lb_in[0];
  ub_armci[0] = ub_in[0];

  for (i = 1; i < *rank; i++) {
    lb[i] = lb_in[1];
    extent[i] = 1 + ub_in[i] - lb_in[i];
    stride[i] = extent[i-1] * stride[i-1];
    lb_armci[i] = lb_in[i];
    ub_armci[i] = ub_in[i];
  }

  /*
   * Create array memory
   */

   if ( ! armci_init_loc ) {
     ARMCI_Init();
     armci_init_loc = 1;
   }

  _array_create(&data, elem_size, *rank, lb_armci, ub_armci);
  assert(data);

  *rc = cc.resetArrayDesc(dv, data, *rank, lb, extent, stride);
  if (*rc) {
    fprintf(stderr, "ERROR in resetting array descriptor\n");
    return;
  }
}

/** ------------------------------------------------------------------- */
void ARMCI_Free_I1(void* dv, int* rank, int* rc)
{
  F90_CompilerCharacteristics cc;
  void* data;

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  /*
   * Free array memory
   */
  data = cc.getArrayBaseAddress(dv, *rank);
  if (data == 0) {
    fprintf(stderr, "ERROR in getArrayBaseAddress\n");
    *rc = -1;
    return;
  }
  _array_free(data);   /* ARMCI call to free memory */
}

/** ------------------------------------------------------------------- */
void ARMCI_Malloc_I2(void* dv, int* rank, int lb_in[], int ub_in[], int* rc)
{
  F90_CompilerCharacteristics cc;
  int i;
  void* data;

  long lb[7], stride[7];
  unsigned long extent[7];
  index_size_t lb_armci[7], ub_armci[7];
  unsigned long elem_size = sizeof(short);

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  lb[0] = lb_in[0];
  extent[0] = 1 + ub_in[0] - lb_in[0];
  stride[0] = elem_size;
  lb_armci[0] = lb_in[0];
  ub_armci[0] = ub_in[0];

  for (i = 1; i < *rank; i++) {
    lb[i] = lb_in[1];
    extent[i] = 1 + ub_in[i] - lb_in[i];
    stride[i] = extent[i-1] * stride[i-1];
    lb_armci[i] = lb_in[i];
    ub_armci[i] = ub_in[i];
  }

  /*
   * Create array memory
   */

   if ( ! armci_init_loc ) {
     ARMCI_Init();
     armci_init_loc = 1;
   }

  _array_create(&data, elem_size, *rank, lb_armci, ub_armci);
  assert(data);

  *rc = cc.resetArrayDesc(dv, data, *rank, lb, extent, stride);
  if (*rc) {
    fprintf(stderr, "ERROR in resetting array descriptor\n");
    return;
  }
}

/** ------------------------------------------------------------------- */
void ARMCI_Free_I2(void* dv, int* rank, int* rc)
{
  F90_CompilerCharacteristics cc;
  void* data;

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  /*
   * Free array memory
   */
  data = cc.getArrayBaseAddress(dv, *rank);
  if (data == 0) {
    fprintf(stderr, "ERROR in getArrayBaseAddress\n");
    *rc = -1;
    return;
  }
  _array_free(data);   /* ARMCI call to free memory */
}

/** ------------------------------------------------------------------- */
void ARMCI_Malloc_I(void* dv, int* rank, int lb_in[], int ub_in[], int* rc)
{
  F90_CompilerCharacteristics cc;
  int i;
  void* data;

  long lb[7], stride[7];
  unsigned long extent[7];
  index_size_t lb_armci[7], ub_armci[7];
  unsigned long elem_size = sizeof(int);

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  lb[0] = lb_in[0];
  extent[0] = 1 + ub_in[0] - lb_in[0];
  stride[0] = elem_size;
  lb_armci[0] = lb_in[0];
  ub_armci[0] = ub_in[0];

  for (i = 1; i < *rank; i++) {
    lb[i] = lb_in[1];
    extent[i] = 1 + ub_in[i] - lb_in[i];
    stride[i] = extent[i-1] * stride[i-1];
    lb_armci[i] = lb_in[i];
    ub_armci[i] = ub_in[i];
  }

  /*
   * Create array memory
   */

   if ( ! armci_init_loc ) {
     ARMCI_Init();
     armci_init_loc = 1;
   }

  _array_create(&data, elem_size, *rank, lb_armci, ub_armci);
  assert(data);

  *rc = cc.resetArrayDesc(dv, data, *rank, lb, extent, stride);
  if (*rc) {
    fprintf(stderr, "ERROR in resetting array descriptor\n");
    return;
  }
}

/** ------------------------------------------------------------------- */
void ARMCI_Free_I(void* dv, int* rank, int* rc)
{
  F90_CompilerCharacteristics cc;
  void* data;

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  /*
   * Free array memory
   */
  data = cc.getArrayBaseAddress(dv, *rank);
  if (data == 0) {
    fprintf(stderr, "ERROR in getArrayBaseAddress\n");
    *rc = -1;
    return;
  }
  _array_free(data);   /* ARMCI call to free memory */
}

/** ------------------------------------------------------------------- */
void ARMCI_Malloc_I8(void* dv, int* rank, int lb_in[], int ub_in[], int* rc)
{
  F90_CompilerCharacteristics cc;
  int i;
  void* data;

  long lb[7], stride[7];
  unsigned long extent[7];
  index_size_t lb_armci[7], ub_armci[7];
  unsigned long elem_size = sizeof(long long);

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  lb[0] = lb_in[0];
  extent[0] = 1 + ub_in[0] - lb_in[0];
  stride[0] = elem_size;
  lb_armci[0] = lb_in[0];
  ub_armci[0] = ub_in[0];

  for (i = 1; i < *rank; i++) {
    lb[i] = lb_in[1];
    extent[i] = 1 + ub_in[i] - lb_in[i];
    stride[i] = extent[i-1] * stride[i-1];
    lb_armci[i] = lb_in[i];
    ub_armci[i] = ub_in[i];
  }

  /*
   * Create array memory
   */

   if ( ! armci_init_loc ) {
     ARMCI_Init();
     armci_init_loc = 1;
   }

  _array_create(&data, elem_size, *rank, lb_armci, ub_armci);
  assert(data);

  *rc = cc.resetArrayDesc(dv, data, *rank, lb, extent, stride);
  if (*rc) {
    fprintf(stderr, "ERROR in resetting array descriptor\n");
    return;
  }
}

/** ------------------------------------------------------------------- */
void ARMCI_Free_I8(void* dv, int* rank, int* rc)
{
  F90_CompilerCharacteristics cc;
  void* data;

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  /*
   * Free array memory
   */
  data = cc.getArrayBaseAddress(dv, *rank);
  if (data == 0) {
    fprintf(stderr, "ERROR in getArrayBaseAddress\n");
    *rc = -1;
    return;
  }
  _array_free(data);   /* ARMCI call to free memory */
}

/** ------------------------------------------------------------------- */
void ARMCI_Malloc_R(void* dv, int* rank, int lb_in[], int ub_in[], int* rc)
{
  F90_CompilerCharacteristics cc;
  int i;
  void* data;

  long lb[7], stride[7];
  unsigned long extent[7];
  index_size_t lb_armci[7], ub_armci[7];
  unsigned long elem_size = sizeof(float);

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  lb[0] = lb_in[0];
  extent[0] = 1 + ub_in[0] - lb_in[0];
  stride[0] = elem_size;
  lb_armci[0] = lb_in[0];
  ub_armci[0] = ub_in[0];

  for (i = 1; i < *rank; i++) {
    lb[i] = lb_in[1];
    extent[i] = 1 + ub_in[i] - lb_in[i];
    stride[i] = extent[i-1] * stride[i-1];
    lb_armci[i] = lb_in[i];
    ub_armci[i] = ub_in[i];
  }

  /*
   * Create array memory
   */

   if ( ! armci_init_loc ) {
     ARMCI_Init();
     armci_init_loc = 1;
   }

  _array_create(&data, elem_size, *rank, lb_armci, ub_armci);
  assert(data);

  *rc = cc.resetArrayDesc(dv, data, *rank, lb, extent, stride);
  if (*rc) {
    fprintf(stderr, "ERROR in resetting array descriptor\n");
    return;
  }
}

/** ------------------------------------------------------------------- */
void ARMCI_Free_R(void* dv, int* rank, int* rc)
{
  F90_CompilerCharacteristics cc;
  void* data;

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  /*
   * Free array memory
   */
  data = cc.getArrayBaseAddress(dv, *rank);
  if (data == 0) {
    fprintf(stderr, "ERROR in getArrayBaseAddress\n");
    *rc = -1;
    return;
  }
  _array_free(data);   /* ARMCI call to free memory */
}

/** ------------------------------------------------------------------- */
void ARMCI_Malloc_D(void* dv, int* rank, int lb_in[], int ub_in[], int* rc)
{
  F90_CompilerCharacteristics cc;
  int i;
  void* data;

  long lb[7], stride[7];
  unsigned long extent[7];
  index_size_t lb_armci[7], ub_armci[7];
  unsigned long elem_size = sizeof(double);

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  lb[0] = lb_in[0];
  extent[0] = 1 + ub_in[0] - lb_in[0];
  stride[0] = elem_size;
  lb_armci[0] = lb_in[0];
  ub_armci[0] = ub_in[0];

  for (i = 1; i < *rank; i++) {
    lb[i] = lb_in[1];
    extent[i] = 1 + ub_in[i] - lb_in[i];
    stride[i] = extent[i-1] * stride[i-1];
    lb_armci[i] = lb_in[i];
    ub_armci[i] = ub_in[i];
  }

  /*
   * Create array memory
   */

   if ( ! armci_init_loc ) {
     ARMCI_Init();
     armci_init_loc = 1;
   }

  _array_create(&data, elem_size, *rank, lb_armci, ub_armci);
  assert(data);

  *rc = cc.resetArrayDesc(dv, data, *rank, lb, extent, stride);
  if (*rc) {
    fprintf(stderr, "ERROR in resetting array descriptor\n");
    return;
  }
}

/** ------------------------------------------------------------------- */
void ARMCI_Free_D(void* dv, int* rank, int* rc)
{
  F90_CompilerCharacteristics cc;
  void* data;

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  /*
   * Free array memory
   */
  data = cc.getArrayBaseAddress(dv, *rank);
  if (data == 0) {
    fprintf(stderr, "ERROR in getArrayBaseAddress\n");
    *rc = -1;
    return;
  }
  _array_free(data);   /* ARMCI call to free memory */
}

/** ------------------------------------------------------------------- */
void ARMCI_Malloc_C(void* dv, int* rank, int lb_in[], int ub_in[], int* rc)
{
  F90_CompilerCharacteristics cc;
  int i;
  void* data;

  long lb[7], stride[7];
  unsigned long extent[7];
  index_size_t lb_armci[7], ub_armci[7];
  unsigned long elem_size = sizeof(complex_t);

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  lb[0] = lb_in[0];
  extent[0] = 1 + ub_in[0] - lb_in[0];
  stride[0] = elem_size;
  lb_armci[0] = lb_in[0];
  ub_armci[0] = ub_in[0];

  for (i = 1; i < *rank; i++) {
    lb[i] = lb_in[1];
    extent[i] = 1 + ub_in[i] - lb_in[i];
    stride[i] = extent[i-1] * stride[i-1];
    lb_armci[i] = lb_in[i];
    ub_armci[i] = ub_in[i];
  }

  /*
   * Create array memory
   */

   if ( ! armci_init_loc ) {
     ARMCI_Init();
     armci_init_loc = 1;
   }

  _array_create(&data, elem_size, *rank, lb_armci, ub_armci);
  assert(data);

  *rc = cc.resetArrayDesc(dv, data, *rank, lb, extent, stride);
  if (*rc) {
    fprintf(stderr, "ERROR in resetting array descriptor\n");
    return;
  }
}

/** ------------------------------------------------------------------- */
void ARMCI_Free_C(void* dv, int* rank, int* rc)
{
  F90_CompilerCharacteristics cc;
  void* data;

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  /*
   * Free array memory
   */
  data = cc.getArrayBaseAddress(dv, *rank);
  if (data == 0) {
    fprintf(stderr, "ERROR in getArrayBaseAddress\n");
    *rc = -1;
    return;
  }
  _array_free(data);   /* ARMCI call to free memory */
}

/** ------------------------------------------------------------------- */
void ARMCI_Malloc_DC(void* dv, int* rank, int lb_in[], int ub_in[], int* rc)
{
  F90_CompilerCharacteristics cc;
  int i;
  void* data;

  long lb[7], stride[7];
  unsigned long extent[7];
  index_size_t lb_armci[7], ub_armci[7];
  unsigned long elem_size = sizeof(dcomplex_t);

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  lb[0] = lb_in[0];
  extent[0] = 1 + ub_in[0] - lb_in[0];
  stride[0] = elem_size;
  lb_armci[0] = lb_in[0];
  ub_armci[0] = ub_in[0];

  for (i = 1; i < *rank; i++) {
    lb[i] = lb_in[1];
    extent[i] = 1 + ub_in[i] - lb_in[i];
    stride[i] = extent[i-1] * stride[i-1];
    lb_armci[i] = lb_in[i];
    ub_armci[i] = ub_in[i];
  }

  /*
   * Create array memory
   */

   if ( ! armci_init_loc ) {
     ARMCI_Init();
     armci_init_loc = 1;
   }

  _array_create(&data, elem_size, *rank, lb_armci, ub_armci);
  assert(data);

  *rc = cc.resetArrayDesc(dv, data, *rank, lb, extent, stride);
  if (*rc) {
    fprintf(stderr, "ERROR in resetting array descriptor\n");
    return;
  }
}

/** ------------------------------------------------------------------- */
void ARMCI_Free_DC(void* dv, int* rank, int* rc)
{
  F90_CompilerCharacteristics cc;
  void* data;

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  /*
   * Free array memory
   */
  data = cc.getArrayBaseAddress(dv, *rank);
  if (data == 0) {
    fprintf(stderr, "ERROR in getArrayBaseAddress\n");
    *rc = -1;
    return;
  }
  _array_free(data);   /* ARMCI call to free memory */
}

