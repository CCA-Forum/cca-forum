/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */
#include <compilers/PGI.h>
#include <compilers/PGI_dv.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define dope_vec dope_vec1d_PGI
#define dope_vec_hidden dope_vec_hidden_PGI

#define dv0d dope_vec0d_PGI
#define dv1d dope_vec1d_PGI
#define dv2d dope_vec2d_PGI
#define dv3d dope_vec3d_PGI
#define dv4d dope_vec4d_PGI
#define dv5d dope_vec5d_PGI
#define dv6d dope_vec6d_PGI
#define dv7d dope_vec7d_PGI

#define COOKIE 536936448

#ifdef __cplusplus
extern "C"{
#endif


/**
 * Set CompilerCharacteristics function pointers for PGI.
 */
void F90_SetCCFunctions_PGI(F90_CompilerCharacteristics* cc)
{
  cc->setArrayDesc              = setArrayDesc_PGI;
  cc->resetArrayDesc            = resetArrayDesc_PGI;
  cc->createArrayDesc           = createArrayDesc_PGI;
  cc->createArrayDescAndHidden  = createArrayDescAndHidden_PGI;
  cc->freeArrayDescAndHidden    = freeArrayDescAndHidden_PGI;
  cc->copyToArrayDescAndHidden  = copyToArrayDescAndHidden_PGI;
  cc->getArrayBaseAddress       = getArrayBaseAddress_PGI;
  cc->getArraySize              = getArraySize_PGI;
  cc->getArrayLowerBound        = getArrayLowerBound_PGI;
  cc->getArrayExtent	        = getArrayExtent_PGI;
  cc->getArrayStrideMult        = getArrayStrideMult_PGI;
  cc->getArrayDescSize	        = getArrayDescSize_PGI;
  cc->nullifyArrayDesc          = nullifyArrayDesc_PGI;
  cc->verifyArrayDesc           = verifyArrayDesc_PGI;
  cc->hiddenArrayDescType       = hiddenArrayDescType_PGI;
  cc->getMangledName	        = getMangledName_PGI;
  cc->equalsArrayDesc	        = equalsArrayDesc_PGI;
  cc->printArrayDesc	        = printArrayDesc_PGI;
}


/**
 * Returns the type code for the given data type
 */
 static int typeCode(F90_ArrayDataType data_type)
 {
    switch (data_type) {
    case F90_Integer1: return 32;
    case F90_Integer2: return 24;
    case F90_Integer:  return 25;
    case F90_Integer4: return 25;
    case F90_Integer8: return 26;
    case F90_Logical1: return 17;
    case F90_Logical2: return 18;
    case F90_Logical:  return 19;
    case F90_Logical4: return 19;
    case F90_Logical8: return 20;
    case F90_Real:     return 27;
    case F90_Double:   return 28;
    case F90_QReal:    return 29; /* not tested */
    case F90_Complex:  return 9;
    case F90_DComplex: return 10;
    case F90_QComplex: return 11; /* not tested */
    case F90_Derived:  return 33;
    case F90_Unknown:
    default:          return -1;
  }
  
  return -1;
  
 }


/**
 * Stage 1 of setting the elements of a preallocated array descriptor.
 *
 * NOTE, this function is static (private).
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param rank          the rank of the array
 * @param desc_type     type of the descriptor
 * @param data_type     data type of an array element
 * @param element_size  size of an array element
 * @param lowerBound    array[rank] of lower bounds for the array
 * @param extent        array[rank] of extents for the array (in elements)
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes)
 * @return              0 if successful (nonzero on error)
 */
static int setArrayDescStage1_PGI(void* desc,
				  int rank,
				  F90_DescType desc_type,
				  F90_ArrayDataType data_type,
				  unsigned long element_size
				  )
{
  int i;
  int rc = 0;
  dope_header_PGI* h; 
  dope_vec1d_PGI* dv = (dope_vec1d_PGI*) desc;

  h             = &dv->header;
  if (rank == 0) {
  	h->start_flag = typeCode(data_type);
  } else {
    h->start_flag = 35;
    h->rank       = rank;
    h->type_code  = typeCode(data_type);
    h->elem_size  = element_size;
    h->ten_flag   = COOKIE;
    h->zero_1[0]  = 0;
    h->zero_1[1]  = 0;
  }
  return rc;
}


/**
 * Sets the elements of a preallocated array descriptor.  This function is
 * used when passing a C array to Fortran.  NOTE, assumes that, at least,
 * ArrayDescSize bytes have been allocated in the desc pointer.
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param base_addr     the base address of the array
 * @param rank          the rank of the array
 * @param data_type     data type of an array element
 * @param element_size  size of an array element
 * @param lowerBound    array[rank] of lower bounds for the array
 * @param extent        array[rank] of extents for the array (in elements)
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes)
 * @return              0 if successful (nonzero on error)
 */
int setArrayDesc_PGI(void* desc,
		     void* base_addr,
		     int rank,
		     F90_DescType desc_type,
		     F90_ArrayDataType data_type,
		     unsigned long element_size,
		     const long* lowerBound,
		     const unsigned long* extent,
		     const long* strideMult
		     )
{
  int rc;

  if (rank < 0 || rank > 7) return 1;

  rc = setArrayDescStage1_PGI(desc, rank, desc_type, data_type, element_size);
  if (rc) return rc;
  return resetArrayDesc_PGI(desc, base_addr, rank,
			    lowerBound, extent, strideMult);
}


/**
 * Resets the elements of a preallocated array descriptor.  The descriptor
 * must have been previously initialized by either setArrayDesc() or
 * createArrayDesc().  The rank, data type and element size of the array
 * MUST NOT change.  NOTE, assumes that, at least, ArrayDescSize() bytes
 * have been allocated in the desc pointer.
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param base_addr     the base address of the array
 * @param rank          the rank of the array
 * @param lowerBound    array[rank] of lower bounds for the array
 * @param extent        array[rank] of extents for the array (in elements)
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes)
 * @return              0 if successful (nonzero on error)
 */
int resetArrayDesc_PGI(void* desc,
		       void* base_addr,
		       int rank,
		       const long* lowerBound,
		       const unsigned long* extent,
		       const long* strideMult
		       )
{
  int i;
  long sum;
  unsigned long size;
  dope_vec1d_PGI* dv = (dope_vec1d_PGI*) desc;
  dope_header_PGI* h;

  if (rank < 0 || rank > 7) return 1;

  dv->base_addr = base_addr;
  dv->unkn_addr = 0x0;
  
  if (rank == 0) return 0;	/* descriptors for pointers have little data? */

  for (i = 0; i < rank; i++) {
    dv->dim[i].lower_bound = lowerBound[i];
    dv->dim[i].extent      = extent[i];
    dv->dim[i].one         = 1;
    dv->dim[i].zero        = 0;   
    dv->dim[i].upper_bound = lowerBound[i] + extent[i] - 1;
    dv->dim[i].stride_mult = strideMult[i]/dv->header.elem_size;
  }

  h = &dv->header;

  sum = 0;
  size = 1;
  for (i = 0; i < rank; i++) {
    size *= 1 + dv->dim[i].upper_bound - dv->dim[i].lower_bound;
    sum += dv->dim[i].lower_bound * dv->dim[i].stride_mult;
  }
  h->size     = size;
  h->size_dup = size;
  h->sum_d    = 1 - sum;

  return 0;
}


/**
 * Returns an array descriptor by copying an existing descriptor.  This
 * function is used when passing an array from Fortran to C++.  NOTE,
 * it is the callers responsibility to free the returned descriptor.
 *
 * @param desc       the descriptor to copy
 * @param hidden     hidden descriptor parameter
 * @param rank       the rank of the array
 * @param desc_type  type of the source descriptor
 * @return           allocated array descriptor copy
 */
void* createArrayDesc_PGI(void* desc,
			  void* hidden,
			  int rank,
			  F90_DescType desc_type
			  )
{
  unsigned long size = getArrayDescSize_PGI(rank);

  dope_vec*        dvl = (dope_vec*) desc;
  dope_vec_hidden* dvh = (dope_vec_hidden*) hidden;

  dope_vec* dv = (dope_vec*) calloc( 1, size );
  assert(dv != 0);

  switch (desc_type) {
  	case F90_ArrayPointer: {
      char* p = (char*) &dv->base_addr;
      dv->base_addr = dvl->base_addr;	/* desc contains everything, hidden 8 bytes after desc */
      dv->unkn_addr = dvl->unkn_addr;
      memcpy(p + 2*sizeof(void*), dvh, size - 2*sizeof(void*));
      break;
  	}
    case F90_Array: {
      char* p = (char*) &dv->base_addr;
      dv->base_addr = desc;	/* desc is base_addr only, hidden is separate from desc/base_addr */
      dv->unkn_addr = dvl->unkn_addr; /* probably should be set to zero */
      memcpy(p + 2*sizeof(void*), dvh, size - 2*sizeof(void*));
      break;
    }
    case F90_Pointer:		/* note fall through */
    case F90_ArrayPointerInDerived: {
      memcpy(dv, dvl, size);	/* no hidden parameter */
      break;
    }
    default: {
      free(dv);
      dv = 0x0;
    }
  }
  return dv;
  
}


/**
 * Creates an array descriptor (with hidden portion) from an existing
 * descriptor in preparation for calling a Fortran function from C (with
 * an array valued parameter).
 *
 * IMPORTANT NOTES: The companion function freeArrayDescAndHidden must be
 * called to free the parameters desc and hidden after use (lifetime
 * must not exceed that of the source descriptor).
 *
 * @param src     the source descriptor
 * @param rank    the rank of the source and destination arrays
 * @param desc_type  type of the source and destination descriptors
 * @param desc    on return, contains address of created descriptor
 * @param hidden  on return, contains address of hidden form of the descriptor
 * @return        0 if successful (nonzero on error)
 */
int createArrayDescAndHidden_PGI(void* src,
				 int rank,
				 F90_DescType desc_type,
				 void** desc,
				 void** hidden
				 )
{
  switch (desc_type) {
    case F90_ArrayPointer: {	/* desc contains everything, hidden 8 bytes after desc */
      *desc = src;
      *hidden = (char*) src + 2*sizeof(void*);
      break;
    }
    case F90_Array: {		/* desc is base_addr only, hidden is separate from desc/base_addr */
      dope_vec* dv = (dope_vec*) src;
      char* p = (char*) &dv->base_addr;
      *desc = dv->base_addr;
      *hidden = p + 2*sizeof(void*);
      break;
    }
    case F90_Pointer:		/* note fall through to default */
    case F90_ArrayPointerInDerived:
    default: {
      *desc = src;
      *hidden = 0x0;
    }
  }
  return 0;
}


/**
 * Frees an array descriptor (with hidden portion) created by
 * a call to createArrayDescAndHidden().
 *
 * @param desc_type  type of the descriptor
 * @param desc       address of descriptor to be freed
 * @param hidden     address of hidden form of the descriptor to be freed
 * @return           0 if successful (nonzero on error)
 */
int freeArrayDescAndHidden_PGI(F90_DescType desc_type, void* desc, void* hidden)
{
  return 0;
}


/**
 * Copies one array descriptor to another.  This function is used
 * when passing an array from C++ to Fortran.
 *
 * @param src        the source descriptor
 * @param rank       the rank of the source and destination arrays
 * @param desc_type  type of the source and destination descriptors
 * @param dest       the destination descriptor
 * @param hidden     hidden form of the descriptor, after formal parameter list
 * @return           0 if successful (nonzero on error)
 */
int copyToArrayDescAndHidden_PGI(void* src,
				 int rank,
				 F90_DescType desc_type,
				 void* dest,
				 void* hidden
				 )
{
	/* TODO what about base_addr and unkn_base? */
  switch (desc_type) {
    case F90_Array: {
      dope_vec* dv = (dope_vec*) src;
      char*     p  = (char*) &dv->base_addr;
      memcpy(hidden, p + sizeof(void*),
	     getArrayDescSize_PGI(rank) - 2*sizeof(void*));	     
      break;
    }
    case F90_Pointer:		/* note fall through to default */
    case F90_ArrayPointer:
    case F90_ArrayPointerInDerived:
    default: {
      memcpy(dest, src, getArrayDescSize_PGI(rank));
    }
  }
  return 0;
}


/** 
 * Returns a pointer to the base address of the array.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       base address of the array
 */
void* getArrayBaseAddress_PGI(const void* desc, int rank)
{
  if (rank < 0 || rank > 7) {
    return 0x0;
  } else {
    return ((dope_vec1d_PGI*) desc)->base_addr;
  }
}


/**
 * Returns the array size (in elements).
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       array size
 */
unsigned long getArraySize_PGI(const void* desc, int rank)
{
  if (rank < 1 || rank > 7) return 0;
  
  return ((dope_vec1d_PGI*) desc)->header.size;
}


/**
 * Returns the lower bound for the given dimension.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       lower bound
 */
long getArrayLowerBound_PGI(const void* desc, int rank, int dim)
{
  if (rank < 1 || rank > 7) return 0; 
   
  return((dope_vec1d_PGI*) desc)->dim[dim-1].lower_bound;
}


/**
 * Returns the extent of the array for the given dimension (in elements).
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       array extent (in elements)
 */
unsigned long getArrayExtent_PGI(const void* desc, int rank, int dim)
{
  dope_vec1d_PGI* dv = (dope_vec1d_PGI*) desc;
  if (rank < 1 || rank > 7) return 0;
  
  return (1 + dv->dim[dim-1].upper_bound - dv->dim[dim-1].lower_bound);
}


/**
 * Returns the distance between successive elements (in bytes).
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       stride (in bytes)
 */
long getArrayStrideMult_PGI(const void* desc, int rank, int dim)
{
  dope_vec *dv = (dope_vec*) desc;
  if (rank < 1 || rank > 7) return 0;

  return dv->dim[dim-1].stride_mult * dv->header.elem_size;
}


/**
 * Returns the size of an array descriptor (in bytes).
 *
 * @param rank   the rank of the array
 * @return       descriptor size (in bytes)
 */
unsigned long getArrayDescSize_PGI(int rank)
{
  switch (rank) {
  	case 0:  return sizeof(dv0d);
    case 1:  return sizeof(dv1d);
    case 2:  return sizeof(dv2d);
    case 3:  return sizeof(dv3d);
    case 4:  return sizeof(dv4d);
    case 5:  return sizeof(dv5d);
    case 6:  return sizeof(dv6d);
    case 7:  return sizeof(dv7d);
  }
  return 0;
}


/**
 * Nullify an array descriptor (associated intrinsic will return false).
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @return       0 if successful (nonzero on error)
 */
int nullifyArrayDesc_PGI(void* desc, int rank)
{
  dope_vec1d_PGI* dv = (dope_vec1d_PGI*) desc;
  dv->base_addr = 0x0;
  return 0;
}


/**
 * Verify an array descriptor.
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @return       0 if the descriptor is valid, nonzero otherwise
 */
int verifyArrayDesc_PGI(const void* desc, int rank)
{
  int i;
  long sum;
  unsigned long size;
  dope_vec1d_PGI* dv = (dope_vec1d_PGI*) desc;
  dope_header_PGI* h;

  if (dv->base_addr  == 0x0)		return 1;
  
  if (rank < 1 || rank > 7) return 0;

  h = &dv->header;
  if (h->rank       != rank)		return 1;
  if (h->start_flag != 35)		return 1;
  if (h->elem_size  <  1)		return 1;

  sum = 0;
  size = 1;
  for (i = 0; i < rank; i++) {
    if (dv->dim[i].upper_bound < dv->dim[i].lower_bound) return 1;
    if (dv->dim[i].stride_mult < 1) return 1;
    size *= 1 + dv->dim[i].upper_bound - dv->dim[i].lower_bound;
    sum += dv->dim[i].lower_bound * dv->dim[i].stride_mult;
  }
  if (h->size     != size)	return 1;
  if (h->size_dup != size)	return 1;
  if (h->sum_d    != 1 - sum)	return 1;

  return 0;
}


/**
 * Returns the type of hidden descriptors used by the compiler
 *
 * @return       hidden descriptor type
 */
F90_HiddenDescType hiddenArrayDescType_PGI(F90_DescType desc_type)
{
  switch (desc_type) {
  	case F90_ArrayPointer:  return F90_Hidden;
    case F90_Array:			return F90_PointerWithHiddenDesc;	
    case F90_Pointer:
    case F90_ArrayPointerInDerived:
    case F90_NonArray:
    default:				return F90_NoHidden;
  }
}


/**
 * Returns the symbol name of a module procedure, if the module name
 * is not null, otherwise returns the name of the procedure.
 *
 * Note: static memory is used for the return value so it must be
 * copied if retained because the memory is overwritten at each call.
 *
 * @param fun_name   the name of the procedure
 * @param mod_name   the module name (NULL if a global procedure)
 * @return           symbol name
 */
char* getMangledName_PGI(const char* fun_name, const char* mod_name)
{   
  int i;
  static char name[512];
  size_t funsize, modsize, namesize;

  if (fun_name == NULL) return NULL;

  funsize = strlen(fun_name);
  if (mod_name == NULL) {
    modsize = 0;
    namesize = funsize + 1;
  } else {
    modsize = strlen(mod_name);
    namesize = modsize + 1 + funsize + 1;
  }

  if (namesize > 511) return NULL;

  if (modsize > 0) {
    strcpy(name, mod_name);
    strcpy(name + modsize, "_");
    strcpy(name + modsize + 1, fun_name);
    strcpy(name + modsize + 1 + funsize, "_");
    /* lower case -> fun_name and mod_name */
    for (i = 0; i < modsize; i++) {
      if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
    }
    for (i = modsize + 1; i < namesize; i++) {
      if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
    }
  } else {
    strcpy(name, fun_name);
    strcpy(name + funsize, "_");
    /* lower case -> fun_name */
    for (i = 0; i < funsize; i++) {
      if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
    }
  }

  return name;
}


/**
 * Prints all fields in the array descriptor.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       0 if successful (nonzero on error)
 */
int printArrayDesc_PGI(const void* desc, int rank)
{
  int i;
  dope_vec1d_PGI* dv = (dope_vec1d_PGI*) desc;
  dope_header_PGI* h = &dv->header;

  printf("PGI array descriptor:\n");
  printf("  base_addr    = %p\n", dv->base_addr);
  printf("  unkn_addr    = %p\n", dv->unkn_addr);
  printf("  start_flag   = %d\n", h->start_flag);
  printf("  rank         = %d\n", h->rank);
  printf("  type_code    = %d\n", h->type_code);
  printf("  elem_size    = %d\n", h->elem_size);
  printf("  ten_flag     = %d\n", h->ten_flag);
  printf("  size         = %d\n", h->size);
  printf("  size_dup     = %d\n", h->size_dup);
  printf("  zero_1       = %d %d\n", h->zero_1[0], h->zero_1[1]);
  printf("  sum_d        = %d\n", h->sum_d);
/*
  printf("  block_1      = %d %d %d %d %d %d %d\n", h->block_1[0],
                           h->block_1[1], h->block_1[2], h->block_1[3],
                           h->block_1[4], h->block_1[5], h->block_1[6]);
  printf("  block_2      = %d %d %d %d %d %d %d\n", h->block_2[0],
                           h->block_2[1], h->block_2[2], h->block_2[3],
                           h->block_2[4], h->block_2[5], h->block_2[6]);
  printf("  stop _flag_1 = %d\n", h->stop_flag_1);
  printf("  stop _flag_2 = %d\n", h->stop_flag_2);
  printf("  zero_2       = %d %d\n", h->zero_2[0], h->zero_2[1]);
*/
  for (i = 0; i < rank; i++) {
    printf("    dim[%d] = LB:%d, UB:%d, STRD:%d EX:%d  %d %d\n", i+1,
	   dv->dim[i].lower_bound,
	   dv->dim[i].upper_bound,
           dv->dim[i].stride_mult, dv->dim[i].extent, dv->dim[i].one, dv->dim[i].zero);
  }
  return 0;
}


/**
 * Determines if two descriptors are equal (equivalent).
 *
 * WARNING, this function is deprecated.
 *
 * @param desc1   first descriptor
 * @param desc2   second descriptor
 * @param rank    the rank of the array
 * @return        1 if equal, 0 otherwise
 */
int equalsArrayDesc_PGI(const void* desc1, const void* desc2, int rank)
{
  int i;
  unsigned long size;
  int * dvi1, * dvi2;
  dope_vec* dv1 = (dope_vec*) desc1;
  dope_vec* dv2 = (dope_vec*) desc2;
  dope_header_PGI* dh1 = &dv1->header;
  dope_header_PGI* dh2 = &dv2->header;

  if (dv1->base_addr  != dv2->base_addr)  return 0;
  if (dv1->unkn_addr  != dv2->unkn_addr)  return 0;
  
  if (dh1->start_flag != dh2->start_flag) return 0;

  if (rank == 0) return 1;	/* assume pointer descriptors are small, how large? */
  
  if (dh1->rank       != dh2->rank      ) return 0;
  if (dh1->type_code  != dh2->type_code ) return 0;
  if (dh1->elem_size  != dh2->elem_size ) return 0;
  if (dh1->ten_flag   != dh2->ten_flag  ) return 0;
  if (dh1->size       != dh2->size      ) return 0;
  if (dh1->size_dup   != dh2->size_dup  ) return 0;
  if (dh1->sum_d      != dh2->sum_d     ) return 0;
  if (dh1->zero_1[0]  != dh2->zero_1[0] ) return 0;
  if (dh1->zero_1[1]  != dh2->zero_1[1] ) return 0;

  for (i = 0; i < rank; i++) {
    if (dv1->dim[i].lower_bound != dv2->dim[i].lower_bound) return 0;
    if (dv1->dim[i].extent      != dv2->dim[i].extent)      return 0;
    if (dv1->dim[i].one         != dv2->dim[i].one)         return 0;
    if (dv1->dim[i].zero        != dv2->dim[i].zero)        return 0;
    if (dv1->dim[i].stride_mult != dv2->dim[i].stride_mult) return 0;
    if (dv1->dim[i].upper_bound != dv2->dim[i].upper_bound) return 0;
  }

  return 1;
}


#ifdef __cplusplus
}
#endif
