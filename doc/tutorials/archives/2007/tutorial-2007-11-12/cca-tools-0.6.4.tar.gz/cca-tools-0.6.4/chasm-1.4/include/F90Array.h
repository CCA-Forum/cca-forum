/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */
#ifndef _F90ARRAY_H_
#define _F90ARRAY_H_

#include "CompilerCharacteristics.h"
#include "F90Compiler.h"
#include "F90Descriptor.h"
#include <assert.h>

namespace F90 {

/**
 * An implementation of the basic methods of the Descriptor interface.
 */
class ChasmDescriptor : public Descriptor {
  public:
    void* address()	      { return cc.getArrayBaseAddress(desc, rank_m); }
    int   rank()	      { return rank_m; }

    long lowerBound(int dim)
    {
      return cc.getArrayLowerBound(desc, rank_m, dim);
    }

    unsigned long extent(int dim)
    {
      return cc.getArrayExtent(desc, rank_m, dim);
    }

    long stride(int dim)   { return cc.getArrayStrideMult(desc, rank_m, dim); }
    unsigned long arraySize()       { return cc.getArraySize(desc, rank_m); }
    unsigned long elementSize()     { return elementSize_m; }
    F90_ArrayDataType elementType() { return elementType_m; }
    void* descriptor()              { return desc; }

  protected:
    F90_CompilerCharacteristics cc;
    int  		    rank_m;
    int  		    elementSize_m;
    F90_ArrayDataType 	    elementType_m;
    void* 		    desc;
};

/**
 * A detailed implementation that allocates and fills in a descriptor.
 */
template<class T>
class Array : public ChasmDescriptor {
  public: 
    /**
     * A simple constructor that just allocates the descriptor.
     */
    Array()
    {
      allocateDescriptor();      
    }

    /**
     * This constructor only requires an address, rank and extent.  The
     * lower bounds are assumed to be 1 for each rank.
     */
    Array( T* addr, int rank, unsigned long extent[] )
    {
      long lowerBound[7];

      allocateDescriptor(rank);      

      // since the lower bounds weren't specified, set them to 1
      for( int i=0; i<rank; i++ ) {
        lowerBound[i] = 1L;
      }

      // fill in the descriptor
       setDesc( addr, rank, lowerBound, extent );
    }
    
    /**
     * This constructor requires an address, rank, extent, and lower
     * bounds information.
     */
    Array( T* addr, int rank, int lowerBound[], int extent[] )
    {
      allocateDescriptor(rank);      

      // fill in the descriptor
      setDesc( addr, rank, lowerBound, extent );
    }

    /**
     * Deallocates the descriptor.
     */
    ~Array()
    {
      if( desc != 0 ) free( desc );
    }

    /**
     * Allocates memory for the descriptor.
     */
    void allocateDescriptor(int rank)
    {
      // fill in the compiler characteristics object
      F90_SetCompilerCharacteristics( &cc, FORTRAN_COMPILER);
      // allocate memory for the descriptor object associated with this compiler
      desc = calloc( 1, cc.getArrayDescSize( rank ));
      // make sure it worked
      assert( desc != 0 );
    }
    
    /**
     * Fills in the descriptor.
     */
    void setDesc( T* addr, int rank, long lowerBound[], unsigned long extent[] )
    {
      int rc;		// the return code (1 on error, 0 ok)
      long strideMult[7];

      elementType_m = elementType();
      elementSize_m = sizeof( T );
      rank_m = rank;
            
      // figure out the strides
      for( int i=0; i<rank_m; i++ ) {
        strideMult[i] = elementSize_m;
      }
      
      // fill in the descriptor object
      rc = cc.setArrayDesc(desc, addr, rank_m, F90_ArrayPointer, elementType_m,
			   elementSize_m, lowerBound, extent, strideMult );
      // make sure we didn't have any problems
      assert( rc == 0 );
    }

    operator T*()	{ return (T*) desc; }
    T* baseAddress()
    {
      return static_cast<T*>( cc.getArrayBaseAddress(desc, rank_m) );
    } 

    F90_ArrayDataType elementType() { return Unknown; }
};

    /**
     * These specialize the elementType() function so that the proper
     * enumerated F90_ArrayDataType is returned based on the instantiated
     * template class type.
     *
     * NOTE: These mappings are platform dependent, so this will likely
     * have to change at some point...
     */

    template<> inline F90_ArrayDataType Array<char>::elementType()
    {
      return F90_Integer1;
    }

    template<> inline F90_ArrayDataType Array<short>::elementType()
    {
      return F90_Integer2;
    }

    template<> inline F90_ArrayDataType Array<int>::elementType()
    {
      return F90_Integer;
    }

    template<> inline F90_ArrayDataType Array<long>::elementType()
    {
      return F90_Integer4;
    }

    template<> inline F90_ArrayDataType Array<long long>::elementType()
    {
      return F90_Integer8;
    }

    template<> inline F90_ArrayDataType Array<float>::elementType()
    {
      return F90_Real;
    }

    template<> inline F90_ArrayDataType Array<double>::elementType()
    {
      return F90_Double;
    }

} // namespace F90


#endif /* _F90ARRAY_H_ */
