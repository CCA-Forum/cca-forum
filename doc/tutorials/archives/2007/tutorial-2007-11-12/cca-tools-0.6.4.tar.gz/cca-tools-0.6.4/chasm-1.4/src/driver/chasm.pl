#!/usr/bin/perl
#### -------------------------------------------------------------------------
#### LANL:license
#### -------------------------------------------------------------------------
#### This SOFTWARE has been authored by an employee or employees of the
#### University of California, operator of the Los Alamos National Laboratory
#### under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
#### The U.S. Government has rights to use, reproduce, and distribute this
#### SOFTWARE.  The public may copy, distribute, prepare derivative works and
#### publicly display this SOFTWARE without charge, provided that this Notice
#### and any statement of authorship are reproduced on all copies.  Neither
#### the Government nor the University makes any warranty, express or implied,
#### or assumes any liability or responsibility for the use of this SOFTWARE.
#### If SOFTWARE is modified to produce derivative works, such modified
#### SOFTWARE should be clearly marked, so as not to confuse it with the
#### version available from LANL.
#### -------------------------------------------------------------------------
#### LANL:license
#### -------------------------------------------------------------------------

##
## chasm.pl : driver for chasm
##

$debug = 1;

##
## some paths
##
$chasm_root = "/home/baallan/cca/build/chasm_cvs";
$pdt_root = "";
$xalan_root = "";
$mapping_dtd = $chasm_root."/xml/schema/mapping.dtd";

##
## usage:
##   chasm.pl <XSL Style Sheet> <Source File> [<Output>]
##

#
# debug message routine
#
sub dbg {
    my $msg = shift(@_);
    if ($debug == 1) {
        print "[DEBUG] $msg\n";
    }
}

# 
# usage
#
if ($#ARGV != 1 && $#ARGV != 2) {
    print "Usage: chasm.pl <XSL Style Sheet> <Source File> [<output>]\n\n";
    exit(0);
}

#
# get the arguments
#
($stylesheet, $sourcefile, $outfile) = @ARGV;

#
# steps to work:
#  1. PDT
#  2. XML Generator
#  3. Java Xalan
#

#
# before PDT, try to figure out what language the file is.  Note that we
# assume .h maps to C++, not C.
#
$language = "UNKNOWN";

if ($sourcefile =~ /.c$/) {
    $language = "C";
}
if ($sourcefile =~ /.h$/ || $sourcefile =~ /.hh$/) {
    $language = "CXX";
}
if ($sourcefile =~ /.cc$/ || $sourcefile =~ /.cxx$/) {
    $language = "CXX";
}
if ($sourcefile =~ /.f90$/ || $sourcefile =~ /.f$/) {
    $language = "FORTRAN";
}

dbg("Language is $language");

#
# PDT analysis step
#
$pdtline = $pdt_root."/bin/";

SWITCH: {
    if ($language eq "C") { $pdtline .= "cparse"; last SWITCH; }
    if ($language eq "CXX") { $pdtline .= "cxxparse"; last SWITCH; }
    if ($language eq "FORTRAN") { $pdtline .= "f90parse"; last SWITCH; }
    $nothing = 1;
}

$pdtline .= " $sourcefile";

#
# invoke the PDT parser
#
system($pdtline);

##
## find the PDB file
##
@pathparts = split(/\//,$sourcefile);
$srcpath = "";
for ($i=0;$i<$#pathparts;$i++) {
    $srcpath .= $pathparts[$i]."/";
}
chop($srcpath);
dbg("Source is in : $srcpath");

# guess PDB filename. total hack.
$sfile = $pathparts[$#pathparts];
($fname, $fext) = split(/\./,$sfile);
if ($fext eq "hh") {
    $sfile = $fname.".hh";
} else {
    $sfile = $fname;
}
$pdbfilename = $srcpath."/".$sfile.".pdb";

dbg("PDB file is: $pdbfilename");
if (!(-e $pdbfilename)) {
    dbg("It seems to exist too.");
}

##
## now generate XML
##
$xmlfile = "./".$sfile.".xml";
$xmlcmd = $chasm_root."/src/xmlgen/xmlgen ".$xmlfile." ".$pdbfilename;
system($xmlcmd);

##
## assuming XML came out right, run Xalan
##
$classpath = $xalan_root."/bin/xalan.jar";
$javacmd = "";
if ($outfile eq "") {
    $javacmd = "java -cp $classpath org.apache.xalan.xslt.Process -xsl $stylesheet -in $xmlfile";
} else {
    $javacmd = "java -cp $classpath org.apache.xalan.xslt.Process -xsl $stylesheet -in $xmlfile -out $outfile";
}

#
# copy the DTD in here temporarily for validation
#
system("cp $mapping_dtd .");
system($javacmd);
system("rm mapping.dtd");
