#include <CompilerCharacteristics.h>
#include <F90Compiler.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <sys/types.h>

#define MAX_DESCRIPTOR_SIZE 256

#if defined(F90_SYM_CASE_LOWER)
# define SIDL_double__array_createRow_m F90_SYMBOL_COND( sidl_double__array_createrow_m )
#endif /* F90_SYM_CASE_LOWER */

#if defined(F90_SYM_CASE_MIXED)
# define SIDL_double__array_createRow_m F90_SYMBOL_COND( SIDL_double__array_createRow_m )
#endif /* F90_SYM_CASE_MIXED */

#ifdef F90_SYM_CASE_UPPER
# define SIDL_double__array_createRow_m F90_SYMBOL_COND( SIDL_DOUBLE__ARRAY_CREATEROW_M )
#endif /* F90_SYM_CASE_UPPER */

typedef struct F90_Array2D_ {
  int64_t d_array;
  unsigned char desc[MAX_DESCRIPTOR_SIZE];
} F90_Array2D;

int SIDL_double__array_createRow_m(int* pRank,
				   int* lower,
				   int* upper,
				   F90_Array2D* a_t)
{
  F90_CompilerCharacteristics cc;
  int i, rank, rc, elem_size;
  unsigned long ex[7];
  long size, stride, lb[7], sm[7];
  double *base_addr;
  void* dv_a;

  rank = *pRank;
  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  dv_a = &(a_t->desc);

  /* create array layout */
  size = 1;
  elem_size = sizeof(double);
  assert(elem_size == 8);
  stride = elem_size;
  for (i = rank - 1; i >= 0; i--) {
    lb[i] = lower[i];
    ex[i] = 1 + upper[i] - lower[i];
    sm[i] = stride;
    size = size*ex[i];
    stride *= ex[i];
  }

  base_addr = (double*) malloc(size * (elem_size));
  assert(base_addr);

  for (i = 0; i < size; i++) {
    base_addr[i] = (double) i+1;
  }

  /* reset descriptor with new information */
  rc = cc.resetArrayDesc(dv_a, base_addr, rank, lb, ex, sm);
  if (rc) {
    fprintf(stderr, "ERROR in resetArrayDesc\n");
    return 1;
  }

  return 0;
}
