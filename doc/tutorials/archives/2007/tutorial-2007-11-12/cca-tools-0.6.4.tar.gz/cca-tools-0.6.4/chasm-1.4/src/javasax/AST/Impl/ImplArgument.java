package AST.Impl;

import java.util.*;

/**
 * This file contains the 'abstract syntax' nodes for use by a SAX
 * parser of implementation files.
 */
public class ImplArgument {
    String name;
    String type;
    String intent;
    boolean typeSet;
    boolean isReturn;

    public ImplArgument(String name, String intent) {
        this.name = name;
        this.type = "unknown";
        this.intent = intent;
        typeSet = false;
        isReturn = false;
    }

    public void setIsReturn(boolean b) {
        isReturn = b;
    }

    public void setType(String type) {
        if (!typeSet) {
            this.type = type;
            typeSet = true;
        }
    }

    public String toString() {
        if (isReturn) {
            return type;
        } else {
            return type+" "+name;
        }
    }
}                                                                
