package XML;

import javax.xml.parsers.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

import java.io.*;

public class SAXImplReader extends DefaultHandler {
    private AST.Impl.ImplLibrary lib;
    private AST.Impl.ImplScope scope;
    private AST.Impl.ImplMethod method;
    private AST.Impl.ImplArgument arg;

    public void startDocument() throws SAXException {
        lib = null;
        scope = null;
        method = null;
        arg = null;
    }

    public AST.Impl.ImplLibrary getLibrary() {
        return lib;
    }

    public void startElement(String namespaceURI,
                             String localName,
                             String qName,
                             Attributes atts) throws SAXException {
        if (localName.equals("library")) {
            String lName = atts.getValue("name");
            String lLang = atts.getValue("language");
            lib = new AST.Impl.ImplLibrary(lName,lLang);
        } else if (localName.equals("scope")) {
            String sName = atts.getValue("name");
            scope = new AST.Impl.ImplScope(sName);
        } else if (localName.equals("method")) {
            String mName = atts.getValue("name");
            method = new AST.Impl.ImplMethod(mName);
        } else if (localName.equals("arg")) {
            String aName = atts.getValue("name");
            String aIntent = atts.getValue("intent");
            arg = new AST.Impl.ImplArgument(aName,aIntent);
        } else if (localName.equals("return")) {
            String aName = atts.getValue("name");
            arg = new AST.Impl.ImplArgument(aName,"out");
            arg.setIsReturn(true);
        } else if (localName.equals("type")) {
            arg.setType(atts.getValue("kind"));
        } else {
        }
    }

    public void endElement(String namespaceURI,
                           String localName,
                           String qName) throws SAXException {
        if (localName.equals("library")) {
            if (scope != null || method != null || arg != null) {
                System.err.println("Not quite right.");
            }
        } else if (localName.equals("scope")) {
            lib.addScope(scope);
            scope = null;
        } else if (localName.equals("method")) {
            if (scope == null)
                lib.addMethod(method);
            else
                scope.addMethod(method);
            method = null;
        } else if (localName.equals("return")) {
            method.setReturn(arg);
            arg = null;
        } else if (localName.equals("arg")) {
            method.addArgument(arg);
            arg = null;
        } else if (localName.equals("type")) {
            
        } else {
            // nada
        }
    }

    public void endDocument() throws SAXException {
        System.err.println("Ending document.");
    }

    /**
     * Convert from a filename to a file URL.
     */
    private String convertToFileURL(String filename) {
        try {
            String fu = (new File(filename)).toURL().toString();
            return fu;
        } catch (Exception e) {
            System.err.println("Exception: "+e.toString());
            return null;
        }
    }

    public SAXImplReader(String filename) {
        String furl = convertToFileURL(filename);

        SAXParserFactory spf = SAXParserFactory.newInstance();

        spf.setNamespaceAware(true);

        spf.setValidating(false);

        try {
            SAXParser saxParser = spf.newSAXParser();
            
            XMLReader xmlReader = saxParser.getXMLReader();

            xmlReader.setContentHandler(this);
            xmlReader.setErrorHandler(new SAXErrorHandler());
            xmlReader.parse(furl);
        } catch (Exception e) {
            System.err.println("Exception:"+e.toString());
        }
    }
}
