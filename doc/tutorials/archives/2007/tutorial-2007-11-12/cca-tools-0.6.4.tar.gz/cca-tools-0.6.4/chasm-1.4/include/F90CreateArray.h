/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 *
 * F90CreateArray.h - this file is automatically created
 *
 * The C functions declared in this file are implemented in Fortran and
 * are used to create and destroy F90 Arrays.  These procedures can be used
 * to allocate an array in Fortran (called from C), save the array descriptor
 * in C, modify the memory in C, then pass the descriptor back to Fortran.
 *
 * WARNING, array memory must not be free'd in C; memory must be free'd
 * by calling the associated F90DestroyArray functions.
 *
 * The large number of procedures are needed, since Fortran is
 * now strongly typed and there is no casting mechanism.
 *
 */

#ifndef _CHASM_CREATE_ARRAY_H_
#define _CHASM_CREATE_ARRAY_H_

#include <F90Compiler.h>


#ifdef F90_ABSOFT
#  include <compilers/Absoft.h>
#  define getArrayDescSize getArrayDescSize_Absoft
#  define createArrayDesc createArrayDesc_Absoft
#endif

#ifdef F90_ALPHA
#  include <compilers/Alpha.h>
#  define getArrayDescSize getArrayDescSize_Alpha
#  define createArrayDesc createArrayDesc_Alpha
#endif

#ifdef F90_CRAY
#  include <compilers/Cray.h>
#  define getArrayDescSize getArrayDescSize_Cray
#  define createArrayDesc createArrayDesc_Cray
#endif

#ifdef F90_GNU
#  include <compilers/GNU.h>
#  define getArrayDescSize getArrayDescSize_GNU
#  define createArrayDesc createArrayDesc_GNU
#endif

#ifdef F90_G95
#  include <compilers/G95.h>
#  define getArrayDescSize getArrayDescSize_G95
#  define createArrayDesc createArrayDesc_G95
#endif

#ifdef F90_IBMXL
#  include <compilers/IBMXL.h>
#  define getArrayDescSize getArrayDescSize_IBMXL
#  define createArrayDesc createArrayDesc_IBMXL
#endif

#ifdef F90_INTEL
#  include <compilers/Intel.h>
#  define getArrayDescSize getArrayDescSize_Intel
#  define createArrayDesc createArrayDesc_Intel
#endif

#ifdef F90_INTEL_7
#  include <compilers/Intel_7.h>
#  define getArrayDescSize getArrayDescSize_Intel_7
#  define createArrayDesc createArrayDesc_Intel_7
#endif

#ifdef F90_LAHEY
#  include <compilers/Lahey.h>
#  define getArrayDescSize getArrayDescSize_Lahey
#  define createArrayDesc createArrayDesc_Lahey
#endif

#ifdef F90_MIPSPRO
#  include <compilers/MIPSpro.h>
#  define getArrayDescSize getArrayDescSize_MIPSpro
#  define createArrayDesc createArrayDesc_MIPSpro
#endif

#ifdef F90_NAG
#  include <compilers/NAG.h>
#  define getArrayDescSize getArrayDescSize_NAG
#  define createArrayDesc createArrayDesc_NAG
#endif

#ifdef F90_PGI
#  include <compilers/PGI.h>
#  define getArrayDescSize getArrayDescSize_PGI
#  define createArrayDesc createArrayDesc_PGI
#endif

#ifdef F90_SUNWSPRO
#  include <compilers/SUNWspro.h>
#  define getArrayDescSize getArrayDescSize_SUNWspro
#  define createArrayDesc createArrayDesc_SUNWspro
#endif


#ifdef F90_SYM_CASE_LOWER

# define F90_CopyDesc1DI1      F90_SYMBOL_COND( f90_copydesc1di1 )
# define F90_CreateArray1DI1   F90_SYMBOL_COND( f90_createarray1di1 )
# define F90_DestroyArray1DI1  F90_SYMBOL_COND( f90_destroyarray1di1 )
# define F90_Dealloc1DI1       F90_SYMBOL_COND( f90_dealloc1di1 )

# define F90_CopyDesc1DI2      F90_SYMBOL_COND( f90_copydesc1di2 )
# define F90_CreateArray1DI2   F90_SYMBOL_COND( f90_createarray1di2 )
# define F90_DestroyArray1DI2  F90_SYMBOL_COND( f90_destroyarray1di2 )
# define F90_Dealloc1DI2       F90_SYMBOL_COND( f90_dealloc1di2 )

# define F90_CopyDesc1DI      F90_SYMBOL_COND( f90_copydesc1di )
# define F90_CreateArray1DI   F90_SYMBOL_COND( f90_createarray1di )
# define F90_DestroyArray1DI  F90_SYMBOL_COND( f90_destroyarray1di )
# define F90_Dealloc1DI       F90_SYMBOL_COND( f90_dealloc1di )

# define F90_CopyDesc1DI4      F90_SYMBOL_COND( f90_copydesc1di4 )
# define F90_CreateArray1DI4   F90_SYMBOL_COND( f90_createarray1di4 )
# define F90_DestroyArray1DI4  F90_SYMBOL_COND( f90_destroyarray1di4 )
# define F90_Dealloc1DI4       F90_SYMBOL_COND( f90_dealloc1di4 )

# define F90_CopyDesc1DI8      F90_SYMBOL_COND( f90_copydesc1di8 )
# define F90_CreateArray1DI8   F90_SYMBOL_COND( f90_createarray1di8 )
# define F90_DestroyArray1DI8  F90_SYMBOL_COND( f90_destroyarray1di8 )
# define F90_Dealloc1DI8       F90_SYMBOL_COND( f90_dealloc1di8 )

# define F90_CopyDesc1DL1      F90_SYMBOL_COND( f90_copydesc1dl1 )
# define F90_CreateArray1DL1   F90_SYMBOL_COND( f90_createarray1dl1 )
# define F90_DestroyArray1DL1  F90_SYMBOL_COND( f90_destroyarray1dl1 )
# define F90_Dealloc1DL1       F90_SYMBOL_COND( f90_dealloc1dl1 )

# define F90_CopyDesc1DL2      F90_SYMBOL_COND( f90_copydesc1dl2 )
# define F90_CreateArray1DL2   F90_SYMBOL_COND( f90_createarray1dl2 )
# define F90_DestroyArray1DL2  F90_SYMBOL_COND( f90_destroyarray1dl2 )
# define F90_Dealloc1DL2       F90_SYMBOL_COND( f90_dealloc1dl2 )

# define F90_CopyDesc1DL      F90_SYMBOL_COND( f90_copydesc1dl )
# define F90_CreateArray1DL   F90_SYMBOL_COND( f90_createarray1dl )
# define F90_DestroyArray1DL  F90_SYMBOL_COND( f90_destroyarray1dl )
# define F90_Dealloc1DL       F90_SYMBOL_COND( f90_dealloc1dl )

# define F90_CopyDesc1DL4      F90_SYMBOL_COND( f90_copydesc1dl4 )
# define F90_CreateArray1DL4   F90_SYMBOL_COND( f90_createarray1dl4 )
# define F90_DestroyArray1DL4  F90_SYMBOL_COND( f90_destroyarray1dl4 )
# define F90_Dealloc1DL4       F90_SYMBOL_COND( f90_dealloc1dl4 )

# define F90_CopyDesc1DL8      F90_SYMBOL_COND( f90_copydesc1dl8 )
# define F90_CreateArray1DL8   F90_SYMBOL_COND( f90_createarray1dl8 )
# define F90_DestroyArray1DL8  F90_SYMBOL_COND( f90_destroyarray1dl8 )
# define F90_Dealloc1DL8       F90_SYMBOL_COND( f90_dealloc1dl8 )

# define F90_CopyDesc1DR      F90_SYMBOL_COND( f90_copydesc1dr )
# define F90_CreateArray1DR   F90_SYMBOL_COND( f90_createarray1dr )
# define F90_DestroyArray1DR  F90_SYMBOL_COND( f90_destroyarray1dr )
# define F90_Dealloc1DR       F90_SYMBOL_COND( f90_dealloc1dr )

# define F90_CopyDesc1DD      F90_SYMBOL_COND( f90_copydesc1dd )
# define F90_CreateArray1DD   F90_SYMBOL_COND( f90_createarray1dd )
# define F90_DestroyArray1DD  F90_SYMBOL_COND( f90_destroyarray1dd )
# define F90_Dealloc1DD       F90_SYMBOL_COND( f90_dealloc1dd )

# define F90_CopyDesc1DC      F90_SYMBOL_COND( f90_copydesc1dc )
# define F90_CreateArray1DC   F90_SYMBOL_COND( f90_createarray1dc )
# define F90_DestroyArray1DC  F90_SYMBOL_COND( f90_destroyarray1dc )
# define F90_Dealloc1DC       F90_SYMBOL_COND( f90_dealloc1dc )

# define F90_CopyDesc1DDC      F90_SYMBOL_COND( f90_copydesc1ddc )
# define F90_CreateArray1DDC   F90_SYMBOL_COND( f90_createarray1ddc )
# define F90_DestroyArray1DDC  F90_SYMBOL_COND( f90_destroyarray1ddc )
# define F90_Dealloc1DDC       F90_SYMBOL_COND( f90_dealloc1ddc )

# define F90_CopyDesc2DI1      F90_SYMBOL_COND( f90_copydesc2di1 )
# define F90_CreateArray2DI1   F90_SYMBOL_COND( f90_createarray2di1 )
# define F90_DestroyArray2DI1  F90_SYMBOL_COND( f90_destroyarray2di1 )
# define F90_Dealloc2DI1       F90_SYMBOL_COND( f90_dealloc2di1 )

# define F90_CopyDesc2DI2      F90_SYMBOL_COND( f90_copydesc2di2 )
# define F90_CreateArray2DI2   F90_SYMBOL_COND( f90_createarray2di2 )
# define F90_DestroyArray2DI2  F90_SYMBOL_COND( f90_destroyarray2di2 )
# define F90_Dealloc2DI2       F90_SYMBOL_COND( f90_dealloc2di2 )

# define F90_CopyDesc2DI      F90_SYMBOL_COND( f90_copydesc2di )
# define F90_CreateArray2DI   F90_SYMBOL_COND( f90_createarray2di )
# define F90_DestroyArray2DI  F90_SYMBOL_COND( f90_destroyarray2di )
# define F90_Dealloc2DI       F90_SYMBOL_COND( f90_dealloc2di )

# define F90_CopyDesc2DI4      F90_SYMBOL_COND( f90_copydesc2di4 )
# define F90_CreateArray2DI4   F90_SYMBOL_COND( f90_createarray2di4 )
# define F90_DestroyArray2DI4  F90_SYMBOL_COND( f90_destroyarray2di4 )
# define F90_Dealloc2DI4       F90_SYMBOL_COND( f90_dealloc2di4 )

# define F90_CopyDesc2DI8      F90_SYMBOL_COND( f90_copydesc2di8 )
# define F90_CreateArray2DI8   F90_SYMBOL_COND( f90_createarray2di8 )
# define F90_DestroyArray2DI8  F90_SYMBOL_COND( f90_destroyarray2di8 )
# define F90_Dealloc2DI8       F90_SYMBOL_COND( f90_dealloc2di8 )

# define F90_CopyDesc2DL1      F90_SYMBOL_COND( f90_copydesc2dl1 )
# define F90_CreateArray2DL1   F90_SYMBOL_COND( f90_createarray2dl1 )
# define F90_DestroyArray2DL1  F90_SYMBOL_COND( f90_destroyarray2dl1 )
# define F90_Dealloc2DL1       F90_SYMBOL_COND( f90_dealloc2dl1 )

# define F90_CopyDesc2DL2      F90_SYMBOL_COND( f90_copydesc2dl2 )
# define F90_CreateArray2DL2   F90_SYMBOL_COND( f90_createarray2dl2 )
# define F90_DestroyArray2DL2  F90_SYMBOL_COND( f90_destroyarray2dl2 )
# define F90_Dealloc2DL2       F90_SYMBOL_COND( f90_dealloc2dl2 )

# define F90_CopyDesc2DL      F90_SYMBOL_COND( f90_copydesc2dl )
# define F90_CreateArray2DL   F90_SYMBOL_COND( f90_createarray2dl )
# define F90_DestroyArray2DL  F90_SYMBOL_COND( f90_destroyarray2dl )
# define F90_Dealloc2DL       F90_SYMBOL_COND( f90_dealloc2dl )

# define F90_CopyDesc2DL4      F90_SYMBOL_COND( f90_copydesc2dl4 )
# define F90_CreateArray2DL4   F90_SYMBOL_COND( f90_createarray2dl4 )
# define F90_DestroyArray2DL4  F90_SYMBOL_COND( f90_destroyarray2dl4 )
# define F90_Dealloc2DL4       F90_SYMBOL_COND( f90_dealloc2dl4 )

# define F90_CopyDesc2DL8      F90_SYMBOL_COND( f90_copydesc2dl8 )
# define F90_CreateArray2DL8   F90_SYMBOL_COND( f90_createarray2dl8 )
# define F90_DestroyArray2DL8  F90_SYMBOL_COND( f90_destroyarray2dl8 )
# define F90_Dealloc2DL8       F90_SYMBOL_COND( f90_dealloc2dl8 )

# define F90_CopyDesc2DR      F90_SYMBOL_COND( f90_copydesc2dr )
# define F90_CreateArray2DR   F90_SYMBOL_COND( f90_createarray2dr )
# define F90_DestroyArray2DR  F90_SYMBOL_COND( f90_destroyarray2dr )
# define F90_Dealloc2DR       F90_SYMBOL_COND( f90_dealloc2dr )

# define F90_CopyDesc2DD      F90_SYMBOL_COND( f90_copydesc2dd )
# define F90_CreateArray2DD   F90_SYMBOL_COND( f90_createarray2dd )
# define F90_DestroyArray2DD  F90_SYMBOL_COND( f90_destroyarray2dd )
# define F90_Dealloc2DD       F90_SYMBOL_COND( f90_dealloc2dd )

# define F90_CopyDesc2DC      F90_SYMBOL_COND( f90_copydesc2dc )
# define F90_CreateArray2DC   F90_SYMBOL_COND( f90_createarray2dc )
# define F90_DestroyArray2DC  F90_SYMBOL_COND( f90_destroyarray2dc )
# define F90_Dealloc2DC       F90_SYMBOL_COND( f90_dealloc2dc )

# define F90_CopyDesc2DDC      F90_SYMBOL_COND( f90_copydesc2ddc )
# define F90_CreateArray2DDC   F90_SYMBOL_COND( f90_createarray2ddc )
# define F90_DestroyArray2DDC  F90_SYMBOL_COND( f90_destroyarray2ddc )
# define F90_Dealloc2DDC       F90_SYMBOL_COND( f90_dealloc2ddc )

# define F90_CopyDesc3DI1      F90_SYMBOL_COND( f90_copydesc3di1 )
# define F90_CreateArray3DI1   F90_SYMBOL_COND( f90_createarray3di1 )
# define F90_DestroyArray3DI1  F90_SYMBOL_COND( f90_destroyarray3di1 )
# define F90_Dealloc3DI1       F90_SYMBOL_COND( f90_dealloc3di1 )

# define F90_CopyDesc3DI2      F90_SYMBOL_COND( f90_copydesc3di2 )
# define F90_CreateArray3DI2   F90_SYMBOL_COND( f90_createarray3di2 )
# define F90_DestroyArray3DI2  F90_SYMBOL_COND( f90_destroyarray3di2 )
# define F90_Dealloc3DI2       F90_SYMBOL_COND( f90_dealloc3di2 )

# define F90_CopyDesc3DI      F90_SYMBOL_COND( f90_copydesc3di )
# define F90_CreateArray3DI   F90_SYMBOL_COND( f90_createarray3di )
# define F90_DestroyArray3DI  F90_SYMBOL_COND( f90_destroyarray3di )
# define F90_Dealloc3DI       F90_SYMBOL_COND( f90_dealloc3di )

# define F90_CopyDesc3DI4      F90_SYMBOL_COND( f90_copydesc3di4 )
# define F90_CreateArray3DI4   F90_SYMBOL_COND( f90_createarray3di4 )
# define F90_DestroyArray3DI4  F90_SYMBOL_COND( f90_destroyarray3di4 )
# define F90_Dealloc3DI4       F90_SYMBOL_COND( f90_dealloc3di4 )

# define F90_CopyDesc3DI8      F90_SYMBOL_COND( f90_copydesc3di8 )
# define F90_CreateArray3DI8   F90_SYMBOL_COND( f90_createarray3di8 )
# define F90_DestroyArray3DI8  F90_SYMBOL_COND( f90_destroyarray3di8 )
# define F90_Dealloc3DI8       F90_SYMBOL_COND( f90_dealloc3di8 )

# define F90_CopyDesc3DL1      F90_SYMBOL_COND( f90_copydesc3dl1 )
# define F90_CreateArray3DL1   F90_SYMBOL_COND( f90_createarray3dl1 )
# define F90_DestroyArray3DL1  F90_SYMBOL_COND( f90_destroyarray3dl1 )
# define F90_Dealloc3DL1       F90_SYMBOL_COND( f90_dealloc3dl1 )

# define F90_CopyDesc3DL2      F90_SYMBOL_COND( f90_copydesc3dl2 )
# define F90_CreateArray3DL2   F90_SYMBOL_COND( f90_createarray3dl2 )
# define F90_DestroyArray3DL2  F90_SYMBOL_COND( f90_destroyarray3dl2 )
# define F90_Dealloc3DL2       F90_SYMBOL_COND( f90_dealloc3dl2 )

# define F90_CopyDesc3DL      F90_SYMBOL_COND( f90_copydesc3dl )
# define F90_CreateArray3DL   F90_SYMBOL_COND( f90_createarray3dl )
# define F90_DestroyArray3DL  F90_SYMBOL_COND( f90_destroyarray3dl )
# define F90_Dealloc3DL       F90_SYMBOL_COND( f90_dealloc3dl )

# define F90_CopyDesc3DL4      F90_SYMBOL_COND( f90_copydesc3dl4 )
# define F90_CreateArray3DL4   F90_SYMBOL_COND( f90_createarray3dl4 )
# define F90_DestroyArray3DL4  F90_SYMBOL_COND( f90_destroyarray3dl4 )
# define F90_Dealloc3DL4       F90_SYMBOL_COND( f90_dealloc3dl4 )

# define F90_CopyDesc3DL8      F90_SYMBOL_COND( f90_copydesc3dl8 )
# define F90_CreateArray3DL8   F90_SYMBOL_COND( f90_createarray3dl8 )
# define F90_DestroyArray3DL8  F90_SYMBOL_COND( f90_destroyarray3dl8 )
# define F90_Dealloc3DL8       F90_SYMBOL_COND( f90_dealloc3dl8 )

# define F90_CopyDesc3DR      F90_SYMBOL_COND( f90_copydesc3dr )
# define F90_CreateArray3DR   F90_SYMBOL_COND( f90_createarray3dr )
# define F90_DestroyArray3DR  F90_SYMBOL_COND( f90_destroyarray3dr )
# define F90_Dealloc3DR       F90_SYMBOL_COND( f90_dealloc3dr )

# define F90_CopyDesc3DD      F90_SYMBOL_COND( f90_copydesc3dd )
# define F90_CreateArray3DD   F90_SYMBOL_COND( f90_createarray3dd )
# define F90_DestroyArray3DD  F90_SYMBOL_COND( f90_destroyarray3dd )
# define F90_Dealloc3DD       F90_SYMBOL_COND( f90_dealloc3dd )

# define F90_CopyDesc3DC      F90_SYMBOL_COND( f90_copydesc3dc )
# define F90_CreateArray3DC   F90_SYMBOL_COND( f90_createarray3dc )
# define F90_DestroyArray3DC  F90_SYMBOL_COND( f90_destroyarray3dc )
# define F90_Dealloc3DC       F90_SYMBOL_COND( f90_dealloc3dc )

# define F90_CopyDesc3DDC      F90_SYMBOL_COND( f90_copydesc3ddc )
# define F90_CreateArray3DDC   F90_SYMBOL_COND( f90_createarray3ddc )
# define F90_DestroyArray3DDC  F90_SYMBOL_COND( f90_destroyarray3ddc )
# define F90_Dealloc3DDC       F90_SYMBOL_COND( f90_dealloc3ddc )

# define F90_CopyDesc4DI1      F90_SYMBOL_COND( f90_copydesc4di1 )
# define F90_CreateArray4DI1   F90_SYMBOL_COND( f90_createarray4di1 )
# define F90_DestroyArray4DI1  F90_SYMBOL_COND( f90_destroyarray4di1 )
# define F90_Dealloc4DI1       F90_SYMBOL_COND( f90_dealloc4di1 )

# define F90_CopyDesc4DI2      F90_SYMBOL_COND( f90_copydesc4di2 )
# define F90_CreateArray4DI2   F90_SYMBOL_COND( f90_createarray4di2 )
# define F90_DestroyArray4DI2  F90_SYMBOL_COND( f90_destroyarray4di2 )
# define F90_Dealloc4DI2       F90_SYMBOL_COND( f90_dealloc4di2 )

# define F90_CopyDesc4DI      F90_SYMBOL_COND( f90_copydesc4di )
# define F90_CreateArray4DI   F90_SYMBOL_COND( f90_createarray4di )
# define F90_DestroyArray4DI  F90_SYMBOL_COND( f90_destroyarray4di )
# define F90_Dealloc4DI       F90_SYMBOL_COND( f90_dealloc4di )

# define F90_CopyDesc4DI4      F90_SYMBOL_COND( f90_copydesc4di4 )
# define F90_CreateArray4DI4   F90_SYMBOL_COND( f90_createarray4di4 )
# define F90_DestroyArray4DI4  F90_SYMBOL_COND( f90_destroyarray4di4 )
# define F90_Dealloc4DI4       F90_SYMBOL_COND( f90_dealloc4di4 )

# define F90_CopyDesc4DI8      F90_SYMBOL_COND( f90_copydesc4di8 )
# define F90_CreateArray4DI8   F90_SYMBOL_COND( f90_createarray4di8 )
# define F90_DestroyArray4DI8  F90_SYMBOL_COND( f90_destroyarray4di8 )
# define F90_Dealloc4DI8       F90_SYMBOL_COND( f90_dealloc4di8 )

# define F90_CopyDesc4DL1      F90_SYMBOL_COND( f90_copydesc4dl1 )
# define F90_CreateArray4DL1   F90_SYMBOL_COND( f90_createarray4dl1 )
# define F90_DestroyArray4DL1  F90_SYMBOL_COND( f90_destroyarray4dl1 )
# define F90_Dealloc4DL1       F90_SYMBOL_COND( f90_dealloc4dl1 )

# define F90_CopyDesc4DL2      F90_SYMBOL_COND( f90_copydesc4dl2 )
# define F90_CreateArray4DL2   F90_SYMBOL_COND( f90_createarray4dl2 )
# define F90_DestroyArray4DL2  F90_SYMBOL_COND( f90_destroyarray4dl2 )
# define F90_Dealloc4DL2       F90_SYMBOL_COND( f90_dealloc4dl2 )

# define F90_CopyDesc4DL      F90_SYMBOL_COND( f90_copydesc4dl )
# define F90_CreateArray4DL   F90_SYMBOL_COND( f90_createarray4dl )
# define F90_DestroyArray4DL  F90_SYMBOL_COND( f90_destroyarray4dl )
# define F90_Dealloc4DL       F90_SYMBOL_COND( f90_dealloc4dl )

# define F90_CopyDesc4DL4      F90_SYMBOL_COND( f90_copydesc4dl4 )
# define F90_CreateArray4DL4   F90_SYMBOL_COND( f90_createarray4dl4 )
# define F90_DestroyArray4DL4  F90_SYMBOL_COND( f90_destroyarray4dl4 )
# define F90_Dealloc4DL4       F90_SYMBOL_COND( f90_dealloc4dl4 )

# define F90_CopyDesc4DL8      F90_SYMBOL_COND( f90_copydesc4dl8 )
# define F90_CreateArray4DL8   F90_SYMBOL_COND( f90_createarray4dl8 )
# define F90_DestroyArray4DL8  F90_SYMBOL_COND( f90_destroyarray4dl8 )
# define F90_Dealloc4DL8       F90_SYMBOL_COND( f90_dealloc4dl8 )

# define F90_CopyDesc4DR      F90_SYMBOL_COND( f90_copydesc4dr )
# define F90_CreateArray4DR   F90_SYMBOL_COND( f90_createarray4dr )
# define F90_DestroyArray4DR  F90_SYMBOL_COND( f90_destroyarray4dr )
# define F90_Dealloc4DR       F90_SYMBOL_COND( f90_dealloc4dr )

# define F90_CopyDesc4DD      F90_SYMBOL_COND( f90_copydesc4dd )
# define F90_CreateArray4DD   F90_SYMBOL_COND( f90_createarray4dd )
# define F90_DestroyArray4DD  F90_SYMBOL_COND( f90_destroyarray4dd )
# define F90_Dealloc4DD       F90_SYMBOL_COND( f90_dealloc4dd )

# define F90_CopyDesc4DC      F90_SYMBOL_COND( f90_copydesc4dc )
# define F90_CreateArray4DC   F90_SYMBOL_COND( f90_createarray4dc )
# define F90_DestroyArray4DC  F90_SYMBOL_COND( f90_destroyarray4dc )
# define F90_Dealloc4DC       F90_SYMBOL_COND( f90_dealloc4dc )

# define F90_CopyDesc4DDC      F90_SYMBOL_COND( f90_copydesc4ddc )
# define F90_CreateArray4DDC   F90_SYMBOL_COND( f90_createarray4ddc )
# define F90_DestroyArray4DDC  F90_SYMBOL_COND( f90_destroyarray4ddc )
# define F90_Dealloc4DDC       F90_SYMBOL_COND( f90_dealloc4ddc )

# define F90_CopyDesc5DI1      F90_SYMBOL_COND( f90_copydesc5di1 )
# define F90_CreateArray5DI1   F90_SYMBOL_COND( f90_createarray5di1 )
# define F90_DestroyArray5DI1  F90_SYMBOL_COND( f90_destroyarray5di1 )
# define F90_Dealloc5DI1       F90_SYMBOL_COND( f90_dealloc5di1 )

# define F90_CopyDesc5DI2      F90_SYMBOL_COND( f90_copydesc5di2 )
# define F90_CreateArray5DI2   F90_SYMBOL_COND( f90_createarray5di2 )
# define F90_DestroyArray5DI2  F90_SYMBOL_COND( f90_destroyarray5di2 )
# define F90_Dealloc5DI2       F90_SYMBOL_COND( f90_dealloc5di2 )

# define F90_CopyDesc5DI      F90_SYMBOL_COND( f90_copydesc5di )
# define F90_CreateArray5DI   F90_SYMBOL_COND( f90_createarray5di )
# define F90_DestroyArray5DI  F90_SYMBOL_COND( f90_destroyarray5di )
# define F90_Dealloc5DI       F90_SYMBOL_COND( f90_dealloc5di )

# define F90_CopyDesc5DI4      F90_SYMBOL_COND( f90_copydesc5di4 )
# define F90_CreateArray5DI4   F90_SYMBOL_COND( f90_createarray5di4 )
# define F90_DestroyArray5DI4  F90_SYMBOL_COND( f90_destroyarray5di4 )
# define F90_Dealloc5DI4       F90_SYMBOL_COND( f90_dealloc5di4 )

# define F90_CopyDesc5DI8      F90_SYMBOL_COND( f90_copydesc5di8 )
# define F90_CreateArray5DI8   F90_SYMBOL_COND( f90_createarray5di8 )
# define F90_DestroyArray5DI8  F90_SYMBOL_COND( f90_destroyarray5di8 )
# define F90_Dealloc5DI8       F90_SYMBOL_COND( f90_dealloc5di8 )

# define F90_CopyDesc5DL1      F90_SYMBOL_COND( f90_copydesc5dl1 )
# define F90_CreateArray5DL1   F90_SYMBOL_COND( f90_createarray5dl1 )
# define F90_DestroyArray5DL1  F90_SYMBOL_COND( f90_destroyarray5dl1 )
# define F90_Dealloc5DL1       F90_SYMBOL_COND( f90_dealloc5dl1 )

# define F90_CopyDesc5DL2      F90_SYMBOL_COND( f90_copydesc5dl2 )
# define F90_CreateArray5DL2   F90_SYMBOL_COND( f90_createarray5dl2 )
# define F90_DestroyArray5DL2  F90_SYMBOL_COND( f90_destroyarray5dl2 )
# define F90_Dealloc5DL2       F90_SYMBOL_COND( f90_dealloc5dl2 )

# define F90_CopyDesc5DL      F90_SYMBOL_COND( f90_copydesc5dl )
# define F90_CreateArray5DL   F90_SYMBOL_COND( f90_createarray5dl )
# define F90_DestroyArray5DL  F90_SYMBOL_COND( f90_destroyarray5dl )
# define F90_Dealloc5DL       F90_SYMBOL_COND( f90_dealloc5dl )

# define F90_CopyDesc5DL4      F90_SYMBOL_COND( f90_copydesc5dl4 )
# define F90_CreateArray5DL4   F90_SYMBOL_COND( f90_createarray5dl4 )
# define F90_DestroyArray5DL4  F90_SYMBOL_COND( f90_destroyarray5dl4 )
# define F90_Dealloc5DL4       F90_SYMBOL_COND( f90_dealloc5dl4 )

# define F90_CopyDesc5DL8      F90_SYMBOL_COND( f90_copydesc5dl8 )
# define F90_CreateArray5DL8   F90_SYMBOL_COND( f90_createarray5dl8 )
# define F90_DestroyArray5DL8  F90_SYMBOL_COND( f90_destroyarray5dl8 )
# define F90_Dealloc5DL8       F90_SYMBOL_COND( f90_dealloc5dl8 )

# define F90_CopyDesc5DR      F90_SYMBOL_COND( f90_copydesc5dr )
# define F90_CreateArray5DR   F90_SYMBOL_COND( f90_createarray5dr )
# define F90_DestroyArray5DR  F90_SYMBOL_COND( f90_destroyarray5dr )
# define F90_Dealloc5DR       F90_SYMBOL_COND( f90_dealloc5dr )

# define F90_CopyDesc5DD      F90_SYMBOL_COND( f90_copydesc5dd )
# define F90_CreateArray5DD   F90_SYMBOL_COND( f90_createarray5dd )
# define F90_DestroyArray5DD  F90_SYMBOL_COND( f90_destroyarray5dd )
# define F90_Dealloc5DD       F90_SYMBOL_COND( f90_dealloc5dd )

# define F90_CopyDesc5DC      F90_SYMBOL_COND( f90_copydesc5dc )
# define F90_CreateArray5DC   F90_SYMBOL_COND( f90_createarray5dc )
# define F90_DestroyArray5DC  F90_SYMBOL_COND( f90_destroyarray5dc )
# define F90_Dealloc5DC       F90_SYMBOL_COND( f90_dealloc5dc )

# define F90_CopyDesc5DDC      F90_SYMBOL_COND( f90_copydesc5ddc )
# define F90_CreateArray5DDC   F90_SYMBOL_COND( f90_createarray5ddc )
# define F90_DestroyArray5DDC  F90_SYMBOL_COND( f90_destroyarray5ddc )
# define F90_Dealloc5DDC       F90_SYMBOL_COND( f90_dealloc5ddc )

# define F90_CopyDesc6DI1      F90_SYMBOL_COND( f90_copydesc6di1 )
# define F90_CreateArray6DI1   F90_SYMBOL_COND( f90_createarray6di1 )
# define F90_DestroyArray6DI1  F90_SYMBOL_COND( f90_destroyarray6di1 )
# define F90_Dealloc6DI1       F90_SYMBOL_COND( f90_dealloc6di1 )

# define F90_CopyDesc6DI2      F90_SYMBOL_COND( f90_copydesc6di2 )
# define F90_CreateArray6DI2   F90_SYMBOL_COND( f90_createarray6di2 )
# define F90_DestroyArray6DI2  F90_SYMBOL_COND( f90_destroyarray6di2 )
# define F90_Dealloc6DI2       F90_SYMBOL_COND( f90_dealloc6di2 )

# define F90_CopyDesc6DI      F90_SYMBOL_COND( f90_copydesc6di )
# define F90_CreateArray6DI   F90_SYMBOL_COND( f90_createarray6di )
# define F90_DestroyArray6DI  F90_SYMBOL_COND( f90_destroyarray6di )
# define F90_Dealloc6DI       F90_SYMBOL_COND( f90_dealloc6di )

# define F90_CopyDesc6DI4      F90_SYMBOL_COND( f90_copydesc6di4 )
# define F90_CreateArray6DI4   F90_SYMBOL_COND( f90_createarray6di4 )
# define F90_DestroyArray6DI4  F90_SYMBOL_COND( f90_destroyarray6di4 )
# define F90_Dealloc6DI4       F90_SYMBOL_COND( f90_dealloc6di4 )

# define F90_CopyDesc6DI8      F90_SYMBOL_COND( f90_copydesc6di8 )
# define F90_CreateArray6DI8   F90_SYMBOL_COND( f90_createarray6di8 )
# define F90_DestroyArray6DI8  F90_SYMBOL_COND( f90_destroyarray6di8 )
# define F90_Dealloc6DI8       F90_SYMBOL_COND( f90_dealloc6di8 )

# define F90_CopyDesc6DL1      F90_SYMBOL_COND( f90_copydesc6dl1 )
# define F90_CreateArray6DL1   F90_SYMBOL_COND( f90_createarray6dl1 )
# define F90_DestroyArray6DL1  F90_SYMBOL_COND( f90_destroyarray6dl1 )
# define F90_Dealloc6DL1       F90_SYMBOL_COND( f90_dealloc6dl1 )

# define F90_CopyDesc6DL2      F90_SYMBOL_COND( f90_copydesc6dl2 )
# define F90_CreateArray6DL2   F90_SYMBOL_COND( f90_createarray6dl2 )
# define F90_DestroyArray6DL2  F90_SYMBOL_COND( f90_destroyarray6dl2 )
# define F90_Dealloc6DL2       F90_SYMBOL_COND( f90_dealloc6dl2 )

# define F90_CopyDesc6DL      F90_SYMBOL_COND( f90_copydesc6dl )
# define F90_CreateArray6DL   F90_SYMBOL_COND( f90_createarray6dl )
# define F90_DestroyArray6DL  F90_SYMBOL_COND( f90_destroyarray6dl )
# define F90_Dealloc6DL       F90_SYMBOL_COND( f90_dealloc6dl )

# define F90_CopyDesc6DL4      F90_SYMBOL_COND( f90_copydesc6dl4 )
# define F90_CreateArray6DL4   F90_SYMBOL_COND( f90_createarray6dl4 )
# define F90_DestroyArray6DL4  F90_SYMBOL_COND( f90_destroyarray6dl4 )
# define F90_Dealloc6DL4       F90_SYMBOL_COND( f90_dealloc6dl4 )

# define F90_CopyDesc6DL8      F90_SYMBOL_COND( f90_copydesc6dl8 )
# define F90_CreateArray6DL8   F90_SYMBOL_COND( f90_createarray6dl8 )
# define F90_DestroyArray6DL8  F90_SYMBOL_COND( f90_destroyarray6dl8 )
# define F90_Dealloc6DL8       F90_SYMBOL_COND( f90_dealloc6dl8 )

# define F90_CopyDesc6DR      F90_SYMBOL_COND( f90_copydesc6dr )
# define F90_CreateArray6DR   F90_SYMBOL_COND( f90_createarray6dr )
# define F90_DestroyArray6DR  F90_SYMBOL_COND( f90_destroyarray6dr )
# define F90_Dealloc6DR       F90_SYMBOL_COND( f90_dealloc6dr )

# define F90_CopyDesc6DD      F90_SYMBOL_COND( f90_copydesc6dd )
# define F90_CreateArray6DD   F90_SYMBOL_COND( f90_createarray6dd )
# define F90_DestroyArray6DD  F90_SYMBOL_COND( f90_destroyarray6dd )
# define F90_Dealloc6DD       F90_SYMBOL_COND( f90_dealloc6dd )

# define F90_CopyDesc6DC      F90_SYMBOL_COND( f90_copydesc6dc )
# define F90_CreateArray6DC   F90_SYMBOL_COND( f90_createarray6dc )
# define F90_DestroyArray6DC  F90_SYMBOL_COND( f90_destroyarray6dc )
# define F90_Dealloc6DC       F90_SYMBOL_COND( f90_dealloc6dc )

# define F90_CopyDesc6DDC      F90_SYMBOL_COND( f90_copydesc6ddc )
# define F90_CreateArray6DDC   F90_SYMBOL_COND( f90_createarray6ddc )
# define F90_DestroyArray6DDC  F90_SYMBOL_COND( f90_destroyarray6ddc )
# define F90_Dealloc6DDC       F90_SYMBOL_COND( f90_dealloc6ddc )

# define F90_CopyDesc7DI1      F90_SYMBOL_COND( f90_copydesc7di1 )
# define F90_CreateArray7DI1   F90_SYMBOL_COND( f90_createarray7di1 )
# define F90_DestroyArray7DI1  F90_SYMBOL_COND( f90_destroyarray7di1 )
# define F90_Dealloc7DI1       F90_SYMBOL_COND( f90_dealloc7di1 )

# define F90_CopyDesc7DI2      F90_SYMBOL_COND( f90_copydesc7di2 )
# define F90_CreateArray7DI2   F90_SYMBOL_COND( f90_createarray7di2 )
# define F90_DestroyArray7DI2  F90_SYMBOL_COND( f90_destroyarray7di2 )
# define F90_Dealloc7DI2       F90_SYMBOL_COND( f90_dealloc7di2 )

# define F90_CopyDesc7DI      F90_SYMBOL_COND( f90_copydesc7di )
# define F90_CreateArray7DI   F90_SYMBOL_COND( f90_createarray7di )
# define F90_DestroyArray7DI  F90_SYMBOL_COND( f90_destroyarray7di )
# define F90_Dealloc7DI       F90_SYMBOL_COND( f90_dealloc7di )

# define F90_CopyDesc7DI4      F90_SYMBOL_COND( f90_copydesc7di4 )
# define F90_CreateArray7DI4   F90_SYMBOL_COND( f90_createarray7di4 )
# define F90_DestroyArray7DI4  F90_SYMBOL_COND( f90_destroyarray7di4 )
# define F90_Dealloc7DI4       F90_SYMBOL_COND( f90_dealloc7di4 )

# define F90_CopyDesc7DI8      F90_SYMBOL_COND( f90_copydesc7di8 )
# define F90_CreateArray7DI8   F90_SYMBOL_COND( f90_createarray7di8 )
# define F90_DestroyArray7DI8  F90_SYMBOL_COND( f90_destroyarray7di8 )
# define F90_Dealloc7DI8       F90_SYMBOL_COND( f90_dealloc7di8 )

# define F90_CopyDesc7DL1      F90_SYMBOL_COND( f90_copydesc7dl1 )
# define F90_CreateArray7DL1   F90_SYMBOL_COND( f90_createarray7dl1 )
# define F90_DestroyArray7DL1  F90_SYMBOL_COND( f90_destroyarray7dl1 )
# define F90_Dealloc7DL1       F90_SYMBOL_COND( f90_dealloc7dl1 )

# define F90_CopyDesc7DL2      F90_SYMBOL_COND( f90_copydesc7dl2 )
# define F90_CreateArray7DL2   F90_SYMBOL_COND( f90_createarray7dl2 )
# define F90_DestroyArray7DL2  F90_SYMBOL_COND( f90_destroyarray7dl2 )
# define F90_Dealloc7DL2       F90_SYMBOL_COND( f90_dealloc7dl2 )

# define F90_CopyDesc7DL      F90_SYMBOL_COND( f90_copydesc7dl )
# define F90_CreateArray7DL   F90_SYMBOL_COND( f90_createarray7dl )
# define F90_DestroyArray7DL  F90_SYMBOL_COND( f90_destroyarray7dl )
# define F90_Dealloc7DL       F90_SYMBOL_COND( f90_dealloc7dl )

# define F90_CopyDesc7DL4      F90_SYMBOL_COND( f90_copydesc7dl4 )
# define F90_CreateArray7DL4   F90_SYMBOL_COND( f90_createarray7dl4 )
# define F90_DestroyArray7DL4  F90_SYMBOL_COND( f90_destroyarray7dl4 )
# define F90_Dealloc7DL4       F90_SYMBOL_COND( f90_dealloc7dl4 )

# define F90_CopyDesc7DL8      F90_SYMBOL_COND( f90_copydesc7dl8 )
# define F90_CreateArray7DL8   F90_SYMBOL_COND( f90_createarray7dl8 )
# define F90_DestroyArray7DL8  F90_SYMBOL_COND( f90_destroyarray7dl8 )
# define F90_Dealloc7DL8       F90_SYMBOL_COND( f90_dealloc7dl8 )

# define F90_CopyDesc7DR      F90_SYMBOL_COND( f90_copydesc7dr )
# define F90_CreateArray7DR   F90_SYMBOL_COND( f90_createarray7dr )
# define F90_DestroyArray7DR  F90_SYMBOL_COND( f90_destroyarray7dr )
# define F90_Dealloc7DR       F90_SYMBOL_COND( f90_dealloc7dr )

# define F90_CopyDesc7DD      F90_SYMBOL_COND( f90_copydesc7dd )
# define F90_CreateArray7DD   F90_SYMBOL_COND( f90_createarray7dd )
# define F90_DestroyArray7DD  F90_SYMBOL_COND( f90_destroyarray7dd )
# define F90_Dealloc7DD       F90_SYMBOL_COND( f90_dealloc7dd )

# define F90_CopyDesc7DC      F90_SYMBOL_COND( f90_copydesc7dc )
# define F90_CreateArray7DC   F90_SYMBOL_COND( f90_createarray7dc )
# define F90_DestroyArray7DC  F90_SYMBOL_COND( f90_destroyarray7dc )
# define F90_Dealloc7DC       F90_SYMBOL_COND( f90_dealloc7dc )

# define F90_CopyDesc7DDC      F90_SYMBOL_COND( f90_copydesc7ddc )
# define F90_CreateArray7DDC   F90_SYMBOL_COND( f90_createarray7ddc )
# define F90_DestroyArray7DDC  F90_SYMBOL_COND( f90_destroyarray7ddc )
# define F90_Dealloc7DDC       F90_SYMBOL_COND( f90_dealloc7ddc )

#endif /* F90_SYM_CASE_LOWER */


#ifdef F90_SYM_CASE_MIXED

# define F90_CopyDesc1DI1      F90_SYMBOL_COND( F90_CopyDesc1DI1 )
# define F90_CreateArray1DI1   F90_SYMBOL_COND( F90_CreateArray1DI1 )
# define F90_DestroyArray1DI1  F90_SYMBOL_COND( F90_DestroyArray1DI1 )
# define F90_Dealloc1DI1       F90_SYMBOL_COND( F90_Dealloc1DI1 )

# define F90_CopyDesc1DI2      F90_SYMBOL_COND( F90_CopyDesc1DI2 )
# define F90_CreateArray1DI2   F90_SYMBOL_COND( F90_CreateArray1DI2 )
# define F90_DestroyArray1DI2  F90_SYMBOL_COND( F90_DestroyArray1DI2 )
# define F90_Dealloc1DI2       F90_SYMBOL_COND( F90_Dealloc1DI2 )

# define F90_CopyDesc1DI      F90_SYMBOL_COND( F90_CopyDesc1DI )
# define F90_CreateArray1DI   F90_SYMBOL_COND( F90_CreateArray1DI )
# define F90_DestroyArray1DI  F90_SYMBOL_COND( F90_DestroyArray1DI )
# define F90_Dealloc1DI       F90_SYMBOL_COND( F90_Dealloc1DI )

# define F90_CopyDesc1DI4      F90_SYMBOL_COND( F90_CopyDesc1DI4 )
# define F90_CreateArray1DI4   F90_SYMBOL_COND( F90_CreateArray1DI4 )
# define F90_DestroyArray1DI4  F90_SYMBOL_COND( F90_DestroyArray1DI4 )
# define F90_Dealloc1DI4       F90_SYMBOL_COND( F90_Dealloc1DI4 )

# define F90_CopyDesc1DI8      F90_SYMBOL_COND( F90_CopyDesc1DI8 )
# define F90_CreateArray1DI8   F90_SYMBOL_COND( F90_CreateArray1DI8 )
# define F90_DestroyArray1DI8  F90_SYMBOL_COND( F90_DestroyArray1DI8 )
# define F90_Dealloc1DI8       F90_SYMBOL_COND( F90_Dealloc1DI8 )

# define F90_CopyDesc1DL1      F90_SYMBOL_COND( F90_CopyDesc1DL1 )
# define F90_CreateArray1DL1   F90_SYMBOL_COND( F90_CreateArray1DL1 )
# define F90_DestroyArray1DL1  F90_SYMBOL_COND( F90_DestroyArray1DL1 )
# define F90_Dealloc1DL1       F90_SYMBOL_COND( F90_Dealloc1DL1 )

# define F90_CopyDesc1DL2      F90_SYMBOL_COND( F90_CopyDesc1DL2 )
# define F90_CreateArray1DL2   F90_SYMBOL_COND( F90_CreateArray1DL2 )
# define F90_DestroyArray1DL2  F90_SYMBOL_COND( F90_DestroyArray1DL2 )
# define F90_Dealloc1DL2       F90_SYMBOL_COND( F90_Dealloc1DL2 )

# define F90_CopyDesc1DL      F90_SYMBOL_COND( F90_CopyDesc1DL )
# define F90_CreateArray1DL   F90_SYMBOL_COND( F90_CreateArray1DL )
# define F90_DestroyArray1DL  F90_SYMBOL_COND( F90_DestroyArray1DL )
# define F90_Dealloc1DL       F90_SYMBOL_COND( F90_Dealloc1DL )

# define F90_CopyDesc1DL4      F90_SYMBOL_COND( F90_CopyDesc1DL4 )
# define F90_CreateArray1DL4   F90_SYMBOL_COND( F90_CreateArray1DL4 )
# define F90_DestroyArray1DL4  F90_SYMBOL_COND( F90_DestroyArray1DL4 )
# define F90_Dealloc1DL4       F90_SYMBOL_COND( F90_Dealloc1DL4 )

# define F90_CopyDesc1DL8      F90_SYMBOL_COND( F90_CopyDesc1DL8 )
# define F90_CreateArray1DL8   F90_SYMBOL_COND( F90_CreateArray1DL8 )
# define F90_DestroyArray1DL8  F90_SYMBOL_COND( F90_DestroyArray1DL8 )
# define F90_Dealloc1DL8       F90_SYMBOL_COND( F90_Dealloc1DL8 )

# define F90_CopyDesc1DR      F90_SYMBOL_COND( F90_CopyDesc1DR )
# define F90_CreateArray1DR   F90_SYMBOL_COND( F90_CreateArray1DR )
# define F90_DestroyArray1DR  F90_SYMBOL_COND( F90_DestroyArray1DR )
# define F90_Dealloc1DR       F90_SYMBOL_COND( F90_Dealloc1DR )

# define F90_CopyDesc1DD      F90_SYMBOL_COND( F90_CopyDesc1DD )
# define F90_CreateArray1DD   F90_SYMBOL_COND( F90_CreateArray1DD )
# define F90_DestroyArray1DD  F90_SYMBOL_COND( F90_DestroyArray1DD )
# define F90_Dealloc1DD       F90_SYMBOL_COND( F90_Dealloc1DD )

# define F90_CopyDesc1DC      F90_SYMBOL_COND( F90_CopyDesc1DC )
# define F90_CreateArray1DC   F90_SYMBOL_COND( F90_CreateArray1DC )
# define F90_DestroyArray1DC  F90_SYMBOL_COND( F90_DestroyArray1DC )
# define F90_Dealloc1DC       F90_SYMBOL_COND( F90_Dealloc1DC )

# define F90_CopyDesc1DDC      F90_SYMBOL_COND( F90_CopyDesc1DDC )
# define F90_CreateArray1DDC   F90_SYMBOL_COND( F90_CreateArray1DDC )
# define F90_DestroyArray1DDC  F90_SYMBOL_COND( F90_DestroyArray1DDC )
# define F90_Dealloc1DDC       F90_SYMBOL_COND( F90_Dealloc1DDC )

# define F90_CopyDesc2DI1      F90_SYMBOL_COND( F90_CopyDesc2DI1 )
# define F90_CreateArray2DI1   F90_SYMBOL_COND( F90_CreateArray2DI1 )
# define F90_DestroyArray2DI1  F90_SYMBOL_COND( F90_DestroyArray2DI1 )
# define F90_Dealloc2DI1       F90_SYMBOL_COND( F90_Dealloc2DI1 )

# define F90_CopyDesc2DI2      F90_SYMBOL_COND( F90_CopyDesc2DI2 )
# define F90_CreateArray2DI2   F90_SYMBOL_COND( F90_CreateArray2DI2 )
# define F90_DestroyArray2DI2  F90_SYMBOL_COND( F90_DestroyArray2DI2 )
# define F90_Dealloc2DI2       F90_SYMBOL_COND( F90_Dealloc2DI2 )

# define F90_CopyDesc2DI      F90_SYMBOL_COND( F90_CopyDesc2DI )
# define F90_CreateArray2DI   F90_SYMBOL_COND( F90_CreateArray2DI )
# define F90_DestroyArray2DI  F90_SYMBOL_COND( F90_DestroyArray2DI )
# define F90_Dealloc2DI       F90_SYMBOL_COND( F90_Dealloc2DI )

# define F90_CopyDesc2DI4      F90_SYMBOL_COND( F90_CopyDesc2DI4 )
# define F90_CreateArray2DI4   F90_SYMBOL_COND( F90_CreateArray2DI4 )
# define F90_DestroyArray2DI4  F90_SYMBOL_COND( F90_DestroyArray2DI4 )
# define F90_Dealloc2DI4       F90_SYMBOL_COND( F90_Dealloc2DI4 )

# define F90_CopyDesc2DI8      F90_SYMBOL_COND( F90_CopyDesc2DI8 )
# define F90_CreateArray2DI8   F90_SYMBOL_COND( F90_CreateArray2DI8 )
# define F90_DestroyArray2DI8  F90_SYMBOL_COND( F90_DestroyArray2DI8 )
# define F90_Dealloc2DI8       F90_SYMBOL_COND( F90_Dealloc2DI8 )

# define F90_CopyDesc2DL1      F90_SYMBOL_COND( F90_CopyDesc2DL1 )
# define F90_CreateArray2DL1   F90_SYMBOL_COND( F90_CreateArray2DL1 )
# define F90_DestroyArray2DL1  F90_SYMBOL_COND( F90_DestroyArray2DL1 )
# define F90_Dealloc2DL1       F90_SYMBOL_COND( F90_Dealloc2DL1 )

# define F90_CopyDesc2DL2      F90_SYMBOL_COND( F90_CopyDesc2DL2 )
# define F90_CreateArray2DL2   F90_SYMBOL_COND( F90_CreateArray2DL2 )
# define F90_DestroyArray2DL2  F90_SYMBOL_COND( F90_DestroyArray2DL2 )
# define F90_Dealloc2DL2       F90_SYMBOL_COND( F90_Dealloc2DL2 )

# define F90_CopyDesc2DL      F90_SYMBOL_COND( F90_CopyDesc2DL )
# define F90_CreateArray2DL   F90_SYMBOL_COND( F90_CreateArray2DL )
# define F90_DestroyArray2DL  F90_SYMBOL_COND( F90_DestroyArray2DL )
# define F90_Dealloc2DL       F90_SYMBOL_COND( F90_Dealloc2DL )

# define F90_CopyDesc2DL4      F90_SYMBOL_COND( F90_CopyDesc2DL4 )
# define F90_CreateArray2DL4   F90_SYMBOL_COND( F90_CreateArray2DL4 )
# define F90_DestroyArray2DL4  F90_SYMBOL_COND( F90_DestroyArray2DL4 )
# define F90_Dealloc2DL4       F90_SYMBOL_COND( F90_Dealloc2DL4 )

# define F90_CopyDesc2DL8      F90_SYMBOL_COND( F90_CopyDesc2DL8 )
# define F90_CreateArray2DL8   F90_SYMBOL_COND( F90_CreateArray2DL8 )
# define F90_DestroyArray2DL8  F90_SYMBOL_COND( F90_DestroyArray2DL8 )
# define F90_Dealloc2DL8       F90_SYMBOL_COND( F90_Dealloc2DL8 )

# define F90_CopyDesc2DR      F90_SYMBOL_COND( F90_CopyDesc2DR )
# define F90_CreateArray2DR   F90_SYMBOL_COND( F90_CreateArray2DR )
# define F90_DestroyArray2DR  F90_SYMBOL_COND( F90_DestroyArray2DR )
# define F90_Dealloc2DR       F90_SYMBOL_COND( F90_Dealloc2DR )

# define F90_CopyDesc2DD      F90_SYMBOL_COND( F90_CopyDesc2DD )
# define F90_CreateArray2DD   F90_SYMBOL_COND( F90_CreateArray2DD )
# define F90_DestroyArray2DD  F90_SYMBOL_COND( F90_DestroyArray2DD )
# define F90_Dealloc2DD       F90_SYMBOL_COND( F90_Dealloc2DD )

# define F90_CopyDesc2DC      F90_SYMBOL_COND( F90_CopyDesc2DC )
# define F90_CreateArray2DC   F90_SYMBOL_COND( F90_CreateArray2DC )
# define F90_DestroyArray2DC  F90_SYMBOL_COND( F90_DestroyArray2DC )
# define F90_Dealloc2DC       F90_SYMBOL_COND( F90_Dealloc2DC )

# define F90_CopyDesc2DDC      F90_SYMBOL_COND( F90_CopyDesc2DDC )
# define F90_CreateArray2DDC   F90_SYMBOL_COND( F90_CreateArray2DDC )
# define F90_DestroyArray2DDC  F90_SYMBOL_COND( F90_DestroyArray2DDC )
# define F90_Dealloc2DDC       F90_SYMBOL_COND( F90_Dealloc2DDC )

# define F90_CopyDesc3DI1      F90_SYMBOL_COND( F90_CopyDesc3DI1 )
# define F90_CreateArray3DI1   F90_SYMBOL_COND( F90_CreateArray3DI1 )
# define F90_DestroyArray3DI1  F90_SYMBOL_COND( F90_DestroyArray3DI1 )
# define F90_Dealloc3DI1       F90_SYMBOL_COND( F90_Dealloc3DI1 )

# define F90_CopyDesc3DI2      F90_SYMBOL_COND( F90_CopyDesc3DI2 )
# define F90_CreateArray3DI2   F90_SYMBOL_COND( F90_CreateArray3DI2 )
# define F90_DestroyArray3DI2  F90_SYMBOL_COND( F90_DestroyArray3DI2 )
# define F90_Dealloc3DI2       F90_SYMBOL_COND( F90_Dealloc3DI2 )

# define F90_CopyDesc3DI      F90_SYMBOL_COND( F90_CopyDesc3DI )
# define F90_CreateArray3DI   F90_SYMBOL_COND( F90_CreateArray3DI )
# define F90_DestroyArray3DI  F90_SYMBOL_COND( F90_DestroyArray3DI )
# define F90_Dealloc3DI       F90_SYMBOL_COND( F90_Dealloc3DI )

# define F90_CopyDesc3DI4      F90_SYMBOL_COND( F90_CopyDesc3DI4 )
# define F90_CreateArray3DI4   F90_SYMBOL_COND( F90_CreateArray3DI4 )
# define F90_DestroyArray3DI4  F90_SYMBOL_COND( F90_DestroyArray3DI4 )
# define F90_Dealloc3DI4       F90_SYMBOL_COND( F90_Dealloc3DI4 )

# define F90_CopyDesc3DI8      F90_SYMBOL_COND( F90_CopyDesc3DI8 )
# define F90_CreateArray3DI8   F90_SYMBOL_COND( F90_CreateArray3DI8 )
# define F90_DestroyArray3DI8  F90_SYMBOL_COND( F90_DestroyArray3DI8 )
# define F90_Dealloc3DI8       F90_SYMBOL_COND( F90_Dealloc3DI8 )

# define F90_CopyDesc3DL1      F90_SYMBOL_COND( F90_CopyDesc3DL1 )
# define F90_CreateArray3DL1   F90_SYMBOL_COND( F90_CreateArray3DL1 )
# define F90_DestroyArray3DL1  F90_SYMBOL_COND( F90_DestroyArray3DL1 )
# define F90_Dealloc3DL1       F90_SYMBOL_COND( F90_Dealloc3DL1 )

# define F90_CopyDesc3DL2      F90_SYMBOL_COND( F90_CopyDesc3DL2 )
# define F90_CreateArray3DL2   F90_SYMBOL_COND( F90_CreateArray3DL2 )
# define F90_DestroyArray3DL2  F90_SYMBOL_COND( F90_DestroyArray3DL2 )
# define F90_Dealloc3DL2       F90_SYMBOL_COND( F90_Dealloc3DL2 )

# define F90_CopyDesc3DL      F90_SYMBOL_COND( F90_CopyDesc3DL )
# define F90_CreateArray3DL   F90_SYMBOL_COND( F90_CreateArray3DL )
# define F90_DestroyArray3DL  F90_SYMBOL_COND( F90_DestroyArray3DL )
# define F90_Dealloc3DL       F90_SYMBOL_COND( F90_Dealloc3DL )

# define F90_CopyDesc3DL4      F90_SYMBOL_COND( F90_CopyDesc3DL4 )
# define F90_CreateArray3DL4   F90_SYMBOL_COND( F90_CreateArray3DL4 )
# define F90_DestroyArray3DL4  F90_SYMBOL_COND( F90_DestroyArray3DL4 )
# define F90_Dealloc3DL4       F90_SYMBOL_COND( F90_Dealloc3DL4 )

# define F90_CopyDesc3DL8      F90_SYMBOL_COND( F90_CopyDesc3DL8 )
# define F90_CreateArray3DL8   F90_SYMBOL_COND( F90_CreateArray3DL8 )
# define F90_DestroyArray3DL8  F90_SYMBOL_COND( F90_DestroyArray3DL8 )
# define F90_Dealloc3DL8       F90_SYMBOL_COND( F90_Dealloc3DL8 )

# define F90_CopyDesc3DR      F90_SYMBOL_COND( F90_CopyDesc3DR )
# define F90_CreateArray3DR   F90_SYMBOL_COND( F90_CreateArray3DR )
# define F90_DestroyArray3DR  F90_SYMBOL_COND( F90_DestroyArray3DR )
# define F90_Dealloc3DR       F90_SYMBOL_COND( F90_Dealloc3DR )

# define F90_CopyDesc3DD      F90_SYMBOL_COND( F90_CopyDesc3DD )
# define F90_CreateArray3DD   F90_SYMBOL_COND( F90_CreateArray3DD )
# define F90_DestroyArray3DD  F90_SYMBOL_COND( F90_DestroyArray3DD )
# define F90_Dealloc3DD       F90_SYMBOL_COND( F90_Dealloc3DD )

# define F90_CopyDesc3DC      F90_SYMBOL_COND( F90_CopyDesc3DC )
# define F90_CreateArray3DC   F90_SYMBOL_COND( F90_CreateArray3DC )
# define F90_DestroyArray3DC  F90_SYMBOL_COND( F90_DestroyArray3DC )
# define F90_Dealloc3DC       F90_SYMBOL_COND( F90_Dealloc3DC )

# define F90_CopyDesc3DDC      F90_SYMBOL_COND( F90_CopyDesc3DDC )
# define F90_CreateArray3DDC   F90_SYMBOL_COND( F90_CreateArray3DDC )
# define F90_DestroyArray3DDC  F90_SYMBOL_COND( F90_DestroyArray3DDC )
# define F90_Dealloc3DDC       F90_SYMBOL_COND( F90_Dealloc3DDC )

# define F90_CopyDesc4DI1      F90_SYMBOL_COND( F90_CopyDesc4DI1 )
# define F90_CreateArray4DI1   F90_SYMBOL_COND( F90_CreateArray4DI1 )
# define F90_DestroyArray4DI1  F90_SYMBOL_COND( F90_DestroyArray4DI1 )
# define F90_Dealloc4DI1       F90_SYMBOL_COND( F90_Dealloc4DI1 )

# define F90_CopyDesc4DI2      F90_SYMBOL_COND( F90_CopyDesc4DI2 )
# define F90_CreateArray4DI2   F90_SYMBOL_COND( F90_CreateArray4DI2 )
# define F90_DestroyArray4DI2  F90_SYMBOL_COND( F90_DestroyArray4DI2 )
# define F90_Dealloc4DI2       F90_SYMBOL_COND( F90_Dealloc4DI2 )

# define F90_CopyDesc4DI      F90_SYMBOL_COND( F90_CopyDesc4DI )
# define F90_CreateArray4DI   F90_SYMBOL_COND( F90_CreateArray4DI )
# define F90_DestroyArray4DI  F90_SYMBOL_COND( F90_DestroyArray4DI )
# define F90_Dealloc4DI       F90_SYMBOL_COND( F90_Dealloc4DI )

# define F90_CopyDesc4DI4      F90_SYMBOL_COND( F90_CopyDesc4DI4 )
# define F90_CreateArray4DI4   F90_SYMBOL_COND( F90_CreateArray4DI4 )
# define F90_DestroyArray4DI4  F90_SYMBOL_COND( F90_DestroyArray4DI4 )
# define F90_Dealloc4DI4       F90_SYMBOL_COND( F90_Dealloc4DI4 )

# define F90_CopyDesc4DI8      F90_SYMBOL_COND( F90_CopyDesc4DI8 )
# define F90_CreateArray4DI8   F90_SYMBOL_COND( F90_CreateArray4DI8 )
# define F90_DestroyArray4DI8  F90_SYMBOL_COND( F90_DestroyArray4DI8 )
# define F90_Dealloc4DI8       F90_SYMBOL_COND( F90_Dealloc4DI8 )

# define F90_CopyDesc4DL1      F90_SYMBOL_COND( F90_CopyDesc4DL1 )
# define F90_CreateArray4DL1   F90_SYMBOL_COND( F90_CreateArray4DL1 )
# define F90_DestroyArray4DL1  F90_SYMBOL_COND( F90_DestroyArray4DL1 )
# define F90_Dealloc4DL1       F90_SYMBOL_COND( F90_Dealloc4DL1 )

# define F90_CopyDesc4DL2      F90_SYMBOL_COND( F90_CopyDesc4DL2 )
# define F90_CreateArray4DL2   F90_SYMBOL_COND( F90_CreateArray4DL2 )
# define F90_DestroyArray4DL2  F90_SYMBOL_COND( F90_DestroyArray4DL2 )
# define F90_Dealloc4DL2       F90_SYMBOL_COND( F90_Dealloc4DL2 )

# define F90_CopyDesc4DL      F90_SYMBOL_COND( F90_CopyDesc4DL )
# define F90_CreateArray4DL   F90_SYMBOL_COND( F90_CreateArray4DL )
# define F90_DestroyArray4DL  F90_SYMBOL_COND( F90_DestroyArray4DL )
# define F90_Dealloc4DL       F90_SYMBOL_COND( F90_Dealloc4DL )

# define F90_CopyDesc4DL4      F90_SYMBOL_COND( F90_CopyDesc4DL4 )
# define F90_CreateArray4DL4   F90_SYMBOL_COND( F90_CreateArray4DL4 )
# define F90_DestroyArray4DL4  F90_SYMBOL_COND( F90_DestroyArray4DL4 )
# define F90_Dealloc4DL4       F90_SYMBOL_COND( F90_Dealloc4DL4 )

# define F90_CopyDesc4DL8      F90_SYMBOL_COND( F90_CopyDesc4DL8 )
# define F90_CreateArray4DL8   F90_SYMBOL_COND( F90_CreateArray4DL8 )
# define F90_DestroyArray4DL8  F90_SYMBOL_COND( F90_DestroyArray4DL8 )
# define F90_Dealloc4DL8       F90_SYMBOL_COND( F90_Dealloc4DL8 )

# define F90_CopyDesc4DR      F90_SYMBOL_COND( F90_CopyDesc4DR )
# define F90_CreateArray4DR   F90_SYMBOL_COND( F90_CreateArray4DR )
# define F90_DestroyArray4DR  F90_SYMBOL_COND( F90_DestroyArray4DR )
# define F90_Dealloc4DR       F90_SYMBOL_COND( F90_Dealloc4DR )

# define F90_CopyDesc4DD      F90_SYMBOL_COND( F90_CopyDesc4DD )
# define F90_CreateArray4DD   F90_SYMBOL_COND( F90_CreateArray4DD )
# define F90_DestroyArray4DD  F90_SYMBOL_COND( F90_DestroyArray4DD )
# define F90_Dealloc4DD       F90_SYMBOL_COND( F90_Dealloc4DD )

# define F90_CopyDesc4DC      F90_SYMBOL_COND( F90_CopyDesc4DC )
# define F90_CreateArray4DC   F90_SYMBOL_COND( F90_CreateArray4DC )
# define F90_DestroyArray4DC  F90_SYMBOL_COND( F90_DestroyArray4DC )
# define F90_Dealloc4DC       F90_SYMBOL_COND( F90_Dealloc4DC )

# define F90_CopyDesc4DDC      F90_SYMBOL_COND( F90_CopyDesc4DDC )
# define F90_CreateArray4DDC   F90_SYMBOL_COND( F90_CreateArray4DDC )
# define F90_DestroyArray4DDC  F90_SYMBOL_COND( F90_DestroyArray4DDC )
# define F90_Dealloc4DDC       F90_SYMBOL_COND( F90_Dealloc4DDC )

# define F90_CopyDesc5DI1      F90_SYMBOL_COND( F90_CopyDesc5DI1 )
# define F90_CreateArray5DI1   F90_SYMBOL_COND( F90_CreateArray5DI1 )
# define F90_DestroyArray5DI1  F90_SYMBOL_COND( F90_DestroyArray5DI1 )
# define F90_Dealloc5DI1       F90_SYMBOL_COND( F90_Dealloc5DI1 )

# define F90_CopyDesc5DI2      F90_SYMBOL_COND( F90_CopyDesc5DI2 )
# define F90_CreateArray5DI2   F90_SYMBOL_COND( F90_CreateArray5DI2 )
# define F90_DestroyArray5DI2  F90_SYMBOL_COND( F90_DestroyArray5DI2 )
# define F90_Dealloc5DI2       F90_SYMBOL_COND( F90_Dealloc5DI2 )

# define F90_CopyDesc5DI      F90_SYMBOL_COND( F90_CopyDesc5DI )
# define F90_CreateArray5DI   F90_SYMBOL_COND( F90_CreateArray5DI )
# define F90_DestroyArray5DI  F90_SYMBOL_COND( F90_DestroyArray5DI )
# define F90_Dealloc5DI       F90_SYMBOL_COND( F90_Dealloc5DI )

# define F90_CopyDesc5DI4      F90_SYMBOL_COND( F90_CopyDesc5DI4 )
# define F90_CreateArray5DI4   F90_SYMBOL_COND( F90_CreateArray5DI4 )
# define F90_DestroyArray5DI4  F90_SYMBOL_COND( F90_DestroyArray5DI4 )
# define F90_Dealloc5DI4       F90_SYMBOL_COND( F90_Dealloc5DI4 )

# define F90_CopyDesc5DI8      F90_SYMBOL_COND( F90_CopyDesc5DI8 )
# define F90_CreateArray5DI8   F90_SYMBOL_COND( F90_CreateArray5DI8 )
# define F90_DestroyArray5DI8  F90_SYMBOL_COND( F90_DestroyArray5DI8 )
# define F90_Dealloc5DI8       F90_SYMBOL_COND( F90_Dealloc5DI8 )

# define F90_CopyDesc5DL1      F90_SYMBOL_COND( F90_CopyDesc5DL1 )
# define F90_CreateArray5DL1   F90_SYMBOL_COND( F90_CreateArray5DL1 )
# define F90_DestroyArray5DL1  F90_SYMBOL_COND( F90_DestroyArray5DL1 )
# define F90_Dealloc5DL1       F90_SYMBOL_COND( F90_Dealloc5DL1 )

# define F90_CopyDesc5DL2      F90_SYMBOL_COND( F90_CopyDesc5DL2 )
# define F90_CreateArray5DL2   F90_SYMBOL_COND( F90_CreateArray5DL2 )
# define F90_DestroyArray5DL2  F90_SYMBOL_COND( F90_DestroyArray5DL2 )
# define F90_Dealloc5DL2       F90_SYMBOL_COND( F90_Dealloc5DL2 )

# define F90_CopyDesc5DL      F90_SYMBOL_COND( F90_CopyDesc5DL )
# define F90_CreateArray5DL   F90_SYMBOL_COND( F90_CreateArray5DL )
# define F90_DestroyArray5DL  F90_SYMBOL_COND( F90_DestroyArray5DL )
# define F90_Dealloc5DL       F90_SYMBOL_COND( F90_Dealloc5DL )

# define F90_CopyDesc5DL4      F90_SYMBOL_COND( F90_CopyDesc5DL4 )
# define F90_CreateArray5DL4   F90_SYMBOL_COND( F90_CreateArray5DL4 )
# define F90_DestroyArray5DL4  F90_SYMBOL_COND( F90_DestroyArray5DL4 )
# define F90_Dealloc5DL4       F90_SYMBOL_COND( F90_Dealloc5DL4 )

# define F90_CopyDesc5DL8      F90_SYMBOL_COND( F90_CopyDesc5DL8 )
# define F90_CreateArray5DL8   F90_SYMBOL_COND( F90_CreateArray5DL8 )
# define F90_DestroyArray5DL8  F90_SYMBOL_COND( F90_DestroyArray5DL8 )
# define F90_Dealloc5DL8       F90_SYMBOL_COND( F90_Dealloc5DL8 )

# define F90_CopyDesc5DR      F90_SYMBOL_COND( F90_CopyDesc5DR )
# define F90_CreateArray5DR   F90_SYMBOL_COND( F90_CreateArray5DR )
# define F90_DestroyArray5DR  F90_SYMBOL_COND( F90_DestroyArray5DR )
# define F90_Dealloc5DR       F90_SYMBOL_COND( F90_Dealloc5DR )

# define F90_CopyDesc5DD      F90_SYMBOL_COND( F90_CopyDesc5DD )
# define F90_CreateArray5DD   F90_SYMBOL_COND( F90_CreateArray5DD )
# define F90_DestroyArray5DD  F90_SYMBOL_COND( F90_DestroyArray5DD )
# define F90_Dealloc5DD       F90_SYMBOL_COND( F90_Dealloc5DD )

# define F90_CopyDesc5DC      F90_SYMBOL_COND( F90_CopyDesc5DC )
# define F90_CreateArray5DC   F90_SYMBOL_COND( F90_CreateArray5DC )
# define F90_DestroyArray5DC  F90_SYMBOL_COND( F90_DestroyArray5DC )
# define F90_Dealloc5DC       F90_SYMBOL_COND( F90_Dealloc5DC )

# define F90_CopyDesc5DDC      F90_SYMBOL_COND( F90_CopyDesc5DDC )
# define F90_CreateArray5DDC   F90_SYMBOL_COND( F90_CreateArray5DDC )
# define F90_DestroyArray5DDC  F90_SYMBOL_COND( F90_DestroyArray5DDC )
# define F90_Dealloc5DDC       F90_SYMBOL_COND( F90_Dealloc5DDC )

# define F90_CopyDesc6DI1      F90_SYMBOL_COND( F90_CopyDesc6DI1 )
# define F90_CreateArray6DI1   F90_SYMBOL_COND( F90_CreateArray6DI1 )
# define F90_DestroyArray6DI1  F90_SYMBOL_COND( F90_DestroyArray6DI1 )
# define F90_Dealloc6DI1       F90_SYMBOL_COND( F90_Dealloc6DI1 )

# define F90_CopyDesc6DI2      F90_SYMBOL_COND( F90_CopyDesc6DI2 )
# define F90_CreateArray6DI2   F90_SYMBOL_COND( F90_CreateArray6DI2 )
# define F90_DestroyArray6DI2  F90_SYMBOL_COND( F90_DestroyArray6DI2 )
# define F90_Dealloc6DI2       F90_SYMBOL_COND( F90_Dealloc6DI2 )

# define F90_CopyDesc6DI      F90_SYMBOL_COND( F90_CopyDesc6DI )
# define F90_CreateArray6DI   F90_SYMBOL_COND( F90_CreateArray6DI )
# define F90_DestroyArray6DI  F90_SYMBOL_COND( F90_DestroyArray6DI )
# define F90_Dealloc6DI       F90_SYMBOL_COND( F90_Dealloc6DI )

# define F90_CopyDesc6DI4      F90_SYMBOL_COND( F90_CopyDesc6DI4 )
# define F90_CreateArray6DI4   F90_SYMBOL_COND( F90_CreateArray6DI4 )
# define F90_DestroyArray6DI4  F90_SYMBOL_COND( F90_DestroyArray6DI4 )
# define F90_Dealloc6DI4       F90_SYMBOL_COND( F90_Dealloc6DI4 )

# define F90_CopyDesc6DI8      F90_SYMBOL_COND( F90_CopyDesc6DI8 )
# define F90_CreateArray6DI8   F90_SYMBOL_COND( F90_CreateArray6DI8 )
# define F90_DestroyArray6DI8  F90_SYMBOL_COND( F90_DestroyArray6DI8 )
# define F90_Dealloc6DI8       F90_SYMBOL_COND( F90_Dealloc6DI8 )

# define F90_CopyDesc6DL1      F90_SYMBOL_COND( F90_CopyDesc6DL1 )
# define F90_CreateArray6DL1   F90_SYMBOL_COND( F90_CreateArray6DL1 )
# define F90_DestroyArray6DL1  F90_SYMBOL_COND( F90_DestroyArray6DL1 )
# define F90_Dealloc6DL1       F90_SYMBOL_COND( F90_Dealloc6DL1 )

# define F90_CopyDesc6DL2      F90_SYMBOL_COND( F90_CopyDesc6DL2 )
# define F90_CreateArray6DL2   F90_SYMBOL_COND( F90_CreateArray6DL2 )
# define F90_DestroyArray6DL2  F90_SYMBOL_COND( F90_DestroyArray6DL2 )
# define F90_Dealloc6DL2       F90_SYMBOL_COND( F90_Dealloc6DL2 )

# define F90_CopyDesc6DL      F90_SYMBOL_COND( F90_CopyDesc6DL )
# define F90_CreateArray6DL   F90_SYMBOL_COND( F90_CreateArray6DL )
# define F90_DestroyArray6DL  F90_SYMBOL_COND( F90_DestroyArray6DL )
# define F90_Dealloc6DL       F90_SYMBOL_COND( F90_Dealloc6DL )

# define F90_CopyDesc6DL4      F90_SYMBOL_COND( F90_CopyDesc6DL4 )
# define F90_CreateArray6DL4   F90_SYMBOL_COND( F90_CreateArray6DL4 )
# define F90_DestroyArray6DL4  F90_SYMBOL_COND( F90_DestroyArray6DL4 )
# define F90_Dealloc6DL4       F90_SYMBOL_COND( F90_Dealloc6DL4 )

# define F90_CopyDesc6DL8      F90_SYMBOL_COND( F90_CopyDesc6DL8 )
# define F90_CreateArray6DL8   F90_SYMBOL_COND( F90_CreateArray6DL8 )
# define F90_DestroyArray6DL8  F90_SYMBOL_COND( F90_DestroyArray6DL8 )
# define F90_Dealloc6DL8       F90_SYMBOL_COND( F90_Dealloc6DL8 )

# define F90_CopyDesc6DR      F90_SYMBOL_COND( F90_CopyDesc6DR )
# define F90_CreateArray6DR   F90_SYMBOL_COND( F90_CreateArray6DR )
# define F90_DestroyArray6DR  F90_SYMBOL_COND( F90_DestroyArray6DR )
# define F90_Dealloc6DR       F90_SYMBOL_COND( F90_Dealloc6DR )

# define F90_CopyDesc6DD      F90_SYMBOL_COND( F90_CopyDesc6DD )
# define F90_CreateArray6DD   F90_SYMBOL_COND( F90_CreateArray6DD )
# define F90_DestroyArray6DD  F90_SYMBOL_COND( F90_DestroyArray6DD )
# define F90_Dealloc6DD       F90_SYMBOL_COND( F90_Dealloc6DD )

# define F90_CopyDesc6DC      F90_SYMBOL_COND( F90_CopyDesc6DC )
# define F90_CreateArray6DC   F90_SYMBOL_COND( F90_CreateArray6DC )
# define F90_DestroyArray6DC  F90_SYMBOL_COND( F90_DestroyArray6DC )
# define F90_Dealloc6DC       F90_SYMBOL_COND( F90_Dealloc6DC )

# define F90_CopyDesc6DDC      F90_SYMBOL_COND( F90_CopyDesc6DDC )
# define F90_CreateArray6DDC   F90_SYMBOL_COND( F90_CreateArray6DDC )
# define F90_DestroyArray6DDC  F90_SYMBOL_COND( F90_DestroyArray6DDC )
# define F90_Dealloc6DDC       F90_SYMBOL_COND( F90_Dealloc6DDC )

# define F90_CopyDesc7DI1      F90_SYMBOL_COND( F90_CopyDesc7DI1 )
# define F90_CreateArray7DI1   F90_SYMBOL_COND( F90_CreateArray7DI1 )
# define F90_DestroyArray7DI1  F90_SYMBOL_COND( F90_DestroyArray7DI1 )
# define F90_Dealloc7DI1       F90_SYMBOL_COND( F90_Dealloc7DI1 )

# define F90_CopyDesc7DI2      F90_SYMBOL_COND( F90_CopyDesc7DI2 )
# define F90_CreateArray7DI2   F90_SYMBOL_COND( F90_CreateArray7DI2 )
# define F90_DestroyArray7DI2  F90_SYMBOL_COND( F90_DestroyArray7DI2 )
# define F90_Dealloc7DI2       F90_SYMBOL_COND( F90_Dealloc7DI2 )

# define F90_CopyDesc7DI      F90_SYMBOL_COND( F90_CopyDesc7DI )
# define F90_CreateArray7DI   F90_SYMBOL_COND( F90_CreateArray7DI )
# define F90_DestroyArray7DI  F90_SYMBOL_COND( F90_DestroyArray7DI )
# define F90_Dealloc7DI       F90_SYMBOL_COND( F90_Dealloc7DI )

# define F90_CopyDesc7DI4      F90_SYMBOL_COND( F90_CopyDesc7DI4 )
# define F90_CreateArray7DI4   F90_SYMBOL_COND( F90_CreateArray7DI4 )
# define F90_DestroyArray7DI4  F90_SYMBOL_COND( F90_DestroyArray7DI4 )
# define F90_Dealloc7DI4       F90_SYMBOL_COND( F90_Dealloc7DI4 )

# define F90_CopyDesc7DI8      F90_SYMBOL_COND( F90_CopyDesc7DI8 )
# define F90_CreateArray7DI8   F90_SYMBOL_COND( F90_CreateArray7DI8 )
# define F90_DestroyArray7DI8  F90_SYMBOL_COND( F90_DestroyArray7DI8 )
# define F90_Dealloc7DI8       F90_SYMBOL_COND( F90_Dealloc7DI8 )

# define F90_CopyDesc7DL1      F90_SYMBOL_COND( F90_CopyDesc7DL1 )
# define F90_CreateArray7DL1   F90_SYMBOL_COND( F90_CreateArray7DL1 )
# define F90_DestroyArray7DL1  F90_SYMBOL_COND( F90_DestroyArray7DL1 )
# define F90_Dealloc7DL1       F90_SYMBOL_COND( F90_Dealloc7DL1 )

# define F90_CopyDesc7DL2      F90_SYMBOL_COND( F90_CopyDesc7DL2 )
# define F90_CreateArray7DL2   F90_SYMBOL_COND( F90_CreateArray7DL2 )
# define F90_DestroyArray7DL2  F90_SYMBOL_COND( F90_DestroyArray7DL2 )
# define F90_Dealloc7DL2       F90_SYMBOL_COND( F90_Dealloc7DL2 )

# define F90_CopyDesc7DL      F90_SYMBOL_COND( F90_CopyDesc7DL )
# define F90_CreateArray7DL   F90_SYMBOL_COND( F90_CreateArray7DL )
# define F90_DestroyArray7DL  F90_SYMBOL_COND( F90_DestroyArray7DL )
# define F90_Dealloc7DL       F90_SYMBOL_COND( F90_Dealloc7DL )

# define F90_CopyDesc7DL4      F90_SYMBOL_COND( F90_CopyDesc7DL4 )
# define F90_CreateArray7DL4   F90_SYMBOL_COND( F90_CreateArray7DL4 )
# define F90_DestroyArray7DL4  F90_SYMBOL_COND( F90_DestroyArray7DL4 )
# define F90_Dealloc7DL4       F90_SYMBOL_COND( F90_Dealloc7DL4 )

# define F90_CopyDesc7DL8      F90_SYMBOL_COND( F90_CopyDesc7DL8 )
# define F90_CreateArray7DL8   F90_SYMBOL_COND( F90_CreateArray7DL8 )
# define F90_DestroyArray7DL8  F90_SYMBOL_COND( F90_DestroyArray7DL8 )
# define F90_Dealloc7DL8       F90_SYMBOL_COND( F90_Dealloc7DL8 )

# define F90_CopyDesc7DR      F90_SYMBOL_COND( F90_CopyDesc7DR )
# define F90_CreateArray7DR   F90_SYMBOL_COND( F90_CreateArray7DR )
# define F90_DestroyArray7DR  F90_SYMBOL_COND( F90_DestroyArray7DR )
# define F90_Dealloc7DR       F90_SYMBOL_COND( F90_Dealloc7DR )

# define F90_CopyDesc7DD      F90_SYMBOL_COND( F90_CopyDesc7DD )
# define F90_CreateArray7DD   F90_SYMBOL_COND( F90_CreateArray7DD )
# define F90_DestroyArray7DD  F90_SYMBOL_COND( F90_DestroyArray7DD )
# define F90_Dealloc7DD       F90_SYMBOL_COND( F90_Dealloc7DD )

# define F90_CopyDesc7DC      F90_SYMBOL_COND( F90_CopyDesc7DC )
# define F90_CreateArray7DC   F90_SYMBOL_COND( F90_CreateArray7DC )
# define F90_DestroyArray7DC  F90_SYMBOL_COND( F90_DestroyArray7DC )
# define F90_Dealloc7DC       F90_SYMBOL_COND( F90_Dealloc7DC )

# define F90_CopyDesc7DDC      F90_SYMBOL_COND( F90_CopyDesc7DDC )
# define F90_CreateArray7DDC   F90_SYMBOL_COND( F90_CreateArray7DDC )
# define F90_DestroyArray7DDC  F90_SYMBOL_COND( F90_DestroyArray7DDC )
# define F90_Dealloc7DDC       F90_SYMBOL_COND( F90_Dealloc7DDC )

#endif /* F90_SYM_CASE_MIXED */


#ifdef F90_SYM_CASE_UPPER

# define F90_CopyDesc1DI1      F90_SYMBOL_COND( F90_COPYDESC1DI1 )
# define F90_CreateArray1DI1   F90_SYMBOL_COND( F90_CREATEARRAY1DI1 )
# define F90_DestroyArray1DI1  F90_SYMBOL_COND( F90_DESTROYARRAY1DI1 )
# define F90_Dealloc1DI1       F90_SYMBOL_COND( F90_DEALLOC1DI1 )

# define F90_CopyDesc1DI2      F90_SYMBOL_COND( F90_COPYDESC1DI2 )
# define F90_CreateArray1DI2   F90_SYMBOL_COND( F90_CREATEARRAY1DI2 )
# define F90_DestroyArray1DI2  F90_SYMBOL_COND( F90_DESTROYARRAY1DI2 )
# define F90_Dealloc1DI2       F90_SYMBOL_COND( F90_DEALLOC1DI2 )

# define F90_CopyDesc1DI      F90_SYMBOL_COND( F90_COPYDESC1DI )
# define F90_CreateArray1DI   F90_SYMBOL_COND( F90_CREATEARRAY1DI )
# define F90_DestroyArray1DI  F90_SYMBOL_COND( F90_DESTROYARRAY1DI )
# define F90_Dealloc1DI       F90_SYMBOL_COND( F90_DEALLOC1DI )

# define F90_CopyDesc1DI4      F90_SYMBOL_COND( F90_COPYDESC1DI4 )
# define F90_CreateArray1DI4   F90_SYMBOL_COND( F90_CREATEARRAY1DI4 )
# define F90_DestroyArray1DI4  F90_SYMBOL_COND( F90_DESTROYARRAY1DI4 )
# define F90_Dealloc1DI4       F90_SYMBOL_COND( F90_DEALLOC1DI4 )

# define F90_CopyDesc1DI8      F90_SYMBOL_COND( F90_COPYDESC1DI8 )
# define F90_CreateArray1DI8   F90_SYMBOL_COND( F90_CREATEARRAY1DI8 )
# define F90_DestroyArray1DI8  F90_SYMBOL_COND( F90_DESTROYARRAY1DI8 )
# define F90_Dealloc1DI8       F90_SYMBOL_COND( F90_DEALLOC1DI8 )

# define F90_CopyDesc1DL1      F90_SYMBOL_COND( F90_COPYDESC1DL1 )
# define F90_CreateArray1DL1   F90_SYMBOL_COND( F90_CREATEARRAY1DL1 )
# define F90_DestroyArray1DL1  F90_SYMBOL_COND( F90_DESTROYARRAY1DL1 )
# define F90_Dealloc1DL1       F90_SYMBOL_COND( F90_DEALLOC1DL1 )

# define F90_CopyDesc1DL2      F90_SYMBOL_COND( F90_COPYDESC1DL2 )
# define F90_CreateArray1DL2   F90_SYMBOL_COND( F90_CREATEARRAY1DL2 )
# define F90_DestroyArray1DL2  F90_SYMBOL_COND( F90_DESTROYARRAY1DL2 )
# define F90_Dealloc1DL2       F90_SYMBOL_COND( F90_DEALLOC1DL2 )

# define F90_CopyDesc1DL      F90_SYMBOL_COND( F90_COPYDESC1DL )
# define F90_CreateArray1DL   F90_SYMBOL_COND( F90_CREATEARRAY1DL )
# define F90_DestroyArray1DL  F90_SYMBOL_COND( F90_DESTROYARRAY1DL )
# define F90_Dealloc1DL       F90_SYMBOL_COND( F90_DEALLOC1DL )

# define F90_CopyDesc1DL4      F90_SYMBOL_COND( F90_COPYDESC1DL4 )
# define F90_CreateArray1DL4   F90_SYMBOL_COND( F90_CREATEARRAY1DL4 )
# define F90_DestroyArray1DL4  F90_SYMBOL_COND( F90_DESTROYARRAY1DL4 )
# define F90_Dealloc1DL4       F90_SYMBOL_COND( F90_DEALLOC1DL4 )

# define F90_CopyDesc1DL8      F90_SYMBOL_COND( F90_COPYDESC1DL8 )
# define F90_CreateArray1DL8   F90_SYMBOL_COND( F90_CREATEARRAY1DL8 )
# define F90_DestroyArray1DL8  F90_SYMBOL_COND( F90_DESTROYARRAY1DL8 )
# define F90_Dealloc1DL8       F90_SYMBOL_COND( F90_DEALLOC1DL8 )

# define F90_CopyDesc1DR      F90_SYMBOL_COND( F90_COPYDESC1DR )
# define F90_CreateArray1DR   F90_SYMBOL_COND( F90_CREATEARRAY1DR )
# define F90_DestroyArray1DR  F90_SYMBOL_COND( F90_DESTROYARRAY1DR )
# define F90_Dealloc1DR       F90_SYMBOL_COND( F90_DEALLOC1DR )

# define F90_CopyDesc1DD      F90_SYMBOL_COND( F90_COPYDESC1DD )
# define F90_CreateArray1DD   F90_SYMBOL_COND( F90_CREATEARRAY1DD )
# define F90_DestroyArray1DD  F90_SYMBOL_COND( F90_DESTROYARRAY1DD )
# define F90_Dealloc1DD       F90_SYMBOL_COND( F90_DEALLOC1DD )

# define F90_CopyDesc1DC      F90_SYMBOL_COND( F90_COPYDESC1DC )
# define F90_CreateArray1DC   F90_SYMBOL_COND( F90_CREATEARRAY1DC )
# define F90_DestroyArray1DC  F90_SYMBOL_COND( F90_DESTROYARRAY1DC )
# define F90_Dealloc1DC       F90_SYMBOL_COND( F90_DEALLOC1DC )

# define F90_CopyDesc1DDC      F90_SYMBOL_COND( F90_COPYDESC1DDC )
# define F90_CreateArray1DDC   F90_SYMBOL_COND( F90_CREATEARRAY1DDC )
# define F90_DestroyArray1DDC  F90_SYMBOL_COND( F90_DESTROYARRAY1DDC )
# define F90_Dealloc1DDC       F90_SYMBOL_COND( F90_DEALLOC1DDC )

# define F90_CopyDesc2DI1      F90_SYMBOL_COND( F90_COPYDESC2DI1 )
# define F90_CreateArray2DI1   F90_SYMBOL_COND( F90_CREATEARRAY2DI1 )
# define F90_DestroyArray2DI1  F90_SYMBOL_COND( F90_DESTROYARRAY2DI1 )
# define F90_Dealloc2DI1       F90_SYMBOL_COND( F90_DEALLOC2DI1 )

# define F90_CopyDesc2DI2      F90_SYMBOL_COND( F90_COPYDESC2DI2 )
# define F90_CreateArray2DI2   F90_SYMBOL_COND( F90_CREATEARRAY2DI2 )
# define F90_DestroyArray2DI2  F90_SYMBOL_COND( F90_DESTROYARRAY2DI2 )
# define F90_Dealloc2DI2       F90_SYMBOL_COND( F90_DEALLOC2DI2 )

# define F90_CopyDesc2DI      F90_SYMBOL_COND( F90_COPYDESC2DI )
# define F90_CreateArray2DI   F90_SYMBOL_COND( F90_CREATEARRAY2DI )
# define F90_DestroyArray2DI  F90_SYMBOL_COND( F90_DESTROYARRAY2DI )
# define F90_Dealloc2DI       F90_SYMBOL_COND( F90_DEALLOC2DI )

# define F90_CopyDesc2DI4      F90_SYMBOL_COND( F90_COPYDESC2DI4 )
# define F90_CreateArray2DI4   F90_SYMBOL_COND( F90_CREATEARRAY2DI4 )
# define F90_DestroyArray2DI4  F90_SYMBOL_COND( F90_DESTROYARRAY2DI4 )
# define F90_Dealloc2DI4       F90_SYMBOL_COND( F90_DEALLOC2DI4 )

# define F90_CopyDesc2DI8      F90_SYMBOL_COND( F90_COPYDESC2DI8 )
# define F90_CreateArray2DI8   F90_SYMBOL_COND( F90_CREATEARRAY2DI8 )
# define F90_DestroyArray2DI8  F90_SYMBOL_COND( F90_DESTROYARRAY2DI8 )
# define F90_Dealloc2DI8       F90_SYMBOL_COND( F90_DEALLOC2DI8 )

# define F90_CopyDesc2DL1      F90_SYMBOL_COND( F90_COPYDESC2DL1 )
# define F90_CreateArray2DL1   F90_SYMBOL_COND( F90_CREATEARRAY2DL1 )
# define F90_DestroyArray2DL1  F90_SYMBOL_COND( F90_DESTROYARRAY2DL1 )
# define F90_Dealloc2DL1       F90_SYMBOL_COND( F90_DEALLOC2DL1 )

# define F90_CopyDesc2DL2      F90_SYMBOL_COND( F90_COPYDESC2DL2 )
# define F90_CreateArray2DL2   F90_SYMBOL_COND( F90_CREATEARRAY2DL2 )
# define F90_DestroyArray2DL2  F90_SYMBOL_COND( F90_DESTROYARRAY2DL2 )
# define F90_Dealloc2DL2       F90_SYMBOL_COND( F90_DEALLOC2DL2 )

# define F90_CopyDesc2DL      F90_SYMBOL_COND( F90_COPYDESC2DL )
# define F90_CreateArray2DL   F90_SYMBOL_COND( F90_CREATEARRAY2DL )
# define F90_DestroyArray2DL  F90_SYMBOL_COND( F90_DESTROYARRAY2DL )
# define F90_Dealloc2DL       F90_SYMBOL_COND( F90_DEALLOC2DL )

# define F90_CopyDesc2DL4      F90_SYMBOL_COND( F90_COPYDESC2DL4 )
# define F90_CreateArray2DL4   F90_SYMBOL_COND( F90_CREATEARRAY2DL4 )
# define F90_DestroyArray2DL4  F90_SYMBOL_COND( F90_DESTROYARRAY2DL4 )
# define F90_Dealloc2DL4       F90_SYMBOL_COND( F90_DEALLOC2DL4 )

# define F90_CopyDesc2DL8      F90_SYMBOL_COND( F90_COPYDESC2DL8 )
# define F90_CreateArray2DL8   F90_SYMBOL_COND( F90_CREATEARRAY2DL8 )
# define F90_DestroyArray2DL8  F90_SYMBOL_COND( F90_DESTROYARRAY2DL8 )
# define F90_Dealloc2DL8       F90_SYMBOL_COND( F90_DEALLOC2DL8 )

# define F90_CopyDesc2DR      F90_SYMBOL_COND( F90_COPYDESC2DR )
# define F90_CreateArray2DR   F90_SYMBOL_COND( F90_CREATEARRAY2DR )
# define F90_DestroyArray2DR  F90_SYMBOL_COND( F90_DESTROYARRAY2DR )
# define F90_Dealloc2DR       F90_SYMBOL_COND( F90_DEALLOC2DR )

# define F90_CopyDesc2DD      F90_SYMBOL_COND( F90_COPYDESC2DD )
# define F90_CreateArray2DD   F90_SYMBOL_COND( F90_CREATEARRAY2DD )
# define F90_DestroyArray2DD  F90_SYMBOL_COND( F90_DESTROYARRAY2DD )
# define F90_Dealloc2DD       F90_SYMBOL_COND( F90_DEALLOC2DD )

# define F90_CopyDesc2DC      F90_SYMBOL_COND( F90_COPYDESC2DC )
# define F90_CreateArray2DC   F90_SYMBOL_COND( F90_CREATEARRAY2DC )
# define F90_DestroyArray2DC  F90_SYMBOL_COND( F90_DESTROYARRAY2DC )
# define F90_Dealloc2DC       F90_SYMBOL_COND( F90_DEALLOC2DC )

# define F90_CopyDesc2DDC      F90_SYMBOL_COND( F90_COPYDESC2DDC )
# define F90_CreateArray2DDC   F90_SYMBOL_COND( F90_CREATEARRAY2DDC )
# define F90_DestroyArray2DDC  F90_SYMBOL_COND( F90_DESTROYARRAY2DDC )
# define F90_Dealloc2DDC       F90_SYMBOL_COND( F90_DEALLOC2DDC )

# define F90_CopyDesc3DI1      F90_SYMBOL_COND( F90_COPYDESC3DI1 )
# define F90_CreateArray3DI1   F90_SYMBOL_COND( F90_CREATEARRAY3DI1 )
# define F90_DestroyArray3DI1  F90_SYMBOL_COND( F90_DESTROYARRAY3DI1 )
# define F90_Dealloc3DI1       F90_SYMBOL_COND( F90_DEALLOC3DI1 )

# define F90_CopyDesc3DI2      F90_SYMBOL_COND( F90_COPYDESC3DI2 )
# define F90_CreateArray3DI2   F90_SYMBOL_COND( F90_CREATEARRAY3DI2 )
# define F90_DestroyArray3DI2  F90_SYMBOL_COND( F90_DESTROYARRAY3DI2 )
# define F90_Dealloc3DI2       F90_SYMBOL_COND( F90_DEALLOC3DI2 )

# define F90_CopyDesc3DI      F90_SYMBOL_COND( F90_COPYDESC3DI )
# define F90_CreateArray3DI   F90_SYMBOL_COND( F90_CREATEARRAY3DI )
# define F90_DestroyArray3DI  F90_SYMBOL_COND( F90_DESTROYARRAY3DI )
# define F90_Dealloc3DI       F90_SYMBOL_COND( F90_DEALLOC3DI )

# define F90_CopyDesc3DI4      F90_SYMBOL_COND( F90_COPYDESC3DI4 )
# define F90_CreateArray3DI4   F90_SYMBOL_COND( F90_CREATEARRAY3DI4 )
# define F90_DestroyArray3DI4  F90_SYMBOL_COND( F90_DESTROYARRAY3DI4 )
# define F90_Dealloc3DI4       F90_SYMBOL_COND( F90_DEALLOC3DI4 )

# define F90_CopyDesc3DI8      F90_SYMBOL_COND( F90_COPYDESC3DI8 )
# define F90_CreateArray3DI8   F90_SYMBOL_COND( F90_CREATEARRAY3DI8 )
# define F90_DestroyArray3DI8  F90_SYMBOL_COND( F90_DESTROYARRAY3DI8 )
# define F90_Dealloc3DI8       F90_SYMBOL_COND( F90_DEALLOC3DI8 )

# define F90_CopyDesc3DL1      F90_SYMBOL_COND( F90_COPYDESC3DL1 )
# define F90_CreateArray3DL1   F90_SYMBOL_COND( F90_CREATEARRAY3DL1 )
# define F90_DestroyArray3DL1  F90_SYMBOL_COND( F90_DESTROYARRAY3DL1 )
# define F90_Dealloc3DL1       F90_SYMBOL_COND( F90_DEALLOC3DL1 )

# define F90_CopyDesc3DL2      F90_SYMBOL_COND( F90_COPYDESC3DL2 )
# define F90_CreateArray3DL2   F90_SYMBOL_COND( F90_CREATEARRAY3DL2 )
# define F90_DestroyArray3DL2  F90_SYMBOL_COND( F90_DESTROYARRAY3DL2 )
# define F90_Dealloc3DL2       F90_SYMBOL_COND( F90_DEALLOC3DL2 )

# define F90_CopyDesc3DL      F90_SYMBOL_COND( F90_COPYDESC3DL )
# define F90_CreateArray3DL   F90_SYMBOL_COND( F90_CREATEARRAY3DL )
# define F90_DestroyArray3DL  F90_SYMBOL_COND( F90_DESTROYARRAY3DL )
# define F90_Dealloc3DL       F90_SYMBOL_COND( F90_DEALLOC3DL )

# define F90_CopyDesc3DL4      F90_SYMBOL_COND( F90_COPYDESC3DL4 )
# define F90_CreateArray3DL4   F90_SYMBOL_COND( F90_CREATEARRAY3DL4 )
# define F90_DestroyArray3DL4  F90_SYMBOL_COND( F90_DESTROYARRAY3DL4 )
# define F90_Dealloc3DL4       F90_SYMBOL_COND( F90_DEALLOC3DL4 )

# define F90_CopyDesc3DL8      F90_SYMBOL_COND( F90_COPYDESC3DL8 )
# define F90_CreateArray3DL8   F90_SYMBOL_COND( F90_CREATEARRAY3DL8 )
# define F90_DestroyArray3DL8  F90_SYMBOL_COND( F90_DESTROYARRAY3DL8 )
# define F90_Dealloc3DL8       F90_SYMBOL_COND( F90_DEALLOC3DL8 )

# define F90_CopyDesc3DR      F90_SYMBOL_COND( F90_COPYDESC3DR )
# define F90_CreateArray3DR   F90_SYMBOL_COND( F90_CREATEARRAY3DR )
# define F90_DestroyArray3DR  F90_SYMBOL_COND( F90_DESTROYARRAY3DR )
# define F90_Dealloc3DR       F90_SYMBOL_COND( F90_DEALLOC3DR )

# define F90_CopyDesc3DD      F90_SYMBOL_COND( F90_COPYDESC3DD )
# define F90_CreateArray3DD   F90_SYMBOL_COND( F90_CREATEARRAY3DD )
# define F90_DestroyArray3DD  F90_SYMBOL_COND( F90_DESTROYARRAY3DD )
# define F90_Dealloc3DD       F90_SYMBOL_COND( F90_DEALLOC3DD )

# define F90_CopyDesc3DC      F90_SYMBOL_COND( F90_COPYDESC3DC )
# define F90_CreateArray3DC   F90_SYMBOL_COND( F90_CREATEARRAY3DC )
# define F90_DestroyArray3DC  F90_SYMBOL_COND( F90_DESTROYARRAY3DC )
# define F90_Dealloc3DC       F90_SYMBOL_COND( F90_DEALLOC3DC )

# define F90_CopyDesc3DDC      F90_SYMBOL_COND( F90_COPYDESC3DDC )
# define F90_CreateArray3DDC   F90_SYMBOL_COND( F90_CREATEARRAY3DDC )
# define F90_DestroyArray3DDC  F90_SYMBOL_COND( F90_DESTROYARRAY3DDC )
# define F90_Dealloc3DDC       F90_SYMBOL_COND( F90_DEALLOC3DDC )

# define F90_CopyDesc4DI1      F90_SYMBOL_COND( F90_COPYDESC4DI1 )
# define F90_CreateArray4DI1   F90_SYMBOL_COND( F90_CREATEARRAY4DI1 )
# define F90_DestroyArray4DI1  F90_SYMBOL_COND( F90_DESTROYARRAY4DI1 )
# define F90_Dealloc4DI1       F90_SYMBOL_COND( F90_DEALLOC4DI1 )

# define F90_CopyDesc4DI2      F90_SYMBOL_COND( F90_COPYDESC4DI2 )
# define F90_CreateArray4DI2   F90_SYMBOL_COND( F90_CREATEARRAY4DI2 )
# define F90_DestroyArray4DI2  F90_SYMBOL_COND( F90_DESTROYARRAY4DI2 )
# define F90_Dealloc4DI2       F90_SYMBOL_COND( F90_DEALLOC4DI2 )

# define F90_CopyDesc4DI      F90_SYMBOL_COND( F90_COPYDESC4DI )
# define F90_CreateArray4DI   F90_SYMBOL_COND( F90_CREATEARRAY4DI )
# define F90_DestroyArray4DI  F90_SYMBOL_COND( F90_DESTROYARRAY4DI )
# define F90_Dealloc4DI       F90_SYMBOL_COND( F90_DEALLOC4DI )

# define F90_CopyDesc4DI4      F90_SYMBOL_COND( F90_COPYDESC4DI4 )
# define F90_CreateArray4DI4   F90_SYMBOL_COND( F90_CREATEARRAY4DI4 )
# define F90_DestroyArray4DI4  F90_SYMBOL_COND( F90_DESTROYARRAY4DI4 )
# define F90_Dealloc4DI4       F90_SYMBOL_COND( F90_DEALLOC4DI4 )

# define F90_CopyDesc4DI8      F90_SYMBOL_COND( F90_COPYDESC4DI8 )
# define F90_CreateArray4DI8   F90_SYMBOL_COND( F90_CREATEARRAY4DI8 )
# define F90_DestroyArray4DI8  F90_SYMBOL_COND( F90_DESTROYARRAY4DI8 )
# define F90_Dealloc4DI8       F90_SYMBOL_COND( F90_DEALLOC4DI8 )

# define F90_CopyDesc4DL1      F90_SYMBOL_COND( F90_COPYDESC4DL1 )
# define F90_CreateArray4DL1   F90_SYMBOL_COND( F90_CREATEARRAY4DL1 )
# define F90_DestroyArray4DL1  F90_SYMBOL_COND( F90_DESTROYARRAY4DL1 )
# define F90_Dealloc4DL1       F90_SYMBOL_COND( F90_DEALLOC4DL1 )

# define F90_CopyDesc4DL2      F90_SYMBOL_COND( F90_COPYDESC4DL2 )
# define F90_CreateArray4DL2   F90_SYMBOL_COND( F90_CREATEARRAY4DL2 )
# define F90_DestroyArray4DL2  F90_SYMBOL_COND( F90_DESTROYARRAY4DL2 )
# define F90_Dealloc4DL2       F90_SYMBOL_COND( F90_DEALLOC4DL2 )

# define F90_CopyDesc4DL      F90_SYMBOL_COND( F90_COPYDESC4DL )
# define F90_CreateArray4DL   F90_SYMBOL_COND( F90_CREATEARRAY4DL )
# define F90_DestroyArray4DL  F90_SYMBOL_COND( F90_DESTROYARRAY4DL )
# define F90_Dealloc4DL       F90_SYMBOL_COND( F90_DEALLOC4DL )

# define F90_CopyDesc4DL4      F90_SYMBOL_COND( F90_COPYDESC4DL4 )
# define F90_CreateArray4DL4   F90_SYMBOL_COND( F90_CREATEARRAY4DL4 )
# define F90_DestroyArray4DL4  F90_SYMBOL_COND( F90_DESTROYARRAY4DL4 )
# define F90_Dealloc4DL4       F90_SYMBOL_COND( F90_DEALLOC4DL4 )

# define F90_CopyDesc4DL8      F90_SYMBOL_COND( F90_COPYDESC4DL8 )
# define F90_CreateArray4DL8   F90_SYMBOL_COND( F90_CREATEARRAY4DL8 )
# define F90_DestroyArray4DL8  F90_SYMBOL_COND( F90_DESTROYARRAY4DL8 )
# define F90_Dealloc4DL8       F90_SYMBOL_COND( F90_DEALLOC4DL8 )

# define F90_CopyDesc4DR      F90_SYMBOL_COND( F90_COPYDESC4DR )
# define F90_CreateArray4DR   F90_SYMBOL_COND( F90_CREATEARRAY4DR )
# define F90_DestroyArray4DR  F90_SYMBOL_COND( F90_DESTROYARRAY4DR )
# define F90_Dealloc4DR       F90_SYMBOL_COND( F90_DEALLOC4DR )

# define F90_CopyDesc4DD      F90_SYMBOL_COND( F90_COPYDESC4DD )
# define F90_CreateArray4DD   F90_SYMBOL_COND( F90_CREATEARRAY4DD )
# define F90_DestroyArray4DD  F90_SYMBOL_COND( F90_DESTROYARRAY4DD )
# define F90_Dealloc4DD       F90_SYMBOL_COND( F90_DEALLOC4DD )

# define F90_CopyDesc4DC      F90_SYMBOL_COND( F90_COPYDESC4DC )
# define F90_CreateArray4DC   F90_SYMBOL_COND( F90_CREATEARRAY4DC )
# define F90_DestroyArray4DC  F90_SYMBOL_COND( F90_DESTROYARRAY4DC )
# define F90_Dealloc4DC       F90_SYMBOL_COND( F90_DEALLOC4DC )

# define F90_CopyDesc4DDC      F90_SYMBOL_COND( F90_COPYDESC4DDC )
# define F90_CreateArray4DDC   F90_SYMBOL_COND( F90_CREATEARRAY4DDC )
# define F90_DestroyArray4DDC  F90_SYMBOL_COND( F90_DESTROYARRAY4DDC )
# define F90_Dealloc4DDC       F90_SYMBOL_COND( F90_DEALLOC4DDC )

# define F90_CopyDesc5DI1      F90_SYMBOL_COND( F90_COPYDESC5DI1 )
# define F90_CreateArray5DI1   F90_SYMBOL_COND( F90_CREATEARRAY5DI1 )
# define F90_DestroyArray5DI1  F90_SYMBOL_COND( F90_DESTROYARRAY5DI1 )
# define F90_Dealloc5DI1       F90_SYMBOL_COND( F90_DEALLOC5DI1 )

# define F90_CopyDesc5DI2      F90_SYMBOL_COND( F90_COPYDESC5DI2 )
# define F90_CreateArray5DI2   F90_SYMBOL_COND( F90_CREATEARRAY5DI2 )
# define F90_DestroyArray5DI2  F90_SYMBOL_COND( F90_DESTROYARRAY5DI2 )
# define F90_Dealloc5DI2       F90_SYMBOL_COND( F90_DEALLOC5DI2 )

# define F90_CopyDesc5DI      F90_SYMBOL_COND( F90_COPYDESC5DI )
# define F90_CreateArray5DI   F90_SYMBOL_COND( F90_CREATEARRAY5DI )
# define F90_DestroyArray5DI  F90_SYMBOL_COND( F90_DESTROYARRAY5DI )
# define F90_Dealloc5DI       F90_SYMBOL_COND( F90_DEALLOC5DI )

# define F90_CopyDesc5DI4      F90_SYMBOL_COND( F90_COPYDESC5DI4 )
# define F90_CreateArray5DI4   F90_SYMBOL_COND( F90_CREATEARRAY5DI4 )
# define F90_DestroyArray5DI4  F90_SYMBOL_COND( F90_DESTROYARRAY5DI4 )
# define F90_Dealloc5DI4       F90_SYMBOL_COND( F90_DEALLOC5DI4 )

# define F90_CopyDesc5DI8      F90_SYMBOL_COND( F90_COPYDESC5DI8 )
# define F90_CreateArray5DI8   F90_SYMBOL_COND( F90_CREATEARRAY5DI8 )
# define F90_DestroyArray5DI8  F90_SYMBOL_COND( F90_DESTROYARRAY5DI8 )
# define F90_Dealloc5DI8       F90_SYMBOL_COND( F90_DEALLOC5DI8 )

# define F90_CopyDesc5DL1      F90_SYMBOL_COND( F90_COPYDESC5DL1 )
# define F90_CreateArray5DL1   F90_SYMBOL_COND( F90_CREATEARRAY5DL1 )
# define F90_DestroyArray5DL1  F90_SYMBOL_COND( F90_DESTROYARRAY5DL1 )
# define F90_Dealloc5DL1       F90_SYMBOL_COND( F90_DEALLOC5DL1 )

# define F90_CopyDesc5DL2      F90_SYMBOL_COND( F90_COPYDESC5DL2 )
# define F90_CreateArray5DL2   F90_SYMBOL_COND( F90_CREATEARRAY5DL2 )
# define F90_DestroyArray5DL2  F90_SYMBOL_COND( F90_DESTROYARRAY5DL2 )
# define F90_Dealloc5DL2       F90_SYMBOL_COND( F90_DEALLOC5DL2 )

# define F90_CopyDesc5DL      F90_SYMBOL_COND( F90_COPYDESC5DL )
# define F90_CreateArray5DL   F90_SYMBOL_COND( F90_CREATEARRAY5DL )
# define F90_DestroyArray5DL  F90_SYMBOL_COND( F90_DESTROYARRAY5DL )
# define F90_Dealloc5DL       F90_SYMBOL_COND( F90_DEALLOC5DL )

# define F90_CopyDesc5DL4      F90_SYMBOL_COND( F90_COPYDESC5DL4 )
# define F90_CreateArray5DL4   F90_SYMBOL_COND( F90_CREATEARRAY5DL4 )
# define F90_DestroyArray5DL4  F90_SYMBOL_COND( F90_DESTROYARRAY5DL4 )
# define F90_Dealloc5DL4       F90_SYMBOL_COND( F90_DEALLOC5DL4 )

# define F90_CopyDesc5DL8      F90_SYMBOL_COND( F90_COPYDESC5DL8 )
# define F90_CreateArray5DL8   F90_SYMBOL_COND( F90_CREATEARRAY5DL8 )
# define F90_DestroyArray5DL8  F90_SYMBOL_COND( F90_DESTROYARRAY5DL8 )
# define F90_Dealloc5DL8       F90_SYMBOL_COND( F90_DEALLOC5DL8 )

# define F90_CopyDesc5DR      F90_SYMBOL_COND( F90_COPYDESC5DR )
# define F90_CreateArray5DR   F90_SYMBOL_COND( F90_CREATEARRAY5DR )
# define F90_DestroyArray5DR  F90_SYMBOL_COND( F90_DESTROYARRAY5DR )
# define F90_Dealloc5DR       F90_SYMBOL_COND( F90_DEALLOC5DR )

# define F90_CopyDesc5DD      F90_SYMBOL_COND( F90_COPYDESC5DD )
# define F90_CreateArray5DD   F90_SYMBOL_COND( F90_CREATEARRAY5DD )
# define F90_DestroyArray5DD  F90_SYMBOL_COND( F90_DESTROYARRAY5DD )
# define F90_Dealloc5DD       F90_SYMBOL_COND( F90_DEALLOC5DD )

# define F90_CopyDesc5DC      F90_SYMBOL_COND( F90_COPYDESC5DC )
# define F90_CreateArray5DC   F90_SYMBOL_COND( F90_CREATEARRAY5DC )
# define F90_DestroyArray5DC  F90_SYMBOL_COND( F90_DESTROYARRAY5DC )
# define F90_Dealloc5DC       F90_SYMBOL_COND( F90_DEALLOC5DC )

# define F90_CopyDesc5DDC      F90_SYMBOL_COND( F90_COPYDESC5DDC )
# define F90_CreateArray5DDC   F90_SYMBOL_COND( F90_CREATEARRAY5DDC )
# define F90_DestroyArray5DDC  F90_SYMBOL_COND( F90_DESTROYARRAY5DDC )
# define F90_Dealloc5DDC       F90_SYMBOL_COND( F90_DEALLOC5DDC )

# define F90_CopyDesc6DI1      F90_SYMBOL_COND( F90_COPYDESC6DI1 )
# define F90_CreateArray6DI1   F90_SYMBOL_COND( F90_CREATEARRAY6DI1 )
# define F90_DestroyArray6DI1  F90_SYMBOL_COND( F90_DESTROYARRAY6DI1 )
# define F90_Dealloc6DI1       F90_SYMBOL_COND( F90_DEALLOC6DI1 )

# define F90_CopyDesc6DI2      F90_SYMBOL_COND( F90_COPYDESC6DI2 )
# define F90_CreateArray6DI2   F90_SYMBOL_COND( F90_CREATEARRAY6DI2 )
# define F90_DestroyArray6DI2  F90_SYMBOL_COND( F90_DESTROYARRAY6DI2 )
# define F90_Dealloc6DI2       F90_SYMBOL_COND( F90_DEALLOC6DI2 )

# define F90_CopyDesc6DI      F90_SYMBOL_COND( F90_COPYDESC6DI )
# define F90_CreateArray6DI   F90_SYMBOL_COND( F90_CREATEARRAY6DI )
# define F90_DestroyArray6DI  F90_SYMBOL_COND( F90_DESTROYARRAY6DI )
# define F90_Dealloc6DI       F90_SYMBOL_COND( F90_DEALLOC6DI )

# define F90_CopyDesc6DI4      F90_SYMBOL_COND( F90_COPYDESC6DI4 )
# define F90_CreateArray6DI4   F90_SYMBOL_COND( F90_CREATEARRAY6DI4 )
# define F90_DestroyArray6DI4  F90_SYMBOL_COND( F90_DESTROYARRAY6DI4 )
# define F90_Dealloc6DI4       F90_SYMBOL_COND( F90_DEALLOC6DI4 )

# define F90_CopyDesc6DI8      F90_SYMBOL_COND( F90_COPYDESC6DI8 )
# define F90_CreateArray6DI8   F90_SYMBOL_COND( F90_CREATEARRAY6DI8 )
# define F90_DestroyArray6DI8  F90_SYMBOL_COND( F90_DESTROYARRAY6DI8 )
# define F90_Dealloc6DI8       F90_SYMBOL_COND( F90_DEALLOC6DI8 )

# define F90_CopyDesc6DL1      F90_SYMBOL_COND( F90_COPYDESC6DL1 )
# define F90_CreateArray6DL1   F90_SYMBOL_COND( F90_CREATEARRAY6DL1 )
# define F90_DestroyArray6DL1  F90_SYMBOL_COND( F90_DESTROYARRAY6DL1 )
# define F90_Dealloc6DL1       F90_SYMBOL_COND( F90_DEALLOC6DL1 )

# define F90_CopyDesc6DL2      F90_SYMBOL_COND( F90_COPYDESC6DL2 )
# define F90_CreateArray6DL2   F90_SYMBOL_COND( F90_CREATEARRAY6DL2 )
# define F90_DestroyArray6DL2  F90_SYMBOL_COND( F90_DESTROYARRAY6DL2 )
# define F90_Dealloc6DL2       F90_SYMBOL_COND( F90_DEALLOC6DL2 )

# define F90_CopyDesc6DL      F90_SYMBOL_COND( F90_COPYDESC6DL )
# define F90_CreateArray6DL   F90_SYMBOL_COND( F90_CREATEARRAY6DL )
# define F90_DestroyArray6DL  F90_SYMBOL_COND( F90_DESTROYARRAY6DL )
# define F90_Dealloc6DL       F90_SYMBOL_COND( F90_DEALLOC6DL )

# define F90_CopyDesc6DL4      F90_SYMBOL_COND( F90_COPYDESC6DL4 )
# define F90_CreateArray6DL4   F90_SYMBOL_COND( F90_CREATEARRAY6DL4 )
# define F90_DestroyArray6DL4  F90_SYMBOL_COND( F90_DESTROYARRAY6DL4 )
# define F90_Dealloc6DL4       F90_SYMBOL_COND( F90_DEALLOC6DL4 )

# define F90_CopyDesc6DL8      F90_SYMBOL_COND( F90_COPYDESC6DL8 )
# define F90_CreateArray6DL8   F90_SYMBOL_COND( F90_CREATEARRAY6DL8 )
# define F90_DestroyArray6DL8  F90_SYMBOL_COND( F90_DESTROYARRAY6DL8 )
# define F90_Dealloc6DL8       F90_SYMBOL_COND( F90_DEALLOC6DL8 )

# define F90_CopyDesc6DR      F90_SYMBOL_COND( F90_COPYDESC6DR )
# define F90_CreateArray6DR   F90_SYMBOL_COND( F90_CREATEARRAY6DR )
# define F90_DestroyArray6DR  F90_SYMBOL_COND( F90_DESTROYARRAY6DR )
# define F90_Dealloc6DR       F90_SYMBOL_COND( F90_DEALLOC6DR )

# define F90_CopyDesc6DD      F90_SYMBOL_COND( F90_COPYDESC6DD )
# define F90_CreateArray6DD   F90_SYMBOL_COND( F90_CREATEARRAY6DD )
# define F90_DestroyArray6DD  F90_SYMBOL_COND( F90_DESTROYARRAY6DD )
# define F90_Dealloc6DD       F90_SYMBOL_COND( F90_DEALLOC6DD )

# define F90_CopyDesc6DC      F90_SYMBOL_COND( F90_COPYDESC6DC )
# define F90_CreateArray6DC   F90_SYMBOL_COND( F90_CREATEARRAY6DC )
# define F90_DestroyArray6DC  F90_SYMBOL_COND( F90_DESTROYARRAY6DC )
# define F90_Dealloc6DC       F90_SYMBOL_COND( F90_DEALLOC6DC )

# define F90_CopyDesc6DDC      F90_SYMBOL_COND( F90_COPYDESC6DDC )
# define F90_CreateArray6DDC   F90_SYMBOL_COND( F90_CREATEARRAY6DDC )
# define F90_DestroyArray6DDC  F90_SYMBOL_COND( F90_DESTROYARRAY6DDC )
# define F90_Dealloc6DDC       F90_SYMBOL_COND( F90_DEALLOC6DDC )

# define F90_CopyDesc7DI1      F90_SYMBOL_COND( F90_COPYDESC7DI1 )
# define F90_CreateArray7DI1   F90_SYMBOL_COND( F90_CREATEARRAY7DI1 )
# define F90_DestroyArray7DI1  F90_SYMBOL_COND( F90_DESTROYARRAY7DI1 )
# define F90_Dealloc7DI1       F90_SYMBOL_COND( F90_DEALLOC7DI1 )

# define F90_CopyDesc7DI2      F90_SYMBOL_COND( F90_COPYDESC7DI2 )
# define F90_CreateArray7DI2   F90_SYMBOL_COND( F90_CREATEARRAY7DI2 )
# define F90_DestroyArray7DI2  F90_SYMBOL_COND( F90_DESTROYARRAY7DI2 )
# define F90_Dealloc7DI2       F90_SYMBOL_COND( F90_DEALLOC7DI2 )

# define F90_CopyDesc7DI      F90_SYMBOL_COND( F90_COPYDESC7DI )
# define F90_CreateArray7DI   F90_SYMBOL_COND( F90_CREATEARRAY7DI )
# define F90_DestroyArray7DI  F90_SYMBOL_COND( F90_DESTROYARRAY7DI )
# define F90_Dealloc7DI       F90_SYMBOL_COND( F90_DEALLOC7DI )

# define F90_CopyDesc7DI4      F90_SYMBOL_COND( F90_COPYDESC7DI4 )
# define F90_CreateArray7DI4   F90_SYMBOL_COND( F90_CREATEARRAY7DI4 )
# define F90_DestroyArray7DI4  F90_SYMBOL_COND( F90_DESTROYARRAY7DI4 )
# define F90_Dealloc7DI4       F90_SYMBOL_COND( F90_DEALLOC7DI4 )

# define F90_CopyDesc7DI8      F90_SYMBOL_COND( F90_COPYDESC7DI8 )
# define F90_CreateArray7DI8   F90_SYMBOL_COND( F90_CREATEARRAY7DI8 )
# define F90_DestroyArray7DI8  F90_SYMBOL_COND( F90_DESTROYARRAY7DI8 )
# define F90_Dealloc7DI8       F90_SYMBOL_COND( F90_DEALLOC7DI8 )

# define F90_CopyDesc7DL1      F90_SYMBOL_COND( F90_COPYDESC7DL1 )
# define F90_CreateArray7DL1   F90_SYMBOL_COND( F90_CREATEARRAY7DL1 )
# define F90_DestroyArray7DL1  F90_SYMBOL_COND( F90_DESTROYARRAY7DL1 )
# define F90_Dealloc7DL1       F90_SYMBOL_COND( F90_DEALLOC7DL1 )

# define F90_CopyDesc7DL2      F90_SYMBOL_COND( F90_COPYDESC7DL2 )
# define F90_CreateArray7DL2   F90_SYMBOL_COND( F90_CREATEARRAY7DL2 )
# define F90_DestroyArray7DL2  F90_SYMBOL_COND( F90_DESTROYARRAY7DL2 )
# define F90_Dealloc7DL2       F90_SYMBOL_COND( F90_DEALLOC7DL2 )

# define F90_CopyDesc7DL      F90_SYMBOL_COND( F90_COPYDESC7DL )
# define F90_CreateArray7DL   F90_SYMBOL_COND( F90_CREATEARRAY7DL )
# define F90_DestroyArray7DL  F90_SYMBOL_COND( F90_DESTROYARRAY7DL )
# define F90_Dealloc7DL       F90_SYMBOL_COND( F90_DEALLOC7DL )

# define F90_CopyDesc7DL4      F90_SYMBOL_COND( F90_COPYDESC7DL4 )
# define F90_CreateArray7DL4   F90_SYMBOL_COND( F90_CREATEARRAY7DL4 )
# define F90_DestroyArray7DL4  F90_SYMBOL_COND( F90_DESTROYARRAY7DL4 )
# define F90_Dealloc7DL4       F90_SYMBOL_COND( F90_DEALLOC7DL4 )

# define F90_CopyDesc7DL8      F90_SYMBOL_COND( F90_COPYDESC7DL8 )
# define F90_CreateArray7DL8   F90_SYMBOL_COND( F90_CREATEARRAY7DL8 )
# define F90_DestroyArray7DL8  F90_SYMBOL_COND( F90_DESTROYARRAY7DL8 )
# define F90_Dealloc7DL8       F90_SYMBOL_COND( F90_DEALLOC7DL8 )

# define F90_CopyDesc7DR      F90_SYMBOL_COND( F90_COPYDESC7DR )
# define F90_CreateArray7DR   F90_SYMBOL_COND( F90_CREATEARRAY7DR )
# define F90_DestroyArray7DR  F90_SYMBOL_COND( F90_DESTROYARRAY7DR )
# define F90_Dealloc7DR       F90_SYMBOL_COND( F90_DEALLOC7DR )

# define F90_CopyDesc7DD      F90_SYMBOL_COND( F90_COPYDESC7DD )
# define F90_CreateArray7DD   F90_SYMBOL_COND( F90_CREATEARRAY7DD )
# define F90_DestroyArray7DD  F90_SYMBOL_COND( F90_DESTROYARRAY7DD )
# define F90_Dealloc7DD       F90_SYMBOL_COND( F90_DEALLOC7DD )

# define F90_CopyDesc7DC      F90_SYMBOL_COND( F90_COPYDESC7DC )
# define F90_CreateArray7DC   F90_SYMBOL_COND( F90_CREATEARRAY7DC )
# define F90_DestroyArray7DC  F90_SYMBOL_COND( F90_DESTROYARRAY7DC )
# define F90_Dealloc7DC       F90_SYMBOL_COND( F90_DEALLOC7DC )

# define F90_CopyDesc7DDC      F90_SYMBOL_COND( F90_COPYDESC7DDC )
# define F90_CreateArray7DDC   F90_SYMBOL_COND( F90_CREATEARRAY7DDC )
# define F90_DestroyArray7DDC  F90_SYMBOL_COND( F90_DESTROYARRAY7DDC )
# define F90_Dealloc7DDC       F90_SYMBOL_COND( F90_DEALLOC7DDC )

#endif /* F90_SYM_CASE_UPPER */


void F90_CreateArray1DI1 (void*, long*, long*);
void F90_DestroyArray1DI1(void*);

void F90_CreateArray1DI2 (void*, long*, long*);
void F90_DestroyArray1DI2(void*);

void F90_CreateArray1DI (void*, long*, long*);
void F90_DestroyArray1DI(void*);

void F90_CreateArray1DI4 (void*, long*, long*);
void F90_DestroyArray1DI4(void*);

void F90_CreateArray1DI8 (void*, long*, long*);
void F90_DestroyArray1DI8(void*);

void F90_CreateArray1DL1 (void*, long*, long*);
void F90_DestroyArray1DL1(void*);

void F90_CreateArray1DL2 (void*, long*, long*);
void F90_DestroyArray1DL2(void*);

void F90_CreateArray1DL (void*, long*, long*);
void F90_DestroyArray1DL(void*);

void F90_CreateArray1DL4 (void*, long*, long*);
void F90_DestroyArray1DL4(void*);

void F90_CreateArray1DL8 (void*, long*, long*);
void F90_DestroyArray1DL8(void*);

void F90_CreateArray1DR (void*, long*, long*);
void F90_DestroyArray1DR(void*);

void F90_CreateArray1DD (void*, long*, long*);
void F90_DestroyArray1DD(void*);

void F90_CreateArray1DC (void*, long*, long*);
void F90_DestroyArray1DC(void*);

void F90_CreateArray1DDC (void*, long*, long*);
void F90_DestroyArray1DDC(void*);

void F90_CreateArray2DI1 (void*, long*, long*);
void F90_DestroyArray2DI1(void*);

void F90_CreateArray2DI2 (void*, long*, long*);
void F90_DestroyArray2DI2(void*);

void F90_CreateArray2DI (void*, long*, long*);
void F90_DestroyArray2DI(void*);

void F90_CreateArray2DI4 (void*, long*, long*);
void F90_DestroyArray2DI4(void*);

void F90_CreateArray2DI8 (void*, long*, long*);
void F90_DestroyArray2DI8(void*);

void F90_CreateArray2DL1 (void*, long*, long*);
void F90_DestroyArray2DL1(void*);

void F90_CreateArray2DL2 (void*, long*, long*);
void F90_DestroyArray2DL2(void*);

void F90_CreateArray2DL (void*, long*, long*);
void F90_DestroyArray2DL(void*);

void F90_CreateArray2DL4 (void*, long*, long*);
void F90_DestroyArray2DL4(void*);

void F90_CreateArray2DL8 (void*, long*, long*);
void F90_DestroyArray2DL8(void*);

void F90_CreateArray2DR (void*, long*, long*);
void F90_DestroyArray2DR(void*);

void F90_CreateArray2DD (void*, long*, long*);
void F90_DestroyArray2DD(void*);

void F90_CreateArray2DC (void*, long*, long*);
void F90_DestroyArray2DC(void*);

void F90_CreateArray2DDC (void*, long*, long*);
void F90_DestroyArray2DDC(void*);

void F90_CreateArray3DI1 (void*, long*, long*);
void F90_DestroyArray3DI1(void*);

void F90_CreateArray3DI2 (void*, long*, long*);
void F90_DestroyArray3DI2(void*);

void F90_CreateArray3DI (void*, long*, long*);
void F90_DestroyArray3DI(void*);

void F90_CreateArray3DI4 (void*, long*, long*);
void F90_DestroyArray3DI4(void*);

void F90_CreateArray3DI8 (void*, long*, long*);
void F90_DestroyArray3DI8(void*);

void F90_CreateArray3DL1 (void*, long*, long*);
void F90_DestroyArray3DL1(void*);

void F90_CreateArray3DL2 (void*, long*, long*);
void F90_DestroyArray3DL2(void*);

void F90_CreateArray3DL (void*, long*, long*);
void F90_DestroyArray3DL(void*);

void F90_CreateArray3DL4 (void*, long*, long*);
void F90_DestroyArray3DL4(void*);

void F90_CreateArray3DL8 (void*, long*, long*);
void F90_DestroyArray3DL8(void*);

void F90_CreateArray3DR (void*, long*, long*);
void F90_DestroyArray3DR(void*);

void F90_CreateArray3DD (void*, long*, long*);
void F90_DestroyArray3DD(void*);

void F90_CreateArray3DC (void*, long*, long*);
void F90_DestroyArray3DC(void*);

void F90_CreateArray3DDC (void*, long*, long*);
void F90_DestroyArray3DDC(void*);

void F90_CreateArray4DI1 (void*, long*, long*);
void F90_DestroyArray4DI1(void*);

void F90_CreateArray4DI2 (void*, long*, long*);
void F90_DestroyArray4DI2(void*);

void F90_CreateArray4DI (void*, long*, long*);
void F90_DestroyArray4DI(void*);

void F90_CreateArray4DI4 (void*, long*, long*);
void F90_DestroyArray4DI4(void*);

void F90_CreateArray4DI8 (void*, long*, long*);
void F90_DestroyArray4DI8(void*);

void F90_CreateArray4DL1 (void*, long*, long*);
void F90_DestroyArray4DL1(void*);

void F90_CreateArray4DL2 (void*, long*, long*);
void F90_DestroyArray4DL2(void*);

void F90_CreateArray4DL (void*, long*, long*);
void F90_DestroyArray4DL(void*);

void F90_CreateArray4DL4 (void*, long*, long*);
void F90_DestroyArray4DL4(void*);

void F90_CreateArray4DL8 (void*, long*, long*);
void F90_DestroyArray4DL8(void*);

void F90_CreateArray4DR (void*, long*, long*);
void F90_DestroyArray4DR(void*);

void F90_CreateArray4DD (void*, long*, long*);
void F90_DestroyArray4DD(void*);

void F90_CreateArray4DC (void*, long*, long*);
void F90_DestroyArray4DC(void*);

void F90_CreateArray4DDC (void*, long*, long*);
void F90_DestroyArray4DDC(void*);

void F90_CreateArray5DI1 (void*, long*, long*);
void F90_DestroyArray5DI1(void*);

void F90_CreateArray5DI2 (void*, long*, long*);
void F90_DestroyArray5DI2(void*);

void F90_CreateArray5DI (void*, long*, long*);
void F90_DestroyArray5DI(void*);

void F90_CreateArray5DI4 (void*, long*, long*);
void F90_DestroyArray5DI4(void*);

void F90_CreateArray5DI8 (void*, long*, long*);
void F90_DestroyArray5DI8(void*);

void F90_CreateArray5DL1 (void*, long*, long*);
void F90_DestroyArray5DL1(void*);

void F90_CreateArray5DL2 (void*, long*, long*);
void F90_DestroyArray5DL2(void*);

void F90_CreateArray5DL (void*, long*, long*);
void F90_DestroyArray5DL(void*);

void F90_CreateArray5DL4 (void*, long*, long*);
void F90_DestroyArray5DL4(void*);

void F90_CreateArray5DL8 (void*, long*, long*);
void F90_DestroyArray5DL8(void*);

void F90_CreateArray5DR (void*, long*, long*);
void F90_DestroyArray5DR(void*);

void F90_CreateArray5DD (void*, long*, long*);
void F90_DestroyArray5DD(void*);

void F90_CreateArray5DC (void*, long*, long*);
void F90_DestroyArray5DC(void*);

void F90_CreateArray5DDC (void*, long*, long*);
void F90_DestroyArray5DDC(void*);

void F90_CreateArray6DI1 (void*, long*, long*);
void F90_DestroyArray6DI1(void*);

void F90_CreateArray6DI2 (void*, long*, long*);
void F90_DestroyArray6DI2(void*);

void F90_CreateArray6DI (void*, long*, long*);
void F90_DestroyArray6DI(void*);

void F90_CreateArray6DI4 (void*, long*, long*);
void F90_DestroyArray6DI4(void*);

void F90_CreateArray6DI8 (void*, long*, long*);
void F90_DestroyArray6DI8(void*);

void F90_CreateArray6DL1 (void*, long*, long*);
void F90_DestroyArray6DL1(void*);

void F90_CreateArray6DL2 (void*, long*, long*);
void F90_DestroyArray6DL2(void*);

void F90_CreateArray6DL (void*, long*, long*);
void F90_DestroyArray6DL(void*);

void F90_CreateArray6DL4 (void*, long*, long*);
void F90_DestroyArray6DL4(void*);

void F90_CreateArray6DL8 (void*, long*, long*);
void F90_DestroyArray6DL8(void*);

void F90_CreateArray6DR (void*, long*, long*);
void F90_DestroyArray6DR(void*);

void F90_CreateArray6DD (void*, long*, long*);
void F90_DestroyArray6DD(void*);

void F90_CreateArray6DC (void*, long*, long*);
void F90_DestroyArray6DC(void*);

void F90_CreateArray6DDC (void*, long*, long*);
void F90_DestroyArray6DDC(void*);

void F90_CreateArray7DI1 (void*, long*, long*);
void F90_DestroyArray7DI1(void*);

void F90_CreateArray7DI2 (void*, long*, long*);
void F90_DestroyArray7DI2(void*);

void F90_CreateArray7DI (void*, long*, long*);
void F90_DestroyArray7DI(void*);

void F90_CreateArray7DI4 (void*, long*, long*);
void F90_DestroyArray7DI4(void*);

void F90_CreateArray7DI8 (void*, long*, long*);
void F90_DestroyArray7DI8(void*);

void F90_CreateArray7DL1 (void*, long*, long*);
void F90_DestroyArray7DL1(void*);

void F90_CreateArray7DL2 (void*, long*, long*);
void F90_DestroyArray7DL2(void*);

void F90_CreateArray7DL (void*, long*, long*);
void F90_DestroyArray7DL(void*);

void F90_CreateArray7DL4 (void*, long*, long*);
void F90_DestroyArray7DL4(void*);

void F90_CreateArray7DL8 (void*, long*, long*);
void F90_DestroyArray7DL8(void*);

void F90_CreateArray7DR (void*, long*, long*);
void F90_DestroyArray7DR(void*);

void F90_CreateArray7DD (void*, long*, long*);
void F90_DestroyArray7DD(void*);

void F90_CreateArray7DC (void*, long*, long*);
void F90_DestroyArray7DC(void*);

void F90_CreateArray7DDC (void*, long*, long*);
void F90_DestroyArray7DDC(void*);


#endif /* _CHASM_CREATE_ARRAY_H_ */
