/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */
#ifndef _CompilerCharacteristics_h_
#define _CompilerCharacteristics_h_

#include "F90ArrayDataType.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * F90_DescType describes the type of the array descriptor.  The descriptor
 * layout can depend on how the array-valued paramater is declared.
 */
typedef enum
{
  F90_Array,		    /**< an array (e.g., integer :: a(:)) */
  F90_Pointer,		    /**< a pointer (e.g., integer, pointer :: p) */
  F90_ArrayPointer,	   /**< an array pointer
                                (e.g., integer, pointer :: pa(:) )*/
  F90_ArrayPointerInDerived,/**< an array pointer within a derived type */
  F90_DerivedPointer,	    /**< pointer to a derived type */
  F90_NonArray		    /**< not an array or pointer type */
} F90_DescType;


/**
 * F90_HiddenDescType describes the types of hidden descriptor arguments used
 * by a compiler.  Hidden descriptors arguments may be passed at the end of
 * the formal parameter list by some compilers.  Most compilers pass
 * explicitly-defined array parameters via a descriptor (F90_NoHidden).
 * However, in some instances, a compiler may place a pointer to the base
 * of the array in the formal parameter slot and pass a hidden descriptor
 * argument after the formal parameters (F90_PointerWithHiddenDesc).
 */
typedef enum
{
  F90_Hidden,		     /**< has a hidden param */
  F90_NoHidden,		     /**< has no hidden parameter */
  F90_PointerWithHiddenDesc  /**< array pointer passed with a hidden descriptor
				  argument */
} F90_HiddenDescType;


/**
 * CompilerCharacteristics contains function pointers that provide a generic
 * interface to the array descriptor library.
 *
 * This struct contains a pointer for each function that is needed for
 * manipulating fortran array descriptors. The
 * F90_SetCompilerCharacteristics() function is used to initialize the
 * function pointers to the correct vendor-specific function.
 *
 * @see F90_SetCompilerCharacteristics()
 */
typedef struct
{
  int (*setArrayDesc) (void* desc,
		       void* base_addr,
		       int rank,
		       F90_DescType kind,
		       F90_ArrayDataType data_type,
		       unsigned long element_size,
		       const long* lowerBound,
		       const unsigned long* extent,
		       const long* strideMult
		       );

  int (*resetArrayDesc) (void* desc,
			 void* base_addr,
			 int rank,
			 const long* lowerBound,
			 const unsigned long* extent,
			 const long* strideMult
			 );

  void* (*createArrayDesc) (void* desc,
			    void* hidden,
			    int rank,
			    F90_DescType kind
			    );

  int (*createArrayDescAndHidden) (void* src,
				   int rank,
				   F90_DescType kind,
				   void** desc,
				   void** hidden
				   );
  int (*freeArrayDescAndHidden) (F90_DescType kind, void* desc, void* hidden);

  int (*copyToArrayDescAndHidden) (void* src,
				   int rank,
				   F90_DescType kind,
				   void* dest,
				   void* hidden
				   );

  void* (*getArrayBaseAddress ) (const void* desc, int rank);
  unsigned long (*getArraySize) (const void* desc, int rank);

  long          (*getArrayLowerBound) (const void* desc, int rank, int dim);
  unsigned long (*getArrayExtent    ) (const void* desc, int rank, int dim);
  long          (*getArrayStrideMult) (const void* desc, int rank, int dim);

  unsigned long (*getArrayDescSize)   (int rank);

  int (*nullifyArrayDesc) (void* desc, int rank);
  int (*verifyArrayDesc ) (const void* desc, int rank);

  F90_HiddenDescType (*hiddenArrayDescType) (F90_DescType kind);

  char* (*getMangledName) (const char* fun_name, const char* mod_name);

  int  (*printArrayDesc ) (const void* desc, int rank);
  int  (*equalsArrayDesc) (const void* desc2, const void* desc1, int rank);

} F90_CompilerCharacteristics;


/**
 * Sets the CompilerCharacteristics function pointers for the given compiler.
 * Delegates the actual setting of function pointers to the vendor-specific
 * function F90_SetCCFunctions_F90Vendor().  The current set of supported
 * compilers is {"Absoft", "Alpha", "IBMXL", "Intel", "Lahey", "MIPSpro",
 * "NAG", "SUNWspro"}.
 *
 * @param  cc        the CompilerCharacteristics struct
 * @param  compiler  the name of the compiler
 * @return 0         if successful (nonzero on error)
 */
int F90_SetCompilerCharacteristics(F90_CompilerCharacteristics* cc,
				   const char* compiler
				   );


#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* _CompilerCharacteristics_h_ */
