#include <iso_fortran_desc.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif


/*
 * If performance is a concern, implement this as a macro
 */
size_t GFC_DESCRIPTOR_ARRAY_SIZE(dope_vec_GNU* desc,
				 const F_extent_t shape[restrict])
{
  int i;
  size_t size = 1L;
  for (i = 0; i < GFC_DESCRIPTOR_RANK(desc); i++) {
    size *= shape[i-1];
  }
  return size*GFC_DESCRIPTOR_SIZE(desc);
}

/*
 * If performance is a concern, implement this as a macro
 */
static void GFC_GET_STRIDE(dope_vec_GNU* desc,
			   const F_extent_t shape[restrict],
			   F_stride_t stride[restrict]
			   )
{
  int i;
  stride[0] = GFC_DESCRIPTOR_SIZE(desc);
  for (i = 1; i < GFC_DESCRIPTOR_RANK(desc); i++) {
    stride[i] = stride[i-1] * shape[i-1];
  }
}


/*
 * If performance is a concern, implement this as a macro
 */
static void GFC_DESCRIPTOR_SET(dope_vec_GNU* desc,
			       const F_extent_t shape[restrict],
			       const F_extent_t lbound[restrict],
			       const F_stride_t stride[restrict]
			       )
{
  int i;
  size_t offset = 0L;
  
  for (i = 0; i < GFC_DESCRIPTOR_RANK(desc); i++) {
    desc->dim[i].stride_mult = stride[i] / GFC_DESCRIPTOR_SIZE(desc);
    desc->dim[i].lower_bound = lbound[i];
    desc->dim[i].upper_bound = lbound[i] + shape[i] - 1;
    offset += lbound[i] * desc->dim[i].stride_mult;
  }
  desc->base = (void*) -offset;
}


/*
 * If performance is a concern, implement this as a macro
 */
int GFC_DESCRIPTOR_GET (
			dope_vec_GNU* desc,
			void ** base_addr,
			size_t * elem_size,
			F_extent_t shape[],
			F_extent_t lbound[],
			F_stride_t stride[]
			)
{
  int i;
  *base_addr = GFC_DESCRIPTOR_DATA(desc);
  *elem_size = GFC_DESCRIPTOR_SIZE(desc);
  for (i = 0; i < GFC_DESCRIPTOR_RANK(desc); i++) {
    shape[i] = 1 + desc->dim[i].upper_bound - desc->dim[i].lower_bound;
    lbound[i] = desc->dim[i].lower_bound;
    stride[i] = desc->dim[i].stride_mult * GFC_DESCRIPTOR_SIZE(desc);
  }
  return 0;
}


int FDesc_Assumed_Create
                (
                 FDesc_Assumed_t * fdesc,
                 size_t elem_size,
                 unsigned int rank
                )
{
  long size = sizeof(dope_vec_GNU);
  size -= (7-rank) * 3 * sizeof(size_t);
  FDesc_Pointer_t desc = malloc(size);
  if (desc) {
    int dtype_rank = rank & GFC_DTYPE_RANK_MASK;
    int dtype_type = (GFC_DTYPE_UNKNOWN << GFC_DTYPE_TYPE_SHIFT) & GFC_DTYPE_TYPE_MASK;
    int dtype_size = (elem_size << GFC_DTYPE_SIZE_SHIFT);
    desc->dtype = dtype_size | dtype_type | dtype_rank;
    *fdesc = desc;
    return 0;
  }
  else return -1;
}


int FDesc_Pointer_Create
                (
                 FDesc_Pointer_t * fdesc,
                 size_t elem_size,
                 unsigned int rank
                )
{
  long size = sizeof(dope_vec_GNU);
  size -= (7-rank) * 3 * sizeof(size_t);
  FDesc_Pointer_t desc = malloc(size);
  if (desc) {
    int dtype_rank = rank & GFC_DTYPE_RANK_MASK;
    int dtype_type = (GFC_DTYPE_UNKNOWN << GFC_DTYPE_TYPE_SHIFT) & GFC_DTYPE_TYPE_MASK;
    int dtype_size = (elem_size << GFC_DTYPE_SIZE_SHIFT);
    desc->dtype = dtype_size | dtype_type | dtype_rank;
    *fdesc = desc;
    return 0;
  }
  else return -1;
}


int FDesc_Alloc_Create
                (
                 FDesc_Alloc_t * fdesc,
                 size_t elem_size,
                 unsigned int rank
                )
{
  long size = sizeof(dope_vec_GNU);
  size -= (7-rank) * 3 * sizeof(size_t);
  *fdesc = malloc(size);
  if (*fdesc) {
    int dtype_rank = rank & GFC_DTYPE_RANK_MASK;
    int dtype_type = (GFC_DTYPE_UNKNOWN << GFC_DTYPE_TYPE_SHIFT) & GFC_DTYPE_TYPE_MASK;
    int dtype_size = (elem_size << GFC_DTYPE_SIZE_SHIFT);
    (*fdesc)->dtype = dtype_size | dtype_type | dtype_rank;
    return 0;
  }
  else return -1;
}


int FDesc_Assumed_Destroy ( FDesc_Assumed_t * fdesc )
{
  (*fdesc)->base_addr = 0; /* TODO is this good idea, enough? */
  (*fdesc)->base = 0;
  free(*fdesc);
  *fdesc = 0;
  return 0;
}


int FDesc_Pointer_Destroy ( FDesc_Pointer_t * fdesc )
{
  (*fdesc)->base_addr = 0;
  (*fdesc)->base = 0;
  free(*fdesc);
  *fdesc = 0;
  return 0;
}


int FDesc_Alloc_Destroy ( FDesc_Alloc_t * fdesc )
{
  (*fdesc)->base_addr = 0;
  (*fdesc)->base = 0;
  free(*fdesc);
  *fdesc = 0;
  return 0;
}


int FDesc_Assumed_Set
                (
                 FDesc_Assumed_t fdesc,
                 void * restrict base_addr,
                 const F_extent_t shape[restrict],
                 const F_stride_t stride[restrict]
                )
{
  F_extent_t lbound[7] = {1, 1, 1, 1, 1, 1, 1};
  fdesc->base_addr = base_addr;
  GFC_DESCRIPTOR_SET(fdesc, shape, lbound, stride);
  return 0;
}


int FDesc_Pointer_Set
                (
                 FDesc_Pointer_t fdesc,
                 void * base_addr,
                 const F_extent_t shape[restrict],
                 const F_extent_t lbound[restrict],
                 const F_stride_t stride[restrict]
                )
{
  fdesc->base_addr = base_addr;
  GFC_DESCRIPTOR_SET(fdesc, shape, lbound, stride);
  return 0;
}


int FDesc_Assumed_Allocate
                (
                 FDesc_Assumed_t fdesc,
                 const F_extent_t shape[restrict]
                )
{
  F_stride_t stride[7];
  F_extent_t lbound[7] = {1, 1, 1, 1, 1, 1, 1};
  
  GFC_GET_STRIDE(fdesc, shape, stride);
  GFC_DESCRIPTOR_SET(fdesc, shape, lbound, stride);
  
  fdesc->base_addr = malloc(GFC_DESCRIPTOR_ARRAY_SIZE(fdesc, shape));
  if (fdesc->base_addr == 0) return -1;
	
  return 0;
}


int FDesc_Pointer_Allocate
                (
                 FDesc_Pointer_t fdesc,
                 const F_extent_t shape[restrict],
                 const F_extent_t lbound[restrict]
                )
{
  F_stride_t stride[7];
  
  GFC_GET_STRIDE(fdesc, shape, stride);
  GFC_DESCRIPTOR_SET(fdesc, shape, lbound, stride);
  
  fdesc->base_addr = malloc(GFC_DESCRIPTOR_ARRAY_SIZE(fdesc, shape));
  if (fdesc->base_addr == 0) return -1;
	
  return 0;
}


int FDesc_Alloc_Allocate
                (
                 FDesc_Alloc_t fdesc,
                 const F_extent_t shape[restrict],
                 const F_extent_t lbound[restrict]
                )
{
  F_stride_t stride[7];
  
  GFC_GET_STRIDE(fdesc, shape, stride);
  GFC_DESCRIPTOR_SET(fdesc, shape, lbound, stride);

  fdesc->base_addr = malloc(GFC_DESCRIPTOR_ARRAY_SIZE(fdesc, shape));
  if (fdesc->base_addr == 0) return -1;
	
  return 0;
}


int FDesc_Assumed_Deallocate ( FDesc_Assumed_t fdesc )
{
  free(fdesc->base_addr);
  return 0;
}


int FDesc_Pointer_Deallocate ( FDesc_Pointer_t fdesc )
{
  free(fdesc->base_addr);
  return 0;
}


int FDesc_Alloc_Deallocate ( FDesc_Alloc_t fdesc )
{
  free(fdesc->base_addr);
  return 0;
}


_Bool FDesc_Associated ( FDesc_Pointer_t fdesc )
{
  return (fdesc && (fdesc->base_addr != 0) && (fdesc->base != 0));
}


_Bool FDesc_Allocated ( FDesc_Alloc_t fdesc )
{
  return (fdesc && (fdesc->base_addr != 0) && (fdesc->base != 0));  /* TODO check */
}


int FDesc_Assumed_Rank ( FDesc_Assumed_t fdesc )
{
  return GFC_DESCRIPTOR_RANK(fdesc);
}


int FDesc_Pointer_Rank ( FDesc_Pointer_t fdesc )
{
  return GFC_DESCRIPTOR_RANK(fdesc);
}


int FDesc_Alloc_Rank ( FDesc_Alloc_t fdesc )
{
  return GFC_DESCRIPTOR_RANK(fdesc);
}


int FDesc_Assumed_Get
                (
                 FDesc_Assumed_t fdesc,
                 void ** base_addr,
                 size_t * elem_size,
                 F_extent_t shape[],
                 F_extent_t lbound[],
                 F_stride_t stride[]
                )
{
  return GFC_DESCRIPTOR_GET(fdesc, base_addr, elem_size, shape, lbound, stride);
}


int FDesc_Pointer_Get
                (
                 FDesc_Pointer_t fdesc,
                 void ** base_addr,
                 size_t * elem_size,
                 F_extent_t shape[],
                 F_extent_t lbound[],
                 F_stride_t stride[]
                )
{
  return GFC_DESCRIPTOR_GET(fdesc, base_addr, elem_size, shape, lbound, stride);
}


int FDesc_Alloc_Get
                (
                 FDesc_Alloc_t fdesc,
                 void ** base_addr,
                 size_t * elem_size,
                 F_extent_t shape[],
                 F_extent_t lbound[]
                )
{
  F_stride_t stride[7];	//TODO - why not return stride as well? 	
  return GFC_DESCRIPTOR_GET(fdesc, base_addr, elem_size, shape, lbound, stride);
}


#ifdef __cplusplus
}
#endif
