/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */

/**
 * xml_equiv : given two XML documents, checks for structural equivalence,
 *             since plain old diff isn't quite good enough.
 *             not sure if this is implemented in the java XML package,
 *             but it was easy and quick to write...
 *             requires JDK1.4 or later, or earlier JDKs with a compatible
 *             XML library.
 *
 * KNOWN ISSUES: will give false failure if an implicit value is
 *               explicitly specified, since this parser does NOT 
 *               currently use information in a schema or DTD.
 *
 * @author   Matthew Sottile
 */
import java.io.File;
import java.util.Vector;
import javax.xml.parsers.*;
import org.w3c.dom.*;

public class xml_equiv {
    public static boolean compare_documents(Node a, Node b) {
        //
        // name check
        //
        if (!a.getNodeName().equals(b.getNodeName())) {
            return false;
        }

        //
        // attribute check
        //
        NamedNodeMap aAttrs = a.getAttributes();
        NamedNodeMap bAttrs = b.getAttributes();

        //
        // if one does and the other doesn't, fail
        //
        if ((aAttrs == null && bAttrs != null) ||
            (aAttrs != null && bAttrs == null)) {
            return false;
        }

        // 
        // if both have attributes, check them...
        //
        if (aAttrs != null && bAttrs != null) {
            //
            // matching counts?
            //
            if (aAttrs.getLength() != bAttrs.getLength()) {
                return false;
            }

            //
            // attribute by attribute comparisson - for each attribute
            // in a, find one with the same name in b and compare values.
            //
            for (int i = 0; i < aAttrs.getLength(); i++) {
                Node aa = aAttrs.item(i);
                Node ba = bAttrs.getNamedItem(aa.getNodeName());

                //
                // if ba is null, b didn't contain attribute by that name
                //
                if (ba == null) {
                    return false;
                }

                //
                // the only way they can't match now is if the values
                // don't match
                //
                if (!aa.getNodeValue().equals(ba.getNodeValue())) {
                    return false;
                }
            }
        }

        //
        // get children
        //
        NodeList aChildren = a.getChildNodes();
        NodeList bChildren = b.getChildNodes();

        // 
        // child count check
        //
        if (aChildren.getLength() != bChildren.getLength()) {
            return false;
        }

        //
        // if child count is 0, just bail out now.
        //
        if (aChildren.getLength() == 0) {
            return true;
        }

        //-------------------------------------------------------------------
        // comparing children isn't exactly trivial.  must try to match up
        // element and attribute counts, and then element, attribute names,
        // and then values.  if that is impossible, THEN we have a mismatch.
        //

        //
        // first, put the children in a couple of vectors so we can remove
        // matches as we find them.  can't do that on the NodeLists to my
        // knowledge
        //
        Vector aNodes, bNodes;
        aNodes = new Vector();
        bNodes = new Vector();

        for (int i = 0; i < aChildren.getLength(); i++) {
            aNodes.addElement(aChildren.item(i));
            bNodes.addElement(bChildren.item(i));
        }

        //
        // try to find a match for each child of a in b.
        //
        while (aNodes.size() > 0) {
            boolean found = false;
            Node x = (Node)aNodes.elementAt(0);            
            for (int i = 0; i < bNodes.size(); i++) {
                Node y = (Node)bNodes.elementAt(i);
                if (compare_documents(x,y) == true) {
                    aNodes.removeElementAt(0);
                    bNodes.removeElementAt(i);
                    found = true;
                    break;
                }
            }

            if (found == false) {
                return false;
            }
        }

        //
        // the two nodes are equal up to children and attribute equivalence.
        // this makes no assertions about the ordering of either of those
        // though.
        //
        return true;
    }

    public static void main(String args[]) {
        //
        // create a new DOM parser
        //
        DocumentBuilder db = null;
        DocumentBuilderFactory dbf = null;

        try {
            dbf = DocumentBuilderFactory.newInstance();
        } catch (FactoryConfigurationError fce) {
            System.err.println(fce.toString());
        }

        try {
            db = dbf.newDocumentBuilder();
        } catch (ParserConfigurationException pce) {
            System.err.println(pce.toString());
        }

        //
        // Make sure we have 2 arguments
        //
        if (args.length != 2) {
            System.err.println("usage: xml_equiv file1 file2");
            System.exit(1);
        }

        File f1 = new File(args[0]);
        if (f1.exists() == false) {
            System.err.println("error: file \""+args[0]+"\" does not exist.");
            System.exit(1);
        }

        File f2 = new File(args[1]);
        if (f2.exists() == false) {
            System.err.println("error: file \""+args[1]+"\" does not exist.");
            System.exit(1);
        }

        // 
        // ok - both files exist.
        //
        Document doc1 = null;
        Document doc2 = null;

        try {
            doc1 = db.parse(f1);
        } catch (Exception e) {
            System.err.println("doc1 parse: "+e.toString());
        }

        try {
            doc2 = db.parse(f2);
        } catch (Exception e) {
            System.err.println("doc2 parse: "+e.toString());
        }

        System.err.println(compare_documents(doc1,doc2));
    }
}
