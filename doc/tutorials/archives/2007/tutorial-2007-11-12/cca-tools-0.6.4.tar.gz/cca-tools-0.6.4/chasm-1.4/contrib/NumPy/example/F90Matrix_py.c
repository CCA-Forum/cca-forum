#include <Python.h>
#include <arrayobject.h>
#include <CompilerCharacteristics.h>
#include <F90Compiler.h>


#if defined(F90_SYM_CASE_LOWER) || defined(F90_SYM_CASE_MIXED)
# define f90_multiply  F90_SYMBOL( f90_multiply )
#endif

#ifdef F90_SYM_CASE_UPPER
# define f90_multiply  F90_SYMBOL( F90_MULTIPLY )
#endif


/*
 * Define a local exception object and a macro to raise exceptions
 */
static PyObject* ChasmError;		/* local exception object */
#define onError(message) \
	{ PyErr_SetString(ChasmError, message); return NULL; }


/*
 * function prototypes
 */
static PyObject* F90Matrix_multiply(PyObject* self, PyObject* args);

static struct PyMethodDef F90Matrix_methods[] = {
   {"f90_multiply", F90Matrix_multiply, METH_VARARGS, "Matrix multiply."},
   {NULL, NULL, 0, NULL}
};


void initF90Matrix()
{
   PyObject *m, *d;

   // Python initializations
   m = Py_InitModule("F90Matrix", F90Matrix_methods);
   import_array();	/* Magic handshake for Numeric */
   d = PyModule_GetDict(m);
   ChasmError = PyString_FromString("chasm.error");
   PyDict_SetItemString(d, "error", ChasmError);
   if (PyErr_Occurred()) {
      Py_FatalError("Can't initialize module F90Matrix");
   }
}


static PyObject* F90Matrix_multiply(PyObject* self, PyObject* args)
{
  F90_CompilerCharacteristics cc;
  PyObject* arg;
  PyArrayObject *a, *b, *c;
  void *dv_a, *dv_b, *dv_c;
  void *out_dv_a, *out_dv_b, *out_dv_c, *hid_a, *hid_b, *hid_c;
  int i, m, n, rc;
  unsigned long ex[2];
  long size, stride, desc_size, sm[2];
  int shape[2];
  long lb[] = {1, 1};

  int rank = 2;
  long elem_size = sizeof(int);

  if ( ! PyArg_ParseTuple(args,"OO", &a, &b) ) return NULL;

  if (a->nd != 2 || a->descr->type_num != PyArray_INT) {
    Py_FatalError("Array A must be two-dimensional and of type int");
  }
  if (b->nd != 2 || b->descr->type_num != PyArray_INT) {
    Py_FatalError("Array B must be two-dimensional and of type int");
  }

  if (a->dimensions[1] != b->dimensions[0]) {
    Py_FatalError("Cannot perform matrix multiplication on shapes A and B");
  }

  shape[0] = a->dimensions[0];
  shape[1] = b->dimensions[1];

  c = (PyArrayObject*) PyArray_FromDims(rank, shape, PyArray_INT);

  /*
   * create fortran array descriptors (these can be saved)
   */

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);
  desc_size = cc.getArrayDescSize(rank);

  dv_a = malloc(desc_size);
  assert(dv_a);
  stride = elem_size;
  for (i = rank - 1; i >= 0 ; i--) {
    ex[i] = a->dimensions[i];
    sm[i] = stride;
    size = size*ex[i];
    stride *= ex[i];
  }
  rc = cc.setArrayDesc(dv_a, a->data, rank,
		       F90_ArrayPointer, F90_Integer, elem_size, lb, ex, sm);
  if (rc) {
    Py_FatalError("Failed to create array descriptor for A");
  }

  dv_b = malloc(desc_size);
  assert(dv_b);
  stride = elem_size;
  for (i = rank - 1; i >= 0 ; i--) {
    ex[i] = b->dimensions[i];
    sm[i] = stride;
    size = size*ex[i];
    stride *= ex[i];
  }
  rc = cc.setArrayDesc(dv_b, b->data, rank,
		       F90_ArrayPointer, F90_Integer, elem_size, lb, ex, sm);
  if (rc) {
    Py_FatalError("Failed to create array descriptor for B");
  }

  dv_c = malloc(desc_size);
  assert(dv_c);
  stride = elem_size;
  for (i = rank - 1; i >= 0 ; i--) {
    ex[i] = shape[i];
    sm[i] = stride;
    size = size*ex[i];
    stride *= ex[i];
  }
  rc = cc.setArrayDesc(dv_c, c->data, rank,
		       F90_ArrayPointer, F90_Integer, elem_size, lb, ex, sm);
  if (rc) {
    Py_FatalError("Failed to create array descriptor for B");
  }

  /*
   * create temporary array descriptors for call to fortran
   */

  rc = cc.createArrayDescAndHidden(dv_a, rank,
				   F90_ArrayPointer, &out_dv_a, &hid_a);
  rc = cc.createArrayDescAndHidden(dv_b, rank,
				   F90_ArrayPointer, &out_dv_b, &hid_b);
  rc = cc.createArrayDescAndHidden(dv_c, rank,
				   F90_ArrayPointer, &out_dv_c, &hid_c);


  /*
   * make the call to fortran
   */

  f90_multiply(out_dv_a, out_dv_b, out_dv_c, hid_a, hid_b, hid_c);

  /*
   * free array descriptor memory
   */

  cc.freeArrayDescAndHidden(F90_ArrayPointer, out_dv_a, hid_a);
  cc.freeArrayDescAndHidden(F90_ArrayPointer, out_dv_b, hid_b);
  cc.freeArrayDescAndHidden(F90_ArrayPointer, out_dv_c, hid_c);

  free(dv_a);
  free(dv_b);
  free(dv_c);

  Py_INCREF(c);
  return (PyObject*) c;
}
