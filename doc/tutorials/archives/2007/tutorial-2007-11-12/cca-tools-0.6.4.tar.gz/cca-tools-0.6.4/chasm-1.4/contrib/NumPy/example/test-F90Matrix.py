import Numeric
import F90Matrix

a = Numeric.array(([2,0],[0,2]), 'i')
b = Numeric.array(([1,2],[3,4]), 'i')

c = F90Matrix.f90_multiply(a,b)

print
print "a = "
print a
print

print "b = "
print b
print

print "a x b = "
print c
print
