package ChasmXML;

import java.util.Vector;
import java.io.PrintStream;

public class XMLMethod extends XMLEntity {
    private String name, sig;
    private boolean isAbstract, isStatic, isFinal, isVirtual;
    private Vector arguments;
    private boolean isctor, isdtor;
    private Vector exceptions;
    private XMLArg returnArg;

    public XMLMethod(String name, String sig, boolean isA, boolean isS,
                     boolean isF, boolean isV) {
        this.name = name;
        this.sig = sig;
        isAbstract = isA;
        isStatic = isS;
        isFinal = isF;
        isVirtual = isV;
        returnArg = null;

        exceptions = new Vector();
        arguments = new Vector();

        isdtor = false;
        isctor = false;
    }

    public void addArgument(XMLArg a) {
        arguments.addElement(a);
    }

    public void setReturn(XMLArg r) {
        returnArg = r;
    }

    public void addException(String e) {
        exceptions.addElement(e);
    }

    public void isCTOR(boolean isctor) {
        this.isctor = isctor;
    }

    public void isDTOR(boolean isdtor) {
        this.isdtor = isdtor;
    }
    
    public void toXML(PrintStream ps, int depth) {
        String line = "<method name=\""+name+"\" ";
        if (isAbstract) line += "kind=\"abstract\" ";
        else if (isStatic) line += "kind=\"static\" ";
        else if (isFinal) line += "kind=\"final\" ";
        else line += "kind=\"abstract\" ";
        
        if (isctor) {
            line += "ctor=\"yes\" ";
        } else if (isdtor) {
            line += "dtor=\"yes\" ";
        }

        line += ">";
        indent(ps,line,depth);
        
        for (int i = 0; i < arguments.size(); i++) {
            XMLArg a = (XMLArg)arguments.elementAt(i);
            a.toXML(ps,depth++);
        }

        returnArg.toXML(ps,depth++);

        for (int i = 0; i < exceptions.size(); i++) {
            String s = (String)exceptions.elementAt(i);
            indent(ps,"<exception name=\""+s+"\" />",depth++);
        }
        indent(ps,"</method>",depth);
    }
}
