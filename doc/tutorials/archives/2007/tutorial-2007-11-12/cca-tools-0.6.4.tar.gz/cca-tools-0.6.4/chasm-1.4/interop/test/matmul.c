#include <assert.h>
#include <iso_fortran_desc.h>

 /* The interoperable prototype */

void matmul_f90_(FDesc_Assumed_t, FDesc_Assumed_t, FDesc_Assumed_t);


int main(int argc, char* argv[])
{
   int err;

   int A[4][3] = {1,2,3,4,5,6,7,8,9,10,11,12};
   int B[4] = {1,2,3,4};
   int C[3];

   /* The opaque descriptor handles */

   FDesc_Assumed_t A_desc, B_desc, C_desc;

   F_extent_t shape[2] = {3,4};
   F_stride_t stride[2] = {sizeof(int),3*sizeof(int)};

   /* Create the descriptors (error return values are ignored) */

   err = FDesc_Assumed_Create(&A_desc, sizeof(int), 2);
   err = FDesc_Assumed_Create(&B_desc, sizeof(int), 1);
   err = FDesc_Assumed_Create(&C_desc, sizeof(int), 1);

   /* Initialize the descriptors (error return values are ignored) */

   err = FDesc_Assumed_Set(A_desc, A, shape, stride);
   err = FDesc_Assumed_Set(C_desc, C, shape, stride);
   shape[0] = 4;
   err = FDesc_Assumed_Set(B_desc, B, shape, stride);

   /* Assign initial values to A, B */

   matmul_f90_(A_desc, B_desc, C_desc); /* Perform C=A*B */
   
   //printf("C = %d %d %d\n", C[0], C[1], C[2]);

   assert(C[0] == 70);
   assert(C[1] == 80);
   assert(C[2] == 90);

   /* Destroy the descriptors (error return values are ignored) */

   err = FDesc_Assumed_Destroy(&A_desc);
   err = FDesc_Assumed_Destroy(&B_desc);
   err = FDesc_Assumed_Destroy(&C_desc);

   return 0;
}
