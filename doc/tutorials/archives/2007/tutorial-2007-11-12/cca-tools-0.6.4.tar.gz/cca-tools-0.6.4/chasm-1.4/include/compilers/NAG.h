/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */
#ifndef _NAG_H_
#define _NAG_H_

#include <stdio.h>
#include <CompilerCharacteristics.h>

/**
 * @file F90Vendor.h Function declarations for the Chasm array-descriptor
 * library.
 *
 * Fortran 90 (and later) compilers pass array-valued parameters via an array
 * descriptor (sometimes called a dope vector).  The Chasm library provides
 * C functions to get and set array-descriptor elements.  This file
 * declares the API for the array-descriptor library.
 *
 * Note that separate global functions are provided for each Fortran compiler
 * with vendor name appended to the generic function name.  In this file,
 * F90Vendor is used in place of a specific compiler vendor.  A generic
 * interface is available via function pointers in the
 * F90_CompilerCharacteristics struct.  These function pointers are set
 * with the F90_SetCompilerCharacteristics() function.
 * 
 */

/** @mainpage Array Descriptor Library
 *
 * Fortran 90 (and later) compilers pass array-valued parameters via an array
 * descriptor (sometimes called a dope vector).  The Chasm library provides
 * C functions to access elements in an array descriptor.
 *
 * The API for the array descriptor library is divided into
 * several groups:
 * - Creation and initialization of an array descriptor:
 *   -# createArrayDesc_NAG()
 *   -# setArrayDesc_NAG()
 *   -# resetArrayDesc_NAG()
 * - Creation and initialization of a temporary, array and hidden
 *   descriptor pair, used in a procedure call:
 *   -# copyToArrayDescAndHidden_NAG()
 *   -# createArrayDescAndHidden_NAG()
 *   -# freeArrayDescAndHidden_NAG()
 * - Access functions:
 *   -# getArrayBaseAddress_NAG()
 *   -# getArraySize_NAG()
 *   -# getArrayLowerBound_NAG()
 *   -# getArrayExtent_NAG()
 *   -# getArrayStrideMult_NAG()
 * - Miscellaneous helper functions:
 *   -# getArrayDescSize_NAG()
 *   -# hiddenArrayDescType_NAG()
 *   -# verifyArrayDesc_NAG()
 *   -# nullifyArrayDesc_NAG()
 *   -# printArrayDesc_NAG()
 *   -# equalsArrayDesc_NAG()
 *   -# getMangledName_NAG()
 *   -# F90_SetCCFunctions_NAG()
 */


#ifdef __cplusplus
extern "C" {
#endif


/**
 * @defgroup group1 Create and Initialize
 *
 * Functions in this group are used to create and initialize an array
 * descriptor.  Descriptors created by these functions may be permanently
 * stored in C (as long as the array associated with the descriptor has not 
 * freed; it is an error to use a descriptor if the associated array
 * has been freed).  However, these descriptors cannot be directly used in a
 * procedure call to Fortran as the call may require a hidden descriptor
 * parameter (depending on the Fortran compiler).  Descriptors created
 * by these functions must first be converted to a descriptor and hidden
 * descriptor pair by a function in the <b>"Procedure Call"</b> group.
 */
/*@{*/


/**
 * Creates an array descriptor by copying an existing array and
 * hidden descriptor pair.
 *
 * This function is used when passing an array from Fortran to C. 
 * The array and hidden descriptor input parameters are obtained from
 * the Fortran calling procedure; they must not be otherwise stored
 * or saved.
 * 
 * The returned descriptor cannot be directly used in calls to Fortran
 * because a hidden descriptor may be required by some compilers.
 * The created descriptor may be copied to a descriptor and hidden
 * descriptor pair by either createArrayDescAndHidden_NAG()
 * (for a C call to Fortran) or by copyToArrayDescAndHidden_NAG()
 * (for modifying an array pointer on return from a Fortran call to C).
 * <b>Note</b>, it is the callers responsibility to free the returned
 * descriptor.
 *
 * @see setArrayDesc_NAG()
 * @see resetArrayDesc_NAG()
 *
 * @param desc       the array descriptor (from Fortran call stack) to copy
 *                   (in parameter).
 * @param hidden     hidden descriptor (from Fortran call stack; in parameter).
 * @param rank       the rank of the array (in parameter).
 * @param desc_type  type of the source descriptor (in parameter).
 * @return           a newly allocated array descriptor.
 */
void* createArrayDesc_NAG(void* desc,
			       void* hidden,
			       int rank,
			       F90_DescType desc_type
			       );


/**
 * Sets the elements of a preallocated array descriptor.
 * 
 * This function is used when memory for an array has been created in
 * C and the C array is to be subsequently passed to a Fortran procedure.
 *
 * The initialized descriptor cannot be directly used in calls to Fortran
 * because a hidden descriptor parameter may be required by some compilers.
 * The initialized descriptor may be copied to a descriptor and hidden
 * descriptor pair by either createArrayDescAndHidden_NAG()
 * (for a C call to Fortran) or by copyToArrayDescAndHidden_NAG() (for
 * modifying an array pointer on return from a Fortran call to C).
 *
 * Memory for the descriptor is allocated and freed by the caller.
 * The size of descriptor must be at least getArrayDescSize_NAG()
 * bytes.
 *
 * @see createArrayDesc_NAG()
 * @see resetArrayDesc_NAG()
 *
 * @param desc          an uninitialized array descriptor
 *                      (memory created and freed by caller; out parameter).
 * @param base_addr     the base address of the array (in paramemter).
 * @param rank          the rank of the array (in parameter).
 * @param desc_type     type of the descriptor (in parameter).
 * @param data_type     data type of an array element (in parameter).
 * @param element_size  size of an array element (in parameter).
 * @param lowerBound    array[rank] of lower bounds for the array
 *                      (in parameter).
 * @param extent        array[rank] of extents for the array (in elements;
 *                      in parameter).
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes; in parameter).
 * @return              0 if successful (nonzero on error).
 */
int setArrayDesc_NAG(void* desc,
			  void* base_addr,
			  int rank,
			  F90_DescType desc_type,
			  F90_ArrayDataType data_type,
			  unsigned long element_size,
			  const long* lowerBound,
			  const unsigned long* extent,
			  const long* strideMult
			  );


/**
 * Resets the elements of a preallocated array descriptor.  The descriptor
 * must have been previously initialized by either setArrayDesc_NAG()
 * or createArrayDesc_NAG().  The rank, data type and element size
 * of the array MUST NOT change.  <b>Note</b>, at least,
 * getArrayDescSize_NAG() bytes must have been allocated for the
 * descriptor.
 *
 * @param desc          a previously initialized array descriptor
 *                      (memory created and freed by caller; inout parameter).
 * @param base_addr     the base address of the array (in parameter).
 * @param rank          the rank of the array (in parameter).
 * @param lowerBound    array[rank] of lower bounds for the array
 *                      (in parameter).
 * @param extent        array[rank] of extents for the array (in elements;
 *                      in parameter).
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes; in parameter).
 * @return              0 if successful (nonzero on error).
 */
int resetArrayDesc_NAG(void* desc,
			    void* base_addr,
			    int rank,
			    const long* lowerBound,
			    const unsigned long* extent,
			    const long* strideMult
			    );

/*@}*/ /* end of Create_and_Initialize group */


/**
 * @defgroup group2 Procedure Calls
 *
 * Functions in this group are used to create (or copy to) a temporary
 * array and hidden descriptor pair used in a procedure call.
 * <b>Note</b> that descriptors created or intialized by functions in the
 * <b>"Create and Initialize"</b> group cannot be used directly in a procedure
 * call, but must first be copied by one of the functions in this group.
 */
/*@{*/


/**
 * Copies an array descriptor to an array and hidden descriptor pair.
 *
 * This function may be used to modify an array pointer on the return of
 * a Fortran call to C.  The source descriptor must have been created
 * by a call to either createArrayDesc_NAG() or
 * setArrayDesc_NAG().
 *
 * @see createArrayDescAndHidden_NAG()
 *
 * @param src        the source descriptor (in parameter).
 * @param rank       the rank of the source and destination arrays
 *                   (in parameter).
 * @param desc_type  type of the source and destination descriptors
 *                   (in parameter).
 * @param desc       the destination array descriptor
 *                   (from Fortran call stack; out parameter).
 * @param hidden     the destination hidden descriptor (from Fortran call
 *                   stack; out parameter).
 * @return           0 if successful (nonzero on error).
 */
int copyToArrayDescAndHidden_NAG(void* src,
				      int rank,
				      F90_DescType desc_type,
				      void* desc,
				      void* hidden
				      );


/**
 * Creates an array and hidden descriptor pair from an existing
 * descriptor.
 *
 * This function may used in calling a Fortran procedure from C (with
 * an array-valued parameter).  The source descriptor must have been created
 * by a call to either createArrayDesc_NAG() or
 * setArrayDesc_NAG().
 *
 * <b>Note</b>, the companion function
 * freeArrayDescWithHidden_NAG() must be called to free the
 * parameters desc and hidden after use (lifetime must not exceed that of
 * the source descriptor).
 *
 * @see copyToArrayDescAndHidden_NAG()
 *
 * @param src        the source descriptor (in parameter).
 * @param rank       the rank of the source and destination arrays
 *                   (in parameter).
 * @param desc_type  type of the source and destination descriptors
 *                   (in parameter).
 * @param desc       on return, contains address of created array descriptor
 *                   (to be passed to Fortran; out parameter).
 * @param hidden     on return, contains address of hidden form of the
 *                   array descriptor (to be passed to Fortran; out parameter).
 * @return           0 if successful (nonzero on error).
 */
int createArrayDescAndHidden_NAG(void* src,
				      int rank,
				      F90_DescType desc_type,
				      void** desc,
				      void** hidden
				      );


/**
 * Frees an array and hidden descriptor pair created by
 * a call to createArrayDescAndHidden_NAG().
 *
 * @param desc_type  type of the descriptor (in parameter).
 * @param desc       address of descriptor to be freed (inout parameter).
 * @param hidden     address of hidden form of the descriptor to be freed
 *                   (inout parameter).
 * @return           0 if successful (nonzero on error).
 */
int freeArrayDescAndHidden_NAG(F90_DescType desc_type,
				    void* desc, void* hidden
				    );


/*@}*/ /* end of Procedure_Calls group */


/**
 * @defgroup group3 Accessors
 *
 * Functions in this group provide access to information contained in an array
 * descriptor obtained by a call to either createArrayDesc_NAG() or
 * setArrayDesc_NAG().
 */
/*@{*/


/** 
 * Returns a pointer to the base address of the array.
 *
 * @param desc   array descriptor (in parameter).
 * @param rank   the rank of the array (in parameter).
 * @return       the base address of the array.
 */
void* getArrayBaseAddress_NAG(const void* desc, int rank);


/**
 * Returns the array size (in elements).
 *
 * @param desc   array descriptor (in parameter).
 * @param rank   the rank of the array (in parameter).
 * @return       the array size.
 */
unsigned long getArraySize_NAG(const void* desc, int rank);


/**
 * Returns the lower bound for the given dimension.
 *
 * @param desc   array descriptor (in parameter).
 * @param rank   the rank of the array (in parameter).
 * @param dim    the dimension (in parameter).
 * @return       the lower bound of the array for the given dimension.
 */
long getArrayLowerBound_NAG(const void* desc, int rank, int dim);


/**
 * Returns the extent of the array for the given dimension (in elements).
 *
 * @param desc   array descriptor (in parameter).
 * @param rank   the rank of the array (in parameter).
 * @param dim    the dimension (in parameter).
 * @return       the array extent for the given dimension (in elements).
 */
unsigned long getArrayExtent_NAG(const void* desc, int rank, int dim);


/**
 * Returns the distance between successive elements (in bytes).
 *
 * @param desc   array descriptor (in parameter).
 * @param rank   the rank of the array (in parameter).
 * @param dim    the dimension (in parameter).
 * @return       the array stride for the given dimension (in bytes).
 */
long getArrayStrideMult_NAG(const void* desc, int rank, int dim);


/*@}*/ /* end of Accessors group */


/**
 * @defgroup group4 Miscellaneous
 *
 * This group of functions contains various miscellaneous helper functions.
 *
 * <b>Note</b> that all descriptor parameters in this function group
 * must have been obtained by a call to either
 * createArrayDesc_NAG() or setArrayDesc_NAG().
 */
/*@{*/


/**
 * Returns the size of an array descriptor (in bytes).
 *
 * @param rank   the rank of the array (in parameter).
 * @return       the descriptor size (in bytes).
 */
unsigned long getArrayDescSize_NAG(int rank);


/**
 * Returns the type of hidden descriptor used by the compiler for the given
 * descriptor type.
 *
 * @param desc_type  type of the descriptor (in parameter).
 * @return           the hidden descriptor type.
 */
F90_HiddenDescType hiddenArrayDescType_NAG(F90_DescType desc_type);


/**
 * Verify an array descriptor.
 *
 * This function does what it can (given only the limited information
 * in the descriptor) to verify that the elements of the array
 * descriptor are correct (i.e., self consistent).
 *
 * @param desc   array descriptor (in parameter).
 * @param rank   the rank of the array (in parameter).
 * @return       0 if the descriptor is valid, nonzero otherwise.
 */
int verifyArrayDesc_NAG(const void* desc, int rank);


/**
 * Nullify an array descriptor.
 *
 * This sets elements of the array descriptor so that the
 * Fortran nullify intrinsic will return false, given the associated array.
 *
 * @param desc   array descriptor (inout parameter).
 * @param rank   the rank of the array (in parameter).
 * @return       0 if successful (nonzero on error).
 */
int nullifyArrayDesc_NAG(void* desc, int rank);


/**
 * Prints all fields in the array descriptor.
 *
 * @param desc   array descriptor (in parameter).
 * @param rank   the rank of the array (in parameter).
 * @return       0 if successful (nonzero on error).
 */
int printArrayDesc_NAG(const void* desc, int rank);


/**
 * Determines if two descriptors are equal (equivalent).
 *
 * @param desc1   first descriptor (in parameter).
 * @param desc2   second descriptor (in parameter).
 * @param rank    the rank of the array (in parameter).
 * @return        1 if equal, 0 otherwise.
 */
int equalsArrayDesc_NAG(const void* desc1, const void* desc2, int rank);


/**
 * Returns the symbol name of a module procedure, if the module name
 * is not null, otherwise returns the name of the procedure.
 *
 * <b>Note</b> that static memory is used for the return value so it must be
 * copied if retained because the memory is overwritten at each call.
 *
 * @param fun_name   the name of the procedure (in parameter).
 * @param mod_name   the module name (in parameter).  Should be NULL if a
 *                   global procedure rather than a module procedure.
 * @return           the symbol name.
 */
char* getMangledName_NAG(const char* fun_name, const char* mod_name);


/**
 * Set CompilerCharacteristics function pointers for a particular compiler.
 *
 * This function is called by the generic (and global)
 * F90_SetCompilerCharacteristics() function to provide a generic interface
 * to the Chasm array-descriptor library.
 *
 * @param cc  the F90_CompilerCharacteristics struct (out parameter).
 */
void F90_SetCCFunctions_NAG(F90_CompilerCharacteristics* cc);


/*@}*/ /* end of Miscellaneous group */


#ifdef __cplusplus
}
#endif

#endif /*_NAG_H_*/
