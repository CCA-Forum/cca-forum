/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */

#include "CompilerCharacteristics.h"
#include <F90Compiler.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#ifdef F90_ABSOFT
#  include <compilers/Absoft_dv.h>
#  define dope_vec dope_vec_Absoft
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_ALPHA
#  include <compilers/Alpha_dv.h>
#  define dope_vec dope_vec_Alpha
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_CRAY
#  include <compilers/Cray_dv.h>
#  define dope_vec dope_vec_Cray
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_GNU
#  include <compilers/GNU_dv.h>
#  define dope_vec dope_vec_GNU
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_G95
#  include <compilers/G95_dv.h>
#  define dope_vec dope_vec_G95
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_IBMXL
#  include <compilers/IBMXL_dv.h>
#  define dope_vec dope_vec_IBMXL
#  define dope_vec_hidden dope_vec_hidden_IBMXL
#endif

#ifdef F90_INTEL
#  include <compilers/Intel_dv.h>
#  define dope_vec dope_vec_Intel
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_INTEL_7
#  include <compilers/Intel_7_dv.h>
#  define dope_vec dope_vec_Intel_7
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_LAHEY
#  include <compilers/Lahey_dv.h>
#  define dope_vec dope_vec_Lahey
#  define desc_or_hidden hidden
#  undef dope_vec_hidden
#  define dope_vec_hidden dope_vec_hidden_Lahey
#endif

#ifdef F90_MIPSPRO
#  include <compilers/MIPSpro_dv.h>
#  define dope_vec dope_vec_MIPSpro
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_NAG
#  include <compilers/NAG_dv.h>
#  define dope_vec dope_vec_NAG
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_PGI
#  include <compilers/PGI_dv.h>
#  define dope_vec dope_vec1d_PGI
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_SUNWSPRO
#  include <compilers/SUNWspro_dv.h>
#  define dope_vec dope_vec1d_SUNWspro
#  define dope_vec_hidden dope_vec
#endif


#if defined(F90_SYM_CASE_LOWER) || defined(F90_SYM_CASE_MIXED)
#  define chasm_reshape F90_SYMBOL_COND( chasm_reshape )
#endif /* F90_SYM_CASE_LOWER || F90_SYM_CASE_MIXED */

#ifdef F90_SYM_CASE_UPPER
#  define chasm_reshape F90_SYMBOL_COND( CHASM_RESHAPE )
#endif /* F90_SYM_CASE_UPPER */


/*
 * The main chasm reshape function. It reshapes a fortran array by writing
 * a new array descriptor. The function does not alter the original descriptor;
 * it only changes the outgoing descriptor.  The resulting array will be a
 * fortran array which points to the same elements as the original, so changing
 * the values in one will change the values in the other. The order of the
 * elements in the reshaped array will have the same order as if they were
 * reshaped by the reshape function that is built into fortran, only they are
 * not copied into new memory.
 */
void chasm_reshape(int* pRank, dope_vec* old_desc, dope_vec* dim_desc,
		   dope_vec* new_desc, dope_vec_hidden* hidden1,
		   dope_vec_hidden* hidden2, dope_vec_hidden* hidden3,
		   dope_vec_hidden* hidden4
		  )
{
  F90_CompilerCharacteristics cc;
  int i, rank, new_rank, rc;
  unsigned long size, new_size, extent[7];
  long lb[7], stride[7];
  dope_vec_hidden *old_desc_h, *dim_desc_h, *new_desc_h;
  dope_vec *dvIn, *dvDim, *dvOut;
  int* new_dim;

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  assert (old_desc != (dope_vec*) 0);
  assert (dim_desc != (dope_vec*) 0);
  assert (new_desc != (dope_vec*) 0);

  rank  = *pRank;

  old_desc_h = 0;
  dim_desc_h = 0;
  new_desc_h = 0;

  if (cc.hiddenArrayDescType(F90_NonArray) == F90_Hidden) {
    if (cc.hiddenArrayDescType(F90_Array) == F90_PointerWithHiddenDesc) {
      old_desc_h = hidden2;
      dim_desc_h = hidden3;
    }
    if (cc.hiddenArrayDescType(F90_ArrayPointer) == F90_PointerWithHiddenDesc) {
      new_desc_h = hidden4;
    }
  } else {
    if (cc.hiddenArrayDescType(F90_Array) == F90_PointerWithHiddenDesc) {
      old_desc_h = hidden1;
      dim_desc_h = hidden2;
    }
    if (cc.hiddenArrayDescType(F90_ArrayPointer) == F90_PointerWithHiddenDesc || 
        cc.hiddenArrayDescType(F90_ArrayPointer) == F90_Hidden) {
      new_desc_h = hidden3;
    }
  }

  dvIn  = cc.createArrayDesc(old_desc, old_desc_h, rank, F90_Array);
  dvDim = cc.createArrayDesc(dim_desc, dim_desc_h, 1, F90_Array);

  size = cc.getArraySize(dvIn, rank);

  new_rank = cc.getArrayExtent(dvDim, 1, 1);
  new_dim  = (int*) cc.getArrayBaseAddress(dvDim, 1);

  new_size = 1;
  for (i = 0; i < new_rank; i++) {
    new_size *= new_dim[i];
  }
  assert (size == new_size);

  dvOut = (dope_vec*) calloc( 1, cc.getArrayDescSize(new_rank) );

  lb[0] = 1;
  extent[0] = new_dim[0];
  stride[0] = sizeof(int);
  for (i = 1; i < new_rank; i++) {
    lb[i] = 1;
    extent[i] = new_dim[i];
    stride[i] = extent[i-1] * stride[i-1];
  }

  rc = cc.setArrayDesc(dvOut,
		       cc.getArrayBaseAddress(dvIn, rank),
		       new_rank,
		       F90_ArrayPointer,
		       F90_Integer,
		       sizeof(int),
		       lb,
		       extent,
		       stride);
  if (rc) fprintf(stderr, "FAILED in setArrayDesc\n");

  /* copy new descriptor to out parameters (including hidden) */
  cc.copyToArrayDescAndHidden(dvOut, new_rank,
			      F90_ArrayPointer, new_desc, new_desc_h);

  free(dvIn);
  free(dvDim);
  free(dvOut);
}
