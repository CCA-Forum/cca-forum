#
# path to doxygen (may vary depending on installation)
#

doxygen_path = "/usr/local/bin/doxygen"


import sys
sys.path = ['../include/compilers',] + sys.path

import CreationService

#
# create the file F90Vendor.h
#

cs = CreationService.F90CompilerCreator('F90Vendor')
cs.cpp_header()

#
# create the documentation with doxygen
#

import os
os.system(doxygen_path)

