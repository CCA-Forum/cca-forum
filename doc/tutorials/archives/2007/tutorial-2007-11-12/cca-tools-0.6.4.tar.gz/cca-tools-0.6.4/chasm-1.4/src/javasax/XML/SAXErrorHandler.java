package XML;

import org.xml.sax.*;
import org.xml.sax.helpers.*;

/**
 * Implementation of my error handling routines.
 */
public class SAXErrorHandler implements ErrorHandler {
    public void warning(SAXParseException spe) throws SAXException {
        System.err.println("Warning: "+spe.toString());
    }

    public void error(SAXParseException spe) throws SAXException {
        throw new SAXException("Error: "+spe.toString());
    }

    public void fatalError(SAXParseException spe) throws SAXException {
        throw new SAXException("Fatal error: "+spe.toString());
    }
}
