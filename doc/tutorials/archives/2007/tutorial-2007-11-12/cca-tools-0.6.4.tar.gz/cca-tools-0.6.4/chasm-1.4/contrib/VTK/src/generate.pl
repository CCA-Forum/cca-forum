#!/usr/bin/perl

#
# Flags to indicate what should be generated.
# 0 - do not generate, 1 - generate
#

$generate_pdb   			= 0;
$generate_xml	 		= 0;
$generate_c_wrapper 		= 0;
$generate_fortran_wrapper 	= 1;
$generate_fortran_type		= 1;

#
# Set some paths
#
$pdt_root = "/usr/local/pdtoolkit";
$xmlgen_root = "/usr/local/pdtoolkit";
$xsl_root = "xsl";
$xalan = "org.apache.xalan.xslt.Process";
$xalan_root = "/usr/local/xalan";
$vtk_root = "/Users/tomb/Projects/vtk";

#
# Specify all the vtk header locations
#
$includes = " -I".$vtk_root."/Graphics/Testing/Cxx ";
$includes .= " -I".$vtk_root."/Rendering";
$includes .= " -I".$vtk_root."/IO";
$includes .= " -I".$vtk_root."/Imaging";
$includes .= " -I".$vtk_root."/Graphics";
$includes .= " -I".$vtk_root."/Filtering";
$includes .= " -I".$vtk_root."/Common";
$includes .= " -I".$vtk_root."/Common/Testing/Cxx";
$includes .= " -I".$vtk_root."/Utilities/zlib";
$includes .= " -I".$vtk_root."/Utilities/jpeg";
$includes .= " -I".$vtk_root."/Utilities/png";
$includes .= " -I".$vtk_root."/Utilities/tiff";
$includes .= " -I".$vtk_root."/Utilities/expat";
$includes .= " -I".$vtk_root."/Utilities/freetype/include";
$includes .= " -I".$vtk_root."/Utilities/freetype";
$includes .= " -I".$vtk_root."/Utilities/ftgl/src";
$includes .= " -I".$vtk_root."/Utilities/ftgl";
$includes .= " -I".$vtk_root."/usr/X11R6/include";
$includes .= " -I".$vtk_root."/";

#
# Open up the input file and get the list of headers
#
open( HEADERFILE, "headers.txt" );

while( <HEADERFILE> )
   {
   my($line) = $_;
   
   if( substr( $line, 0, 1 ) ne "#" )
     {
   
   # Get the next header name
   $filename = "$line";
   chop $filename;
   my( $justfilename ) = $filename =~ m{([^/]+)$};

   if( $generate_pdb == 1 )
      {            
      # generate and make the call to pdt
      $pdtcmd = $pdt_root."/bin/cxxparse ".$vtk_root."/$filename ".$includes;
      print "generating pdb file for header: ".$filename."\n";
      #print "$pdtcmd"."\n";
      system( $pdtcmd );
      }
      
   if( $generate_xml == 1 )
      {
      # generate and make the call to xmlgen
      $xmlcmd = $xmlgen_root."/bin/xmlgen "."$justfilename".".xml ".$vtk_root."/$filename".".pdb";
      print "generating xml file for header: ".$filename."\n";
      #print "$xmlcmd"."\n";
      system( $xmlcmd );
      }
      
   # now delete the pdb file from the vtk include folder (you can't control where
   # pdt creates its output file.
   $delcmd = "rm ".$vtk_root."/$filename".".pdb"; 
   #print "$delcmd"."\n";
   #system( $delcmd );

   # generate and make the calls (fortran and c) to xslt
   $classpath = $xalan_root."/bin/xalan.jar";
   
   if( $generate_c_wrapper == 1 )
      {
      print "generating C wrapper code for header: ".$filename."\n";
      $xslccmd = "java -cp $xalan_root ".$xalan." -xsl ".$xsl_root."/fc_c.xsl -in ".$justfilename.".xml -out ".$justfilename."_C.cxx";
      #print "$xslccmd"."\n";
      system( $xslccmd );
      }
   
   if( $generate_fortran_wrapper == 1 )
      {
      print "generating fortran wrapper code for header: ".$filename."\n";
      $xslfcmd = "java -cp $xalan_root ".$xalan." -xsl ".$xsl_root."/fc_f.xsl -in ".$justfilename.".xml -out ".$justfilename."_F.f90";
      #print "$xslfcmd"."\n";
      system( $xslfcmd );
      }
      
   if( $generate_fortran_type == 1 )
      {
      print "generating fortran types for header: ".$filename."\n";
      $xslftypecmd = "java -cp $xalan_root ".$xalan." -xsl ".$xsl_root."/fc_ftypes.xsl -in ".$justfilename.".xml -out ".$justfilename."_Ftype.f90";
      system( $xslftypecmd );
      }

   # now delete the xml file since we don't need it anymore
   $delcmd = "rm ".$justfilename.".xml"; 
   #print "$delcmd"."\n";
   #system( $delcmd );

   }
   else
      {
      #print "skipping file ".$line
      }
   
   }
