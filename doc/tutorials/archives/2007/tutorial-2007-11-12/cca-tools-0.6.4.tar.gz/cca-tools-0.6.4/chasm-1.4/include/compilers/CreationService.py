class F90CompilerCreator:

  def __init__(self, compiler):
    self.xpath = '/Users/rasmussn/chasm/include/compilers/'
    self.compiler = compiler
  ### enddef __init__


  ##################################################################
  #  create .h file
  #
  def cpp_header(self):
    xpath = '/Users/rasmussn/chasm/include/compilers/'

    input = open(xpath + 'Generic.h', 'r')
    output = open(self.compiler + '.h', 'w')

    for line in input.readlines():
      out = line.replace('@NAME_UPPER@', self.compiler.upper())
      output.write( out.replace('@NAME_MIXED@', self.compiler) )

    input.close()
    output.close()

  ### enddef cpp_header
