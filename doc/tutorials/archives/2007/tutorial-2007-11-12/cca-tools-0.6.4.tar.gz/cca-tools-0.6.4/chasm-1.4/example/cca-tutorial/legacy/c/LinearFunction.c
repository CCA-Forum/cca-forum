#include "LinearFunction.h"

double evaluate_c_lf(double x)
{
  return 12.0 * x + 3.2;
}
