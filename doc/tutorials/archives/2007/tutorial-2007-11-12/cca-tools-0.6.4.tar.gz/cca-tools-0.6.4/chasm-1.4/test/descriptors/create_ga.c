/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */

#include "CompilerCharacteristics.h"
#include <F90Compiler.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#if defined(F90_SYM_CASE_LOWER) || defined(F90_SYM_CASE_MIXED)
#  define create_ga F90_SYMBOL_COND( create_ga )
#endif /* F90_SYM_CASE_LOWER || F90_SYM_CASE_MIXED */

#ifdef F90_SYM_CASE_UPPER
#  define create_ga F90_SYMBOL_COND( CREATE_GA )
#endif /* F90_SYM_CASE_UPPER */


/*
 * Initialize a 2-D integer array (column major)
 */
void initArrayI2D(int* a, int nx, int ny) {
  int i, j;
  int* pa = a;

  for (i = 0; i < nx; i++) {
    for (j = 0; j < ny; j++) {
      *pa = 10*(j+1) + (i+1);
      pa++;
    }
  }
}


void create_ga(void* dv, int* shape, int* error, void* dv_hidden)
{
  F90_CompilerCharacteristics cc;
  void* dv_local;
  int* ia;
  int rank = 2;
  int nx = shape[0];
  int ny = shape[1];

  unsigned long elem_size = sizeof(int);

  long lb[2] = {1, 1};
  long  s[2];
  unsigned long extent[2];

  s[0] = elem_size;
  s[1] = elem_size * ny;
  extent[0] = nx;
  extent[1] = ny;

  *error = 0;

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  dv_local = malloc( cc.getArrayDescSize(rank) );
  assert(dv_local);

  /*
   * Create and initialize array memory.
   */
  ia = (int*) malloc(sizeof(int) * nx * ny);
  assert(ia);
  initArrayI2D(ia, nx, ny);  

  *error = cc.setArrayDesc(dv_local, ia, rank, F90_ArrayPointer,
			   F90_Integer, sizeof(int), lb, extent, s);
  if (*error) {
    fprintf(stderr, "ERROR in setting array descriptor\n");
  }

  cc.copyToArrayDescAndHidden(dv_local, rank, F90_ArrayPointer, dv, dv_hidden);
}
