#include "CubeFunction.hh"

double functions::CubeFunction::evaluate(double x)
{
   return x*x*x;
}
