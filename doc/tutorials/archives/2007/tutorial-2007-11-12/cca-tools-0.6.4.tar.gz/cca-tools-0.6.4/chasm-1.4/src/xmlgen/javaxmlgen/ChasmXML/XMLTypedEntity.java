package ChasmXML;

public abstract class XMLTypedEntity extends XMLEntity {
    int type;
    
    // the java equiv. of an enumeration...
    public final int TY_INT    = 1;
    public final int TY_LONG   = 2;
    public final int TY_FLOAT  = 3;
    public final int TY_DOUBLE = 4;
    public final int TY_VOID   = 5;
    public final int TY_CHAR   = 6;
    public final int TY_STRING = 7;
    public final int TY_OBJECT = 8;
    public final int TY_SHORT  = 9;
    
    public String toTypeString() {
        String typeString = "";
        
        switch (type) {
        case TY_INT:
            typeString = "int";
            break;
        case TY_LONG:
            typeString = "long";
            break;
        case TY_FLOAT:
            typeString = "float";
            break;
        case TY_DOUBLE:
            typeString = "double";
            break;
        case TY_VOID:
            typeString = "void";
            break;
        case TY_CHAR:
            typeString = "char";
            break;
        case TY_STRING:
        case TY_OBJECT:
            typeString = "object";
            break;
        case TY_SHORT:
            typeString = "short";
            break;
        default:
            typeString = "undefined("+type+")";
        }
        
        return typeString;
    }
}
