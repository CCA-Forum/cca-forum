/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */

#include "CompilerCharacteristics.h"
#include <F90Compiler.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#if defined(F90_SYM_CASE_LOWER) || defined(F90_SYM_CASE_MIXED)
#  define test_short F90_SYMBOL_COND( test_short )
#  define test_short_p F90_SYMBOL_COND( test_short_p )
#  define test_short_dp F90_SYMBOL_COND( test_short_dp )
#  define test_int F90_SYMBOL_COND( test_int )
#  define test_int_p F90_SYMBOL_COND( test_int_p )
#  define test_int_dp F90_SYMBOL_COND( test_int_dp )
#  define test_long F90_SYMBOL_COND( test_long )
#  define test_long_p F90_SYMBOL_COND( test_long_p )
#  define test_long_dp F90_SYMBOL_COND( test_long_dp )
#endif /* F90_SYM_CASE_LOWER || F90_SYM_CASE_MIXED */

#ifdef F90_SYM_CASE_UPPER
#  define test_short F90_SYMBOL_COND( TEST_SHORT )
#  define test_short_p F90_SYMBOL_COND( TEST_SHORT_P )
#  define test_short_dp F90_SYMBOL_COND( TEST_SHORT_DP )
#  define test_int F90_SYMBOL_COND( TEST_INT )
#  define test_int_p F90_SYMBOL_COND( TEST_INT_P )
#  define test_int_dp F90_SYMBOL_COND( TEST_INT_DP )
#  define test_long F90_SYMBOL_COND( TEST_LONG )
#  define test_long_p F90_SYMBOL_COND( TEST_LONG_P )
#  define test_long_dp F90_SYMBOL_COND( TEST_LONG_DP )
#endif /* F90_SYM_CASE_UPPER */


int test_short(void* dv, void* dv_hidden);
int test_short_p(void* dv, void* dv_hidden);
int test_short_dp(void* dv, void* dv_hidden);
int test_int(void* dv, void* dv_hidden);
int test_int_p(void* dv, void* dv_hidden);
int test_int_dp(void* dv, void* dv_hidden);
int test_long(void* dv, void* dv_hidden);
int test_long_p(void* dv, void* dv_hidden);
int test_long_dp(void* dv, void* dv_hidden);


int F90_MAIN(int argc, char* argv[])
{
  F90_CompilerCharacteristics cc;
  void *desc, *dv, *dv_hidden;
  int i, rank, rc;
#if F90_MIN_ELEMENT_SIZE == 4
  int sa[10];
#else
  short sa[10];
#endif
  int ia[10];
  long la[10];
  long lb[7], stride[7];
  unsigned long elem_size;
  unsigned long extent[7];

  rc = 0;
  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  for (i = 0; i < 10; i++) {
    sa[i] = i + 1;
    ia[i] = i + 1;
    la[i] = i + 1;
  }

  rank = 1;
  lb[0] = 1;
  extent[0] = 10;

  desc = malloc( cc.getArrayDescSize(rank) );
  assert(desc);

  /* create short array descriptor */

  elem_size = sizeof(short);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  stride[0] = elem_size;
  rc = cc.setArrayDesc(desc, sa, rank, F90_Array,
		       F90_Integer2, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setting array descriptor\n");
  }

  /* test short array */

  rc = cc.createArrayDescAndHidden(desc, rank, F90_Array, &dv, &dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in createArrayDescAndHidden\n");
  }

  rc = test_short(dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in test_short\n");
  }
  
  rc = cc.freeArrayDescAndHidden(F90_Array, dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in freeArrayDescAndHidden\n");
  }

  /* test short array pointer */

  rc = cc.createArrayDescAndHidden(desc, rank, F90_ArrayPointer, &dv, &dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in createArrayDescAndHidden\n");
  }

  rc = test_short_p(dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in test_short_p\n");
  }
  
  rc = cc.freeArrayDescAndHidden(F90_ArrayPointer, dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in freeArrayDescAndHidden\n");
  }

  /* test short array pointer in derived type */

  rc = cc.createArrayDescAndHidden(desc, rank,
				    F90_ArrayPointerInDerived, &dv, &dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in createArrayDescAndHidden\n");
  }
  if (dv_hidden) {
    fprintf(stderr, "WARNING, dv_hidden not NULL, could be trouble\n");
  }

  rc = test_short_dp(dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in test_short_dp\n");
  }
  
  rc = cc.freeArrayDescAndHidden(F90_ArrayPointerInDerived, dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in freeArrayDescAndHidden\n");
  }

  /* create int array descriptor */

  elem_size = sizeof(int);
  stride[0] = elem_size;
  rc = cc.setArrayDesc(desc, ia, rank, F90_Array,
		       F90_Integer, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setting array descriptor\n");
  }

  /* test int array */

  rc = cc.createArrayDescAndHidden(desc, rank, F90_Array, &dv, &dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in createArrayDescAndHidden\n");
  }

  rc = test_int(dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in test_int\n");
  }
  
  rc = cc.freeArrayDescAndHidden(F90_Array, dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in freeArrayDescAndHidden\n");
  }

  /* test int array pointer */

  rc = cc.createArrayDescAndHidden(desc, rank, F90_ArrayPointer, &dv, &dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in createArrayDescAndHidden\n");
  }

  rc = test_int_p(dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in test_int_p\n");
  }
  
  rc = cc.freeArrayDescAndHidden(F90_ArrayPointer, dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in freeArrayDescAndHidden\n");
  }

  /* test int array pointer in derived type */

  rc = cc.createArrayDescAndHidden(desc, rank,
				    F90_ArrayPointerInDerived, &dv, &dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in createArrayDescAndHidden\n");
  }
  if (dv_hidden) {
    fprintf(stderr, "WARNING, dv_hidden not NULL, could be trouble\n");
  }

  rc = test_int_dp(dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in test_int_dp\n");
  }
  
  rc = cc.freeArrayDescAndHidden(F90_ArrayPointerInDerived, dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in freeArrayDescAndHidden\n");
  }

  /* create long array descriptor */

  elem_size = sizeof(long);
  stride[0] = elem_size;
  if (elem_size == 4) {
    rc = cc.setArrayDesc(desc, la, rank, F90_Array,
			 F90_Integer4, elem_size, lb, extent, stride);
  } else if (elem_size == 8) {
    rc = cc.setArrayDesc(desc, la, rank, F90_Array,
			 F90_Integer8, elem_size, lb, extent, stride);
  } else {
    fprintf(stderr, "ERROR, sizeof(long) neither 4 nor 8\n");
    exit(1);
  }

  if (rc) {
    fprintf(stderr, "ERROR in setting array descriptor\n");
  }

  /* test long array */

  rc = cc.createArrayDescAndHidden(desc, rank, F90_Array, &dv, &dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in createArrayDescAndHidden\n");
  }

  rc = test_long(dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in test_long\n");
  }
  
  rc = cc.freeArrayDescAndHidden(F90_Array, dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in freeArrayDescAndHidden\n");
  }

  /* test long array pointer */

  rc = cc.createArrayDescAndHidden(desc, rank, F90_ArrayPointer, &dv, &dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in createArrayDescAndHidden\n");
  }

  rc = test_long_p(dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in test_long_p\n");
  }
  
  rc = cc.freeArrayDescAndHidden(F90_ArrayPointer, dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in freeArrayDescAndHidden\n");
  }

  /* test long array pointer in derived type */

  rc = cc.createArrayDescAndHidden(desc, rank,
				    F90_ArrayPointerInDerived, &dv, &dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in createArrayDescAndHidden\n");
  }
  if (dv_hidden) {
    fprintf(stderr, "WARNING, dv_hidden not NULL, could be trouble\n");
  }

  rc = test_long_dp(dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in test_long_dp\n");
  }
  
  rc = cc.freeArrayDescAndHidden(F90_ArrayPointerInDerived, dv, dv_hidden);
  if (rc) {
    fprintf(stderr, "ERROR in freeArrayDescAndHidden\n");
  }

  return rc;
}
