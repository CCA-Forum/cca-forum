/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */
#include <compilers/Intel.h>
#include <compilers/Intel_dv.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define dope_vec dope_vec_Intel

#ifdef __cplusplus
extern "C"{
#endif


/**
 * Set CompilerCharacteristics function pointers for Intel.
 */
void F90_SetCCFunctions_Intel(F90_CompilerCharacteristics* cc)
{
  cc->setArrayDesc              = setArrayDesc_Intel;
  cc->resetArrayDesc            = resetArrayDesc_Intel;
  cc->createArrayDesc           = createArrayDesc_Intel;
  cc->createArrayDescAndHidden  = createArrayDescAndHidden_Intel;
  cc->freeArrayDescAndHidden    = freeArrayDescAndHidden_Intel;
  cc->copyToArrayDescAndHidden  = copyToArrayDescAndHidden_Intel;
  cc->getArrayBaseAddress       = getArrayBaseAddress_Intel;
  cc->getArraySize              = getArraySize_Intel;
  cc->getArrayLowerBound        = getArrayLowerBound_Intel;
  cc->getArrayExtent	        = getArrayExtent_Intel;
  cc->getArrayStrideMult        = getArrayStrideMult_Intel;
  cc->getArrayDescSize	        = getArrayDescSize_Intel;
  cc->nullifyArrayDesc          = nullifyArrayDesc_Intel;
  cc->verifyArrayDesc           = verifyArrayDesc_Intel;
  cc->hiddenArrayDescType       = hiddenArrayDescType_Intel;
  cc->getMangledName	        = getMangledName_Intel;
  cc->equalsArrayDesc	        = equalsArrayDesc_Intel;
  cc->printArrayDesc	        = printArrayDesc_Intel;
}


/**
 * Sets the elements of a preallocated array descriptor.  This function is
 * used when passing a C array to Fortran.  NOTE, assumes that, at least,
 * ArrayDescSize bytes have been allocated in the desc pointer.
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param base_addr     the base address of the array
 * @param rank          the rank of the array
 * @param desc_type     type of the descriptor
 * @param data_type     data type of an array element
 * @param element_size  size of an array element
 * @param lowerBound    array[rank] of lower bounds for the array
 * @param extent        array[rank] of extents for the array (in elements)
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes)
 * @return              0 if successful (nonzero on error)
 */
int setArrayDesc_Intel(void* desc,
		       void* base_addr,
		       int rank,
		       F90_DescType desc_type,
		       F90_ArrayDataType data_type,
		       unsigned long element_size,
		       const long* lowerBound,
		       const unsigned long* extent,
		       const long* strideMult
		       )
{
  dope_vec* dv = (dope_vec*) desc;

  if (rank < 0 || rank > 7) return 1;

  dv->rank        = rank;
  dv->offset      = 0;			/* set later in reset */

  if (rank == 0) {
    dv->elem_size = 0;
    dv->assoc     = 0;
    dv->ptr_alloc = 0;
    dv->p_or_a    = 0;
  } else {
    dv->elem_size = element_size;
    dv->assoc     = 1;
    dv->ptr_alloc = 1;
    dv->p_or_a    = 1;
  }

  dv->non_contig  = 0;
  dv->reserved_1  = 0;
  dv->reserved_2  = 0;
  dv->reserved_3  = 0;

#ifdef CHASM_ARCH_64
  dv->reserved64  = 0;
#endif

  return resetArrayDesc_Intel(desc, base_addr, rank,
			      lowerBound, extent, strideMult);
}


/**
 * Resets the elements of a preallocated array descriptor.  The descriptor
 * must have been previously initialized by either setArrayDesc() or
 * createArrayDesc().  The rank, data type and element size of the array
 * MUST NOT change.  NOTE, assumes that, at least, ArrayDescSize() bytes
 * have been allocated in the desc pointer.
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param base_addr     the base address of the array
 * @param rank          the rank of the array
 * @param lowerBound    array[rank] of lower bounds for the array
 * @param extent        array[rank] of extents for the array (in elements)
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes)
 * @return              0 if successful (nonzero on error)
 */
int resetArrayDesc_Intel(void* desc,
			 void* base_addr,
			 int rank,
			 const long* lowerBound,
			 const unsigned long* extent,
			 const long* strideMult
			 )
{
  int i;
  long offset = 0L;
  dope_vec* dv = (dope_vec*) desc;

  if (rank < 0 || rank > 7) return 1;

  if (rank > 0) {
    dv->assoc     = 1;
    dv->ptr_alloc = 1;
    dv->p_or_a    = 1;
  }

  dv->base_addr = base_addr;
  for (i = 0; i < rank; i++) {
    dv->dim[i].extent      = extent[i];
    dv->dim[i].stride_mult = strideMult[i];
    dv->dim[i].lower_bound = lowerBound[i];
    offset += dv->dim[i].lower_bound * dv->dim[i].stride_mult;
  }
  dv->offset = -offset;

  return 0;
}


/**
 * Returns an array descriptor by copying an existing descriptor.  This
 * function is used when passing an array from Fortran to C++.  NOTE,
 * it is the callers responsibility to free the returned descriptor.
 *
 * @param desc       the descriptor to copy
 * @param hidden     hidden descriptor parameter
 * @param rank       the rank of the array
 * @param desc_type  type of the source descriptor
 * @return           allocated array descriptor copy
 */
void* createArrayDesc_Intel(void* desc,
			    void* hidden,
			    int rank,
			    F90_DescType desc_type
			    )
{
  unsigned long size = getArrayDescSize_Intel(rank);

  void* dv = (void*) calloc( 1, size );
  assert(dv != 0);

  memcpy(dv, desc, size);

  return dv;
}


/**
 * Creates an array descriptor (with hidden portion) from an existing
 * descriptor in preparation for calling a Fortran function from C (with
 * an array valued parameter).
 *
 * IMPORTANT NOTES: The companion function freeArrayDescAndHidden must be
 * called to free the parameters desc and hidden after use (lifetime
 * must not exceed that of the source descriptor).
 *
 * @param src        the source descriptor
 * @param rank       the rank of the source and destination arrays
 * @param desc_type  type of the source and destination descriptors
 * @param desc       on return, contains address of created descriptor
 * @param hidden     on return, contains address of hidden form of the descriptor
 * @return           0 if successful (nonzero on error)
 */
int createArrayDescAndHidden_Intel(void* src,
				   int rank,
				   F90_DescType desc_type,
				   void** desc,
				   void** hidden
				   )
{
  *desc = src;
  *hidden = 0x0;
  return 0;
}


/**
 * Frees an array descriptor (with hidden portion) created by
 * a call to createArrayDescAndHidden().
 *
 * @param desc_type  type of the descriptor
 * @param desc       address of descriptor to be freed
 * @param hidden     address of hidden form of the descriptor to be freed
 * @return           0 if successful (nonzero on error)
 */
int freeArrayDescAndHidden_Intel(F90_DescType desc_type, void* desc, void* hidden)
{
  return 0;
}


/**
 * Copies one array descriptor to another.  This function is used
 * when passing an array from C++ to Fortran.
 *
 * @param src        the source descriptor
 * @param rank       the rank of the source and destination arrays
 * @param desc_type  type of the source and destination descriptors
 * @param dest       the destination descriptor
 * @param hidden     hidden form of the descriptor, after formal parameter list
 * @return           0 if successful (nonzero on error)
 */
int copyToArrayDescAndHidden_Intel(void* src,
				   int rank,
				   F90_DescType desc_type,
				   void* dest,
				   void* hidden
				   )
{
  memcpy(dest, src, getArrayDescSize_Intel(rank));
  return 0;
}


/** 
 * Returns a pointer to the base address of the array.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       base address of the array
 */
void* getArrayBaseAddress_Intel(const void* desc, int rank)
{
  dope_vec* dv = (dope_vec*) desc;

  if (rank < 0 || rank > 7) return 0x0;
  if (rank != 0) {
    if (rank != dv->rank) return 0x0;
  }

  return dv->base_addr;
}


/**
 * Returns the array size (in elements).
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       array size
 */
unsigned long getArraySize_Intel(const void* desc, int rank)
{
  int i;
  unsigned long size = 1L;

  dope_vec* dv = (dope_vec*) desc;
  if (rank < 1 || rank > dv->rank) return 0L;

  for (i = 0; i < rank; i++) {
    size *= dv->dim[i].extent;
  }
  return size;
}


/**
 * Returns the lower bound for the given dimension.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       lower bound
 */
long getArrayLowerBound_Intel(const void* desc, int rank, int dim)
{
  dope_vec* dv = (dope_vec*) desc;
  if (rank < 1 || rank > dv->rank) return 0L;
  return dv->dim[dim-1].lower_bound;
}


/**
 * Returns the extent of the array for the given dimension (in elements).
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       array extent (in elements)
 */
unsigned long getArrayExtent_Intel(const void* desc, int rank, int dim)
{
  dope_vec* dv = (dope_vec*) desc;
  if (rank < 1 || rank > dv->rank) return 0L;
  return dv->dim[dim-1].extent;
}


/**
 * Returns the distance between successive elements (in bytes).
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       stride (in bytes)
 */
long getArrayStrideMult_Intel(const void* desc, int rank, int dim)
{
  dope_vec* dv = (dope_vec*) desc;
  if (rank < 1 || rank > dv->rank) return 0L;
  return dv->dim[dim-1].stride_mult;
}


/**
 * Returns the size of an array descriptor (in bytes).
 *
 * @param rank   the rank of the array
 * @return       descriptor size (in bytes)
 */
unsigned long getArrayDescSize_Intel(int rank)
{
  if (rank < 0 || rank > 7) return 0L;
  return sizeof(dope_vec) - 3*(7-rank)*sizeof(long);
}


/**
 * Nullify an array descriptor (associated intrinsic will return false).
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @return       0 if successful (nonzero on error)
 */
int nullifyArrayDesc_Intel(void* desc, int rank)
{
  dope_vec* dv = (dope_vec*) desc;
  dv->assoc = 0;

  if (rank == 0) {
    dv->base_addr = 0x0;
  }

  return 0;
}


/**
 * Verify an array descriptor.
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @return       0 if the descriptor is valid, nonzero otherwise
 */
int verifyArrayDesc_Intel(const void* desc, int rank)
{
  int i;
  long offset;
  unsigned long size;
  dope_vec* dv = (dope_vec*) desc;

  if (dv->base_addr == 0x0) return 1;

  if (rank == 0) {
    return 0;
  }

  /*
   * rank != 0
   */

  if (dv->rank      != rank)	return 1;
  if (dv->elem_size <  1)	return 1;

  if (dv->assoc != 1)           return 1;          

  for (i = 0; i < dv->rank; i++) {
    if (dv->dim[i].extent      < 1) return 1;
    if (dv->dim[i].stride_mult < 1) return 1;
  }
  return 0;
}


/**
 * Returns the type of hidden descriptors used by the compiler
 *
 * @return       hidden descriptor type
 */
F90_HiddenDescType hiddenArrayDescType_Intel(F90_DescType desc_type)
{
  return F90_NoHidden;
}


/**
 * Returns the symbol name of a module procedure, if the module name
 * is not null, otherwise returns the name of the procedure.
 *
 * Note: static memory is used for the return value so it must be
 * copied if retained because the memory is overwritten at each call.
 *
 * @param fun_name   the name of the procedure
 * @param mod_name   the module name (NULL if a global procedure)
 * @return           symbol name
 */
char* getMangledName_Intel(const char* fun_name, const char* mod_name)
{   
  int i;
  static char name[512];
  size_t funsize, modsize, namesize;

  if (fun_name == NULL) return NULL;

  funsize = strlen(fun_name);
  if (mod_name == NULL) {
    modsize = 0L;
    namesize = funsize + 1;
  } else {
    modsize = strlen(mod_name);
    namesize = modsize + 2 + funsize + 1;
  }

  if (namesize > 511) return NULL;

  if (modsize > 0L) {
    strcpy(name, mod_name);
    strcpy(name + modsize, "..");
    strcpy(name + modsize + 2, fun_name);
    strcpy(name + modsize + 2 + funsize, "_");
    /* lower case -> fun_name and mod_name */
    for (i = 0; i < modsize; i++) {
      if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
    }
    for (i = modsize + 2; i < namesize; i++) {
      if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
    }
  } else {
    strcpy(name, fun_name);
    strcpy(name + funsize, "_");
    /* lower case -> fun_name */
    for (i = 0; i < funsize; i++) {
      if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
    }
  }

  return name;
}


/**
 * Prints all fields in the array descriptor.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       0 if successful (nonzero on error)
 */
int printArrayDesc_Intel(const void* desc, int rank)
{
  int i;
  dope_vec *dv = (dope_vec*) desc;

  printf("Intel array descriptor:\n");
  printf("  base_addr   = %p\n" , dv->base_addr);
  printf("  elem_size   = %ld\n"  , dv->elem_size);
  printf("  offset      = %ld\n"  , dv->offset);

  printf("  assoc       = %d\n"   , dv->assoc);
  printf("  ptr_alloc   = %d\n"   , dv->ptr_alloc);
  printf("  p_or_a      = %d\n"   , dv->p_or_a);
  printf("  non_contig  = %d\n"   , dv->non_contig);

  printf("  reserved_1   = %d\n"   , dv->reserved_1);
  printf("  reserved_2   = %d\n"   , dv->reserved_2);
  printf("  reserved_3   = %d\n"   , dv->reserved_3);
#ifdef CHASM_ARCH_64
  printf("  reserved64   = %d\n"   , dv->reserved64);
#endif

  printf("  rank        = %ld\n"   , dv->rank);

  if (rank == 0) return 0;

  for (i = 0; i < dv->rank; i++) {
    printf("    dim[%d] = EX:%ld, SM:%ld, LB:%ld\n", i, dv->dim[i].extent,
           dv->dim[i].stride_mult, dv->dim[i].lower_bound);
  }
  return 0;
}


/**
 * Determines if two descriptors are equal (equivalent).
 *
 * WARNING, this function is deprecated.
 *
 * @param desc1   first descriptor
 * @param desc2   second descriptor
 * @param rank    the rank of the array
 * @return        1 if equal, 0 otherwise
 */
int equalsArrayDesc_Intel(const void* desc1, const void* desc2, int rank)
{
  int i;
  dope_vec* dv1 = (dope_vec*) desc1;
  dope_vec* dv2 = (dope_vec*) desc2;

  if (dv1->base_addr != dv2->base_addr)	return 0;

  if (rank == 0) return 1;

  if (dv1->offset      != dv2->offset) return 0;
  if (dv1->rank        != dv2->rank)   return 0;

  if (dv1->elem_size   != dv2->elem_size)   return 0;
  if (dv1->assoc       != dv2->assoc    )   return 0;
  if (dv1->ptr_alloc   != dv2->ptr_alloc)   return 0;
  if (dv1->p_or_a      != dv2->p_or_a   )   return 0;
  if (dv1->non_contig  != dv2->non_contig ) return 0;

  if (dv1->reserved_1 != dv2->reserved_1) return 0;
  if (dv1->reserved_2 != dv2->reserved_2) return 0;
  if (dv1->reserved_3 != dv2->reserved_3) return 0;
#ifdef CHASM_ARCH_64
  if (dv1->reserved64 != dv2->reserved64) return 0;
#endif

  for (i = 0; i < rank; i++) {
    if (dv1->dim[i].extent      != dv2->dim[i].extent) return 0;
    if (dv1->dim[i].stride_mult != dv2->dim[i].stride_mult) return 0;
    if (dv1->dim[i].lower_bound != dv2->dim[i].lower_bound) return 0;
  }
  return 1;
}


#ifdef __cplusplus
}
#endif
