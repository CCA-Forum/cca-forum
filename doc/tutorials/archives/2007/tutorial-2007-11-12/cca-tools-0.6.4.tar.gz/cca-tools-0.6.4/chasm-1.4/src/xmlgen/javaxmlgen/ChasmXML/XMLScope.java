package ChasmXML;

import java.util.Vector;
import java.io.PrintStream;

/**
 * An XML Scope represents a package in Java
 */
public class XMLScope extends XMLEntity {
    private String name, fullname;
    private String filename;
    private Vector members;
    private XMLScope parent;
    
    public XMLScope() {
        name = "";
        fullname = "";
        members = new Vector();
        parent = null;
    }
    
    public XMLScope(String name, XMLScope parent) {
        this.name = name;
        members = new Vector();
        this.parent = parent;
        this.setFullname();
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public void setParent(XMLScope parent) {
        this.parent = parent;
        this.setFullname();
    }

    public XMLScope getParent() {
        return parent;
    }
    
    public void setFullname() {
        if (parent != null) {
            fullname = parent.getFullname()+"."+name;
            parent.addMember(this);
        } else {
            fullname = name;
        }
    }

    public String getFullname() {
        return fullname;
    }

    public void addMember(Object o) {
        members.addElement(o);
    }
    
    public void toXML(PrintStream ps, int depth) {
        indent(ps,"<scope name=\""+name+"\" kind=\"package\">",depth);
        for (int i = 0; i < members.size(); i++) {
            Object o = members.elementAt(i);
            if (o instanceof XMLEntity) {
                XMLEntity oxe = (XMLEntity)o;
                oxe.toXML(ps,depth++);
            }
        }
        indent(ps,"</scope>",depth);
    }
    
}
