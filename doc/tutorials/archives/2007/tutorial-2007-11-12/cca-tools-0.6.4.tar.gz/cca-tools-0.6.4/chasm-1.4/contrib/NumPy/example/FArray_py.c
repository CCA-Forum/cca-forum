#include <Python.h>
#include <Numeric/arrayobject.h>
#include <F90Compiler.h>


#if   defined (F90_SYM_CASE_LOWER)
#  define get_arrays F90_SYMBOL(get_arrays)
#elif defined (F90_SYM_CASE_UPPER)
#  define get_arrays F90_SYMBOL(GET_ARRAYS)
#endif

void get_arrays(void*);


/*
 * Define a local exception object and a macro to raise exceptions
 */
static PyObject* FArray_Error_py;	/* local exception object */
#define onError(message) \
	{ PyErr_SetString(FArray_Error_py, message); return NULL; }


/*
 * function prototypes
 */
static PyObject* FArray_GetArrays_py(PyObject* self, PyObject* args);


static struct PyMethodDef FArray_methods[] = {
  {"getArrays", FArray_GetArrays_py, METH_VARARGS, "Get Fortran array dictionary."},
   {NULL, NULL, 0, NULL}
};


void initFArray()
{
  PyObject *m, *d;

  /* Python initializations */
  m = Py_InitModule("FArray", FArray_methods);
  import_array();	/* Magic handshake for Numeric */
  d = PyModule_GetDict(m);
  FArray_Error_py = PyString_FromString("FArray_py.error");
  PyDict_SetItemString(d, "error", FArray_Error_py);
  if (PyErr_Occurred()) {
    Py_FatalError("Can't initialize module FArray");
  }
}


static
PyObject* FArray_GetArrays_py(PyObject* self, PyObject* args)
{
  PyObject* dict;

  if ( ! PyArg_ParseTuple(args, "O", &dict) ) return NULL;

  get_arrays(dict);

  Py_INCREF(Py_None);
  return Py_None;
}
