package ChasmXML;

import java.io.PrintStream;

public class XMLArg extends XMLTypedEntity {
    private String  name;
    private int     intent;
    private boolean isReturn;
    
    // note : no out only intent
    //
    public final int INTENT_IN    = 1;
    public final int INTENT_INOUT = 2;
    
    public XMLArg(String name, int type) {
        this.name = name;
        this.type = type;
        isReturn = false;
    }

    public XMLArg(int type) {
        this.type = type;
    }

    public void setReturn(boolean ir) {
        isReturn = ir;
    }
    
    public void toXML(PrintStream ps, int depth) {
        String line = "";

        if (isReturn) {
            line += "<return>";
        } else {
            line += "<arg name=\""+name+"\" ";
            if (intent == INTENT_IN) {
                line += "intent=\"in\" ";
            } else {
                line += "intent=\"out\" ";
            }
            line += ">";
        }

        indent(ps,line,depth);
        indent(ps,this.toTypeString(),depth++);

        if (isReturn)
            indent(ps,"</return>",depth);
        else
            indent(ps,"</arg>",depth);
    }    
}
