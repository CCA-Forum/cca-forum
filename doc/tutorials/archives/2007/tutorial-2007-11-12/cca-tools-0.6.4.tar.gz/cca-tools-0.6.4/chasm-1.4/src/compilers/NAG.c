/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */
#include <compilers/NAG.h>
#include <compilers/NAG_dv.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define dope_vec dope_vec_NAG

#ifdef __cplusplus
extern "C"{
#endif


/**
 * Set CompilerCharacteristics function pointers for NAG.
 */
void F90_SetCCFunctions_NAG(F90_CompilerCharacteristics* cc)
{
  cc->setArrayDesc              = setArrayDesc_NAG;
  cc->resetArrayDesc            = resetArrayDesc_NAG;
  cc->createArrayDesc           = createArrayDesc_NAG;
  cc->createArrayDescAndHidden  = createArrayDescAndHidden_NAG;
  cc->freeArrayDescAndHidden    = freeArrayDescAndHidden_NAG;
  cc->copyToArrayDescAndHidden  = copyToArrayDescAndHidden_NAG;
  cc->getArrayBaseAddress       = getArrayBaseAddress_NAG;
  cc->getArraySize              = getArraySize_NAG;
  cc->getArrayLowerBound        = getArrayLowerBound_NAG;
  cc->getArrayExtent	        = getArrayExtent_NAG;
  cc->getArrayStrideMult        = getArrayStrideMult_NAG;
  cc->getArrayDescSize	        = getArrayDescSize_NAG;
  cc->nullifyArrayDesc          = nullifyArrayDesc_NAG;
  cc->verifyArrayDesc           = verifyArrayDesc_NAG;
  cc->hiddenArrayDescType       = hiddenArrayDescType_NAG;
  cc->getMangledName	        = getMangledName_NAG;
  cc->equalsArrayDesc	        = equalsArrayDesc_NAG;
  cc->printArrayDesc	        = printArrayDesc_NAG;
}


/**
 * Sets the elements of a preallocated array descriptor.  This function is
 * used when passing a C array to Fortran.  NOTE, assumes that, at least,
 * ArrayDescSize bytes have been allocated in the desc pointer.
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param base_addr     the base address of the array
 * @param rank          the rank of the array
 * @param desc_type     type of the descriptor
 * @param data_type     data type of an array element
 * @param element_size  size of an array element
 * @param lowerBound    array[rank] of lower bounds for the array
 * @param extent        array[rank] of extents for the array (in elements)
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes)
 * @return              0 if successful (nonzero on error)
 */
int setArrayDesc_NAG(void* desc,
		     void* base_addr,
		     int rank,
		     F90_DescType desc_type,
		     F90_ArrayDataType data_type,
		     unsigned long element_size,
		     const long* lowerBound,
		     const unsigned long* extent,
		     const long* strideMult
		     )
{
  if (rank < 0 || rank > 7) return 1;

  return resetArrayDesc_NAG(desc, base_addr, rank,
			    lowerBound, extent, strideMult);
}


/**
 * Resets the elements of a preallocated array descriptor.  The descriptor
 * must have been previously initialized by either setArrayDesc() or
 * createArrayDesc().  The rank, data type and element size of the array
 * MUST NOT change.  NOTE, assumes that, at least, ArrayDescSize() bytes
 * have been allocated in the desc pointer.
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param base_addr     the base address of the array
 * @param rank          the rank of the array
 * @param lowerBound    array[rank] of lower bounds for the array
 * @param extent        array[rank] of extents for the array (in elements)
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes)
 * @return              0 if successful (nonzero on error)
 */
int resetArrayDesc_NAG(void* desc,
		       void* base_addr,
		       int rank,
		       const long* lowerBound,
		       const unsigned long* extent,
		       const long* strideMult
		       )
{
  int i;
  long offset = 0L;
  dope_vec *dv = (dope_vec*) desc;

  if (rank < 0 || rank > 7) return 1;

  dv->base_addr = base_addr;

  for (i = 0; i < rank; i++) {
    dv->dim[i].extent      = extent[i];
    dv->dim[i].stride_mult = strideMult[i];
    dv->dim[i].lower_bound = lowerBound[i];
  }

  for (i = 0; i < rank; i++) {
    offset += dv->dim[i].lower_bound * dv->dim[i].stride_mult;
  }
  if (rank == 0) offset = 1L;
  dv->offset = -offset;

  return 0;
}


/**
 * Returns an array descriptor by copying an existing descriptor.  This
 * function is used when passing an array from Fortran to C++.  NOTE,
 * it is the callers responsibility to free the returned descriptor.
 *
 * @param desc       the descriptor to copy
 * @param hidden     hidden descriptor parameter
 * @param rank       the rank of the array
 * @param desc_type  type of the source descriptor
 * @return           allocated array descriptor copy
 */
void* createArrayDesc_NAG(void* desc,
			  void* hidden,
			  int rank,
			  F90_DescType desc_type
			  )
{
  void* dv = (void*) calloc( 1, getArrayDescSize_NAG(rank) );
  assert(dv != 0);

  memcpy(dv, desc, getArrayDescSize_NAG(rank));

  return dv;
}


/**
 * Creates an array descriptor (with hidden portion) from an existing
 * descriptor in preparation for calling a Fortran function from C (with
 * an array valued parameter).
 *
 * IMPORTANT NOTES: The companion function freeArrayDescAndHidden must be
 * called to free the parameters desc and hidden after use (lifetime
 * must not exceed that of the source descriptor).
 *
 * @param src        the source descriptor
 * @param rank       the rank of the source and destination arrays
 * @param desc_type  type of the source and destination descriptors
 * @param desc       on return, contains address of created descriptor
 * @param hidden     on return, contains address of hidden form of the descriptor
 * @return           0 if successful (nonzero on error)
 */
int createArrayDescAndHidden_NAG(void* src,
				 int rank,
				 F90_DescType desc_type,
				 void** desc,
				 void** hidden
				 )
{
  *desc = src;
  *hidden = 0x0;
  return 0;
}


/**
 * Frees an array descriptor (with hidden portion) created by
 * a call to createArrayDescAndHidden().
 *
 * @param desc_type  type of the descriptor
 * @param desc       address of descriptor to be freed
 * @param hidden     address of hidden form of the descriptor to be freed
 * @return           0 if successful (nonzero on error)
 */
int freeArrayDescAndHidden_NAG(F90_DescType desc_type, void* desc, void* hidden)
{
  return 0;
}


/**
 * Copies one array descriptor to another.  This function is used
 * when passing an array from C++ to Fortran.
 *
 * @param src        the source descriptor
 * @param rank       the rank of the source and destination arrays
 * @param desc_type  type of the source and destination descriptors
 * @param dest       the destination descriptor
 * @param hidden     hidden form of the descriptor, after formal parameter list
 * @return           0 if successful (nonzero on error)
 */
int copyToArrayDescAndHidden_NAG(void* src,
				 int rank,
				 F90_DescType desc_type,
				 void* dest,
				 void* hidden
				 )
{
  memcpy(dest, src, getArrayDescSize_NAG(rank));
  return 0;
}


/** 
 * Returns a pointer to the base address of the array.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       base address of the array
 */
void* getArrayBaseAddress_NAG(const void* desc, int rank)
{
  if (rank < 0 || rank > 7) {
    return 0x0;
  } else {
    return (long*) ((dope_vec*) desc)->base_addr;
  }
}


/**
 * Returns the array size (in elements).
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       array size
 */
unsigned long getArraySize_NAG(const void* desc, int rank)
{
  int i;
  unsigned long size = 1L;

  if (rank < 1 || rank > 7) return 0;

  for (i = 0; i < rank; i++) {
    size *= ((dope_vec*)desc)->dim[i].extent;
  }
  return size;
}


/**
 * Returns the lower bound for the given dimension.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       lower bound
 */
long getArrayLowerBound_NAG(const void* desc, int rank, int dim)
{
  if (rank < 1 || rank > 7) return 0;

  return((dope_vec*) desc)->dim[dim-1].lower_bound;
}


/**
 * Returns the extent of the array for the given dimension (in elements).
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       array extent (in elements)
 */
unsigned long getArrayExtent_NAG(const void* desc, int rank, int dim)
{
  if (rank < 1 || rank > 7) return 0;

  return ((dope_vec*) desc)->dim[dim-1].extent;
}


/**
 * Returns the distance between successive elements (in bytes).
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       stride (in bytes)
 */
long getArrayStrideMult_NAG(const void* desc, int rank, int dim)
{
  if (rank < 1 || rank > 7) return 0;

  return ((dope_vec*) desc)->dim[dim-1].stride_mult;
}


/**
 * Returns the size of an array descriptor (in bytes).
 *
 * @param rank   the rank of the array
 * @return       descriptor size (in bytes)
 */
unsigned long getArrayDescSize_NAG(int rank)
{
  if (rank < 0 || rank > 7) return 0;

  return sizeof(dope_vec) - 3*(7-rank)*sizeof(long);
}


/**
 * Nullify an array descriptor (associated intrinsic will return false).
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @return       0 if successful (nonzero on error)
 */
int nullifyArrayDesc_NAG(void* desc, int rank)
{
  dope_vec* dv = (dope_vec*) desc;
  dv->base_addr = 0x0;
  return 0;
}


/**
 * Verify an array descriptor.
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @return       0 if the descriptor is valid, nonzero otherwise
 */
int verifyArrayDesc_NAG(const void* desc, int rank)
{
  int i;
  long offset = 0L;
  dope_vec* dv = (dope_vec*) desc;

  if (dv->base_addr == 0x0) return 1;

  for (i = 0; i < rank; i++) {
    if (dv->dim[i].extent      < 1) return 1;
    if (dv->dim[i].stride_mult < 1) return 1;
    offset += dv->dim[i].lower_bound * dv->dim[i].stride_mult;
  }
  if (dv->offset != -offset) return 1;

  return 0;
}


/**
 * Returns the type of hidden descriptors used by the compiler
 *
 * @return       hidden descriptor type
 */
F90_HiddenDescType hiddenArrayDescType_NAG(F90_DescType desc_type)
{
  return F90_NoHidden;
}


/**
 * Returns the symbol name of a module procedure, if the module name
 * is not null, otherwise returns the name of the procedure.
 *
 * Note: static memory is used for the return value so it must be
 * copied if retained because the memory is overwritten at each call.
 *
 * @param fun_name   the name of the procedure
 * @param mod_name   the module name (NULL if a global procedure)
 * @return           symbol name
 */
char* getMangledName_NAG(const char* fun_name, const char* mod_name)
{   
  int i;
  static char name[512];
  size_t funsize, modsize, namesize;

  if (fun_name == NULL) return NULL;

  funsize = strlen(fun_name);
  if (mod_name == NULL) {
    modsize = 0L;
    namesize = funsize + 1;
  } else {
    modsize = strlen(mod_name);
    namesize = modsize + 4 + funsize;
  }

  if (namesize > 511) return NULL;

  if (modsize > 0L) {
    strcpy(name, mod_name);
    strcpy(name + modsize, "_MP_");
    strcpy(name + modsize + 4, fun_name);
    /* lower case -> fun_name name and mod_name */
    for (i = 0; i < modsize; i++) {
      if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
    }
    for (i = modsize + 4; i < namesize; i++) {
      if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
    }
  } else {
    strcpy(name, fun_name);
    strcpy(name + funsize, "_");
    /* lower case -> fun_name */
    for (i = 0; i < funsize; i++) {
      if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
    }
  }

  return name;
}


/**
 * Prints all fields in the array descriptor.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       0 if successful (nonzero on error)
 */
int printArrayDesc_NAG(const void* desc, int rank)
{
  int i;
  dope_vec *dv = (dope_vec*) desc;

  printf("NAG array descriptor:\n");
  printf("  base_addr   = %p\n" , (void*) dv->base_addr);
  printf("  offset      = %d\n" , dv->offset);

  for (i = 0; i < rank; i++) {
    printf("    dim[%d] = LB:%ld, Ex:%ld, SM:%ld\n", i, dv->dim[i].lower_bound,
           dv->dim[i].extent, dv->dim[i].stride_mult);
  }
  return 0;
}


/**
 * Determines if two descriptors are equal (equivalent).
 *
 * WARNING, this function is deprecated.
 *
 * @param desc1   first descriptor
 * @param desc2   second descriptor
 * @param rank    the rank of the array
 * @return        1 if equal, 0 otherwise
 */
int equalsArrayDesc_NAG(const void* desc1, const void* desc2, int rank)
{
  int i;
  dope_vec* dv1 = (dope_vec*) desc1;
  dope_vec* dv2 = (dope_vec*) desc2;

  if (dv1->base_addr  != dv2->base_addr)  return 0;

  for (i = 0; i < rank; i++) {
    if (dv1->dim[i].extent      != dv2->dim[i].extent)      return 0;
    if (dv1->dim[i].stride_mult != dv2->dim[i].stride_mult) return 0;
    if (dv1->dim[i].lower_bound != dv2->dim[i].lower_bound) return 0;
  }
  return 1;
}


#ifdef __cplusplus
}
#endif
