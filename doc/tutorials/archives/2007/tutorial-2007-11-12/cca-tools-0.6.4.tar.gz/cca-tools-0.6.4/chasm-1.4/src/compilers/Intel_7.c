/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */
#include <compilers/Intel_7.h>
#include <compilers/Intel_7_dv.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define dope_vec dope_vec_Intel_7

#ifdef __cplusplus
extern "C"{
#endif


/**
 * Set CompilerCharacteristics function pointers for Intel (version 7).
 */
void F90_SetCCFunctions_Intel_7(F90_CompilerCharacteristics* cc)
{
  cc->setArrayDesc              = setArrayDesc_Intel_7;
  cc->resetArrayDesc            = resetArrayDesc_Intel_7;
  cc->createArrayDesc           = createArrayDesc_Intel_7;
  cc->createArrayDescAndHidden  = createArrayDescAndHidden_Intel_7;
  cc->freeArrayDescAndHidden    = freeArrayDescAndHidden_Intel_7;
  cc->copyToArrayDescAndHidden  = copyToArrayDescAndHidden_Intel_7;
  cc->getArrayBaseAddress       = getArrayBaseAddress_Intel_7;
  cc->getArraySize              = getArraySize_Intel_7;
  cc->getArrayLowerBound        = getArrayLowerBound_Intel_7;
  cc->getArrayExtent	        = getArrayExtent_Intel_7;
  cc->getArrayStrideMult        = getArrayStrideMult_Intel_7;
  cc->getArrayDescSize	        = getArrayDescSize_Intel_7;
  cc->nullifyArrayDesc          = nullifyArrayDesc_Intel_7;
  cc->verifyArrayDesc           = verifyArrayDesc_Intel_7;
  cc->hiddenArrayDescType       = hiddenArrayDescType_Intel_7;
  cc->getMangledName	        = getMangledName_Intel_7;
  cc->equalsArrayDesc	        = equalsArrayDesc_Intel_7;
  cc->printArrayDesc	        = printArrayDesc_Intel_7;
}


/**
 * Sets the elements of a preallocated array descriptor.  This function is
 * used when passing a C array to Fortran.  NOTE, assumes that, at least,
 * ArrayDescSize bytes have been allocated in the desc pointer.
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param base_addr     the base address of the array
 * @param rank          the rank of the array
 * @param desc_type     type of the descriptor
 * @param data_type     data type of an array element
 * @param element_size  size of an array element
 * @param lowerBound    array[rank] of lower bounds for the array
 * @param extent        array[rank] of extents for the array (in elements)
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes)
 * @return              0 if successful (nonzero on error)
 */
int setArrayDesc_Intel_7(void* desc,
			 void* base_addr,
			 int rank,
			 F90_DescType desc_type,
			 F90_ArrayDataType data_type,
			 unsigned long element_size,
			 const long* lowerBound,
			 const unsigned long* extent,
			 const long* strideMult
			 )
{
  dope_vec* dv = (dope_vec*) desc;

  if (rank < 0 || rank > 7) return 1;

  dv->rank        = rank;
  dv->non_contig  = 0;
  dv->unknown_1   = 0;
  dv->not_pointer = 0;

  if (rank == 0) {
    dv->elem_size   = 0;
    dv->elem_size_2 = 0;
  } else {
    dv->elem_size   = element_size;
    dv->elem_size_2 = element_size;
  }

  return resetArrayDesc_Intel_7(desc, base_addr, rank,
				lowerBound, extent, strideMult);
}


/**
 * Resets the elements of a preallocated array descriptor.  The descriptor
 * must have been previously initialized by either setArrayDesc() or
 * createArrayDesc().  The rank, data type and element size of the array
 * MUST NOT change.  NOTE, assumes that, at least, ArrayDescSize() bytes
 * have been allocated in the desc pointer.
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param base_addr     the base address of the array
 * @param rank          the rank of the array
 * @param lowerBound    array[rank] of lower bounds for the array
 * @param extent        array[rank] of extents for the array (in elements)
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes)
 * @return              0 if successful (nonzero on error)
 */
int resetArrayDesc_Intel_7(void* desc,
			   void* base_addr,
			   int rank,
			   const long* lowerBound,
			   const unsigned long* extent,
			   const long* strideMult
			   )
{
  int i;
  long offset;
  unsigned long size;
  dope_vec* dv = (dope_vec*) desc;

  if (rank < 0 || rank > 7) return 1;

  if (rank == 0) {
    dv->marked_base = (char*) base_addr;
    dv->base_addr   = 0x0;
    dv->size        = 0;
#ifdef USE_MARK_OFFSET
    dv->mark_offset = - (long) dv->marked_base;
#endif
    return 0;
  }

  /*
   * rank != 0
   */

  dv->base_addr = (char*) base_addr;

  if (dv->base_addr == 0x0) return 1;
  if (dv->elem_size == 0) return 1;

  for (i = 0; i < rank; i++) {
    dv->dim[i].lower_bound = lowerBound[i];
    dv->dim[i].upper_bound = lowerBound[i] + extent[i] - 1;
    dv->dim[i].stride_mult = strideMult[i] / dv->elem_size;
  }

  size = 1L;
  offset = 0L;
  for (i = 0; i < dv->rank; i++) {
    unsigned long extent = 1L + dv->dim[i].upper_bound - dv->dim[i].lower_bound;
    if (dv->dim[i].stride_mult == 0) return 1;
    size *= extent;
    offset += dv->dim[i].lower_bound * dv->dim[i].stride_mult;
  }
  dv->size = size;
  offset = offset * dv->elem_size;

#ifdef USE_MARK_OFFSET
  dv->mark_offset  = offset;
#endif
  dv->marked_base  = dv->base_addr - offset;

  return 0;
}


/**
 * Returns an array descriptor by copying an existing descriptor.  This
 * function is used when passing an array from Fortran to C++.  NOTE,
 * it is the callers responsibility to free the returned descriptor.
 *
 * @param desc       the descriptor to copy
 * @param hidden     hidden descriptor parameter
 * @param rank       the rank of the array
 * @param desc_type  type of the source descriptor
 * @return           allocated array descriptor copy
 */
void* createArrayDesc_Intel_7(void* desc,
			      void* hidden,
			      int rank,
			      F90_DescType desc_type
			      )
{
  unsigned long size = getArrayDescSize_Intel_7(rank);

  long* dv = (long*) calloc( 1, size );
  assert(dv != 0);

  if (rank == 0) {
    memcpy(dv, desc, size);
    return dv;
  }

  if (desc_type == F90_ArrayPointerInDerived) {
    memcpy(dv, desc, size);
  } else {
    dv[0] = ((long*)desc)[1] - ((long*)desc)[0];
    memcpy(&dv[1], desc, size - sizeof(dv[0]));
  }
  return dv;
}


/**
 * Creates an array descriptor (with hidden portion) from an existing
 * descriptor in preparation for calling a Fortran function from C (with
 * an array valued parameter).
 *
 * IMPORTANT NOTES: The companion function freeArrayDescAndHidden must be
 * called to free the parameters desc and hidden after use (lifetime
 * must not exceed that of the source descriptor).
 *
 * @param src        the source descriptor
 * @param rank       the rank of the source and destination arrays
 * @param desc_type  type of the source and destination descriptors
 * @param desc       on return, contains address of created descriptor
 * @param hidden     on return, contains address of hidden form of the descriptor
 * @return           0 if successful (nonzero on error)
 */
int createArrayDescAndHidden_Intel_7(void* src,
				     int rank,
				     F90_DescType desc_type,
				     void** desc,
				     void** hidden
				     )
{
  if (desc_type == F90_ArrayPointerInDerived) {
    *desc = src;
  } else {
    *desc = (long*) src + 1;
  }
  *hidden = 0x0;

  return 0;
}


/**
 * Frees an array descriptor (with hidden portion) created by
 * a call to createArrayDescAndHidden().
 *
 * @param desc_type  type of the descriptor
 * @param desc       address of descriptor to be freed
 * @param hidden     address of hidden form of the descriptor to be freed
 * @return           0 if successful (nonzero on error)
 */
int freeArrayDescAndHidden_Intel_7(F90_DescType desc_type,
				   void* desc,
				   void* hidden
				   )
{
  return 0;
}


/**
 * Copies one array descriptor to another.  This function is used
 * when passing an array from C++ to Fortran.
 *
 * @param src        the source descriptor
 * @param rank       the rank of the source and destination arrays
 * @param desc_type  type of the source and destination descriptors
 * @param dest       the destination descriptor
 * @param hidden     hidden form of the descriptor, after formal parameter list
 * @return           0 if successful (nonzero on error)
 */
int copyToArrayDescAndHidden_Intel_7(void* src,
				     int rank,
				     F90_DescType desc_type,
				     void* dest,
				     void* hidden
				     )
{
  if (desc_type == F90_ArrayPointerInDerived) {
    memcpy(dest, src, getArrayDescSize_Intel_7(rank));
  } else {
    memcpy(dest, (long*)src + 1, getArrayDescSize_Intel_7(rank) - sizeof(long));
  }
  return 0;
}


/** 
 * Returns a pointer to the base address of the array.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       base address of the array
 */
void* getArrayBaseAddress_Intel_7(const void* desc, int rank)
{
  dope_vec* dv = (dope_vec*) desc;

  if (rank < 0 || rank > 7) return 0x0;
  if (rank != 0) {
    if (rank != dv->rank) return 0x0;
  }

  if (rank == 0) return dv->marked_base;
  else           return dv->base_addr;
}


/**
 * Returns the array size (in elements).
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       array size
 */
unsigned long getArraySize_Intel_7(const void* desc, int rank)
{
  dope_vec* dv = (dope_vec*) desc;
  if (rank < 1 || rank > dv->rank) return 0L;
  return dv->size;
}


/**
 * Returns the lower bound for the given dimension.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       lower bound
 */
long getArrayLowerBound_Intel_7(const void* desc, int rank, int dim)
{
  dope_vec* dv = (dope_vec*) desc;
  if (rank < 1 || rank > dv->rank) return 0L;
  return dv->dim[dim-1].lower_bound;
}


/**
 * Returns the extent of the array for the given dimension (in elements).
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       array extent (in elements)
 */
unsigned long getArrayExtent_Intel_7(const void* desc, int rank, int dim)
{
  dope_vec* dv = (dope_vec*) desc;
  if (rank < 1 || rank > dv->rank) return 0L;

  return ( 1L + dv->dim[dim-1].upper_bound - dv->dim[dim-1].lower_bound );
}


/**
 * Returns the distance between successive elements (in bytes).
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       stride (in bytes)
 */
long getArrayStrideMult_Intel_7(const void* desc, int rank, int dim)
{
  dope_vec* dv = (dope_vec*) desc;
  if (rank < 1 || rank > dv->rank) return 0L;
  return dv->elem_size * dv->dim[dim-1].stride_mult;
}


/**
 * Returns the size of an array descriptor (in bytes).
 *
 * @param rank   the rank of the array
 * @return       descriptor size (in bytes)
 */
unsigned long getArrayDescSize_Intel_7(int rank)
{
  if (rank < 0 || rank > 7) return 0L;
  return sizeof(dope_vec) - 3*(7-rank)*sizeof(long);
}


/**
 * Nullify an array descriptor (associated intrinsic will return false).
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @return       0 if successful (nonzero on error)
 */
int nullifyArrayDesc_Intel_7(void* desc, int rank)
{
  dope_vec* dv = (dope_vec*) desc;
  dv->base_addr = 0x0;
  if (rank == 0) dv->marked_base = 0x0;
  return 0;
}


/**
 * Verify an array descriptor.
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @return       0 if the descriptor is valid, nonzero otherwise
 */
int verifyArrayDesc_Intel_7(const void* desc, int rank)
{
  int i;
  long offset;
  unsigned long size;
  dope_vec* dv = (dope_vec*) desc;

  if (rank == 0) {
    if (dv->marked_base == 0x0)	return 1;
    return 0;
  }

  /*
   * rank != 0
   */

  if (dv->base_addr == 0x0)		return 1;
  if (dv->rank      != rank)		return 1;
  if (dv->elem_size <  1)		return 1;
  if (dv->elem_size_2 != dv->elem_size)	return 1;

  size = 1L;
  offset = 0L;
  for (i = 0; i < dv->rank; i++) {
    unsigned long extent = 1L + dv->dim[i].upper_bound - dv->dim[i].lower_bound;
    if (dv->dim[i].upper_bound < dv->dim[i].lower_bound) return 1;
    if (dv->dim[i].stride_mult < 1) return 1;
    size *= extent;
    offset += dv->dim[i].lower_bound * dv->dim[i].stride_mult;
  }
  if (dv->size != size) return 1;
  offset = offset * dv->elem_size;

#ifdef USE_MARK_OFFSET
  if (dv->mark_offset != offset) return 1;
#endif
  if (dv->marked_base != dv->base_addr - offset) return 1;

  return 0;
}


/**
 * Returns the type of hidden descriptors used by the compiler
 *
 * @return       hidden descriptor type
 */
F90_HiddenDescType hiddenArrayDescType_Intel_7(F90_DescType desc_type)
{
  return F90_NoHidden;
}


/**
 * Returns the symbol name of a module procedure, if the module name
 * is not null, otherwise returns the name of the procedure.
 *
 * Note: static memory is used for the return value so it must be
 * copied if retained because the memory is overwritten at each call.
 *
 * @param fun_name   the name of the procedure
 * @param mod_name   the module name (NULL if a global procedure)
 * @return           symbol name
 */
char* getMangledName_Intel_7(const char* fun_name, const char* mod_name)
{   
  int i;
  static char name[512];
  size_t funsize, modsize, namesize;

  if (fun_name == NULL) return NULL;

  funsize = strlen(fun_name);
  if (mod_name == NULL) {
    modsize = 0L;
    namesize = funsize + 1;
  } else {
    modsize = strlen(mod_name);
    namesize = modsize + 2 + funsize + 1;
  }

  if (namesize > 511) return NULL;

  if (modsize > 0L) {
    strcpy(name, mod_name);
    strcpy(name + modsize, "..");
    strcpy(name + modsize + 2, fun_name);
    strcpy(name + modsize + 2 + funsize, "_");
    /* lower case -> fun_name and mod_name */
    for (i = 0; i < modsize; i++) {
      if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
    }
    for (i = modsize + 2; i < namesize; i++) {
      if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
    }
  } else {
    strcpy(name, fun_name);
    strcpy(name + funsize, "_");
    /* lower case -> fun_name */
    for (i = 0; i < funsize; i++) {
      if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
    }
  }

  return name;
}


/**
 * Prints all fields in the array descriptor.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       0 if successful (nonzero on error)
 */
int printArrayDesc_Intel_7(const void* desc, int rank)
{
  int i;
  dope_vec *dv = (dope_vec*) desc;

  printf("Intel_7 array descriptor:\n");
  printf("  base_addr   = %p\n" , (void*) dv->base_addr);
  printf("  marked_base = %p\n" , (void*) dv->marked_base);
#ifdef USE_MARK_OFFSET
  printf("  mark_offset = %ld\n"  , (void*) dv->mark_offset);
#endif
  printf("  size        = %ld\n"  , dv->size);
  printf("  elem_size   = %ld\n"  , dv->elem_size);
  printf("  elem_size_2 = %ld\n"  , dv->elem_size_2);

  printf("  rank        = %ld\n"   , dv->rank);
  printf("  non_contig  = %ld\n"   , dv->non_contig);
  printf("  not_pointer = %ld\n"   , dv->not_pointer);

  printf("  unknown_1   = %ld\n"   , dv->unknown_1);

  if (rank == 0) return 0;

  for (i = 0; i < dv->rank; i++) {
    printf("    dim[%d] = LB:%ld, UB:%ld, SM:%ld\n", i, dv->dim[i].lower_bound,
           dv->dim[i].upper_bound, dv->dim[i].stride_mult);
  }
  return 0;
}


/**
 * Determines if two descriptors are equal (equivalent).
 *
 * WARNING, this function is deprecated.
 *
 * @param desc1   first descriptor
 * @param desc2   second descriptor
 * @param rank    the rank of the array
 * @return        1 if equal, 0 otherwise
 */
int equalsArrayDesc_Intel_7(const void* desc1, const void* desc2, int rank)
{
  int i;
  dope_vec* dv1 = (dope_vec*) desc1;
  dope_vec* dv2 = (dope_vec*) desc2;

  if (dv1->marked_base != dv2->marked_base)	return 0;

  if (rank == 0) return 1;

#ifdef USE_MARK_OFFSET
  if (dv1->mark_offset != dv2->mark_offset)	return 0;
#endif
  if (dv1->base_addr   != dv2->base_addr)	return 0;

  if (dv1->size        != dv2->size)		return 0;
  if (dv1->elem_size   != dv2->elem_size)	return 0;
  if (dv1->elem_size_2 != dv2->elem_size_2)	return 0;

  if (dv1->rank        != dv2->rank)		return 0;
  if (dv1->non_contig  != dv2->non_contig)	return 0;
  if (dv1->unknown_1   != dv2->unknown_1)	return 0;
  if (dv1->not_pointer != dv2->not_pointer)	return 0;

  for (i = 0; i < dv1->rank; i++) {
    if (dv1->dim[i].lower_bound != dv2->dim[i].lower_bound)  return 0;
    if (dv1->dim[i].upper_bound != dv2->dim[i].upper_bound)  return 0;
    if (dv1->dim[i].stride_mult != dv2->dim[i].stride_mult)  return 0;
  }
  return 1;
}


#ifdef __cplusplus
}
#endif
