/**
 * This information inferred from a dump of a set of array descriptors.
 */


/* dope_vec_Lahey: the F90 array descriptor for the Lahey compiler */

typedef struct dope_vec_Lahey_ {
  void*   base_addr;		  /* base address of the array		*/
  int     alloc_size;		  /* size ?	*/
  int     size;			  /* size of the array (in elements)	*/

  struct {
    int lower_bound;  /* first array index for a given dimension	*/
    int upper_bound;  /* last array index for a given dimension		*/
    int stride_mult;  /* distance between successive elements (bytes)   */
    int extent;       /* number of elements for a given dimension	*/
  } dim[7];
} dope_vec_Lahey;


/**
 * dope_vec_hidden_Lahey: hidden form of array descriptor.  This form is
 * passed at the end of the formal argument list for arrays that are NOT
 * passed by pointer.  The address of the array is passed in the normal
 * formal parameter slot.
 */
typedef struct dope_vec_hidden_Lahey_ {
  struct {
    int extent;       /* number of elements for a given dimension	*/
    int stride_mult;  /* distance between successive elements (bytes)   */
  } dim[7];
} dope_vec_hidden_Lahey;

