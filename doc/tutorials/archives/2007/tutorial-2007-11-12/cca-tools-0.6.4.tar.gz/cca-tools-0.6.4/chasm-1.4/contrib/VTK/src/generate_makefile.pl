#!/usr/bin/perl

#
# Set some paths
#
$pdt_root = "/usr/local/pdtoolkit";
$xmlgen_root = "/usr/local/pdtoolkit";
$xsl_root = "xsl";
$xalan = "org.apache.xalan.xslt.Process";
$xalan_root = "/usr/local/xalan";
$vtk_root = "/Users/tomb/Projects/vtk";

#
# Specify all the vtk header locations
#
$includes = " -I".$vtk_root."/Graphics/Testing/Cxx ";
$includes .= " -I".$vtk_root."/Rendering";
$includes .= " -I".$vtk_root."/IO";
$includes .= " -I".$vtk_root."/Imaging";
$includes .= " -I".$vtk_root."/Graphics";
$includes .= " -I".$vtk_root."/Filtering";
$includes .= " -I".$vtk_root."/Common";
$includes .= " -I".$vtk_root."/Common/Testing/Cxx";
$includes .= " -I".$vtk_root."/Utilities/zlib";
$includes .= " -I".$vtk_root."/Utilities/jpeg";
$includes .= " -I".$vtk_root."/Utilities/png";
$includes .= " -I".$vtk_root."/Utilities/tiff";
$includes .= " -I".$vtk_root."/Utilities/expat";
$includes .= " -I".$vtk_root."/Utilities/freetype/include";
$includes .= " -I".$vtk_root."/Utilities/freetype";
$includes .= " -I".$vtk_root."/Utilities/ftgl/src";
$includes .= " -I".$vtk_root."/Utilities/ftgl";
$includes .= " -I".$vtk_root."/usr/X11R6/include";
$includes .= " -I".$vtk_root."/";


#
# Open the new makefile file
#
open( MAKEFILE, ">makefile" );

#
# Copy the makefile header into the new makefile
#
open( MAKEFILEHEADER, "makefile.header" );
while( <MAKEFILEHEADER> )
   {
   my($line) = $_;
   print MAKEFILE $line;
   }
close( MAKEFILEHEADER );

#
# Generate the batch compilation lines
#
open( HEADERFILE, "headers.txt" );
print MAKEFILE "fortrantypes: ";
while( <HEADERFILE> )
   {
   my($line) = $_;
   
   if( substr( $line, 0, 1 ) ne "#" )
      {
      # Get the next header name
      $filename = "$line";
      chop $filename;
      my( $justfilename ) = $filename =~ m{([^/]+)$};
           
      # Generate the fortran types compilation commands
      print MAKEFILE $justfilename."_Ftype.o ";
      }
   }
close( HEADERFILE );
print MAKEFILE "\n\n";

open( HEADERFILE, "headers.txt" );
print MAKEFILE "fortranwrappers: ";
while( <HEADERFILE> )
   {
   my($line) = $_;
   
   if( substr( $line, 0, 1 ) ne "#" )
      {
      # Get the next header name
      $filename = "$line";
      chop $filename;
      my( $justfilename ) = $filename =~ m{([^/]+)$};
           
      # Generate the fortran types compilation commands
      print MAKEFILE $justfilename."_F.o ";
      }
   }
close( HEADERFILE );
print MAKEFILE "\n\n";

open( HEADERFILE, "headers.txt" );
print MAKEFILE "cwrappers: ";
while( <HEADERFILE> )
   {
   my($line) = $_;
   
   if( substr( $line, 0, 1 ) ne "#" )
      {
      # Get the next header name
      $filename = "$line";
      chop $filename;
      my( $justfilename ) = $filename =~ m{([^/]+)$};
           
      # Generate the fortran types compilation commands
      print MAKEFILE $justfilename."_C.o ";
      }
   }
close( HEADERFILE );
print MAKEFILE "\n\n";

#
# Generate the compilation commands for each of the source files
#
open( HEADERFILE, "headers.txt" );
while( <HEADERFILE> )
   {
   my($line) = $_;
   
   if( substr( $line, 0, 1 ) ne "#" )
      {
      # Get the next header name
      $filename = "$line";
      chop $filename;
      my( $justfilename ) = $filename =~ m{([^/]+)$};
           
      # Generate the C wrapper compilation commands
      print MAKEFILE $justfilename."_C.o: ".$justfilename."_C.cxx\n";
      print MAKEFILE "\t c++ -c -g \$(INCS) ".$justfilename."_C.cxx\n";

      # Generate the fortran wrapper compilation commands
      print MAKEFILE $justfilename."_F.o: ".$justfilename."_F.f90\n";
      print MAKEFILE "\t f90 -c -g ".$justfilename."_F.f90\n";

      # Generate the fortran types compilation commands
      print MAKEFILE $justfilename."_Ftype.o: ".$justfilename."_Ftype.f90\n";
      print MAKEFILE "\t f90 -c -g ".$justfilename."_Ftype.f90\n";

      print MAKEFILE "\n";
      }
   }
close( HEADERFILE );
