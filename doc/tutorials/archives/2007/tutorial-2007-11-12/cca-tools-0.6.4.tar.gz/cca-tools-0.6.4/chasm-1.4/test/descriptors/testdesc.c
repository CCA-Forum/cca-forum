#include <CompilerCharacteristics.h>
#include <F90Compiler.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Particle {
  double position[3];
  double velocity[3];
  double mass;
  char char_element;
} Particle;

#ifdef F90_ABSOFT
#  include <compilers/Absoft_dv.h>
#  define dope_vec dope_vec_Absoft
#  define dope_vec_hidden dope_vec
#  ifdef CHASM_ARCH_LINUX
#    define PARTICLE_ALIGN_DOUBLE_SIZE
#  endif
#endif

#ifdef F90_ALPHA
#  include <compilers/Alpha_dv.h>
#  define dope_vec dope_vec_Alpha
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_CRAY
#  include <compilers/Cray_dv.h>
#  define dope_vec dope_vec_Cray
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_GNU
#  include <compilers/GNU_dv.h>
#  define dope_vec dope_vec_GNU
#  define dope_vec_hidden dope_vec
#  define PARTICLE_MIN_ALIGNED_SIZE
#  define ALL_LBOUND_ONE
#endif

#ifdef F90_G95
#  include <compilers/G95_dv.h>
#  define dope_vec dope_vec_G95
#  define dope_vec_hidden dope_vec
#  define PARTICLE_MIN_ALIGNED_SIZE
#endif

#ifdef F90_IBMXL
#  include <compilers/IBMXL_dv.h>
#  define dope_vec dope_vec_IBMXL
#  define dope_vec_hidden dope_vec_hidden_IBMXL
#endif

#ifdef F90_INTEL
#  include <compilers/Intel_dv.h>
#  define dope_vec dope_vec_Intel
#  define dope_vec_hidden dope_vec
#  define PARTICLE_ALIGN_DOUBLE_SIZE
#endif

#ifdef F90_INTEL_7
#  include <compilers/Intel_7_dv.h>
#  define dope_vec dope_vec_Intel_7
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_LAHEY
#  include <compilers/Lahey_dv.h>
#  define dope_vec dope_vec_Lahey
#  define desc_or_hidden hidden
#  undef dope_vec_hidden
#  define dope_vec_hidden dope_vec_hidden_Lahey
#  define USE_HIDDEN
#  define PARTICLE_ALIGN_DOUBLE_SIZE
#endif

#ifdef F90_MIPSPRO
#  include <compilers/MIPSpro_dv.h>
#  define dope_vec dope_vec_MIPSpro
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_NAG
#  include <compilers/NAG_dv.h>
#  define dope_vec dope_vec_NAG
#  define dope_vec_hidden dope_vec
#endif

#ifdef F90_PGI
#  include <compilers/PGI_dv.h>
#  define dope_vec dope_vec1d_PGI
#  define dope_vec_hidden dope_vec
#  define PARTICLE_ALIGN_DOUBLE_SIZE
#endif

#ifdef F90_SUNWSPRO
#  include <compilers/SUNWspro_dv.h>
#  define dope_vec dope_vec1d_SUNWspro
#  define dope_vec_hidden dope_vec
#endif


#if defined(F90_SYM_CASE_LOWER) || defined(F90_SYM_CASE_MIXED)
#  define print_iaddr F90_SYMBOL_COND( print_iaddr )
#  define print_raddr F90_SYMBOL_COND( print_raddr )
#  define print_daddr F90_SYMBOL_COND( print_daddr )
#  define print_i1a F90_SYMBOL_COND( print_i1a )
#  define print_i2a F90_SYMBOL_COND( print_i2a )
#  define print_i8a F90_SYMBOL_COND( print_i8a )
#  define print_ia  F90_SYMBOL_COND( print_ia )
#  define print_ra  F90_SYMBOL_COND( print_ra )
#  define print_da  F90_SYMBOL_COND( print_da )
#  define print_sizeofs F90_SYMBOL_COND( print_sizeofs )
#  define c_sizeof F90_SYMBOL_COND( c_sizeof )

#  define send_i1a1d_print F90_SYMBOL_COND( send_i1a1d_print )
#  define send_i2a1d_print F90_SYMBOL_COND( send_i2a1d_print )
#  define send_i4a1d_print F90_SYMBOL_COND( send_i4a1d_print )
#  define send_i8a1d_print F90_SYMBOL_COND( send_i8a1d_print )

#  define send_iia1d_null  F90_SYMBOL_COND( send_iia1d_null )

#  define send_iia0d F90_SYMBOL_COND( send_iia0d )
#  define send_iia1d F90_SYMBOL_COND( send_iia1d )
#  define send_iia2d F90_SYMBOL_COND( send_iia2d )
#  define send_iia3d F90_SYMBOL_COND( send_iia3d )
#  define send_iia4d F90_SYMBOL_COND( send_iia4d )
#  define send_iia5d F90_SYMBOL_COND( send_iia5d )
#  define send_iia6d F90_SYMBOL_COND( send_iia6d )
#  define send_iia7d F90_SYMBOL_COND( send_iia7d )

#  define send_lla0d F90_SYMBOL_COND( send_lla0d )
#  define send_l1a0d F90_SYMBOL_COND( send_l1a0d )
#  define send_l2a0d F90_SYMBOL_COND( send_l2a0d )
#  define send_l4a0d F90_SYMBOL_COND( send_l4a0d )
#  define send_l8a0d F90_SYMBOL_COND( send_l8a0d )
#  define send_i1a0d F90_SYMBOL_COND( send_i1a0d )
#  define send_i2a0d F90_SYMBOL_COND( send_i2a0d )
#  define send_i4a0d F90_SYMBOL_COND( send_i4a0d )
#  define send_i8a0d F90_SYMBOL_COND( send_i8a0d )
#  define send_lla1d F90_SYMBOL_COND( send_lla1d )
#  define send_l1a1d F90_SYMBOL_COND( send_l1a1d )
#  define send_l2a1d F90_SYMBOL_COND( send_l2a1d )
#  define send_l4a1d F90_SYMBOL_COND( send_l4a1d )
#  define send_l8a1d F90_SYMBOL_COND( send_l8a1d )
#  define send_i1a1d F90_SYMBOL_COND( send_i1a1d )
#  define send_i2a1d F90_SYMBOL_COND( send_i2a1d )
#  define send_i4a1d F90_SYMBOL_COND( send_i4a1d )
#  define send_i8a1d F90_SYMBOL_COND( send_i8a1d )
#  define send_rra1d F90_SYMBOL_COND( send_rra1d )
#  define send_dda1d F90_SYMBOL_COND( send_dda1d )
#  define send_ca0d  F90_SYMBOL_COND( send_ca0d )
#  define send_ca1d  F90_SYMBOL_COND( send_ca1d )
#  define send_dca0d F90_SYMBOL_COND( send_dca0d )
#  define send_dca1d F90_SYMBOL_COND( send_dca1d )
#  define send_ua0d  F90_SYMBOL_COND( send_ua0d )
#  define send_ua1d  F90_SYMBOL_COND( send_ua1d )
#  define send_upa1d F90_SYMBOL_COND( send_upa1d )

#  define recv_iia1d_null F90_SYMBOL_COND( recv_iia1d_null )

#  define recv_iia0d F90_SYMBOL_COND( recv_iia0d )
#  define recv_iia1d F90_SYMBOL_COND( recv_iia1d )
#  define recv_iia2d F90_SYMBOL_COND( recv_iia2d )
#  define recv_iia3d F90_SYMBOL_COND( recv_iia3d )
#  define recv_iia4d F90_SYMBOL_COND( recv_iia4d )
#  define recv_iia5d F90_SYMBOL_COND( recv_iia5d )
#  define recv_iia6d F90_SYMBOL_COND( recv_iia6d )
#  define recv_iia7d F90_SYMBOL_COND( recv_iia7d )

#  define recv_lla0d F90_SYMBOL_COND( recv_lla0d )
#  define recv_l1a0d F90_SYMBOL_COND( recv_l1a0d )
#  define recv_l2a0d F90_SYMBOL_COND( recv_l2a0d )
#  define recv_l4a0d F90_SYMBOL_COND( recv_l4a0d )
#  define recv_l8a0d F90_SYMBOL_COND( recv_l8a0d )
#  define recv_i1a0d F90_SYMBOL_COND( recv_i1a0d )
#  define recv_i2a0d F90_SYMBOL_COND( recv_i2a0d )
#  define recv_i4a0d F90_SYMBOL_COND( recv_i4a0d )
#  define recv_i8a0d F90_SYMBOL_COND( recv_i8a0d )
#  define recv_lla1d F90_SYMBOL_COND( recv_lla1d )
#  define recv_l1a1d F90_SYMBOL_COND( recv_l1a1d )
#  define recv_l2a1d F90_SYMBOL_COND( recv_l2a1d )
#  define recv_l4a1d F90_SYMBOL_COND( recv_l4a1d )
#  define recv_l8a1d F90_SYMBOL_COND( recv_l8a1d )
#  define recv_i1a1d F90_SYMBOL_COND( recv_i1a1d )
#  define recv_i2a1d F90_SYMBOL_COND( recv_i2a1d )
#  define recv_i4a1d F90_SYMBOL_COND( recv_i4a1d )
#  define recv_i8a1d F90_SYMBOL_COND( recv_i8a1d )
#  define recv_rra1d F90_SYMBOL_COND( recv_rra1d )
#  define recv_dda1d F90_SYMBOL_COND( recv_dda1d )

#  define send_ia1d F90_SYMBOL_COND( send_ia1d )
#  define recv_ia1d F90_SYMBOL_COND( recv_ia1d )
#  define send_ia2d F90_SYMBOL_COND( send_ia2d )
#  define recv_ia2d F90_SYMBOL_COND( recv_ia2d )
#  define send_ia3d F90_SYMBOL_COND( send_ia3d )
#  define recv_ia3d F90_SYMBOL_COND( recv_ia3d )
#  define send_ia3d_s F90_SYMBOL_COND( send_ia3d_s )
#  define recv_ia3d_s F90_SYMBOL_COND( recv_ia3d_s )
#  define send_ia3d_p F90_SYMBOL_COND( send_ia3d_p )
#  define send_ia3d_dp F90_SYMBOL_COND( send_ia3d_dp )
#  define recv_ia3d_p F90_SYMBOL_COND( recv_ia3d_p )
#  define recv_ia3d_dp F90_SYMBOL_COND( recv_ia3d_dp )
#  define send_ra0d F90_SYMBOL_COND( send_ra0d )
#  define recv_ra0d F90_SYMBOL_COND( recv_ra0d )
#  define send_ra1d F90_SYMBOL_COND( send_ra1d )
#  define recv_ra1d F90_SYMBOL_COND( recv_ra1d )
#  define send_ra2d F90_SYMBOL_COND( send_ra2d )
#  define recv_ra2d F90_SYMBOL_COND( recv_ra2d )
#  define send_ra3d F90_SYMBOL_COND( send_ra3d )
#  define recv_ra3d F90_SYMBOL_COND( recv_ra3d )
#  define send_da0d F90_SYMBOL_COND( send_da0d )
#  define recv_da0d F90_SYMBOL_COND( recv_da0d )
#  define send_da1d F90_SYMBOL_COND( send_da1d )
#  define recv_da1d F90_SYMBOL_COND( recv_da1d )
#  define recv_ca0d F90_SYMBOL_COND( recv_ca0d )
#  define recv_ca1d F90_SYMBOL_COND( recv_ca1d )
#  define recv_dca0d F90_SYMBOL_COND( recv_dca0d )
#  define recv_dca1d F90_SYMBOL_COND( recv_dca1d )
#  define recv_ua0d  F90_SYMBOL_COND( recv_ua0d )
#  define recv_ua1d  F90_SYMBOL_COND( recv_ua1d )
#  define recv_upa1d F90_SYMBOL_COND( recv_upa1d )
#endif /* F90_SYM_CASE_LOWER || F90_SYM_CASE_MIXED */

#ifdef F90_SYM_CASE_UPPER
#  define print_iaddr F90_SYMBOL_COND( PRINT_IADDR )
#  define print_raddr F90_SYMBOL_COND( PRINT_RADDR )
#  define print_daddr F90_SYMBOL_COND( PRINT_DADDR )
#  define print_i1a F90_SYMBOL_COND( PRINT_I1A )
#  define print_i2a F90_SYMBOL_COND( PRINT_I2A )
#  define print_i8a F90_SYMBOL_COND( PRINT_I8A )
#  define print_ia  F90_SYMBOL_COND( PRINT_IA )
#  define print_ra  F90_SYMBOL_COND( PRINT_RA )
#  define print_da  F90_SYMBOL_COND( PRINT_DA )
#  define print_sizeofs F90_SYMBOL_COND( PRINT_SIZEOFS )
#  define c_sizeof F90_SYMBOL_COND( C_SIZEOF )

#  define send_i1a1d_print F90_SYMBOL_COND( SEND_I1A1D_PRINT )
#  define send_i2a1d_print F90_SYMBOL_COND( SEND_I2A1D_PRINT )
#  define send_i4a1d_print F90_SYMBOL_COND( SEND_I4A1D_PRINT )
#  define send_i8a1d_print F90_SYMBOL_COND( SEND_I8A1D_PRINT )

#  define send_iia1d_null  F90_SYMBOL_COND( SEND_IIA1D_NULL )

#  define send_iia0d F90_SYMBOL_COND( SEND_IIA0D )
#  define send_iia1d F90_SYMBOL_COND( SEND_IIA1D )
#  define send_iia2d F90_SYMBOL_COND( SEND_IIA2D )
#  define send_iia3d F90_SYMBOL_COND( SEND_IIA3D )
#  define send_iia4d F90_SYMBOL_COND( SEND_IIA4D )
#  define send_iia5d F90_SYMBOL_COND( SEND_IIA5D )
#  define send_iia6d F90_SYMBOL_COND( SEND_IIA6D )
#  define send_iia7d F90_SYMBOL_COND( SEND_IIA7D )

#  define send_lla0d F90_SYMBOL_COND( SEND_LLA0D )
#  define send_l1a0d F90_SYMBOL_COND( SEND_L1A0D )
#  define send_l2a0d F90_SYMBOL_COND( SEND_L2A0D )
#  define send_l4a0d F90_SYMBOL_COND( SEND_L4A0D )
#  define send_l8a0d F90_SYMBOL_COND( SEND_L8A0D )
#  define send_i1a0d F90_SYMBOL_COND( SEND_I1A0D )
#  define send_i2a0d F90_SYMBOL_COND( SEND_I2A0D )
#  define send_i4a0d F90_SYMBOL_COND( SEND_I4A0D )
#  define send_i8a0d F90_SYMBOL_COND( SEND_I8A0D )
#  define send_lla1d F90_SYMBOL_COND( SEND_LLA1D )
#  define send_l1a1d F90_SYMBOL_COND( SEND_L1A1D )
#  define send_l2a1d F90_SYMBOL_COND( SEND_L2A1D )
#  define send_l4a1d F90_SYMBOL_COND( SEND_L4A1D )
#  define send_l8a1d F90_SYMBOL_COND( SEND_L8A1D )
#  define send_i1a1d F90_SYMBOL_COND( SEND_I1A1D )
#  define send_i2a1d F90_SYMBOL_COND( SEND_I2A1D )
#  define send_i4a1d F90_SYMBOL_COND( SEND_I4A1D )
#  define send_i8a1d F90_SYMBOL_COND( SEND_I8A1D )
#  define send_rra1d F90_SYMBOL_COND( SEND_RRA1D )
#  define send_dda1d F90_SYMBOL_COND( SEND_DDA1D )
#  define send_ca0d  F90_SYMBOL_COND( SEND_CA0D )
#  define send_ca1d  F90_SYMBOL_COND( SEND_CA1D )
#  define send_dca0d F90_SYMBOL_COND( SEND_DCA0D )
#  define send_dca1d F90_SYMBOL_COND( SEND_DCA1D )
#  define send_ua0d  F90_SYMBOL_COND( SEND_UA0D )
#  define send_ua1d  F90_SYMBOL_COND( SEND_UA1D )
#  define send_upa1d F90_SYMBOL_COND( SEND_UPA1D )

#  define recv_iia1d_null F90_SYMBOL_COND( RECV_IIA1D_NULL )

#  define recv_iia0d F90_SYMBOL_COND( RECV_IIA0D )
#  define recv_iia1d F90_SYMBOL_COND( RECV_IIA1D )
#  define recv_iia2d F90_SYMBOL_COND( RECV_IIA2D )
#  define recv_iia3d F90_SYMBOL_COND( RECV_IIA3D )
#  define recv_iia4d F90_SYMBOL_COND( RECV_IIA4D )
#  define recv_iia5d F90_SYMBOL_COND( RECV_IIA5D )
#  define recv_iia6d F90_SYMBOL_COND( RECV_IIA6D )
#  define recv_iia7d F90_SYMBOL_COND( RECV_IIA7D )

#  define recv_lla0d F90_SYMBOL_COND( RECV_LLA0D )
#  define recv_l1a0d F90_SYMBOL_COND( RECV_L1A0D )
#  define recv_l2a0d F90_SYMBOL_COND( RECV_L2A0D )
#  define recv_l4a0d F90_SYMBOL_COND( RECV_L4A0D )
#  define recv_l8a0d F90_SYMBOL_COND( RECV_L8A0D )
#  define recv_i1a0d F90_SYMBOL_COND( RECV_I1A0D )
#  define recv_i2a0d F90_SYMBOL_COND( RECV_I2A0D )
#  define recv_i4a0d F90_SYMBOL_COND( RECV_I4A0D )
#  define recv_i8a0d F90_SYMBOL_COND( RECV_I8A0D )
#  define recv_lla1d F90_SYMBOL_COND( RECV_LLA1D )
#  define recv_l1a1d F90_SYMBOL_COND( RECV_L1A1D )
#  define recv_l2a1d F90_SYMBOL_COND( RECV_L2A1D )
#  define recv_l4a1d F90_SYMBOL_COND( RECV_L4A1D )
#  define recv_l8a1d F90_SYMBOL_COND( RECV_L8A1D )
#  define recv_i1a1d F90_SYMBOL_COND( RECV_I1A1D )
#  define recv_i2a1d F90_SYMBOL_COND( RECV_I2A1D )
#  define recv_i4a1d F90_SYMBOL_COND( RECV_I4A1D )
#  define recv_i8a1d F90_SYMBOL_COND( RECV_I8A1D )
#  define recv_rra1d F90_SYMBOL_COND( RECV_RRA1D )
#  define recv_dda1d F90_SYMBOL_COND( RECV_DDA1D )

#  define send_ia1d F90_SYMBOL_COND( SEND_IA1D )
#  define recv_ia1d F90_SYMBOL_COND( RECV_IA1D )
#  define send_ia2d F90_SYMBOL_COND( SEND_IA2D )
#  define recv_ia2d F90_SYMBOL_COND( RECV_IA2D )
#  define send_ia3d F90_SYMBOL_COND( SEND_IA3D )
#  define recv_ia3d F90_SYMBOL_COND( RECV_IA3D )
#  define send_ia3d_s F90_SYMBOL_COND( SEND_IA3D_S )
#  define recv_ia3d_s F90_SYMBOL_COND( RECV_IA3D_S )
#  define send_ia3d_p F90_SYMBOL_COND( SEND_IA3D_P )
#  define send_ia3d_dp F90_SYMBOL_COND( SEND_IA3D_DP )
#  define recv_ia3d_p F90_SYMBOL_COND( RECV_IA3D_P )
#  define recv_ia3d_dp F90_SYMBOL_COND( RECV_IA3D_DP )
#  define send_ra0d F90_SYMBOL_COND( SEND_RA0D )
#  define recv_ra0d F90_SYMBOL_COND( RECV_RA0D )
#  define send_ra1d F90_SYMBOL_COND( SEND_RA1D )
#  define recv_ra1d F90_SYMBOL_COND( RECV_RA1D )
#  define send_ra2d F90_SYMBOL_COND( SEND_RA2D )
#  define recv_ra2d F90_SYMBOL_COND( RECV_RA2D )
#  define send_ra3d F90_SYMBOL_COND( SEND_RA3D )
#  define recv_ra3d F90_SYMBOL_COND( RECV_RA3D )
#  define send_da0d F90_SYMBOL_COND( SEND_DA0D )
#  define recv_da0d F90_SYMBOL_COND( RECV_DA0D )
#  define send_da1d F90_SYMBOL_COND( SEND_DA1D )
#  define recv_da1d F90_SYMBOL_COND( RECV_DA1D )
#  define recv_ca0d F90_SYMBOL_COND( RECV_CA0D )
#  define recv_ca1d F90_SYMBOL_COND( RECV_CA1D )
#  define recv_dca0d F90_SYMBOL_COND( RECV_DCA0D )
#  define recv_dca1d F90_SYMBOL_COND( RECV_DCA1D )
#  define recv_ua0d  F90_SYMBOL_COND( RECV_UA0D )
#  define recv_ua1d  F90_SYMBOL_COND( RECV_UA1D )
#  define recv_upa1d F90_SYMBOL_COND( RECV_UPA1D )
#endif /* F90_SYM_CASE_UPPER */

dope_vec* dv_la0d;
dope_vec* dv_la1d;
dope_vec* dv_ia0d;
dope_vec* dv_ia1d;
dope_vec* dv_ia2d;
dope_vec* dv_ia3d;
dope_vec* dv_ia3d_s;
dope_vec* dv_ia3d_p;
dope_vec* dv_ra0d;
dope_vec* dv_ra1d;
dope_vec* dv_ra2d;
dope_vec* dv_ra3d;
dope_vec* dv_da0d;
dope_vec* dv_da1d;
dope_vec* dv_ca0d;
dope_vec* dv_ca1d;
dope_vec* dv_dca0d;
dope_vec* dv_dca1d;
dope_vec* dv_ua0d;
dope_vec* dv_ua1d;
dope_vec* dv_upa1d;

dope_vec_hidden* vdv_la0d;
dope_vec_hidden* vdv_la1d;
dope_vec_hidden* vdv_ia0d;
dope_vec_hidden* vdv_ia1d;
dope_vec_hidden* vdv_ia2d;
dope_vec_hidden* vdv_ia3d;
dope_vec_hidden* vdv_ia3d_s;
dope_vec_hidden* vdv_ia3d_p;
dope_vec_hidden* vdv_ra0d;
dope_vec_hidden* vdv_ra1d;
dope_vec_hidden* vdv_ra2d;
dope_vec_hidden* vdv_ra3d;
dope_vec_hidden* vdv_da0d;
dope_vec_hidden* vdv_da1d;
dope_vec_hidden* vdv_ca0d;
dope_vec_hidden* vdv_ca1d;
dope_vec_hidden* vdv_dca0d;
dope_vec_hidden* vdv_dca1d;
dope_vec_hidden* vdv_ua0d;
dope_vec_hidden* vdv_ua1d;
dope_vec_hidden* vdv_upa1d;

dope_vec* dv_iia1d;
dope_vec* dv_iia2d;
dope_vec* dv_iia3d;
dope_vec* dv_iia4d;
dope_vec* dv_iia5d;
dope_vec* dv_iia6d;
dope_vec* dv_iia7d;

dope_vec_hidden* vdv_iia1d;
dope_vec_hidden* vdv_iia2d;
dope_vec_hidden* vdv_iia3d;
dope_vec_hidden* vdv_iia4d;
dope_vec_hidden* vdv_iia5d;
dope_vec_hidden* vdv_iia6d;
dope_vec_hidden* vdv_iia7d;

void send_iia1d_null();

void send_iia0d();
void send_iia1d();
void send_iia2d();
void send_iia3d();
void send_iia4d();
void send_iia5d();
void send_iia6d();
void send_iia7d();

void send_lla0d();
void send_l1a0d();
void send_l2a0d();
void send_l4a0d();
void send_l8a0d();
void send_i1a0d();
void send_i2a0d();
void send_i4a0d();
void send_i8a0d();
void send_lla1d();
void send_l1a1d();
void send_l2a1d();
void send_l4a1d();
void send_l8a1d();
void send_i1a1d();
void send_i2a1d();
void send_i4a1d();
void send_i8a1d();
void send_rra1d();
void send_dda1d();
void send_ca0d();
void send_ca1d();
void send_dca0d();
void send_dca1d();
void send_ua0d();
void send_ua1d();
void send_upa1d();

void send_ia1d(int*, int*);
void send_ia2d(int*, int*, int*);
void send_ia3d(int*, int*, int*, int*);
void send_ia3d_s(int*, int*);
void send_ia3d_p(int*, int*);
void send_ia3d_dp(int*, int*);
void send_ra0d();
void send_ra1d(int*, int*);
void send_ra2d(int*, int*);
void send_ra3d(int*, int*);
void send_da0d();
void send_da1d(int*, int*);

void send_ia1d_print(int*, int*);

void send_i1a1d_print(int*, int*);
void send_i2a1d_print(int*, int*);
void send_i4a1d_print(int*, int*);
void send_i8a1d_print(int*, int*);

void print_iia1d_null();
void print_ia1d();
void print_ia2d();
void print_ia3d();
void print_sizeofs();
void printRaw();
void printDesc();
int  testDesc();
int  testSetDesc();
void printRawDesc(void* desc, int rank);

F90_CompilerCharacteristics cc;


int F90_MAIN(int argc, char* argv[])
{
  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  if (argc < 2) {
    printf("Usage: testdesc [-b | -d | -i1 | -i2 | -i3 | -t]\n"
           "          -b (prints binary)\n"
           "          -d (prints descriptor elements)\n"
           "          -i1 (prints integer 1d arrays)\n"
           "          -i2 (prints integer 2d arrays)\n"
           "          -n (prints integer 1d null arrays)\n"
           "          -t (test descriptor creation)\n"
	   );
  } else {
    int i;
    for(i = 1; i < argc; i++) {
      if      ( strcmp(argv[i], "-b") == 0 ) printRaw();
      else if ( strcmp(argv[i], "-d") == 0 ) printDesc();
      else if ( strcmp(argv[i], "-i1") == 0 ) print_ia1d();
      else if ( strcmp(argv[i], "-i2") == 0 ) print_ia2d();
      else if ( strcmp(argv[i], "-i3") == 0 ) print_ia3d();
      else if ( strcmp(argv[i], "-n") == 0 ) print_iia1d_null();
      else if ( strcmp(argv[i], "-t") == 0 ) {
	if ( testDesc() ) return 1;
	if ( testSetDesc() ) return 1;
      }
    }
  }
  return 0;
}


void print_iia1d_null()
{
  printf("\nPrinting I1D NULL\n");
  send_iia1d();
  printRawDesc(dv_iia1d, 1);
  printf("\n");
  send_iia1d_null();
  printRawDesc(dv_iia1d, 1);
}


void print_ia1d()
{
  char* a1;
  short* a2;
  int* a4;
  int i, ii;
  int code = 1;

  printf("\nPrinting i1ad\n");
  send_i1a1d();
  a1 = cc.getArrayBaseAddress(dv_ia1d, 1);
  for (i = 0; i < 5; i++) printf("  ia[%d] = %d\n", i, a1[i]);
  printRawDesc(dv_ia1d, 1);

  printf("\nPrinting i2ad\n");
  send_i2a1d();
  a2 = cc.getArrayBaseAddress(dv_ia1d, 1);
  for (i = 0; i < 5; i++) printf("  ia[%d] = %d\n", i, a2[i]);
  printRawDesc(dv_ia1d, 1);

  printf("\nPrinting i4ad\n");
  send_i4a1d();
  a4 = cc.getArrayBaseAddress(dv_ia1d, 1);
  for (i = 0; i < 5; i++) printf("  ia[%d] = %d\n", i, a4[i]);
  printRawDesc(dv_ia1d, 1);

  printf("\nPrinting i8ad\n");
  send_i8a1d();
  printRawDesc(dv_ia1d, 1);

  printf("\nPrinting I1D, ii = 3\n");
  ii = 3;
  send_ia1d(&code, &ii);
  printRawDesc(dv_ia1d, 1);

  printf("\nPrinting I1D, ii = 6\n");
  ii = 6;
  send_ia1d(&code, &ii);
  printRawDesc(dv_ia1d, 1);

  printf("\nPrinting I1D, ii = 9\n");
  ii = 9;
  send_ia1d(&code, &ii);
  printRawDesc(dv_ia1d, 1);
}


void print_ia2d()
{
  int ii, jj;
  int code = 1;

  printf("\nPrinting I2D, ii,jj = 3, 4\n");
  ii = 3;
  jj = 4;
  send_ia2d(&code, &ii, &jj);
  printRawDesc(dv_ia2d, 2);

  printf("\nPrinting I2D, ii,jj = 4, 3\n");
  ii = 4;
  jj = 3;
  send_ia2d(&code, &ii, &jj);
  printRawDesc(dv_ia2d, 2);

  printf("\nPrinting I2D, ii,jj = 5, 2\n");
  ii = 5;
  jj = 2;
  send_ia2d(&code, &ii, &jj);
  printRawDesc(dv_ia2d, 2);

  printf("\nPrinting I2D, ii,jj = 6, 1\n");
  ii = 6;
  jj = 1;
  send_ia2d(&code, &ii, &jj);
  printRawDesc(dv_ia2d, 2);
}


void print_ia3d()
{
  int ii, jj, kk;
  int code = 1;

  printf("\nPrinting I3D, ii,jj,kk = 1, 1, 1\n");
  ii = 1;
  jj = 1;
  kk = 1;
  send_ia3d(&code, &ii, &jj, &kk);
  printRawDesc(dv_ia3d, 3);

  printf("\nPrinting I3D, ii,jj,kk = 2, 1, 1\n");
  ii = 2;
  jj = 1;
  kk = 1;
  send_ia3d(&code, &ii, &jj, &kk);
  printRawDesc(dv_ia3d, 3);

  printf("\nPrinting I3D, ii,jj,kk = 1, 2, 1\n");
  ii = 1;
  jj = 2;
  kk = 1;
  send_ia3d(&code, &ii, &jj, &kk);
  printRawDesc(dv_ia3d, 3);

  printf("\nPrinting I3D, ii,jj,kk = 1, 1, 2\n");
  ii = 1;
  jj = 1;
  kk = 2;
  send_ia3d(&code, &ii, &jj, &kk);
  printRawDesc(dv_ia3d, 3);

  printf("\nPrinting I3D, ii,jj,kk = 3, 4, 5\n");
  ii = 3;
  jj = 4;
  kk = 5;
  send_ia3d(&code, &ii, &jj, &kk);
  printRawDesc(dv_ia3d, 3);

  printf("\nPrinting I3D, ii,jj,kk = 4, 3, 2\n");
  ii = 4;
  jj = 3;
  kk = 2;
  send_ia3d(&code, &ii, &jj, &kk);
  printRawDesc(dv_ia3d, 3);

  printf("\nPrinting I3D, ii,jj,kk = 5, 2, 4\n");
  ii = 5;
  jj = 2;
  kk = 4;
  send_ia3d(&code, &ii, &jj, &kk);
  printRawDesc(dv_ia3d, 3);

  printf("\nPrinting I3D, ii,jj,kk = 6, 1, 3\n");
  ii = 6;
  jj = 1;
  kk = 3;
  send_ia3d(&code, &ii, &jj, &kk);
  printRawDesc(dv_ia3d, 3);
}


void c_sizeof(int* size, char* a1, char* a2)
{
  *size = (a2 > a1) ? a2 - a1 : a1 - a2;
}


void printRaw()
{
  int code = 1;
  int count = -1;

  printf("\nPrinting sizeof basic types...\n");
  print_sizeofs();

  printf("\nPrinting I1A1D\n");
  send_i1a1d_print(&code, &count);
  printRawDesc(dv_ia1d, 1);

  printf("\nPrinting I2A1D\n");
  send_i2a1d_print(&code, &count);
  printRawDesc(dv_ia1d, 1);

  printf("\nPrinting I4A1D\n");
  send_i4a1d_print(&code, &count);
  printRawDesc(dv_ia1d, 1);

  printf("\nPrinting I8A1D\n");
  send_i8a1d_print(&code, &count);
  printRawDesc(dv_ia1d, 1);

  printf("\nPrinting I0D\n");
  send_iia0d();
  printRawDesc(dv_ia0d, 0);

  printf("\nPrinting I1D\n");
  send_ia1d(&code, &count);
  printRawDesc(dv_ia1d, 1);

  printf("\nPrinting I2D\n");
  send_ia2d(&code, &count, &count);
  printRawDesc(dv_ia2d, 2);

  printf("\nPrinting I3D, no section, a(3,4,5)\n");
  send_ia3d(&code, &count, &count, &count);
  printRawDesc(dv_ia3d, 3);

  printf("\nPrinting I3D, section, a(2:3,:,:)\n");
  send_ia3d_s(&code, &count);
  printRawDesc(dv_ia3d_s, 3);

  printf("\nPrinting I3D, pointer, a(0:2,0:3,0:4)\n");
  send_ia3d_p(&code, &count);
  printRawDesc(dv_ia3d_p, 3);

  printf("\nPrinting I3D, array pointer in derived, a(0:2,0:3,-1:3)\n");
  send_ia3d_dp(&code, &count);
  printRawDesc(dv_ia3d_p, 3);

  printf("\nPrinting R0D\n");
  send_ra0d();
  printRawDesc(dv_ra0d, 0);

  printf("\nPrinting R1D\n");
  send_ra1d(&code, &count);
  printRawDesc(dv_ra1d, 1);

  printf("\nPrinting R2D\n");
  send_ra2d(&code, &count);
  printRawDesc(dv_ra2d, 2);

  printf("\nPrinting R3D\n");
  send_ra3d(&code, &count);
  printRawDesc(dv_ra3d, 3);

  printf("\nPrinting D1D\n");
  send_da1d(&code, &count);
  printRawDesc(dv_da1d, 1);

  printf("\nPrinting ptr I1D\n");
  send_upa1d();
  printRawDesc(dv_upa1d, 1);
}


void printDesc()
{
  int code = 0;
  int count = -1;

  printf("\nPrinting I1A1D, pointer a(10)\n");
  send_i1a1d_print(&code, &count);
  cc.printArrayDesc(dv_ia1d, 1);

  printf("\nPrinting I2A1D, pointer a(10)\n");
  send_i2a1d_print(&code, &count);
  cc.printArrayDesc(dv_ia1d, 1);

  printf("\nPrinting I4A1D, pointer a(10)\n");
  send_i4a1d_print(&code, &count);
  cc.printArrayDesc(dv_ia1d, 1);

  printf("\nPrinting I8A1D, pointer a(10)\n");
  send_i8a1d_print(&code, &count);
  cc.printArrayDesc(dv_ia1d, 1);

  printf("\nPrinting I1D, a(6)\n");
  send_ia1d(&code, &count);
  cc.printArrayDesc(dv_ia1d, 1);

  printf("\nPrinting I1D, pointer in derived a(-1:9)\n");
  send_upa1d();
  cc.printArrayDesc(dv_upa1d, 1);

  printf("\nPrinting I2D a(3,4)\n");
  send_ia2d(&code, &count, &count);
  cc.printArrayDesc(dv_ia2d, 2);

  printf("\nPrinting I3D, no section, a(3,4,4)\n");
  send_ia3d(&code, &count, &count, &count);
  cc.printArrayDesc(dv_ia3d, 3);

  printf("\nPrinting I3D, section, a(2:3,:4,:5)\n");
  send_ia3d_s(&code, &count);
  cc.printArrayDesc(dv_ia3d_s, 3);

  printf("\nPrinting I3D, pointer, a(0:2,0:3,0:4)\n");
  send_ia3d_p(&code, &count);
  cc.printArrayDesc(dv_ia3d_p, 3);

  printf("\nPrinting I3D, pointer in derived, a(0:2,0:3,-1:3)\n");
  send_ia3d_dp(&code, &count);
  cc.printArrayDesc(dv_ia3d_p, 3);

  printf("\nPrinting R1D, pointer\n");
  send_rra1d();
  cc.printArrayDesc(dv_ra1d, 1);

  printf("\nPrinting R1D\n");
  send_ra1d(&code, &count);
  cc.printArrayDesc(dv_ra1d, 1);

  printf("\nPrinting R2D\n");
  send_ra2d(&code, &count);
  cc.printArrayDesc(dv_ra2d, 2);

  printf("\nPrinting R3D\n");
  send_ra3d(&code, &count);
  cc.printArrayDesc(dv_ra3d, 3);

  printf("\nPrinting D1D\n");
  send_da1d(&code, &count);
  cc.printArrayDesc(dv_da1d, 1);

  printf("\nPrinting I0D\n");
  send_iia0d();
  cc.printArrayDesc(dv_ia0d, 0);

  printf("\nPrinting R0D\n");
  send_ra0d();
  cc.printArrayDesc(dv_ra0d, 0);

  printf("\nPrinting C0D\n");
  send_ca0d();
  cc.printArrayDesc(dv_ca0d, 0);

  printf("\nPrinting U0D\n");
  send_ua0d();
  cc.printArrayDesc(dv_ua0d, 0);
}


int testDesc()
{
  dope_vec* dv;
  void* addr;
  int i, rank, rc, code, count;
  long lb[7], stride[7], calc_stride;
  unsigned long extent[7], elem_size;
  int error = 0;
  int nErrors = 0;

  /*
   * Test pointer data type (zero dimensional array)
   */

  rank = 0;

  send_lla0d();
  addr = cc.getArrayBaseAddress(dv_la0d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  rc = cc.setArrayDesc(dv, addr, rank, F90_Pointer,
		       F90_Logical, elem_size, 0, 0, 0);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for lla0d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_la0d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for lla0d\n");
  }
  free(dv);
  free(dv_la0d);
  error = nErrors;

  send_l1a0d();
  addr = cc.getArrayBaseAddress(dv_la0d, rank);
  elem_size = sizeof(unsigned char);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  rc = cc.setArrayDesc(dv, addr, rank, F90_Pointer,
		       F90_Logical1, elem_size, 0, 0, 0);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for l1a0d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_la0d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for l1a0d\n");
  }
  free(dv);
  free(dv_la0d);
  error = nErrors;

  send_l2a0d();
  addr = cc.getArrayBaseAddress(dv_la0d, rank);
  elem_size = sizeof(unsigned short);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  rc = cc.setArrayDesc(dv, addr, rank, F90_Pointer,
		       F90_Logical2, elem_size, 0, 0, 0);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for l2a0d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_la0d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for l2a0d\n");
  }
  free(dv);
  free(dv_la0d);
  error = nErrors;

  send_l4a0d();
  addr = cc.getArrayBaseAddress(dv_la0d, rank);
  elem_size = sizeof(unsigned int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  rc = cc.setArrayDesc(dv, addr, rank, F90_Pointer,
		       F90_Logical4, elem_size, 0, 0, 0);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for l4a0d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_la0d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for l4a0d\n");
  }
  free(dv);
  free(dv_la0d);
  error = nErrors;

  send_l8a0d();
  addr = cc.getArrayBaseAddress(dv_la0d, rank);
  elem_size = sizeof(unsigned long long);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  rc = cc.setArrayDesc(dv, addr, rank, F90_Pointer,
		       F90_Logical8, elem_size, 0, 0, 0);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for l8a0d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_la0d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for l8a0d\n");
  }
  free(dv);
  free(dv_la0d);
  error = nErrors;

  send_iia0d();
  addr = cc.getArrayBaseAddress(dv_ia0d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  rc = cc.setArrayDesc(dv, addr, rank,
		       F90_Pointer, F90_Integer, elem_size, 0, 0, 0);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for iia0d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_ia0d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for iia0d\n");
  }
  free(dv);
  free(dv_ia0d);
  error = nErrors;

  send_ra0d();
  addr = cc.getArrayBaseAddress(dv_ra0d, rank);
  elem_size = sizeof(float);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  rc = cc.setArrayDesc(dv, addr, rank,
		       F90_Pointer, F90_Real, elem_size, 0, 0, 0);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for ra0d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_ra0d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for ra0d\n");
  }
  free(dv);
  free(dv_ra0d);
  error = nErrors;

  send_da0d();
  addr = cc.getArrayBaseAddress(dv_da0d, rank);
  elem_size = sizeof(double);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  rc = cc.setArrayDesc(dv, addr, rank,
		       F90_Pointer, F90_Double, elem_size, 0, 0, 0);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for da0d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_da0d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for da0d\n");
  }
  free(dv);
  free(dv_da0d);
  error = nErrors;

  send_ca0d();
  addr = cc.getArrayBaseAddress(dv_ca0d, rank);
  elem_size = 2*sizeof(float);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  rc = cc.setArrayDesc(dv, addr, rank, F90_Pointer,
		       F90_Complex, elem_size, 0, 0, 0);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for ca0d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_ca0d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for ca0d\n");
  }
  free(dv);
  free(dv_ca0d);
  error = nErrors;

  send_dca0d();
  addr = cc.getArrayBaseAddress(dv_dca0d, rank);
  elem_size = 2*sizeof(double);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  rc = cc.setArrayDesc(dv, addr, rank, F90_Pointer,
		       F90_DComplex, elem_size, 0, 0, 0);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for dca0d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_dca0d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for dca0d\n");
  }
  free(dv);
  free(dv_dca0d);
  error = nErrors;

  send_ua0d();
  addr = cc.getArrayBaseAddress(dv_ua0d, rank);
#if defined(PARTICLE_ALIGN_DOUBLE_SIZE)
  elem_size = 8*sizeof(double);
#elif defined(PARTICLE_MIN_ALIGNED_SIZE)
  elem_size = 7*sizeof(double) + sizeof(size_t);
#else
  elem_size = sizeof(Particle);
#endif
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  rc = cc.setArrayDesc(dv, addr, rank, F90_Pointer,
		       F90_Derived, elem_size, 0, 0, 0);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for ua0d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_ua0d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for ua0d\n");
  }
  free(dv);
  free(dv_ua0d);
  error = nErrors;


  /*
   * Test data types (one dimensional arrays)
   */

  rank = 1;

  /* default integer */

  send_iia1d();
  addr = cc.getArrayBaseAddress(dv_iia1d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_iia1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_iia1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for iia1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_iia1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for iia1d\n");
  }
  free(dv);
  free(dv_iia1d);
  error = nErrors;

  /* default Logical */

  send_lla1d();
  addr = cc.getArrayBaseAddress(dv_la1d, rank);
  elem_size = sizeof(unsigned int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_la1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_la1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_la1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Logical, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for lla1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_la1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for lla1d\n");
  }
  free(dv);
  free(dv_la1d);
  error = nErrors;

  /* logical(1) */

  send_l1a1d();
  addr = cc.getArrayBaseAddress(dv_la1d, rank);
  elem_size = sizeof(unsigned char);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_la1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_la1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_la1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Logical1, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for l1a1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_la1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for l1a1d\n");
  }
  free(dv);
  free(dv_la1d);
  error = nErrors;

  /* logical(2) */

  send_l2a1d();
  addr = cc.getArrayBaseAddress(dv_la1d, rank);
  elem_size = sizeof(unsigned short);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_la1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_la1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_la1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Logical2, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for l2a1d\n");
    nErrors += 1;
  }

  if (cc.equalsArrayDesc(dv_la1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for l2a1d\n");
  }
  free(dv);
  free(dv_la1d);
  error = nErrors;

  /* logical(4) */

  send_l4a1d();
  addr = cc.getArrayBaseAddress(dv_la1d, rank);
  elem_size = sizeof(unsigned int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_la1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_la1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_la1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Logical4, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for l4a1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_la1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for l4a1d\n");
  }
  free(dv);
  free(dv_la1d);
  error = nErrors;

  /* Logical(8) */

  send_l8a1d();
  addr = cc.getArrayBaseAddress(dv_la1d, rank);
  elem_size = sizeof(unsigned long long);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_la1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_la1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_la1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Logical8, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for l8a1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_la1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for l8a1d\n");
  }
  free(dv);
  free(dv_la1d);
  error = nErrors;

  /* byte */

  send_i1a1d();
  addr = cc.getArrayBaseAddress(dv_ia1d, rank);
  for (i = 0; i < 10; i++) {
#if F90_MIN_ELEMENT_SIZE == 4
    int* a = (int*) addr;
#else
    char* a = (char*) addr;
#endif
    if (a[i] != i+1) {
      fprintf(stderr, "Value error for i1a1d(%d) = %d\n", i+1, a[i]);
      nErrors += 1;
    }
  }
  elem_size = sizeof(char);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_ia1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_ia1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_ia1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer1, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for i1a1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_ia1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for i1a1d\n");
  }
  free(dv);
  free(dv_ia1d);
  error = nErrors;

  /* short */

  send_i2a1d();
  addr = cc.getArrayBaseAddress(dv_ia1d, rank);
  for (i = 0; i < 10; i++) {
#if F90_MIN_ELEMENT_SIZE == 4
    int* a = (int*) addr;
#else
    short* a = (short*) addr;
#endif
    if (a[i] != i+1) {
      fprintf(stderr, "Value error for i2a1d(%d) = %d\n", i+1, a[i]);
      nErrors += 1;
    }
  }
  elem_size = sizeof(short);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_ia1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_ia1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_ia1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer2, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for i2a1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_ia1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for i2a1d\n");
  }
  free(dv);
  free(dv_ia1d);
  error = nErrors;

  /* integer */

  send_i4a1d();
  addr = cc.getArrayBaseAddress(dv_ia1d, rank);
  for (i = 0; i < 10; i++) {
    int* a = (int*) addr;
    if (a[i] != i+1) {
      fprintf(stderr, "Value error for i4a1d(%d) = %d\n", i+1, a[i]);
      nErrors += 1;
    }
  }
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_ia1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_ia1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_ia1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer4, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for i4a1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_ia1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for i4a1d\n");
  }
  free(dv);
  free(dv_ia1d);
  error = nErrors;

  /* long long */

  send_i8a1d();
  addr = cc.getArrayBaseAddress(dv_ia1d, rank);
  for (i = 0; i < 10; i++) {
    long long * a = (long long*) addr;
    if (a[i] != i+1) {
      fprintf(stderr, "Value error for i8a1d(%d)\n", i+1);
      nErrors += 1;
    }
  }
  elem_size = sizeof(long long);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_ia1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_ia1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_ia1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer8, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for i8a1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_ia1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for i8a1d\n");
  }
  free(dv);
  free(dv_ia1d);
  error = nErrors;

  /* real */

  send_rra1d();
  addr = cc.getArrayBaseAddress(dv_ra1d, rank);
  elem_size = sizeof(float);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_ra1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_ra1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_ra1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Real, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for rra1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_ra1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for rra1d\n");
  }
  free(dv);
  free(dv_ra1d);
  error = nErrors;

  /* double */

  send_dda1d();
  addr = cc.getArrayBaseAddress(dv_da1d, rank);
  elem_size = sizeof(double);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_da1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_da1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_da1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Double, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for dda1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_da1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for dda1d\n");
  }
  free(dv);
  free(dv_da1d);
  error = nErrors;

  /* complex */

  send_ca1d();
  addr = cc.getArrayBaseAddress(dv_ca1d, rank);
  elem_size = 2*sizeof(float);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_ca1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_ca1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_ca1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Complex, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for ca1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_ca1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for ca1d\n");
  }
  free(dv);
  free(dv_ca1d);
  error = nErrors;

  /* double complex */

  send_dca1d();
  addr = cc.getArrayBaseAddress(dv_dca1d, rank);
  elem_size = 2*sizeof(double);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_dca1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_dca1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_dca1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_DComplex, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for dca1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_dca1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for dca1d\n");
  }
  free(dv);
  free(dv_dca1d);
  error = nErrors;

  /* derived data type */

  send_ua1d();
  addr = cc.getArrayBaseAddress(dv_ua1d, rank);
#if defined(PARTICLE_ALIGN_DOUBLE_SIZE)
  elem_size = 8*sizeof(double);
#elif defined(PARTICLE_MIN_ALIGNED_SIZE)
  elem_size = 7*sizeof(double) + sizeof(size_t);
#else
  elem_size = sizeof(Particle);
#endif
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_ua1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_ua1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_ua1d, rank, i+1);
#ifdef ALL_LBOUND_ONE
    if (lb[i] != 1) nErrors += 1;
#else
    if (lb[i] != 3) nErrors += 1;
#endif
    if (extent[i] != 97) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Derived, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for ua1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_ua1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for ua1d\n");
  }
  free(dv);
  free(dv_ua1d);
  error = nErrors;


  /* derived data type with array pointer */

  send_upa1d();
  addr = cc.getArrayBaseAddress(dv_upa1d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_upa1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_upa1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_upa1d, rank, i+1);
#ifdef ALL_LBOUND_ONE
    if (lb[i] != 1) nErrors += 1;
#else
    if (lb[i] != -1) nErrors += 1;
#endif
    if (extent[i] != 11) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointerInDerived,
		       F90_Integer, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for upa1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_upa1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for upa1d\n");
  }
  free(dv);
  free(dv_upa1d);
  error = nErrors;

  /* array pointer in derived a(0:2,0:3,-1:3) */

  code = 0;
  count = -1;
  rank = 3;
  send_ia3d_dp(&code, &count);
  addr = cc.getArrayBaseAddress(dv_ia3d_p, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  calc_stride = elem_size;
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_ia3d_p, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_ia3d_p, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_ia3d_p, rank, i+1);
#ifdef ALL_LBOUND_ONE
    if (lb[i] != 1) nErrors += 1;
#else
    if (i < 2) {
      if (lb[i] != 0) nErrors += 1;
    } else {
      if (lb[i] != -1) nErrors += 1;
    }
#endif
    if (extent[i] != i+3) nErrors += 1;
    if (stride[i] != calc_stride) nErrors += 1;
    calc_stride = extent[i] * stride[i];
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointerInDerived,
		       F90_Integer, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for ia3d_dp\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_ia3d_p, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for ia3d_dp\n");
  }
  free(dv);
  free(dv_ia3d_p);
  error = nErrors;


  /*
   * Test dimensions (all integer arrays)
   */

  /* one dimension */

  rank = 1;
  send_iia1d();
  addr = cc.getArrayBaseAddress(dv_iia1d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_iia1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_iia1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for iia1d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_iia1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for iia1d\n");
  }
  free(dv);
  free(dv_iia1d);
  error = nErrors;

  /* two dimensions */

  rank = 2;
  send_iia2d();
  addr = cc.getArrayBaseAddress(dv_iia2d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  calc_stride = elem_size;
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_iia2d, 2, i+1);
    extent[i] = cc.getArrayExtent(dv_iia2d, 2, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia2d, 2, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != i+1) nErrors += 1;
    if (stride[i] != calc_stride) nErrors += 1;
    calc_stride = extent[i] * stride[i];
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for iia2d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_iia2d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for iia2d\n");
  }
  free(dv);
  free(dv_iia2d);
  error = nErrors;

  /* three dimensions */

  rank = 3;
  send_iia3d();
  addr = cc.getArrayBaseAddress(dv_iia3d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  calc_stride = elem_size;
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_iia3d, 3, i+1);
    extent[i] = cc.getArrayExtent(dv_iia3d, 3, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia3d, 3, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != i+1) nErrors += 1;
    if (stride[i] != calc_stride) nErrors += 1;
    calc_stride = extent[i] * stride[i];
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for iia3d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_iia3d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for iia3d\n");
  }
  free(dv);
  free(dv_iia3d);
  error = nErrors;

  /* four dimensions */

  rank = 4;
  send_iia4d();
  addr = cc.getArrayBaseAddress(dv_iia4d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  calc_stride = elem_size;
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_iia4d, 4, i+1);
    extent[i] = cc.getArrayExtent(dv_iia4d, 4, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia4d, 4, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != i+1) nErrors += 1;
    if (stride[i] != calc_stride) nErrors += 1;
    calc_stride = extent[i] * stride[i];
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for iia4d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_iia4d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for iia4d\n");
  }
  free(dv);
  free(dv_iia4d);
  error = nErrors;

  /* five dimensions */

  rank = 5;
  send_iia5d();
  addr = cc.getArrayBaseAddress(dv_iia5d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  calc_stride = elem_size;
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_iia5d, 5, i+1);
    extent[i] = cc.getArrayExtent(dv_iia5d, 5, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia5d, 5, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != i+1) nErrors += 1;
    if (stride[i] != calc_stride) nErrors += 1;
    calc_stride = extent[i] * stride[i];
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		        F90_Integer, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for iia5d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_iia5d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for iia5d\n");
  }
  free(dv);
  free(dv_iia5d);
  error = nErrors;

  /* six dimensions */

  rank = 6;
  send_iia6d();
  addr = cc.getArrayBaseAddress(dv_iia6d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  calc_stride = elem_size;
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_iia6d, 6, i+1);
    extent[i] = cc.getArrayExtent(dv_iia6d, 6, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia6d, 6, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != i+1) nErrors += 1;
    if (stride[i] != calc_stride) nErrors += 1;
    calc_stride = extent[i] * stride[i];
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for iia6d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_iia6d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for iia6d\n");
  }
  free(dv);
  free(dv_iia6d);
  error = nErrors;

  /* seven dimensions */

  rank = 7;
  send_iia7d();
  addr = cc.getArrayBaseAddress(dv_iia7d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  dv = (dope_vec*) malloc( cc.getArrayDescSize(rank) );
  calc_stride = elem_size;
  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_iia7d, 7, i+1);
    extent[i] = cc.getArrayExtent(dv_iia7d, 7, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia7d, 7, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != i+1) nErrors += 1;
    if (stride[i] != calc_stride) nErrors += 1;
    calc_stride = extent[i] * stride[i];
  }
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer, elem_size, lb, extent, stride);
  if (rc) {
    fprintf(stderr, "ERROR in setArrayDesc for iia7d\n");
    nErrors += 1;
  }
  if (cc.equalsArrayDesc(dv_iia7d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error) {
    fprintf(stderr, "Descriptor error for iia7d\n");
  }
  free(dv);
  free(dv_iia7d);
  error = nErrors;

  if (nErrors > 0) {
    fprintf(stderr, "FAILED, descriptor error in testDesc\n");
  }

  return nErrors;
}


int testSetDesc()
{
  dope_vec* dv;
  void* addr;
  int i, rc, rank;
  long calc_stride, stride0, lb[7], stride[7];
  unsigned long elem_size, extent0, extent[7];
  int error = 0;
  int nErrors = 0;

  /*
   * Test dimensions (all integer arrays)
   */

  /* one dimension */

  rank = 1;
  send_iia1d();
  addr = cc.getArrayBaseAddress(dv_iia1d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;

  for (i = 0; i < rank; i++) {
    lb[i] = cc.getArrayLowerBound(dv_iia1d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_iia1d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia1d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != 10) nErrors += 1;
    if (stride[i] != elem_size) nErrors += 1;
  }
  dv = (void*) calloc( 1, cc.getArrayDescSize(rank) );
  assert(dv != 0);
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer, elem_size, lb, extent, stride);
  if (cc.equalsArrayDesc(dv_iia1d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error || rc) {
    fprintf(stderr, "Descriptor error for new iia1d\n");
  }
  free(dv);
  free(dv_iia1d);
  error = nErrors;

  /* two dimensions */

  rank = 2;
  send_iia2d();
  addr = cc.getArrayBaseAddress(dv_iia2d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  extent0 = 1;
  stride0 = elem_size;
  for (i = 0; i < rank; i++) {
    calc_stride = extent0 * stride0;
    lb[i] =  cc.getArrayLowerBound(dv_iia2d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_iia2d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia2d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != i+1) nErrors += 1;
    if (stride[i] != calc_stride) nErrors += 1;
    extent0 = extent[i];
    stride0 = stride[i];
  }
  dv = (void*) calloc( 1, cc.getArrayDescSize(rank) );
  assert(dv != 0);
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer, elem_size, lb, extent, stride);
  if (cc.equalsArrayDesc(dv_iia2d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error || rc) {
    fprintf(stderr, "Descriptor error for new iia2d\n");
  }
  free(dv);
  free(dv_iia2d);
  error = nErrors;

  /* three dimensions */

  rank = 3;
  send_iia3d();
  addr = cc.getArrayBaseAddress(dv_iia3d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  extent0 = 1;
  stride0 = elem_size;
  for (i = 0; i < rank; i++) {
    calc_stride = extent0 * stride0;
    lb[i] =  cc.getArrayLowerBound(dv_iia3d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_iia3d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia3d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != i+1) nErrors += 1;
    if (stride[i] != calc_stride) nErrors += 1;
    extent0 = extent[i];
    stride0 = stride[i];
  }
  dv = (void*) calloc( 1, cc.getArrayDescSize(rank) );
  assert(dv != 0);
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer, elem_size, lb, extent, stride);
  if (cc.equalsArrayDesc(dv_iia3d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error || rc) {
    fprintf(stderr, "Descriptor error for new iia3d\n");
  }
  free(dv);
  free(dv_iia3d);
  error = nErrors;

  /* four dimensions */

  rank = 4;
  send_iia4d();
  addr = cc.getArrayBaseAddress(dv_iia4d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  extent0 = 1;
  stride0 = elem_size;
  for (i = 0; i < rank; i++) {
    calc_stride = extent0 * stride0;
    lb[i] =  cc.getArrayLowerBound(dv_iia4d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_iia4d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia4d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != i+1) nErrors += 1;
    if (stride[i] != calc_stride) nErrors += 1;
    extent0 = extent[i];
    stride0 = stride[i];
  }
  dv = (void*) calloc( 1, cc.getArrayDescSize(rank) );
  assert(dv != 0);
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer, elem_size, lb, extent, stride);
  if (cc.equalsArrayDesc(dv_iia4d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error || rc) {
    fprintf(stderr, "Descriptor error for new iia4d\n");
  }
  free(dv);
  free(dv_iia4d);
  error = nErrors;

  /* five dimensions */

  rank = 5;
  send_iia5d();
  addr = cc.getArrayBaseAddress(dv_iia5d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  extent0 = 1;
  stride0 = elem_size;
  for (i = 0; i < rank; i++) {
    calc_stride = extent0 * stride0;
    lb[i] =  cc.getArrayLowerBound(dv_iia5d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_iia5d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia5d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != i+1) nErrors += 1;
    if (stride[i] != calc_stride) nErrors += 1;
    extent0 = extent[i];
    stride0 = stride[i];
  }
  dv = (void*) calloc( 1, cc.getArrayDescSize(rank) );
  assert(dv != 0);
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer, elem_size, lb, extent, stride);
  if (cc.equalsArrayDesc(dv_iia5d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error || rc) {
    fprintf(stderr, "Descriptor error for new iia5d\n");
  }
  free(dv);
  free(dv_iia5d);
  error = nErrors;

  /* six dimensions */

  rank = 6;
  send_iia6d();
  addr = cc.getArrayBaseAddress(dv_iia6d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  extent0 = 1;
  stride0 = elem_size;
  for (i = 0; i < rank; i++) {
    calc_stride = extent0 * stride0;
    lb[i] =  cc.getArrayLowerBound(dv_iia6d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_iia6d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia6d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != i+1) nErrors += 1;
    if (stride[i] != calc_stride) nErrors += 1;
    extent0 = extent[i];
    stride0 = stride[i];
  }
  dv = (void*) calloc( 1, cc.getArrayDescSize(rank) );
  assert(dv != 0);
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer, elem_size, lb, extent, stride);
  if (cc.equalsArrayDesc(dv_iia6d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error || rc) {
    fprintf(stderr, "Descriptor error for new iia6d\n");
  }
  free(dv);
  free(dv_iia6d);
  error = nErrors;

  /* seven dimensions */

  rank = 7;
  send_iia7d();
  addr = cc.getArrayBaseAddress(dv_iia7d, rank);
  elem_size = sizeof(int);
  if (elem_size < F90_MIN_ELEMENT_SIZE) elem_size = F90_MIN_ELEMENT_SIZE;
  extent0 = 1;
  stride0 = elem_size;
  for (i = 0; i < rank; i++) {
    calc_stride = extent0 * stride0;
    lb[i] = cc.getArrayLowerBound(dv_iia7d, rank, i+1);
    extent[i] = cc.getArrayExtent(dv_iia7d, rank, i+1);
    stride[i] = cc.getArrayStrideMult(dv_iia7d, rank, i+1);
    if (lb[i] != 1) nErrors += 1;
    if (extent[i] != i+1) nErrors += 1;
    if (stride[i] != calc_stride) nErrors += 1;
    extent0 = extent[i];
    stride0 = stride[i];
  }
  dv = (void*) calloc( 1, cc.getArrayDescSize(rank) );
  assert(dv != 0);
  rc = cc.setArrayDesc(dv, addr, rank, F90_ArrayPointer,
		       F90_Integer, elem_size, lb, extent, stride);
  if (cc.equalsArrayDesc(dv_iia7d, dv, rank) != 1) nErrors += 1;
  if (nErrors > error || rc) {
    fprintf(stderr, "Descriptor error for new iia7d\n");
  }
  free(dv);
  free(dv_iia7d);
  error = nErrors;

  if (nErrors > 0) {
    fprintf(stderr, "FAILED, descriptor error in testDesc\n");
  }

  return nErrors;
}


/** These functions save the array descriptor (called from Fortran). */


void recv_iia1d_null(dope_vec* desc, dope_vec_hidden* hidden)
{
   dv_iia1d  = cc.createArrayDesc(desc, hidden, 1, F90_Array);
   printf("printing newly created descriptor\n");
   printRawDesc(dv_iia1d, 1);
   cc.printArrayDesc(dv_iia1d, 1);
   printf("done printing newly created descriptor\n");   
  vdv_iia1d = hidden;
}

void recv_ia1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia1d  = cc.createArrayDesc(desc, hidden, 1, F90_Array);
  vdv_ia1d = hidden;
}

void recv_ia2d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia2d  = cc.createArrayDesc(desc, hidden, 2, F90_Array);
  vdv_ia2d = hidden;
}

void recv_ia3d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia3d  = cc.createArrayDesc(desc, hidden, 3, F90_Array);
  vdv_ia3d = hidden;
}

void recv_ia3d_s(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia3d_s  = cc.createArrayDesc(desc, hidden, 3, F90_Array);
  vdv_ia3d_s = hidden;
}

void recv_ia3d_p(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia3d_p  = cc.createArrayDesc(desc, hidden, 3, F90_ArrayPointer);
  vdv_ia3d_p = hidden;
}

void recv_ia3d_dp(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia3d_p  = cc.createArrayDesc(desc, hidden, 3, F90_ArrayPointerInDerived);
  vdv_ia3d_p = hidden;
}

void recv_ra0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ra0d  = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_ra0d = hidden;
}

void recv_ra1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ra1d  = cc.createArrayDesc(desc, hidden, 1, F90_Array);
  vdv_ra1d = hidden;
}

void recv_ra2d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ra2d  = cc.createArrayDesc(desc, hidden, 2, F90_Array);
  vdv_ra2d = hidden;
}

void recv_ra3d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ra3d  = cc.createArrayDesc(desc, hidden, 3, F90_Array);
  vdv_ra3d = hidden;
}

void recv_da0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_da0d  = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_da0d = hidden;
}

void recv_da1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_da1d  = cc.createArrayDesc(desc, hidden, 1, F90_Array);
  vdv_da1d = hidden;
}

void recv_ca0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ca0d  = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_ca0d = hidden;
}

void recv_ca1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ca1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointer);
  vdv_ca1d = hidden;
}

void recv_dca0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_dca0d  = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_dca0d = hidden;
}

void recv_dca1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_dca1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointer);
  vdv_dca1d = hidden;
}

void recv_ua0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ua0d  = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_ua0d = hidden;
}

void recv_ua1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ua1d  = cc.createArrayDesc(desc, hidden, 1, F90_Pointer);
  vdv_ua1d = hidden;
}

void recv_upa1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_upa1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointerInDerived);
  vdv_upa1d = hidden;
}

void recv_iia0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia0d = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_ia0d = hidden;
}

void recv_iia1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_iia1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointer);
  vdv_iia1d = hidden;
}

void recv_iia2d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_iia2d  = cc.createArrayDesc(desc, hidden, 2, F90_ArrayPointer);
  vdv_iia2d = hidden;
}

void recv_iia3d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_iia3d  = cc.createArrayDesc(desc, hidden, 3, F90_ArrayPointer);
  vdv_iia3d = hidden;
}

void recv_iia4d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_iia4d  = cc.createArrayDesc(desc, hidden, 4, F90_ArrayPointer);
  vdv_iia4d = hidden;
}

void recv_iia5d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_iia5d  = cc.createArrayDesc(desc, hidden, 5, F90_ArrayPointer);
  vdv_iia5d = hidden;
}

void recv_iia6d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_iia6d  = cc.createArrayDesc(desc, hidden, 6, F90_ArrayPointer);
  vdv_iia6d = hidden;
}

void recv_iia7d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_iia7d  = cc.createArrayDesc(desc, hidden, 7, F90_ArrayPointer);
  vdv_iia7d = hidden;
}

void recv_lla0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_la0d  = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_la0d = hidden;
}

void recv_l1a0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_la0d  = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_la0d = hidden;
}

void recv_l2a0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_la0d  = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_la0d = hidden;
}

void recv_l4a0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_la0d  = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_la0d = hidden;
}

void recv_l8a0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_la0d  = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_la0d = hidden;
}

void recv_lla1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_la1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointer);
  vdv_la1d = hidden;
}

void recv_l1a1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_la1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointer);
  vdv_la1d = hidden;
}

void recv_l2a1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_la1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointer);
  vdv_la1d = hidden;
}

void recv_l4a1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_la1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointer);
  vdv_la1d = hidden;
}

void recv_l8a1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_la1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointer);
  vdv_la1d = hidden;
}

void recv_i1a0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia0d  = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_ia0d = hidden;
}

void recv_i2a0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia0d  = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_ia0d = hidden;
}

void recv_i4a0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia0d  = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_ia0d = hidden;
}

void recv_i8a0d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia0d  = cc.createArrayDesc(desc, hidden, 0, F90_Pointer);
  vdv_ia0d = hidden;
}

void recv_i1a1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointer);
  vdv_ia1d = hidden;
}

void recv_i2a1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointer);
  vdv_ia1d = hidden;
}

void recv_i4a1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointer);
  vdv_ia1d = hidden;
}

void recv_i8a1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ia1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointer);
  vdv_ia1d = hidden;
}

void recv_rra1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_ra1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointer);
  vdv_ra1d = hidden;
}

void recv_dda1d(dope_vec* desc, dope_vec_hidden* hidden)
{
  dv_da1d  = cc.createArrayDesc(desc, hidden, 1, F90_ArrayPointer);
  vdv_da1d = hidden;
}


/**
 * Prints the array base address.
 */
void print_iaddr(long* a)
{
  printf("   Array: base_addr      = %p\n", a);
}


/**
 * Prints the array base address.
 */
void print_raddr(long* a)
{
  printf("   Array: base_addr      = %p\n", a);
}


/**
 * Prints the array base address.
 */
void print_daddr(long* a)
{
  printf("   Array: base_addr      = %p\n", a);
}


/**
 * Prints the first *count members of the byte array
 */
void print_i1a(char* a, int* count)
{
  int i;
  for (i = 0; i < *count; i++) {
    printf("      a[%d] = %d\n", i, a[i]);
  }
}


/**
 * Prints the first *count members of the short array
 */
void print_i2a(short* a, int* count)
{
  int i;
  for (i = 0; i < *count; i++) {
    printf("      a[%d] = %d\n", i, a[i]);
  }
}


/**
 * Prints the first *count members of the long array
 */
void print_i8a(long* a, int* count)
{
  int i;
  for (i = 0; i < *count; i++) {
    printf("      a[%d] = %d\n", i, a[i]);
  }
}


/**
 * Prints the first *count members of the int array
 */
void print_ia(int* a, int* count)
{
  int i;
  for (i = 0; i < *count; i++) {
    printf("      a[%d] = %d\n", i, a[i]);
  }
}


/**
 * Prints the first *count members of the float array
 */
void print_ra(float* a, int* count)
{
  int i;
  for (i = 0; i < *count; i++) {
    printf("      a[%d] = %f\n", i, a[i]);
  }
}


/**
 * Prints the first *count members of the double array
 */
void print_da(double* a, int* count)
{
  int i;
  for (i = 0; i < *count; i++) {
    printf("      a[%d] = %g\n", i, a[i]);
  }
}


/**
 * prints out the array and the array descriptor information
 */
void printRawDesc(void* desc, int rank)
{
  int i, imax;
  short* is = (short*) desc;
  long*  ia = (long*) desc;

  /* imax is compiler dependent, change value if necessary to test */
  imax = 6 + rank*6;

  printf("   ArrayPrint: base_addr = %p (%ld)\n", (void*) ia[0], ia[0]);
#ifdef CHASM_ARCH_64
  printf("      ia[1] = %ld (%d, %d, %d, %d), %p\n",
                ia[1], is[4], is[5], is[6], is[7], (void*)ia[1]);
#else
  printf("      ia[1] = %ld (%d, %d), %p\n",
                ia[1], is[2], is[3], (void*)ia[1]);
#endif

  for (i = 2; i < imax; i++) {
#ifdef CHASM_ARCH_64
    printf("      ia[%d] = %ld (%d, %d, %d, %d)\n",
	       i, ia[i], is[4*i], is[4*i+1], is[4*i+2], is[4*i+3]);
#else
    printf("      ia[%d] = %ld (%d, %d)\n", i, ia[i], is[2*i], is[2*i+1]);
#endif
  }
}
