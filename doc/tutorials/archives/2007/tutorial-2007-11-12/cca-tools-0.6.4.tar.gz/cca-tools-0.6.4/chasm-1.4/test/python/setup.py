from distutils.core import setup, Extension
setup(name="RECEIVE", version="1.0",
      ext_modules=[
         Extension("RECEIVE",
                   ["receive_py.c"],
	           extra_objects=["receive.o",
                                  "receive_init.o"],
	           include_dirs=["/Users/rasmussn/chasm/include"]
                  ),
         ])


#                   library_dirs=["."],
#                   libraries=["NLF"]