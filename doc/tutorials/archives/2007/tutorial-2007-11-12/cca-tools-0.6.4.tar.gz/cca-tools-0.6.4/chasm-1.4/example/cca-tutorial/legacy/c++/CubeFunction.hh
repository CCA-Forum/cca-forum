namespace functions {

  class CubeFunction {
    public: double evaluate(double x);
  };

}
