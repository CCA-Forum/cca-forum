//
// testing typedefs and aliasing
//
class hasalias {
public:
  int A();

  typedef float* floater;

  floater f;
};

//
// global typedefs
//
typedef int global_integer;
