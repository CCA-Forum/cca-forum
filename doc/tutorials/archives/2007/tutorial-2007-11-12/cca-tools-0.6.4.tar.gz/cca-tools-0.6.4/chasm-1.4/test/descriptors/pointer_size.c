#include <stdio.h>
#include <F90Compiler.h>


#if   defined (F90_SYM_CASE_LOWER)
#  define setTypeInfo F90_SYMBOL(settypeinfo)
#elif defined (F90_SYM_CASE_UPPER)
#  define setTypeInfo F90_SYMBOL(SETTYPEINFO)
#else
#  define setTypeInfo F90_SYMBOL(setTypeInfo)
#endif


typedef struct wrapper_ {
  int a[512];
} wrapper;

void setTypeInfo(wrapper*);

int F90_MAIN(int argc, char* argv[])
{
  int i;
  wrapper w;

  setTypeInfo(&w);  

  if (w.a[0] != 333331) {
    printf("FAILED, start flag is incorrect = %d\n", w.a[0]);
    return 1;
  }

  for (i = 0; i < 512; i++) {
    if (w.a[i] == 333332) {
      printf("SUCCESSFULLY found Fortran pointer length of %d bytes\n",
	     (i-1) * (unsigned) sizeof(int));
      return 0;
    }
  }

  printf("FAILED to find end flag\n");
  return 1;
}
