/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */

#include "CompilerCharacteristics.h"
#include <F90Compiler.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>


#if defined(F90_SYM_CASE_LOWER) || defined(F90_SYM_CASE_MIXED)
#  define test_int_pointer F90_SYMBOL_COND( test_int_pointer )
#  define test_float_pointer F90_SYMBOL_COND( test_float_pointer )
#  define test_complex_pointer F90_SYMBOL_COND( test_complex_pointer )
#  define test_derived_pointer F90_SYMBOL_COND( test_derived_pointer )
#endif /* F90_SYM_CASE_LOWER || F90_SYM_CASE_MIXED */

#ifdef F90_SYM_CASE_UPPER
#  define test_int_pointer F90_SYMBOL_COND( TEST_INT_POINTER )
#  define test_float_pointer F90_SYMBOL_COND( TEST_FLOAT_POINTER )
#  define test_complex_pointer F90_SYMBOL_COND( TEST_COMPLEX_POINTER )
#  define test_derived_pointer F90_SYMBOL_COND( TEST_DERIVED_POINTER )
#endif /* F90_SYM_CASE_UPPER */


int test_int_pointer(void* dv, void* dv_hidden);
int test_float_pointer(void* dv, void* dv_hidden);
int test_complex_pointer(void* dv, void* dv_hidden);
int test_derived_pointer(void* dv, void* dv_hidden);


typedef struct Complex_ {
  float real;
  float imag;
} Complex;


int F90_MAIN(int argc, char* argv[])
{
  void *desc, *dv, *dv_hidden;
  F90_CompilerCharacteristics cc;
  int rc, i, rank, nErrors;
  Complex c;
  float x;

  rc = 0;
  nErrors = 0;

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);

  i = 33;
  rank = 0;

  desc = malloc( cc.getArrayDescSize(rank) );
  assert(desc);

  /* create int pointer descriptor */

  rc = cc.setArrayDesc(desc, &i, rank, F90_Pointer,
		       F90_Integer, sizeof(int), 0, 0, 0);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in setting integer-pointer descriptor\n");
  }

  /* test int pointer */

  rc = cc.createArrayDescAndHidden(desc, rank, F90_Pointer, &dv, &dv_hidden);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in createArrayDescAndHidden\n");
  }

  rc = test_int_pointer(dv, dv_hidden);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in test_int_pointer\n");
  }
  if (i != 4) {
    nErrors += 1;
    fprintf(stderr, "ERROR in test_int_pointer, i != 4, = %d\n", i);
  }
  
  /* test accessor functions */

  if (cc.getArraySize(desc, 0) != 0) {
    nErrors += 1;
    fprintf(stderr, "ERROR getArraySize != 0\n");
  }

  if (cc.getArrayLowerBound(desc, 0, 1) != 0) {
    nErrors += 1;
    fprintf(stderr, "ERROR getArrayLowerBound != 0\n");
  }

  if (cc.getArrayExtent(desc, 0, 1) != 0) {
    nErrors += 1;
    fprintf(stderr, "ERROR getArrayExtent != 0\n");
  }

  if (cc.getArrayStrideMult(desc, 0, 1) != 0) {
    nErrors += 1;
    fprintf(stderr, "ERROR getArrayStrideMult != 0\n");
  }

  rc = cc.freeArrayDescAndHidden(F90_Pointer, dv, dv_hidden);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in freeArrayDescAndHidden\n");
  }


  /* create float pointer descriptor */

  x = 33.3;

  rc = cc.setArrayDesc(desc, &x, rank, F90_Pointer,
		       F90_Real, sizeof(float), 0, 0, 0);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in setting float-pointer descriptor\n");
  }

  /* test float pointer */

  rc = cc.createArrayDescAndHidden(desc, rank, F90_Pointer, &dv, &dv_hidden);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in createArrayDescAndHidden\n");
  }

  rc = test_float_pointer(dv, dv_hidden);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in test_float_pointer\n");
  }
  if (x < 99.89999 | x > 99.90001) {
    nErrors += 1;
    fprintf(stderr, "ERROR in test_float_pointer, x != 99.9, = %f\n", x);
  }
  
  rc = cc.freeArrayDescAndHidden(F90_Pointer, dv, dv_hidden);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in freeArrayDescAndHidden\n");
  }


  /* create complex pointer descriptor */

  c.real = -33.3;
  c.imag = 99.9;

  rc = cc.setArrayDesc(desc, &c, rank, F90_Pointer,
		       F90_Complex, sizeof(Complex), 0, 0, 0);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in setting complex-pointer descriptor\n");
  }

  /* test complex pointer */

  rc = cc.createArrayDescAndHidden(desc, rank, F90_Pointer, &dv, &dv_hidden);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in createArrayDescAndHidden\n");
  }

  rc = test_complex_pointer(dv, dv_hidden);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in test_complex_pointer\n");
  }
  if (c.real != 4.0 && c.imag != 5.0) {
    nErrors += 1;
    fprintf(stderr, "ERROR in test_complex_pointer, c = (%f,%f)\n",
	    c.real, c.imag);
  }
  
  rc = cc.freeArrayDescAndHidden(F90_Pointer, dv, dv_hidden);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in freeArrayDescAndHidden\n");
  }


  /* create derived pointer descriptor */

  rc = cc.setArrayDesc(desc, &c, rank, F90_Pointer,
		       F90_Derived, sizeof(Complex), 0, 0, 0);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in setting derived-pointer descriptor\n");
  }

  /* test derived pointer */

  rc = cc.createArrayDescAndHidden(desc, rank, F90_Pointer, &dv, &dv_hidden);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in createArrayDescAndHidden\n");
  }

  rc = test_derived_pointer(dv, dv_hidden);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in test_derived_pointer\n");
  }
  if (c.real != 5.0 && c.imag != 4.0) {
    nErrors += 1;
    fprintf(stderr, "ERROR in test_derived_pointer, c = (%f,%f)\n",
	    c.real, c.imag);
  }
  
  rc = cc.freeArrayDescAndHidden(F90_Pointer, dv, dv_hidden);
  if (rc) {
    nErrors += 1;
    fprintf(stderr, "ERROR in freeArrayDescAndHidden\n");
  }

  free(desc);

  return nErrors;
}
