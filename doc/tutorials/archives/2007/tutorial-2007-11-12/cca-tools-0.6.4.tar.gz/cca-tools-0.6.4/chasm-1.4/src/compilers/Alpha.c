/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 */
#include <compilers/Alpha.h>
#include <compilers/Alpha_dv.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define dope_vec   dope_vec_Alpha
#define dope_vec0d dope_vec0d_Alpha

#ifdef __cplusplus
extern "C"{
#endif


/**
 * Set CompilerCharacteristics function pointers for Alpha.
 */
void F90_SetCCFunctions_Alpha(F90_CompilerCharacteristics* cc)
{
  cc->setArrayDesc              = setArrayDesc_Alpha;
  cc->resetArrayDesc            = resetArrayDesc_Alpha;
  cc->createArrayDesc           = createArrayDesc_Alpha;
  cc->copyToArrayDescAndHidden  = copyToArrayDescAndHidden_Alpha;
  cc->createArrayDescAndHidden  = createArrayDescAndHidden_Alpha;
  cc->freeArrayDescAndHidden    = freeArrayDescAndHidden_Alpha;
  cc->getArrayBaseAddress       = getArrayBaseAddress_Alpha;
  cc->getArraySize              = getArraySize_Alpha;
  cc->getArrayLowerBound        = getArrayLowerBound_Alpha;
  cc->getArrayExtent	        = getArrayExtent_Alpha;
  cc->getArrayStrideMult        = getArrayStrideMult_Alpha;
  cc->getArrayDescSize	        = getArrayDescSize_Alpha;
  cc->nullifyArrayDesc          = nullifyArrayDesc_Alpha;
  cc->verifyArrayDesc           = verifyArrayDesc_Alpha;
  cc->hiddenArrayDescType       = hiddenArrayDescType_Alpha;
  cc->getMangledName	        = getMangledName_Alpha;
  cc->equalsArrayDesc	        = equalsArrayDesc_Alpha;
  cc->printArrayDesc	        = printArrayDesc_Alpha;
}


/**
 * Stage 1 of setting the elements of a preallocated array descriptor.
 *
 * NOTE, this function is static (private).
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param rank          the rank of the array
 * @param desc_type     type of the descriptor
 * @param data_type     data type of an array element
 * @param element_size  size of an array element
 * @return              0 if successful (nonzero on error)
 */
static int setArrayDescStage1_Alpha(void* desc,
				    int rank,
				    F90_DescType desc_type,
				    F90_ArrayDataType data_type,
				    unsigned long element_size
				    )
{
  int rc = 0;
  dope_vec* dv = (dope_vec*) desc;

  dv->rank       = rank;
  dv->one        = 1;
  dv->ptr        = 1;
  dv->alloc      = 1;
  dv->zero       = 0;
  dv->elem_size  = element_size;

  dv->reserved1 = 10;

  switch (data_type) {
    case F90_Integer1:	dv->type_code = 1; break;
    case F90_Integer2:	dv->type_code = 2; break;
    case F90_Integer:	dv->type_code = 3; break;
    case F90_Integer4:	dv->type_code = 3; break;
    case F90_Integer8:	dv->type_code = 4; break;
    case F90_Logical1:	dv->type_code = 5; break;
    case F90_Logical2:	dv->type_code = 6; break;
    case F90_Logical:	dv->type_code = 7; break;
    case F90_Logical4:	dv->type_code = 7; break;
    case F90_Logical8:	dv->type_code = 8; break;
    case F90_Real:	dv->type_code = 9; break;
    case F90_Double:	dv->type_code = 10; break;
    case F90_QReal:	dv->type_code = 11; break;
    case F90_Complex:	dv->type_code = 12; break;
    case F90_DComplex:	dv->type_code = 13; break;
    case F90_QComplex:	dv->type_code = 17; break;
/*  case F90_Character:	dv->type_code = 14; break; */
    case F90_Derived:	dv->type_code = 15; break;
    case F90_Unknown:	dv->type_code =  0; break;
    default:
      dv->type_code = 0;  break;
  }
  return rc;
}


/**
 * Sets the elements of a preallocated array descriptor.  This function is
 * used when passing a C array to Fortran.  NOTE, assumes that, at least,
 * ArrayDescSize bytes have been allocated in the desc pointer.
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param base_addr     the base address of the array
 * @param rank          the rank of the array
 * @param desc_type     type of the descriptor
 * @param data_type     data type of an array element
 * @param element_size  size of an array element
 * @param lowerBound    array[rank] of lower bounds for the array
 * @param extent        array[rank] of extents for the array (in elements)
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes)
 * @return              0 if successful (nonzero on error)
 */
int setArrayDesc_Alpha(void* desc,
		       void* base_addr,
		       int rank,
		       F90_DescType desc_type,
		       F90_ArrayDataType data_type,
		       unsigned long element_size,
		       const long* lowerBound,
		       const unsigned long* extent,
		       const long* strideMult
		       )
{
  int rc = 0;

  if (rank < 0 || rank > 7) return 1;

  rc = setArrayDescStage1_Alpha(desc, rank, desc_type, data_type, element_size);
  if (rc) return rc;
  return resetArrayDesc_Alpha(desc, base_addr, rank,
			      lowerBound, extent, strideMult);
}


/**
 * Resets the elements of a preallocated array descriptor.  The descriptor
 * must have been previously initialized by either setArrayDesc() or
 * createArrayDesc().  The rank, data type and element size of the array
 * MUST NOT change.  NOTE, assumes that, at least, ArrayDescSize() bytes
 * have been allocated in the desc pointer.
 *
 * @param desc           pointer to memory for the array descriptor
 *                       (caller must have allocated)
 * @param base_addr     the base address of the array
 * @param rank          the rank of the array
 * @param lowerBound    array[rank] of lower bounds for the array
 * @param extent        array[rank] of extents for the array (in elements)
 * @param strideMult    array[rank] of distances between successive elements
 *                      (in bytes)
 * @return              0 if successful (nonzero on error)
 */
int resetArrayDesc_Alpha(void* desc,
			 void* base_addr,
			 int rank,
			 const long* lowerBound,
			 const unsigned long* extent,
			 const long* strideMult
			 )
{
  int i;
  dope_vec* dv = (dope_vec*) desc;

  if (rank < 0 || rank > 7) return 1;

  if (rank == 0) {
    dope_vec0d* dv = (dope_vec0d*) desc;
    dv->base_addr = base_addr;
    return 0;
  }

  dv->base_addr  = base_addr;

  for (i = 0; i < rank; i++) {
    dv->dim[i].stride_mult = strideMult[i];
    dv->dim[i].upper_bound = lowerBound[i] + extent[i] - 1;
    dv->dim[i].lower_bound = lowerBound[i];
  }
  return 0;
}


/**
 * Returns an array descriptor by copying an existing descriptor.  This
 * function is used when passing an array from Fortran to C++.  NOTE,
 * it is the callers responsibility to free the returned descriptor.
 *
 * @param desc       the descriptor to copy
 * @param hidden     hidden descriptor parameter
 * @param rank       the rank of the array
 * @param desc_type  type of the source descriptor
 * @return           allocated array descriptor copy
 */
void* createArrayDesc_Alpha(void* desc,
			    void* hidden,
			    int rank,
			    F90_DescType desc_type
			    )
{
  void* dv;

  if (rank < 0 || rank > 7) return 0x0;

  dv = (void*) calloc( 1, getArrayDescSize_Alpha(rank) );
  assert(dv != 0);

  memcpy(dv, desc, getArrayDescSize_Alpha(rank));

 return dv;
}


/**
 * Creates an array descriptor (with hidden portion) from an existing
 * descriptor in preparation for calling a Fortran function from C (with
 * an array valued parameter).
 *
 * IMPORTANT NOTES: The companion function freeArrayDescAndHidden must be
 * called to free the parameters desc and hidden after use (lifetime
 * must not exceed that of the source descriptor).
 *
 * @param src        the source descriptor
 * @param rank       the rank of the source and destination arrays
 * @param desc_type  type of the source and destination descriptors
 * @param desc       on return, contains address of created descriptor
 * @param hidden     on return, contains address of hidden form of the descriptor
 * @return           0 if successful (nonzero on error)
 */
int createArrayDescAndHidden_Alpha(void* src,
				   int rank,
				   F90_DescType desc_type,
				   void** desc,
				   void** hidden
				   )
{
  if (rank < 0 || rank > 7) return 1;

  *desc = src;
  *hidden = 0x0;

  return 0;
}


/**
 * Frees an array descriptor (with hidden portion) created by
 * a call to createArrayDescAndHidden().
 *
 * @param desc_type  type of the descriptor
 * @param desc       address of descriptor to be freed
 * @param hidden     address of hidden form of the descriptor to be freed
 * @return           0 if successful (nonzero on error)
 */
int freeArrayDescAndHidden_Alpha(F90_DescType desc_type, void* desc, void* hidden)
{
  return 0;
}


/**
 * Copies one array descriptor to another.  This function is used
 * when passing an array from C++ to Fortran.
 *
 * @param src        the source descriptor
 * @param rank       the rank of the source and destination arrays
 * @param desc_type  type of the source and destination descriptors
 * @param dest       the destination descriptor
 * @param hidden     hidden form of the descriptor, after formal parameter list
 * @return           0 if successful (nonzero on error)
 */
int copyToArrayDescAndHidden_Alpha(void* src,
				   int rank,
				   F90_DescType desc_type,
				   void* dest,
				   void* hidden
				   )
{
  if (rank < 0 || rank > 7) return 1;
  if (rank == 0) {
    memcpy(dest, src, sizeof(void*));
  }
  memcpy(dest, src, getArrayDescSize_Alpha(rank));
  return 0;
}


/** 
 * Returns a pointer to the base address of the array.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       base address of the array
 */
void* getArrayBaseAddress_Alpha(const void* desc, int rank)
{
  if (rank < 0 || rank > 7) {
    return 0x0;
  } else if (rank == 0) {
    return ((dope_vec0d*) desc)->base_addr;
  } else {
    return ((dope_vec*) desc)->base_addr;
  }
}


/**
 * Returns the array size (in elements).
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       array size
 */
unsigned long getArraySize_Alpha(const void* desc, int rank)
{
  int i;
  unsigned long size = 1L;
  dope_vec *dv = (dope_vec*) desc;

  if (rank < 1 || rank > 7) return 0;

  for (i = 0; i < rank; i++) {
    size *= 1L + dv->dim[i].upper_bound - dv->dim[i].lower_bound;
  }
  return size;
}


/**
 * Returns the lower bound for the given dimension.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       lower bound
 */
long getArrayLowerBound_Alpha(const void* desc, int rank, int dim)
{
  if (rank < 1 || rank > 7) return 0;
  return((dope_vec*) desc)->dim[dim-1].lower_bound;
}


/**
 * Returns the extent of the array for the given dimension (in elements).
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       array extent (in elements)
 */
unsigned long getArrayExtent_Alpha(const void* desc, int rank, int dim)
{
  dope_vec* dv = (dope_vec*) desc;
  if (rank < 1 || rank > 7) return 0;
  return 1L + dv->dim[dim-1].upper_bound - dv->dim[dim-1].lower_bound;
}


/**
 * Returns the distance between successive elements (in bytes).
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @param dim    the dimension
 * @return       stride (in bytes)
 */
long getArrayStrideMult_Alpha(const void* desc, int rank, int dim)
{
  if (rank < 1 || rank > 7) return 0;
  return((dope_vec*) desc)->dim[dim-1].stride_mult;
}


/**
 * Returns the size of an array descriptor (in bytes).
 *
 * @param rank   the rank of the array
 * @return       descriptor size (in bytes)
 */
unsigned long getArrayDescSize_Alpha(int rank)
{
  if (rank < 0 || rank > 7) return 0;
  if (rank == 0) return sizeof(dope_vec0d);
  else           return sizeof(dope_vec) - 3*(7-rank)*8;
}


/**
 * Nullify an array descriptor (associated intrinsic will return false).
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @return       0 if successful (nonzero on error)
 */
int nullifyArrayDesc_Alpha(void* desc, int rank)
{
  if (rank < 0 || rank > 7) return 1;

  if (rank == 0) {
    dope_vec0d* dv = (dope_vec0d*) desc;
    dv->base_addr = 0x0;
  } else {
    dope_vec* dv = (dope_vec*) desc;
    dv->one   = 0;
    dv->ptr   = 0;
    dv->alloc = 0;
    dv->zero  = 0;
  }

  return 0;
}


/**
 * Verify an array descriptor.
 *
 * @param desc   array descriptor 
 * @param rank   the rank of the array
 * @return       0 if the descriptor is valid, nonzero otherwise
 */
int verifyArrayDesc_Alpha(const void* desc, int rank)
{
  int i;
  dope_vec* dv = (dope_vec*) desc;

  if (rank < 0 || rank > 7) return 1;

  if (rank == 0) {
    if ( ((dope_vec0d*)desc)->base_addr == 0 ) return 1;
    return 0;
  }

  if (dv->base_addr  == 0x0)		return 1;
  if (dv->rank       != rank)		return 1;
  if (dv->zero       != 0)		return 1;
  if (dv->one        != 1)		return 1;
  if (dv->elem_size  <  1)		return 1;

  if (dv->type_code < 1 || dv->type_code > 17) return 1;

  for (i = 0; i < rank; i++) {
    if (dv->dim[i].upper_bound < dv->dim[i].lower_bound) return 1;
    if (dv->dim[i].stride_mult < 1) return 1;
  }
  return 0;
}


/**
 * Returns the type of hidden descriptors used by the compiler
 *
 * @param desc_type  type of the descriptor
 * @return           hidden descriptor type
 */
F90_HiddenDescType hiddenArrayDescType_Alpha(F90_DescType desc_type)
{
  return F90_NoHidden;
}


/**
 * Returns the symbol name of a module procedure, if the module name
 * is not null, otherwise returns the name of the procedure.
 *
 * Note: static memory is used for the return value so it must be
 * copied if retained because the memory is overwritten at each call.
 *
 * @param fun_name   the name of the procedure
 * @param mod_name   the module name (NULL if a global procedure)
 * @return           symbol name
 */
char* getMangledName_Alpha(const char* fun_name, const char* mod_name)
{   
  int i;
  static char name[512];
  size_t funsize, modsize, namesize;

  if (fun_name == NULL) return NULL;

  funsize = strlen(fun_name);
  if (mod_name == NULL) {
    modsize = 0L;
    namesize = funsize + 1;
  } else {
    modsize = strlen(mod_name);
    namesize = 1 + modsize + 1 + funsize + 1;
  }

  if (namesize > 511) return NULL;

  if (modsize > 0L) {
    strcpy(name, "$");
    strcpy(name + 1, mod_name);
    strcpy(name + 1 + modsize, "$");
    strcpy(name + 1 + modsize + 1, fun_name);
    strcpy(name + 1 + modsize + 1 + funsize, "_");
    /* lower case -> fun_name and mod_name */
    for (i = 0; i < namesize; i++) {
      if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
    }
  } else {
    strcpy(name, fun_name);
    strcpy(name + funsize, "_");
    /* lower case -> fun_name */
    for (i = 0; i < funsize; i++) {
      if ((name[i] > 64) && (name[i] < 91))  name[i] += 32;
    }
  }

  return name;
}


/**
 * Prints all fields in the array descriptor.
 *
 * @param desc   array descriptor
 * @param rank   the rank of the array
 * @return       0 if successful (nonzero on error)
 */
int printArrayDesc_Alpha(const void* desc, int rank)
{
  int i;
  dope_vec *dv = (dope_vec*) desc;

  if (rank < 0 || rank > 7) return 1;

  if (rank == 0) {
    dope_vec0d* dv = (dope_vec0d*) desc;
    printf("Alpha pointer descriptor:\n");
    printf("  base_addr  = %p\n" , dv->base_addr);
    return 0;
  }

  printf("Alpha array descriptor:\n");
  printf("  base_addr  = %p\n" , dv->base_addr);
  printf("  rank       = %d\n" , dv->rank);
  printf("  one        = %d\n" , dv->one);
  printf("  ptr        = %d\n" , dv->ptr);
  printf("  alloc      = %d\n" , dv->alloc);
  printf("  zero       = %d\n" , dv->zero);
  printf("  type_code  = %d\n" , dv->type_code);
  printf("  elem_size  = %ld\n", dv->elem_size);

  printf("  reserved1   = %d\n" , dv->reserved1);
  printf("  reserved2   = %d\n" , dv->reserved2);
  printf("  reserved3   = %ld\n", dv->reserved3);
  printf("  reserved4   = %ld\n", dv->reserved4);

  for (i = 0; i < dv->rank; i++)
  {
    printf("    dim[%d] = SM: %ld, LB: %ld, UB: %ld\n",i, dv->dim[i].stride_mult
           /dv->elem_size, dv->dim[i].lower_bound, dv->dim[i].upper_bound);
  }
  return 0;
}


/**
 * Determines if two descriptors are equal (equivalent).
 *
 * WARNING, this function is deprecated.
 *
 * @param desc1   first descriptor
 * @param desc2   second descriptor
 * @param rank    the rank of the array
 * @return        1 if equal, 0 otherwise
 */
int equalsArrayDesc_Alpha(const void* desc1, const void* desc2, int rank)
{
  int i;
  dope_vec *dv1, *dv2;

  if (rank < 0 || rank > 7) return 1;

  if (rank == 0) {
    dope_vec0d *dv1 = (dope_vec0d*) desc1;
    dope_vec0d *dv2 = (dope_vec0d*) desc2;
    if (dv1->base_addr != dv2->base_addr ) return 0;
    return 1;
  }

  dv1 = (dope_vec*) desc1;
  dv2 = (dope_vec*) desc2;

  if (dv1->rank       != dv2->rank      ) return 0;
  if (dv1->one        != dv2->one       ) return 0;
  if (dv1->ptr        != dv2->ptr       ) return 0;
  if (dv1->alloc      != dv2->alloc     ) return 0;
  if (dv1->zero       != dv2->zero      ) return 0;
  if (dv1->type_code  != dv2->type_code ) return 0;
  if (dv1->elem_size  != dv2->elem_size ) return 0;
  if (dv1->base_addr  != dv2->base_addr ) return 0;

  if (dv1->reserved1  != dv2->reserved1 ) return 0;
  /****
  if (dv1->reserved2  != dv2->reserved2 ) return 0;
  if (dv1->reserved3  != dv2->reserved3 ) return 0;
  if (dv1->reserved4  != dv2->reserved4 ) return 0;
  ****/

  for (i = 0; i < rank; i++) {
    if (dv1->dim[i].lower_bound != dv2->dim[i].lower_bound) return 0;
    if (dv1->dim[i].upper_bound != dv2->dim[i].upper_bound) return 0;
    if (dv1->dim[i].stride_mult != dv2->dim[i].stride_mult) return 0;
  }
  return 1;
}


#ifdef __cplusplus
}
#endif
