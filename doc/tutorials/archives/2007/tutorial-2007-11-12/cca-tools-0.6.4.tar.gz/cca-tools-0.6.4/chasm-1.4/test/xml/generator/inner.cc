//
// test for inner classes in C++
//

class outer {

 protected:

  class inner {
  public:
    void foo();
  };

 public:
  void blah();
};

//
// ... and inner structs
//
class s_outer {
 protected:
  struct inner_struct {
    int a;
  };

 public:
  void booboo();
};
