double evaluate_c_lf(double x);
