/** LANL:license
 * -------------------------------------------------------------------------
 * This SOFTWARE has been authored by an employee or employees of the
 * University of California, operator of the Los Alamos National Laboratory
 * under Contract No. W-7405-ENG-36 with the U.S. Department of Energy.
 * The U.S. Government has rights to use, reproduce, and distribute this
 * SOFTWARE.  The public may copy, distribute, prepare derivative works and
 * publicly display this SOFTWARE without charge, provided that this Notice
 * and any statement of authorship are reproduced on all copies.  Neither
 * the Government nor the University makes any warranty, express or implied,
 * or assumes any liability or responsibility for the use of this SOFTWARE.
 * If SOFTWARE is modified to produce derivative works, such modified
 * SOFTWARE should be clearly marked, so as not to confuse it with the
 * version available from LANL.
 * -------------------------------------------------------------------------
 * LANL:license
 * -------------------------------------------------------------------------
 *
 * testverify.c - this file is automatically created
 *
 * This file tests the verify/nullifyArrayDesc functions
 *
 */

#include <F90CreateArray.h>

#ifdef F90_ABSOFT
#  define getArrayBaseAddress getArrayBaseAddress_Absoft
#endif

#ifdef F90_ALPHA
#  define getArrayBaseAddress getArrayBaseAddress_Alpha
#endif

#ifdef F90_CRAY
#  define getArrayBaseAddress getArrayBaseAddress_Cray
#endif

#ifdef F90_GNU
#  define getArrayBaseAddress getArrayBaseAddress_GNU
#endif

#ifdef F90_G95
#  define getArrayBaseAddress getArrayBaseAddress_G95
#endif

#ifdef F90_IBMXL
#  define getArrayBaseAddress getArrayBaseAddress_IBMXL
#endif

#ifdef F90_INTEL
#  define getArrayBaseAddress getArrayBaseAddress_Intel
#endif

#ifdef F90_INTEL_7
#  define getArrayBaseAddress getArrayBaseAddress_Intel_7
#endif

#ifdef F90_LAHEY
#  define getArrayBaseAddress getArrayBaseAddress_Lahey
#endif

#ifdef F90_MIPSPRO
#  define getArrayBaseAddress getArrayBaseAddress_MIPSpro
#endif

#ifdef F90_NAG
#  define getArrayBaseAddress getArrayBaseAddress_NAG
#endif

#ifdef F90_PGI
#  define getArrayBaseAddress getArrayBaseAddress_PGI
#endif

#ifdef F90_SUNWSPRO
#  define getArrayBaseAddress getArrayBaseAddress_SUNWspro
#endif

#ifdef F90_SYM_CASE_LOWER
#  define testArray1DI1  F90_SYMBOL( testarray1di1 )
#  define testArray1DI2  F90_SYMBOL( testarray1di2 )
#  define testArray1DI  F90_SYMBOL( testarray1di )
#  define testArray1DI4  F90_SYMBOL( testarray1di4 )
#  define testArray1DI8  F90_SYMBOL( testarray1di8 )
#  define testArray1DL1  F90_SYMBOL( testarray1dl1 )
#  define testArray1DL2  F90_SYMBOL( testarray1dl2 )
#  define testArray1DL  F90_SYMBOL( testarray1dl )
#  define testArray1DL4  F90_SYMBOL( testarray1dl4 )
#  define testArray1DL8  F90_SYMBOL( testarray1dl8 )
#  define testArray1DR  F90_SYMBOL( testarray1dr )
#  define testArray1DD  F90_SYMBOL( testarray1dd )
#  define testArray1DC  F90_SYMBOL( testarray1dc )
#  define testArray1DDC  F90_SYMBOL( testarray1ddc )
#  define testArray2DI1  F90_SYMBOL( testarray2di1 )
#  define testArray2DI2  F90_SYMBOL( testarray2di2 )
#  define testArray2DI  F90_SYMBOL( testarray2di )
#  define testArray2DI4  F90_SYMBOL( testarray2di4 )
#  define testArray2DI8  F90_SYMBOL( testarray2di8 )
#  define testArray2DL1  F90_SYMBOL( testarray2dl1 )
#  define testArray2DL2  F90_SYMBOL( testarray2dl2 )
#  define testArray2DL  F90_SYMBOL( testarray2dl )
#  define testArray2DL4  F90_SYMBOL( testarray2dl4 )
#  define testArray2DL8  F90_SYMBOL( testarray2dl8 )
#  define testArray2DR  F90_SYMBOL( testarray2dr )
#  define testArray2DD  F90_SYMBOL( testarray2dd )
#  define testArray2DC  F90_SYMBOL( testarray2dc )
#  define testArray2DDC  F90_SYMBOL( testarray2ddc )
#  define testArray3DI1  F90_SYMBOL( testarray3di1 )
#  define testArray3DI2  F90_SYMBOL( testarray3di2 )
#  define testArray3DI  F90_SYMBOL( testarray3di )
#  define testArray3DI4  F90_SYMBOL( testarray3di4 )
#  define testArray3DI8  F90_SYMBOL( testarray3di8 )
#  define testArray3DL1  F90_SYMBOL( testarray3dl1 )
#  define testArray3DL2  F90_SYMBOL( testarray3dl2 )
#  define testArray3DL  F90_SYMBOL( testarray3dl )
#  define testArray3DL4  F90_SYMBOL( testarray3dl4 )
#  define testArray3DL8  F90_SYMBOL( testarray3dl8 )
#  define testArray3DR  F90_SYMBOL( testarray3dr )
#  define testArray3DD  F90_SYMBOL( testarray3dd )
#  define testArray3DC  F90_SYMBOL( testarray3dc )
#  define testArray3DDC  F90_SYMBOL( testarray3ddc )
#  define testArray4DI1  F90_SYMBOL( testarray4di1 )
#  define testArray4DI2  F90_SYMBOL( testarray4di2 )
#  define testArray4DI  F90_SYMBOL( testarray4di )
#  define testArray4DI4  F90_SYMBOL( testarray4di4 )
#  define testArray4DI8  F90_SYMBOL( testarray4di8 )
#  define testArray4DL1  F90_SYMBOL( testarray4dl1 )
#  define testArray4DL2  F90_SYMBOL( testarray4dl2 )
#  define testArray4DL  F90_SYMBOL( testarray4dl )
#  define testArray4DL4  F90_SYMBOL( testarray4dl4 )
#  define testArray4DL8  F90_SYMBOL( testarray4dl8 )
#  define testArray4DR  F90_SYMBOL( testarray4dr )
#  define testArray4DD  F90_SYMBOL( testarray4dd )
#  define testArray4DC  F90_SYMBOL( testarray4dc )
#  define testArray4DDC  F90_SYMBOL( testarray4ddc )
#  define testArray5DI1  F90_SYMBOL( testarray5di1 )
#  define testArray5DI2  F90_SYMBOL( testarray5di2 )
#  define testArray5DI  F90_SYMBOL( testarray5di )
#  define testArray5DI4  F90_SYMBOL( testarray5di4 )
#  define testArray5DI8  F90_SYMBOL( testarray5di8 )
#  define testArray5DL1  F90_SYMBOL( testarray5dl1 )
#  define testArray5DL2  F90_SYMBOL( testarray5dl2 )
#  define testArray5DL  F90_SYMBOL( testarray5dl )
#  define testArray5DL4  F90_SYMBOL( testarray5dl4 )
#  define testArray5DL8  F90_SYMBOL( testarray5dl8 )
#  define testArray5DR  F90_SYMBOL( testarray5dr )
#  define testArray5DD  F90_SYMBOL( testarray5dd )
#  define testArray5DC  F90_SYMBOL( testarray5dc )
#  define testArray5DDC  F90_SYMBOL( testarray5ddc )
#  define testArray6DI1  F90_SYMBOL( testarray6di1 )
#  define testArray6DI2  F90_SYMBOL( testarray6di2 )
#  define testArray6DI  F90_SYMBOL( testarray6di )
#  define testArray6DI4  F90_SYMBOL( testarray6di4 )
#  define testArray6DI8  F90_SYMBOL( testarray6di8 )
#  define testArray6DL1  F90_SYMBOL( testarray6dl1 )
#  define testArray6DL2  F90_SYMBOL( testarray6dl2 )
#  define testArray6DL  F90_SYMBOL( testarray6dl )
#  define testArray6DL4  F90_SYMBOL( testarray6dl4 )
#  define testArray6DL8  F90_SYMBOL( testarray6dl8 )
#  define testArray6DR  F90_SYMBOL( testarray6dr )
#  define testArray6DD  F90_SYMBOL( testarray6dd )
#  define testArray6DC  F90_SYMBOL( testarray6dc )
#  define testArray6DDC  F90_SYMBOL( testarray6ddc )
#  define testArray7DI1  F90_SYMBOL( testarray7di1 )
#  define testArray7DI2  F90_SYMBOL( testarray7di2 )
#  define testArray7DI  F90_SYMBOL( testarray7di )
#  define testArray7DI4  F90_SYMBOL( testarray7di4 )
#  define testArray7DI8  F90_SYMBOL( testarray7di8 )
#  define testArray7DL1  F90_SYMBOL( testarray7dl1 )
#  define testArray7DL2  F90_SYMBOL( testarray7dl2 )
#  define testArray7DL  F90_SYMBOL( testarray7dl )
#  define testArray7DL4  F90_SYMBOL( testarray7dl4 )
#  define testArray7DL8  F90_SYMBOL( testarray7dl8 )
#  define testArray7DR  F90_SYMBOL( testarray7dr )
#  define testArray7DD  F90_SYMBOL( testarray7dd )
#  define testArray7DC  F90_SYMBOL( testarray7dc )
#  define testArray7DDC  F90_SYMBOL( testarray7ddc )
#endif /* F90_SYM_CASE_LOWER */


#ifdef F90_SYM_CASE_MIXED
#  define testArray1DI1  F90_SYMBOL( testArray1DI1 )
#  define testArray1DI2  F90_SYMBOL( testArray1DI2 )
#  define testArray1DI  F90_SYMBOL( testArray1DI )
#  define testArray1DI4  F90_SYMBOL( testArray1DI4 )
#  define testArray1DI8  F90_SYMBOL( testArray1DI8 )
#  define testArray1DL1  F90_SYMBOL( testArray1DL1 )
#  define testArray1DL2  F90_SYMBOL( testArray1DL2 )
#  define testArray1DL  F90_SYMBOL( testArray1DL )
#  define testArray1DL4  F90_SYMBOL( testArray1DL4 )
#  define testArray1DL8  F90_SYMBOL( testArray1DL8 )
#  define testArray1DR  F90_SYMBOL( testArray1DR )
#  define testArray1DD  F90_SYMBOL( testArray1DD )
#  define testArray1DC  F90_SYMBOL( testArray1DC )
#  define testArray1DDC  F90_SYMBOL( testArray1DDC )
#  define testArray2DI1  F90_SYMBOL( testArray2DI1 )
#  define testArray2DI2  F90_SYMBOL( testArray2DI2 )
#  define testArray2DI  F90_SYMBOL( testArray2DI )
#  define testArray2DI4  F90_SYMBOL( testArray2DI4 )
#  define testArray2DI8  F90_SYMBOL( testArray2DI8 )
#  define testArray2DL1  F90_SYMBOL( testArray2DL1 )
#  define testArray2DL2  F90_SYMBOL( testArray2DL2 )
#  define testArray2DL  F90_SYMBOL( testArray2DL )
#  define testArray2DL4  F90_SYMBOL( testArray2DL4 )
#  define testArray2DL8  F90_SYMBOL( testArray2DL8 )
#  define testArray2DR  F90_SYMBOL( testArray2DR )
#  define testArray2DD  F90_SYMBOL( testArray2DD )
#  define testArray2DC  F90_SYMBOL( testArray2DC )
#  define testArray2DDC  F90_SYMBOL( testArray2DDC )
#  define testArray3DI1  F90_SYMBOL( testArray3DI1 )
#  define testArray3DI2  F90_SYMBOL( testArray3DI2 )
#  define testArray3DI  F90_SYMBOL( testArray3DI )
#  define testArray3DI4  F90_SYMBOL( testArray3DI4 )
#  define testArray3DI8  F90_SYMBOL( testArray3DI8 )
#  define testArray3DL1  F90_SYMBOL( testArray3DL1 )
#  define testArray3DL2  F90_SYMBOL( testArray3DL2 )
#  define testArray3DL  F90_SYMBOL( testArray3DL )
#  define testArray3DL4  F90_SYMBOL( testArray3DL4 )
#  define testArray3DL8  F90_SYMBOL( testArray3DL8 )
#  define testArray3DR  F90_SYMBOL( testArray3DR )
#  define testArray3DD  F90_SYMBOL( testArray3DD )
#  define testArray3DC  F90_SYMBOL( testArray3DC )
#  define testArray3DDC  F90_SYMBOL( testArray3DDC )
#  define testArray4DI1  F90_SYMBOL( testArray4DI1 )
#  define testArray4DI2  F90_SYMBOL( testArray4DI2 )
#  define testArray4DI  F90_SYMBOL( testArray4DI )
#  define testArray4DI4  F90_SYMBOL( testArray4DI4 )
#  define testArray4DI8  F90_SYMBOL( testArray4DI8 )
#  define testArray4DL1  F90_SYMBOL( testArray4DL1 )
#  define testArray4DL2  F90_SYMBOL( testArray4DL2 )
#  define testArray4DL  F90_SYMBOL( testArray4DL )
#  define testArray4DL4  F90_SYMBOL( testArray4DL4 )
#  define testArray4DL8  F90_SYMBOL( testArray4DL8 )
#  define testArray4DR  F90_SYMBOL( testArray4DR )
#  define testArray4DD  F90_SYMBOL( testArray4DD )
#  define testArray4DC  F90_SYMBOL( testArray4DC )
#  define testArray4DDC  F90_SYMBOL( testArray4DDC )
#  define testArray5DI1  F90_SYMBOL( testArray5DI1 )
#  define testArray5DI2  F90_SYMBOL( testArray5DI2 )
#  define testArray5DI  F90_SYMBOL( testArray5DI )
#  define testArray5DI4  F90_SYMBOL( testArray5DI4 )
#  define testArray5DI8  F90_SYMBOL( testArray5DI8 )
#  define testArray5DL1  F90_SYMBOL( testArray5DL1 )
#  define testArray5DL2  F90_SYMBOL( testArray5DL2 )
#  define testArray5DL  F90_SYMBOL( testArray5DL )
#  define testArray5DL4  F90_SYMBOL( testArray5DL4 )
#  define testArray5DL8  F90_SYMBOL( testArray5DL8 )
#  define testArray5DR  F90_SYMBOL( testArray5DR )
#  define testArray5DD  F90_SYMBOL( testArray5DD )
#  define testArray5DC  F90_SYMBOL( testArray5DC )
#  define testArray5DDC  F90_SYMBOL( testArray5DDC )
#  define testArray6DI1  F90_SYMBOL( testArray6DI1 )
#  define testArray6DI2  F90_SYMBOL( testArray6DI2 )
#  define testArray6DI  F90_SYMBOL( testArray6DI )
#  define testArray6DI4  F90_SYMBOL( testArray6DI4 )
#  define testArray6DI8  F90_SYMBOL( testArray6DI8 )
#  define testArray6DL1  F90_SYMBOL( testArray6DL1 )
#  define testArray6DL2  F90_SYMBOL( testArray6DL2 )
#  define testArray6DL  F90_SYMBOL( testArray6DL )
#  define testArray6DL4  F90_SYMBOL( testArray6DL4 )
#  define testArray6DL8  F90_SYMBOL( testArray6DL8 )
#  define testArray6DR  F90_SYMBOL( testArray6DR )
#  define testArray6DD  F90_SYMBOL( testArray6DD )
#  define testArray6DC  F90_SYMBOL( testArray6DC )
#  define testArray6DDC  F90_SYMBOL( testArray6DDC )
#  define testArray7DI1  F90_SYMBOL( testArray7DI1 )
#  define testArray7DI2  F90_SYMBOL( testArray7DI2 )
#  define testArray7DI  F90_SYMBOL( testArray7DI )
#  define testArray7DI4  F90_SYMBOL( testArray7DI4 )
#  define testArray7DI8  F90_SYMBOL( testArray7DI8 )
#  define testArray7DL1  F90_SYMBOL( testArray7DL1 )
#  define testArray7DL2  F90_SYMBOL( testArray7DL2 )
#  define testArray7DL  F90_SYMBOL( testArray7DL )
#  define testArray7DL4  F90_SYMBOL( testArray7DL4 )
#  define testArray7DL8  F90_SYMBOL( testArray7DL8 )
#  define testArray7DR  F90_SYMBOL( testArray7DR )
#  define testArray7DD  F90_SYMBOL( testArray7DD )
#  define testArray7DC  F90_SYMBOL( testArray7DC )
#  define testArray7DDC  F90_SYMBOL( testArray7DDC )
#endif /* F90_SYM_CASE_MIXED */


#ifdef F90_SYM_CASE_UPPER
#  define testArray1DI1  F90_SYMBOL( TESTARRAY1DI1 )
#  define testArray1DI2  F90_SYMBOL( TESTARRAY1DI2 )
#  define testArray1DI  F90_SYMBOL( TESTARRAY1DI )
#  define testArray1DI4  F90_SYMBOL( TESTARRAY1DI4 )
#  define testArray1DI8  F90_SYMBOL( TESTARRAY1DI8 )
#  define testArray1DL1  F90_SYMBOL( TESTARRAY1DL1 )
#  define testArray1DL2  F90_SYMBOL( TESTARRAY1DL2 )
#  define testArray1DL  F90_SYMBOL( TESTARRAY1DL )
#  define testArray1DL4  F90_SYMBOL( TESTARRAY1DL4 )
#  define testArray1DL8  F90_SYMBOL( TESTARRAY1DL8 )
#  define testArray1DR  F90_SYMBOL( TESTARRAY1DR )
#  define testArray1DD  F90_SYMBOL( TESTARRAY1DD )
#  define testArray1DC  F90_SYMBOL( TESTARRAY1DC )
#  define testArray1DDC  F90_SYMBOL( TESTARRAY1DDC )
#  define testArray2DI1  F90_SYMBOL( TESTARRAY2DI1 )
#  define testArray2DI2  F90_SYMBOL( TESTARRAY2DI2 )
#  define testArray2DI  F90_SYMBOL( TESTARRAY2DI )
#  define testArray2DI4  F90_SYMBOL( TESTARRAY2DI4 )
#  define testArray2DI8  F90_SYMBOL( TESTARRAY2DI8 )
#  define testArray2DL1  F90_SYMBOL( TESTARRAY2DL1 )
#  define testArray2DL2  F90_SYMBOL( TESTARRAY2DL2 )
#  define testArray2DL  F90_SYMBOL( TESTARRAY2DL )
#  define testArray2DL4  F90_SYMBOL( TESTARRAY2DL4 )
#  define testArray2DL8  F90_SYMBOL( TESTARRAY2DL8 )
#  define testArray2DR  F90_SYMBOL( TESTARRAY2DR )
#  define testArray2DD  F90_SYMBOL( TESTARRAY2DD )
#  define testArray2DC  F90_SYMBOL( TESTARRAY2DC )
#  define testArray2DDC  F90_SYMBOL( TESTARRAY2DDC )
#  define testArray3DI1  F90_SYMBOL( TESTARRAY3DI1 )
#  define testArray3DI2  F90_SYMBOL( TESTARRAY3DI2 )
#  define testArray3DI  F90_SYMBOL( TESTARRAY3DI )
#  define testArray3DI4  F90_SYMBOL( TESTARRAY3DI4 )
#  define testArray3DI8  F90_SYMBOL( TESTARRAY3DI8 )
#  define testArray3DL1  F90_SYMBOL( TESTARRAY3DL1 )
#  define testArray3DL2  F90_SYMBOL( TESTARRAY3DL2 )
#  define testArray3DL  F90_SYMBOL( TESTARRAY3DL )
#  define testArray3DL4  F90_SYMBOL( TESTARRAY3DL4 )
#  define testArray3DL8  F90_SYMBOL( TESTARRAY3DL8 )
#  define testArray3DR  F90_SYMBOL( TESTARRAY3DR )
#  define testArray3DD  F90_SYMBOL( TESTARRAY3DD )
#  define testArray3DC  F90_SYMBOL( TESTARRAY3DC )
#  define testArray3DDC  F90_SYMBOL( TESTARRAY3DDC )
#  define testArray4DI1  F90_SYMBOL( TESTARRAY4DI1 )
#  define testArray4DI2  F90_SYMBOL( TESTARRAY4DI2 )
#  define testArray4DI  F90_SYMBOL( TESTARRAY4DI )
#  define testArray4DI4  F90_SYMBOL( TESTARRAY4DI4 )
#  define testArray4DI8  F90_SYMBOL( TESTARRAY4DI8 )
#  define testArray4DL1  F90_SYMBOL( TESTARRAY4DL1 )
#  define testArray4DL2  F90_SYMBOL( TESTARRAY4DL2 )
#  define testArray4DL  F90_SYMBOL( TESTARRAY4DL )
#  define testArray4DL4  F90_SYMBOL( TESTARRAY4DL4 )
#  define testArray4DL8  F90_SYMBOL( TESTARRAY4DL8 )
#  define testArray4DR  F90_SYMBOL( TESTARRAY4DR )
#  define testArray4DD  F90_SYMBOL( TESTARRAY4DD )
#  define testArray4DC  F90_SYMBOL( TESTARRAY4DC )
#  define testArray4DDC  F90_SYMBOL( TESTARRAY4DDC )
#  define testArray5DI1  F90_SYMBOL( TESTARRAY5DI1 )
#  define testArray5DI2  F90_SYMBOL( TESTARRAY5DI2 )
#  define testArray5DI  F90_SYMBOL( TESTARRAY5DI )
#  define testArray5DI4  F90_SYMBOL( TESTARRAY5DI4 )
#  define testArray5DI8  F90_SYMBOL( TESTARRAY5DI8 )
#  define testArray5DL1  F90_SYMBOL( TESTARRAY5DL1 )
#  define testArray5DL2  F90_SYMBOL( TESTARRAY5DL2 )
#  define testArray5DL  F90_SYMBOL( TESTARRAY5DL )
#  define testArray5DL4  F90_SYMBOL( TESTARRAY5DL4 )
#  define testArray5DL8  F90_SYMBOL( TESTARRAY5DL8 )
#  define testArray5DR  F90_SYMBOL( TESTARRAY5DR )
#  define testArray5DD  F90_SYMBOL( TESTARRAY5DD )
#  define testArray5DC  F90_SYMBOL( TESTARRAY5DC )
#  define testArray5DDC  F90_SYMBOL( TESTARRAY5DDC )
#  define testArray6DI1  F90_SYMBOL( TESTARRAY6DI1 )
#  define testArray6DI2  F90_SYMBOL( TESTARRAY6DI2 )
#  define testArray6DI  F90_SYMBOL( TESTARRAY6DI )
#  define testArray6DI4  F90_SYMBOL( TESTARRAY6DI4 )
#  define testArray6DI8  F90_SYMBOL( TESTARRAY6DI8 )
#  define testArray6DL1  F90_SYMBOL( TESTARRAY6DL1 )
#  define testArray6DL2  F90_SYMBOL( TESTARRAY6DL2 )
#  define testArray6DL  F90_SYMBOL( TESTARRAY6DL )
#  define testArray6DL4  F90_SYMBOL( TESTARRAY6DL4 )
#  define testArray6DL8  F90_SYMBOL( TESTARRAY6DL8 )
#  define testArray6DR  F90_SYMBOL( TESTARRAY6DR )
#  define testArray6DD  F90_SYMBOL( TESTARRAY6DD )
#  define testArray6DC  F90_SYMBOL( TESTARRAY6DC )
#  define testArray6DDC  F90_SYMBOL( TESTARRAY6DDC )
#  define testArray7DI1  F90_SYMBOL( TESTARRAY7DI1 )
#  define testArray7DI2  F90_SYMBOL( TESTARRAY7DI2 )
#  define testArray7DI  F90_SYMBOL( TESTARRAY7DI )
#  define testArray7DI4  F90_SYMBOL( TESTARRAY7DI4 )
#  define testArray7DI8  F90_SYMBOL( TESTARRAY7DI8 )
#  define testArray7DL1  F90_SYMBOL( TESTARRAY7DL1 )
#  define testArray7DL2  F90_SYMBOL( TESTARRAY7DL2 )
#  define testArray7DL  F90_SYMBOL( TESTARRAY7DL )
#  define testArray7DL4  F90_SYMBOL( TESTARRAY7DL4 )
#  define testArray7DL8  F90_SYMBOL( TESTARRAY7DL8 )
#  define testArray7DR  F90_SYMBOL( TESTARRAY7DR )
#  define testArray7DD  F90_SYMBOL( TESTARRAY7DD )
#  define testArray7DC  F90_SYMBOL( TESTARRAY7DC )
#  define testArray7DDC  F90_SYMBOL( TESTARRAY7DDC )
#endif /* F90_SYM_CASE_UPPER */


int testArray1DI1(void*);
int testArray1DI2(void*);
int testArray1DI(void*);
int testArray1DI4(void*);
int testArray1DI8(void*);
int testArray1DL1(void*);
int testArray1DL2(void*);
int testArray1DL(void*);
int testArray1DL4(void*);
int testArray1DL8(void*);
int testArray1DR(void*);
int testArray1DD(void*);
int testArray1DC(void*);
int testArray1DDC(void*);
int testArray2DI1(void*);
int testArray2DI2(void*);
int testArray2DI(void*);
int testArray2DI4(void*);
int testArray2DI8(void*);
int testArray2DL1(void*);
int testArray2DL2(void*);
int testArray2DL(void*);
int testArray2DL4(void*);
int testArray2DL8(void*);
int testArray2DR(void*);
int testArray2DD(void*);
int testArray2DC(void*);
int testArray2DDC(void*);
int testArray3DI1(void*);
int testArray3DI2(void*);
int testArray3DI(void*);
int testArray3DI4(void*);
int testArray3DI8(void*);
int testArray3DL1(void*);
int testArray3DL2(void*);
int testArray3DL(void*);
int testArray3DL4(void*);
int testArray3DL8(void*);
int testArray3DR(void*);
int testArray3DD(void*);
int testArray3DC(void*);
int testArray3DDC(void*);
int testArray4DI1(void*);
int testArray4DI2(void*);
int testArray4DI(void*);
int testArray4DI4(void*);
int testArray4DI8(void*);
int testArray4DL1(void*);
int testArray4DL2(void*);
int testArray4DL(void*);
int testArray4DL4(void*);
int testArray4DL8(void*);
int testArray4DR(void*);
int testArray4DD(void*);
int testArray4DC(void*);
int testArray4DDC(void*);
int testArray5DI1(void*);
int testArray5DI2(void*);
int testArray5DI(void*);
int testArray5DI4(void*);
int testArray5DI8(void*);
int testArray5DL1(void*);
int testArray5DL2(void*);
int testArray5DL(void*);
int testArray5DL4(void*);
int testArray5DL8(void*);
int testArray5DR(void*);
int testArray5DD(void*);
int testArray5DC(void*);
int testArray5DDC(void*);
int testArray6DI1(void*);
int testArray6DI2(void*);
int testArray6DI(void*);
int testArray6DI4(void*);
int testArray6DI8(void*);
int testArray6DL1(void*);
int testArray6DL2(void*);
int testArray6DL(void*);
int testArray6DL4(void*);
int testArray6DL8(void*);
int testArray6DR(void*);
int testArray6DD(void*);
int testArray6DC(void*);
int testArray6DDC(void*);
int testArray7DI1(void*);
int testArray7DI2(void*);
int testArray7DI(void*);
int testArray7DI4(void*);
int testArray7DI8(void*);
int testArray7DL1(void*);
int testArray7DL2(void*);
int testArray7DL(void*);
int testArray7DL4(void*);
int testArray7DL8(void*);
int testArray7DR(void*);
int testArray7DD(void*);
int testArray7DC(void*);
int testArray7DDC(void*);


void initArrayI(void* dv, int rank, int* lb, int* ub) {
  int* a;
  int i;
  int size = 1;
  for (i = 0; i < rank; i++) size *= 1 + ub[i] - lb[i];
  a = (int*) getArrayBaseAddress(dv, rank);
  for (i = 0; i < size; i++) *a++ = -rank;
}


int F90_MAIN(int argc, char* argv[])
{
  void* dv;
  int nErrors = 0;
  F90_CompilerCharacteristics cc;

  long lb[] = {2, 3, 4, 5, 6, 7, 8};
  long ub[] = {5, 7, 9, 11, 13, 15, 17};

  F90_SetCompilerCharacteristics(&cc, FORTRAN_COMPILER);


  F90_CreateArray1DI1(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (1DI1)\n");
  }
  cc.nullifyArrayDesc(dv,1);

  if ( ! cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (1DI1)\n");
  }
  if ( testArray1DI1(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (1DI1)\n");
  }


  F90_CreateArray1DI2(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (1DI2)\n");
  }
  cc.nullifyArrayDesc(dv,1);

  if ( ! cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (1DI2)\n");
  }
  if ( testArray1DI2(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (1DI2)\n");
  }


  F90_CreateArray1DI(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (1DI)\n");
  }
  cc.nullifyArrayDesc(dv,1);

  if ( ! cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (1DI)\n");
  }
  if ( testArray1DI(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (1DI)\n");
  }


  F90_CreateArray1DI4(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (1DI4)\n");
  }
  cc.nullifyArrayDesc(dv,1);

  if ( ! cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (1DI4)\n");
  }
  if ( testArray1DI4(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (1DI4)\n");
  }


  F90_CreateArray1DI8(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (1DI8)\n");
  }
  cc.nullifyArrayDesc(dv,1);

  if ( ! cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (1DI8)\n");
  }
  if ( testArray1DI8(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (1DI8)\n");
  }


  F90_CreateArray1DL1(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (1DL1)\n");
  }
  cc.nullifyArrayDesc(dv,1);

  if ( ! cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (1DL1)\n");
  }
  if ( testArray1DL1(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (1DL1)\n");
  }


  F90_CreateArray1DL2(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (1DL2)\n");
  }
  cc.nullifyArrayDesc(dv,1);

  if ( ! cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (1DL2)\n");
  }
  if ( testArray1DL2(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (1DL2)\n");
  }


  F90_CreateArray1DL(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (1DL)\n");
  }
  cc.nullifyArrayDesc(dv,1);

  if ( ! cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (1DL)\n");
  }
  if ( testArray1DL(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (1DL)\n");
  }


  F90_CreateArray1DL4(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (1DL4)\n");
  }
  cc.nullifyArrayDesc(dv,1);

  if ( ! cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (1DL4)\n");
  }
  if ( testArray1DL4(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (1DL4)\n");
  }


  F90_CreateArray1DL8(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (1DL8)\n");
  }
  cc.nullifyArrayDesc(dv,1);

  if ( ! cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (1DL8)\n");
  }
  if ( testArray1DL8(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (1DL8)\n");
  }


  F90_CreateArray1DR(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (1DR)\n");
  }
  cc.nullifyArrayDesc(dv,1);

  if ( ! cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (1DR)\n");
  }
  if ( testArray1DR(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (1DR)\n");
  }


  F90_CreateArray1DD(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (1DD)\n");
  }
  cc.nullifyArrayDesc(dv,1);

  if ( ! cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (1DD)\n");
  }
  if ( testArray1DD(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (1DD)\n");
  }


  F90_CreateArray1DC(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (1DC)\n");
  }
  cc.nullifyArrayDesc(dv,1);

  if ( ! cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (1DC)\n");
  }
  if ( testArray1DC(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (1DC)\n");
  }


  F90_CreateArray1DDC(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (1DDC)\n");
  }
  cc.nullifyArrayDesc(dv,1);

  if ( ! cc.verifyArrayDesc(dv,1) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (1DDC)\n");
  }
  if ( testArray1DDC(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (1DDC)\n");
  }


  F90_CreateArray2DI1(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (2DI1)\n");
  }
  cc.nullifyArrayDesc(dv,2);

  if ( ! cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (2DI1)\n");
  }
  if ( testArray2DI1(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (2DI1)\n");
  }


  F90_CreateArray2DI2(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (2DI2)\n");
  }
  cc.nullifyArrayDesc(dv,2);

  if ( ! cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (2DI2)\n");
  }
  if ( testArray2DI2(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (2DI2)\n");
  }


  F90_CreateArray2DI(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (2DI)\n");
  }
  cc.nullifyArrayDesc(dv,2);

  if ( ! cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (2DI)\n");
  }
  if ( testArray2DI(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (2DI)\n");
  }


  F90_CreateArray2DI4(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (2DI4)\n");
  }
  cc.nullifyArrayDesc(dv,2);

  if ( ! cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (2DI4)\n");
  }
  if ( testArray2DI4(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (2DI4)\n");
  }


  F90_CreateArray2DI8(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (2DI8)\n");
  }
  cc.nullifyArrayDesc(dv,2);

  if ( ! cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (2DI8)\n");
  }
  if ( testArray2DI8(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (2DI8)\n");
  }


  F90_CreateArray2DL1(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (2DL1)\n");
  }
  cc.nullifyArrayDesc(dv,2);

  if ( ! cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (2DL1)\n");
  }
  if ( testArray2DL1(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (2DL1)\n");
  }


  F90_CreateArray2DL2(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (2DL2)\n");
  }
  cc.nullifyArrayDesc(dv,2);

  if ( ! cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (2DL2)\n");
  }
  if ( testArray2DL2(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (2DL2)\n");
  }


  F90_CreateArray2DL(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (2DL)\n");
  }
  cc.nullifyArrayDesc(dv,2);

  if ( ! cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (2DL)\n");
  }
  if ( testArray2DL(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (2DL)\n");
  }


  F90_CreateArray2DL4(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (2DL4)\n");
  }
  cc.nullifyArrayDesc(dv,2);

  if ( ! cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (2DL4)\n");
  }
  if ( testArray2DL4(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (2DL4)\n");
  }


  F90_CreateArray2DL8(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (2DL8)\n");
  }
  cc.nullifyArrayDesc(dv,2);

  if ( ! cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (2DL8)\n");
  }
  if ( testArray2DL8(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (2DL8)\n");
  }


  F90_CreateArray2DR(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (2DR)\n");
  }
  cc.nullifyArrayDesc(dv,2);

  if ( ! cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (2DR)\n");
  }
  if ( testArray2DR(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (2DR)\n");
  }


  F90_CreateArray2DD(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (2DD)\n");
  }
  cc.nullifyArrayDesc(dv,2);

  if ( ! cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (2DD)\n");
  }
  if ( testArray2DD(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (2DD)\n");
  }


  F90_CreateArray2DC(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (2DC)\n");
  }
  cc.nullifyArrayDesc(dv,2);

  if ( ! cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (2DC)\n");
  }
  if ( testArray2DC(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (2DC)\n");
  }


  F90_CreateArray2DDC(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (2DDC)\n");
  }
  cc.nullifyArrayDesc(dv,2);

  if ( ! cc.verifyArrayDesc(dv,2) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (2DDC)\n");
  }
  if ( testArray2DDC(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (2DDC)\n");
  }


  F90_CreateArray3DI1(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (3DI1)\n");
  }
  cc.nullifyArrayDesc(dv,3);

  if ( ! cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (3DI1)\n");
  }
  if ( testArray3DI1(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (3DI1)\n");
  }


  F90_CreateArray3DI2(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (3DI2)\n");
  }
  cc.nullifyArrayDesc(dv,3);

  if ( ! cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (3DI2)\n");
  }
  if ( testArray3DI2(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (3DI2)\n");
  }


  F90_CreateArray3DI(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (3DI)\n");
  }
  cc.nullifyArrayDesc(dv,3);

  if ( ! cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (3DI)\n");
  }
  if ( testArray3DI(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (3DI)\n");
  }


  F90_CreateArray3DI4(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (3DI4)\n");
  }
  cc.nullifyArrayDesc(dv,3);

  if ( ! cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (3DI4)\n");
  }
  if ( testArray3DI4(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (3DI4)\n");
  }


  F90_CreateArray3DI8(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (3DI8)\n");
  }
  cc.nullifyArrayDesc(dv,3);

  if ( ! cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (3DI8)\n");
  }
  if ( testArray3DI8(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (3DI8)\n");
  }


  F90_CreateArray3DL1(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (3DL1)\n");
  }
  cc.nullifyArrayDesc(dv,3);

  if ( ! cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (3DL1)\n");
  }
  if ( testArray3DL1(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (3DL1)\n");
  }


  F90_CreateArray3DL2(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (3DL2)\n");
  }
  cc.nullifyArrayDesc(dv,3);

  if ( ! cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (3DL2)\n");
  }
  if ( testArray3DL2(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (3DL2)\n");
  }


  F90_CreateArray3DL(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (3DL)\n");
  }
  cc.nullifyArrayDesc(dv,3);

  if ( ! cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (3DL)\n");
  }
  if ( testArray3DL(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (3DL)\n");
  }


  F90_CreateArray3DL4(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (3DL4)\n");
  }
  cc.nullifyArrayDesc(dv,3);

  if ( ! cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (3DL4)\n");
  }
  if ( testArray3DL4(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (3DL4)\n");
  }


  F90_CreateArray3DL8(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (3DL8)\n");
  }
  cc.nullifyArrayDesc(dv,3);

  if ( ! cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (3DL8)\n");
  }
  if ( testArray3DL8(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (3DL8)\n");
  }


  F90_CreateArray3DR(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (3DR)\n");
  }
  cc.nullifyArrayDesc(dv,3);

  if ( ! cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (3DR)\n");
  }
  if ( testArray3DR(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (3DR)\n");
  }


  F90_CreateArray3DD(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (3DD)\n");
  }
  cc.nullifyArrayDesc(dv,3);

  if ( ! cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (3DD)\n");
  }
  if ( testArray3DD(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (3DD)\n");
  }


  F90_CreateArray3DC(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (3DC)\n");
  }
  cc.nullifyArrayDesc(dv,3);

  if ( ! cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (3DC)\n");
  }
  if ( testArray3DC(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (3DC)\n");
  }


  F90_CreateArray3DDC(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (3DDC)\n");
  }
  cc.nullifyArrayDesc(dv,3);

  if ( ! cc.verifyArrayDesc(dv,3) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (3DDC)\n");
  }
  if ( testArray3DDC(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (3DDC)\n");
  }


  F90_CreateArray4DI1(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (4DI1)\n");
  }
  cc.nullifyArrayDesc(dv,4);

  if ( ! cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (4DI1)\n");
  }
  if ( testArray4DI1(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (4DI1)\n");
  }


  F90_CreateArray4DI2(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (4DI2)\n");
  }
  cc.nullifyArrayDesc(dv,4);

  if ( ! cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (4DI2)\n");
  }
  if ( testArray4DI2(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (4DI2)\n");
  }


  F90_CreateArray4DI(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (4DI)\n");
  }
  cc.nullifyArrayDesc(dv,4);

  if ( ! cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (4DI)\n");
  }
  if ( testArray4DI(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (4DI)\n");
  }


  F90_CreateArray4DI4(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (4DI4)\n");
  }
  cc.nullifyArrayDesc(dv,4);

  if ( ! cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (4DI4)\n");
  }
  if ( testArray4DI4(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (4DI4)\n");
  }


  F90_CreateArray4DI8(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (4DI8)\n");
  }
  cc.nullifyArrayDesc(dv,4);

  if ( ! cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (4DI8)\n");
  }
  if ( testArray4DI8(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (4DI8)\n");
  }


  F90_CreateArray4DL1(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (4DL1)\n");
  }
  cc.nullifyArrayDesc(dv,4);

  if ( ! cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (4DL1)\n");
  }
  if ( testArray4DL1(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (4DL1)\n");
  }


  F90_CreateArray4DL2(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (4DL2)\n");
  }
  cc.nullifyArrayDesc(dv,4);

  if ( ! cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (4DL2)\n");
  }
  if ( testArray4DL2(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (4DL2)\n");
  }


  F90_CreateArray4DL(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (4DL)\n");
  }
  cc.nullifyArrayDesc(dv,4);

  if ( ! cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (4DL)\n");
  }
  if ( testArray4DL(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (4DL)\n");
  }


  F90_CreateArray4DL4(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (4DL4)\n");
  }
  cc.nullifyArrayDesc(dv,4);

  if ( ! cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (4DL4)\n");
  }
  if ( testArray4DL4(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (4DL4)\n");
  }


  F90_CreateArray4DL8(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (4DL8)\n");
  }
  cc.nullifyArrayDesc(dv,4);

  if ( ! cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (4DL8)\n");
  }
  if ( testArray4DL8(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (4DL8)\n");
  }


  F90_CreateArray4DR(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (4DR)\n");
  }
  cc.nullifyArrayDesc(dv,4);

  if ( ! cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (4DR)\n");
  }
  if ( testArray4DR(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (4DR)\n");
  }


  F90_CreateArray4DD(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (4DD)\n");
  }
  cc.nullifyArrayDesc(dv,4);

  if ( ! cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (4DD)\n");
  }
  if ( testArray4DD(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (4DD)\n");
  }


  F90_CreateArray4DC(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (4DC)\n");
  }
  cc.nullifyArrayDesc(dv,4);

  if ( ! cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (4DC)\n");
  }
  if ( testArray4DC(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (4DC)\n");
  }


  F90_CreateArray4DDC(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (4DDC)\n");
  }
  cc.nullifyArrayDesc(dv,4);

  if ( ! cc.verifyArrayDesc(dv,4) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (4DDC)\n");
  }
  if ( testArray4DDC(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (4DDC)\n");
  }


  F90_CreateArray5DI1(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (5DI1)\n");
  }
  cc.nullifyArrayDesc(dv,5);

  if ( ! cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (5DI1)\n");
  }
  if ( testArray5DI1(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (5DI1)\n");
  }


  F90_CreateArray5DI2(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (5DI2)\n");
  }
  cc.nullifyArrayDesc(dv,5);

  if ( ! cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (5DI2)\n");
  }
  if ( testArray5DI2(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (5DI2)\n");
  }


  F90_CreateArray5DI(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (5DI)\n");
  }
  cc.nullifyArrayDesc(dv,5);

  if ( ! cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (5DI)\n");
  }
  if ( testArray5DI(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (5DI)\n");
  }


  F90_CreateArray5DI4(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (5DI4)\n");
  }
  cc.nullifyArrayDesc(dv,5);

  if ( ! cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (5DI4)\n");
  }
  if ( testArray5DI4(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (5DI4)\n");
  }


  F90_CreateArray5DI8(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (5DI8)\n");
  }
  cc.nullifyArrayDesc(dv,5);

  if ( ! cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (5DI8)\n");
  }
  if ( testArray5DI8(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (5DI8)\n");
  }


  F90_CreateArray5DL1(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (5DL1)\n");
  }
  cc.nullifyArrayDesc(dv,5);

  if ( ! cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (5DL1)\n");
  }
  if ( testArray5DL1(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (5DL1)\n");
  }


  F90_CreateArray5DL2(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (5DL2)\n");
  }
  cc.nullifyArrayDesc(dv,5);

  if ( ! cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (5DL2)\n");
  }
  if ( testArray5DL2(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (5DL2)\n");
  }


  F90_CreateArray5DL(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (5DL)\n");
  }
  cc.nullifyArrayDesc(dv,5);

  if ( ! cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (5DL)\n");
  }
  if ( testArray5DL(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (5DL)\n");
  }


  F90_CreateArray5DL4(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (5DL4)\n");
  }
  cc.nullifyArrayDesc(dv,5);

  if ( ! cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (5DL4)\n");
  }
  if ( testArray5DL4(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (5DL4)\n");
  }


  F90_CreateArray5DL8(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (5DL8)\n");
  }
  cc.nullifyArrayDesc(dv,5);

  if ( ! cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (5DL8)\n");
  }
  if ( testArray5DL8(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (5DL8)\n");
  }


  F90_CreateArray5DR(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (5DR)\n");
  }
  cc.nullifyArrayDesc(dv,5);

  if ( ! cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (5DR)\n");
  }
  if ( testArray5DR(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (5DR)\n");
  }


  F90_CreateArray5DD(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (5DD)\n");
  }
  cc.nullifyArrayDesc(dv,5);

  if ( ! cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (5DD)\n");
  }
  if ( testArray5DD(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (5DD)\n");
  }


  F90_CreateArray5DC(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (5DC)\n");
  }
  cc.nullifyArrayDesc(dv,5);

  if ( ! cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (5DC)\n");
  }
  if ( testArray5DC(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (5DC)\n");
  }


  F90_CreateArray5DDC(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (5DDC)\n");
  }
  cc.nullifyArrayDesc(dv,5);

  if ( ! cc.verifyArrayDesc(dv,5) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (5DDC)\n");
  }
  if ( testArray5DDC(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (5DDC)\n");
  }


  F90_CreateArray6DI1(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (6DI1)\n");
  }
  cc.nullifyArrayDesc(dv,6);

  if ( ! cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (6DI1)\n");
  }
  if ( testArray6DI1(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (6DI1)\n");
  }


  F90_CreateArray6DI2(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (6DI2)\n");
  }
  cc.nullifyArrayDesc(dv,6);

  if ( ! cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (6DI2)\n");
  }
  if ( testArray6DI2(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (6DI2)\n");
  }


  F90_CreateArray6DI(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (6DI)\n");
  }
  cc.nullifyArrayDesc(dv,6);

  if ( ! cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (6DI)\n");
  }
  if ( testArray6DI(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (6DI)\n");
  }


  F90_CreateArray6DI4(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (6DI4)\n");
  }
  cc.nullifyArrayDesc(dv,6);

  if ( ! cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (6DI4)\n");
  }
  if ( testArray6DI4(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (6DI4)\n");
  }


  F90_CreateArray6DI8(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (6DI8)\n");
  }
  cc.nullifyArrayDesc(dv,6);

  if ( ! cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (6DI8)\n");
  }
  if ( testArray6DI8(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (6DI8)\n");
  }


  F90_CreateArray6DL1(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (6DL1)\n");
  }
  cc.nullifyArrayDesc(dv,6);

  if ( ! cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (6DL1)\n");
  }
  if ( testArray6DL1(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (6DL1)\n");
  }


  F90_CreateArray6DL2(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (6DL2)\n");
  }
  cc.nullifyArrayDesc(dv,6);

  if ( ! cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (6DL2)\n");
  }
  if ( testArray6DL2(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (6DL2)\n");
  }


  F90_CreateArray6DL(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (6DL)\n");
  }
  cc.nullifyArrayDesc(dv,6);

  if ( ! cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (6DL)\n");
  }
  if ( testArray6DL(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (6DL)\n");
  }


  F90_CreateArray6DL4(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (6DL4)\n");
  }
  cc.nullifyArrayDesc(dv,6);

  if ( ! cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (6DL4)\n");
  }
  if ( testArray6DL4(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (6DL4)\n");
  }


  F90_CreateArray6DL8(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (6DL8)\n");
  }
  cc.nullifyArrayDesc(dv,6);

  if ( ! cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (6DL8)\n");
  }
  if ( testArray6DL8(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (6DL8)\n");
  }


  F90_CreateArray6DR(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (6DR)\n");
  }
  cc.nullifyArrayDesc(dv,6);

  if ( ! cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (6DR)\n");
  }
  if ( testArray6DR(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (6DR)\n");
  }


  F90_CreateArray6DD(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (6DD)\n");
  }
  cc.nullifyArrayDesc(dv,6);

  if ( ! cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (6DD)\n");
  }
  if ( testArray6DD(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (6DD)\n");
  }


  F90_CreateArray6DC(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (6DC)\n");
  }
  cc.nullifyArrayDesc(dv,6);

  if ( ! cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (6DC)\n");
  }
  if ( testArray6DC(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (6DC)\n");
  }


  F90_CreateArray6DDC(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (6DDC)\n");
  }
  cc.nullifyArrayDesc(dv,6);

  if ( ! cc.verifyArrayDesc(dv,6) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (6DDC)\n");
  }
  if ( testArray6DDC(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (6DDC)\n");
  }


  F90_CreateArray7DI1(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (7DI1)\n");
  }
  cc.nullifyArrayDesc(dv,7);

  if ( ! cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (7DI1)\n");
  }
  if ( testArray7DI1(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (7DI1)\n");
  }


  F90_CreateArray7DI2(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (7DI2)\n");
  }
  cc.nullifyArrayDesc(dv,7);

  if ( ! cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (7DI2)\n");
  }
  if ( testArray7DI2(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (7DI2)\n");
  }


  F90_CreateArray7DI(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (7DI)\n");
  }
  cc.nullifyArrayDesc(dv,7);

  if ( ! cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (7DI)\n");
  }
  if ( testArray7DI(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (7DI)\n");
  }


  F90_CreateArray7DI4(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (7DI4)\n");
  }
  cc.nullifyArrayDesc(dv,7);

  if ( ! cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (7DI4)\n");
  }
  if ( testArray7DI4(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (7DI4)\n");
  }


  F90_CreateArray7DI8(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (7DI8)\n");
  }
  cc.nullifyArrayDesc(dv,7);

  if ( ! cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (7DI8)\n");
  }
  if ( testArray7DI8(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (7DI8)\n");
  }


  F90_CreateArray7DL1(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (7DL1)\n");
  }
  cc.nullifyArrayDesc(dv,7);

  if ( ! cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (7DL1)\n");
  }
  if ( testArray7DL1(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (7DL1)\n");
  }


  F90_CreateArray7DL2(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (7DL2)\n");
  }
  cc.nullifyArrayDesc(dv,7);

  if ( ! cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (7DL2)\n");
  }
  if ( testArray7DL2(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (7DL2)\n");
  }


  F90_CreateArray7DL(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (7DL)\n");
  }
  cc.nullifyArrayDesc(dv,7);

  if ( ! cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (7DL)\n");
  }
  if ( testArray7DL(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (7DL)\n");
  }


  F90_CreateArray7DL4(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (7DL4)\n");
  }
  cc.nullifyArrayDesc(dv,7);

  if ( ! cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (7DL4)\n");
  }
  if ( testArray7DL4(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (7DL4)\n");
  }


  F90_CreateArray7DL8(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (7DL8)\n");
  }
  cc.nullifyArrayDesc(dv,7);

  if ( ! cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (7DL8)\n");
  }
  if ( testArray7DL8(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (7DL8)\n");
  }


  F90_CreateArray7DR(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (7DR)\n");
  }
  cc.nullifyArrayDesc(dv,7);

  if ( ! cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (7DR)\n");
  }
  if ( testArray7DR(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (7DR)\n");
  }


  F90_CreateArray7DD(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (7DD)\n");
  }
  cc.nullifyArrayDesc(dv,7);

  if ( ! cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (7DD)\n");
  }
  if ( testArray7DD(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (7DD)\n");
  }


  F90_CreateArray7DC(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (7DC)\n");
  }
  cc.nullifyArrayDesc(dv,7);

  if ( ! cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (7DC)\n");
  }
  if ( testArray7DC(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (7DC)\n");
  }


  F90_CreateArray7DDC(&dv, lb, ub);
  if ( cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc failed (7DDC)\n");
  }
  cc.nullifyArrayDesc(dv,7);

  if ( ! cc.verifyArrayDesc(dv,7) ) {
    nErrors += 1;
    printf("ERROR, verifyArrayDesc should have failed (7DDC)\n");
  }
  if ( testArray7DDC(dv) != 1 ) {
    nErrors += 1;
    printf("ERROR, testArray should have failed (7DDC)\n");
  }


  return nErrors;
}
