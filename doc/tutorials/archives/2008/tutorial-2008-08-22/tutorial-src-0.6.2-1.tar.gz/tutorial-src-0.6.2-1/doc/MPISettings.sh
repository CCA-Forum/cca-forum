#!/bin/sh
# script to query bocca, etc to get the right mpi settings from
# within a bocca project.

CCAFE_CONFIG=`$BOCCA config project --query-var=ccaffeine:ccafe_config`
HAVE_MPI=`$CCAFE_CONFIG --var CCAFE_USEMPI`
CCAFESIDL="`$CCAFE_CONFIG --var CCAFE_pkgdatadir`/ccafe.sidl"
CCAFEINCL="`$CCAFE_CONFIG --var CCAFE_pkgincludedir`/dc/babel.new/babel-cca/serv
er"
CCAFEINCL2="`$CCAFE_CONFIG --var CCAFE_pkgincludedir`/util"
if test "x$HAVE_MPI" = "x1"; then
        USESMPI="--uses=ccaffeine.ports.MPIService@MPIService@$CCAFESIDL"

        if test "x$MPI_PREFIX" = "x"; then
                echo "##################################################"
                echo "MPI_PREFIX has not been defined. Most likely this"
                echo "will cause build and link to fail from missing headers"
		echo "and missing libraries."
                echo "##################################################"
        fi
        MPIINCDIR="$MPI_PREFIX/include"
        MPIINC="-I$MPIINCDIR -DMPICH_SKIP_MPICXX"
        MPILIB="$MPI_PREFIX/lib"
        MPILIBNAME="mpich"
fi

