// 
// File:          pde_viewers_MeshPrinter_Impl.cxx
// Symbol:        pde.viewers.MeshPrinter-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.viewers.MeshPrinter
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_viewers_MeshPrinter_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_bsl_arr_hxx
#include "bsl_arr.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_ParameterPortFactory_hxx
#include "gov_cca_ports_ParameterPortFactory.hxx"
#endif
#ifndef included_pde_FieldVar_hxx
#include "pde_FieldVar.hxx"
#endif
#ifndef included_pde_Mesh_hxx
#include "pde_Mesh.hxx"
#endif
#ifndef included_pde_MeshColl_hxx
#include "pde_MeshColl.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter._includes)

  // Insert-UserCode-Here {pde.viewers.MeshPrinter._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(pde.viewers.MeshPrinter._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.viewers.MeshPrinter._includes)

#include <iomanip> 

  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::viewers::MeshPrinter_impl::MeshPrinter_impl() : StubBase(reinterpret_cast< 
  void*>(::pde::viewers::MeshPrinter::_wrapObj(reinterpret_cast< void*>(this))),
  false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter._ctor2)
  // Insert-Code-Here {pde.viewers.MeshPrinter._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter._ctor2)
}

// user defined constructor
void pde::viewers::MeshPrinter_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter._ctor)
    
  // Insert-UserCode-Here {pde.viewers.MeshPrinter._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(pde.viewers.MeshPrinter._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.viewers.MeshPrinter: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.viewers.MeshPrinter._ctor)

  // Insert-UserCode-Here {pde.viewers.MeshPrinter._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter._ctor)
}

// user defined destructor
void pde::viewers::MeshPrinter_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter._dtor)
  // Insert-UserCode-Here {pde.viewers.MeshPrinter._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.viewers.MeshPrinter._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.viewers.MeshPrinter: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.viewers.MeshPrinter._dtor) 

  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter._dtor)
}

// static class initializer
void pde::viewers::MeshPrinter_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter._load)
  // Insert-Code-Here {pde.viewers.MeshPrinter._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
pde::viewers::MeshPrinter_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.viewers.MeshPrinter.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "pde.viewers.MeshPrinter: Error casting self to gov::cca::Port");
  } 


  // Provide a pde.RenderPort port with port name printer 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "printer", // port instance name
                   "pde.RenderPort",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "pde.viewers.MeshPrinter: Error calling addProvidesPort(port,"
        "\"printer\", \"pde.RenderPort\", typeMap) ", -2);
    throw;
  }    

  // Provide a pde.NamedPatchPort port with port name dump 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "dump", // port instance name
                   "pde.NamedPatchPort",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "pde.viewers.MeshPrinter: Error calling addProvidesPort(port,"
        "\"dump\", \"pde.NamedPatchPort\", typeMap) ", -2);
    throw;
  }    

  // Use a gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    this->d_services.registerUsesPort(
                   "ppf", // port instance name
                   "gov.cca.ports.ParameterPortFactory",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.viewers.MeshPrinter: Error calling registerUsesPort(\"ppf\", "
       "\"gov.cca.ports.ParameterPortFactory\", typeMap) ", -2);
    throw;
  }


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(pde.viewers.MeshPrinter.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
pde::viewers::MeshPrinter_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.viewers.MeshPrinter.boccaReleaseServices)
  this->d_services=0;


  // Un-provide pde.RenderPort port with port name printer 
  try{
    services.removeProvidesPort("printer");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.viewers.MeshPrinter: Error calling removeProvidesPort("
              << "\"printer\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Un-provide pde.NamedPatchPort port with port name dump 
  try{
    services.removeProvidesPort("dump");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.viewers.MeshPrinter: Error calling removeProvidesPort("
              << "\"dump\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    services.unregisterUsesPort("ppf");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.viewers.MeshPrinter: Error calling unregisterUsesPort("
              << "\"ppf\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(pde.viewers.MeshPrinter.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::viewers::MeshPrinter_impl::boccaForceUsePortInclude_impl (
  /* in */::gov::cca::ports::ParameterPortFactory dummy0,
  /* in */::bsl::arr dummy1 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.viewers.MeshPrinter.boccaForceUsePortInclude)
    (void)dummy0;
    (void)dummy1;

  // Bocca generated code. bocca.protected.end(pde.viewers.MeshPrinter.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
pde::viewers::MeshPrinter_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter.setServices)

  // Insert-UserCode-Here{pde.viewers.MeshPrinter.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(pde.viewers.MeshPrinter.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(pde.viewers.MeshPrinter.setServices)
  
  // Insert-UserCode-Here{pde.viewers.MeshPrinter.setServices:epilog}

  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
pde::viewers::MeshPrinter_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter.releaseServices)

  // Insert-UserCode-Here {pde.viewers.MeshPrinter.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(pde.viewers.MeshPrinter.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(pde.viewers.MeshPrinter.releaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter.releaseServices)
}

/**
 * Method:  setOutput[]
 */
void
pde::viewers::MeshPrinter_impl::setOutput_impl (
  /* in */const ::std::string& destination ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter.setOutput)
	fname = destination;
  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter.setOutput)
}

/**
 * Method:  setIncludeBoundaries[]
 */
void
pde::viewers::MeshPrinter_impl::setIncludeBoundaries_impl (
  /* in */int32_t useBounds ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter.setIncludeBoundaries)
  // Insert-Code-Here {pde.viewers.MeshPrinter.setIncludeBoundaries} (setIncludeBoundaries method)
    
    // DO-DELETE-WHEN-IMPLEMENTING exception.begin()
    /*
     * This method has not been implemented
     */
    ::sidl::NotImplementedException ex = ::sidl::NotImplementedException::_create();
    ex.setNote("This method has not been implemented");
    ex.add(__FILE__, __LINE__, "setIncludeBoundaries");
    throw ex;
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter.setIncludeBoundaries)
}

/**
 * Method:  setAnimateImages[]
 */
void
pde::viewers::MeshPrinter_impl::setAnimateImages_impl (
  /* in */int32_t animateFrames ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter.setAnimateImages)
  // Insert-Code-Here {pde.viewers.MeshPrinter.setAnimateImages} (setAnimateImages method)
    
    // DO-DELETE-WHEN-IMPLEMENTING exception.begin()
    /*
     * This method has not been implemented
     */
    ::sidl::NotImplementedException ex = ::sidl::NotImplementedException::_create();
    ex.setNote("This method has not been implemented");
    ex.add(__FILE__, __LINE__, "setAnimateImages");
    throw ex;
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter.setAnimateImages)
}

/**
 * Method:  showMesh[]
 */
void
pde::viewers::MeshPrinter_impl::showMesh_impl (
  /* in */::pde::Mesh m ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter.showMesh)
  
	if (fname.length() < 1) {
		fname = "pde.viewers.MeshPrinter.showMesh.out";
	}

	// add in proc num to the filename
	int32_t num = m.getProcId();
	char snum[32];
	sprintf(snum,".%d",num);
	fname += snum;

	std::fstream f( fname.c_str(),  std::fstream::out );
	std::cout << "Writing mesh to " << fname << std::endl;
	int dim = m.getDimension();
   	f <<  "Dimension: " << dim << std::endl;
	sidl::array< int32_t > shape = m.getShape();
	sidl::array< double > distances = m.getDistances();
	f <<  "Shape/distance: " ;
	for (int i = 0; i < dim; i++) {
		f << "[" << shape[i] << "]";
	}
	for (int i = 0; i < dim; i++) {
		f << "[" << distances[i] << "]";
	}
	f << std::endl;
   	f <<  "BoundaryWidth: " << m.getBoundaryWidth() << std::endl;
   	f <<  "SpaceStencil: " << m.getSpaceStencil() << std::endl;
	int32_t tlow, thigh;
	m.getTimeRange(tlow, thigh);
   	f <<  "TimeRange: " << tlow << " , " << thigh << std::endl;
	f << "CurrentTime: " << m.currentTime() << std::endl;
	f << "StepsCompleted: " << m.stepsCompleted() << std::endl;
	f << "ProcID: " << m.getProcId() << std::endl;

	sidl::array< std::string > names = m.getFieldNames();
	int len = names.upper(0);
	for (int i = 0; i <= len; i++) {
		f <<  "FieldVar: " << names[i] << std::endl;
	}
	
	sidl::array< int64_t > gids = m.getPatchIds();
	sidl::array< int32_t > point = sidl::array< int32_t >::create1d(3);
	for (int i= 0; i < dim; i++) {
		point.set(i,3); // check 3,3,3 for containment.
	}
	for (int i=gids.lower(0); i <= gids.upper(0); i++) {

		int64_t np = gids[i];
		pde::Patch p = m.getPatch(np);
		f << "Patch " << np << "(" << p.getGlobalId() << ") ";
		int32_t pdim = p.getDimension();
		sidl::array< int32_t > first = p.getFirstIndices();
		sidl::array< int32_t > last = p.getLastIndices();
		sidl::array< int32_t > lens = p.getLengths();
		f <<  pdim << "D: ";
		for (int j= 0; j < pdim; j++) {
			f <<  "[" << first[j] << ".." << last[j] << "|" << lens[j] <<"]";
		}
		f <<  " contains 3: " << p.contains(point) << std::endl;
		f << "getxyz:        [" << p.getXBegin() << ".." << p.getXEnd() <<"|" << p.getXLen() <<"]";
		if (pdim >1) {
			f << "[" << p.getYBegin() << ".." << p.getYEnd() << "|" << p.getYLen() << "]";
		}
		if (pdim >2) {
			f << "[" << p.getZBegin() << ".." << p.getZEnd() <<"|" << p.getZLen() <<"]";
		}
		f << std::endl;
		f << "Bounding sides:" ;
		sidl::array< pde::BoundPos > directions = p.getBoundaryDirections();
		//sidl::array< int64_t > directions = p.getBoundaryDirections();
		if (directions._not_nil()) {
			for (int k = 0; k <= directions.upper(0); k++) {
				f << " " << directions[k] ;
			}
		} else {
			f << "none" ; 
		}
		f << std::endl;
		f << " Neighbors LOW0 " <<
			bsl::arr::str(p.getNeighborIds(pde::BoundPos_LOW0)) << 
			" HIGH0 " <<  bsl::arr::str(p.getNeighborIds(pde::BoundPos_HIGH0));
		if (pdim >1) {
		f <<  " LOW1 " <<
			bsl::arr::str(p.getNeighborIds(pde::BoundPos_LOW1)) << 
			" HIGH1 " <<  bsl::arr::str(p.getNeighborIds(pde::BoundPos_HIGH1));
		}
		if (pdim >2) {
		f <<  " LOW2 " <<
			bsl::arr::str(p.getNeighborIds(pde::BoundPos_LOW2)) << 
			" HIGH2 " <<  bsl::arr::str(p.getNeighborIds(pde::BoundPos_HIGH2));
		}
		f << std::endl;

	}
	
	std::cout << "Closing " << fname << std::endl;
	f.close();

  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter.showMesh)
}

/**
 * Method:  showField[]
 */
void
pde::viewers::MeshPrinter_impl::showField_impl (
  /* in */::pde::Mesh m,
  /* in */::pde::FieldVar fv ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter.showField)
	if (fname.length() < 1) {
		fname = "pde.viewers.MeshPrinter.showField.out";
	}

	// add in proc num to the filename
	int32_t num = m.getProcId();
	char snum[32];
	sprintf(snum,".%d",num);
	fname += snum;

	std::fstream f( fname.c_str(),  std::fstream::out );
	std::cout << "Writing fieldvar to " << fname << std::endl;
	int32_t dim = fv.getDimension();
	int32_t nvars = fv.getNVars();
	int32_t pcount = fv.getRegionCount();
   	f <<  "Name: " << fv.getName() << std::endl;
   	f <<  "Dimension: " << dim << std::endl;
   	f <<  "NVars: " << nvars << std::endl;
   	f <<  "BoundaryWidth: " << fv.getBoundaryWidth() << std::endl;
   	f <<  "MeshColl: " << fv.getMeshColl() << std::endl;
	int32_t tlow, thigh;
	m.getTimeRange(tlow, thigh);
   	f <<  "TimeRange: " << tlow << " , " << thigh << std::endl;
	int32_t ct = fv.getCurrentTime();
	f << "CurrentTime: " << ct << std::endl;
	f << "StepsCompleted: " << m.stepsCompleted() << std::endl;
	for (int32_t k=0; k < pcount; k++) {
		f << "Region " << k << " data" << std::endl;
		sidl::array< int32_t > lens = fv.getShape(k);
		f <<  "Shape: " ;
		for (int i = 0; i < dim; i++) {
			f << "[" << lens[i] << "]";
		}
		sidl::array< int32_t > first = fv.getLowerCorner(k);
		sidl::array< int32_t > last = fv.getUpperCorner(k);
		for (int32_t j= 0; j < dim; j++) {
			f <<  "[" << first[j] << ".." << last[j] << "|" << lens[j] <<"]";
		}
		f <<  std::endl;
		sidl::array< double > data = fv.getData( ct, k);
		int32_t dmax = data.upper(0);
		int32_t coord[3];
		int64_t volume = m.shapeVolume(lens);
		for (int d = data.lower(0); d <= dmax; d++) {
			f << "[" << d << "] = " << /* std::showpoint << std::fixed << */ data[d] << " cell coord = " ;
			// std::cout << "[" << d << "] = " << /* std::showpoint << std::fixed << */ data[d] << " cell coord = " ;
			int32_t nvar = d / volume;
			fv.indexToCoord(d, first, last, coord[0], coord[1], coord[2]);
			int32_t c2i = fv.coordToIndex(nvar, first, last, coord[0], coord[1], coord[2]);
			for (int q = 0; q < dim; q++) {
				f << "[" << coord[q] << "]" ;
				std::cout << "[" << coord[q] << "]" ;
			}
			f << " cell index = " << c2i << " nvar=" << nvar;
			std::cout << " cell index = " << c2i << " nvar=" << nvar;
			f << std::endl;
			std::cout << std::endl;
		}
		f <<  std::endl;
		std::cout <<  std::endl;
	}
	f << std::endl;
	std::cout << std::endl;
	    
  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter.showField)
}

/**
 * Method:  setData[]
 */
int32_t
pde::viewers::MeshPrinter_impl::setData_impl (
  /* in */int32_t ndim,
  /* in array<double> */::sidl::array<double> dataNamed,
  /* in array<int> */::sidl::array<int32_t> lowerCorner,
  /* in array<int> */::sidl::array<int32_t> upperCorner,
  /* in array<int> */::sidl::array<int32_t> shape,
  /* in */int32_t nvars,
  /* in */::pde::MeshColl mc,
  /* in */const ::std::string& name ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter.setData)
	(void) ndim;
	(void)dataNamed;
	(void)lowerCorner;
	(void)upperCorner;
	(void)shape;
	(void)nvars;
	(void) mc;
	nppfname = name;
	// std::fstream f( nppfname.c_str(),  std::fstream::out );
	std::cout << "logging to" << nppfname << std::endl;
	return 0;
  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter.setData)
}

/**
 * Method:  compute[]
 */
int32_t
pde::viewers::MeshPrinter_impl::compute_impl (
  /* in */int32_t ndim,
  /* in array<double> */::sidl::array<double> data1,
  /* in array<int> */::sidl::array<int32_t> lowerCorner,
  /* in array<int> */::sidl::array<int32_t> upperCorner,
  /* in array<int> */::sidl::array<int32_t> shape,
  /* in */int32_t nvars,
  /* in */::pde::MeshColl mc,
  /* inout array<double> */::sidl::array<double>& data2 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter.compute)
	int32_t bottom, top, i;
	top = data1.upper(0);
	bottom = data1.lower(0);
	std::ofstream f( nppfname.c_str(),  std::ios::app );
	std::cout << "Writing mesh to " << nppfname << std::endl;
	f << "START" << std::endl;
	for (i = bottom; i <= top; i++) {
		f << "[" << i << "]  data1: " << /* std::showpoint << std::fixed << */ data1[i] << " data2 " << data2[i] << std::endl;
	}
	f.close();
  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter.compute)
}

/**
 * Set extra data for processing several patches of the same sort.
 * @param boundaryWidth something
 * @param stencil_radius something else
 * @param meshShape mesh size in each dimension (excludes boundaries).
 * @param delta grid spacing in each dimension (uniform cell size assumed).
 */
int32_t
pde::viewers::MeshPrinter_impl::setComputeInfoUniform_impl (
  /* in */int32_t boundaryWidth,
  /* in */int32_t stencil_radius,
  /* in array<int> */::sidl::array<int32_t> meshShape,
  /* in array<double> */::sidl::array<double> delta ) 
{
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter.setComputeInfoUniform)
  (void) boundaryWidth;
  (void)stencil_radius;
  (void)meshShape;
  (void) delta;
  return 0;
    
  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter.setComputeInfoUniform)
}

/**
 * A method to indicate that all state set by set can now be forgotten 
 */
void
pde::viewers::MeshPrinter_impl::clearData_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter.clearData)
  // DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter.clearData)
}


// DO-NOT-DELETE splicer.begin(pde.viewers.MeshPrinter._misc)

// DO-NOT-DELETE splicer.end(pde.viewers.MeshPrinter._misc)

