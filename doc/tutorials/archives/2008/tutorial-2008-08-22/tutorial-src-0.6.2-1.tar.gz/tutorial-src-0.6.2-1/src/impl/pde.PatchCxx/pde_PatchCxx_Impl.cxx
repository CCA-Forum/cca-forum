// 
// File:          pde_PatchCxx_Impl.cxx
// Symbol:        pde.PatchCxx-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.PatchCxx
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_PatchCxx_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_bsl_arr_hxx
#include "bsl_arr.hxx"
#endif
#ifndef included_pde_BoundPos_hxx
#include "pde_BoundPos.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx._includes)

  // Insert-UserCode-Here {pde.PatchCxx._includes:prolog} (additional includes or code)
#include <iostream>
#include <sstream>
#include <string>

  // Bocca generated code. bocca.protected.begin(pde.PatchCxx._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.PatchCxx._includes)

  // Insert-UserCode-Here {pde.PatchCxx._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.PatchCxx._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::PatchCxx_impl::PatchCxx_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::PatchCxx::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx._ctor2)
  // Insert-Code-Here {pde.PatchCxx._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.PatchCxx._ctor2)
}

// user defined constructor
void pde::PatchCxx_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx._ctor)
    
	b_dim = -1;
	b_firstIndices = b_lastIndices = b_lengths = 0;
	allocationSet = false;

// a macro to return (presumably doing nothing) if a range is reversed.
// 
#define B_INIT_RANGE_OK(lo, hi) if (lo > hi) return

  // bocca-default-code. User may edit or delete.begin(pde.PatchCxx._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.PatchCxx: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.PatchCxx._ctor)


  // DO-NOT-DELETE splicer.end(pde.PatchCxx._ctor)
}

// user defined destructor
void pde::PatchCxx_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx._dtor)
    
  // bocca-default-code. User may edit or delete.begin(pde.PatchCxx._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.PatchCxx: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 

	if (b_dim >= 0) {
		b_dim = -2;
		delete [] b_firstIndices;
		delete [] b_lastIndices;
		delete [] b_lengths;
	}
  // DO-NOT-DELETE splicer.end(pde.PatchCxx._dtor)
}

// static class initializer
void pde::PatchCxx_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx._load)
  nextid = 0;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx._load)
}

// user defined static methods:
/**
 * Method:  nextId[]
 */
int64_t
pde::PatchCxx_impl::nextId_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.nextId)
	++nextid; // should probably check for nextid==maxlong and die if the counter rolls over
	return nextid;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.nextId)
}


// user defined non-static methods:
/**
 * Method:  init1d[]
 */
void
pde::PatchCxx_impl::init1d_impl (
  /* in */int64_t id,
  /* in */int32_t procid,
  /* in */int32_t low0,
  /* in */int32_t high0 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.init1d)
	B_INIT_RANGE_OK(low0,high0);
	b_dim = 1;
	b_id = id;
	b_procid = procid;
	b_allocate();
	b_firstIndices[0] = low0;
	b_lastIndices[0] = high0;
	b_lengths[0] = high0 - low0 + 1;
    
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.init1d)
}

/**
 * Method:  init2d[]
 */
void
pde::PatchCxx_impl::init2d_impl (
  /* in */int64_t id,
  /* in */int32_t procid,
  /* in */int32_t low0,
  /* in */int32_t high0,
  /* in */int32_t low1,
  /* in */int32_t high1 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.init2d)
	B_INIT_RANGE_OK(low0,high0);
	b_dim = 2;
	b_id = id;
	b_procid = procid;
	b_allocate();

	b_firstIndices[0] = low0;
	b_lastIndices[0] = high0;
	b_lengths[0] = high0 - low0 + 1;

	b_firstIndices[1] = low1;
	b_lastIndices[1] = high1;
	b_lengths[1] = high1 - low1 + 1;

    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.init2d)
}

/**
 * Method:  init3d[]
 */
void
pde::PatchCxx_impl::init3d_impl (
  /* in */int64_t id,
  /* in */int32_t procid,
  /* in */int32_t low0,
  /* in */int32_t high0,
  /* in */int32_t low1,
  /* in */int32_t high1,
  /* in */int32_t low2,
  /* in */int32_t high2 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.init3d)
	B_INIT_RANGE_OK(low0,high0);
	b_dim = 3;
	b_id = id;
	b_procid = procid;
	b_allocate();

	b_firstIndices[0] = low0;
	b_lastIndices[0] = high0;
	b_lengths[0] = high0 - low0 + 1;

	b_firstIndices[1] = low1;
	b_lastIndices[1] = high1;
	b_lengths[1] = high1 - low1 + 1;

	b_firstIndices[2] = low2;
	b_lastIndices[2] = high2;
	b_lengths[2] = high2 - low2 + 1;
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.init3d)
}

/**
 * Method:  addBoundary[]
 */
void
pde::PatchCxx_impl::addBoundary_impl (
  /* in */::pde::BoundPos direction ) 
{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.addBoundary)
	boundaries.push_back(direction);
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.addBoundary)
}

/**
 * Method:  addNeighbor[]
 */
void
pde::PatchCxx_impl::addNeighbor_impl (
  /* in */::pde::BoundPos direction,
  /* in */int64_t nid ) 
{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.addNeighbor)
	switch(direction) {
	case ::pde::BoundPos_HIGH0:
		nids[NHI0].push_back(nid);
		break;
	case ::pde::BoundPos_HIGH1:
		nids[NHI1].push_back(nid);
		break;
	case ::pde::BoundPos_HIGH2:
		nids[NHI2].push_back(nid);
		break;
	case ::pde::BoundPos_LOW0:
		nids[NLO0].push_back(nid);
		break;
	case ::pde::BoundPos_LOW1:
		nids[NLO1].push_back(nid);
		break;
	case ::pde::BoundPos_LOW2:
		nids[NLO2].push_back(nid);
		break;
	default:
		BOCCA_THROW_CXX(sidl::SIDLException, BOOST_CURRENT_FUNCTION ": bad direction given.");
	}
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.addNeighbor)
}

/**
 * Method:  setProcId[]
 */
void
pde::PatchCxx_impl::setProcId_impl (
  /* in */int32_t id ) 
{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.setProcId)
	b_procid = id;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.setProcId)
}

/**
 * Method:  size[]
 */
int32_t
pde::PatchCxx_impl::size_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.size)
	int32_t size = b_lengths[0];
	for(int i=1; i<b_dim; i++) {
		size = size * b_lengths[i];
	}
	return size;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.size)
}

/**
 * Method:  toString[]
 */
::std::string
pde::PatchCxx_impl::toString_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.toString)
   // String result = new String("Box "+b_dim+"D{first: "+ArrayUtil.toString(b_firstIndices)+"}{last: "+ArrayUtil.toString(b_lastIndices)+"}{len: "+ArrayUtil.toString(b_lengths)+"}");
	std::stringstream ss;
	ss << "Box " << b_dim << 
		"D{first: " << bsl::arr::toStringC(b_firstIndices, b_dim, bsl::datatype_intArray) <<
		"}{last: " << bsl::arr::toStringC(b_lastIndices, b_dim, bsl::datatype_intArray) <<
		"}{len:  " << bsl::arr::toStringC(b_lengths, b_dim, bsl::datatype_intArray) <<
		"}";
	std::string s = ss.str();
	return s;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.toString)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::PatchCxx_impl::boccaForceUsePortInclude_impl (
  /* in */::bsl::arr dummy0 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.PatchCxx.boccaForceUsePortInclude)
    (void)dummy0;

  // Bocca generated code. bocca.protected.end(pde.PatchCxx.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.boccaForceUsePortInclude)
}

/**
 *  Get the number of dimensions on this box (1..3).
 * @return the size of arrays that will be returned by
 * get[[[First,Last]Indices],[[Before,After]GhostSizes]]
 */
int32_t
pde::PatchCxx_impl::getDimension_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getDimension)
	return b_dim;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getDimension)
}

/**
 *  Get the lowest index of valid (patch-owned) data
 * (in global index space) for each dimension. 
 * @return the first indices of this block.
 */
::sidl::array<int32_t>
pde::PatchCxx_impl::getFirstIndices_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getFirstIndices)
	if (! b_firstIndices) {
		BOCCA_THROW_CXX(sidl::SIDLException, " null b_firstIndices in pde.PatchCxx.getFirstIndices");
	}
	sidl::array< int32_t > result = sidl::array< int32_t >::create1d(b_dim);
	bsl::arr::loadC(result, b_firstIndices, b_dim, bsl::datatype_intArray);
	return result;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getFirstIndices)
}

/**
 *  Get the highest index of valid (patch-owned) data
 * (in global index space) for each dimension. 
 * @return the last indices of this block. 
 */
::sidl::array<int32_t>
pde::PatchCxx_impl::getLastIndices_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getLastIndices)
	if (! b_lastIndices) {
		BOCCA_THROW_CXX(sidl::SIDLException, " null b_lastIndices in pde.PatchCxx.getLastIndices");
	}
	::sidl::array<int32_t> result = ::sidl::array<int32_t>::create1d(b_dim);
	bsl::arr::load1(result, b_lastIndices, b_dim);
	return result;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getLastIndices)
}

/**
 *  Get the length (number of cells) in each dimension.
 * @return the size of this cell block. 
 */
::sidl::array<int32_t>
pde::PatchCxx_impl::getLengths_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getLengths)
	::sidl::array<int32_t> result = ::sidl::array<int32_t>::create1d(b_dim);
	bsl::arr::load1(result, b_lengths, b_dim);
	return result;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getLengths)
}

/**
 *  test coordinate p for being in the space defined
 * by the box.
 * @param p an array of indices of the same or lower
 * dimensionality as the box.
 * @return true if p contained in box.
 */
bool
pde::PatchCxx_impl::contains_impl (
  /* in array<int> */::sidl::array<int32_t> p ) 
{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.contains)
	if (p._is_nil()) {
		return false;
	}
	if (p.length(0) < b_dim || p.lower(0) != 0) {
		std::cout << "Dimension range error in patch query." << std::endl;
		std::cout << "b_dim: " << b_dim << " upper " << p.upper(0) << " lower " << p.lower(0) << std::endl;
		BOCCA_THROW_CXX(::sidl::SIDLException, "Dimension range error in patch query.");
	}
	for (int32_t d = 0; d < b_dim; d++) {
		if (p[d] > b_lastIndices[d] || p[d] < b_firstIndices[d])
		{
			return false;
		}
	}
	return true;

  // DO-NOT-DELETE splicer.end(pde.PatchCxx.contains)
}

/**
 *  alternate way of getting firstIndices[0]. 
 */
int32_t
pde::PatchCxx_impl::getXBegin_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getXBegin)
	if (b_dim >= 1) {
		return b_firstIndices[0];
	}
	BOCCA_THROW_CXX(::sidl::SIDLException, "Dimension range error in patch query.");
	return -1;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getXBegin)
}

/**
 *  alternate way of getting lastIndices[0]. 
 */
int32_t
pde::PatchCxx_impl::getXEnd_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getXEnd)
	if (b_dim >= 1) {
		return b_lastIndices[0];
	}
	BOCCA_THROW_CXX(::sidl::SIDLException, "Dimension range error in patch query.");
	return -1;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getXEnd)
}

/**
 *  alternate way of getting firstIndices[1].
 */
int32_t
pde::PatchCxx_impl::getYBegin_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getYBegin)
	if (b_dim >= 2) {
		return b_firstIndices[1];
	}
	BOCCA_THROW_CXX(::sidl::SIDLException, "Dimension range error in patch query.");
	return -1;
    
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getYBegin)
}

/**
 *  alternate way of getting lastIndices[1] 
 */
int32_t
pde::PatchCxx_impl::getYEnd_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getYEnd)
	if (b_dim >= 2) {
		return b_lastIndices[1];
	}
	BOCCA_THROW_CXX(::sidl::SIDLException, "Dimension range error in patch query.");
	return -1;
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getYEnd)
}

/**
 *  alternate way of getting firstIndices[2] 
 */
int32_t
pde::PatchCxx_impl::getZBegin_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getZBegin)
	if (b_dim >= 3) {
		return b_firstIndices[2];
	}
	BOCCA_THROW_CXX(::sidl::SIDLException, "Dimension range error in patch query.");
	return -1;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getZBegin)
}

/**
 *  alternate way of getting lastIndices[2]
 */
int32_t
pde::PatchCxx_impl::getZEnd_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getZEnd)
	if (b_dim >= 3) {
		return b_lastIndices[2];
	}
    
	BOCCA_THROW_CXX(::sidl::SIDLException, "Dimension range error in patch query.");
	return -1;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getZEnd)
}

/**
 *  alternate way of getting lengths[0]. 
 */
int32_t
pde::PatchCxx_impl::getXLen_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getXLen)
	if (b_dim >= 1) {
		return b_lengths[0];
	}
	BOCCA_THROW_CXX(::sidl::SIDLException, "Dimension range error in patch query.");
	return -1;
    
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getXLen)
}

/**
 *  alternate way of getting lengths[1].
 */
int32_t
pde::PatchCxx_impl::getYLen_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getYLen)
	if (b_dim >= 2) {
		return b_lengths[1];
	}
	BOCCA_THROW_CXX(::sidl::SIDLException, "Dimension range error in patch query.");
	return -1;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getYLen)
}

/**
 *  alternate way of getting lengths[2]
 */
int32_t
pde::PatchCxx_impl::getZLen_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getZLen)
	if (b_dim >= 3) {
		return b_lengths[2];
	}
	BOCCA_THROW_CXX(::sidl::SIDLException, "Dimension range error in patch query.");
	return -1;
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getZLen)
}

/**
 * Query which edges are coincident with the domain 
 * boundary.
 * 
 * @return an array with as many elements as there are boundary edges,
 * or a nil array if there are no boundaries on the patch.
 * The array will be indexed from 0.
 */
::sidl::array< ::pde::BoundPos>
pde::PatchCxx_impl::getBoundaryDirections_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getBoundaryDirections)
	::sidl::array< ::pde::BoundPos > result;
	//::sidl::array< int64_t > result;
	int n = (int)(boundaries.size());
	if (n > 0) {
		result = ::sidl::array< ::pde::BoundPos>::create1d(n);
		// result = ::sidl::array< int64_t >::create1d(n);
		for (int i = 0; i < n; i++) {
			// result.set(i, static_cast< int64_t > (boundaries[i]));
			result.set(i, boundaries[i]);
		}
	}
	return result;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getBoundaryDirections)
}

/**
 * Get the corners of the boundary region in the given direction.
 * Throws an exception if the direction is not a boundary.
 * @param direction the side of the patch of interest.
 * @param lower the lower bound corner of the answer.
 * @param upper the upper bound corner of the answer.
 */
void
pde::PatchCxx_impl::getBoundaryIntersection_impl (
  /* in */::pde::BoundPos direction,
  /* inout array<int> */::sidl::array<int32_t>& lower,
  /* inout array<int> */::sidl::array<int32_t>& upper ) 
{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getBoundaryIntersection)
	std::vector< pde::BoundPos >::iterator loc;
	loc = find(boundaries.begin(), boundaries.end(), direction);
	if ( loc == boundaries.end() ) {
		BOCCA_THROW_CXX( sidl::SIDLException, "pde.PatchCxx.getBoundaryIntersection miscalled.");
	}
	switch (direction) { // also need to handle b_dim.
	case pde::BoundPos_LOW0:
	case pde::BoundPos_HIGH0:
	case pde::BoundPos_LOW1:
	case pde::BoundPos_HIGH1:
	case pde::BoundPos_LOW2:
	case pde::BoundPos_HIGH2:
	default:
		break;
	}
	bsl::arr::fill(lower, 0);
	bsl::arr::fill(upper, 0);
	// FIXME pde.PatchCxx.getBoundaryIntersection completely bogus

  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getBoundaryIntersection)
}

/**
 * Get the patch ids of neighbors in a direction; often there is just one,
 * but there may be more.
 * 
 * @param boundaryType element of BoundPos for the direction desired.
 * @return the ids in a particular direction.
 */
::sidl::array<int64_t>
pde::PatchCxx_impl::getNeighborIds_impl (
  /* in */::pde::BoundPos boundaryType ) 
{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getNeighborIds)

	int32_t index;
	switch(boundaryType) {
	case ::pde::BoundPos_HIGH0:
		index = NHI0;
		break;
	case ::pde::BoundPos_HIGH1:
		index = NHI1;
		break;
	case ::pde::BoundPos_HIGH2:
		index = NHI2;
		break;
	case ::pde::BoundPos_LOW0:
		index = NLO0;
		break;
	case ::pde::BoundPos_LOW1:
		index = NLO1;
		break;
	case ::pde::BoundPos_LOW2:
		index = NLO2;
		break;
	default:
		BOCCA_THROW_CXX(sidl::SIDLException, BOOST_CURRENT_FUNCTION ": bad direction given.");
	}
	int32_t len = (int32_t)(nids[index].size());

	::sidl::array<int64_t> p = ::sidl::array<int64_t>::create1d(len);
	::std::vector< int64_t > &v = nids[index];
	for (int i=0;i<len;i++) {
		p.set(i, v[i]);
	}
	return p;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getNeighborIds)
}

/**
 *  @return the global identifier of this patch with its domain. 
 */
int64_t
pde::PatchCxx_impl::getGlobalId_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getGlobalId)
	return b_id;
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getGlobalId)
}

/**
 *  @return the process id, in mpi rank terms, of the process which owns this patch's data arrays. 
 */
int32_t
pde::PatchCxx_impl::getProcId_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.PatchCxx.getProcId)
	return b_procid; 
  // DO-NOT-DELETE splicer.end(pde.PatchCxx.getProcId)
}


// DO-NOT-DELETE splicer.begin(pde.PatchCxx._misc)
bool
pde::PatchCxx_impl::b_allocate() {
	if (b_dim < 1) {
		return false;
	}
	if (b_dim > 7) {
		return false;
	}
        b_lengthsAllocated = new int32_t[b_dim];
        b_firstAllocated = new int32_t[b_dim];
        b_lastAllocated = new int32_t[b_dim];
	b_lengths = new int32_t[b_dim];
	b_firstIndices = new int32_t[b_dim];
	b_lastIndices = new int32_t[b_dim];
	for (int i=0;i < b_dim; i++) {
                b_lastAllocated[i] = -1;
                b_firstAllocated[i] = -1;
                b_lengthsAllocated[i] = -1;

		b_lastIndices[i] = -1;
		b_firstIndices[i] = -1;
		b_lengths[i] = -1;
	}
	if (b_lengths && b_firstIndices && b_lastIndices && b_lastAllocated && b_firstAllocated && b_lengthsAllocated) { return true; }
	return false; // and probably memory corrupted or seg fault.
}

int64_t
pde::PatchCxx_impl::nextid = -1;

// DO-NOT-DELETE splicer.end(pde.PatchCxx._misc)

