/*
 * File:          pde_ICcoordsC_Impl.h
 * Symbol:        pde.ICcoordsC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for pde.ICcoordsC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_pde_ICcoordsC_Impl_h
#define included_pde_ICcoordsC_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_gov_cca_CCAException_h
#include "gov_cca_CCAException.h"
#endif
#ifndef included_gov_cca_Component_h
#include "gov_cca_Component.h"
#endif
#ifndef included_gov_cca_ComponentRelease_h
#include "gov_cca_ComponentRelease.h"
#endif
#ifndef included_gov_cca_Port_h
#include "gov_cca_Port.h"
#endif
#ifndef included_gov_cca_Services_h
#include "gov_cca_Services.h"
#endif
#ifndef included_gov_cca_ports_ParameterPortFactory_h
#include "gov_cca_ports_ParameterPortFactory.h"
#endif
#ifndef included_pde_FieldVar_h
#include "pde_FieldVar.h"
#endif
#ifndef included_pde_ICPort_h
#include "pde_ICPort.h"
#endif
#ifndef included_pde_ICcoordsC_h
#include "pde_ICcoordsC.h"
#endif
#ifndef included_pde_Mesh_h
#include "pde_Mesh.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif

/* DO-NOT-DELETE splicer.begin(pde.ICcoordsC._includes) */
/* Insert-Code-Here {pde.ICcoordsC._includes} (include files) */
/* DO-NOT-DELETE splicer.end(pde.ICcoordsC._includes) */

/*
 * Private data for class pde.ICcoordsC
 */

struct pde_ICcoordsC__data {
  /* DO-NOT-DELETE splicer.begin(pde.ICcoordsC._data) */

  /* Bocca generated code. bocca.protected.begin(pde.ICcoordsC._data) */
  /* Handle to framework services object */
  gov_cca_Services d_services;
  /* Bocca generated code. bocca.protected.end(pde.ICcoordsC._data) */

  /* Put other private data members here... */

  /* DO-NOT-DELETE splicer.end(pde.ICcoordsC._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct pde_ICcoordsC__data*
pde_ICcoordsC__get_data(
  pde_ICcoordsC);

extern void
pde_ICcoordsC__set_data(
  pde_ICcoordsC,
  struct pde_ICcoordsC__data*);

extern
void
impl_pde_ICcoordsC__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_pde_ICcoordsC__ctor(
  /* in */ pde_ICcoordsC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_pde_ICcoordsC__ctor2(
  /* in */ pde_ICcoordsC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_pde_ICcoordsC__dtor(
  /* in */ pde_ICcoordsC self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct gov_cca_CCAException__object* 
  impl_pde_ICcoordsC_fconnect_gov_cca_CCAException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct gov_cca_CCAException__object* 
  impl_pde_ICcoordsC_fcast_gov_cca_CCAException(void* bi, sidl_BaseInterface* 
  _ex);
extern struct gov_cca_Component__object* 
  impl_pde_ICcoordsC_fconnect_gov_cca_Component(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct gov_cca_Component__object* 
  impl_pde_ICcoordsC_fcast_gov_cca_Component(void* bi, sidl_BaseInterface* _ex);
extern struct gov_cca_ComponentRelease__object* 
  impl_pde_ICcoordsC_fconnect_gov_cca_ComponentRelease(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_ComponentRelease__object* 
  impl_pde_ICcoordsC_fcast_gov_cca_ComponentRelease(void* bi, 
  sidl_BaseInterface* _ex);
extern struct gov_cca_Port__object* impl_pde_ICcoordsC_fconnect_gov_cca_Port(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_Port__object* impl_pde_ICcoordsC_fcast_gov_cca_Port(void* 
  bi, sidl_BaseInterface* _ex);
extern struct gov_cca_Services__object* 
  impl_pde_ICcoordsC_fconnect_gov_cca_Services(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct gov_cca_Services__object* 
  impl_pde_ICcoordsC_fcast_gov_cca_Services(void* bi, sidl_BaseInterface* _ex);
extern struct gov_cca_ports_ParameterPortFactory__object* 
  impl_pde_ICcoordsC_fconnect_gov_cca_ports_ParameterPortFactory(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_ports_ParameterPortFactory__object* 
  impl_pde_ICcoordsC_fcast_gov_cca_ports_ParameterPortFactory(void* bi, 
  sidl_BaseInterface* _ex);
extern struct pde_FieldVar__object* impl_pde_ICcoordsC_fconnect_pde_FieldVar(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct pde_FieldVar__object* impl_pde_ICcoordsC_fcast_pde_FieldVar(void* 
  bi, sidl_BaseInterface* _ex);
extern struct pde_ICPort__object* impl_pde_ICcoordsC_fconnect_pde_ICPort(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct pde_ICPort__object* impl_pde_ICcoordsC_fcast_pde_ICPort(void* bi, 
  sidl_BaseInterface* _ex);
extern struct pde_ICcoordsC__object* impl_pde_ICcoordsC_fconnect_pde_ICcoordsC(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct pde_ICcoordsC__object* impl_pde_ICcoordsC_fcast_pde_ICcoordsC(
  void* bi, sidl_BaseInterface* _ex);
extern struct pde_Mesh__object* impl_pde_ICcoordsC_fconnect_pde_Mesh(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct pde_Mesh__object* impl_pde_ICcoordsC_fcast_pde_Mesh(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_pde_ICcoordsC_fconnect_sidl_BaseClass(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_pde_ICcoordsC_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_pde_ICcoordsC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_pde_ICcoordsC_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_ClassInfo__object* 
  impl_pde_ICcoordsC_fconnect_sidl_ClassInfo(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_pde_ICcoordsC_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_pde_ICcoordsC_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_pde_ICcoordsC_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
extern
void
impl_pde_ICcoordsC_boccaSetServices(
  /* in */ pde_ICcoordsC self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_pde_ICcoordsC_boccaReleaseServices(
  /* in */ pde_ICcoordsC self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_pde_ICcoordsC_checkException(
  /* in */ pde_ICcoordsC self,
  /* in */ sidl_BaseInterface excpt,
  /* in */ const char* msg,
  /* in */ sidl_bool fatal,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_pde_ICcoordsC_boccaForceUsePortInclude(
  /* in */ pde_ICcoordsC self,
  /* in */ gov_cca_ports_ParameterPortFactory dummy0,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_pde_ICcoordsC_setServices(
  /* in */ pde_ICcoordsC self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_pde_ICcoordsC_releaseServices(
  /* in */ pde_ICcoordsC self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_pde_ICcoordsC_setInitialConditions(
  /* in */ pde_ICcoordsC self,
  /* inout array<pde.FieldVar> */ struct pde_FieldVar__array** vfv,
  /* in */ pde_Mesh m,
  /* out */ sidl_BaseInterface *_ex);

extern struct gov_cca_CCAException__object* 
  impl_pde_ICcoordsC_fconnect_gov_cca_CCAException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct gov_cca_CCAException__object* 
  impl_pde_ICcoordsC_fcast_gov_cca_CCAException(void* bi, sidl_BaseInterface* 
  _ex);
extern struct gov_cca_Component__object* 
  impl_pde_ICcoordsC_fconnect_gov_cca_Component(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct gov_cca_Component__object* 
  impl_pde_ICcoordsC_fcast_gov_cca_Component(void* bi, sidl_BaseInterface* _ex);
extern struct gov_cca_ComponentRelease__object* 
  impl_pde_ICcoordsC_fconnect_gov_cca_ComponentRelease(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_ComponentRelease__object* 
  impl_pde_ICcoordsC_fcast_gov_cca_ComponentRelease(void* bi, 
  sidl_BaseInterface* _ex);
extern struct gov_cca_Port__object* impl_pde_ICcoordsC_fconnect_gov_cca_Port(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_Port__object* impl_pde_ICcoordsC_fcast_gov_cca_Port(void* 
  bi, sidl_BaseInterface* _ex);
extern struct gov_cca_Services__object* 
  impl_pde_ICcoordsC_fconnect_gov_cca_Services(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct gov_cca_Services__object* 
  impl_pde_ICcoordsC_fcast_gov_cca_Services(void* bi, sidl_BaseInterface* _ex);
extern struct gov_cca_ports_ParameterPortFactory__object* 
  impl_pde_ICcoordsC_fconnect_gov_cca_ports_ParameterPortFactory(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_ports_ParameterPortFactory__object* 
  impl_pde_ICcoordsC_fcast_gov_cca_ports_ParameterPortFactory(void* bi, 
  sidl_BaseInterface* _ex);
extern struct pde_FieldVar__object* impl_pde_ICcoordsC_fconnect_pde_FieldVar(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct pde_FieldVar__object* impl_pde_ICcoordsC_fcast_pde_FieldVar(void* 
  bi, sidl_BaseInterface* _ex);
extern struct pde_ICPort__object* impl_pde_ICcoordsC_fconnect_pde_ICPort(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct pde_ICPort__object* impl_pde_ICcoordsC_fcast_pde_ICPort(void* bi, 
  sidl_BaseInterface* _ex);
extern struct pde_ICcoordsC__object* impl_pde_ICcoordsC_fconnect_pde_ICcoordsC(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct pde_ICcoordsC__object* impl_pde_ICcoordsC_fcast_pde_ICcoordsC(
  void* bi, sidl_BaseInterface* _ex);
extern struct pde_Mesh__object* impl_pde_ICcoordsC_fconnect_pde_Mesh(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct pde_Mesh__object* impl_pde_ICcoordsC_fcast_pde_Mesh(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_pde_ICcoordsC_fconnect_sidl_BaseClass(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* impl_pde_ICcoordsC_fcast_sidl_BaseClass(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_pde_ICcoordsC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_pde_ICcoordsC_fcast_sidl_BaseInterface(void* bi, sidl_BaseInterface* 
  _ex);
extern struct sidl_ClassInfo__object* 
  impl_pde_ICcoordsC_fconnect_sidl_ClassInfo(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* impl_pde_ICcoordsC_fcast_sidl_ClassInfo(
  void* bi, sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_pde_ICcoordsC_fconnect_sidl_RuntimeException(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_pde_ICcoordsC_fcast_sidl_RuntimeException(void* bi, sidl_BaseInterface* 
  _ex);
#ifdef __cplusplus
}
#endif
#endif
