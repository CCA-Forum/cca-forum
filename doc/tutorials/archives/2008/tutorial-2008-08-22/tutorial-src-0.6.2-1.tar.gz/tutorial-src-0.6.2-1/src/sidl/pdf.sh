#!/bin/sh
for i in *.sidl; do
	enscript -2r -Ejava $i -o $i.ps
	ps2pdf $i.ps
done
