// 
// File:          pde_Reaction_Impl.cxx
// Symbol:        pde.Reaction-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.Reaction
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_Reaction_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_gov_cca_ports_ParameterPortFactory_hxx
#include "gov_cca_ports_ParameterPortFactory.hxx"
#endif
#ifndef included_pde_MeshColl_hxx
#include "pde_MeshColl.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.Reaction._includes)

  // Insert-UserCode-Here {pde.Reaction._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(pde.Reaction._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.Reaction._includes)

  // Insert-UserCode-Here {pde.Reaction._includes:epilog} (additional includes or code)

  // DO-NOT-DELETE splicer.end(pde.Reaction._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::Reaction_impl::Reaction_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::Reaction::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(pde.Reaction._ctor2)
  // Insert-Code-Here {pde.Reaction._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.Reaction._ctor2)
}

// user defined constructor
void pde::Reaction_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.Reaction._ctor)
    
  // Insert-UserCode-Here {pde.Reaction._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(pde.Reaction._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.Reaction: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.Reaction._ctor)

  // Insert-UserCode-Here {pde.Reaction._ctor:epilog} (constructor method)
     qConstant_ = 0.01 ;
     fConstant_ = 0.3 ;
     epsilon_ = 1.0e-3 ;
     d_stencil_radius = 1;
  // DO-NOT-DELETE splicer.end(pde.Reaction._ctor)
}

// user defined destructor
void pde::Reaction_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.Reaction._dtor)
  // Insert-UserCode-Here {pde.Reaction._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(pde.Reaction._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.Reaction: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.Reaction._dtor) 

  // DO-NOT-DELETE splicer.end(pde.Reaction._dtor)
}

// static class initializer
void pde::Reaction_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.Reaction._load)
  // Insert-Code-Here {pde.Reaction._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.Reaction._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
pde::Reaction_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.Reaction.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.Reaction.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "pde.Reaction: Error casting self to gov::cca::Port");
  } 


  // Provide a pde.NamedPatchPort port with port name reaction 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "reaction", // port instance name
                   "pde.NamedPatchPort",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "pde.Reaction: Error calling addProvidesPort(port,"
        "\"reaction\", \"pde.NamedPatchPort\", typeMap) ", -2);
    throw;
  }    

  // Use a gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    this->d_services.registerUsesPort(
                   "ppf", // port instance name
                   "gov.cca.ports.ParameterPortFactory",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "pde.Reaction: Error calling registerUsesPort(\"ppf\", "
       "\"gov.cca.ports.ParameterPortFactory\", typeMap) ", -2);
    throw;
  }


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(pde.Reaction.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(pde.Reaction.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
pde::Reaction_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.Reaction.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.Reaction.boccaReleaseServices)
  this->d_services=0;


  // Un-provide pde.NamedPatchPort port with port name reaction 
  try{
    services.removeProvidesPort("reaction");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.Reaction: Error calling removeProvidesPort("
              << "\"reaction\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release gov.cca.ports.ParameterPortFactory port with port name ppf 
  try{
    services.unregisterUsesPort("ppf");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "pde.Reaction: Error calling unregisterUsesPort("
              << "\"ppf\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(pde.Reaction.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.Reaction.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::Reaction_impl::boccaForceUsePortInclude_impl (
  /* in */::gov::cca::ports::ParameterPortFactory dummy0 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.Reaction.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.Reaction.boccaForceUsePortInclude)
    (void)dummy0;

  // Bocca generated code. bocca.protected.end(pde.Reaction.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.Reaction.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
pde::Reaction_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.Reaction.setServices)

  // Insert-UserCode-Here{pde.Reaction.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(pde.Reaction.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(pde.Reaction.setServices)
  
  // Insert-UserCode-Here{pde.Reaction.setServices:epilog}

  // DO-NOT-DELETE splicer.end(pde.Reaction.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
pde::Reaction_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(pde.Reaction.releaseServices)

  // Insert-UserCode-Here {pde.Reaction.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(pde.Reaction.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(pde.Reaction.releaseServices)
    
  // DO-NOT-DELETE splicer.end(pde.Reaction.releaseServices)
}

/**
 * Method:  setData[]
 */
int32_t
pde::Reaction_impl::setData_impl (
  /* in */int32_t ndim,
  /* in array<double> */::sidl::array<double> dataNamed,
  /* in array<int> */::sidl::array<int32_t> lowerCorner,
  /* in array<int> */::sidl::array<int32_t> upperCorner,
  /* in array<int> */::sidl::array<int32_t> shape,
  /* in */int32_t nvars,
  /* in */::pde::MeshColl mc,
  /* in */const ::std::string& name ) 
{
  // DO-NOT-DELETE splicer.begin(pde.Reaction.setData)
	// nothing to do 
	return 0;
  // DO-NOT-DELETE splicer.end(pde.Reaction.setData)
}

/**
 * Method:  compute[]
 */
int32_t
pde::Reaction_impl::compute_impl (
  /* in */int32_t ndim,
  /* in array<double> */::sidl::array<double> data1,
  /* in array<int> */::sidl::array<int32_t> lowerCorner,
  /* in array<int> */::sidl::array<int32_t> upperCorner,
  /* in array<int> */::sidl::array<int32_t> shape,
  /* in */int32_t nvars,
  /* in */::pde::MeshColl mc,
  /* inout array<double> */::sidl::array<double>& data2 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.Reaction.compute)

    if (nvars != 3) {
	BOCCA_THROW_CXX(sidl::SIDLException, "Reaction compute called without nvars=3 variable");
    }

    int32_t nx = 1, ny = 1, nz = 1;
    int32_t ioffset = 0, joffset = 0, koffset = 0;
    int32_t starti = 0, endi = 0, startj = 0, endj = 0, startk = 0, endk = 0;
    
    starti = lowerCorner[0] + d_stencil_radius; endi = upperCorner[0] - d_stencil_radius; 
    nx = shape[0] ;
    ioffset = lowerCorner[0] ;
    
    if ( ndim > 1) 
    { 
	startj = lowerCorner[1] + d_stencil_radius ; endj = upperCorner[1] - d_stencil_radius ;
	ny = shape[1]; joffset = lowerCorner[1] ;
    }

    if ( ndim > 2) 
    { 
	startk = lowerCorner[2] + d_stencil_radius ; endk = upperCorner[2] - d_stencil_radius ;
	nz = shape[2]; koffset = lowerCorner[3] ;
    }

    // Now loop over all variables and diffuse
    int32_t line = nx ;
    int32_t slab = nx*ny ;
    int32_t vol  = nx*ny*nz ;

    // first initialize the incoming data2 to zero.
    for(int32_t i = 0; i < data2.length(0); i++) data2.set(i, 0.0) ;

    // Now loop over all variables and react. no grid positioning matters, but avoid boundaries.
    double oeps = 1.0 / epsilon_ ;
    for (int32_t k = startk; k <= endk; k++)
    {
	for (int32_t j = startj; j <= endj ; j++)
	{
	    for (int32_t i = starti; i <= endi ; i++) 
	    {
		int32_t iindex = i - ioffset ;
		int32_t jindex = j - joffset ;
		int32_t kindex = k - koffset ;
		int32_t index_v0 = iindex + nx*jindex + slab*kindex ;
		int32_t index_v1 = index_v0 + vol ;
		int32_t index_v2 = index_v1 + vol ;

		double v0 = data1[ index_v0 ];
		double v1 = data1[ index_v1 ];
		double v2 = data1[ index_v2 ];
	
		double r0 = 0.0 ; // Temperature does not change in a BZ reaction
		double v1_th = (v2 + qConstant_)/fConstant_ ;
		double r1 = oeps * ( v1*(1-v1)*(v1-v1_th) );
		double r2 = v1 - v2; // [Mox]
		
		data2.set(index_v0, r0 ) ;
		data2.set(index_v1, r1 ) ;
		data2.set(index_v2, r2 ) ;
	    } // end of loop over i
	} // End of loop over j
    } // End of loop over k
	    
    // DO-NOT-DELETE splicer.end(pde.Reaction.compute)
}
	
/**
 * Set extra data for processing several patches of the same sort.
 * @param boundaryWidth something
 * @param stencil_radius something else
 * @param meshShape mesh size in each dimension (excludes boundaries).
 * @param delta grid spacing in each dimension (uniform cell size assumed).
 */
int32_t
pde::Reaction_impl::setComputeInfoUniform_impl (
  /* in */int32_t boundaryWidth,
  /* in */int32_t stencil_radius,
  /* in array<int> */::sidl::array<int32_t> meshShape,
  /* in array<double> */::sidl::array<double> delta ) 
{
  // DO-NOT-DELETE splicer.begin(pde.Reaction.setComputeInfoUniform)
    d_stencil_radius = stencil_radius ;
  // DO-NOT-DELETE splicer.end(pde.Reaction.setComputeInfoUniform)
}

/**
 * A method to indicate that all state set by set can now be forgotten 
 */
void
pde::Reaction_impl::clearData_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.Reaction.clearData)
	// nothing to do.
  // DO-NOT-DELETE splicer.end(pde.Reaction.clearData)
}


// DO-NOT-DELETE splicer.begin(pde.Reaction._misc)
// Insert-Code-Here {pde.Reaction._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(pde.Reaction._misc)

