// 
// File:          pde_FieldVarCxx_Impl.cxx
// Symbol:        pde.FieldVarCxx-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for pde.FieldVarCxx
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "pde_FieldVarCxx_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_pde_BoundPos_hxx
#include "pde_BoundPos.hxx"
#endif
#ifndef included_pde_BoundaryCondition_hxx
#include "pde_BoundaryCondition.hxx"
#endif
#ifndef included_pde_Mesh_hxx
#include "pde_Mesh.hxx"
#endif
#ifndef included_pde_MeshColl_hxx
#include "pde_MeshColl.hxx"
#endif
#ifndef included_pde_Patch_hxx
#include "pde_Patch.hxx"
#endif
#ifndef included_pde_Region_hxx
#include "pde_Region.hxx"
#endif
#ifndef included_pde_RegionCxx_hxx
#include "pde_RegionCxx.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx._includes)

  // Insert-UserCode-Here {pde.FieldVarCxx._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(pde.FieldVarCxx._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(pde.FieldVarCxx._includes)

#define INITCHECK \
	if (!inited) \
	BOCCA_THROW_CXX(sidl::SIDLException, "function called before pde.FieldVarCxx.init called.");

#define PIDCHECK(patchId) \
	if (patchId < 0 || patchId >= regions.size()) { \
		BOCCA_THROW_CXX(sidl::SIDLException, "bad local region given"); \
	}
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
pde::FieldVarCxx_impl::FieldVarCxx_impl() : StubBase(reinterpret_cast< void*>(
  ::pde::FieldVarCxx::_wrapObj(reinterpret_cast< void*>(this))),false) , 
  _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx._ctor2)
  // Insert-Code-Here {pde.FieldVarCxx._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx._ctor2)
}

// user defined constructor
void pde::FieldVarCxx_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx._ctor)
    
  // Insert-UserCode-Here {pde.FieldVarCxx._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(pde.FieldVarCxx._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR pde.FieldVarCxx: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(pde.FieldVarCxx._ctor)

	inited = false;
	tcur = -1;
	fnvars = -1;
	coll = ::pde::MeshColl_ErrorMC;

  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx._ctor)
}

// user defined destructor
void pde::FieldVarCxx_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx._dtor)
  // Insert-UserCode-Here {pde.FieldVarCxx._dtor} (destructor method) 
    
#ifdef HAVE_MPI
    for(int i = 0; i < recvReqs_.size(); i++) delete recvReqs_[i] ;
    for(int i = 0; i < sendReqs_.size(); i++) delete sendReqs_[i] ;
    recvReqs_.clear() ;
    sendReqs_.clear() ;
#endif
  // bocca-default-code. User may edit or delete.begin(pde.FieldVarCxx._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR pde.FieldVarCxx: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(pde.FieldVarCxx._dtor) 

  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx._dtor)
}

// static class initializer
void pde::FieldVarCxx_impl::_load() {
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx._load)
  // Insert-Code-Here {pde.FieldVarCxx._load} (class initialization)
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  init[]
 */
void
pde::FieldVarCxx_impl::init_impl (
  /* in */const ::std::string& name,
  /* in */int32_t nvars,
  /* in */::pde::MeshColl T,
  /* in */::pde::BoundaryCondition bc,
  /* in */::pde::Mesh m,
  /* in array<pde.Patch> */::sidl::array< ::pde::Patch> localpatches ) 
{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.init)
	if (inited) {
		BOCCA_THROW_CXX(sidl::SIDLException, "pde.FieldVarCxx.init called twice on same object");
	}
	inited = true;
	forceReceives = false;
	tcur = 0;
	fname = name;
	fnvars = nvars;
	coll = T;
	mesh = m;
        boundary = bc;
	d_dim = m.getDimension();
	
	int32_t tl, th, sstencil, bwidth;
	m.getTimeRange(tl,th);
	d_stencil = sstencil = m.getSpaceStencil();
	bwidth = m.getBoundaryWidth();
	for (int i = localpatches.lower(0); i <= localpatches.upper(0); i++) {
		pde::RegionCxx r = pde::RegionCxx::_create();
		r.init(localpatches[i], sstencil, bwidth, fnvars, coll, tl, th);
		int64_t long gid = localpatches[i].getGlobalId();
		regionindex[gid] = (regions.size() );
		regions.push_back(r);
	}

  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.init)
}

/**
 * Method:  finalize[]
 */
void
pde::FieldVarCxx_impl::finalize_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.finalize)
	std::vector< pde::RegionCxx >::iterator piter;
	for( piter = regions.begin(); piter != regions.end(); piter++ ) {
		(*piter).finalize();
	}
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.finalize)
}

/**
 * Method:  updateGhosts[]
 */
void
pde::FieldVarCxx_impl::updateGhosts_impl (
  /* in */::pde::BoundPos direction,
  /* in */::pde::RegionCxx source,
  /* inout */::pde::RegionCxx& dest ) 
{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.updateGhosts)
	(void) direction; // not needed unless optimizing loops to eliminate inner coord transformations.
	if (d_stencil <1) { 
		return; // no ghosts to copy
	}
	if (coll != pde::MeshColl_CENTERS) {
		BOCCA_THROW_CXX(sidl::SIDLException, "ghosts unsupported except for CENTERS collocation yet.");
	}
	if (source._is_nil() ) {
		std::cout << "crap source sent to updateghosts" << std::endl;
		BOCCA_THROW_CXX(sidl::SIDLException, "crap source sent to updateghosts");
	}
	if (dest._is_nil() ) {
		std::cout << "crap dest sent to updateghosts" << std::endl;
		BOCCA_THROW_CXX(sidl::SIDLException, "crap dest sent to updateghosts");
	}

	pde::Patch sourcePatch = source.getPatch();
	int32_t loCoord[3]  = {0,0,0};
	int32_t hiCoord[3]  = {0,0,0};
	std::cout << d_dim << loCoord[0] << loCoord[1] << loCoord[2] << hiCoord[0] << hiCoord[1] 
		  << hiCoord[2] << std::endl;
	if (! dest.computeOverlap(sourcePatch, loCoord, hiCoord, d_dim) ) {
		return;
	}
	
	sidl::array< double > sdata = source.getData(tcur);
	sidl::array< double > ddata = dest.getData(tcur);
	sidl::array< int32_t > srclower, srcupper, destlower, destupper;
	srclower = source.getLowerCorner();
	srcupper = source.getUpperCorner();
	destlower = dest.getLowerCorner();
	destupper = dest.getUpperCorner();

	for (int32_t v = 0; v < fnvars; v++) {
		int32_t k0=0, k1=0, j0=0, j1=0; 
		int32_t i0 = loCoord[0], i1 = hiCoord[0];
		if (d_dim > 1) {
			j0 = loCoord[1], j1 = hiCoord[1];
		}
		if (d_dim > 2) {
			k0 = loCoord[2], k1 = hiCoord[2];
		}
		for (int32_t k = k0; k <= k1; k++) {	
			for (int32_t j = j0; j <= j1; j++) {	
				for (int32_t i = i0; i <= i1; i++) {	
					int32_t srcindex, destindex;
					srcindex = coordToIndex(v, srclower, srcupper, i, j, k);
					destindex = coordToIndex(v, destlower, destupper, i, j, k);
					ddata.set(destindex, sdata[srcindex]);
						
				}
			}
		}
	}
    
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.updateGhosts)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
pde::FieldVarCxx_impl::boccaForceUsePortInclude_impl (
  /* in */::pde::Patch dummy0,
  /* in */::pde::RegionCxx dummy1,
  /* in */::pde::BoundPos dummy2,
  /* in */::pde::Mesh dummy3,
  /* in */::pde::Region dummy4 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(pde.FieldVarCxx.boccaForceUsePortInclude)
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;
    (void)dummy3;
    (void)dummy4;

  // Bocca generated code. bocca.protected.end(pde.FieldVarCxx.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.boccaForceUsePortInclude)
}

/**
 *  what's the spatial dimension of the data ? Error returns -1 
 */
int32_t
pde::FieldVarCxx_impl::getDimension_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.getDimension)
	INITCHECK;
	return d_dim;
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.getDimension)
}

/**
 *  @return number of regions assigned to the local process. The
 * regionIds used in other functions range [0 - getRegionCount()-1]
 */
int32_t
pde::FieldVarCxx_impl::getRegionCount_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.getRegionCount)
	INITCHECK;
	return (int32_t) regions.size();
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.getRegionCount)
}

/**
 *  number of dependent vars in the vector. 
 */
int32_t
pde::FieldVarCxx_impl::getNVars_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.getNVars)
	INITCHECK;
	return fnvars;
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.getNVars)
}

/**
 *  
 * @return lower bounding box corner of the regionId given.
 * result array will be getDimension() long.
 */
::sidl::array<int32_t>
pde::FieldVarCxx_impl::getLowerCorner_impl (
  /* in */int32_t regionId ) 
{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.getLowerCorner)
	INITCHECK;
	PIDCHECK(regionId);
	return (regions.at(regionId)).getLowerCorner();
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.getLowerCorner)
}

/**
 *  
 * @return upper bounding box corner of the local regionId given.
 * result array will be getDimension() long.
 */
::sidl::array<int32_t>
pde::FieldVarCxx_impl::getUpperCorner_impl (
  /* in */int32_t regionId ) 
{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.getUpperCorner)
	INITCHECK;
	PIDCHECK(regionId);
	return (regions.at(regionId)).getUpperCorner();
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.getUpperCorner)
}

/**
 *  @return  array 'dimension' long with sizes in X,Y,Z directions. 
 */
::sidl::array<int32_t>
pde::FieldVarCxx_impl::getShape_impl (
  /* in */int32_t regionId ) 
{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.getShape)
	INITCHECK;
	PIDCHECK(regionId);
	return (regions.at(regionId)).getShape();
    // DO-DELETE-WHEN-IMPLEMENTING exception.end()
    
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.getShape)
}

/**
 * Method:  getPatch[]
 */
::pde::Patch
pde::FieldVarCxx_impl::getPatch_impl (
  /* in */int32_t regionId ) 
{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.getPatch)
	INITCHECK;
	PIDCHECK(regionId);
	return (regions.at(regionId)).getPatch();
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.getPatch)
}

/**
 *  @param regionId in range [0..getRegionCount).
 * @return 1d array with size the product of getShape()[i] for all i=[0.dim-1].
 */
::sidl::array<double>
pde::FieldVarCxx_impl::getData_impl (
  /* in */int32_t time,
  /* in */int32_t regionId ) 
{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.getData)
	return (regions.at(regionId)).getData(time);
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.getData)
}

/**
 *  Get mesh position indices from corners and position in 1d data array if all from the same regionId.
 * outputs are undefined if first/last are outside dimensions [1..3].
 * @param index position in data 1d array.
 * @param lowerCorner
 * @param upperCorner
 * @param i0 output index in dimension 0.
 * @param i1 output index in dimension 0 if 2 or 3d, else undefined.
 * @param i2 output index in dimension 0 if 2 or 3d, else undefined.
 */
void
pde::FieldVarCxx_impl::indexToCoord_impl (
  /* in */int32_t index,
  /* in array<int> */::sidl::array<int32_t> lowerCorner,
  /* in array<int> */::sidl::array<int32_t> upperCorner,
  /* out */int32_t& i0,
  /* out */int32_t& i1,
  /* out */int32_t& i2 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.indexToCoord)
        int32_t dim = lowerCorner.length(0);
        int32_t volume = 1;
	volume = mesh.boxVolume(lowerCorner, upperCorner);
	index = index % volume;
        if (dim == 1) {
                i0 = lowerCorner[0] + index;
		i1 = i2 = 0;
        }
        if (dim == 2) {
                int32_t len0 = 1 + upperCorner[0] - lowerCorner[0];
                i1 = (index / len0) + lowerCorner[1];
                i0 = (index % len0) + lowerCorner[0];
		i2 = len0;
        }
        if (dim == 3) {
		int32_t r1;
                int32_t len1 = 1 + upperCorner[1] - lowerCorner[1];
                int32_t len0 = 1 + upperCorner[0] - lowerCorner[0];
                i2 = index / (len0*len1);
                r1 = index % (len0*len1);
                i1 = r1 / len0;
                i0 = r1 % len0;
                i2 += lowerCorner[2];
                i1 += lowerCorner[1];
                i0 += lowerCorner[0];
        }
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.indexToCoord)
}

/**
 *  Get position in 1d data array from mesh position indices if all from the same regionId.
 * Output is undefined if first/last are outside dimensions [1..3].
 * @param varNumber a number from [0..getNVars-1].
 * @param lowerCorner
 * @param upperCorner
 * @param i0 output index in dimension 0.
 * @param i1 output index in dimension 0 if 2 or 3d, else undefined.
 * @param i2 output index in dimension 0 if 2 or 3d, else undefined.
 * @return index position in data 1d array.
 */
int32_t
pde::FieldVarCxx_impl::coordToIndex_impl (
  /* in */int32_t varNumber,
  /* in array<int> */::sidl::array<int32_t> lowerCorner,
  /* in array<int> */::sidl::array<int32_t> upperCorner,
  /* in */int32_t i0,
  /* in */int32_t i1,
  /* in */int32_t i2 ) 
{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.coordToIndex)
	if (lowerCorner._is_nil() || upperCorner._is_nil()) {
		BOCCA_THROW_CXX(sidl::SIDLException,"corner given to pde.FieldVarCxx.coordToIndex");
	}
        int32_t dim = lowerCorner.length(0);
        int32_t volume = 1;
	volume = mesh.boxVolume(lowerCorner, upperCorner);
        if (dim == 1) {
                int index = i0 - lowerCorner[0];
		return index + varNumber*volume;
        }
        if (dim == 2) {
                int32_t len0 = 1 + upperCorner[0] - lowerCorner[0];
                int32_t index = (i0 - lowerCorner[0]) + len0*(i1 - lowerCorner[1]);
                return index + varNumber*volume;
        }
        if (dim == 3) {
                int32_t len1 = 1 + upperCorner[1] - lowerCorner[1];
                int32_t len0 = 1 + upperCorner[0] - lowerCorner[0];
                int32_t index = (i0 - lowerCorner[0]) + len0*( (i1 - lowerCorner[1]) + len1 * (i2 - lowerCorner[2]));
		return index + varNumber*volume;
        }
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.coordToIndex)
}

/**
 *  get the type of mesh collocation you have 
 */
::pde::MeshColl
pde::FieldVarCxx_impl::getMeshColl_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.getMeshColl)
	INITCHECK;
	return coll;
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.getMeshColl)
}

/**
 *  get name of this fieldvariable. 
 */
::std::string
pde::FieldVarCxx_impl::getName_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.getName)
	INITCHECK;
	return fname;
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.getName)
}

/**
 *  @return Width of the halo/ghost cells for stencil purposes. 
 */
int32_t
pde::FieldVarCxx_impl::getStencilWidth_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.getStencilWidth)
	INITCHECK;
	return mesh.getSpaceStencil();
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.getStencilWidth)
}

/**
 *  @return Width of the halo cells for BC purposes. 
 */
int32_t
pde::FieldVarCxx_impl::getBoundaryWidth_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.getBoundaryWidth)
	INITCHECK;
	return mesh.getBoundaryWidth();
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.getBoundaryWidth)
}

/**
 * Method:  dim2BoundPos[]
 */
void
pde::FieldVarCxx_impl::dim2BoundPos_impl (
  /* in */int32_t dim,
  /* out */::pde::BoundPos& lo,
  /* out */::pde::BoundPos& hi ) 
{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.dim2BoundPos)
	switch (dim) {
	case 1:
		lo = pde::BoundPos_LOW0;
		hi = pde::BoundPos_HIGH0;
		break;
	case 2:
		lo = pde::BoundPos_LOW1;
		hi = pde::BoundPos_HIGH1;
		break;
	case 3:
		lo = pde::BoundPos_LOW2;
		hi = pde::BoundPos_HIGH2;
		break;
	default:
		BOCCA_THROW_CXX(sidl::SIDLException,"bad dim given to dim2BoundPos");
	}

  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.dim2BoundPos)
}

/**
 *  BC and adapt bndry update. 
 */
int32_t
pde::FieldVarCxx_impl::boundaryUpdate_impl (
  /* in */int32_t time ) 
{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.boundaryUpdate)
	INITCHECK;
        sidl::array< int32_t > wlb = sidl::array< int32_t >::create1d(d_dim);
        sidl::array< int32_t > wub = sidl::array< int32_t >::create1d(d_dim);
        sidl::array< int32_t > wshape = sidl::array< int32_t >::create1d(d_dim);
        int32_t tcur = time;

	boundary.startApplication(fname);
        for (int32_t i = 1; i <= d_dim; i++) {
                pde::BoundPos lowside = pde::BoundPos_LOW0, highside = pde::BoundPos_LOW0;
                dim2BoundPos(i, lowside, highside);

		sidl::array< double > data;
		sidl::array< int32_t > lbc;
		sidl::array< int32_t > ubc;
		sidl::array< int32_t > shapec;

		int32_t nvars = getNVars();

                mesh.getBoundaryWindow(lowside, wlb, wub, wshape);
                boundary.setWindow(lowside, wlb, wub, wshape);

                for (int32_t region = 0; region < getRegionCount(); region++) {

                        data = getData(tcur, region);
                        lbc = getLowerCorner(region);
                        ubc = getUpperCorner(region);
                        shapec = getShape(region);

                        boundary.compute( data, lbc, ubc, shapec, nvars);
                }

                mesh.getBoundaryWindow(highside, wlb, wub, wshape);
                boundary.setWindow(highside, wlb, wub, wshape);

                for (int32_t region = 0; region < getRegionCount(); region++) {

                        data = getData(tcur, region);
                        lbc = getLowerCorner(region);
                        ubc = getUpperCorner(region);
                        shapec = getShape(region);

                        boundary.compute( data, lbc, ubc, shapec, nvars);
                }

        }
	boundary.endApplication(fname);
	return 0;

  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.boundaryUpdate)
}

/**
 *  @return total ticks recorded. 
 */
int32_t
pde::FieldVarCxx_impl::getCurrentTime_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.getCurrentTime)
	INITCHECK;
	return tcur;
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.getCurrentTime)
}

/**
 *  increment time (add 1 to total ticks recorded). Success return 0 
 */
int32_t
pde::FieldVarCxx_impl::incrementTime_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.incrementTime)
	INITCHECK;
	tcur++;
	std::vector< pde::RegionCxx >::iterator piter;
	for( piter = regions.begin(); piter != regions.end(); piter++ ) {
		(*piter).setCurrentTime(tcur);
	}
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.incrementTime)
}

/**
 *  @name  Data movement, swap, copy methods
 * @return  Error returns -1, else 0
 */
int32_t
pde::FieldVarCxx_impl::cycleTimes_impl () 

{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.cycleTimes)
	std::vector< pde::RegionCxx >::iterator piter;
	for( piter = regions.begin(); piter != regions.end(); piter++ ) {
		(*piter).cycletimes();
	}
  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.cycleTimes)
}

/**
 *  update ghost cells for time given. 
 */
int32_t
pde::FieldVarCxx_impl::synchronize_impl (
  /* in */int32_t time ) 
{
  // DO-NOT-DELETE splicer.begin(pde.FieldVarCxx.synchronize)
  // Insert-Code-Here {pde.FieldVarCxx.synchronize} (synchronize method) FIXME

    std::cout << "pde.FieldVarCxx.synchronize at time=" <<time << std::endl;
    std::vector< pde::RegionCxx >::iterator riter;
    int32_t myproc = mesh.getProcId();
#ifdef HAVE_MPI
    int iRecvReq = 0, iSendReq = 0 ;
#endif
	
    for( riter = regions.begin(); riter != regions.end(); riter++ ) 
    {
	pde::RegionCxx r = (*riter); 
	if (r._is_nil()) {
	    std::cout << "nil r regioncxx!!!" << std::endl;
	    continue;
	}
	pde::Patch p = r.getPatch();
	
	for (int i = 1; i <= d_dim; i++) // Loop over dimensions
	{
	    // First get domain boundaries
	    pde::BoundPos lo = pde::BoundPos_LOW0, hi = pde::BoundPos_LOW0;
	    dim2BoundPos(i, lo, hi); 
#ifdef DEBUG
	    std::cout << "lopos= " << lo <<  " hipos= " << hi << std::endl;
#endif

	    sidl::array< int64_t > nlo = p.getNeighborIds(lo);
	    sidl::array< int64_t > nhi = p.getNeighborIds(hi);
	    if (nlo._is_nil()){ std::cout << "nil nlo!!!" << std::endl; continue; }
	    if (nhi._is_nil()){ std::cout << "nil nhi!!!" << std::endl; continue; }

	    // Post receives from patches and regions on the lower end of this dimension, for
	    // this given region
	    for (int32_t k = nlo.lower(0); k <= nlo.upper(0); k++) 
	    {
		int64_t idlow = nlo[k];
		if ( idlow >= 0) 
		{
		    pde::Patch plow = mesh.getPatch(idlow);
		    if (plow.getProcId() == myproc ) 
		    {
#ifdef DEBUG
			std::cout << "idlow " << idlow << " rindex " << regionindex[idlow] 
				  << std::endl;
#endif
			pde::RegionCxx rlow = regions[regionindex[idlow]]; //  FIXME
			if (rlow._is_nil()) 
			{
			    std::cout << "nil regioncxx!!!" << std::endl;
			    continue;
			}
			updateGhosts(lo, rlow, r); 
		    } 
		    else 
		    {
#ifdef HAVE_MPI			
#ifdef DEBUG
			std::cout << " posting receive a" <<std::endl;
			std::cout << " idlow " << idlow << " rindex " << regionindex[idlow] 
				  << " plow.procid= " << plow.getProcId()<< " myproc=" << myproc 
				  << std::endl;
#endif
			if ( iRecvReq == recvReqs_.size() ) // I haven't enough requests
			{
			    ::pde::NBRequest *pR = new pde::NBRequest() ;
			    recvReqs_.push_back(pR) ;
			}
			updateGhostsPostRecvs_( plow, r, i, ::pde::NBRequest::LO, time, 
					       recvReqs_[iRecvReq] )  ;
			iRecvReq++ ;
#endif // HAVE_MPI
		    }
		} // End of loop over whether a neighboring patch exists
	    } // End of loop over all  my neighboring patches from whom i request data.
	    
	    // Post receives from patches and regions on the upper end of this dimension, for
	    // this given region
	    for (int32_t k = nhi.lower(0); k <= nhi.upper(0); k++) 
	    {
		int64_t idhigh = nhi[k];
		if ( idhigh >= 0) 
		{
		    pde::Patch phigh = mesh.getPatch(idhigh);
		    if (phigh.getProcId() == myproc ) 
		    {
#ifdef DEBUG
			std::cout << "idhigh " << idhigh << " rindex " << regionindex[idhigh] 
				  << std::endl;
#endif
			pde::RegionCxx rhigh = regions.at(regionindex[idhigh]); // FIXME
			if (rhigh._is_nil()){std::cout << "nil rhi regioncxx!!!" << std::endl; continue;}
			if (r._is_nil()){std::cout << "sending nil r regioncxx!!!" << std::endl; continue;}
			updateGhosts(hi, rhigh, r); 
		    } 
		    else 
		    {
#ifdef HAVE_MPI
#ifdef DEBUG
			std::cout << " posting receive b" <<std::endl;
			std::cout << " idhigh " << idhigh << " rindex " << regionindex[idhigh] 
				  << " phigh.procid= " << phigh.getProcId()<< " myproc=" << myproc 
				  << std::endl;
#endif
			if ( iRecvReq == recvReqs_.size() ) // I haven't enough requests
			{
			    ::pde::NBRequest *pR = new pde::NBRequest() ;
			    recvReqs_.push_back(pR) ;
			}
			updateGhostsPostRecvs_( phigh, r, i, ::pde::NBRequest::HI, time, 
					       recvReqs_[iRecvReq] )  ;
			iRecvReq++ ;
#endif // HAVE_MPI 
		    }
		} // End of test if a neighbor exists
	    } // end of loop over patches from whom i request
	    
	} // End of loop over dimensions
    } // End of loop over regions on this processor
    
#ifdef HAVE_MPI
    // make sure all receives are posted before any sends,
    // else mpi internal buffering behavior may get worse.
    int64_t comm = mesh.getCommunicator();
    MPI_Fint fcomm = comm;
    MPI_Comm ccomm = MPI_Comm_f2c(fcomm);
    if (forceReceives) MPI_Barrier(ccomm);
#endif // HAVE_MPI
    
#ifdef HAVE_MPI
    /*
      Now loop over regions on this processor. For each region, figure 
      out which section needs to be transferred and to whom.. Then send them.
    */
    for( riter = regions.begin(); riter != regions.end(); riter++ ) 
    {
	// Extract the region and the patch
	pde::RegionCxx r = (*riter); 
	if (r._is_nil()){ std::cout << "nil r regioncxx!!!" << std::endl; continue; }
	pde::Patch p = r.getPatch();

	// Loop over dimensions
	for (int idim = 1; idim <= d_dim; idim++) 
	{
	    // First get domain boundaries and then neighbors
	    pde::BoundPos lo = pde::BoundPos_LOW0, hi = pde::BoundPos_LOW0;
	    dim2BoundPos(idim, lo, hi); 

	    // Hi and Lo neighbors
	    sidl::array< int64_t > nlo = p.getNeighborIds(lo);
	    sidl::array< int64_t > nhi = p.getNeighborIds(hi);

	    // check. regions near the domain boundaries will not have neigbors
	    // on one side.
	    if (nlo._is_nil()){ std::cout << "nil nlo!!!" << std::endl; continue; }
	    if (nhi._is_nil()){ std::cout << "nil nhi!!!" << std::endl; continue; }

	    // loop over my lo neighbors and post sends to them. Only to the off-proc ones
	    for (int32_t k = nlo.lower(0); k <= nlo.upper(0); k++) 
	    {
		int64_t idlow = nlo[k]; // destRegion's id
		if ( idlow >= 0) 
		{
		    pde::Patch plow = mesh.getPatch(idlow);
		    if (plow.getProcId() != myproc ) // Off-proc neighbors only
		    {
#ifdef DEBUG
			std::cout << " posting send to neighbor low: idlow " << idlow 
				  << " rindex " << regionindex[idlow] << " plow.procid= " 
				  << plow.getProcId()<< " myproc=" << myproc << std::endl;
#endif
			if ( iSendReq == sendReqs_.size() ) // I haven't enough requests
			{
			    ::pde::NBRequest *pR = new pde::NBRequest() ;
			    sendReqs_.push_back(pR) ;
			}
			updateGhostsPostSends_( r, plow, idim, ::pde::NBRequest::LO, time, 
					       sendReqs_[iSendReq] )  ;
			iSendReq++ ;
		    }
		} // End of if id > 0
	    } // End of loop over sends to low neighbors

	    for (int32_t k = nhi.lower(0); k <= nhi.upper(0); k++) 
	    {
		int64_t idhigh = nhi[k];
		if ( idhigh >= 0) 
		{
		    pde::Patch phigh = mesh.getPatch(idhigh);
		    if (phigh.getProcId() != myproc ) // off-proc neighbors only
		    {
#ifdef DEBUG
			std::cout << " posting sends to neighbor hi: idhigh " << idhigh 
				  << " rindex " << regionindex[idhigh] << " phigh.procid= " 
				  << phigh.getProcId()<< " myproc=" << myproc << std::endl;
#endif
			if ( iSendReq == sendReqs_.size() ) // I haven't enough requests
			{
			    ::pde::NBRequest *pR = new pde::NBRequest() ;
			    sendReqs_.push_back(pR) ;
			}
			updateGhostsPostSends_( r, phigh, idim, ::pde::NBRequest::HI, time, 
					       sendReqs_[iSendReq] )  ;
			iSendReq++ ;
		    } // End of test over off-proc region
		}
	    } // End of loop over hi neighbors
	} // End of loop over dimensions
    } // End of loop over regions
#endif
    

#ifdef HAVE_MPI
     /*
       OK, all my receives have been posted, and I have sent regions that others
       might need, via isend. All other processors should have done this by now. So
       wait for my receives and sends to be satified
     */
    
    int nRecvReqs = recvReqs_.size() ;
    MPI_Request *arrayOfRecvReqs = new MPI_Request [ nRecvReqs ] ;
    MPI_Status *arrayOfRecvStatus = new MPI_Status [ nRecvReqs ] ;
    for (int i = 0 ; i < nRecvReqs; i++)
	arrayOfRecvReqs[i] = recvReqs_[i]->getMPIRequest() ;
    
    MPI_Waitall( nRecvReqs, arrayOfRecvReqs, arrayOfRecvStatus );

    int nSendReqs = sendReqs_.size() ;
    MPI_Request *arrayOfSendReqs = new MPI_Request [ nSendReqs ] ;
    MPI_Status *arrayOfSendStatus = new MPI_Status [ nSendReqs ] ;
    for (int i = 0 ; i < nSendReqs; i++)
	arrayOfSendReqs[i] = sendReqs_[i]->getMPIRequest() ;

    MPI_Waitall( nSendReqs, arrayOfSendReqs, arrayOfSendStatus );
    
    delete [] arrayOfRecvReqs ;
    delete [] arrayOfSendReqs ;
    delete [] arrayOfRecvStatus ;
    delete [] arrayOfSendStatus ;

    // All done; barrier and leave
    MPI_Barrier( ccomm ) ;

#endif // HAVE_MPI

  // DO-NOT-DELETE splicer.end(pde.FieldVarCxx.synchronize)
}


// DO-NOT-DELETE splicer.begin(pde.FieldVarCxx._misc)
// Insert-Code-Here {pde.FieldVarCxx._misc} (miscellaneous code)
void
pde::FieldVarCxx_impl::dim2BoundPos (int32_t dim, pde::BoundPos & lo, pde::BoundPos & hi)
{
	switch (dim) {
	case 1:
		lo = pde::BoundPos_LOW0;
		hi = pde::BoundPos_HIGH0;
		break;
	case 2:
		lo = pde::BoundPos_LOW1;
		hi = pde::BoundPos_HIGH1;
		break;
	case 3:
		lo = pde::BoundPos_LOW2;
		hi = pde::BoundPos_HIGH2;
		break;
	default:
		BOCCA_THROW_CXX(sidl::SIDLException, "pde.FieldVarCxx.dim2BoundPos called incorrectly");
	}
}

#ifdef HAVE_MPI
void 
pde::FieldVarCxx_impl::updateGhostsPostRecvs_( ::pde::Patch &srcPatch, ::pde::RegionCxx &destRegion,
					      int idim, ::pde::NBRequest::LoHiSideType lohi, 
					      int64_t time, ::pde::NBRequest *request)
{

    // if this is a brand new request, configure it.
    if ( request->getInitStatus() == false )
    {

	int64_t srcRegionId = srcPatch.getGlobalId() ; // Region Id of where i'm going to get data from
	int32_t srcProcId   = srcPatch.getProcId()   ; // the proc where it is now
	int32_t ndims       = srcPatch.getDimension();

	int64_t destRegionId = destRegion.getPatch().getGlobalId() ; // Region Id where it'll end up.
	int32_t destProcId   = destRegion.getPatch().getProcId() ; // this should be my proc
	assert( destProcId == mesh.getProcId() ) ; // making sure

	int64_t c = mesh.getCommunicator() ; MPI_Fint fcomm = c ;
	MPI_Comm comm = MPI_Comm_f2c(fcomm) ;

	sidl::array<int32_t> shape = destRegion.getShape() ;
	sidl::array<int32_t> dummy  = sidl::array<int32_t>::create1d(4) ; 
	dummy.set(0, shape[0]) ;  dummy.set(3, fnvars) ;
	if (ndims > 1 ) dummy.set(1, shape[1]) ; else dummy.set(1, 1) ;
	if (ndims > 2 ) dummy.set(2, shape[2]) ; else dummy.set(2, 1) ;
#ifdef DEBUG
	std::cout << " Posting RECV req on proc " << destProcId  << " src id = " << srcRegionId 
		  << " on proc " << srcProcId << " dummy : [" << dummy[0] << "X" << dummy[1] 
		  << "X" << dummy[2] << "X" << dummy[3] << "] " << std::flush ;
#endif
	request->init( ::pde::NBRequest::RECV, idim, lohi, dummy, d_stencil, srcRegionId, srcProcId,
		       destRegionId, destProcId, comm) ;
    }

    // extract the data pointer from the dest region, offset it depending on dimension and
    // side and execute the request.

    double *destData = destRegion.getData(time).first() ;

    int offset = 0;
    if ( lohi == ::pde::NBRequest::HI )
    {
	sidl::array<int32_t> shape = destRegion.getShape() ;
	if ( idim == 1 ) offset = shape[0] - d_stencil;
	if ( idim == 2 ) offset = shape[0] * (shape[1] - d_stencil) ;
	if ( idim == 3 ) offset = shape[0] * shape[1] * (shape[2] - d_stencil) ;
    }
    request->executeNBRequest( destData + offset ) ;

    return ;
}

void 
pde::FieldVarCxx_impl::updateGhostsPostSends_( ::pde::RegionCxx &srcRegion, ::pde::Patch &destPatch,
					       int idim, ::pde::NBRequest::LoHiSideType lohi, 
					       int64_t time, ::pde::NBRequest *request)
{

    // if this is a brand new request, configure it.
    if ( request->getInitStatus() == false )
    {
	int64_t srcRegionId = srcRegion.getPatch().getGlobalId() ; // Region Id of data src
	int32_t srcProcId   = srcRegion.getPatch().getProcId()   ; // the proc where it is now (here)
	assert( srcProcId == mesh.getProcId() ) ; // making sure

	int64_t destRegionId = destPatch.getGlobalId() ; // Region Id where it'll end up.
	int32_t destProcId   = destPatch.getProcId() ; // this should be my proc
	int32_t ndims        = destPatch.getDimension() ;
	
	int64_t c = mesh.getCommunicator() ; MPI_Fint fcomm = c ;
	MPI_Comm comm = MPI_Comm_f2c(fcomm) ;

	sidl::array<int32_t> shape = srcRegion.getShape() ;
	sidl::array<int32_t> dummy = sidl::array<int32_t>::create1d(4) ;
	dummy.set(0, shape[0]) ;   	dummy.set(3, fnvars) ;
	if (ndims > 1 ) dummy.set(1, shape[1]) ; else dummy.set(1, 1) ;
	if (ndims > 2 ) dummy.set(2, shape[2]) ; else dummy.set(2, 1) ;
#ifdef DEBUG
	std::cout << " Posting SEND req on proc " << srcProcId  << " dest id = " << destRegionId 
		  << " on proc " << destProcId << " dummy : [" << dummy[0] << "X" << dummy[1] 
		  << "X" << dummy[2] << "X" << dummy[3] << "] " << std::flush ;
#endif
	request->init( ::pde::NBRequest::SEND, idim, lohi, dummy, d_stencil, srcRegionId, srcProcId,
		       destRegionId, destProcId, comm) ;
    }
    
    // extract the data pointer from the dest region, offset it depending on dimension and
    // side and execute the request.

    double *srcData = srcRegion.getData(time).first() ;

    int offset = 0;

    if ( lohi == ::pde::NBRequest::LO )
    {
	sidl::array<int32_t> shape = srcRegion.getShape() ;
	if ( idim == 1 ) offset = d_stencil ;
	if ( idim == 2 ) offset = d_stencil * shape[0] ;
	if ( idim == 3 ) offset = d_stencil * shape[0] * shape[1] ;
    }
	
    if ( lohi == ::pde::NBRequest::HI )
    {
	sidl::array<int32_t> shape = srcRegion.getShape() ;
	if ( idim == 1 ) offset = shape[0] - 2*d_stencil;
	if ( idim == 2 ) offset = shape[0] * (shape[1] - 2*d_stencil) ;
	if ( idim == 3 ) offset = shape[0] * shape[1] * (shape[2] - 2*d_stencil) ;
    }

    request->executeNBRequest( srcData + offset ) ;

    return ;
}
#endif // HAVE_MPI

// #if 0
// 	BoxPatch p = localPatches[i];
// 	// one neighbor per patch edge.
// 	long[] nleft = p.getNeighborIDs(Boundary.XLOW);
// 	long[] nright = p.getNeighborIDs(Boundary.XHIGH);
// 	long idleft = nleft[0];
// 	long idright = nright[0];
// 	int myproc = p.getProcID();
// 	if ( idleft >= 0) 
// 	{
// 	    Patch pleft = fm_d.getPatchByID(idleft);
// 	    if (pleft.getProcID() != p.getProcID() ) 
// 	    {
// 		// in here do isend with tag sending patch
// 		sendCopyToLeft(pleft,p,fieldName,rholder);
// 	    }
// 	}
// 	if ( idright >= 0) 
// 	{
// 	    Patch pright = fm_d.getPatchByID(idright);
// 	    if (pright.getProcID() != p.getProcID() ) 
// 	    {
// 		// in here do isend
// 		sendCopyToRight(pright,p,fieldName,rholder);
// 	    }
// 	}
// #endif

// #if 0
//     /*
//       OK, all my receives have been posted, and I have sent regions that others
//       might need, via isend. All other processors should have done this by now. So
//       wait for my receives to be satified and copy the data into its rightful place.
//     */
//     int rhc = rholder.getActiveRequestCount();
//     if (rhc > 0 ) 
//     {
// 	Request[] requestBuff = rholder.getRequests();
// 	assert (requestBuff != null);
// 	assert (requestBuff.length == rhc);
// 	try 
// 	{
// 	    Request.Waitall(requestBuff);
// 	} 
// 	catch (Exception e) 
// 	{}
//     } 
//     else 
//     {
// 	// no posts to wait on.
//     }
    
// #endif
    
// DO-NOT-DELETE splicer.end(pde.FieldVarCxx._misc)

