/*
 * File:          functions_LinearFunction_Impl.h
 * Symbol:        functions.LinearFunction-v0.0
 * Symbol Type:   class
 * Babel Version: 1.0.8
 * Description:   Server-side implementation for functions.LinearFunction
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_functions_LinearFunction_Impl_h
#define included_functions_LinearFunction_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_function_FunctionPort_h
#include "function_FunctionPort.h"
#endif
#ifndef included_functions_LinearFunction_h
#include "functions_LinearFunction.h"
#endif
#ifndef included_gov_cca_CCAException_h
#include "gov_cca_CCAException.h"
#endif
#ifndef included_gov_cca_Component_h
#include "gov_cca_Component.h"
#endif
#ifndef included_gov_cca_ComponentRelease_h
#include "gov_cca_ComponentRelease.h"
#endif
#ifndef included_gov_cca_Port_h
#include "gov_cca_Port.h"
#endif
#ifndef included_gov_cca_Services_h
#include "gov_cca_Services.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif

/* DO-NOT-DELETE splicer.begin(functions.LinearFunction._includes) */
/* Put additional include files here... */
/* DO-NOT-DELETE splicer.end(functions.LinearFunction._includes) */

/*
 * Private data for class functions.LinearFunction
 */

struct functions_LinearFunction__data {
  /* DO-NOT-DELETE splicer.begin(functions.LinearFunction._data) */
  /* Bocca generated code. bocca.protected.begin(functions.LinearFunction._data) */
  /* Handle to framework services object */
  gov_cca_Services d_services;
  /* Bocca generated code. bocca.protected.end(functions.LinearFunction._data) */
  /* Put other private data members here... */
  /* Put other private data members here... */
  /* DO-NOT-DELETE splicer.end(functions.LinearFunction._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct functions_LinearFunction__data*
functions_LinearFunction__get_data(
  functions_LinearFunction);

extern void
functions_LinearFunction__set_data(
  functions_LinearFunction,
  struct functions_LinearFunction__data*);

extern
void
impl_functions_LinearFunction__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_functions_LinearFunction__ctor(
  /* in */ functions_LinearFunction self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_functions_LinearFunction__ctor2(
  /* in */ functions_LinearFunction self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_functions_LinearFunction__dtor(
  /* in */ functions_LinearFunction self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

extern struct function_FunctionPort__object* 
  impl_functions_LinearFunction_fconnect_function_FunctionPort(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct function_FunctionPort__object* 
  impl_functions_LinearFunction_fcast_function_FunctionPort(void* bi, 
  sidl_BaseInterface* _ex);
extern struct functions_LinearFunction__object* 
  impl_functions_LinearFunction_fconnect_functions_LinearFunction(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct functions_LinearFunction__object* 
  impl_functions_LinearFunction_fcast_functions_LinearFunction(void* bi, 
  sidl_BaseInterface* _ex);
extern struct gov_cca_CCAException__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_CCAException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_CCAException__object* 
  impl_functions_LinearFunction_fcast_gov_cca_CCAException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct gov_cca_Component__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Component(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_Component__object* 
  impl_functions_LinearFunction_fcast_gov_cca_Component(void* bi, 
  sidl_BaseInterface* _ex);
extern struct gov_cca_ComponentRelease__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_ComponentRelease(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_ComponentRelease__object* 
  impl_functions_LinearFunction_fcast_gov_cca_ComponentRelease(void* bi, 
  sidl_BaseInterface* _ex);
extern struct gov_cca_Port__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Port(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_Port__object* 
  impl_functions_LinearFunction_fcast_gov_cca_Port(void* bi, 
  sidl_BaseInterface* _ex);
extern struct gov_cca_Services__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Services(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_Services__object* 
  impl_functions_LinearFunction_fcast_gov_cca_Services(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_functions_LinearFunction_fconnect_sidl_BaseClass(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* 
  impl_functions_LinearFunction_fcast_sidl_BaseClass(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_functions_LinearFunction_fconnect_sidl_BaseInterface(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_functions_LinearFunction_fcast_sidl_BaseInterface(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* 
  impl_functions_LinearFunction_fconnect_sidl_ClassInfo(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* 
  impl_functions_LinearFunction_fcast_sidl_ClassInfo(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_functions_LinearFunction_fconnect_sidl_RuntimeException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_functions_LinearFunction_fcast_sidl_RuntimeException(void* bi, 
  sidl_BaseInterface* _ex);
extern
void
impl_functions_LinearFunction_boccaSetServices(
  /* in */ functions_LinearFunction self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_functions_LinearFunction_boccaReleaseServices(
  /* in */ functions_LinearFunction self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_functions_LinearFunction_checkException(
  /* in */ functions_LinearFunction self,
  /* in */ sidl_BaseInterface excpt,
  /* in */ const char* msg,
  /* in */ sidl_bool fatal,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_functions_LinearFunction_boccaForceUsePortInclude(
  /* in */ functions_LinearFunction self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_functions_LinearFunction_setServices(
  /* in */ functions_LinearFunction self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_functions_LinearFunction_releaseServices(
  /* in */ functions_LinearFunction self,
  /* in */ gov_cca_Services services,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_functions_LinearFunction_init(
  /* in */ functions_LinearFunction self,
  /* in array<double> */ struct sidl_double__array* params,
  /* out */ sidl_BaseInterface *_ex);

extern
double
impl_functions_LinearFunction_evaluate(
  /* in */ functions_LinearFunction self,
  /* in */ double x,
  /* out */ sidl_BaseInterface *_ex);

extern struct function_FunctionPort__object* 
  impl_functions_LinearFunction_fconnect_function_FunctionPort(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct function_FunctionPort__object* 
  impl_functions_LinearFunction_fcast_function_FunctionPort(void* bi, 
  sidl_BaseInterface* _ex);
extern struct functions_LinearFunction__object* 
  impl_functions_LinearFunction_fconnect_functions_LinearFunction(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct functions_LinearFunction__object* 
  impl_functions_LinearFunction_fcast_functions_LinearFunction(void* bi, 
  sidl_BaseInterface* _ex);
extern struct gov_cca_CCAException__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_CCAException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_CCAException__object* 
  impl_functions_LinearFunction_fcast_gov_cca_CCAException(void* bi, 
  sidl_BaseInterface* _ex);
extern struct gov_cca_Component__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Component(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_Component__object* 
  impl_functions_LinearFunction_fcast_gov_cca_Component(void* bi, 
  sidl_BaseInterface* _ex);
extern struct gov_cca_ComponentRelease__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_ComponentRelease(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_ComponentRelease__object* 
  impl_functions_LinearFunction_fcast_gov_cca_ComponentRelease(void* bi, 
  sidl_BaseInterface* _ex);
extern struct gov_cca_Port__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Port(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_Port__object* 
  impl_functions_LinearFunction_fcast_gov_cca_Port(void* bi, 
  sidl_BaseInterface* _ex);
extern struct gov_cca_Services__object* 
  impl_functions_LinearFunction_fconnect_gov_cca_Services(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct gov_cca_Services__object* 
  impl_functions_LinearFunction_fcast_gov_cca_Services(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseClass__object* 
  impl_functions_LinearFunction_fconnect_sidl_BaseClass(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseClass__object* 
  impl_functions_LinearFunction_fcast_sidl_BaseClass(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_BaseInterface__object* 
  impl_functions_LinearFunction_fconnect_sidl_BaseInterface(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_functions_LinearFunction_fcast_sidl_BaseInterface(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_ClassInfo__object* 
  impl_functions_LinearFunction_fconnect_sidl_ClassInfo(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_ClassInfo__object* 
  impl_functions_LinearFunction_fcast_sidl_ClassInfo(void* bi, 
  sidl_BaseInterface* _ex);
extern struct sidl_RuntimeException__object* 
  impl_functions_LinearFunction_fconnect_sidl_RuntimeException(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_RuntimeException__object* 
  impl_functions_LinearFunction_fcast_sidl_RuntimeException(void* bi, 
  sidl_BaseInterface* _ex);
#ifdef __cplusplus
}
#endif
#endif
