// 
// File:          randomgens_RandNumGenerator_Impl.cxx
// Symbol:        randomgens.RandNumGenerator-v0.0
// Symbol Type:   class
// Babel Version: 1.0.8
// Description:   Server-side implementation for randomgens.RandNumGenerator
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "randomgens_RandNumGenerator_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator._includes)
  // Insert-UserCode-Here {randomgens.RandNumGenerator._includes:prolog} (additional includes or code)
  // Bocca generated code. bocca.protected.begin(randomgens.RandNumGenerator._includes)
#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR
#include <iostream>
#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR
#endif // _BOCCA_STDERR
  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics will
  // include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif
  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}
  // This simplifies exception extending and rethrowing in c++, like SIDL_CHECK in C.
  // EX_OBJ must be the caught exception and is extended with msg and file/line/func added.
  // Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}
  // Bocca generated code. bocca.protected.end(randomgens.RandNumGenerator._includes)
  // Insert-UserCode-Here {randomgens.RandNumGenerator._includes:epilog} (additional includes or code)
  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator._includes)

// speical constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
randomgens::RandNumGenerator_impl::RandNumGenerator_impl() : StubBase(
  reinterpret_cast< void*>(::randomgens::RandNumGenerator::_wrapObj(
  reinterpret_cast< void*>(this))),false) , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator._ctor2)
  // Insert-Code-Here {randomgens.RandNumGenerator._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator._ctor2)
}

// user defined constructor
void randomgens::RandNumGenerator_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator._ctor)
    
  // Insert-UserCode-Here {randomgens.RandNumGenerator._ctor:prolog} (constructor method) 
  // bocca-default-code. User may edit or delete.begin(randomgens.RandNumGenerator._ctor)
   #if _BOCCA_CTOR_MESSAGES
     std::cerr << "CTOR randomgens.RandNumGenerator: " << BOOST_CURRENT_FUNCTION << " constructing " << this << std::endl;
   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(randomgens.RandNumGenerator._ctor)
  // Insert-UserCode-Here {randomgens.RandNumGenerator._ctor:epilog} (constructor method)
  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator._ctor)
}

// user defined destructor
void randomgens::RandNumGenerator_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator._dtor)
  // Insert-UserCode-Here {randomgens.RandNumGenerator._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(randomgens.RandNumGenerator._dtor) */
   #if _BOCCA_CTOR_MESSAGES
     std::cerr << "DTOR randomgens.RandNumGenerator: " << BOOST_CURRENT_FUNCTION << " destructing " << this << std::endl;
   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(randomgens.RandNumGenerator._dtor) 
  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator._dtor)
}

// static class initializer
void randomgens::RandNumGenerator_impl::_load() {
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator._load)
  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
randomgens::RandNumGenerator_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(randomgens.RandNumGenerator.boccaSetServices)
  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;
  this->d_services = services;
  typeMap = this->d_services.createTypeMap();
  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , "randomgens.RandNumGenerator: Error casting self to gov::cca::Port");
  } 
  // Provide a randomgen.RandomGeneratorPort port with port name RandomGeneratorPort 
  try{
    this->d_services.addProvidesPort(port, // implementing object
                                     "RandomGeneratorPort", // port instance name
                                     "randomgen.RandomGeneratorPort", // full sidl type of port
                                     typeMap); // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, "randomgens.RandNumGenerator: Error calling addProvidesPort(port,\"RandomGeneratorPort\", \"randomgen.RandomGeneratorPort\", typeMap) ", -2);
    throw;
  }    
  gov::cca::ComponentRelease cr = ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(randomgens.RandNumGenerator.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
randomgens::RandNumGenerator_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(randomgens.RandNumGenerator.boccaReleaseServices)
  this->d_services=0;
  // Un-provide randomgen.RandomGeneratorPort port with port name RandomGeneratorPort 
  try{
    services.removeProvidesPort("RandomGeneratorPort");
  } catch ( ::gov::cca::CCAException ex )  {
#ifdef _BOCCA_STDERR
    std::cerr << "randomgens.RandNumGenerator: Error calling removeProvidesPort(\"RandomGeneratorPort\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() << std::endl;
#endif // _BOCCA_STDERR
  }
  return;
  // Bocca generated code. bocca.protected.end(randomgens.RandNumGenerator.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
randomgens::RandNumGenerator_impl::boccaForceUsePortInclude_impl () 

{
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(randomgens.RandNumGenerator.boccaForceUsePortInclude)
  // Bocca generated code. bocca.protected.end(randomgens.RandNumGenerator.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument Svc will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
randomgens::RandNumGenerator_impl::setServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator.setServices)
  // Insert-UserCode-Here{randomgens.RandNumGenerator.setServices:prolog}
  // bocca-default-code. User may edit or delete.begin(randomgens.RandNumGenerator.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(randomgens.RandNumGenerator.setServices)
  
  // Insert-UserCode-Here{randomgens.RandNumGenerator.setServices:epilog}
  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning Svc and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument Svc will never be nil/null.
 * The argument Svc will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to Svc.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
randomgens::RandNumGenerator_impl::releaseServices_impl (
  /* in */::gov::cca::Services services ) 
// throws:
//     ::gov::cca::CCAException
//     ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator.releaseServices)
  // Insert-UserCode-Here {randomgens.RandNumGenerator.releaseServices} 
  // bocca-default-code. User may edit or delete.begin(randomgens.RandNumGenerator.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(randomgens.RandNumGenerator.releaseServices)
    
  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator.releaseServices)
}

/**
 * Method:  getRandomNumber[]
 */
double
randomgens::RandNumGenerator_impl::getRandomNumber_impl () 

{
  // DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator.getRandomNumber)
    
  double random_value = static_cast < double >(rand ());
  return random_value / RAND_MAX;
  // DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator.getRandomNumber)
}


// DO-NOT-DELETE splicer.begin(randomgens.RandNumGenerator._misc)
    
// DO-NOT-DELETE splicer.end(randomgens.RandNumGenerator._misc)

