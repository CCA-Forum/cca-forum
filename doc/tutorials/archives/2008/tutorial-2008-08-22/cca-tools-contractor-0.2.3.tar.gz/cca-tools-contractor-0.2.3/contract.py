#!/usr/bin/env python

import sys

from contractor import *
from packages import *

if packages_name and packages_version:
    print packages_name + ' version ' + packages_version + packages_copyright
    
try:
	main(sys.argv)
except KeyboardInterrupt:
	print "Exiting..."
