# This file is part of Contractor
# Original author: James Amundson, amundson@fnal.gov
# (c) 2007 Fermi Research Alliance, LLC
# For copying information, see the file LICENSE

#!/usr/bin/env python

from nodes import *
from utils import *
from root import *

import os, os.path
import string

_options = {}

def check_bin(binary_name, prefix=None):
    """
    Check for the existence of a binary in the system's path.
    
    @param binary_name: The name of the binary to find
    @type binary_name: str
    @return: True if the binary is found, otherwise False
    """
    
    if not binary_name:
        return None
    
    binpath = binary_name
    if prefix: binpath = os.path.realpath(os.path.join(prefix,binpath))
    elif binpath.startswith(os.sep):
        binpath = os.path.realpath(binary_name)
            
    # Split the system's path variable
    PATH = os.environ["PATH"]
    if os.pathsep in PATH:
        paths = PATH.split(os.pathsep)
    else:
        print "Don't know how to split path! Expected colon-separated, but encountered " + PATH
        print PATH
        return None
    
    # Search each path until we find the binary
    if not prefix:
        for path in paths:
            if os.access(os.path.join(path, binary_name), os.F_OK):
                if os.access(os.path.join(path, binary_name), os.X_OK):
                    if not os.path.isdir(os.path.join(path,binary_name)):
                        binpath = os.path.join(path, binary_name)
                        return binpath
                else:
                    binpath = os.path.join(path, binary_name)
                    print binary_name + " found at " + \
                            os.path.join(path, binary_name) + \
                            " but is not an executable."
                        
    # Check if the path exists and can be run
    if os.access(binpath, os.F_OK):
        if os.access(binpath, os.X_OK):
            return binpath
        else:
            print binpath + " found but cannot be executed."

    return None

def check_bin_list(binaries):
    """
    Check for the existance of the passed list of binaries and return the first
    one found to exist, or None.
    """
    for binary in binaries:
        binpath = check_bin(binary)
        if binpath:
            return binpath
    
    return None

def check_lib(library_name):
    """
    Check for the existence of a library that can be linked with.
    
    @param library_name: The name of the library to check
    @type library_name: str
    @return: True if the library can be linked against, otherwise False
    """
    flags = ""
    
    # Try to find and use pkg-config to get compile flags
    if check_bin("pkg-config"):
        pipe = os.popen("pkg-config --libs " + library_name + " >/dev/null 2>&1")
        data = pipe.read()
        ret = pipe.close()
        if not ret:
            flags = data
    
    # If no flags were set above set a default
    if not flags:
        if library_name[:3] == "lib":
            flags = "-l" + library_name[3:]
        else:
            flags = "-l" + library_name
    
    # Attempt to compile a test program linking with the library
    return check_compile(flags = flags)

def check_compile(code = "int main() { return 0; }", compiler = "cc -x c -", \
                    flags = ""):
    """
    Check to see if compiling a test program works.
    
    @param code: The test code to compile
    @type code: str
    @param compiler: How the compiler should be invoked to receive input from
                     standard in
    @type compiler: str
    @param flags: The flags to pass to the compiler to test
    @type flags: str
    @return: True if the command worked, false if it fails
    """
    cmd = "echo '" + code + "' | " + compiler + " -o compile_test " + flags + \
          " >/dev/null 2>&1"
    
    passed = True
    if os.system(cmd):
        passed = False
    
    if os.access("compile_test", os.F_OK):
        os.unlink("compile_test")
    
    return passed

class Option:
    def __init__(self,root,name,default,type,description,function=None,deps=[]):
        self.root = root
        self.name = name
        self.default = str(default)
        self.type = type
        self.description = description
        self.function = function
        self.configured = False
        self.deps = deps
        self.source = "default"
        self.filename = os.path.join(self.root.get_vars()["config_dir"],
                                     self.name)
        _options[self.name] = self

    def _have_value(self):
        return os.path.exists(self.filename)
    
    def _get(self):
        if self._have_value():
            f = open(self.filename,"r")
            source = f.readline()
            source = source.rstrip()
            value = f.readline()
            f.close()
        else:
            if self.function:
                source = "function"
                value = str(self.function())
            else:
                source = "default"
                value = self.default
        return (source,value)

    def _write_value(self,source,value):
        dirname = os.path.dirname(self.filename)
        if not os.path.isdir(dirname):
            os.makedirs(dirname)
        f = open(self.filename, "w")
        f.write("%s\n" % source)
        f.write("%s" % str(value))
        
    def get(self):
        if self._have_value():
            (source,value) = self._get()
            # Booleans cannot be converted to/from strings like other primitives
            # so the following hack is necessary!
            if value == "None":
                return None
            elif self.type != bool:
                return self.type(value)
            else:
                if value == "True":
                    return True
                else:
                    return False
        else:
            return self.type(self.default)
    
    def configure(self, user_opts={}):
        for dep in self.deps:
            if not dep.configured:
                dep.configure(user_opts)
        value = self.default
        source = "default"
        if self._have_value():
            (source,value) = self._get()
        if user_opts.has_key(self.name):
            source = "user"
            value = user_opts[self.name]
        elif self.function or value == 'function':
            source = "function"
            value = str(self.function())
        if self._have_value() and value != 'default':
            (old_source,old_value) = self._get()
            if value != old_value:
                self._write_value(source,value)
        else:
            if value == 'default': 
                source = 'default'
                value = self.default
            self._write_value(source,value)
        print self.name,"=",value,"(%s)" % source
        self.configured = True

    def help(self):
        print self.name,":",self.description,"(default=%s)" % self.default

    def display(self,output,show_source):
        (source,value) = self._get()
        output.write("%s=%s" % (self.name,value))
        if show_source:
            output.write(" (%s)" % source)
        output.write("\n")

    def reset(self):
        if self._have_value():
            os.remove(self.filename)

def get_prefix():
    if 'prefix' in _options:
        return local_root.set_install_dir(_options['prefix'].get())
    return None 

def configure_error(message):
    sys.stderr.write("Configuration error:\n%s\n" % message)
    sys.exit(1)

def configure(args):
    cmd = " ".join(args)
    user_opts = {}
    for arg in args:
        pair = string.split(arg,"=")
        if len(pair) < 2:
            configure_error('Improper configure argument "%s".\nArgument should be of the form "option=value".' % arg)
        option_name = pair[0]
        value = string.join(pair[1:],"=")
        if not _options.has_key(option_name):
            configure_error('Unknown configure option "%s".' % option_name)
        user_opts[option_name] = value
    for key in _options:
        if not _options[key].configured:
            _options[key].configure(user_opts)
    if 'prefix' in _options:
        local_root.set_install_dir(_options['prefix'].get())
    fname = os.path.join(local_root.get_vars()["config_dir"], "configure_cmd")
    if not os.path.exists(os.path.dirname(fname)):
        os.makedirs(os.path.dirname(fname))
    open(fname, "w").write(cmd + '\n')
    sys.exit(0)
            
def configure_help():
    for key in _options:
        _options[key].help()
    sys.exit(0)

def configure_show():
    fname = os.path.join(local_root.get_vars()["config_dir"], "configure_cmd")
    if os.path.exists(fname):
        print "Configured with '" + open(fname).read() + "'"
    for key in _options:
        _options[key].display(sys.stdout,show_source=1)
    sys.exit(0)

def configure_dump(args):
    if len(args) != 1 :
        configure_error("dump requires (one) filename")
    filename = args[0]
    f = open(filename,"w")
    for key in _options:
        _options[key].display(f,show_source=0)
    f.close()
    sys.exit(0)

def configure_import(args):
    if len(args) != 1 :
        configure_error("import requires (one) filename")
    filename = args[0]
    f = open(filename,"r")
    args = []
    for line in f.readlines():
        args.append(line.rstrip())
    f.close()
    configure(args)
    sys.exit(0)

def configure_reset():
    for key in _options:
        _options[key].reset()
    sys.exit(0)
    
