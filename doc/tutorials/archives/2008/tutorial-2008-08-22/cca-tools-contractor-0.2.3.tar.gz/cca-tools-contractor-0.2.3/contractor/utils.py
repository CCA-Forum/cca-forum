# This file is part of Contractor
# Original author: James Amundson, amundson@fnal.gov
# (c) 2007 Fermi Research Alliance, LLC
# For copying information, see the file LICENSE

#!/usr/bin/env python

import os,os.path,sys,glob,time
import timer

import events

_shell = '/bin/sh'
start_time = -1.7724539
def create_tag(target):
    f = open("%s" % target[0],'w')
    f.write('%s (%f)\n' % (time.strftime("%Y-%m-%d %H:%M:%S"),time.time()))
    f.close()

# Set Attribute Mode    <ESC>[{attr1};...;{attrn}m
#     * Sets multiple display attribute settings. The following lists
#       standard attributes:

# 0    Reset all attributes
# 1    Bright
# 2    Dim
# 4    Underscore    
# 5    Blink
# 7    Reverse
# 8    Hidden

#     Foreground Colours
# 30    Black
# 31    Red
# 32    Green
# 33    Yellow
# 34    Blue
# 35    Magenta
# 36    Cyan
# 37    White

#     Background Colours
# 40    Black
# 41    Red
# 42    Green
# 43    Yellow
# 44    Blue
# 45    Magenta
# 46    Cyan
# 47    White

command_pre = "*** contractor command: "
command_post = ""
time_pre = "--- contractor time: "
time_post = ""
error_msg_pre = "XXXXXXXXXXXXXX "
error_msg_post = ""
error_pre = ""
error_post = ""

command_pre = "\x1B[01;34m"
command_post = "\x1B[00m"
time_pre = "\x1B[02;32m"
time_post = "\x1B[00m"
error_msg_pre = "\x1B[00;41;37m"
error_msg_post = "\x1B[00m"
error_pre = "\x1B[00;31m"
error_post = "\x1B[00m"

def command_message(description):
    print "%s[%s]%s"%(command_pre,description,command_post)
    
def system_cmd(command_in, log_file=None):
    t0 = time.time()
    print "%s%s%s"%(command_pre,command_in,command_post)
    if log_file:
        command = "%s &> %s" % (command_in,log_file)
        if not os.path.isdir(os.path.dirname(log_file)):
            os.makedirs(os.path.dirname(log_file))
    else:
        command = command_in
    #print "Running cmd... " + command
    #retval = os.system(command)
    #retval = os.spawnlp(os.P_WAIT, "sh", "sh", "-c", command)
    retval = os.spawnlp(os.P_WAIT, _shell, _shell, "-c", command)
    if log_file:
        t1 = time.time()
        f = open(log_file + ".time","w")
        f.write("%0.4g seconds\n" % (t1-t0))
        f.close()
    return retval

def system_or_die(command_in, log_file=None):
    retval = system_cmd(command_in, log_file)
    if retval != 0:
        if log_file:
            print "%scontractor failed command output (final 10 lines):%s" % \
                  (error_msg_pre,error_post)
            os.system('tail -n 10 %s' % log_file)
            print "%scontractor failed command output end.%s" % \
                  (error_msg_pre,error_post)
            sys.stdout.write("%slog file is %s%s\n" % \
                             (error_pre,log_file,error_post))
        timer.show_timer()
        import root
        
        siteinfo = open('siteinfo.txt', 'w')
        siteinfo.write(os.popen('echo "# uname -a"; uname -a 2>&1; echo "# env"; env 2>&1;').read())
        siteinfo.close()
        try: os.system('cp siteinfo.txt ' + root.local_root.vars["log_dir"])
        except: pass
    
        archive = generate_error_archive(root.local_root.vars['base_dir'], [root.local_root.vars["log_dir"], root.local_root.vars["config_dir"]])

        events.signal("error", (command_in, log_file, archive))
        #raise RuntimeError, 'Failed system command'
        print "An archive of the logs has been saved to " + archive + \
              ". Please email this file to the CCA tools developers at " + \
              "norris@mcs.anl.gov"
        try:
            send_email(archive, 'norris@mcs.anl.gov')
        except: 
            pass
        
        sys.exit(1)
    return retval

def check_shell():
    global _shell
    _shell = '/bin/sh'
    realshellpath = os.path.realpath(_shell)
    if realshellpath == '/bin/dash':
        warn = False
        if os.path.exists('/bin/bash'):
            warn = True 
            _shell = '/bin/bash'
        elif os.path.exists('/bin/ksh'):
            warn = True
            _shell = '/bin/ksh'
        else:
            print 'Error: default shell is /bin/dash, which will likely cause many problems downstream. Giving up.'
            sys.exit(1)
        if warn: print 'Warning: default shell is /bin/dash. Contractor will use ' + _shell + ', but you will likely encounter problems in other tools.'
    
 
def generate_error_archive(rootdir, dirs):
    from configuration import check_bin
    d = os.getcwd()
    save = os.path.join(os.environ["HOME"], "cca-tools-logs.tar")

    if rootdir: os.chdir(rootdir)
    if os.path.exists(save): os.unlink(save)
    for dir in dirs:
        if dir.startswith(rootdir): d = dir[len(rootdir)+1:]
        os.system("tar -upf " + save + ' ' + d)
    zip = check_bin('bzip2')
    suffix = '.bz2'
    if not zip: 
        zip = check_bin('tar')
        suffix = '.gz'
    if zip:
        if os.path.exists(save + suffix): os.unlink(save + suffix)
        os.system(zip + ' ' + save)
        save += suffix
    return save

def send_email(file, to, server="localhost"):
    try:
        import smtplib
        from email.MIMEMultipart import MIMEMultipart
        from email.MIMEBase import MIMEBase
        from email.MIMEText import MIMEText
        from email.Utils import COMMASPACE, formatdate
        from email import Encoders
    except:
        return
    try:
        smtp = smtplib.SMTP(server)
    except:
        return
    response = raw_input('Would you like to try to send the email with the log now (y/n) ? [n] ')
    if not str(response).lower() in ['yes', 'y']:
        return 
    name = raw_input('Please enter your name: ')
    emailaddr = raw_input('Please enter your email address: ')
    fro = name + '<' + emailaddr + '>'

    msg = MIMEMultipart()
    msg['From'] = fro
    msg['To'] = COMMASPACE.join(to)
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = 'error log for cca-tools-contractor build'

    text = 'CCA tools build log: ' + msg['Date']
    msg.attach( MIMEText(text) )

    # Encode file and atach
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(file,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"'
                   % os.path.basename(file))
    msg.attach(part)


    smtp.sendmail(fro, to, msg.as_string() )
    smtp.close()
    return
    
def abs_rel_dir(base_dir, dir):
    if os.path.isabs(dir):
        retval = dir
    else:
        retval = os.path.join(base_dir,dir)
    return retval

def env_path_add(var, item, delimiter=':'):
    if os.environ.has_key(var):
        os.environ[var] = item + delimiter + os.environ[var]
    else:
        os.environ[var] = item

def listify(x):
    if type(x) == type([]) or type(x) == type(()):
        return x
    else:
        return [x]

class Changed_files:
    def __init__(self, path):
        self.old = {}
        self.new = {}
        self.new_files = []
        self.modified_files = []
        self.path = path
        os.path.walk(self.path,self.walker,self.old)
        
    def walker(self, arg, dirname, names):
        for name in names:
            fullpath = os.path.join(dirname,name)
            if not os.path.isdir(fullpath):
                arg[fullpath] = os.path.getmtime(fullpath)

    def end(self):
        os.path.walk(self.path,self.walker,self.new)
        for key in self.new.keys():
            if self.old.has_key(key):
                if self.old[key] != self.new[key]:
                    self.modified_files.append(key)
            else:
                self.new_files.append(key)

    def _dump(self,filename,pathlists):
        f = open(filename,"w")
        for pathlist in pathlists:
            for path in pathlist:
                f.write("%s\n" % path)
        f.close()
        
    def dump_new(self, filename):
        self._dump(filename,[self.new_files])
        
    def dump_modified(self, filename):
        self._dump(filename,[self.modified_files])

    def dump_all(self, filename):
        self._dump(filename,[self.new_files,self.modified_files])
