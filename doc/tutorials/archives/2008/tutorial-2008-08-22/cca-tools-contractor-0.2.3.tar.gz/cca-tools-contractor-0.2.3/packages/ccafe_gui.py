#!/usr/bin/env python

import os

from contractor import *
from ccaffeine import *

ccafe_gui_internal = Option(local_root, "ccafe_gui_internal", True, \
						bool, "Install internal version of Ccaffeine GUI")

#spec_classic_version = "0.5.7"
#spec_classic_url = "http://www.cca-forum.org/download/cca-tools/cca-tools-0.6.2_rc3+bocca-0.1.0-alpha/cca-spec-classic-" + spec_classic_version + ".tar.gz"


ccafe_gui_url = toolsurl + 'ccafe-gui-0.5.6.tar.gz'
ccafe_gui_version = "0.5.6"
    
class CcafeGUIUnpack(Unpack):
    def __init__(self):
        Unpack.__init__(self, url = ccafe_gui_url)
    
    def build_method(self):
        Unpack.build_method(self)
        os.chdir(self._var("build_dir"))
        if not os.path.exists(os.path.join(self._var("build_dir"),"configure.in")):
            system_or_die("mv ccafe-gui-" + ccafe_gui_version + "/* . && rm -rf ccafe-gui-" + ccafe_gui_version, self._log())
        os.chdir(self._var("root.base_dir"))
            
if ccafe_gui_internal.get():
	ccafe_gui = Package(local_root, "ccafe_gui", \
			[CcafeGUIUnpack(), \
			Configure(extra_args = "--with-ccafe-config=%s/bin/ccafe-config" % ccaffeine.get_var("root.install_dir")), \
			Make(), Install()], \
			[ccaffeine])
else:
	ccafe_gui = External_package("ccafe_gui")
