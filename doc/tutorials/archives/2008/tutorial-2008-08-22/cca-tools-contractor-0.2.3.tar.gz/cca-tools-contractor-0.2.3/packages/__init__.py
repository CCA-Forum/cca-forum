#!/usr/bin/env python

packages_name = 'CCA Tools Contractor Build'
packages_version = '0.2.3'
packages_copyright = ''

from common import *
from final import *
