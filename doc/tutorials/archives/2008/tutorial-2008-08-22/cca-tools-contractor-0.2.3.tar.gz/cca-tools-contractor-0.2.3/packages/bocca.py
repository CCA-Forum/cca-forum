#!/usr/bin/env python

import os

from contractor import *
from ccaffeine import *

bocca_internal = Option(local_root, "bocca_internal", True, \
						bool, "Install internal version of Ccaffeine GUI")

if nightly.get():
    bocca_version = 'nightly'
    bocca_url = nightlyurl + 'bocca.tar.gz'
else:
    bocca_version = "0.5.0"
    bocca_url = toolsurl + 'bocca-' + bocca_version + '.tar.gz'
    
# TODO: Remove this when we move to a new release that has it fixed
bash_fix = "find . -type f | grep make.install | xargs sed -e 's/\/bin\/sh/\/bin\/bash/'"

class BoccaUnpack(Unpack):
    def __init__(self):
        Unpack.__init__(self, url = bocca_url)
    
    def build_method(self):
        Unpack.build_method(self)
        if not nightly.get():
            os.chdir(self._var("build_dir"))
            if not os.path.exists(os.path.join(self._var("build_dir"),"configure.ac")):
                system_or_die("mv bocca-" + bocca_version + "/* . && rm -rf bocca-" + bocca_version, self._log())
            os.chdir(self._var("root.base_dir"))
            
class BoccaMake(Make):
    def __init__(self):
        Make.__init__(self, parallel = False)
    
    def build_method(self):
        os.environ["CCA_PMAKE"] = "-j " + str(get_num_cores())
        Make.build_method(self)
        del os.environ["CCA_PMAKE"]
        
if bocca_internal.get():
	bocca = Package(local_root, "bocca", \
			[BoccaUnpack(), \
			Configure(extra_args = "--with-ccafe-config=%s/bin/ccafe-config" % ccaffeine.get_var("root.install_dir")), \
			Build_command("bash-fix", bash_fix), BoccaMake(), Install()], \
			[ccaffeine])
else:
	bocca = External_package("bocca")
