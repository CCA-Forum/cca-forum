#!/usr/bin/env python

import os
import sys

from contractor import *

pythonpath = None
PYTHON = ["python2.5", "python2.4", "python2.3", "python2.2", "python"]
internal_python_version = '2.5.1'


# WARNING: The python module is in the process of being rewritten, so will be messy for a little while

class PythonConfigure(Stage):
    def __init__(self):
        Stage.__init__(self, "configure")
    
    def build_method(self):
        Stage.build_method(self)
        system = os.popen('uname -s').read().strip()
        if system == 'Darwin':
            # Grab prebuilt dylib
            pass
        
               
def python_check():
    """
    Try to find a working python or use the internal one if we are going to
    build it!
    """
    if not python_exec.get():
        from python import python_prefix
        if not python_prefix.get() or python_prefix.get().lower() == 'internal':
            return "python" + internal_python_version
        else: 
            return os.path.join(python_prefix.get(),python)
    else:
        pythonpath = check_bin_list(PYTHON)
        return pythonpath
    
python_exec = Option(local_root, "python", "", str, "Python interpreter", \
                function = python_check)

def python_lib_check():
    global pythonpath
    global python_exec
    from distutils import sysconfig
    libdir = sysconfig.get_config_var('LIBDIR')
    ver = str(sys.version_info[0]) + "." + str(sys.version_info[1])
    pythonpath = None

    if python_version.get(): ver = python_version.get()
    if python_exec.get(): 
        pythonpath = os.path.realpath(python_exec.get())
    else: 
        if not python_version.get():
            for p in PYTHON:
                pythonpath = check_bin('python' + ver)
                if pythonpath: break
        else:
            if python_prefix.get():
                if python_version.get():
                    pythonpath = check_bin('python' + python_version.get(), prefix=python_prefix.get())
                else:
                    pythonpath = check_bin('python', prefix=python_prefix.get())
    if not pythonpath:
        return ""
    
    python_prefixstr = os.path.dirname(pythonpath)
    python_config = check_bin("python-config", prefix=python_prefixstr)

    if python_config:
        args = os.popen(python_config + " --libs").read()
    else:
        python_config = check_bin("python" + ver + "-config")
        if python_config:
            args = os.popen("python" + ver + "-config --libs").read()
        else:
            args = "-lpython" + ver
    
    if check_compile(flags = args):
        if check_compile(flags = "-lpython"):
            if python_config:
                return os.popen(python_config + ' --prefix').read().strip()
            else:
                return "External"
        else:
            return ""
    else:
        return ""

def numpy_check():
    global pythonpath
    if pythonpath:
        if not os.popen(pythonpath + " -c 'import numpy' 2>&1"):
            return True
    return False


# Options 

python_prefix = Option(local_root, "python_prefix", "", str, \
                        "Prefix to python installation to use", \
                        function = python_lib_check)

numpy_internal = Option(local_root, "numpy_internal", False, bool, \
                            "Prefix to numpy installation", \
                            function = numpy_check, deps = [python_prefix])
    
python_version = Option(local_root, "python_version", "", str, \
                        "Python version",
                        function = python_lib_check)

py_version = "2.5.1"
if python_version.get():
    py_version = python_version.get()
if py_version.startswith(os.sep):
    py_version = os.popen(os.path.join(py_version,'bin','python') + ' --version').read().strip()

python_url = "http://www.python.org/ftp/python/" + py_version + \
             "/Python-" + py_version + ".tar.bz2"
             
numpy_version = "1.0.3-2"
#numpy_url = "http://downloads.sourceforge.net/numpy/numpy-" + \ # currently not working
numpy_url = "http://superb-west.dl.sourceforge.net/sourceforge/numpy/numpy-" + \
            numpy_version + ".tar.gz"

if not python_exec.get() and (not python_prefix.get() or python_prefix.get().lower() == 'internal'):
    python = Package(root = local_root, name="python", stages = [Unpack(url = python_url), \
                    Configure(extra_args = "--enable-shared"), Make(), \
                    Install()], depends = [], optiondeps = [python_prefix, python_version])
else:
    python = External_package("python")

if numpy_internal.get():
    numpy = Package(local_root, "numpy", [Unpack(url = numpy_url), \
                    Py_install()], [python])
else:
    numpy = External_package("numpy")
