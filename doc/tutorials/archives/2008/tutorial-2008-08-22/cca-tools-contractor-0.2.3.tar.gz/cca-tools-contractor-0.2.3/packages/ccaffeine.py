#!/usr/bin/env python

import sys, os, time
from contractor import *
from boost import *
from cca_spec_classic import *
from cca_spec_neo import *
from cca_spec_babel import *
from babel import *
from mpi import *
from common import *

ccaffeine_internal = Option(local_root, "ccaffeine_internal", True, \
                        bool, "Install internal version of ccaffeine")

if nightly.get():
    # Nightly version
    ccaffeine_version = "nightly"
    ccaffeine_url = nightlyurl + 'ccaffeine.tar.gz'
else:
    ccaffeine_version = '0.8.4'
    ccaffeine_url = toolsurl + 'ccaffeine-0.8.4.tar.gz'

class CcaffeineUnpack(Unpack):
    def __init__(self):
        Unpack.__init__(self, url = ccaffeine_url)
    
    def build_method(self):
        Unpack.build_method(self)
        if not nightly.get():
            os.chdir(self._var("build_dir"))
            if not os.path.exists(os.path.join(self._var("build_dir"),"configure.in")):
                system_or_die("mv ccaffeine-" + ccaffeine_version + "/* . && rm -rf ccaffeine-" + ccaffeine_version, self._log())
            os.chdir(self._var("root.base_dir"))

class CcaffeConfig(Configure):
    def __init__(self):
        if boost_prefix.get() == "":
            args = "--with-boost=" + boost.get_var("src_dir")
        else:
            args = "--with-boost=" + boost_prefix.get()
        
        if mpi.get():
            args += " --with-mpi=" + mpi.get()
        else:
            args += " --without-mpi"
        
        babel_version = validateBabelVersion()
        babel_version_arg = ''
        if babel_version == '':
            babel_version = time.strftime('%Y%m%d') # Yucky, but nonfatal
        if babel_version != '':
            babel_version_arg = ' --with-babel-experimental=%s' % babel_version
        Configure.__init__(self, extra_args = args + babel_version_arg)

class CcaffeMake(Make):
    def __init__(self):
        Make.__init__(self, parallel = False)
    
    def build_method(self):
        os.environ["CCA_PMAKE"] = "-j " + str(get_num_cores())
        Make.build_method(self)
        del os.environ["CCA_PMAKE"]

if ccaffeine_internal.get():
    ccaffeine = Package(local_root, "ccaffeine", \
                        [CcaffeineUnpack(), \
                        CcaffeConfig(), CcaffeMake(), \
                        Install()], [boost, spec_classic, spec_neo, spec_babel])
else:
    ccaffeine = External_package("ccaffeine")
