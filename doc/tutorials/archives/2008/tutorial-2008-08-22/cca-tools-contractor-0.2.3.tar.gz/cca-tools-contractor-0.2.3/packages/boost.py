#!/usr/bin/env python

from contractor import *

boost_prefix = Option(local_root, "boost_prefix", "", str,
						"Prefix to boost installation")

boost_version = "1.34.0"
boost_url = "http://downloads.sourceforge.net/boost/boost_" + \
			boost_version.replace(".", "_") + \
			".tar.bz2?modtime=1178933561&big_mirror=0"

if boost_prefix.get() == "":
	boost = Package(local_root, "boost", [Unpack(url = boost_url)], optiondeps=[boost_prefix])
else:
	boost = External_package("boost")

