#!/usr/bin/env python

import os

from contractor import *
from babel import *
from common import *

spec_babel_internal = Option(local_root, "spec_babel_internal", True, \
                        bool, "Install internal version of babel cca spec")

if nightly.get():
    spec_babel_version = "nightly"
    spec_babel_url = "http://www.cca-forum.org/download/cca-tools/nightly/cca-spec-babel.tar.gz"
else:
    spec_babel_url = toolsurl + 'cca-spec-babel-0.8.5.tar.gz'
    spec_babel_version = "0.8.5"

class SpecBabelUnpack(Unpack):
    def __init__(self):
        Unpack.__init__(self, url = spec_babel_url)
    
    def build_method(self):
        Unpack.build_method(self)
        if not nightly.get():
            os.chdir(self._var("build_dir"))
            if not os.path.exists(os.path.join(self._var("build_dir"),"configure.in")):
                system_or_die("mv cca-spec-babel-" + spec_babel_version + "/* . && rm -rf cca-babel-classic-" + spec_babel_version, self._log())
            os.chdir(self._var("root.base_dir"))
            
class SpecBabelConfigure(Configure):
    def __init__(self):
        Configure.__init__(self, extra_args = \
            "--disable-contrib --with-babel-config=%s/bin/babel-config" % \
            babel.get_var("root.install_dir"))
    
    def build_method(self):
        babel_version = os.popen("%s/bin/babel-config --version" % babel.get_var("root.install_dir")).read().strip()
        os.environ["CCA_BABEL_FORCE"] = babel_version
        Configure.build_method(self)
        del os.environ["CCA_BABEL_FORCE"]

class SpecBabelMake(Make):
    def __init__(self):
        Make.__init__(self, parallel = False)
    
    def build_method(self):
        os.environ["CCA_PMAKE"] = "-j " + str(get_num_cores())
        Make.build_method(self)
        del os.environ["CCA_PMAKE"]

if spec_babel_internal.get():
    spec_babel = Package(local_root, "spec_babel", \
            [SpecBabelUnpack(), \
            SpecBabelConfigure(), SpecBabelMake(), \
            Install()], [babel])
else:
    spec_babel = External_package("spec_bable")
