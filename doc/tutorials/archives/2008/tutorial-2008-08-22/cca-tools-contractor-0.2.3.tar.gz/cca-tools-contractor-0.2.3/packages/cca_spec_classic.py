#!/usr/bin/env python

import os

from contractor import *
from babel import *
from common import *

spec_classic_internal = Option(local_root, "spec_classic_internal", True, \
                        bool, "Install internal version of classic cca spec")

#spec_classic_version = "0.5.7"
#spec_classic_url = "http://www.cca-forum.org/download/cca-tools/cca-tools-0.6.2_rc3+bocca-0.1.0-alpha/cca-spec-classic-" + spec_classic_version + ".tar.gz"

# Nightly version
if nightly.get():
    spec_classic_version = "nightly"
    spec_classic_url = "http://www.cca-forum.org/download/cca-tools/nightly/cca-spec-classic.tar.gz"
else:
    spec_classic_url = toolsurl + 'cca-spec-classic-0.5.7.tar.gz'
    spec_classic_version = "0.5.7"
    
# TODO: Remove this when we move to a new release that has it fixed
bash_fix = "find . -type f | grep make.install | xargs sed -e 's/\/bin\/sh/\/bin\/bash/'"


class SpecClassicUnpack(Unpack):
    def __init__(self):
        Unpack.__init__(self, url = spec_classic_url)
    
    def build_method(self):
        Unpack.build_method(self)
        if not nightly.get():
            os.chdir(self._var("build_dir"))
            if not os.path.exists(os.path.join(self._var("build_dir"),"configure.in")):
                system_or_die("mv cca-spec-classic-" + spec_classic_version + "/* . && rm -rf cca-spec-classic-" + spec_classic_version, self._log())
            os.chdir(self._var("root.base_dir"))

if spec_classic_internal.get():
    spec_classic = Package(local_root, "spec_classic", \
            [SpecClassicUnpack(), \
            Configure(extra_args = "--with-babel-libtool=%s/bin/babel-libtool" % babel.get_var("root.install_dir")), \
            Build_command("bash-fix", bash_fix), Make(), Install()], \
            [babel])
else:
    spec_classic = External_package("spect_classic")
