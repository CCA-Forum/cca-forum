#!/usr/bin/env python

from contractor import *

prefix = Option(local_root, "prefix", "%(base_dir)s/install", str, \
                "Install all tools in the specified directory")

nightly = Option(local_root, 'nightly', False, bool, 'Install nightly snapshots of Babel and CCA tools')

toolsurl = 'http://www.cca-forum.org/download/cca-tools/cca-tools-latest/'
nightlyurl = 'http://www.cca-forum.org/download/cca-tools/nightly/'
#toolsurl = 'http://www.mcs.anl.gov/~norris/cca-tools/cca-tools-0.6.4/'

